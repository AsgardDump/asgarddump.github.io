#pragma once 
#include "SDK.h" 
 
 
// ScriptStruct ControlRig.RigUnit_SetBoneInitialTransform
// Size: 0x140(Inherited: 0x40) 
struct FRigUnit_SetBoneInitialTransform : public FRigUnitMutable
{
	struct FName bone;  // 0x40(0x8)
	char pad_72[8];  // 0x48(0x8)
	struct FTransform Transform;  // 0x50(0x60)
	struct FTransform Result;  // 0xB0(0x60)
	uint8_t  Space;  // 0x110(0x1)
	char pad_273_1 : 7;  // 0x111(0x1)
	bool bPropagateToChildren : 1;  // 0x111(0x1)
	char pad_274[6];  // 0x112(0x6)
	struct FCachedRigElement CachedBone;  // 0x118(0x20)
	char pad_312[8];  // 0x138(0x8)

}; 
// DelegateFunction ControlRig.ControlRigComponentDelegate__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FControlRigComponentDelegate__DelegateSignature
{
	struct UControlRigComponent* Component;  // 0x0(0x8)

}; 
// ScriptStruct ControlRig.RigUnit_MathFloatMul
// Size: 0x18(Inherited: 0x18) 
struct FRigUnit_MathFloatMul : public FRigUnit_MathFloatBinaryAggregateOp
{

}; 
// ScriptStruct ControlRig.RigUnit_InteractionExecution
// Size: 0x40(Inherited: 0x8) 
struct FRigUnit_InteractionExecution : public FRigUnit
{
	struct FControlRigExecuteContext ExecuteContext;  // 0x8(0x38)

}; 
// ScriptStruct ControlRig.SpaceControlNameAndChannel
// Size: 0x118(Inherited: 0x0) 
struct FSpaceControlNameAndChannel
{
	struct FName ControlName;  // 0x0(0x8)
	struct FMovieSceneControlRigSpaceChannel SpaceCurve;  // 0x8(0x110)

}; 
// ScriptStruct ControlRig.RigInfluenceEntry
// Size: 0x20(Inherited: 0x0) 
struct FRigInfluenceEntry
{
	struct FRigElementKey Source;  // 0x0(0xC)
	char pad_12[4];  // 0xC(0x4)
	struct TArray<struct FRigElementKey> AffectedList;  // 0x10(0x10)

}; 
// Function ControlRig.RigHierarchy.ResetPoseToInitial
// Size: 0x1(Inherited: 0x0) 
struct FResetPoseToInitial
{
	uint8_t  InTypeFilter;  // 0x0(0x1)

}; 
// Function ControlRig.ControlRig.ExecuteEvent
// Size: 0xC(Inherited: 0x0) 
struct FExecuteEvent
{
	struct FName InEventName;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)

}; 
// ScriptStruct ControlRig.RigUnit_FilterItemsByMetadataTags
// Size: 0x50(Inherited: 0x8) 
struct FRigUnit_FilterItemsByMetadataTags : public FRigUnit
{
	struct TArray<struct FRigElementKey> Items;  // 0x8(0x10)
	struct TArray<struct FName> Tags;  // 0x18(0x10)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool Inclusive : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct TArray<struct FRigElementKey> Result;  // 0x30(0x10)
	struct TArray<struct FCachedRigElement> CachedIndices;  // 0x40(0x10)

}; 
// Function ControlRig.ControlRig.Execute
// Size: 0x10(Inherited: 0x0) 
struct FExecute
{
	uint8_t  State;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	struct FName InEventName;  // 0x4(0x8)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool ReturnValue : 1;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)

}; 
// ScriptStruct ControlRig.RigUnit_StringMiddle
// Size: 0x30(Inherited: 0x8) 
struct FRigUnit_StringMiddle : public FRigUnit_StringBase
{
	struct FString Value;  // 0x8(0x10)
	int32_t Start;  // 0x18(0x4)
	int32_t Count;  // 0x1C(0x4)
	struct FString Result;  // 0x20(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_PoseIsEmpty
// Size: 0x80(Inherited: 0x8) 
struct FRigUnit_PoseIsEmpty : public FRigUnit_HierarchyBase
{
	struct FRigPose Pose;  // 0x8(0x70)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool IsEmpty : 1;  // 0x78(0x1)
	char pad_121[7];  // 0x79(0x7)

}; 
// ScriptStruct ControlRig.RigUnit_DebugTransformArrayMutable
// Size: 0x100(Inherited: 0x40) 
struct FRigUnit_DebugTransformArrayMutable : public FRigUnit_DebugBaseMutable
{
	struct TArray<struct FTransform> Transforms;  // 0x40(0x10)
	uint8_t  Mode;  // 0x50(0x1)
	char pad_81[3];  // 0x51(0x3)
	struct FLinearColor Color;  // 0x54(0x10)
	float Thickness;  // 0x64(0x4)
	float Scale;  // 0x68(0x4)
	struct FName Space;  // 0x6C(0x8)
	char pad_116[12];  // 0x74(0xC)
	struct FTransform WorldOffset;  // 0x80(0x60)
	char pad_224_1 : 7;  // 0xE0(0x1)
	bool bEnabled : 1;  // 0xE0(0x1)
	char pad_225[7];  // 0xE1(0x7)
	struct FRigUnit_DebugTransformArrayMutable_WorkData WorkData;  // 0xE8(0x10)
	char pad_248[8];  // 0xF8(0x8)

}; 
// Function ControlRig.ControlRig.ContainsEvent
// Size: 0xC(Inherited: 0x0) 
struct FContainsEvent
{
	struct FName InEventName;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)

}; 
// ScriptStruct ControlRig.RigUnit_MathQuaternionInverse
// Size: 0x50(Inherited: 0x50) 
struct FRigUnit_MathQuaternionInverse : public FRigUnit_MathQuaternionUnaryOp
{

}; 
// ScriptStruct ControlRig.RigUnit_MathVectorIsNearlyEqual
// Size: 0x40(Inherited: 0x8) 
struct FRigUnit_MathVectorIsNearlyEqual : public FRigUnit_MathVectorBase
{
	struct FVector A;  // 0x8(0x18)
	struct FVector B;  // 0x20(0x18)
	float Tolerance;  // 0x38(0x4)
	char pad_60_1 : 7;  // 0x3C(0x1)
	bool Result : 1;  // 0x3C(0x1)
	char pad_61[3];  // 0x3D(0x3)

}; 
// ScriptStruct ControlRig.CRSimPointContainer
// Size: 0x78(Inherited: 0x18) 
struct FCRSimPointContainer : public FCRSimContainer
{
	struct TArray<struct FCRSimPoint> Points;  // 0x18(0x10)
	struct TArray<struct FCRSimLinearSpring> Springs;  // 0x28(0x10)
	struct TArray<struct FCRSimPointForce> Forces;  // 0x38(0x10)
	struct TArray<struct FCRSimSoftCollision> CollisionVolumes;  // 0x48(0x10)
	struct TArray<struct FCRSimPointConstraint> Constraints;  // 0x58(0x10)
	struct TArray<struct FCRSimPoint> PreviousStep;  // 0x68(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_MathDoubleLess
// Size: 0x20(Inherited: 0x8) 
struct FRigUnit_MathDoubleLess : public FRigUnit_MathDoubleBase
{
	double A;  // 0x8(0x8)
	double B;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool Result : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)

}; 
// ScriptStruct ControlRig.RigUnit_MathVectorUnit
// Size: 0x38(Inherited: 0x38) 
struct FRigUnit_MathVectorUnit : public FRigUnit_MathVectorUnaryOp
{

}; 
// Function ControlRig.ControlRigComponent.CanExecute
// Size: 0x1(Inherited: 0x0) 
struct FCanExecute
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// ScriptStruct ControlRig.RigUnit_MathFloatPow
// Size: 0x18(Inherited: 0x18) 
struct FRigUnit_MathFloatPow : public FRigUnit_MathFloatBinaryOp
{

}; 
// ScriptStruct ControlRig.RigPreferredEulerAngles
// Size: 0x38(Inherited: 0x0) 
struct FRigPreferredEulerAngles
{
	uint8_t  RotationOrder;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FVector Current;  // 0x8(0x18)
	struct FVector Initial;  // 0x20(0x18)

}; 
// Function ControlRig.ControlRig.GetScriptAccessibleVariables
// Size: 0x10(Inherited: 0x0) 
struct FGetScriptAccessibleVariables
{
	struct TArray<struct FName> ReturnValue;  // 0x0(0x10)

}; 
// Function ControlRig.ControlRig.GetInteractionRigClass
// Size: 0x8(Inherited: 0x0) 
struct FGetInteractionRigClass
{
	UControlRig* ReturnValue;  // 0x0(0x8)

}; 
// Function ControlRig.ControlRig.CurrentControlSelection
// Size: 0x10(Inherited: 0x0) 
struct FCurrentControlSelection
{
	struct TArray<struct FName> ReturnValue;  // 0x0(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_CollectionItemAtIndex
// Size: 0x28(Inherited: 0x8) 
struct FRigUnit_CollectionItemAtIndex : public FRigUnit_CollectionBase
{
	struct FRigElementKeyCollection Collection;  // 0x8(0x10)
	int32_t Index;  // 0x18(0x4)
	struct FRigElementKey Item;  // 0x1C(0xC)

}; 
// ScriptStruct ControlRig.RigUnit_GetWorldTime
// Size: 0x28(Inherited: 0x8) 
struct FRigUnit_GetWorldTime : public FRigUnit_AnimBase
{
	float Year;  // 0x8(0x4)
	float Month;  // 0xC(0x4)
	float Day;  // 0x10(0x4)
	float WeekDay;  // 0x14(0x4)
	float Hours;  // 0x18(0x4)
	float Minutes;  // 0x1C(0x4)
	float Seconds;  // 0x20(0x4)
	float OverallSeconds;  // 0x24(0x4)

}; 
// ScriptStruct ControlRig.AnimationHierarchy
// Size: 0x88(Inherited: 0x78) 
struct FAnimationHierarchy : public FNodeHierarchyWithUserData
{
	struct TArray<struct FConstraintNodeData> UserData;  // 0x78(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_GetControlColor
// Size: 0x40(Inherited: 0x8) 
struct FRigUnit_GetControlColor : public FRigUnit
{
	struct FName Control;  // 0x8(0x8)
	struct FLinearColor Color;  // 0x10(0x10)
	struct FCachedRigElement CachedControlIndex;  // 0x20(0x20)

}; 
// ScriptStruct ControlRig.RigUnit_MathDoubleCos
// Size: 0x18(Inherited: 0x18) 
struct FRigUnit_MathDoubleCos : public FRigUnit_MathDoubleUnaryOp
{

}; 
// ScriptStruct ControlRig.ConstraintTarget
// Size: 0x70(Inherited: 0x0) 
struct FConstraintTarget
{
	struct FTransform Transform;  // 0x0(0x60)
	float Weight;  // 0x60(0x4)
	char pad_100_1 : 7;  // 0x64(0x1)
	bool bMaintainOffset : 1;  // 0x64(0x1)
	struct FTransformFilter Filter;  // 0x65(0x9)
	char pad_110[2];  // 0x6E(0x2)

}; 
// Function ControlRig.RigHierarchyController.ImportBones
// Size: 0x28(Inherited: 0x0) 
struct FImportBones
{
	struct USkeleton* InSkeleton;  // 0x0(0x8)
	struct FName InNameSpace;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bReplaceExistingBones : 1;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool bRemoveObsoleteBones : 1;  // 0x11(0x1)
	char pad_18_1 : 7;  // 0x12(0x1)
	bool bSelectBones : 1;  // 0x12(0x1)
	char pad_19_1 : 7;  // 0x13(0x1)
	bool bSetupUndo : 1;  // 0x13(0x1)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool bPrintPythonCommand : 1;  // 0x14(0x1)
	char pad_21[3];  // 0x15(0x3)
	struct TArray<struct FRigElementKey> ReturnValue;  // 0x18(0x10)

}; 
// Function ControlRig.ControlRig.SupportsEvent
// Size: 0xC(Inherited: 0x0) 
struct FSupportsEvent
{
	struct FName InEventName;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)

}; 
// ScriptStruct ControlRig.RigCurrentAndInitialTransform
// Size: 0x1C0(Inherited: 0x0) 
struct FRigCurrentAndInitialTransform
{
	struct FRigLocalAndGlobalTransform Current;  // 0x0(0xE0)
	struct FRigLocalAndGlobalTransform Initial;  // 0xE0(0xE0)

}; 
// ScriptStruct ControlRig.RigUnit_StringJoin
// Size: 0x38(Inherited: 0x8) 
struct FRigUnit_StringJoin : public FRigUnit_StringBase
{
	struct TArray<struct FString> Values;  // 0x8(0x10)
	struct FString Separator;  // 0x18(0x10)
	struct FString Result;  // 0x28(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_MathDoubleFloor
// Size: 0x20(Inherited: 0x8) 
struct FRigUnit_MathDoubleFloor : public FRigUnit_MathDoubleBase
{
	double Value;  // 0x8(0x8)
	double Result;  // 0x10(0x8)
	int32_t Int;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)

}; 
// Function ControlRig.ControlRig.ClearControlSelection
// Size: 0x1(Inherited: 0x0) 
struct FClearControlSelection
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// ScriptStruct ControlRig.RigUnit_MathFloatIsNearlyZero
// Size: 0x18(Inherited: 0x8) 
struct FRigUnit_MathFloatIsNearlyZero : public FRigUnit_MathFloatBase
{
	float Value;  // 0x8(0x4)
	float Tolerance;  // 0xC(0x4)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool Result : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// ScriptStruct ControlRig.MovieSceneControlRigParameterTemplate
// Size: 0xC0(Inherited: 0x80) 
struct FMovieSceneControlRigParameterTemplate : public FMovieSceneParameterSectionTemplate
{
	struct TArray<struct FEnumParameterNameAndCurve> Enums;  // 0x80(0x10)
	struct TArray<struct FIntegerParameterNameAndCurve> Integers;  // 0x90(0x10)
	struct TArray<struct FSpaceControlNameAndChannel> Spaces;  // 0xA0(0x10)
	struct TArray<struct FConstraintAndActiveChannel> Constraints;  // 0xB0(0x10)

}; 
// Function ControlRig.ControlRig.GetSupportedEvents
// Size: 0x10(Inherited: 0x0) 
struct FGetSupportedEvents
{
	struct TArray<struct FName> ReturnValue;  // 0x0(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_MathTransformAccumulateArray
// Size: 0xD0(Inherited: 0x40) 
struct FRigUnit_MathTransformAccumulateArray : public FRigUnit_MathTransformMutableBase
{
	struct TArray<struct FTransform> Transforms;  // 0x40(0x10)
	uint8_t  TargetSpace;  // 0x50(0x1)
	char pad_81[15];  // 0x51(0xF)
	struct FTransform Root;  // 0x60(0x60)
	struct TArray<int32_t> ParentIndices;  // 0xC0(0x10)

}; 
// Function ControlRig.ControlRig.CreateTransformableControlHandle
// Size: 0x18(Inherited: 0x0) 
struct FCreateTransformableControlHandle
{
	struct UObject* Outer;  // 0x0(0x8)
	struct FName ControlName;  // 0x8(0x8)
	struct UTransformableControlHandle* ReturnValue;  // 0x10(0x8)

}; 
// Function ControlRig.ControlRig.SetFramesPerSecond
// Size: 0x4(Inherited: 0x0) 
struct FSetFramesPerSecond
{
	float InFramesPerSecond;  // 0x0(0x4)

}; 
// Function ControlRig.ControlRig.GetHostingActor
// Size: 0x8(Inherited: 0x0) 
struct FGetHostingActor
{
	struct AActor* ReturnValue;  // 0x0(0x8)

}; 
// Function ControlRig.ControlRig.FindControlRigs
// Size: 0x20(Inherited: 0x0) 
struct FFindControlRigs
{
	struct UObject* Outer;  // 0x0(0x8)
	UControlRig* OptionalClass;  // 0x8(0x8)
	struct TArray<struct UControlRig*> ReturnValue;  // 0x10(0x10)

}; 
// Function ControlRig.RigHierarchyController.SetParent
// Size: 0x1C(Inherited: 0x0) 
struct FSetParent
{
	struct FRigElementKey InChild;  // 0x0(0xC)
	struct FRigElementKey InParent;  // 0xC(0xC)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool bMaintainGlobalTransform : 1;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool bSetupUndo : 1;  // 0x19(0x1)
	char pad_26_1 : 7;  // 0x1A(0x1)
	bool bPrintPythonCommand : 1;  // 0x1A(0x1)
	char pad_27_1 : 7;  // 0x1B(0x1)
	bool ReturnValue : 1;  // 0x1B(0x1)

}; 
// ScriptStruct ControlRig.RegionScaleFactors
// Size: 0x10(Inherited: 0x0) 
struct FRegionScaleFactors
{
	float PositiveWidth;  // 0x0(0x4)
	float NegativeWidth;  // 0x4(0x4)
	float PositiveHeight;  // 0x8(0x4)
	float NegativeHeight;  // 0xC(0x4)

}; 
// Function ControlRig.ControlRig.GetVariableType
// Size: 0x10(Inherited: 0x0) 
struct FGetVariableType
{
	struct FName InVariableName;  // 0x0(0x8)
	struct FName ReturnValue;  // 0x8(0x8)

}; 
// ScriptStruct ControlRig.RigTransformMetadata
// Size: 0x90(Inherited: 0x28) 
struct FRigTransformMetadata : public FRigBaseMetadata
{
	char pad_40[8];  // 0x28(0x8)
	struct FTransform Value;  // 0x30(0x60)

}; 
// Function ControlRig.RigHierarchy.GetFirstParent
// Size: 0x18(Inherited: 0x0) 
struct FGetFirstParent
{
	struct FRigElementKey InKey;  // 0x0(0xC)
	struct FRigElementKey ReturnValue;  // 0xC(0xC)

}; 
// Function ControlRig.ControlRigComponent.GetAbsoluteTime
// Size: 0x4(Inherited: 0x0) 
struct FGetAbsoluteTime
{
	float ReturnValue;  // 0x0(0x4)

}; 
// ScriptStruct ControlRig.RigHierarchySettings
// Size: 0x4(Inherited: 0x0) 
struct FRigHierarchySettings
{
	int32_t ProceduralElementLimit;  // 0x0(0x4)

}; 
// Function ControlRig.ControlRig.GetCurrentFramesPerSecond
// Size: 0x4(Inherited: 0x0) 
struct FGetCurrentFramesPerSecond
{
	float ReturnValue;  // 0x0(0x4)

}; 
// ScriptStruct ControlRig.RigRigidBodySettings
// Size: 0x4(Inherited: 0x0) 
struct FRigRigidBodySettings
{
	float Mass;  // 0x0(0x4)

}; 
// ScriptStruct ControlRig.RigElementKeyCollection
// Size: 0x10(Inherited: 0x0) 
struct FRigElementKeyCollection
{
	struct TArray<struct FRigElementKey> Keys;  // 0x0(0x10)

}; 
// Function ControlRig.ControlRig.GetVM
// Size: 0x8(Inherited: 0x0) 
struct FGetVM
{
	struct URigVM* ReturnValue;  // 0x0(0x8)

}; 
// ScriptStruct ControlRig.RigUnit_SetControlTransform
// Size: 0xE0(Inherited: 0x40) 
struct FRigUnit_SetControlTransform : public FRigUnitMutable
{
	struct FName Control;  // 0x40(0x8)
	float Weight;  // 0x48(0x4)
	char pad_76[4];  // 0x4C(0x4)
	struct FTransform Transform;  // 0x50(0x60)
	uint8_t  Space;  // 0xB0(0x1)
	char pad_177[7];  // 0xB1(0x7)
	struct FCachedRigElement CachedControlIndex;  // 0xB8(0x20)
	char pad_216[8];  // 0xD8(0x8)

}; 
// ScriptStruct ControlRig.AnimNode_ControlRig_ExternalSource
// Size: 0x278(Inherited: 0x270) 
struct FAnimNode_ControlRig_ExternalSource : public FAnimNode_ControlRigBase
{
	struct TWeakObjectPtr<UControlRig> ControlRig;  // 0x270(0x8)

}; 
// Function ControlRig.ControlRigShapeActor.SetHovered
// Size: 0x1(Inherited: 0x0) 
struct FSetHovered
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bInHovered : 1;  // 0x0(0x1)

}; 
// ScriptStruct ControlRig.RigUnit_HierarchyGetPose
// Size: 0x90(Inherited: 0x8) 
struct FRigUnit_HierarchyGetPose : public FRigUnit_HierarchyBase
{
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Initial : 1;  // 0x8(0x1)
	uint8_t  ElementType;  // 0x9(0x1)
	char pad_10[6];  // 0xA(0x6)
	struct FRigElementKeyCollection ItemsToGet;  // 0x10(0x10)
	struct FRigPose Pose;  // 0x20(0x70)

}; 
// Function ControlRig.ControlRig.GetEvents
// Size: 0x10(Inherited: 0x0) 
struct FGetEvents
{
	struct TArray<struct FName> ReturnValue;  // 0x0(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_VisualDebugTransformItemSpace
// Size: 0x90(Inherited: 0x8) 
struct FRigUnit_VisualDebugTransformItemSpace : public FRigUnit_DebugBase
{
	char pad_8[8];  // 0x8(0x8)
	struct FTransform Value;  // 0x10(0x60)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool bEnabled : 1;  // 0x70(0x1)
	char pad_113[3];  // 0x71(0x3)
	float Thickness;  // 0x74(0x4)
	float Scale;  // 0x78(0x4)
	struct FRigElementKey Space;  // 0x7C(0xC)
	char pad_136[8];  // 0x88(0x8)

}; 
// ScriptStruct ControlRig.RigUnit_RemoveMetadataTag
// Size: 0x78(Inherited: 0x40) 
struct FRigUnit_RemoveMetadataTag : public FRigUnitMutable
{
	struct FRigElementKey Item;  // 0x40(0xC)
	struct FName Tag;  // 0x4C(0x8)
	char pad_84_1 : 7;  // 0x54(0x1)
	bool Removed : 1;  // 0x54(0x1)
	char pad_85[3];  // 0x55(0x3)
	struct FCachedRigElement CachedIndex;  // 0x58(0x20)

}; 
// ScriptStruct ControlRig.MovieSceneControlRigSpaceBaseKey
// Size: 0x10(Inherited: 0x0) 
struct FMovieSceneControlRigSpaceBaseKey
{
	uint8_t  SpaceType;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	struct FRigElementKey ControlRigElement;  // 0x4(0xC)

}; 
// ScriptStruct ControlRig.MovieSceneControlRigInstanceData
// Size: 0x148(Inherited: 0x8) 
struct FMovieSceneControlRigInstanceData : public FMovieSceneSequenceInstanceData
{
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bAdditive : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool bApplyBoneFilter : 1;  // 0x9(0x1)
	char pad_10[6];  // 0xA(0x6)
	struct FInputBlendPose BoneFilter;  // 0x10(0x10)
	struct FMovieSceneFloatChannel Weight;  // 0x20(0x110)
	struct FMovieSceneEvaluationOperand Operand;  // 0x130(0x14)
	char pad_324[4];  // 0x144(0x4)

}; 
// ScriptStruct ControlRig.RigUnit_MathFloatNegate
// Size: 0x10(Inherited: 0x10) 
struct FRigUnit_MathFloatNegate : public FRigUnit_MathFloatUnaryOp
{

}; 
// Function ControlRig.ControlRigComponent.OnPreForwardsSolve
// Size: 0x8(Inherited: 0x0) 
struct FOnPreForwardsSolve
{
	struct UControlRigComponent* Component;  // 0x0(0x8)

}; 
// ScriptStruct ControlRig.CRSimPointForce
// Size: 0x28(Inherited: 0x0) 
struct FCRSimPointForce
{
	uint8_t  ForceType;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FVector Vector;  // 0x8(0x18)
	float Coefficient;  // 0x20(0x4)
	char pad_36_1 : 7;  // 0x24(0x1)
	bool bNormalize : 1;  // 0x24(0x1)
	char pad_37[3];  // 0x25(0x3)

}; 
// Function ControlRig.RigHierarchyController.GetHierarchy
// Size: 0x8(Inherited: 0x0) 
struct FGetHierarchy
{
	struct URigHierarchy* ReturnValue;  // 0x0(0x8)

}; 
// Function ControlRig.ControlRig.GetInteractionRig
// Size: 0x8(Inherited: 0x0) 
struct FGetInteractionRig
{
	struct UControlRig* ReturnValue;  // 0x0(0x8)

}; 
// Function ControlRig.ControlRigComponent.SetObjectBinding
// Size: 0x8(Inherited: 0x0) 
struct FSetObjectBinding
{
	struct UObject* InObjectToBind;  // 0x0(0x8)

}; 
// ScriptStruct ControlRig.RigUnit_SetMultiControlBool
// Size: 0x60(Inherited: 0x40) 
struct FRigUnit_SetMultiControlBool : public FRigUnitMutable
{
	struct TArray<struct FRigUnit_SetMultiControlBool_Entry> Entries;  // 0x40(0x10)
	struct TArray<struct FCachedRigElement> CachedControlIndices;  // 0x50(0x10)

}; 
// ScriptStruct ControlRig.RigDispatch_AnimAttributeBase
// Size: 0x50(Inherited: 0x18) 
struct FRigDispatch_AnimAttributeBase : public FRigDispatchFactory
{
	char pad_24[56];  // 0x18(0x38)

}; 
// Function ControlRig.ControlRig.GetVariableAsString
// Size: 0x18(Inherited: 0x0) 
struct FGetVariableAsString
{
	struct FName InVariableName;  // 0x0(0x8)
	struct FString ReturnValue;  // 0x8(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_StringToLowercase
// Size: 0x28(Inherited: 0x8) 
struct FRigUnit_StringToLowercase : public FRigUnit_StringBase
{
	struct FString Value;  // 0x8(0x10)
	struct FString Result;  // 0x18(0x10)

}; 
// ScriptStruct ControlRig.RigTransformElement
// Size: 0x2F0(Inherited: 0xF0) 
struct FRigTransformElement : public FRigBaseElement
{
	struct FRigCurrentAndInitialTransform Pose;  // 0xF0(0x1C0)
	char pad_688[64];  // 0x2B0(0x40)

}; 
// ScriptStruct ControlRig.RigUnit_HierarchyAddControlTransform
// Size: 0x1D0(Inherited: 0x60) 
struct FRigUnit_HierarchyAddControlTransform : public FRigUnit_HierarchyAddElement
{
	struct FTransform OffsetTransform;  // 0x60(0x60)
	struct FTransform InitialValue;  // 0xC0(0x60)
	struct FRigUnit_HierarchyAddControlTransform_Settings Settings;  // 0x120(0xB0)

}; 
// ScriptStruct ControlRig.RigUnit_HierarchySetParentWeights
// Size: 0x60(Inherited: 0x40) 
struct FRigUnit_HierarchySetParentWeights : public FRigUnit_DynamicHierarchyBaseMutable
{
	struct FRigElementKey Child;  // 0x40(0xC)
	char pad_76[4];  // 0x4C(0x4)
	struct TArray<struct FRigElementWeight> Weights;  // 0x50(0x10)

}; 
// Function ControlRig.ControlRig.IsControlSelected
// Size: 0xC(Inherited: 0x0) 
struct FIsControlSelected
{
	struct FName InControlName;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)

}; 
// ScriptStruct ControlRig.RigUnit_DebugBaseMutable
// Size: 0x40(Inherited: 0x40) 
struct FRigUnit_DebugBaseMutable : public FRigUnitMutable
{

}; 
// SparseDelegateFunction ControlRig.ControlRig.OnControlSelectedBP__DelegateSignature
// Size: 0xA50(Inherited: 0x0) 
struct FOnControlSelectedBP__DelegateSignature
{
	struct UControlRig* Rig;  // 0x0(0x8)
	char pad_8[8];  // 0x8(0x8)
	struct FRigControlElement Control;  // 0x10(0xA30)
	char pad_2624_1 : 7;  // 0xA40(0x1)
	bool bSelected : 1;  // 0xA40(0x1)
	char pad_2625[15];  // 0xA41(0xF)

}; 
// ScriptStruct ControlRig.RigUnit_SetIntAnimationChannel
// Size: 0x70(Inherited: 0x68) 
struct FRigUnit_SetIntAnimationChannel : public FRigUnit_SetAnimationChannelBase
{
	int32_t Value;  // 0x68(0x4)
	char pad_108[4];  // 0x6C(0x4)

}; 
// ScriptStruct ControlRig.RigBaseElement
// Size: 0xF0(Inherited: 0x0) 
struct FRigBaseElement
{
	char pad_0[8];  // 0x0(0x8)
	struct FRigElementKey Key;  // 0x8(0xC)
	char pad_20[4];  // 0x14(0x4)
	struct FString NameString;  // 0x18(0x10)
	int32_t Index;  // 0x28(0x4)
	int32_t SubIndex;  // 0x2C(0x4)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool bSelected : 1;  // 0x30(0x1)
	char pad_49[3];  // 0x31(0x3)
	int32_t CreatedAtInstructionIndex;  // 0x34(0x4)
	char pad_56[184];  // 0x38(0xB8)

}; 
// ScriptStruct ControlRig.RigUnit_HierarchySetPoseItemArray
// Size: 0xD0(Inherited: 0x40) 
struct FRigUnit_HierarchySetPoseItemArray : public FRigUnit_HierarchyBaseMutable
{
	struct FRigPose Pose;  // 0x40(0x70)
	uint8_t  ElementType;  // 0xB0(0x1)
	uint8_t  Space;  // 0xB1(0x1)
	char pad_178[6];  // 0xB2(0x6)
	struct TArray<struct FRigElementKey> ItemsToSet;  // 0xB8(0x10)
	float Weight;  // 0xC8(0x4)
	char pad_204[4];  // 0xCC(0x4)

}; 
// ScriptStruct ControlRig.RigUnit_MathTransformBase
// Size: 0x8(Inherited: 0x8) 
struct FRigUnit_MathTransformBase : public FRigUnit_MathBase
{

}; 
// ScriptStruct ControlRig.RigUnit_SetTranslation
// Size: 0x90(Inherited: 0x40) 
struct FRigUnit_SetTranslation : public FRigUnitMutable
{
	struct FRigElementKey Item;  // 0x40(0xC)
	uint8_t  Space;  // 0x4C(0x1)
	char pad_77_1 : 7;  // 0x4D(0x1)
	bool bInitial : 1;  // 0x4D(0x1)
	char pad_78[2];  // 0x4E(0x2)
	struct FVector Value;  // 0x50(0x18)
	float Weight;  // 0x68(0x4)
	char pad_108_1 : 7;  // 0x6C(0x1)
	bool bPropagateToChildren : 1;  // 0x6C(0x1)
	char pad_109[3];  // 0x6D(0x3)
	struct FCachedRigElement CachedIndex;  // 0x70(0x20)

}; 
// ScriptStruct ControlRig.RigUnit_HighlevelBaseMutable
// Size: 0x40(Inherited: 0x40) 
struct FRigUnit_HighlevelBaseMutable : public FRigUnitMutable
{

}; 
// ScriptStruct ControlRig.RigUnit_MathBoolToInteger
// Size: 0x10(Inherited: 0x8) 
struct FRigUnit_MathBoolToInteger : public FRigUnit_MathBoolBase
{
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Value : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	int32_t Result;  // 0xC(0x4)

}; 
// ScriptStruct ControlRig.RigUnit_MathFloatSin
// Size: 0x10(Inherited: 0x10) 
struct FRigUnit_MathFloatSin : public FRigUnit_MathFloatUnaryOp
{

}; 
// ScriptStruct ControlRig.RigUnit_ConvertTransform
// Size: 0xC0(Inherited: 0x8) 
struct FRigUnit_ConvertTransform : public FRigUnit
{
	char pad_8[8];  // 0x8(0x8)
	struct FTransform Input;  // 0x10(0x60)
	struct FEulerTransform Result;  // 0x70(0x48)
	char pad_184[8];  // 0xB8(0x8)

}; 
// ScriptStruct ControlRig.ConstraintParent
// Size: 0x10(Inherited: 0x0) 
struct FConstraintParent
{
	struct FRigElementKey Item;  // 0x0(0xC)
	float Weight;  // 0xC(0x4)

}; 
// ScriptStruct ControlRig.RigInfluenceMap
// Size: 0x68(Inherited: 0x0) 
struct FRigInfluenceMap
{
	struct FName EventName;  // 0x0(0x8)
	struct TArray<struct FRigInfluenceEntry> Entries;  // 0x8(0x10)
	struct TMap<struct FRigElementKey, int32_t> KeyToIndex;  // 0x18(0x50)

}; 
// ScriptStruct ControlRig.RigUnit_GetControlInitialTransform
// Size: 0xA0(Inherited: 0x8) 
struct FRigUnit_GetControlInitialTransform : public FRigUnit
{
	struct FName Control;  // 0x8(0x8)
	uint8_t  Space;  // 0x10(0x1)
	char pad_17[15];  // 0x11(0xF)
	struct FTransform Transform;  // 0x20(0x60)
	struct FCachedRigElement CachedControlIndex;  // 0x80(0x20)

}; 
// ScriptStruct ControlRig.RigElementKey
// Size: 0xC(Inherited: 0x0) 
struct FRigElementKey
{
	uint8_t  Type;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	struct FName Name;  // 0x4(0x8)

}; 
// ScriptStruct ControlRig.RigUnit_DrawContainerSetThickness
// Size: 0x50(Inherited: 0x40) 
struct FRigUnit_DrawContainerSetThickness : public FRigUnitMutable
{
	struct FName InstructionName;  // 0x40(0x8)
	float Thickness;  // 0x48(0x4)
	char pad_76[4];  // 0x4C(0x4)

}; 
// ScriptStruct ControlRig.RigLocalAndGlobalTransform
// Size: 0xE0(Inherited: 0x0) 
struct FRigLocalAndGlobalTransform
{
	struct FRigComputedTransform Local;  // 0x0(0x70)
	struct FRigComputedTransform Global;  // 0x70(0x70)

}; 
// ScriptStruct ControlRig.RigUnit_CollectionReplaceItemsArray
// Size: 0x40(Inherited: 0x8) 
struct FRigUnit_CollectionReplaceItemsArray : public FRigUnit_CollectionBase
{
	struct TArray<struct FRigElementKey> Items;  // 0x8(0x10)
	struct FName Old;  // 0x18(0x8)
	struct FName New;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool RemoveInvalidItems : 1;  // 0x28(0x1)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool bAllowDuplicates : 1;  // 0x29(0x1)
	char pad_42[6];  // 0x2A(0x6)
	struct TArray<struct FRigElementKey> Result;  // 0x30(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_MathBoolBase
// Size: 0x8(Inherited: 0x8) 
struct FRigUnit_MathBoolBase : public FRigUnit_MathBase
{

}; 
// ScriptStruct ControlRig.ControlRigDrawInstruction
// Size: 0xD0(Inherited: 0x0) 
struct FControlRigDrawInstruction
{
	struct FName Name;  // 0x0(0x8)
	char EControlRigDrawSettings PrimitiveType;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct TArray<struct FVector> Positions;  // 0x10(0x10)
	struct FLinearColor Color;  // 0x20(0x10)
	float Thickness;  // 0x30(0x4)
	char pad_52[12];  // 0x34(0xC)
	struct FTransform Transform;  // 0x40(0x60)
	char pad_160[48];  // 0xA0(0x30)

}; 
// Function ControlRig.ControlRigComponent.SetControlFloat
// Size: 0xC(Inherited: 0x0) 
struct FSetControlFloat
{
	struct FName ControlName;  // 0x0(0x8)
	float Value;  // 0x8(0x4)

}; 
// ScriptStruct ControlRig.RigUnit_BoneName
// Size: 0x10(Inherited: 0x8) 
struct FRigUnit_BoneName : public FRigUnit
{
	struct FName bone;  // 0x8(0x8)

}; 
// ScriptStruct ControlRig.RigUnit_MathDoubleSin
// Size: 0x18(Inherited: 0x18) 
struct FRigUnit_MathDoubleSin : public FRigUnit_MathDoubleUnaryOp
{

}; 
// ScriptStruct ControlRig.RigUnit_AddParent
// Size: 0x58(Inherited: 0x40) 
struct FRigUnit_AddParent : public FRigUnit_DynamicHierarchyBaseMutable
{
	struct FRigElementKey Child;  // 0x40(0xC)
	struct FRigElementKey Parent;  // 0x4C(0xC)

}; 
// Function ControlRig.ControlRig.SetAbsoluteAndDeltaTime
// Size: 0x8(Inherited: 0x0) 
struct FSetAbsoluteAndDeltaTime
{
	float InAbsoluteTime;  // 0x0(0x4)
	float InDeltaTime;  // 0x4(0x4)

}; 
// ScriptStruct ControlRig.RigUnit_SphereTraceByObjectTypes
// Size: 0x80(Inherited: 0x8) 
struct FRigUnit_SphereTraceByObjectTypes : public FRigUnit
{
	struct FVector Start;  // 0x8(0x18)
	struct FVector End;  // 0x20(0x18)
	struct TArray<char EObjectTypeQuery> ObjectTypes;  // 0x38(0x10)
	float Radius;  // 0x48(0x4)
	char pad_76_1 : 7;  // 0x4C(0x1)
	bool bHit : 1;  // 0x4C(0x1)
	char pad_77[3];  // 0x4D(0x3)
	struct FVector HitLocation;  // 0x50(0x18)
	struct FVector HitNormal;  // 0x68(0x18)

}; 
// ScriptStruct ControlRig.RigComputedTransform
// Size: 0x70(Inherited: 0x0) 
struct FRigComputedTransform
{
	struct FTransform Transform;  // 0x0(0x60)
	char pad_96[16];  // 0x60(0x10)

}; 
// ScriptStruct ControlRig.RigElementKeyMetadata
// Size: 0x38(Inherited: 0x28) 
struct FRigElementKeyMetadata : public FRigBaseMetadata
{
	struct FRigElementKey Value;  // 0x28(0xC)
	char pad_52[4];  // 0x34(0x4)

}; 
// ScriptStruct ControlRig.RigHierarchyContainer
// Size: 0x40(Inherited: 0x0) 
struct FRigHierarchyContainer
{
	struct FRigBoneHierarchy BoneHierarchy;  // 0x0(0x10)
	struct FRigSpaceHierarchy SpaceHierarchy;  // 0x10(0x10)
	struct FRigControlHierarchy ControlHierarchy;  // 0x20(0x10)
	struct FRigCurveContainer CurveContainer;  // 0x30(0x10)

}; 
// Function ControlRig.ControlRigComponent.GetControlOffset
// Size: 0x70(Inherited: 0x0) 
struct FGetControlOffset
{
	struct FName ControlName;  // 0x0(0x8)
	uint8_t  Space;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct FTransform ReturnValue;  // 0x10(0x60)

}; 
// Function ControlRig.RigHierarchy.GetController
// Size: 0x10(Inherited: 0x0) 
struct FGetController
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bCreateIfNeeded : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct URigHierarchyController* ReturnValue;  // 0x8(0x8)

}; 
// ScriptStruct ControlRig.RigMultiParentElement
// Size: 0x3F0(Inherited: 0x2F0) 
struct FRigMultiParentElement : public FRigTransformElement
{
	char pad_752[256];  // 0x2F0(0x100)

}; 
// ScriptStruct ControlRig.RigControlElement
// Size: 0xA30(Inherited: 0x3F0) 
struct FRigControlElement : public FRigMultiParentElement
{
	struct FRigControlSettings Settings;  // 0x3F0(0x280)
	struct FRigCurrentAndInitialTransform Offset;  // 0x670(0x1C0)
	struct FRigCurrentAndInitialTransform Shape;  // 0x830(0x1C0)
	struct FRigPreferredEulerAngles PreferredEulerAngles;  // 0x9F0(0x38)
	char pad_2600[8];  // 0xA28(0x8)

}; 
// ScriptStruct ControlRig.RigUnit_CollectionGetAll
// Size: 0x20(Inherited: 0x8) 
struct FRigUnit_CollectionGetAll : public FRigUnit_CollectionBase
{
	uint8_t  TypeToSearch;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct TArray<struct FRigElementKey> Items;  // 0x10(0x10)

}; 
// ScriptStruct ControlRig.ControlRigSequenceObjectReferenceMap
// Size: 0x20(Inherited: 0x0) 
struct FControlRigSequenceObjectReferenceMap
{
	struct TArray<struct FGuid> BindingIds;  // 0x0(0x10)
	struct TArray<struct FControlRigSequenceObjectReferences> References;  // 0x10(0x10)

}; 
// ScriptStruct ControlRig.RigTransformStackEntry
// Size: 0xF0(Inherited: 0x0) 
struct FRigTransformStackEntry
{
	struct FRigElementKey Key;  // 0x0(0xC)
	char ERigTransformStackEntryType EntryType;  // 0xC(0x1)
	char ERigTransformType TransformType;  // 0xD(0x1)
	char pad_14[2];  // 0xE(0x2)
	struct FTransform OldTransform;  // 0x10(0x60)
	struct FTransform NewTransform;  // 0x70(0x60)
	char pad_208_1 : 7;  // 0xD0(0x1)
	bool bAffectChildren : 1;  // 0xD0(0x1)
	char pad_209[7];  // 0xD1(0x7)
	struct TArray<struct FString> Callstack;  // 0xD8(0x10)
	char pad_232[8];  // 0xE8(0x8)

}; 
// Function ControlRig.ControlRigComponent.OnPreInitialize
// Size: 0x8(Inherited: 0x0) 
struct FOnPreInitialize
{
	struct UControlRigComponent* Component;  // 0x0(0x8)

}; 
// ScriptStruct ControlRig.RigDispatch_GetMetadata
// Size: 0x48(Inherited: 0x48) 
struct FRigDispatch_GetMetadata : public FRigDispatch_MetadataBase
{

}; 
// ScriptStruct ControlRig.RigControlSettings
// Size: 0x280(Inherited: 0x0) 
struct FRigControlSettings
{
	uint8_t  AnimationType;  // 0x0(0x1)
	uint8_t  ControlType;  // 0x1(0x1)
	char pad_2[2];  // 0x2(0x2)
	struct FName DisplayName;  // 0x4(0x8)
	uint8_t  PrimaryAxis;  // 0xC(0x1)
	char pad_13_1 : 7;  // 0xD(0x1)
	bool bIsCurve : 1;  // 0xD(0x1)
	char pad_14[2];  // 0xE(0x2)
	struct TArray<struct FRigControlLimitEnabled> LimitEnabled;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool bDrawLimits : 1;  // 0x20(0x1)
	char pad_33[15];  // 0x21(0xF)
	struct FRigControlValue MinimumValue;  // 0x30(0xF0)
	struct FRigControlValue MaximumValue;  // 0x120(0xF0)
	char pad_528_1 : 7;  // 0x210(0x1)
	bool bShapeVisible : 1;  // 0x210(0x1)
	uint8_t  ShapeVisibility;  // 0x211(0x1)
	char pad_530[2];  // 0x212(0x2)
	struct FName ShapeName;  // 0x214(0x8)
	struct FLinearColor ShapeColor;  // 0x21C(0x10)
	char pad_556_1 : 7;  // 0x22C(0x1)
	bool bIsTransientControl : 1;  // 0x22C(0x1)
	char pad_557[3];  // 0x22D(0x3)
	struct UEnum* ControlEnum;  // 0x230(0x8)
	struct FRigControlElementCustomization Customization;  // 0x238(0x20)
	struct TArray<struct FRigElementKey> DrivenControls;  // 0x258(0x10)
	char pad_616[16];  // 0x268(0x10)
	char pad_632_1 : 7;  // 0x278(0x1)
	bool bGroupWithParentControl : 1;  // 0x278(0x1)
	char pad_633_1 : 7;  // 0x279(0x1)
	bool bAnimatable : 1;  // 0x279(0x1)
	char pad_634_1 : 7;  // 0x27A(0x1)
	bool bShapeEnabled : 1;  // 0x27A(0x1)
	char pad_635[5];  // 0x27B(0x5)

}; 
// ScriptStruct ControlRig.RigUnit_MathColorBase
// Size: 0x8(Inherited: 0x8) 
struct FRigUnit_MathColorBase : public FRigUnit_MathBase
{

}; 
// ScriptStruct ControlRig.RigUnit_MathFloatSign
// Size: 0x10(Inherited: 0x10) 
struct FRigUnit_MathFloatSign : public FRigUnit_MathFloatUnaryOp
{

}; 
// ScriptStruct ControlRig.RigUnit_VisualDebugTransform
// Size: 0x90(Inherited: 0x8) 
struct FRigUnit_VisualDebugTransform : public FRigUnit_DebugBase
{
	char pad_8[8];  // 0x8(0x8)
	struct FTransform Value;  // 0x10(0x60)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool bEnabled : 1;  // 0x70(0x1)
	char pad_113[3];  // 0x71(0x3)
	float Thickness;  // 0x74(0x4)
	float Scale;  // 0x78(0x4)
	struct FName BoneSpace;  // 0x7C(0x8)
	char pad_132[12];  // 0x84(0xC)

}; 
// Function ControlRig.RigHierarchy.MakeControlValueFromTransform
// Size: 0x150(Inherited: 0x0) 
struct FMakeControlValueFromTransform
{
	struct FTransform InValue;  // 0x0(0x60)
	struct FRigControlValue ReturnValue;  // 0x60(0xF0)

}; 
// ScriptStruct ControlRig.MathRBFInterpolateQuatXform_Target
// Size: 0x80(Inherited: 0x0) 
struct FMathRBFInterpolateQuatXform_Target
{
	struct FQuat Target;  // 0x0(0x20)
	struct FTransform Value;  // 0x20(0x60)

}; 
// Function ControlRig.ControlRig.SetInteractionRigClass
// Size: 0x8(Inherited: 0x0) 
struct FSetInteractionRigClass
{
	UControlRig* InInteractionRigClass;  // 0x0(0x8)

}; 
// Function ControlRig.RigHierarchy.IsValidIndex
// Size: 0x8(Inherited: 0x0) 
struct FIsValidIndex
{
	int32_t InElementIndex;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool ReturnValue : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)

}; 
// ScriptStruct ControlRig.RigUnit_SequenceAggregate
// Size: 0xB0(Inherited: 0x8) 
struct FRigUnit_SequenceAggregate : public FRigUnit
{
	struct FControlRigExecuteContext ExecuteContext;  // 0x8(0x38)
	struct FControlRigExecuteContext A;  // 0x40(0x38)
	struct FControlRigExecuteContext B;  // 0x78(0x38)

}; 
// ScriptStruct ControlRig.RigControlElementCustomization
// Size: 0x20(Inherited: 0x0) 
struct FRigControlElementCustomization
{
	struct TArray<struct FRigElementKey> AvailableSpaces;  // 0x0(0x10)
	struct TArray<struct FRigElementKey> RemovedSpaces;  // 0x10(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_MathDoubleConstHalfPi
// Size: 0x10(Inherited: 0x10) 
struct FRigUnit_MathDoubleConstHalfPi : public FRigUnit_MathDoubleConstant
{

}; 
// ScriptStruct ControlRig.RigUnit_DebugTransform
// Size: 0x110(Inherited: 0x8) 
struct FRigUnit_DebugTransform : public FRigUnit_DebugBase
{
	char pad_8[8];  // 0x8(0x8)
	struct FTransform Transform;  // 0x10(0x60)
	uint8_t  Mode;  // 0x70(0x1)
	char pad_113[3];  // 0x71(0x3)
	struct FLinearColor Color;  // 0x74(0x10)
	float Thickness;  // 0x84(0x4)
	float Scale;  // 0x88(0x4)
	struct FName Space;  // 0x8C(0x8)
	char pad_148[12];  // 0x94(0xC)
	struct FTransform WorldOffset;  // 0xA0(0x60)
	char pad_256_1 : 7;  // 0x100(0x1)
	bool bEnabled : 1;  // 0x100(0x1)
	char pad_257[15];  // 0x101(0xF)

}; 
// ScriptStruct ControlRig.RigControlValue
// Size: 0xF0(Inherited: 0x0) 
struct FRigControlValue
{
	struct FRigControlValueStorage FloatStorage;  // 0x0(0x84)
	char pad_132[12];  // 0x84(0xC)
	struct FTransform Storage;  // 0x90(0x60)

}; 
// ScriptStruct ControlRig.RigControlValueStorage
// Size: 0x84(Inherited: 0x0) 
struct FRigControlValueStorage
{
	float Float00;  // 0x0(0x4)
	float Float01;  // 0x4(0x4)
	float Float02;  // 0x8(0x4)
	float Float03;  // 0xC(0x4)
	float Float10;  // 0x10(0x4)
	float Float11;  // 0x14(0x4)
	float Float12;  // 0x18(0x4)
	float Float13;  // 0x1C(0x4)
	float Float20;  // 0x20(0x4)
	float Float21;  // 0x24(0x4)
	float Float22;  // 0x28(0x4)
	float Float23;  // 0x2C(0x4)
	float Float30;  // 0x30(0x4)
	float Float31;  // 0x34(0x4)
	float Float32;  // 0x38(0x4)
	float Float33;  // 0x3C(0x4)
	float Float00_3;  // 0x40(0x4)
	float Float01_3;  // 0x44(0x4)
	float Float02_3;  // 0x48(0x4)
	float Float03_3;  // 0x4C(0x4)
	float Float10_3;  // 0x50(0x4)
	float Float11_3;  // 0x54(0x4)
	float Float12_3;  // 0x58(0x4)
	float Float13_3;  // 0x5C(0x4)
	float Float20_3;  // 0x60(0x4)
	float Float21_3;  // 0x64(0x4)
	float Float22_3;  // 0x68(0x4)
	float Float23_3;  // 0x6C(0x4)
	float Float30_3;  // 0x70(0x4)
	float Float31_3;  // 0x74(0x4)
	float Float32_3;  // 0x78(0x4)
	float Float33_3;  // 0x7C(0x4)
	char pad_128_1 : 7;  // 0x80(0x1)
	bool bValid : 1;  // 0x80(0x1)
	char pad_129[3];  // 0x81(0x3)

}; 
// Function ControlRig.RigHierarchy.SetControlVisibility
// Size: 0x10(Inherited: 0x0) 
struct FSetControlVisibility
{
	struct FRigElementKey InKey;  // 0x0(0xC)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool bVisibility : 1;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)

}; 
// ScriptStruct ControlRig.RigUnit_GetRotatorAnimationChannel
// Size: 0x48(Inherited: 0x30) 
struct FRigUnit_GetRotatorAnimationChannel : public FRigUnit_GetAnimationChannelBase
{
	struct FRotator Value;  // 0x30(0x18)

}; 
// ScriptStruct ControlRig.RigUnit_MathIntEquals
// Size: 0x18(Inherited: 0x8) 
struct FRigUnit_MathIntEquals : public FRigUnit_MathIntBase
{
	int32_t A;  // 0x8(0x4)
	int32_t B;  // 0xC(0x4)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool Result : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// ScriptStruct ControlRig.ControlRigShapeDefinition
// Size: 0xB0(Inherited: 0x0) 
struct FControlRigShapeDefinition
{
	struct FName ShapeName;  // 0x0(0x8)
	struct TSoftObjectPtr<UStaticMesh> StaticMesh;  // 0x8(0x30)
	char pad_56[8];  // 0x38(0x8)
	struct FTransform Transform;  // 0x40(0x60)
	char pad_160[16];  // 0xA0(0x10)

}; 
// ScriptStruct ControlRig.ControlRigExecuteContext
// Size: 0x38(Inherited: 0x30) 
struct FControlRigExecuteContext : public FRigVMExecuteContext
{
	char pad_48[8];  // 0x30(0x8)

}; 
// ScriptStruct ControlRig.RigControlLimitEnabled
// Size: 0x2(Inherited: 0x0) 
struct FRigControlLimitEnabled
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bMinimum : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool bMaximum : 1;  // 0x1(0x1)

}; 
// ScriptStruct ControlRig.MathRBFInterpolateVectorQuat_Target
// Size: 0x40(Inherited: 0x0) 
struct FMathRBFInterpolateVectorQuat_Target
{
	struct FVector Target;  // 0x0(0x18)
	char pad_24[8];  // 0x18(0x8)
	struct FQuat Value;  // 0x20(0x20)

}; 
// ScriptStruct ControlRig.RigBoneHierarchy
// Size: 0x10(Inherited: 0x0) 
struct FRigBoneHierarchy
{
	struct TArray<struct FRigBone> Bones;  // 0x0(0x10)

}; 
// Function ControlRig.ControlRig.SetVariableFromString
// Size: 0x20(Inherited: 0x0) 
struct FSetVariableFromString
{
	struct FName InVariableName;  // 0x0(0x8)
	struct FString InValue;  // 0x8(0x10)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool ReturnValue : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)

}; 
// Function ControlRig.ControlRig.SelectControl
// Size: 0xC(Inherited: 0x0) 
struct FSelectControl
{
	struct FName InControlName;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bSelect : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)

}; 
// Function ControlRig.ControlRig.SetAbsoluteTime
// Size: 0x8(Inherited: 0x0) 
struct FSetAbsoluteTime
{
	float InAbsoluteTime;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool InSetDeltaTimeZero : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)

}; 
// Function ControlRig.RigHierarchy.CopyHierarchy
// Size: 0x8(Inherited: 0x0) 
struct FCopyHierarchy
{
	struct URigHierarchy* InHierarchy;  // 0x0(0x8)

}; 
// ScriptStruct ControlRig.RigUnit
// Size: 0x8(Inherited: 0x8) 
struct FRigUnit : public FRigVMStruct
{

}; 
// ScriptStruct ControlRig.RigBone
// Size: 0x170(Inherited: 0x18) 
struct FRigBone : public FRigElement
{
	struct FName ParentName;  // 0x18(0x8)
	int32_t ParentIndex;  // 0x20(0x4)
	char pad_36[12];  // 0x24(0xC)
	struct FTransform InitialTransform;  // 0x30(0x60)
	struct FTransform GlobalTransform;  // 0x90(0x60)
	struct FTransform LocalTransform;  // 0xF0(0x60)
	struct TArray<int32_t> Dependents;  // 0x150(0x10)
	uint8_t  Type;  // 0x160(0x1)
	char pad_353[15];  // 0x161(0xF)

}; 
// Function ControlRig.ControlRig.SetDeltaTime
// Size: 0x4(Inherited: 0x0) 
struct FSetDeltaTime
{
	float InDeltaTime;  // 0x0(0x4)

}; 
// Function ControlRig.ControlRig.SetInteractionRig
// Size: 0x8(Inherited: 0x0) 
struct FSetInteractionRig
{
	struct UControlRig* InInteractionRig;  // 0x0(0x8)

}; 
// ScriptStruct ControlRig.RigControl
// Size: 0x510(Inherited: 0x18) 
struct FRigControl : public FRigElement
{
	uint8_t  ControlType;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)
	struct FName DisplayName;  // 0x1C(0x8)
	struct FName ParentName;  // 0x24(0x8)
	int32_t ParentIndex;  // 0x2C(0x4)
	struct FName SpaceName;  // 0x30(0x8)
	int32_t SpaceIndex;  // 0x38(0x4)
	char pad_60[4];  // 0x3C(0x4)
	struct FTransform OffsetTransform;  // 0x40(0x60)
	struct FRigControlValue InitialValue;  // 0xA0(0xF0)
	struct FRigControlValue Value;  // 0x190(0xF0)
	uint8_t  PrimaryAxis;  // 0x280(0x1)
	char pad_641_1 : 7;  // 0x281(0x1)
	bool bIsCurve : 1;  // 0x281(0x1)
	char pad_642_1 : 7;  // 0x282(0x1)
	bool bAnimatable : 1;  // 0x282(0x1)
	char pad_643_1 : 7;  // 0x283(0x1)
	bool bLimitTranslation : 1;  // 0x283(0x1)
	char pad_644_1 : 7;  // 0x284(0x1)
	bool bLimitRotation : 1;  // 0x284(0x1)
	char pad_645_1 : 7;  // 0x285(0x1)
	bool bLimitScale : 1;  // 0x285(0x1)
	char pad_646_1 : 7;  // 0x286(0x1)
	bool bDrawLimits : 1;  // 0x286(0x1)
	char pad_647[9];  // 0x287(0x9)
	struct FRigControlValue MinimumValue;  // 0x290(0xF0)
	struct FRigControlValue MaximumValue;  // 0x380(0xF0)
	char pad_1136_1 : 7;  // 0x470(0x1)
	bool bGizmoEnabled : 1;  // 0x470(0x1)
	char pad_1137_1 : 7;  // 0x471(0x1)
	bool bGizmoVisible : 1;  // 0x471(0x1)
	char pad_1138[2];  // 0x472(0x2)
	struct FName GizmoName;  // 0x474(0x8)
	char pad_1148[4];  // 0x47C(0x4)
	struct FTransform GizmoTransform;  // 0x480(0x60)
	struct FLinearColor GizmoColor;  // 0x4E0(0x10)
	struct TArray<int32_t> Dependents;  // 0x4F0(0x10)
	char pad_1280_1 : 7;  // 0x500(0x1)
	bool bIsTransientControl : 1;  // 0x500(0x1)
	char pad_1281[7];  // 0x501(0x7)
	struct UEnum* ControlEnum;  // 0x508(0x8)

}; 
// ScriptStruct ControlRig.RigInfluenceMapPerEvent
// Size: 0x60(Inherited: 0x0) 
struct FRigInfluenceMapPerEvent
{
	struct TArray<struct FRigInfluenceMap> Maps;  // 0x0(0x10)
	struct TMap<struct FName, int32_t> EventToIndex;  // 0x10(0x50)

}; 
// Function ControlRig.RigHierarchyController.ExportSelectionToText
// Size: 0x10(Inherited: 0x0) 
struct FExportSelectionToText
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_MathVectorClampSpatially
// Size: 0xC0(Inherited: 0x8) 
struct FRigUnit_MathVectorClampSpatially : public FRigUnit_MathVectorBase
{
	struct FVector Value;  // 0x8(0x18)
	char EAxis Axis;  // 0x20(0x1)
	char EControlRigClampSpatialMode Type;  // 0x21(0x1)
	char pad_34[2];  // 0x22(0x2)
	float Minimum;  // 0x24(0x4)
	float Maximum;  // 0x28(0x4)
	char pad_44[4];  // 0x2C(0x4)
	struct FTransform Space;  // 0x30(0x60)
	char pad_144_1 : 7;  // 0x90(0x1)
	bool bDrawDebug : 1;  // 0x90(0x1)
	char pad_145[3];  // 0x91(0x3)
	struct FLinearColor DebugColor;  // 0x94(0x10)
	float DebugThickness;  // 0xA4(0x4)
	struct FVector Result;  // 0xA8(0x18)

}; 
// ScriptStruct ControlRig.RigUnit_HierarchyAddControlRotator_LimitSettings
// Size: 0x40(Inherited: 0x0) 
struct FRigUnit_HierarchyAddControlRotator_LimitSettings
{
	struct FRigControlLimitEnabled LimitPitch;  // 0x0(0x2)
	struct FRigControlLimitEnabled LimitYaw;  // 0x2(0x2)
	struct FRigControlLimitEnabled LimitRoll;  // 0x4(0x2)
	char pad_6[2];  // 0x6(0x2)
	struct FRotator MinValue;  // 0x8(0x18)
	struct FRotator MaxValue;  // 0x20(0x18)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool bDrawLimits : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)

}; 
// ScriptStruct ControlRig.ControlRigDrawContainer
// Size: 0x18(Inherited: 0x0) 
struct FControlRigDrawContainer
{
	char pad_0[8];  // 0x0(0x8)
	struct TArray<struct FControlRigDrawInstruction> Instructions;  // 0x8(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_SlideChain
// Size: 0xA0(Inherited: 0x40) 
struct FRigUnit_SlideChain : public FRigUnit_HighlevelBaseMutable
{
	struct FName StartBone;  // 0x40(0x8)
	struct FName EndBone;  // 0x48(0x8)
	float SlideAmount;  // 0x50(0x4)
	char pad_84_1 : 7;  // 0x54(0x1)
	bool bPropagateToChildren : 1;  // 0x54(0x1)
	char pad_85[3];  // 0x55(0x3)
	struct FRigUnit_SlideChain_WorkData WorkData;  // 0x58(0x48)

}; 
// ScriptStruct ControlRig.RigUnit_MathRBFInterpolateVectorWorkData
// Size: 0x90(Inherited: 0x0) 
struct FRigUnit_MathRBFInterpolateVectorWorkData
{
	char pad_0[144];  // 0x0(0x90)

}; 
// ScriptStruct ControlRig.RigUnit_CollectionNameSearch
// Size: 0x28(Inherited: 0x8) 
struct FRigUnit_CollectionNameSearch : public FRigUnit_CollectionBase
{
	struct FName PartialName;  // 0x8(0x8)
	uint8_t  TypeToSearch;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct FRigElementKeyCollection Collection;  // 0x18(0x10)

}; 
// Function ControlRig.RigHierarchy.GetParentWeightArray
// Size: 0x20(Inherited: 0x0) 
struct FGetParentWeightArray
{
	struct FRigElementKey InChild;  // 0x0(0xC)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool bInitial : 1;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)
	struct TArray<struct FRigElementWeight> ReturnValue;  // 0x10(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_FitChainToCurve_WorkData
// Size: 0x98(Inherited: 0x0) 
struct FRigUnit_FitChainToCurve_WorkData
{
	float ChainLength;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct TArray<struct FVector> ItemPositions;  // 0x8(0x10)
	struct TArray<float> ItemSegments;  // 0x18(0x10)
	struct TArray<struct FVector> CurvePositions;  // 0x28(0x10)
	struct TArray<float> CurveSegments;  // 0x38(0x10)
	struct TArray<struct FCachedRigElement> CachedItems;  // 0x48(0x10)
	struct TArray<int32_t> ItemRotationA;  // 0x58(0x10)
	struct TArray<int32_t> ItemRotationB;  // 0x68(0x10)
	struct TArray<float> ItemRotationT;  // 0x78(0x10)
	struct TArray<struct FTransform> ItemLocalTransforms;  // 0x88(0x10)

}; 
// ScriptStruct ControlRig.RigUnitMutable
// Size: 0x40(Inherited: 0x8) 
struct FRigUnitMutable : public FRigUnit
{
	struct FControlRigExecuteContext ExecuteContext;  // 0x8(0x38)

}; 
// ScriptStruct ControlRig.CachedRigElement
// Size: 0x20(Inherited: 0x0) 
struct FCachedRigElement
{
	struct FRigElementKey Key;  // 0x0(0xC)
	uint16_t Index;  // 0xC(0x2)
	char pad_14[2];  // 0xE(0x2)
	int32_t ContainerVersion;  // 0x10(0x4)
	char pad_20[12];  // 0x14(0xC)

}; 
// ScriptStruct ControlRig.RigUnit_StringTruncate
// Size: 0x40(Inherited: 0x8) 
struct FRigUnit_StringTruncate : public FRigUnit_StringBase
{
	struct FString Name;  // 0x8(0x10)
	int32_t Count;  // 0x18(0x4)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool FromEnd : 1;  // 0x1C(0x1)
	char pad_29[3];  // 0x1D(0x3)
	struct FString Remainder;  // 0x20(0x10)
	struct FString Chopped;  // 0x30(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_FitChainToCurve_DebugSettings
// Size: 0x90(Inherited: 0x0) 
struct FRigUnit_FitChainToCurve_DebugSettings
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bEnabled : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	float Scale;  // 0x4(0x4)
	struct FLinearColor CurveColor;  // 0x8(0x10)
	struct FLinearColor SegmentsColor;  // 0x18(0x10)
	char pad_40[8];  // 0x28(0x8)
	struct FTransform WorldOffset;  // 0x30(0x60)

}; 
// ScriptStruct ControlRig.RigUnit_StringConcat
// Size: 0x38(Inherited: 0x8) 
struct FRigUnit_StringConcat : public FRigUnit_StringBase
{
	struct FString A;  // 0x8(0x10)
	struct FString B;  // 0x18(0x10)
	struct FString Result;  // 0x28(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_FitChainToCurve_Rotation
// Size: 0x30(Inherited: 0x0) 
struct FRigUnit_FitChainToCurve_Rotation
{
	struct FQuat Rotation;  // 0x0(0x20)
	float Ratio;  // 0x20(0x4)
	char pad_36[12];  // 0x24(0xC)

}; 
// ScriptStruct ControlRig.RigSingleParentElement
// Size: 0x300(Inherited: 0x2F0) 
struct FRigSingleParentElement : public FRigTransformElement
{
	char pad_752[16];  // 0x2F0(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_HasMetadataTagArray
// Size: 0x50(Inherited: 0x8) 
struct FRigUnit_HasMetadataTagArray : public FRigUnit
{
	struct FRigElementKey Item;  // 0x8(0xC)
	char pad_20[4];  // 0x14(0x4)
	struct TArray<struct FName> Tags;  // 0x18(0x10)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool Found : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct FCachedRigElement CachedIndex;  // 0x30(0x20)

}; 
// ScriptStruct ControlRig.RigUnit_GetAnimationChannelBase
// Size: 0x30(Inherited: 0x8) 
struct FRigUnit_GetAnimationChannelBase : public FRigUnit
{
	struct FName Control;  // 0x8(0x8)
	struct FName Channel;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool bInitial : 1;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)
	struct FRigElementKey CachedChannelKey;  // 0x1C(0xC)
	int32_t CachedChannelHash;  // 0x28(0x4)
	char pad_44[4];  // 0x2C(0x4)

}; 
// ScriptStruct ControlRig.RigUnit_MathIntNotEquals
// Size: 0x18(Inherited: 0x8) 
struct FRigUnit_MathIntNotEquals : public FRigUnit_MathIntBase
{
	int32_t A;  // 0x8(0x4)
	int32_t B;  // 0xC(0x4)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool Result : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// ScriptStruct ControlRig.RigElementWeight
// Size: 0xC(Inherited: 0x0) 
struct FRigElementWeight
{
	float Location;  // 0x0(0x4)
	float Rotation;  // 0x4(0x4)
	float Scale;  // 0x8(0x4)

}; 
// ScriptStruct ControlRig.RigUnit_CollectionLoop
// Size: 0xA8(Inherited: 0x40) 
struct FRigUnit_CollectionLoop : public FRigUnit_CollectionBaseMutable
{
	struct FRigElementKeyCollection Collection;  // 0x40(0x10)
	struct FRigElementKey Item;  // 0x50(0xC)
	int32_t Index;  // 0x5C(0x4)
	int32_t Count;  // 0x60(0x4)
	float Ratio;  // 0x64(0x4)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool Continue : 1;  // 0x68(0x1)
	char pad_105[7];  // 0x69(0x7)
	struct FControlRigExecuteContext Completed;  // 0x70(0x38)

}; 
// ScriptStruct ControlRig.RigUnit_AnimEasing
// Size: 0x28(Inherited: 0x8) 
struct FRigUnit_AnimEasing : public FRigUnit_AnimBase
{
	float Value;  // 0x8(0x4)
	uint8_t  Type;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)
	float SourceMinimum;  // 0x10(0x4)
	float SourceMaximum;  // 0x14(0x4)
	float TargetMinimum;  // 0x18(0x4)
	float TargetMaximum;  // 0x1C(0x4)
	float Result;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)

}; 
// ScriptStruct ControlRig.RigUnit_MathIntAdd
// Size: 0x18(Inherited: 0x18) 
struct FRigUnit_MathIntAdd : public FRigUnit_MathIntBinaryAggregateOp
{

}; 
// ScriptStruct ControlRig.RigElementParentConstraint
// Size: 0x90(Inherited: 0x0) 
struct FRigElementParentConstraint
{
	char pad_0[144];  // 0x0(0x90)

}; 
// ScriptStruct ControlRig.RigBoneElement
// Size: 0x300(Inherited: 0x300) 
struct FRigBoneElement : public FRigSingleParentElement
{
	uint8_t  BoneType;  // 0x2F8(0x1)

}; 
// ScriptStruct ControlRig.RigUnit_AnimRichCurve
// Size: 0x90(Inherited: 0x8) 
struct FRigUnit_AnimRichCurve : public FRigUnit_AnimBase
{
	struct FRuntimeFloatCurve Curve;  // 0x8(0x88)

}; 
// Function ControlRig.RigHierarchy.GetLocalTransform
// Size: 0x70(Inherited: 0x0) 
struct FGetLocalTransform
{
	struct FRigElementKey InKey;  // 0x0(0xC)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool bInitial : 1;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)
	struct FTransform ReturnValue;  // 0x10(0x60)

}; 
// ScriptStruct ControlRig.RigUnit_GetTransformArray
// Size: 0x40(Inherited: 0x8) 
struct FRigUnit_GetTransformArray : public FRigUnit
{
	struct FRigElementKeyCollection Items;  // 0x8(0x10)
	uint8_t  Space;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool bInitial : 1;  // 0x19(0x1)
	char pad_26[6];  // 0x1A(0x6)
	struct TArray<struct FTransform> Transforms;  // 0x20(0x10)
	struct TArray<struct FCachedRigElement> CachedIndex;  // 0x30(0x10)

}; 
// ScriptStruct ControlRig.RigFloatArrayMetadata
// Size: 0x38(Inherited: 0x28) 
struct FRigFloatArrayMetadata : public FRigBaseMetadata
{
	struct TArray<float> Value;  // 0x28(0x10)

}; 
// ScriptStruct ControlRig.ControlShapeActorCreationParam
// Size: 0x1D0(Inherited: 0x0) 
struct FControlShapeActorCreationParam
{
	char pad_0[464];  // 0x0(0x1D0)

}; 
// ScriptStruct ControlRig.RigNullElement
// Size: 0x3F0(Inherited: 0x3F0) 
struct FRigNullElement : public FRigMultiParentElement
{

}; 
// ScriptStruct ControlRig.RigUnit_MathFloatBinaryAggregateOp
// Size: 0x18(Inherited: 0x8) 
struct FRigUnit_MathFloatBinaryAggregateOp : public FRigUnit_MathFloatBase
{
	float A;  // 0x8(0x4)
	float B;  // 0xC(0x4)
	float Result;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)

}; 
// ScriptStruct ControlRig.RigCurveElement
// Size: 0xF8(Inherited: 0xF0) 
struct FRigCurveElement : public FRigBaseElement
{
	char pad_240[8];  // 0xF0(0x8)

}; 
// ScriptStruct ControlRig.RigUnit_MathRBFInterpolateVectorColor
// Size: 0xE0(Inherited: 0xC0) 
struct FRigUnit_MathRBFInterpolateVectorColor : public FRigUnit_MathRBFInterpolateVectorBase
{
	struct TArray<struct FMathRBFInterpolateVectorColor_Target> Targets;  // 0xC0(0x10)
	struct FLinearColor Output;  // 0xD0(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_MathFloatGreater
// Size: 0x18(Inherited: 0x8) 
struct FRigUnit_MathFloatGreater : public FRigUnit_MathFloatBase
{
	float A;  // 0x8(0x4)
	float B;  // 0xC(0x4)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool Result : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// ScriptStruct ControlRig.RigRigidBodyElement
// Size: 0x300(Inherited: 0x300) 
struct FRigRigidBodyElement : public FRigSingleParentElement
{
	struct FRigRigidBodySettings Settings;  // 0x2F8(0x4)

}; 
// ScriptStruct ControlRig.RigReferenceElement
// Size: 0x310(Inherited: 0x300) 
struct FRigReferenceElement : public FRigSingleParentElement
{
	char pad_768[16];  // 0x300(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_SetDefaultParent
// Size: 0x58(Inherited: 0x40) 
struct FRigUnit_SetDefaultParent : public FRigUnit_DynamicHierarchyBaseMutable
{
	struct FRigElementKey Child;  // 0x40(0xC)
	struct FRigElementKey Parent;  // 0x4C(0xC)

}; 
// Function ControlRig.RigHierarchy.SetControlValueByIndex
// Size: 0x110(Inherited: 0x0) 
struct FSetControlValueByIndex
{
	int32_t InElementIndex;  // 0x0(0x4)
	char pad_4[12];  // 0x4(0xC)
	struct FRigControlValue InValue;  // 0x10(0xF0)
	uint8_t  InValueType;  // 0x100(0x1)
	char pad_257_1 : 7;  // 0x101(0x1)
	bool bSetupUndo : 1;  // 0x101(0x1)
	char pad_258_1 : 7;  // 0x102(0x1)
	bool bPrintPythonCommands : 1;  // 0x102(0x1)
	char pad_259[13];  // 0x103(0xD)

}; 
// ScriptStruct ControlRig.RigHierarchyCopyPasteContentPerElement
// Size: 0x200(Inherited: 0x0) 
struct FRigHierarchyCopyPasteContentPerElement
{
	struct FRigElementKey Key;  // 0x0(0xC)
	char pad_12[4];  // 0xC(0x4)
	struct FString Content;  // 0x10(0x10)
	struct TArray<struct FRigElementKey> Parents;  // 0x20(0x10)
	struct TArray<struct FRigElementWeight> ParentWeights;  // 0x30(0x10)
	struct FRigCurrentAndInitialTransform Pose;  // 0x40(0x1C0)

}; 
// ScriptStruct ControlRig.RigHierarchyCopyPasteContent
// Size: 0x50(Inherited: 0x0) 
struct FRigHierarchyCopyPasteContent
{
	struct TArray<struct FRigHierarchyCopyPasteContentPerElement> Elements;  // 0x0(0x10)
	struct TArray<uint8_t > Types;  // 0x10(0x10)
	struct TArray<struct FString> Contents;  // 0x20(0x10)
	struct TArray<struct FTransform> LocalTransforms;  // 0x30(0x10)
	struct TArray<struct FTransform> GlobalTransforms;  // 0x40(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_PoseGetItems
// Size: 0x90(Inherited: 0x8) 
struct FRigUnit_PoseGetItems : public FRigUnit_HierarchyBase
{
	struct FRigPose Pose;  // 0x8(0x70)
	uint8_t  ElementType;  // 0x78(0x1)
	char pad_121[7];  // 0x79(0x7)
	struct FRigElementKeyCollection Items;  // 0x80(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_AnimBase
// Size: 0x8(Inherited: 0x8) 
struct FRigUnit_AnimBase : public FRigUnit
{

}; 
// Function ControlRig.RigHierarchy.SetVectorMetadata
// Size: 0x38(Inherited: 0x0) 
struct FSetVectorMetadata
{
	struct FRigElementKey InItem;  // 0x0(0xC)
	struct FName InMetadataName;  // 0xC(0x8)
	char pad_20[4];  // 0x14(0x4)
	struct FVector InValue;  // 0x18(0x18)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool ReturnValue : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)

}; 
// ScriptStruct ControlRig.RigUnit_GetDeltaTime
// Size: 0x10(Inherited: 0x8) 
struct FRigUnit_GetDeltaTime : public FRigUnit_AnimBase
{
	float Result;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)

}; 
// ScriptStruct ControlRig.RigUnit_DebugBase
// Size: 0x8(Inherited: 0x8) 
struct FRigUnit_DebugBase : public FRigUnit
{

}; 
// ScriptStruct ControlRig.RigUnit_HighlevelBase
// Size: 0x8(Inherited: 0x8) 
struct FRigUnit_HighlevelBase : public FRigUnit
{

}; 
// ScriptStruct ControlRig.RigUnit_SetMultiControlRotator_Entry
// Size: 0x28(Inherited: 0x0) 
struct FRigUnit_SetMultiControlRotator_Entry
{
	struct FName Control;  // 0x0(0x8)
	struct FRotator Rotator;  // 0x8(0x18)
	uint8_t  Space;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// ScriptStruct ControlRig.RigUnit_MathBase
// Size: 0x8(Inherited: 0x8) 
struct FRigUnit_MathBase : public FRigUnit
{

}; 
// ScriptStruct ControlRig.RigUnit_HierarchyGetParentWeightsArray
// Size: 0x38(Inherited: 0x8) 
struct FRigUnit_HierarchyGetParentWeightsArray : public FRigUnit_DynamicHierarchyBase
{
	struct FRigElementKey Child;  // 0x8(0xC)
	char pad_20[4];  // 0x14(0x4)
	struct TArray<struct FRigElementWeight> Weights;  // 0x18(0x10)
	struct TArray<struct FRigElementKey> Parents;  // 0x28(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_MathMutableBase
// Size: 0x40(Inherited: 0x40) 
struct FRigUnit_MathMutableBase : public FRigUnitMutable
{

}; 
// ScriptStruct ControlRig.RigUnit_SimBase
// Size: 0x8(Inherited: 0x8) 
struct FRigUnit_SimBase : public FRigUnit
{

}; 
// ScriptStruct ControlRig.RigUnit_SetBoneRotation
// Size: 0xA0(Inherited: 0x40) 
struct FRigUnit_SetBoneRotation : public FRigUnitMutable
{
	struct FName bone;  // 0x40(0x8)
	char pad_72[8];  // 0x48(0x8)
	struct FQuat Rotation;  // 0x50(0x20)
	uint8_t  Space;  // 0x70(0x1)
	char pad_113[3];  // 0x71(0x3)
	float Weight;  // 0x74(0x4)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool bPropagateToChildren : 1;  // 0x78(0x1)
	char pad_121[7];  // 0x79(0x7)
	struct FCachedRigElement CachedBone;  // 0x80(0x20)

}; 
// ScriptStruct ControlRig.RigUnit_MathVectorLength
// Size: 0x28(Inherited: 0x8) 
struct FRigUnit_MathVectorLength : public FRigUnit_MathVectorBase
{
	struct FVector Value;  // 0x8(0x18)
	float Result;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)

}; 
// ScriptStruct ControlRig.ControlRigAnimInstanceProxy
// Size: 0x920(Inherited: 0x880) 
struct FControlRigAnimInstanceProxy : public FAnimInstanceProxy
{
	char pad_2176[160];  // 0x880(0xA0)

}; 
// ScriptStruct ControlRig.RigUnit_SimBaseMutable
// Size: 0x40(Inherited: 0x40) 
struct FRigUnit_SimBaseMutable : public FRigUnitMutable
{

}; 
// ScriptStruct ControlRig.RigUnit_HierarchyAddControl_ProxySettings
// Size: 0x20(Inherited: 0x0) 
struct FRigUnit_HierarchyAddControl_ProxySettings
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bIsProxy : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct TArray<struct FRigElementKey> DrivenControls;  // 0x8(0x10)
	uint8_t  ShapeVisibility;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)

}; 
// ScriptStruct ControlRig.StructReference
// Size: 0x8(Inherited: 0x0) 
struct FStructReference
{
	char pad_0[8];  // 0x0(0x8)

}; 
// ScriptStruct ControlRig.RigUnit_ItemBase
// Size: 0x8(Inherited: 0x8) 
struct FRigUnit_ItemBase : public FRigUnit
{

}; 
// ScriptStruct ControlRig.RigUnit_MultiplyQuaternion
// Size: 0x70(Inherited: 0x70) 
struct FRigUnit_MultiplyQuaternion : public FRigUnit_BinaryQuaternionOp
{

}; 
// ScriptStruct ControlRig.AnimNode_ControlRigBase
// Size: 0x270(Inherited: 0x58) 
struct FAnimNode_ControlRigBase : public FAnimNode_CustomProperty
{
	struct FPoseLink Source;  // 0x58(0x10)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool bResetInputPoseToInitial : 1;  // 0x68(0x1)
	char pad_105_1 : 7;  // 0x69(0x1)
	bool bTransferInputPose : 1;  // 0x69(0x1)
	char pad_106_1 : 7;  // 0x6A(0x1)
	bool bTransferInputCurves : 1;  // 0x6A(0x1)
	char pad_107_1 : 7;  // 0x6B(0x1)
	bool bTransferPoseInGlobalSpace : 1;  // 0x6B(0x1)
	char pad_108[4];  // 0x6C(0x4)
	struct TArray<struct FBoneReference> InputBonesToTransfer;  // 0x70(0x10)
	char pad_128[448];  // 0x80(0x1C0)
	struct TWeakObjectPtr<UNodeMappingContainer> NodeMappingContainer;  // 0x240(0x8)
	struct FControlRigIOSettings InputSettings;  // 0x248(0x2)
	struct FControlRigIOSettings OutputSettings;  // 0x24A(0x2)
	char pad_588_1 : 7;  // 0x24C(0x1)
	bool bExecute : 1;  // 0x24C(0x1)
	char pad_589[11];  // 0x24D(0xB)
	struct TArray<struct FControlRigAnimNodeEventName> EventQueue;  // 0x258(0x10)
	char pad_616[8];  // 0x268(0x8)

}; 
// ScriptStruct ControlRig.RigUnit_MathTransformMutableBase
// Size: 0x40(Inherited: 0x40) 
struct FRigUnit_MathTransformMutableBase : public FRigUnit_MathMutableBase
{

}; 
// Function ControlRig.RigHierarchy.SetParentWeightArray
// Size: 0x28(Inherited: 0x0) 
struct FSetParentWeightArray
{
	struct FRigElementKey InChild;  // 0x0(0xC)
	char pad_12[4];  // 0xC(0x4)
	struct TArray<struct FRigElementWeight> InWeights;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool bInitial : 1;  // 0x20(0x1)
	char pad_33_1 : 7;  // 0x21(0x1)
	bool bAffectChildren : 1;  // 0x21(0x1)
	char pad_34_1 : 7;  // 0x22(0x1)
	bool ReturnValue : 1;  // 0x22(0x1)
	char pad_35[5];  // 0x23(0x5)

}; 
// ScriptStruct ControlRig.ControlRigAnimNodeEventName
// Size: 0x8(Inherited: 0x0) 
struct FControlRigAnimNodeEventName
{
	struct FName EventName;  // 0x0(0x8)

}; 
// ScriptStruct ControlRig.ControlRigIOSettings
// Size: 0x2(Inherited: 0x0) 
struct FControlRigIOSettings
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bUpdatePose : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool bUpdateCurves : 1;  // 0x1(0x1)

}; 
// Function ControlRig.RigHierarchy.GetAllKeys_ForBlueprint
// Size: 0x18(Inherited: 0x0) 
struct FGetAllKeys_ForBlueprint
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bTraverse : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct TArray<struct FRigElementKey> ReturnValue;  // 0x8(0x10)

}; 
// ScriptStruct ControlRig.AnimNode_ControlRig
// Size: 0x470(Inherited: 0x270) 
struct FAnimNode_ControlRig : public FAnimNode_ControlRigBase
{
	UControlRig* ControlRigClass;  // 0x270(0x8)
	struct UControlRig* ControlRig;  // 0x278(0x8)
	float Alpha;  // 0x280(0x4)
	uint8_t  AlphaInputType;  // 0x284(0x1)
	char bAlphaBoolEnabled : 1;  // 0x285(0x1)
	char bSetRefPoseFromSkeleton : 1;  // 0x285(0x1)
	char pad_645_1 : 6;  // 0x285(0x1)
	char pad_646[3];  // 0x286(0x3)
	struct FInputScaleBias AlphaScaleBias;  // 0x288(0x8)
	struct FInputAlphaBoolBlend AlphaBoolBlend;  // 0x290(0x48)
	struct FName AlphaCurveName;  // 0x2D8(0x8)
	struct FInputScaleBiasClamp AlphaScaleBiasClamp;  // 0x2E0(0x30)
	struct TMap<struct FName, struct FName> InputMapping;  // 0x310(0x50)
	struct TMap<struct FName, struct FName> OutputMapping;  // 0x360(0x50)
	char pad_944[176];  // 0x3B0(0xB0)
	int32_t LODThreshold;  // 0x460(0x4)
	char pad_1124[12];  // 0x464(0xC)

}; 
// ScriptStruct ControlRig.RigUnit_MathRBFInterpolateQuatBase
// Size: 0xF0(Inherited: 0x8) 
struct FRigUnit_MathRBFInterpolateQuatBase : public FRigUnit_MathRBFInterpolateBase
{
	char pad_8[8];  // 0x8(0x8)
	struct FQuat Input;  // 0x10(0x20)
	uint8_t  DistanceFunction;  // 0x30(0x1)
	uint8_t  SmoothingFunction;  // 0x31(0x1)
	char pad_50[2];  // 0x32(0x2)
	float SmoothingAngle;  // 0x34(0x4)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool bNormalizeOutput : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct FVector TwistAxis;  // 0x40(0x18)
	char pad_88[8];  // 0x58(0x8)
	struct FRigUnit_MathRBFInterpolateQuatWorkData WorkData;  // 0x60(0x90)

}; 
// ScriptStruct ControlRig.RigUnit_ItemTypeNotEquals
// Size: 0x28(Inherited: 0x8) 
struct FRigUnit_ItemTypeNotEquals : public FRigUnit_ItemBase
{
	struct FRigElementKey A;  // 0x8(0xC)
	struct FRigElementKey B;  // 0x14(0xC)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool Result : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// Function ControlRig.ControlRigShapeActor.OnManipulatingChanged
// Size: 0x1(Inherited: 0x0) 
struct FOnManipulatingChanged
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bIsManipulating : 1;  // 0x0(0x1)

}; 
// ScriptStruct ControlRig.RigUnit_HierarchyAddControlInteger
// Size: 0x1A0(Inherited: 0x60) 
struct FRigUnit_HierarchyAddControlInteger : public FRigUnit_HierarchyAddElement
{
	struct FTransform OffsetTransform;  // 0x60(0x60)
	int32_t InitialValue;  // 0xC0(0x4)
	char pad_196[12];  // 0xC4(0xC)
	struct FRigUnit_HierarchyAddControlInteger_Settings Settings;  // 0xD0(0xD0)

}; 
// ScriptStruct ControlRig.RigDispatch_SetAnimAttribute
// Size: 0x50(Inherited: 0x50) 
struct FRigDispatch_SetAnimAttribute : public FRigDispatch_AnimAttributeBase
{

}; 
// ScriptStruct ControlRig.RigInt32ArrayMetadata
// Size: 0x38(Inherited: 0x28) 
struct FRigInt32ArrayMetadata : public FRigBaseMetadata
{
	struct TArray<int32_t> Value;  // 0x28(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_MathColorAdd
// Size: 0x38(Inherited: 0x38) 
struct FRigUnit_MathColorAdd : public FRigUnit_MathColorBinaryAggregateOp
{

}; 
// ScriptStruct ControlRig.ControlRigComponentMappedElement
// Size: 0xD0(Inherited: 0x0) 
struct FControlRigComponentMappedElement
{
	struct FComponentReference ComponentReference;  // 0x0(0x28)
	int32_t TransformIndex;  // 0x28(0x4)
	struct FName TransformName;  // 0x2C(0x8)
	uint8_t  ElementType;  // 0x34(0x1)
	char pad_53[3];  // 0x35(0x3)
	struct FName ElementName;  // 0x38(0x8)
	uint8_t  Direction;  // 0x40(0x1)
	char pad_65[15];  // 0x41(0xF)
	struct FTransform Offset;  // 0x50(0x60)
	float Weight;  // 0xB0(0x4)
	uint8_t  Space;  // 0xB4(0x1)
	char pad_181[3];  // 0xB5(0x3)
	struct USceneComponent* SceneComponent;  // 0xB8(0x8)
	int32_t ElementIndex;  // 0xC0(0x4)
	int32_t SubIndex;  // 0xC4(0x4)
	char pad_200[8];  // 0xC8(0x8)

}; 
// ScriptStruct ControlRig.RigUnit_MathVectorClamp
// Size: 0x68(Inherited: 0x8) 
struct FRigUnit_MathVectorClamp : public FRigUnit_MathVectorBase
{
	struct FVector Value;  // 0x8(0x18)
	struct FVector Minimum;  // 0x20(0x18)
	struct FVector Maximum;  // 0x38(0x18)
	struct FVector Result;  // 0x50(0x18)

}; 
// ScriptStruct ControlRig.RigUnit_SetMultiControlFloat_Entry
// Size: 0xC(Inherited: 0x0) 
struct FRigUnit_SetMultiControlFloat_Entry
{
	struct FName Control;  // 0x0(0x8)
	float FloatValue;  // 0x8(0x4)

}; 
// ScriptStruct ControlRig.ControlRigComponentMappedComponent
// Size: 0x18(Inherited: 0x0) 
struct FControlRigComponentMappedComponent
{
	struct USceneComponent* Component;  // 0x0(0x8)
	struct FName ElementName;  // 0x8(0x8)
	uint8_t  ElementType;  // 0x10(0x1)
	uint8_t  Direction;  // 0x11(0x1)
	char pad_18[6];  // 0x12(0x6)

}; 
// ScriptStruct ControlRig.RigUnit_MathQuaternionFromRotator
// Size: 0x40(Inherited: 0x8) 
struct FRigUnit_MathQuaternionFromRotator : public FRigUnit_MathQuaternionBase
{
	struct FRotator Rotator;  // 0x8(0x18)
	struct FQuat Result;  // 0x20(0x20)

}; 
// ScriptStruct ControlRig.ControlRigComponentMappedBone
// Size: 0x10(Inherited: 0x0) 
struct FControlRigComponentMappedBone
{
	struct FName Source;  // 0x0(0x8)
	struct FName Target;  // 0x8(0x8)

}; 
// ScriptStruct ControlRig.ControlRigComponentMappedCurve
// Size: 0x10(Inherited: 0x0) 
struct FControlRigComponentMappedCurve
{
	struct FName Source;  // 0x0(0x8)
	struct FName Target;  // 0x8(0x8)

}; 
// ScriptStruct ControlRig.RigUnit_Divide_VectorVector
// Size: 0x50(Inherited: 0x50) 
struct FRigUnit_Divide_VectorVector : public FRigUnit_BinaryVectorOp
{

}; 
// ScriptStruct ControlRig.ControlRigValidationContext
// Size: 0x28(Inherited: 0x0) 
struct FControlRigValidationContext
{
	char pad_0[40];  // 0x0(0x28)

}; 
// ScriptStruct ControlRig.RigUnit_GetControlDrivenList
// Size: 0x40(Inherited: 0x8) 
struct FRigUnit_GetControlDrivenList : public FRigUnit
{
	struct FName Control;  // 0x8(0x8)
	struct TArray<struct FRigElementKey> Driven;  // 0x10(0x10)
	struct FCachedRigElement CachedControlIndex;  // 0x20(0x20)

}; 
// Function ControlRig.ControlRigShapeActor.SetGlobalTransform
// Size: 0x60(Inherited: 0x0) 
struct FSetGlobalTransform
{
	struct FTransform InTransform;  // 0x0(0x60)

}; 
// ScriptStruct ControlRig.RigUnit_CCDIK_RotationLimit
// Size: 0xC(Inherited: 0x0) 
struct FRigUnit_CCDIK_RotationLimit
{
	struct FName bone;  // 0x0(0x8)
	float Limit;  // 0x8(0x4)

}; 
// ScriptStruct ControlRig.RigUnit_MathTransformLerp
// Size: 0x140(Inherited: 0x8) 
struct FRigUnit_MathTransformLerp : public FRigUnit_MathTransformBase
{
	char pad_8[8];  // 0x8(0x8)
	struct FTransform A;  // 0x10(0x60)
	struct FTransform B;  // 0x70(0x60)
	float T;  // 0xD0(0x4)
	char pad_212[12];  // 0xD4(0xC)
	struct FTransform Result;  // 0xE0(0x60)

}; 
// ScriptStruct ControlRig.ControlRigDrawInterface
// Size: 0x18(Inherited: 0x18) 
struct FControlRigDrawInterface : public FControlRigDrawContainer
{

}; 
// ScriptStruct ControlRig.RigUnit_DebugRectangleItemSpace
// Size: 0x140(Inherited: 0x40) 
struct FRigUnit_DebugRectangleItemSpace : public FRigUnit_DebugBaseMutable
{
	struct FTransform Transform;  // 0x40(0x60)
	struct FLinearColor Color;  // 0xA0(0x10)
	float Scale;  // 0xB0(0x4)
	float Thickness;  // 0xB4(0x4)
	struct FRigElementKey Space;  // 0xB8(0xC)
	char pad_196[12];  // 0xC4(0xC)
	struct FTransform WorldOffset;  // 0xD0(0x60)
	char pad_304_1 : 7;  // 0x130(0x1)
	bool bEnabled : 1;  // 0x130(0x1)
	char pad_305[15];  // 0x131(0xF)

}; 
// ScriptStruct ControlRig.CRFourPointBezier
// Size: 0x60(Inherited: 0x0) 
struct FCRFourPointBezier
{
	struct FVector A;  // 0x0(0x18)
	struct FVector B;  // 0x18(0x18)
	struct FVector C;  // 0x30(0x18)
	struct FVector D;  // 0x48(0x18)

}; 
// ScriptStruct ControlRig.RigUnit_MathQuaternionUnaryOp
// Size: 0x50(Inherited: 0x8) 
struct FRigUnit_MathQuaternionUnaryOp : public FRigUnit_MathQuaternionBase
{
	char pad_8[8];  // 0x8(0x8)
	struct FQuat Value;  // 0x10(0x20)
	struct FQuat Result;  // 0x30(0x20)

}; 
// ScriptStruct ControlRig.RigUnit_SetControlDrivenList
// Size: 0x78(Inherited: 0x40) 
struct FRigUnit_SetControlDrivenList : public FRigUnitMutable
{
	struct FName Control;  // 0x40(0x8)
	struct TArray<struct FRigElementKey> Driven;  // 0x48(0x10)
	struct FCachedRigElement CachedControlIndex;  // 0x58(0x20)

}; 
// ScriptStruct ControlRig.RigUnit_ConvertQuaternionToVector
// Size: 0x50(Inherited: 0x8) 
struct FRigUnit_ConvertQuaternionToVector : public FRigUnit
{
	char pad_8[8];  // 0x8(0x8)
	struct FQuat Input;  // 0x10(0x20)
	struct FVector Result;  // 0x30(0x18)
	char pad_72[8];  // 0x48(0x8)

}; 
// ScriptStruct ControlRig.CRSimContainer
// Size: 0x18(Inherited: 0x0) 
struct FCRSimContainer
{
	char pad_0[8];  // 0x0(0x8)
	float TimeStep;  // 0x8(0x4)
	float AccumulatedTime;  // 0xC(0x4)
	float TimeLeftForStep;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)

}; 
// ScriptStruct ControlRig.RigUnit_HierarchyAddControlInteger_Settings
// Size: 0xD0(Inherited: 0x10) 
struct FRigUnit_HierarchyAddControlInteger_Settings : public FRigUnit_HierarchyAddControl_Settings
{
	uint8_t  PrimaryAxis;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)
	struct FRigUnit_HierarchyAddControlInteger_LimitSettings Limits;  // 0x14(0x10)
	char pad_36[12];  // 0x24(0xC)
	struct FRigUnit_HierarchyAddControl_ShapeSettings Shape;  // 0x30(0x80)
	struct FRigUnit_HierarchyAddControl_ProxySettings Proxy;  // 0xB0(0x20)

}; 
// ScriptStruct ControlRig.RigVectorMetadata
// Size: 0x40(Inherited: 0x28) 
struct FRigVectorMetadata : public FRigBaseMetadata
{
	struct FVector Value;  // 0x28(0x18)

}; 
// ScriptStruct ControlRig.RigUnit_MathVectorMakeBezierFourPoint
// Size: 0x68(Inherited: 0x8) 
struct FRigUnit_MathVectorMakeBezierFourPoint : public FRigUnit_MathVectorBase
{
	struct FCRFourPointBezier Bezier;  // 0x8(0x60)

}; 
// ScriptStruct ControlRig.RigUnit_ToSwingAndTwist
// Size: 0x90(Inherited: 0x8) 
struct FRigUnit_ToSwingAndTwist : public FRigUnit
{
	char pad_8[8];  // 0x8(0x8)
	struct FQuat Input;  // 0x10(0x20)
	struct FVector TwistAxis;  // 0x30(0x18)
	char pad_72[8];  // 0x48(0x8)
	struct FQuat Swing;  // 0x50(0x20)
	struct FQuat Twist;  // 0x70(0x20)

}; 
// ScriptStruct ControlRig.CRSimLinearSpring
// Size: 0x10(Inherited: 0x0) 
struct FCRSimLinearSpring
{
	int32_t SubjectA;  // 0x0(0x4)
	int32_t SubjectB;  // 0x4(0x4)
	float Coefficient;  // 0x8(0x4)
	float Equilibrium;  // 0xC(0x4)

}; 
// ScriptStruct ControlRig.RigUnit_StringLength
// Size: 0x20(Inherited: 0x8) 
struct FRigUnit_StringLength : public FRigUnit_StringBase
{
	struct FString Value;  // 0x8(0x10)
	int32_t Length;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)

}; 
// ScriptStruct ControlRig.RigUnit_SetRelativeTransformForItem
// Size: 0x110(Inherited: 0x40) 
struct FRigUnit_SetRelativeTransformForItem : public FRigUnitMutable
{
	struct FRigElementKey Child;  // 0x40(0xC)
	struct FRigElementKey Parent;  // 0x4C(0xC)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool bParentInitial : 1;  // 0x58(0x1)
	char pad_89[7];  // 0x59(0x7)
	struct FTransform Value;  // 0x60(0x60)
	float Weight;  // 0xC0(0x4)
	char pad_196_1 : 7;  // 0xC4(0x1)
	bool bPropagateToChildren : 1;  // 0xC4(0x1)
	char pad_197[3];  // 0xC5(0x3)
	struct FCachedRigElement CachedChild;  // 0xC8(0x20)
	struct FCachedRigElement CachedParent;  // 0xE8(0x20)
	char pad_264[8];  // 0x108(0x8)

}; 
// ScriptStruct ControlRig.CRSimPoint
// Size: 0x40(Inherited: 0x0) 
struct FCRSimPoint
{
	float Mass;  // 0x0(0x4)
	float Size;  // 0x4(0x4)
	float LinearDamping;  // 0x8(0x4)
	float InheritMotion;  // 0xC(0x4)
	struct FVector position;  // 0x10(0x18)
	struct FVector LinearVelocity;  // 0x28(0x18)

}; 
// Function ControlRig.RigHierarchy.SetGlobalTransformByIndex
// Size: 0x80(Inherited: 0x0) 
struct FSetGlobalTransformByIndex
{
	int32_t InElementIndex;  // 0x0(0x4)
	char pad_4[12];  // 0x4(0xC)
	struct FTransform InTransform;  // 0x10(0x60)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool bInitial : 1;  // 0x70(0x1)
	char pad_113_1 : 7;  // 0x71(0x1)
	bool bAffectChildren : 1;  // 0x71(0x1)
	char pad_114_1 : 7;  // 0x72(0x1)
	bool bSetupUndo : 1;  // 0x72(0x1)
	char pad_115_1 : 7;  // 0x73(0x1)
	bool bPrintPythonCommand : 1;  // 0x73(0x1)
	char pad_116[12];  // 0x74(0xC)

}; 
// ScriptStruct ControlRig.SphericalPoseReaderDebugSettings
// Size: 0x10(Inherited: 0x0) 
struct FSphericalPoseReaderDebugSettings
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bDrawDebug : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool bDraw2D : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool bDrawLocalAxes : 1;  // 0x2(0x1)
	char pad_3[1];  // 0x3(0x1)
	float DebugScale;  // 0x4(0x4)
	int32_t DebugSegments;  // 0x8(0x4)
	float DebugThickness;  // 0xC(0x4)

}; 
// ScriptStruct ControlRig.CRSimPointConstraint
// Size: 0x40(Inherited: 0x0) 
struct FCRSimPointConstraint
{
	uint8_t  Type;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	int32_t SubjectA;  // 0x4(0x4)
	int32_t SubjectB;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct FVector DataA;  // 0x10(0x18)
	struct FVector DataB;  // 0x28(0x18)

}; 
// Function ControlRig.ControlRigPoseAsset.SavePose
// Size: 0x10(Inherited: 0x0) 
struct FSavePose
{
	struct UControlRig* InControlRig;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bUseAll : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// ScriptStruct ControlRig.CRSimSoftCollision
// Size: 0x80(Inherited: 0x0) 
struct FCRSimSoftCollision
{
	struct FTransform Transform;  // 0x0(0x60)
	uint8_t  ShapeType;  // 0x60(0x1)
	char pad_97[3];  // 0x61(0x3)
	float MinimumDistance;  // 0x64(0x4)
	float MaximumDistance;  // 0x68(0x4)
	uint8_t  FalloffType;  // 0x6C(0x1)
	char pad_109[3];  // 0x6D(0x3)
	float Coefficient;  // 0x70(0x4)
	char pad_116_1 : 7;  // 0x74(0x1)
	bool bInverted : 1;  // 0x74(0x1)
	char pad_117[11];  // 0x75(0xB)

}; 
// ScriptStruct ControlRig.ConstraintNodeData
// Size: 0x140(Inherited: 0x0) 
struct FConstraintNodeData
{
	struct FTransform RelativeParent;  // 0x0(0x60)
	struct FConstraintOffset ConstraintOffset;  // 0x60(0xC0)
	struct FName LinkedNode;  // 0x120(0x8)
	struct TArray<struct FTransformConstraint> Constraints;  // 0x128(0x10)
	char pad_312[8];  // 0x138(0x8)

}; 
// Function ControlRig.RigHierarchy.GetFloatMetadata
// Size: 0x1C(Inherited: 0x0) 
struct FGetFloatMetadata
{
	struct FRigElementKey InItem;  // 0x0(0xC)
	struct FName InMetadataName;  // 0xC(0x8)
	float DefaultValue;  // 0x14(0x4)
	float ReturnValue;  // 0x18(0x4)

}; 
// ScriptStruct ControlRig.RigUnit_GetCurveValue
// Size: 0x38(Inherited: 0x8) 
struct FRigUnit_GetCurveValue : public FRigUnit
{
	struct FName Curve;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool Valid : 1;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)
	float Value;  // 0x14(0x4)
	struct FCachedRigElement CachedCurveIndex;  // 0x18(0x20)

}; 
// ScriptStruct ControlRig.RigUnit_AccumulateVectorLerp
// Size: 0x70(Inherited: 0x8) 
struct FRigUnit_AccumulateVectorLerp : public FRigUnit_AccumulateBase
{
	struct FVector TargetValue;  // 0x8(0x18)
	struct FVector InitialValue;  // 0x20(0x18)
	float Blend;  // 0x38(0x4)
	char pad_60_1 : 7;  // 0x3C(0x1)
	bool bIntegrateDeltaTime : 1;  // 0x3C(0x1)
	char pad_61[3];  // 0x3D(0x3)
	struct FVector Result;  // 0x40(0x18)
	struct FVector AccumulatedValue;  // 0x58(0x18)

}; 
// ScriptStruct ControlRig.RigElement
// Size: 0x18(Inherited: 0x0) 
struct FRigElement
{
	char pad_0[8];  // 0x0(0x8)
	struct FName Name;  // 0x8(0x8)
	int32_t Index;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)

}; 
// ScriptStruct ControlRig.RigUnit_Clamp_Float
// Size: 0x18(Inherited: 0x8) 
struct FRigUnit_Clamp_Float : public FRigUnit
{
	float Value;  // 0x8(0x4)
	float Min;  // 0xC(0x4)
	float Max;  // 0x10(0x4)
	float Result;  // 0x14(0x4)

}; 
// ScriptStruct ControlRig.RigControlHierarchy
// Size: 0x10(Inherited: 0x0) 
struct FRigControlHierarchy
{
	struct TArray<struct FRigControl> Controls;  // 0x0(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_MathDoubleNotEquals
// Size: 0x20(Inherited: 0x8) 
struct FRigUnit_MathDoubleNotEquals : public FRigUnit_MathDoubleBase
{
	double A;  // 0x8(0x8)
	double B;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool Result : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)

}; 
// Function ControlRig.RigHierarchy.IsParentedTo
// Size: 0x1C(Inherited: 0x0) 
struct FIsParentedTo
{
	struct FRigElementKey InChild;  // 0x0(0xC)
	struct FRigElementKey InParent;  // 0xC(0xC)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool ReturnValue : 1;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)

}; 
// ScriptStruct ControlRig.RigUnit_DebugLine
// Size: 0x100(Inherited: 0x40) 
struct FRigUnit_DebugLine : public FRigUnit_DebugBaseMutable
{
	struct FVector A;  // 0x40(0x18)
	struct FVector B;  // 0x58(0x18)
	struct FLinearColor Color;  // 0x70(0x10)
	float Thickness;  // 0x80(0x4)
	struct FName Space;  // 0x84(0x8)
	char pad_140[4];  // 0x8C(0x4)
	struct FTransform WorldOffset;  // 0x90(0x60)
	char pad_240_1 : 7;  // 0xF0(0x1)
	bool bEnabled : 1;  // 0xF0(0x1)
	char pad_241[15];  // 0xF1(0xF)

}; 
// ScriptStruct ControlRig.RigMirrorSettings
// Size: 0x28(Inherited: 0x0) 
struct FRigMirrorSettings
{
	char EAxis MirrorAxis;  // 0x0(0x1)
	char EAxis AxisToFlip;  // 0x1(0x1)
	char pad_2[6];  // 0x2(0x6)
	struct FString SearchString;  // 0x8(0x10)
	struct FString ReplaceString;  // 0x18(0x10)

}; 
// ScriptStruct ControlRig.RigCurve
// Size: 0x20(Inherited: 0x18) 
struct FRigCurve : public FRigElement
{
	float Value;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)

}; 
// ScriptStruct ControlRig.RigUnit_PositionConstraint
// Size: 0x68(Inherited: 0x40) 
struct FRigUnit_PositionConstraint : public FRigUnit_HighlevelBaseMutable
{
	struct FRigElementKey Child;  // 0x40(0xC)
	char pad_76_1 : 7;  // 0x4C(0x1)
	bool bMaintainOffset : 1;  // 0x4C(0x1)
	struct FFilterOptionPerAxis Filter;  // 0x4D(0x3)
	struct TArray<struct FConstraintParent> Parents;  // 0x50(0x10)
	float Weight;  // 0x60(0x4)
	char pad_100[4];  // 0x64(0x4)

}; 
// ScriptStruct ControlRig.RigLinearColorMetadata
// Size: 0x38(Inherited: 0x28) 
struct FRigLinearColorMetadata : public FRigBaseMetadata
{
	struct FLinearColor Value;  // 0x28(0x10)

}; 
// ScriptStruct ControlRig.RigCurveContainer
// Size: 0x10(Inherited: 0x0) 
struct FRigCurveContainer
{
	struct TArray<struct FRigCurve> Curves;  // 0x0(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_SetTransform
// Size: 0xE0(Inherited: 0x40) 
struct FRigUnit_SetTransform : public FRigUnitMutable
{
	struct FRigElementKey Item;  // 0x40(0xC)
	uint8_t  Space;  // 0x4C(0x1)
	char pad_77_1 : 7;  // 0x4D(0x1)
	bool bInitial : 1;  // 0x4D(0x1)
	char pad_78[2];  // 0x4E(0x2)
	struct FTransform Value;  // 0x50(0x60)
	float Weight;  // 0xB0(0x4)
	char pad_180_1 : 7;  // 0xB4(0x1)
	bool bPropagateToChildren : 1;  // 0xB4(0x1)
	char pad_181[3];  // 0xB5(0x3)
	struct FCachedRigElement CachedIndex;  // 0xB8(0x20)
	char pad_216[8];  // 0xD8(0x8)

}; 
// ScriptStruct ControlRig.RigUnit_PoseGetTransform
// Size: 0x100(Inherited: 0x8) 
struct FRigUnit_PoseGetTransform : public FRigUnit_HierarchyBase
{
	struct FRigPose Pose;  // 0x8(0x70)
	struct FRigElementKey Item;  // 0x78(0xC)
	uint8_t  Space;  // 0x84(0x1)
	char pad_133_1 : 7;  // 0x85(0x1)
	bool Valid : 1;  // 0x85(0x1)
	char pad_134[10];  // 0x86(0xA)
	struct FTransform Transform;  // 0x90(0x60)
	float CurveValue;  // 0xF0(0x4)
	int32_t CachedPoseElementIndex;  // 0xF4(0x4)
	int32_t CachedPoseHash;  // 0xF8(0x4)
	char pad_252[4];  // 0xFC(0x4)

}; 
// ScriptStruct ControlRig.RigUnit_SetBoneTranslation
// Size: 0x90(Inherited: 0x40) 
struct FRigUnit_SetBoneTranslation : public FRigUnitMutable
{
	struct FName bone;  // 0x40(0x8)
	struct FVector Translation;  // 0x48(0x18)
	uint8_t  Space;  // 0x60(0x1)
	char pad_97[3];  // 0x61(0x3)
	float Weight;  // 0x64(0x4)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool bPropagateToChildren : 1;  // 0x68(0x1)
	char pad_105[7];  // 0x69(0x7)
	struct FCachedRigElement CachedBone;  // 0x70(0x20)

}; 
// ScriptStruct ControlRig.RigUnit_AccumulateFloatLerp
// Size: 0x20(Inherited: 0x8) 
struct FRigUnit_AccumulateFloatLerp : public FRigUnit_AccumulateBase
{
	float TargetValue;  // 0x8(0x4)
	float InitialValue;  // 0xC(0x4)
	float Blend;  // 0x10(0x4)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool bIntegrateDeltaTime : 1;  // 0x14(0x1)
	char pad_21[3];  // 0x15(0x3)
	float Result;  // 0x18(0x4)
	float AccumulatedValue;  // 0x1C(0x4)

}; 
// ScriptStruct ControlRig.RigSpaceHierarchy
// Size: 0x10(Inherited: 0x0) 
struct FRigSpaceHierarchy
{
	struct TArray<struct FRigSpace> Spaces;  // 0x0(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_StringLeft
// Size: 0x30(Inherited: 0x8) 
struct FRigUnit_StringLeft : public FRigUnit_StringBase
{
	struct FString Value;  // 0x8(0x10)
	int32_t Count;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct FString Result;  // 0x20(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_MathBoolBinaryAggregateOp
// Size: 0x10(Inherited: 0x8) 
struct FRigUnit_MathBoolBinaryAggregateOp : public FRigUnit_MathBoolBase
{
	char pad_8_1 : 7;  // 0x8(0x1)
	bool A : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool B : 1;  // 0x9(0x1)
	char pad_10_1 : 7;  // 0xA(0x1)
	bool Result : 1;  // 0xA(0x1)
	char pad_11[5];  // 0xB(0x5)

}; 
// ScriptStruct ControlRig.RigSpace
// Size: 0xF0(Inherited: 0x18) 
struct FRigSpace : public FRigElement
{
	uint8_t  SpaceType;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)
	struct FName ParentName;  // 0x1C(0x8)
	int32_t ParentIndex;  // 0x24(0x4)
	char pad_40[8];  // 0x28(0x8)
	struct FTransform InitialTransform;  // 0x30(0x60)
	struct FTransform LocalTransform;  // 0x90(0x60)

}; 
// ScriptStruct ControlRig.RigUnit_StartProfilingTimer
// Size: 0x40(Inherited: 0x40) 
struct FRigUnit_StartProfilingTimer : public FRigUnit_DebugBaseMutable
{

}; 
// ScriptStruct ControlRig.RigHierarchyRef
// Size: 0x1(Inherited: 0x0) 
struct FRigHierarchyRef
{
	char pad_0[1];  // 0x0(0x1)

}; 
// ScriptStruct ControlRig.RigUnit_PoseLoop
// Size: 0x1D0(Inherited: 0x40) 
struct FRigUnit_PoseLoop : public FRigUnit_HierarchyBaseMutable
{
	struct FRigPose Pose;  // 0x40(0x70)
	struct FRigElementKey Item;  // 0xB0(0xC)
	char pad_188[4];  // 0xBC(0x4)
	struct FTransform GlobalTransform;  // 0xC0(0x60)
	struct FTransform LocalTransform;  // 0x120(0x60)
	float CurveValue;  // 0x180(0x4)
	int32_t Index;  // 0x184(0x4)
	int32_t Count;  // 0x188(0x4)
	float Ratio;  // 0x18C(0x4)
	char pad_400_1 : 7;  // 0x190(0x1)
	bool Continue : 1;  // 0x190(0x1)
	char pad_401[7];  // 0x191(0x7)
	struct FControlRigExecuteContext Completed;  // 0x198(0x38)

}; 
// ScriptStruct ControlRig.AnimNode_ControlRigInputPose
// Size: 0x30(Inherited: 0x10) 
struct FAnimNode_ControlRigInputPose : public FAnimNode_Base
{
	struct FPoseLink InputPose;  // 0x10(0x10)
	char pad_32[16];  // 0x20(0x10)

}; 
// ScriptStruct ControlRig.RigControlModifiedContext
// Size: 0x18(Inherited: 0x0) 
struct FRigControlModifiedContext
{
	char pad_0[24];  // 0x0(0x18)

}; 
// ScriptStruct ControlRig.RigUnit_HierarchyImportFromSkeleton
// Size: 0x60(Inherited: 0x40) 
struct FRigUnit_HierarchyImportFromSkeleton : public FRigUnit_DynamicHierarchyBaseMutable
{
	struct FName Namespace;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool bIncludeCurves : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)
	struct TArray<struct FRigElementKey> Items;  // 0x50(0x10)

}; 
// ScriptStruct ControlRig.RigEventContext
// Size: 0x28(Inherited: 0x0) 
struct FRigEventContext
{
	char pad_0[40];  // 0x0(0x28)

}; 
// Function ControlRig.RigHierarchy.SetControlOffsetTransform
// Size: 0x80(Inherited: 0x0) 
struct FSetControlOffsetTransform
{
	struct FRigElementKey InKey;  // 0x0(0xC)
	char pad_12[4];  // 0xC(0x4)
	struct FTransform InTransform;  // 0x10(0x60)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool bInitial : 1;  // 0x70(0x1)
	char pad_113_1 : 7;  // 0x71(0x1)
	bool bAffectChildren : 1;  // 0x71(0x1)
	char pad_114_1 : 7;  // 0x72(0x1)
	bool bSetupUndo : 1;  // 0x72(0x1)
	char pad_115_1 : 7;  // 0x73(0x1)
	bool bPrintPythonCommands : 1;  // 0x73(0x1)
	char pad_116[12];  // 0x74(0xC)

}; 
// ScriptStruct ControlRig.RigBaseMetadata
// Size: 0x28(Inherited: 0x0) 
struct FRigBaseMetadata
{
	char pad_0[16];  // 0x0(0x10)
	struct FName Name;  // 0x10(0x8)
	uint8_t  Type;  // 0x18(0x1)
	char pad_25[15];  // 0x19(0xF)

}; 
// ScriptStruct ControlRig.RigUnit_HierarchyAddAnimationChannelBool
// Size: 0x68(Inherited: 0x60) 
struct FRigUnit_HierarchyAddAnimationChannelBool : public FRigUnit_HierarchyAddElement
{
	char pad_96_1 : 7;  // 0x60(0x1)
	bool InitialValue : 1;  // 0x60(0x1)
	char pad_97_1 : 7;  // 0x61(0x1)
	bool MinimumValue : 1;  // 0x61(0x1)
	char pad_98_1 : 7;  // 0x62(0x1)
	bool MaximumValue : 1;  // 0x62(0x1)
	char pad_99[5];  // 0x63(0x5)

}; 
// ScriptStruct ControlRig.RigUnit_TransformConstraint_WorkData
// Size: 0x60(Inherited: 0x0) 
struct FRigUnit_TransformConstraint_WorkData
{
	struct TArray<struct FConstraintData> ConstraintData;  // 0x0(0x10)
	struct TMap<int32_t, int32_t> ConstraintDataToTargets;  // 0x10(0x50)

}; 
// ScriptStruct ControlRig.RigUnit_MathRBFInterpolateQuatWorkData
// Size: 0x90(Inherited: 0x0) 
struct FRigUnit_MathRBFInterpolateQuatWorkData
{
	char pad_0[144];  // 0x0(0x90)

}; 
// ScriptStruct ControlRig.RigUnit_MathRBFInterpolateBase
// Size: 0x8(Inherited: 0x8) 
struct FRigUnit_MathRBFInterpolateBase : public FRigUnit_MathBase
{

}; 
// ScriptStruct ControlRig.RigBoolMetadata
// Size: 0x30(Inherited: 0x28) 
struct FRigBoolMetadata : public FRigBaseMetadata
{
	char pad_40_1 : 7;  // 0x28(0x1)
	bool Value : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)

}; 
// ScriptStruct ControlRig.RigBoolArrayMetadata
// Size: 0x38(Inherited: 0x28) 
struct FRigBoolArrayMetadata : public FRigBaseMetadata
{
	struct TArray<bool> Value;  // 0x28(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_SphereTraceWorld
// Size: 0x78(Inherited: 0x8) 
struct FRigUnit_SphereTraceWorld : public FRigUnit
{
	struct FVector Start;  // 0x8(0x18)
	struct FVector End;  // 0x20(0x18)
	char ECollisionChannel Channel;  // 0x38(0x1)
	char pad_57[3];  // 0x39(0x3)
	float Radius;  // 0x3C(0x4)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool bHit : 1;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)
	struct FVector HitLocation;  // 0x48(0x18)
	struct FVector HitNormal;  // 0x60(0x18)

}; 
// ScriptStruct ControlRig.RigFloatMetadata
// Size: 0x30(Inherited: 0x28) 
struct FRigFloatMetadata : public FRigBaseMetadata
{
	float Value;  // 0x28(0x4)
	char pad_44[4];  // 0x2C(0x4)

}; 
// ScriptStruct ControlRig.RigInt32Metadata
// Size: 0x30(Inherited: 0x28) 
struct FRigInt32Metadata : public FRigBaseMetadata
{
	int32_t Value;  // 0x28(0x4)
	char pad_44[4];  // 0x2C(0x4)

}; 
// ScriptStruct ControlRig.RigUnit_MathFloatBinaryOp
// Size: 0x18(Inherited: 0x8) 
struct FRigUnit_MathFloatBinaryOp : public FRigUnit_MathFloatBase
{
	float A;  // 0x8(0x4)
	float B;  // 0xC(0x4)
	float Result;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)

}; 
// Function ControlRig.RigHierarchy.SetParentWeight
// Size: 0x28(Inherited: 0x0) 
struct FSetParentWeight
{
	struct FRigElementKey InChild;  // 0x0(0xC)
	struct FRigElementKey InParent;  // 0xC(0xC)
	struct FRigElementWeight InWeight;  // 0x18(0xC)
	char pad_36_1 : 7;  // 0x24(0x1)
	bool bInitial : 1;  // 0x24(0x1)
	char pad_37_1 : 7;  // 0x25(0x1)
	bool bAffectChildren : 1;  // 0x25(0x1)
	char pad_38_1 : 7;  // 0x26(0x1)
	bool ReturnValue : 1;  // 0x26(0x1)
	char pad_39[1];  // 0x27(0x1)

}; 
// ScriptStruct ControlRig.RigUnit_Multiply_VectorVector
// Size: 0x50(Inherited: 0x50) 
struct FRigUnit_Multiply_VectorVector : public FRigUnit_BinaryVectorOp
{

}; 
// Function ControlRig.RigHierarchy.MakeControlValueFromRotator
// Size: 0x110(Inherited: 0x0) 
struct FMakeControlValueFromRotator
{
	struct FRotator InValue;  // 0x0(0x18)
	char pad_24[8];  // 0x18(0x8)
	struct FRigControlValue ReturnValue;  // 0x20(0xF0)

}; 
// ScriptStruct ControlRig.RigUnit_MathTransformTransformVector
// Size: 0xA0(Inherited: 0x8) 
struct FRigUnit_MathTransformTransformVector : public FRigUnit_MathTransformBase
{
	char pad_8[8];  // 0x8(0x8)
	struct FTransform Transform;  // 0x10(0x60)
	struct FVector Location;  // 0x70(0x18)
	struct FVector Result;  // 0x88(0x18)

}; 
// ScriptStruct ControlRig.RigNameMetadata
// Size: 0x30(Inherited: 0x28) 
struct FRigNameMetadata : public FRigBaseMetadata
{
	struct FName Value;  // 0x28(0x8)

}; 
// Function ControlRig.RigHierarchyController.SetSelection
// Size: 0x18(Inherited: 0x0) 
struct FSetSelection
{
	struct TArray<struct FRigElementKey> InKeys;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bPrintPythonCommand : 1;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool ReturnValue : 1;  // 0x11(0x1)
	char pad_18[6];  // 0x12(0x6)

}; 
// ScriptStruct ControlRig.RigNameArrayMetadata
// Size: 0x38(Inherited: 0x28) 
struct FRigNameArrayMetadata : public FRigBaseMetadata
{
	struct TArray<struct FName> Value;  // 0x28(0x10)

}; 
// ScriptStruct ControlRig.RigVectorArrayMetadata
// Size: 0x38(Inherited: 0x28) 
struct FRigVectorArrayMetadata : public FRigBaseMetadata
{
	struct TArray<struct FVector> Value;  // 0x28(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_DebugTransformMutable
// Size: 0x140(Inherited: 0x40) 
struct FRigUnit_DebugTransformMutable : public FRigUnit_DebugBaseMutable
{
	struct FTransform Transform;  // 0x40(0x60)
	uint8_t  Mode;  // 0xA0(0x1)
	char pad_161[3];  // 0xA1(0x3)
	struct FLinearColor Color;  // 0xA4(0x10)
	float Thickness;  // 0xB4(0x4)
	float Scale;  // 0xB8(0x4)
	struct FName Space;  // 0xBC(0x8)
	char pad_196[12];  // 0xC4(0xC)
	struct FTransform WorldOffset;  // 0xD0(0x60)
	char pad_304_1 : 7;  // 0x130(0x1)
	bool bEnabled : 1;  // 0x130(0x1)
	char pad_305[15];  // 0x131(0xF)

}; 
// ScriptStruct ControlRig.RigRotatorMetadata
// Size: 0x40(Inherited: 0x28) 
struct FRigRotatorMetadata : public FRigBaseMetadata
{
	struct FRotator Value;  // 0x28(0x18)

}; 
// ScriptStruct ControlRig.RigRotatorArrayMetadata
// Size: 0x38(Inherited: 0x28) 
struct FRigRotatorArrayMetadata : public FRigBaseMetadata
{
	struct TArray<struct FRotator> Value;  // 0x28(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_MathIntMax
// Size: 0x18(Inherited: 0x18) 
struct FRigUnit_MathIntMax : public FRigUnit_MathIntBinaryAggregateOp
{

}; 
// Function ControlRig.RigHierarchy.GetParentWeight
// Size: 0x28(Inherited: 0x0) 
struct FGetParentWeight
{
	struct FRigElementKey InChild;  // 0x0(0xC)
	struct FRigElementKey InParent;  // 0xC(0xC)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool bInitial : 1;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)
	struct FRigElementWeight ReturnValue;  // 0x1C(0xC)

}; 
// ScriptStruct ControlRig.RigQuatMetadata
// Size: 0x50(Inherited: 0x28) 
struct FRigQuatMetadata : public FRigBaseMetadata
{
	char pad_40[8];  // 0x28(0x8)
	struct FQuat Value;  // 0x30(0x20)

}; 
// ScriptStruct ControlRig.RigQuatArrayMetadata
// Size: 0x38(Inherited: 0x28) 
struct FRigQuatArrayMetadata : public FRigBaseMetadata
{
	struct TArray<struct FQuat> Value;  // 0x28(0x10)

}; 
// ScriptStruct ControlRig.RigTransformArrayMetadata
// Size: 0x38(Inherited: 0x28) 
struct FRigTransformArrayMetadata : public FRigBaseMetadata
{
	struct TArray<struct FTransform> Value;  // 0x28(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_MathColorLerp
// Size: 0x40(Inherited: 0x8) 
struct FRigUnit_MathColorLerp : public FRigUnit_MathColorBase
{
	struct FLinearColor A;  // 0x8(0x10)
	struct FLinearColor B;  // 0x18(0x10)
	float T;  // 0x28(0x4)
	struct FLinearColor Result;  // 0x2C(0x10)
	char pad_60[4];  // 0x3C(0x4)

}; 
// ScriptStruct ControlRig.RigUnit_AnimEvalRichCurve
// Size: 0xB0(Inherited: 0x8) 
struct FRigUnit_AnimEvalRichCurve : public FRigUnit_AnimBase
{
	float Value;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct FRuntimeFloatCurve Curve;  // 0x10(0x88)
	float SourceMinimum;  // 0x98(0x4)
	float SourceMaximum;  // 0x9C(0x4)
	float TargetMinimum;  // 0xA0(0x4)
	float TargetMaximum;  // 0xA4(0x4)
	float Result;  // 0xA8(0x4)
	char pad_172[4];  // 0xAC(0x4)

}; 
// ScriptStruct ControlRig.RigLinearColorArrayMetadata
// Size: 0x38(Inherited: 0x28) 
struct FRigLinearColorArrayMetadata : public FRigBaseMetadata
{
	struct TArray<struct FLinearColor> Value;  // 0x28(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_ConvertVectorRotation
// Size: 0x40(Inherited: 0x40) 
struct FRigUnit_ConvertVectorRotation : public FRigUnit_ConvertRotation
{

}; 
// ScriptStruct ControlRig.RigUnit_Distance_VectorVector
// Size: 0x40(Inherited: 0x8) 
struct FRigUnit_Distance_VectorVector : public FRigUnit
{
	struct FVector Argument0;  // 0x8(0x18)
	struct FVector Argument1;  // 0x20(0x18)
	float Result;  // 0x38(0x4)
	char pad_60[4];  // 0x3C(0x4)

}; 
// ScriptStruct ControlRig.RigElementKeyArrayMetadata
// Size: 0x38(Inherited: 0x28) 
struct FRigElementKeyArrayMetadata : public FRigBaseMetadata
{
	struct TArray<struct FRigElementKey> Value;  // 0x28(0x10)

}; 
// ScriptStruct ControlRig.RigPoseElement
// Size: 0xF0(Inherited: 0x0) 
struct FRigPoseElement
{
	struct FCachedRigElement Index;  // 0x0(0x20)
	struct FTransform GlobalTransform;  // 0x20(0x60)
	struct FTransform LocalTransform;  // 0x80(0x60)
	float CurveValue;  // 0xE0(0x4)
	char pad_228[12];  // 0xE4(0xC)

}; 
// ScriptStruct ControlRig.RigPose
// Size: 0x70(Inherited: 0x0) 
struct FRigPose
{
	struct TArray<struct FRigPoseElement> Elements;  // 0x0(0x10)
	int32_t HierarchyTopologyVersion;  // 0x10(0x4)
	int32_t PoseHash;  // 0x14(0x4)
	char pad_24[88];  // 0x18(0x58)

}; 
// ScriptStruct ControlRig.RigInfluenceEntryModifier
// Size: 0x10(Inherited: 0x0) 
struct FRigInfluenceEntryModifier
{
	struct TArray<struct FRigElementKey> AffectedList;  // 0x0(0x10)

}; 
// Function ControlRig.RigHierarchy.GetCurveValue
// Size: 0x10(Inherited: 0x0) 
struct FGetCurveValue
{
	struct FRigElementKey InKey;  // 0x0(0xC)
	float ReturnValue;  // 0xC(0x4)

}; 
// ScriptStruct ControlRig.RigUnit_HierarchyGetParentWeights
// Size: 0x38(Inherited: 0x8) 
struct FRigUnit_HierarchyGetParentWeights : public FRigUnit_DynamicHierarchyBase
{
	struct FRigElementKey Child;  // 0x8(0xC)
	char pad_20[4];  // 0x14(0x4)
	struct TArray<struct FRigElementWeight> Weights;  // 0x18(0x10)
	struct FRigElementKeyCollection Parents;  // 0x28(0x10)

}; 
// ScriptStruct ControlRig.ControlRigLayerInstanceProxy
// Size: 0x920(Inherited: 0x880) 
struct FControlRigLayerInstanceProxy : public FAnimInstanceProxy
{
	char pad_2176[160];  // 0x880(0xA0)

}; 
// ScriptStruct ControlRig.ControlRigSequenceObjectReference
// Size: 0x8(Inherited: 0x0) 
struct FControlRigSequenceObjectReference
{
	UControlRig* ControlRigClass;  // 0x0(0x8)

}; 
// ScriptStruct ControlRig.RigUnit_SetControlVector2D
// Size: 0x80(Inherited: 0x40) 
struct FRigUnit_SetControlVector2D : public FRigUnitMutable
{
	struct FName Control;  // 0x40(0x8)
	float Weight;  // 0x48(0x4)
	char pad_76[4];  // 0x4C(0x4)
	struct FVector2D Vector;  // 0x50(0x10)
	struct FCachedRigElement CachedControlIndex;  // 0x60(0x20)

}; 
// ScriptStruct ControlRig.RigUnit_ConvertVectorToRotation
// Size: 0x38(Inherited: 0x8) 
struct FRigUnit_ConvertVectorToRotation : public FRigUnit
{
	struct FVector Input;  // 0x8(0x18)
	struct FRotator Result;  // 0x20(0x18)

}; 
// ScriptStruct ControlRig.ControlRigSequenceObjectReferences
// Size: 0x10(Inherited: 0x0) 
struct FControlRigSequenceObjectReferences
{
	struct TArray<struct FControlRigSequenceObjectReference> Array;  // 0x0(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_PropagateTransform
// Size: 0x70(Inherited: 0x40) 
struct FRigUnit_PropagateTransform : public FRigUnitMutable
{
	struct FRigElementKey Item;  // 0x40(0xC)
	char pad_76_1 : 7;  // 0x4C(0x1)
	bool bRecomputeGlobal : 1;  // 0x4C(0x1)
	char pad_77_1 : 7;  // 0x4D(0x1)
	bool bApplyToChildren : 1;  // 0x4D(0x1)
	char pad_78_1 : 7;  // 0x4E(0x1)
	bool bRecursive : 1;  // 0x4E(0x1)
	char pad_79[1];  // 0x4F(0x1)
	struct FCachedRigElement CachedIndex;  // 0x50(0x20)

}; 
// ScriptStruct ControlRig.EnumParameterNameAndCurve
// Size: 0x110(Inherited: 0x0) 
struct FEnumParameterNameAndCurve
{
	struct FName ParameterName;  // 0x0(0x8)
	struct FMovieSceneByteChannel ParameterCurve;  // 0x8(0x108)

}; 
// ScriptStruct ControlRig.RigUnit_HierarchyGetChildren
// Size: 0x58(Inherited: 0x8) 
struct FRigUnit_HierarchyGetChildren : public FRigUnit_HierarchyBase
{
	struct FRigElementKey Parent;  // 0x8(0xC)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool bIncludeParent : 1;  // 0x14(0x1)
	char pad_21_1 : 7;  // 0x15(0x1)
	bool bRecursive : 1;  // 0x15(0x1)
	char pad_22[2];  // 0x16(0x2)
	struct FRigElementKeyCollection Children;  // 0x18(0x10)
	struct FCachedRigElement CachedParent;  // 0x28(0x20)
	struct FRigElementKeyCollection CachedChildren;  // 0x48(0x10)

}; 
// Function ControlRig.RigHierarchyController.AddCurve
// Size: 0x1C(Inherited: 0x0) 
struct FAddCurve
{
	struct FName InName;  // 0x0(0x8)
	float InValue;  // 0x8(0x4)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool bSetupUndo : 1;  // 0xC(0x1)
	char pad_13_1 : 7;  // 0xD(0x1)
	bool bPrintPythonCommand : 1;  // 0xD(0x1)
	char pad_14[2];  // 0xE(0x2)
	struct FRigElementKey ReturnValue;  // 0x10(0xC)

}; 
// ScriptStruct ControlRig.IntegerParameterNameAndCurve
// Size: 0x108(Inherited: 0x0) 
struct FIntegerParameterNameAndCurve
{
	struct FName ParameterName;  // 0x0(0x8)
	struct FMovieSceneIntegerChannel ParameterCurve;  // 0x8(0x100)

}; 
// Function ControlRig.RigHierarchy.IsSelectedByIndex
// Size: 0x8(Inherited: 0x0) 
struct FIsSelectedByIndex
{
	int32_t InIndex;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool ReturnValue : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)

}; 
// ScriptStruct ControlRig.RigUnit_DebugArc
// Size: 0x140(Inherited: 0x40) 
struct FRigUnit_DebugArc : public FRigUnit_DebugBaseMutable
{
	struct FTransform Transform;  // 0x40(0x60)
	struct FLinearColor Color;  // 0xA0(0x10)
	float Radius;  // 0xB0(0x4)
	float MinimumDegrees;  // 0xB4(0x4)
	float MaximumDegrees;  // 0xB8(0x4)
	float Thickness;  // 0xBC(0x4)
	int32_t Detail;  // 0xC0(0x4)
	struct FName Space;  // 0xC4(0x8)
	char pad_204[4];  // 0xCC(0x4)
	struct FTransform WorldOffset;  // 0xD0(0x60)
	char pad_304_1 : 7;  // 0x130(0x1)
	bool bEnabled : 1;  // 0x130(0x1)
	char pad_305[15];  // 0x131(0xF)

}; 
// ScriptStruct ControlRig.MathRBFInterpolateVectorXform_Target
// Size: 0x80(Inherited: 0x0) 
struct FMathRBFInterpolateVectorXform_Target
{
	struct FVector Target;  // 0x0(0x18)
	char pad_24[8];  // 0x18(0x8)
	struct FTransform Value;  // 0x20(0x60)

}; 
// Function ControlRig.RigHierarchy.GetFloatFromControlValue
// Size: 0x100(Inherited: 0x0) 
struct FGetFloatFromControlValue
{
	struct FRigControlValue InValue;  // 0x0(0xF0)
	float ReturnValue;  // 0xF0(0x4)
	char pad_244[12];  // 0xF4(0xC)

}; 
// ScriptStruct ControlRig.MovieSceneControlRigSpaceChannel
// Size: 0x110(Inherited: 0x50) 
struct FMovieSceneControlRigSpaceChannel : public FMovieSceneChannel
{
	struct TArray<struct FFrameNumber> KeyTimes;  // 0x50(0x10)
	struct TArray<struct FMovieSceneControlRigSpaceBaseKey> KeyValues;  // 0x60(0x10)
	char pad_112[160];  // 0x70(0xA0)

}; 
// Function ControlRig.RigHierarchyController.DeselectElement
// Size: 0x10(Inherited: 0x0) 
struct FDeselectElement
{
	struct FRigElementKey InKey;  // 0x0(0xC)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool ReturnValue : 1;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)

}; 
// ScriptStruct ControlRig.RigUnit_ChainHarmonics
// Size: 0x310(Inherited: 0x40) 
struct FRigUnit_ChainHarmonics : public FRigUnit_HighlevelBaseMutable
{
	struct FName ChainRoot;  // 0x40(0x8)
	struct FVector Speed;  // 0x48(0x18)
	struct FRigUnit_ChainHarmonics_Reach Reach;  // 0x60(0x48)
	struct FRigUnit_ChainHarmonics_Wave Wave;  // 0xA8(0x78)
	struct FRuntimeFloatCurve WaveCurve;  // 0x120(0x88)
	struct FRigUnit_ChainHarmonics_Pendulum Pendulum;  // 0x1A8(0x58)
	char pad_512_1 : 7;  // 0x200(0x1)
	bool bDrawDebug : 1;  // 0x200(0x1)
	char pad_513[15];  // 0x201(0xF)
	struct FTransform DrawWorldOffset;  // 0x210(0x60)
	struct FRigUnit_ChainHarmonics_WorkData WorkData;  // 0x270(0x98)
	char pad_776[8];  // 0x308(0x8)

}; 
// ScriptStruct ControlRig.ChannelMapInfo
// Size: 0x40(Inherited: 0x0) 
struct FChannelMapInfo
{
	int32_t ControlIndex;  // 0x0(0x4)
	int32_t TotalChannelIndex;  // 0x4(0x4)
	int32_t ChannelIndex;  // 0x8(0x4)
	int32_t ParentControlIndex;  // 0xC(0x4)
	struct FName ChannelTypeName;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool bDoesHaveSpace : 1;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)
	int32_t SpaceChannelIndex;  // 0x1C(0x4)
	int32_t MaskIndex;  // 0x20(0x4)
	int32_t CategoryIndex;  // 0x24(0x4)
	char pad_40[8];  // 0x28(0x8)
	struct TArray<uint32_t> ConstraintsIndex;  // 0x30(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_MathVectorLengthSquared
// Size: 0x28(Inherited: 0x8) 
struct FRigUnit_MathVectorLengthSquared : public FRigUnit_MathVectorBase
{
	struct FVector Value;  // 0x8(0x18)
	float Result;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)

}; 
// ScriptStruct ControlRig.RigUnit_DebugLineStrip
// Size: 0xE0(Inherited: 0x40) 
struct FRigUnit_DebugLineStrip : public FRigUnit_DebugBaseMutable
{
	struct TArray<struct FVector> Points;  // 0x40(0x10)
	struct FLinearColor Color;  // 0x50(0x10)
	float Thickness;  // 0x60(0x4)
	struct FName Space;  // 0x64(0x8)
	char pad_108[4];  // 0x6C(0x4)
	struct FTransform WorldOffset;  // 0x70(0x60)
	char pad_208_1 : 7;  // 0xD0(0x1)
	bool bEnabled : 1;  // 0xD0(0x1)
	char pad_209[15];  // 0xD1(0xF)

}; 
// ScriptStruct ControlRig.ControlRigSettingsPerPinBool
// Size: 0x50(Inherited: 0x0) 
struct FControlRigSettingsPerPinBool
{
	struct TMap<struct FString, bool> Values;  // 0x0(0x50)

}; 
// ScriptStruct ControlRig.RigUnit_MathColorBinaryOp
// Size: 0x38(Inherited: 0x8) 
struct FRigUnit_MathColorBinaryOp : public FRigUnit_MathColorBase
{
	struct FLinearColor A;  // 0x8(0x10)
	struct FLinearColor B;  // 0x18(0x10)
	struct FLinearColor Result;  // 0x28(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_MathVectorRad
// Size: 0x38(Inherited: 0x38) 
struct FRigUnit_MathVectorRad : public FRigUnit_MathVectorUnaryOp
{

}; 
// ScriptStruct ControlRig.RigControlCopy
// Size: 0x2A0(Inherited: 0x0) 
struct FRigControlCopy
{
	char pad_0[16];  // 0x0(0x10)
	struct FName Name;  // 0x10(0x8)
	uint8_t  ControlType;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct FRigControlValue Value;  // 0x20(0xF0)
	struct FRigElementKey ParentKey;  // 0x110(0xC)
	char pad_284[4];  // 0x11C(0x4)
	struct FTransform OffsetTransform;  // 0x120(0x60)
	struct FTransform ParentTransform;  // 0x180(0x60)
	struct FTransform LocalTransform;  // 0x1E0(0x60)
	struct FTransform GlobalTransform;  // 0x240(0x60)

}; 
// ScriptStruct ControlRig.RigUnit_DrawContainerSetTransform
// Size: 0xB0(Inherited: 0x40) 
struct FRigUnit_DrawContainerSetTransform : public FRigUnitMutable
{
	struct FName InstructionName;  // 0x40(0x8)
	char pad_72[8];  // 0x48(0x8)
	struct FTransform Transform;  // 0x50(0x60)

}; 
// ScriptStruct ControlRig.ControlRigControlPose
// Size: 0x60(Inherited: 0x0) 
struct FControlRigControlPose
{
	struct TArray<struct FRigControlCopy> CopyOfControls;  // 0x0(0x10)
	char pad_16[80];  // 0x10(0x50)

}; 
// ScriptStruct ControlRig.RigUnit_MathVectorNegate
// Size: 0x38(Inherited: 0x38) 
struct FRigUnit_MathVectorNegate : public FRigUnit_MathVectorUnaryOp
{

}; 
// ScriptStruct ControlRig.RigUnit_SetBoolAnimationChannel
// Size: 0x70(Inherited: 0x68) 
struct FRigUnit_SetBoolAnimationChannel : public FRigUnit_SetAnimationChannelBase
{
	char pad_104_1 : 7;  // 0x68(0x1)
	bool Value : 1;  // 0x68(0x1)
	char pad_105[7];  // 0x69(0x7)

}; 
// ScriptStruct ControlRig.RigUnit_SlideChainItemArray
// Size: 0xA0(Inherited: 0x40) 
struct FRigUnit_SlideChainItemArray : public FRigUnit_HighlevelBaseMutable
{
	struct TArray<struct FRigElementKey> Items;  // 0x40(0x10)
	float SlideAmount;  // 0x50(0x4)
	char pad_84_1 : 7;  // 0x54(0x1)
	bool bPropagateToChildren : 1;  // 0x54(0x1)
	char pad_85[3];  // 0x55(0x3)
	struct FRigUnit_SlideChain_WorkData WorkData;  // 0x58(0x48)

}; 
// ScriptStruct ControlRig.RigDispatchFactory
// Size: 0x18(Inherited: 0x18) 
struct FRigDispatchFactory : public FRigVMDispatchFactory
{

}; 
// ScriptStruct ControlRig.RigUnit_MathVectorMax
// Size: 0x50(Inherited: 0x50) 
struct FRigUnit_MathVectorMax : public FRigUnit_MathVectorBinaryAggregateOp
{

}; 
// ScriptStruct ControlRig.RigDispatch_GetAnimAttribute
// Size: 0x50(Inherited: 0x50) 
struct FRigDispatch_GetAnimAttribute : public FRigDispatch_AnimAttributeBase
{

}; 
// ScriptStruct ControlRig.RigUnit_AnimEasingType
// Size: 0x10(Inherited: 0x8) 
struct FRigUnit_AnimEasingType : public FRigUnit_AnimBase
{
	uint8_t  Type;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// ScriptStruct ControlRig.RigUnit_FramesToSeconds
// Size: 0x10(Inherited: 0x8) 
struct FRigUnit_FramesToSeconds : public FRigUnit_AnimBase
{
	float Frames;  // 0x8(0x4)
	float Seconds;  // 0xC(0x4)

}; 
// ScriptStruct ControlRig.RigUnit_SecondsToFrames
// Size: 0x10(Inherited: 0x8) 
struct FRigUnit_SecondsToFrames : public FRigUnit_AnimBase
{
	float Seconds;  // 0x8(0x4)
	float Frames;  // 0xC(0x4)

}; 
// ScriptStruct ControlRig.RigUnit_SphereTraceByTraceChannel
// Size: 0x78(Inherited: 0x8) 
struct FRigUnit_SphereTraceByTraceChannel : public FRigUnit
{
	struct FVector Start;  // 0x8(0x18)
	struct FVector End;  // 0x20(0x18)
	char ETraceTypeQuery TraceChannel;  // 0x38(0x1)
	char pad_57[3];  // 0x39(0x3)
	float Radius;  // 0x3C(0x4)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool bHit : 1;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)
	struct FVector HitLocation;  // 0x48(0x18)
	struct FVector HitNormal;  // 0x60(0x18)

}; 
// ScriptStruct ControlRig.RigUnit_BinaryVectorOp
// Size: 0x50(Inherited: 0x8) 
struct FRigUnit_BinaryVectorOp : public FRigUnit
{
	struct FVector Argument0;  // 0x8(0x18)
	struct FVector Argument1;  // 0x20(0x18)
	struct FVector Result;  // 0x38(0x18)

}; 
// Function ControlRig.ControlRigComponent.AddMappedElements
// Size: 0x10(Inherited: 0x0) 
struct FAddMappedElements
{
	struct TArray<struct FControlRigComponentMappedElement> NewMappedElements;  // 0x0(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_Control
// Size: 0x180(Inherited: 0x8) 
struct FRigUnit_Control : public FRigUnit
{
	struct FEulerTransform Transform;  // 0x8(0x48)
	struct FTransform Base;  // 0x50(0x60)
	struct FTransform InitTransform;  // 0xB0(0x60)
	struct FTransform Result;  // 0x110(0x60)
	struct FTransformFilter Filter;  // 0x170(0x9)
	char pad_377[7];  // 0x179(0x7)

}; 
// ScriptStruct ControlRig.RigUnit_MathFloatClamp
// Size: 0x18(Inherited: 0x8) 
struct FRigUnit_MathFloatClamp : public FRigUnit_MathFloatBase
{
	float Value;  // 0x8(0x4)
	float Minimum;  // 0xC(0x4)
	float Maximum;  // 0x10(0x4)
	float Result;  // 0x14(0x4)

}; 
// ScriptStruct ControlRig.RigUnit_Control_StaticMesh
// Size: 0x1E0(Inherited: 0x180) 
struct FRigUnit_Control_StaticMesh : public FRigUnit_Control
{
	struct FTransform MeshTransform;  // 0x180(0x60)

}; 
// ScriptStruct ControlRig.RigUnit_DebugLineStripItemSpace
// Size: 0xE0(Inherited: 0x40) 
struct FRigUnit_DebugLineStripItemSpace : public FRigUnit_DebugBaseMutable
{
	struct TArray<struct FVector> Points;  // 0x40(0x10)
	struct FLinearColor Color;  // 0x50(0x10)
	float Thickness;  // 0x60(0x4)
	struct FRigElementKey Space;  // 0x64(0xC)
	struct FTransform WorldOffset;  // 0x70(0x60)
	char pad_208_1 : 7;  // 0xD0(0x1)
	bool bEnabled : 1;  // 0xD0(0x1)
	char pad_209[15];  // 0xD1(0xF)

}; 
// ScriptStruct ControlRig.RigUnit_ToRigSpace_Transform
// Size: 0xD0(Inherited: 0x8) 
struct FRigUnit_ToRigSpace_Transform : public FRigUnit
{
	char pad_8[8];  // 0x8(0x8)
	struct FTransform Value;  // 0x10(0x60)
	struct FTransform Global;  // 0x70(0x60)

}; 
// ScriptStruct ControlRig.RigUnit_MathColorFromFloat
// Size: 0x20(Inherited: 0x8) 
struct FRigUnit_MathColorFromFloat : public FRigUnit_MathColorBase
{
	float Value;  // 0x8(0x4)
	struct FLinearColor Result;  // 0xC(0x10)
	char pad_28[4];  // 0x1C(0x4)

}; 
// ScriptStruct ControlRig.RigDispatch_CoreBase
// Size: 0x18(Inherited: 0x18) 
struct FRigDispatch_CoreBase : public FRigDispatchFactory
{

}; 
// ScriptStruct ControlRig.RigUnit_AlphaInterp
// Size: 0x78(Inherited: 0x8) 
struct FRigUnit_AlphaInterp : public FRigUnit_SimBase
{
	float Value;  // 0x8(0x4)
	float Scale;  // 0xC(0x4)
	float Bias;  // 0x10(0x4)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool bMapRange : 1;  // 0x14(0x1)
	char pad_21[3];  // 0x15(0x3)
	struct FInputRange InRange;  // 0x18(0x8)
	struct FInputRange OutRange;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool bClampResult : 1;  // 0x28(0x1)
	char pad_41[3];  // 0x29(0x3)
	float ClampMin;  // 0x2C(0x4)
	float ClampMax;  // 0x30(0x4)
	char pad_52_1 : 7;  // 0x34(0x1)
	bool bInterpResult : 1;  // 0x34(0x1)
	char pad_53[3];  // 0x35(0x3)
	float InterpSpeedIncreasing;  // 0x38(0x4)
	float InterpSpeedDecreasing;  // 0x3C(0x4)
	float Result;  // 0x40(0x4)
	struct FInputScaleBiasClamp ScaleBiasClamp;  // 0x44(0x30)
	char pad_116[4];  // 0x74(0x4)

}; 
// ScriptStruct ControlRig.RigDispatch_CoreEquals
// Size: 0x18(Inherited: 0x18) 
struct FRigDispatch_CoreEquals : public FRigDispatch_CoreBase
{

}; 
// ScriptStruct ControlRig.RigUnit_BoneHarmonics
// Size: 0x100(Inherited: 0x40) 
struct FRigUnit_BoneHarmonics : public FRigUnit_HighlevelBaseMutable
{
	struct TArray<struct FRigUnit_BoneHarmonics_BoneTarget> Bones;  // 0x40(0x10)
	struct FVector WaveSpeed;  // 0x50(0x18)
	struct FVector WaveFrequency;  // 0x68(0x18)
	struct FVector WaveAmplitude;  // 0x80(0x18)
	struct FVector WaveOffset;  // 0x98(0x18)
	struct FVector WaveNoise;  // 0xB0(0x18)
	uint8_t  WaveEase;  // 0xC8(0x1)
	char pad_201[3];  // 0xC9(0x3)
	float WaveMinimum;  // 0xCC(0x4)
	float WaveMaximum;  // 0xD0(0x4)
	uint8_t  RotationOrder;  // 0xD4(0x1)
	char pad_213_1 : 7;  // 0xD5(0x1)
	bool bPropagateToChildren : 1;  // 0xD5(0x1)
	char pad_214[2];  // 0xD6(0x2)
	struct FRigUnit_BoneHarmonics_WorkData WorkData;  // 0xD8(0x28)

}; 
// ScriptStruct ControlRig.RigDispatch_CoreNotEquals
// Size: 0x18(Inherited: 0x18) 
struct FRigDispatch_CoreNotEquals : public FRigDispatch_CoreEquals
{

}; 
// ScriptStruct ControlRig.RigUnit_MathRBFInterpolateVectorBase
// Size: 0xC0(Inherited: 0x8) 
struct FRigUnit_MathRBFInterpolateVectorBase : public FRigUnit_MathRBFInterpolateBase
{
	struct FVector Input;  // 0x8(0x18)
	uint8_t  DistanceFunction;  // 0x20(0x1)
	uint8_t  SmoothingFunction;  // 0x21(0x1)
	char pad_34[2];  // 0x22(0x2)
	float SmoothingRadius;  // 0x24(0x4)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool bNormalizeOutput : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct FRigUnit_MathRBFInterpolateVectorWorkData WorkData;  // 0x30(0x90)

}; 
// ScriptStruct ControlRig.RigUnit_NameBase
// Size: 0x8(Inherited: 0x8) 
struct FRigUnit_NameBase : public FRigUnit
{

}; 
// ScriptStruct ControlRig.RigUnit_NameConcat
// Size: 0x20(Inherited: 0x8) 
struct FRigUnit_NameConcat : public FRigUnit_NameBase
{
	struct FName A;  // 0x8(0x8)
	struct FName B;  // 0x10(0x8)
	struct FName Result;  // 0x18(0x8)

}; 
// ScriptStruct ControlRig.RigUnit_MathDoubleDiv
// Size: 0x20(Inherited: 0x20) 
struct FRigUnit_MathDoubleDiv : public FRigUnit_MathDoubleBinaryOp
{

}; 
// ScriptStruct ControlRig.RigUnit_SetControlVector
// Size: 0x90(Inherited: 0x40) 
struct FRigUnit_SetControlVector : public FRigUnitMutable
{
	struct FName Control;  // 0x40(0x8)
	float Weight;  // 0x48(0x4)
	char pad_76[4];  // 0x4C(0x4)
	struct FVector Vector;  // 0x50(0x18)
	uint8_t  Space;  // 0x68(0x1)
	char pad_105[7];  // 0x69(0x7)
	struct FCachedRigElement CachedControlIndex;  // 0x70(0x20)

}; 
// ScriptStruct ControlRig.RigUnit_MathDoubleAsin
// Size: 0x18(Inherited: 0x18) 
struct FRigUnit_MathDoubleAsin : public FRigUnit_MathDoubleUnaryOp
{

}; 
// ScriptStruct ControlRig.RigUnit_NameTruncate
// Size: 0x28(Inherited: 0x8) 
struct FRigUnit_NameTruncate : public FRigUnit_NameBase
{
	struct FName Name;  // 0x8(0x8)
	int32_t Count;  // 0x10(0x4)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool FromEnd : 1;  // 0x14(0x1)
	char pad_21[3];  // 0x15(0x3)
	struct FName Remainder;  // 0x18(0x8)
	struct FName Chopped;  // 0x20(0x8)

}; 
// ScriptStruct ControlRig.RigUnit_NameReplace
// Size: 0x28(Inherited: 0x8) 
struct FRigUnit_NameReplace : public FRigUnit_NameBase
{
	struct FName Name;  // 0x8(0x8)
	struct FName Old;  // 0x10(0x8)
	struct FName New;  // 0x18(0x8)
	struct FName Result;  // 0x20(0x8)

}; 
// ScriptStruct ControlRig.RigUnit_UnsetCurveValue
// Size: 0x68(Inherited: 0x40) 
struct FRigUnit_UnsetCurveValue : public FRigUnitMutable
{
	struct FName Curve;  // 0x40(0x8)
	struct FCachedRigElement CachedCurveIndex;  // 0x48(0x20)

}; 
// ScriptStruct ControlRig.RigUnit_EndsWith
// Size: 0x20(Inherited: 0x8) 
struct FRigUnit_EndsWith : public FRigUnit_NameBase
{
	struct FName Name;  // 0x8(0x8)
	struct FName Ending;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool Result : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)

}; 
// ScriptStruct ControlRig.RigUnit_GetControlVector
// Size: 0x80(Inherited: 0x8) 
struct FRigUnit_GetControlVector : public FRigUnit
{
	struct FName Control;  // 0x8(0x8)
	uint8_t  Space;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct FVector Vector;  // 0x18(0x18)
	struct FVector Minimum;  // 0x30(0x18)
	struct FVector Maximum;  // 0x48(0x18)
	struct FCachedRigElement CachedControlIndex;  // 0x60(0x20)

}; 
// ScriptStruct ControlRig.RigUnit_StartsWith
// Size: 0x20(Inherited: 0x8) 
struct FRigUnit_StartsWith : public FRigUnit_NameBase
{
	struct FName Name;  // 0x8(0x8)
	struct FName Start;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool Result : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)

}; 
// ScriptStruct ControlRig.RigUnit_HierarchyAddNull
// Size: 0xD0(Inherited: 0x60) 
struct FRigUnit_HierarchyAddNull : public FRigUnit_HierarchyAddElement
{
	struct FTransform Transform;  // 0x60(0x60)
	uint8_t  Space;  // 0xC0(0x1)
	char pad_193[15];  // 0xC1(0xF)

}; 
// ScriptStruct ControlRig.RigUnit_Contains
// Size: 0x20(Inherited: 0x8) 
struct FRigUnit_Contains : public FRigUnit_NameBase
{
	struct FName Name;  // 0x8(0x8)
	struct FName Search;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool Result : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)

}; 
// ScriptStruct ControlRig.RigUnit_SpaceName
// Size: 0x10(Inherited: 0x8) 
struct FRigUnit_SpaceName : public FRigUnit
{
	struct FName Space;  // 0x8(0x8)

}; 
// ScriptStruct ControlRig.RigDispatch_Print
// Size: 0x18(Inherited: 0x18) 
struct FRigDispatch_Print : public FRigDispatchFactory
{

}; 
// ScriptStruct ControlRig.RigUnit_MathVectorIsNearlyZero
// Size: 0x28(Inherited: 0x8) 
struct FRigUnit_MathVectorIsNearlyZero : public FRigUnit_MathVectorBase
{
	struct FVector Value;  // 0x8(0x18)
	float Tolerance;  // 0x20(0x4)
	char pad_36_1 : 7;  // 0x24(0x1)
	bool Result : 1;  // 0x24(0x1)
	char pad_37[3];  // 0x25(0x3)

}; 
// ScriptStruct ControlRig.RigUnit_FindItemsWithMetadata
// Size: 0x28(Inherited: 0x8) 
struct FRigUnit_FindItemsWithMetadata : public FRigUnit
{
	struct FName Name;  // 0x8(0x8)
	uint8_t  Type;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct TArray<struct FRigElementKey> Items;  // 0x18(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_Multiply_FloatFloat
// Size: 0x18(Inherited: 0x18) 
struct FRigUnit_Multiply_FloatFloat : public FRigUnit_BinaryFloatOp
{

}; 
// ScriptStruct ControlRig.RigUnit_StringBase
// Size: 0x8(Inherited: 0x8) 
struct FRigUnit_StringBase : public FRigUnit
{

}; 
// ScriptStruct ControlRig.RigUnit_StringReplace
// Size: 0x48(Inherited: 0x8) 
struct FRigUnit_StringReplace : public FRigUnit_StringBase
{
	struct FString Name;  // 0x8(0x10)
	struct FString Old;  // 0x18(0x10)
	struct FString New;  // 0x28(0x10)
	struct FString Result;  // 0x38(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_MathTransformMul
// Size: 0x130(Inherited: 0x130) 
struct FRigUnit_MathTransformMul : public FRigUnit_MathTransformBinaryAggregateOp
{

}; 
// ScriptStruct ControlRig.RigUnit_DebugPoint
// Size: 0xC0(Inherited: 0x8) 
struct FRigUnit_DebugPoint : public FRigUnit_DebugBase
{
	struct FVector Vector;  // 0x8(0x18)
	uint8_t  Mode;  // 0x20(0x1)
	char pad_33[3];  // 0x21(0x3)
	struct FLinearColor Color;  // 0x24(0x10)
	float Scale;  // 0x34(0x4)
	float Thickness;  // 0x38(0x4)
	struct FName Space;  // 0x3C(0x8)
	char pad_68[12];  // 0x44(0xC)
	struct FTransform WorldOffset;  // 0x50(0x60)
	char pad_176_1 : 7;  // 0xB0(0x1)
	bool bEnabled : 1;  // 0xB0(0x1)
	char pad_177[15];  // 0xB1(0xF)

}; 
// Function ControlRig.RigHierarchy.MakeControlValueFromBool
// Size: 0x100(Inherited: 0x0) 
struct FMakeControlValueFromBool
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool InValue : 1;  // 0x0(0x1)
	char pad_1[15];  // 0x1(0xF)
	struct FRigControlValue ReturnValue;  // 0x10(0xF0)

}; 
// ScriptStruct ControlRig.RigUnit_MathBoolNotEquals
// Size: 0x10(Inherited: 0x8) 
struct FRigUnit_MathBoolNotEquals : public FRigUnit_MathBoolBase
{
	char pad_8_1 : 7;  // 0x8(0x1)
	bool A : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool B : 1;  // 0x9(0x1)
	char pad_10_1 : 7;  // 0xA(0x1)
	bool Result : 1;  // 0xA(0x1)
	char pad_11[5];  // 0xB(0x5)

}; 
// ScriptStruct ControlRig.RigUnit_StringEndsWith
// Size: 0x30(Inherited: 0x8) 
struct FRigUnit_StringEndsWith : public FRigUnit_StringBase
{
	struct FString Name;  // 0x8(0x10)
	struct FString Ending;  // 0x18(0x10)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool Result : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)

}; 
// ScriptStruct ControlRig.RigUnit_ConvertRotationToVector
// Size: 0x38(Inherited: 0x8) 
struct FRigUnit_ConvertRotationToVector : public FRigUnit
{
	struct FRotator Input;  // 0x8(0x18)
	struct FVector Result;  // 0x20(0x18)

}; 
// ScriptStruct ControlRig.RigUnit_StringStartsWith
// Size: 0x30(Inherited: 0x8) 
struct FRigUnit_StringStartsWith : public FRigUnit_StringBase
{
	struct FString Name;  // 0x8(0x10)
	struct FString Start;  // 0x18(0x10)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool Result : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)

}; 
// ScriptStruct ControlRig.RigUnit_StringContains
// Size: 0x30(Inherited: 0x8) 
struct FRigUnit_StringContains : public FRigUnit_StringBase
{
	struct FString Name;  // 0x8(0x10)
	struct FString Search;  // 0x18(0x10)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool Result : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)

}; 
// ScriptStruct ControlRig.RigUnit_StringTrimWhitespace
// Size: 0x28(Inherited: 0x8) 
struct FRigUnit_StringTrimWhitespace : public FRigUnit_StringBase
{
	struct FString Value;  // 0x8(0x10)
	struct FString Result;  // 0x18(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_MathDoubleCeil
// Size: 0x20(Inherited: 0x8) 
struct FRigUnit_MathDoubleCeil : public FRigUnit_MathDoubleBase
{
	double Value;  // 0x8(0x8)
	double Result;  // 0x10(0x8)
	int32_t Int;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)

}; 
// ScriptStruct ControlRig.RigUnit_MathTransformInverse
// Size: 0xD0(Inherited: 0xD0) 
struct FRigUnit_MathTransformInverse : public FRigUnit_MathTransformUnaryOp
{

}; 
// ScriptStruct ControlRig.RigUnit_CollectionUnion
// Size: 0x40(Inherited: 0x8) 
struct FRigUnit_CollectionUnion : public FRigUnit_CollectionBase
{
	struct FRigElementKeyCollection A;  // 0x8(0x10)
	struct FRigElementKeyCollection B;  // 0x18(0x10)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool bAllowDuplicates : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct FRigElementKeyCollection Collection;  // 0x30(0x10)

}; 
// ScriptStruct ControlRig.SphericalRegion
// Size: 0x14(Inherited: 0x0) 
struct FSphericalRegion
{
	char pad_0[20];  // 0x0(0x14)

}; 
// ScriptStruct ControlRig.RigUnit_StringToUppercase
// Size: 0x28(Inherited: 0x8) 
struct FRigUnit_StringToUppercase : public FRigUnit_StringBase
{
	struct FString Value;  // 0x8(0x10)
	struct FString Result;  // 0x18(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_PointSimulation_DebugSettings
// Size: 0x80(Inherited: 0x0) 
struct FRigUnit_PointSimulation_DebugSettings
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bEnabled : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	float Scale;  // 0x4(0x4)
	float CollisionScale;  // 0x8(0x4)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool bDrawPointsAsSpheres : 1;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)
	struct FLinearColor Color;  // 0x10(0x10)
	struct FTransform WorldOffset;  // 0x20(0x60)

}; 
// ScriptStruct ControlRig.RigUnit_RotationConstraint
// Size: 0x68(Inherited: 0x40) 
struct FRigUnit_RotationConstraint : public FRigUnit_HighlevelBaseMutable
{
	struct FRigElementKey Child;  // 0x40(0xC)
	char pad_76_1 : 7;  // 0x4C(0x1)
	bool bMaintainOffset : 1;  // 0x4C(0x1)
	struct FFilterOptionPerAxis Filter;  // 0x4D(0x3)
	struct TArray<struct FConstraintParent> Parents;  // 0x50(0x10)
	struct FRigUnit_RotationConstraint_AdvancedSettings AdvancedSettings;  // 0x60(0x2)
	char pad_98[2];  // 0x62(0x2)
	float Weight;  // 0x64(0x4)

}; 
// ScriptStruct ControlRig.RigUnit_ToWorldSpace_Transform
// Size: 0xD0(Inherited: 0x8) 
struct FRigUnit_ToWorldSpace_Transform : public FRigUnit
{
	char pad_8[8];  // 0x8(0x8)
	struct FTransform Value;  // 0x10(0x60)
	struct FTransform World;  // 0x70(0x60)

}; 
// ScriptStruct ControlRig.RigUnit_ItemBaseMutable
// Size: 0x40(Inherited: 0x40) 
struct FRigUnit_ItemBaseMutable : public FRigUnitMutable
{

}; 
// ScriptStruct ControlRig.MathRBFInterpolateQuatFloat_Target
// Size: 0x30(Inherited: 0x0) 
struct FMathRBFInterpolateQuatFloat_Target
{
	struct FQuat Target;  // 0x0(0x20)
	float Value;  // 0x20(0x4)
	char pad_36[12];  // 0x24(0xC)

}; 
// ScriptStruct ControlRig.RigUnit_StringReverse
// Size: 0x28(Inherited: 0x8) 
struct FRigUnit_StringReverse : public FRigUnit_StringBase
{
	struct FString Value;  // 0x8(0x10)
	struct FString Reverse;  // 0x18(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_StringRight
// Size: 0x30(Inherited: 0x8) 
struct FRigUnit_StringRight : public FRigUnit_StringBase
{
	struct FString Value;  // 0x8(0x10)
	int32_t Count;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct FString Result;  // 0x20(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_MathFloatAdd
// Size: 0x18(Inherited: 0x18) 
struct FRigUnit_MathFloatAdd : public FRigUnit_MathFloatBinaryAggregateOp
{

}; 
// ScriptStruct ControlRig.RigUnit_CollectionChain
// Size: 0x38(Inherited: 0x8) 
struct FRigUnit_CollectionChain : public FRigUnit_CollectionBase
{
	struct FRigElementKey FirstItem;  // 0x8(0xC)
	struct FRigElementKey LastItem;  // 0x14(0xC)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool Reverse : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct FRigElementKeyCollection Collection;  // 0x28(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_StringFind
// Size: 0x30(Inherited: 0x8) 
struct FRigUnit_StringFind : public FRigUnit_StringBase
{
	struct FString Value;  // 0x8(0x10)
	struct FString Search;  // 0x18(0x10)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool Found : 1;  // 0x28(0x1)
	char pad_41[3];  // 0x29(0x3)
	int32_t Index;  // 0x2C(0x4)

}; 
// ScriptStruct ControlRig.RigUnit_HierarchyBase
// Size: 0x8(Inherited: 0x8) 
struct FRigUnit_HierarchyBase : public FRigUnit
{

}; 
// ScriptStruct ControlRig.RigUnit_StringSplit
// Size: 0x38(Inherited: 0x8) 
struct FRigUnit_StringSplit : public FRigUnit_StringBase
{
	struct FString Value;  // 0x8(0x10)
	struct FString Separator;  // 0x18(0x10)
	struct TArray<struct FString> Result;  // 0x28(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_MathIntLessEqual
// Size: 0x18(Inherited: 0x8) 
struct FRigUnit_MathIntLessEqual : public FRigUnit_MathIntBase
{
	int32_t A;  // 0x8(0x4)
	int32_t B;  // 0xC(0x4)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool Result : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// ScriptStruct ControlRig.RigUnit_GetVector2DAnimationChannel
// Size: 0x40(Inherited: 0x30) 
struct FRigUnit_GetVector2DAnimationChannel : public FRigUnit_GetAnimationChannelBase
{
	struct FVector2D Value;  // 0x30(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_StringPadInteger
// Size: 0x20(Inherited: 0x8) 
struct FRigUnit_StringPadInteger : public FRigUnit_StringBase
{
	int32_t Value;  // 0x8(0x4)
	int32_t Digits;  // 0xC(0x4)
	struct FString Result;  // 0x10(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_MathDoubleRad
// Size: 0x18(Inherited: 0x18) 
struct FRigUnit_MathDoubleRad : public FRigUnit_MathDoubleUnaryOp
{

}; 
// ScriptStruct ControlRig.RigDispatch_ToString
// Size: 0x18(Inherited: 0x18) 
struct FRigDispatch_ToString : public FRigDispatchFactory
{

}; 
// ScriptStruct ControlRig.RigUnit_MathVectorRound
// Size: 0x38(Inherited: 0x38) 
struct FRigUnit_MathVectorRound : public FRigUnit_MathVectorUnaryOp
{

}; 
// Function ControlRig.RigHierarchyController.ImportCurves
// Size: 0x28(Inherited: 0x0) 
struct FImportCurves
{
	struct USkeleton* InSkeleton;  // 0x0(0x8)
	struct FName InNameSpace;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bSelectCurves : 1;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool bSetupUndo : 1;  // 0x11(0x1)
	char pad_18_1 : 7;  // 0x12(0x1)
	bool bPrintPythonCommand : 1;  // 0x12(0x1)
	char pad_19[5];  // 0x13(0x5)
	struct TArray<struct FRigElementKey> ReturnValue;  // 0x18(0x10)

}; 
// ScriptStruct ControlRig.RigDispatch_FromString
// Size: 0x18(Inherited: 0x18) 
struct FRigDispatch_FromString : public FRigDispatchFactory
{

}; 
// ScriptStruct ControlRig.RigUnit_MathFloatConstPi
// Size: 0x10(Inherited: 0x10) 
struct FRigUnit_MathFloatConstPi : public FRigUnit_MathFloatConstant
{

}; 
// ScriptStruct ControlRig.RigUnit_MathMatrixToVectors
// Size: 0xF0(Inherited: 0x8) 
struct FRigUnit_MathMatrixToVectors : public FRigUnit_MathMatrixBase
{
	char pad_8[8];  // 0x8(0x8)
	struct FMatrix Value;  // 0x10(0x80)
	struct FVector Origin;  // 0x90(0x18)
	struct FVector X;  // 0xA8(0x18)
	struct FVector Y;  // 0xC0(0x18)
	struct FVector Z;  // 0xD8(0x18)

}; 
// ScriptStruct ControlRig.RigUnit_DebugBezier
// Size: 0x140(Inherited: 0x40) 
struct FRigUnit_DebugBezier : public FRigUnit_DebugBaseMutable
{
	struct FCRFourPointBezier Bezier;  // 0x40(0x60)
	float MinimumU;  // 0xA0(0x4)
	float MaximumU;  // 0xA4(0x4)
	struct FLinearColor Color;  // 0xA8(0x10)
	float Thickness;  // 0xB8(0x4)
	int32_t Detail;  // 0xBC(0x4)
	struct FName Space;  // 0xC0(0x8)
	char pad_200[8];  // 0xC8(0x8)
	struct FTransform WorldOffset;  // 0xD0(0x60)
	char pad_304_1 : 7;  // 0x130(0x1)
	bool bEnabled : 1;  // 0x130(0x1)
	char pad_305[15];  // 0x131(0xF)

}; 
// Function ControlRig.RigHierarchy.GetGlobalControlOffsetTransformByIndex
// Size: 0x70(Inherited: 0x0) 
struct FGetGlobalControlOffsetTransformByIndex
{
	int32_t InElementIndex;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool bInitial : 1;  // 0x4(0x1)
	char pad_5[11];  // 0x5(0xB)
	struct FTransform ReturnValue;  // 0x10(0x60)

}; 
// ScriptStruct ControlRig.RigUnit_DebugBezierItemSpace
// Size: 0x140(Inherited: 0x40) 
struct FRigUnit_DebugBezierItemSpace : public FRigUnit_DebugBaseMutable
{
	struct FCRFourPointBezier Bezier;  // 0x40(0x60)
	float MinimumU;  // 0xA0(0x4)
	float MaximumU;  // 0xA4(0x4)
	struct FLinearColor Color;  // 0xA8(0x10)
	float Thickness;  // 0xB8(0x4)
	int32_t Detail;  // 0xBC(0x4)
	struct FRigElementKey Space;  // 0xC0(0xC)
	char pad_204[4];  // 0xCC(0x4)
	struct FTransform WorldOffset;  // 0xD0(0x60)
	char pad_304_1 : 7;  // 0x130(0x1)
	bool bEnabled : 1;  // 0x130(0x1)
	char pad_305[15];  // 0x131(0xF)

}; 
// ScriptStruct ControlRig.RigUnit_MathQuaternionUnit
// Size: 0x50(Inherited: 0x50) 
struct FRigUnit_MathQuaternionUnit : public FRigUnit_MathQuaternionUnaryOp
{

}; 
// Function ControlRig.RigHierarchy.GetCurveValueByIndex
// Size: 0x8(Inherited: 0x0) 
struct FGetCurveValueByIndex
{
	int32_t InElementIndex;  // 0x0(0x4)
	float ReturnValue;  // 0x4(0x4)

}; 
// ScriptStruct ControlRig.RigUnit_ApplyFK
// Size: 0x130(Inherited: 0x40) 
struct FRigUnit_ApplyFK : public FRigUnitMutable
{
	struct FName Joint;  // 0x40(0x8)
	char pad_72[8];  // 0x48(0x8)
	struct FTransform Transform;  // 0x50(0x60)
	struct FTransformFilter Filter;  // 0xB0(0x9)
	uint8_t  ApplyTransformMode;  // 0xB9(0x1)
	uint8_t  ApplyTransformSpace;  // 0xBA(0x1)
	char pad_187[5];  // 0xBB(0x5)
	struct FTransform BaseTransform;  // 0xC0(0x60)
	struct FName BaseJoint;  // 0x120(0x8)
	char pad_296[8];  // 0x128(0x8)

}; 
// ScriptStruct ControlRig.RigUnit_MathQuaternionFromRotatorV2
// Size: 0x40(Inherited: 0x8) 
struct FRigUnit_MathQuaternionFromRotatorV2 : public FRigUnit_MathQuaternionBase
{
	struct FRotator Value;  // 0x8(0x18)
	struct FQuat Result;  // 0x20(0x20)

}; 
// ScriptStruct ControlRig.RigUnit_DebugHierarchy
// Size: 0xD0(Inherited: 0x40) 
struct FRigUnit_DebugHierarchy : public FRigUnit_DebugBaseMutable
{
	float Scale;  // 0x40(0x4)
	struct FLinearColor Color;  // 0x44(0x10)
	float Thickness;  // 0x54(0x4)
	char pad_88[8];  // 0x58(0x8)
	struct FTransform WorldOffset;  // 0x60(0x60)
	char pad_192_1 : 7;  // 0xC0(0x1)
	bool bEnabled : 1;  // 0xC0(0x1)
	char pad_193[15];  // 0xC1(0xF)

}; 
// ScriptStruct ControlRig.RigUnit_MathFloatSqrt
// Size: 0x10(Inherited: 0x10) 
struct FRigUnit_MathFloatSqrt : public FRigUnit_MathFloatUnaryOp
{

}; 
// ScriptStruct ControlRig.RigUnit_DebugPose
// Size: 0x140(Inherited: 0x40) 
struct FRigUnit_DebugPose : public FRigUnit_DebugBaseMutable
{
	struct FRigPose Pose;  // 0x40(0x70)
	float Scale;  // 0xB0(0x4)
	struct FLinearColor Color;  // 0xB4(0x10)
	float Thickness;  // 0xC4(0x4)
	char pad_200[8];  // 0xC8(0x8)
	struct FTransform WorldOffset;  // 0xD0(0x60)
	char pad_304_1 : 7;  // 0x130(0x1)
	bool bEnabled : 1;  // 0x130(0x1)
	char pad_305[15];  // 0x131(0xF)

}; 
// ScriptStruct ControlRig.RigUnit_MathIntSub
// Size: 0x18(Inherited: 0x18) 
struct FRigUnit_MathIntSub : public FRigUnit_MathIntBinaryOp
{

}; 
// ScriptStruct ControlRig.RigUnit_DebugLineItemSpace
// Size: 0x100(Inherited: 0x40) 
struct FRigUnit_DebugLineItemSpace : public FRigUnit_DebugBaseMutable
{
	struct FVector A;  // 0x40(0x18)
	struct FVector B;  // 0x58(0x18)
	struct FLinearColor Color;  // 0x70(0x10)
	float Thickness;  // 0x80(0x4)
	struct FRigElementKey Space;  // 0x84(0xC)
	struct FTransform WorldOffset;  // 0x90(0x60)
	char pad_240_1 : 7;  // 0xF0(0x1)
	bool bEnabled : 1;  // 0xF0(0x1)
	char pad_241[15];  // 0xF1(0xF)

}; 
// ScriptStruct ControlRig.RigUnit_MathQuaternionBinaryAggregateOp
// Size: 0x70(Inherited: 0x8) 
struct FRigUnit_MathQuaternionBinaryAggregateOp : public FRigUnit_MathQuaternionBase
{
	char pad_8[8];  // 0x8(0x8)
	struct FQuat A;  // 0x10(0x20)
	struct FQuat B;  // 0x30(0x20)
	struct FQuat Result;  // 0x50(0x20)

}; 
// ScriptStruct ControlRig.RigUnit_DebugPointMutable
// Size: 0xF0(Inherited: 0x40) 
struct FRigUnit_DebugPointMutable : public FRigUnit_DebugBaseMutable
{
	struct FVector Vector;  // 0x40(0x18)
	uint8_t  Mode;  // 0x58(0x1)
	char pad_89[3];  // 0x59(0x3)
	struct FLinearColor Color;  // 0x5C(0x10)
	float Scale;  // 0x6C(0x4)
	float Thickness;  // 0x70(0x4)
	struct FName Space;  // 0x74(0x8)
	char pad_124[4];  // 0x7C(0x4)
	struct FTransform WorldOffset;  // 0x80(0x60)
	char pad_224_1 : 7;  // 0xE0(0x1)
	bool bEnabled : 1;  // 0xE0(0x1)
	char pad_225[15];  // 0xE1(0xF)

}; 
// ScriptStruct ControlRig.RigUnit_DebugRectangle
// Size: 0x130(Inherited: 0x40) 
struct FRigUnit_DebugRectangle : public FRigUnit_DebugBaseMutable
{
	struct FTransform Transform;  // 0x40(0x60)
	struct FLinearColor Color;  // 0xA0(0x10)
	float Scale;  // 0xB0(0x4)
	float Thickness;  // 0xB4(0x4)
	struct FName Space;  // 0xB8(0x8)
	struct FTransform WorldOffset;  // 0xC0(0x60)
	char pad_288_1 : 7;  // 0x120(0x1)
	bool bEnabled : 1;  // 0x120(0x1)
	char pad_289[15];  // 0x121(0xF)

}; 
// ScriptStruct ControlRig.RigUnit_DebugArcItemSpace
// Size: 0x140(Inherited: 0x40) 
struct FRigUnit_DebugArcItemSpace : public FRigUnit_DebugBaseMutable
{
	struct FTransform Transform;  // 0x40(0x60)
	struct FLinearColor Color;  // 0xA0(0x10)
	float Radius;  // 0xB0(0x4)
	float MinimumDegrees;  // 0xB4(0x4)
	float MaximumDegrees;  // 0xB8(0x4)
	float Thickness;  // 0xBC(0x4)
	int32_t Detail;  // 0xC0(0x4)
	struct FRigElementKey Space;  // 0xC4(0xC)
	struct FTransform WorldOffset;  // 0xD0(0x60)
	char pad_304_1 : 7;  // 0x130(0x1)
	bool bEnabled : 1;  // 0x130(0x1)
	char pad_305[15];  // 0x131(0xF)

}; 
// ScriptStruct ControlRig.RigUnit_DebugTransformMutableItemSpace
// Size: 0x140(Inherited: 0x40) 
struct FRigUnit_DebugTransformMutableItemSpace : public FRigUnit_DebugBaseMutable
{
	struct FTransform Transform;  // 0x40(0x60)
	uint8_t  Mode;  // 0xA0(0x1)
	char pad_161[3];  // 0xA1(0x3)
	struct FLinearColor Color;  // 0xA4(0x10)
	float Thickness;  // 0xB4(0x4)
	float Scale;  // 0xB8(0x4)
	struct FRigElementKey Space;  // 0xBC(0xC)
	char pad_200[8];  // 0xC8(0x8)
	struct FTransform WorldOffset;  // 0xD0(0x60)
	char pad_304_1 : 7;  // 0x130(0x1)
	bool bEnabled : 1;  // 0x130(0x1)
	char pad_305[15];  // 0x131(0xF)

}; 
// ScriptStruct ControlRig.RigUnit_MathDoubleAcos
// Size: 0x18(Inherited: 0x18) 
struct FRigUnit_MathDoubleAcos : public FRigUnit_MathDoubleUnaryOp
{

}; 
// ScriptStruct ControlRig.RigUnit_HierarchySetPose
// Size: 0xD0(Inherited: 0x40) 
struct FRigUnit_HierarchySetPose : public FRigUnit_HierarchyBaseMutable
{
	struct FRigPose Pose;  // 0x40(0x70)
	uint8_t  ElementType;  // 0xB0(0x1)
	uint8_t  Space;  // 0xB1(0x1)
	char pad_178[6];  // 0xB2(0x6)
	struct FRigElementKeyCollection ItemsToSet;  // 0xB8(0x10)
	float Weight;  // 0xC8(0x4)
	char pad_204[4];  // 0xCC(0x4)

}; 
// ScriptStruct ControlRig.RigUnit_DebugTransformArrayMutable_WorkData
// Size: 0x10(Inherited: 0x0) 
struct FRigUnit_DebugTransformArrayMutable_WorkData
{
	struct TArray<struct FTransform> DrawTransforms;  // 0x0(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_DebugTransformArrayMutableItemSpace
// Size: 0x100(Inherited: 0x40) 
struct FRigUnit_DebugTransformArrayMutableItemSpace : public FRigUnit_DebugBaseMutable
{
	struct TArray<struct FTransform> Transforms;  // 0x40(0x10)
	struct TArray<int32_t> ParentIndices;  // 0x50(0x10)
	uint8_t  Mode;  // 0x60(0x1)
	char pad_97[3];  // 0x61(0x3)
	struct FLinearColor Color;  // 0x64(0x10)
	float Thickness;  // 0x74(0x4)
	float Scale;  // 0x78(0x4)
	struct FRigElementKey Space;  // 0x7C(0xC)
	char pad_136[8];  // 0x88(0x8)
	struct FTransform WorldOffset;  // 0x90(0x60)
	char pad_240_1 : 7;  // 0xF0(0x1)
	bool bEnabled : 1;  // 0xF0(0x1)
	char pad_241[15];  // 0xF1(0xF)

}; 
// ScriptStruct ControlRig.RigUnit_FindItemsWithMetadataTagArray
// Size: 0x28(Inherited: 0x8) 
struct FRigUnit_FindItemsWithMetadataTagArray : public FRigUnit
{
	struct TArray<struct FName> Tags;  // 0x8(0x10)
	struct TArray<struct FRigElementKey> Items;  // 0x18(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_EndProfilingTimer
// Size: 0x60(Inherited: 0x40) 
struct FRigUnit_EndProfilingTimer : public FRigUnit_DebugBaseMutable
{
	int32_t NumberOfMeasurements;  // 0x40(0x4)
	char pad_68[4];  // 0x44(0x4)
	struct FString Prefix;  // 0x48(0x10)
	float AccumulatedTime;  // 0x58(0x4)
	int32_t MeasurementsLeft;  // 0x5C(0x4)

}; 
// ScriptStruct ControlRig.RigUnit_SetMetadataTag
// Size: 0x78(Inherited: 0x40) 
struct FRigUnit_SetMetadataTag : public FRigUnitMutable
{
	struct FRigElementKey Item;  // 0x40(0xC)
	struct FName Tag;  // 0x4C(0x8)
	char pad_84[4];  // 0x54(0x4)
	struct FCachedRigElement CachedIndex;  // 0x58(0x20)

}; 
// ScriptStruct ControlRig.RigUnit_AimBone
// Size: 0x1B0(Inherited: 0x40) 
struct FRigUnit_AimBone : public FRigUnit_HighlevelBaseMutable
{
	struct FName bone;  // 0x40(0x8)
	struct FRigUnit_AimBone_Target Primary;  // 0x48(0x48)
	struct FRigUnit_AimBone_Target Secondary;  // 0x90(0x48)
	float Weight;  // 0xD8(0x4)
	char pad_220_1 : 7;  // 0xDC(0x1)
	bool bPropagateToChildren : 1;  // 0xDC(0x1)
	char pad_221[3];  // 0xDD(0x3)
	struct FRigUnit_AimBone_DebugSettings DebugSettings;  // 0xE0(0x70)
	struct FCachedRigElement CachedBoneIndex;  // 0x150(0x20)
	struct FCachedRigElement PrimaryCachedSpace;  // 0x170(0x20)
	struct FCachedRigElement SecondaryCachedSpace;  // 0x190(0x20)

}; 
// ScriptStruct ControlRig.RigUnit_VisualDebugVector
// Size: 0x48(Inherited: 0x8) 
struct FRigUnit_VisualDebugVector : public FRigUnit_DebugBase
{
	struct FVector Value;  // 0x8(0x18)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool bEnabled : 1;  // 0x20(0x1)
	uint8_t  Mode;  // 0x21(0x1)
	char pad_34[2];  // 0x22(0x2)
	struct FLinearColor Color;  // 0x24(0x10)
	float Thickness;  // 0x34(0x4)
	float Scale;  // 0x38(0x4)
	struct FName BoneSpace;  // 0x3C(0x8)
	char pad_68[4];  // 0x44(0x4)

}; 
// ScriptStruct ControlRig.RigUnit_SetShapeTransform
// Size: 0xD0(Inherited: 0x40) 
struct FRigUnit_SetShapeTransform : public FRigUnitMutable
{
	struct FName Control;  // 0x40(0x8)
	char pad_72[8];  // 0x48(0x8)
	struct FTransform Transform;  // 0x50(0x60)
	struct FCachedRigElement CachedControlIndex;  // 0xB0(0x20)

}; 
// Function ControlRig.RigHierarchyController.ExportToText
// Size: 0x20(Inherited: 0x0) 
struct FExportToText
{
	struct TArray<struct FRigElementKey> InKeys;  // 0x0(0x10)
	struct FString ReturnValue;  // 0x10(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_SpringInterpV2
// Size: 0x40(Inherited: 0x8) 
struct FRigUnit_SpringInterpV2 : public FRigUnit_SimBase
{
	float Target;  // 0x8(0x4)
	float Strength;  // 0xC(0x4)
	float CriticalDamping;  // 0x10(0x4)
	float Force;  // 0x14(0x4)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool bUseCurrentInput : 1;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)
	float Current;  // 0x1C(0x4)
	float TargetVelocityAmount;  // 0x20(0x4)
	char pad_36_1 : 7;  // 0x24(0x1)
	bool bInitializeFromTarget : 1;  // 0x24(0x1)
	char pad_37[3];  // 0x25(0x3)
	float Result;  // 0x28(0x4)
	float Velocity;  // 0x2C(0x4)
	float SimulatedResult;  // 0x30(0x4)
	struct FFloatSpringState SpringState;  // 0x34(0xC)

}; 
// ScriptStruct ControlRig.RigUnit_IsInteracting
// Size: 0x20(Inherited: 0x8) 
struct FRigUnit_IsInteracting : public FRigUnit
{
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bIsInteracting : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool bIsTranslating : 1;  // 0x9(0x1)
	char pad_10_1 : 7;  // 0xA(0x1)
	bool bIsRotating : 1;  // 0xA(0x1)
	char pad_11_1 : 7;  // 0xB(0x1)
	bool bIsScaling : 1;  // 0xB(0x1)
	char pad_12[4];  // 0xC(0x4)
	struct TArray<struct FRigElementKey> Items;  // 0x10(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_VisualDebugVectorItemSpace
// Size: 0x48(Inherited: 0x8) 
struct FRigUnit_VisualDebugVectorItemSpace : public FRigUnit_DebugBase
{
	struct FVector Value;  // 0x8(0x18)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool bEnabled : 1;  // 0x20(0x1)
	uint8_t  Mode;  // 0x21(0x1)
	char pad_34[2];  // 0x22(0x2)
	struct FLinearColor Color;  // 0x24(0x10)
	float Thickness;  // 0x34(0x4)
	float Scale;  // 0x38(0x4)
	struct FRigElementKey Space;  // 0x3C(0xC)

}; 
// ScriptStruct ControlRig.RigUnit_VisualDebugQuat
// Size: 0x50(Inherited: 0x8) 
struct FRigUnit_VisualDebugQuat : public FRigUnit_DebugBase
{
	char pad_8[8];  // 0x8(0x8)
	struct FQuat Value;  // 0x10(0x20)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool bEnabled : 1;  // 0x30(0x1)
	char pad_49[3];  // 0x31(0x3)
	float Thickness;  // 0x34(0x4)
	float Scale;  // 0x38(0x4)
	struct FName BoneSpace;  // 0x3C(0x8)
	char pad_68[12];  // 0x44(0xC)

}; 
// ScriptStruct ControlRig.RigUnit_VisualDebugQuatItemSpace
// Size: 0x50(Inherited: 0x8) 
struct FRigUnit_VisualDebugQuatItemSpace : public FRigUnit_DebugBase
{
	char pad_8[8];  // 0x8(0x8)
	struct FQuat Value;  // 0x10(0x20)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool bEnabled : 1;  // 0x30(0x1)
	char pad_49[3];  // 0x31(0x3)
	float Thickness;  // 0x34(0x4)
	float Scale;  // 0x38(0x4)
	struct FRigElementKey Space;  // 0x3C(0xC)
	char pad_72[8];  // 0x48(0x8)

}; 
// ScriptStruct ControlRig.RigUnit_ConvertEulerTransform
// Size: 0xB0(Inherited: 0x8) 
struct FRigUnit_ConvertEulerTransform : public FRigUnit
{
	struct FEulerTransform Input;  // 0x8(0x48)
	struct FTransform Result;  // 0x50(0x60)

}; 
// ScriptStruct ControlRig.RigUnit_PointSimulation
// Size: 0x250(Inherited: 0x40) 
struct FRigUnit_PointSimulation : public FRigUnit_SimBaseMutable
{
	struct TArray<struct FCRSimPoint> Points;  // 0x40(0x10)
	struct TArray<struct FCRSimLinearSpring> Links;  // 0x50(0x10)
	struct TArray<struct FCRSimPointForce> Forces;  // 0x60(0x10)
	struct TArray<struct FCRSimSoftCollision> CollisionVolumes;  // 0x70(0x10)
	float SimulatedStepsPerSecond;  // 0x80(0x4)
	uint8_t  IntegratorType;  // 0x84(0x1)
	char pad_133[3];  // 0x85(0x3)
	float VerletBlend;  // 0x88(0x4)
	char pad_140[4];  // 0x8C(0x4)
	struct TArray<struct FRigUnit_PointSimulation_BoneTarget> BoneTargets;  // 0x90(0x10)
	char pad_160_1 : 7;  // 0xA0(0x1)
	bool bLimitLocalPosition : 1;  // 0xA0(0x1)
	char pad_161_1 : 7;  // 0xA1(0x1)
	bool bPropagateToChildren : 1;  // 0xA1(0x1)
	char pad_162[6];  // 0xA2(0x6)
	struct FVector PrimaryAimAxis;  // 0xA8(0x18)
	struct FVector SecondaryAimAxis;  // 0xC0(0x18)
	char pad_216[8];  // 0xD8(0x8)
	struct FRigUnit_PointSimulation_DebugSettings DebugSettings;  // 0xE0(0x80)
	struct FCRFourPointBezier Bezier;  // 0x160(0x60)
	struct FRigUnit_PointSimulation_WorkData WorkData;  // 0x1C0(0x88)
	char pad_584[8];  // 0x248(0x8)

}; 
// ScriptStruct ControlRig.RigUnit_MathQuaternionScale
// Size: 0x40(Inherited: 0x8) 
struct FRigUnit_MathQuaternionScale : public FRigUnit_MathQuaternionBase
{
	char pad_8[8];  // 0x8(0x8)
	struct FQuat Value;  // 0x10(0x20)
	float Scale;  // 0x30(0x4)
	char pad_52[12];  // 0x34(0xC)

}; 
// ScriptStruct ControlRig.RigUnit_QuaternionFromAxisAndAngle
// Size: 0x50(Inherited: 0x8) 
struct FRigUnit_QuaternionFromAxisAndAngle : public FRigUnit
{
	struct FVector Axis;  // 0x8(0x18)
	float Angle;  // 0x20(0x4)
	char pad_36[12];  // 0x24(0xC)
	struct FQuat Result;  // 0x30(0x20)

}; 
// ScriptStruct ControlRig.RigUnit_GetControlInteger
// Size: 0x40(Inherited: 0x8) 
struct FRigUnit_GetControlInteger : public FRigUnit
{
	struct FName Control;  // 0x8(0x8)
	int32_t IntegerValue;  // 0x10(0x4)
	int32_t Minimum;  // 0x14(0x4)
	int32_t Maximum;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct FCachedRigElement CachedControlIndex;  // 0x20(0x20)

}; 
// ScriptStruct ControlRig.RigUnit_ConvertRotation
// Size: 0x40(Inherited: 0x8) 
struct FRigUnit_ConvertRotation : public FRigUnit
{
	struct FRotator Input;  // 0x8(0x18)
	struct FQuat Result;  // 0x20(0x20)

}; 
// ScriptStruct ControlRig.RigUnit_DynamicHierarchyBase
// Size: 0x8(Inherited: 0x8) 
struct FRigUnit_DynamicHierarchyBase : public FRigUnit
{

}; 
// ScriptStruct ControlRig.RigUnit_ConvertQuaternion
// Size: 0x50(Inherited: 0x8) 
struct FRigUnit_ConvertQuaternion : public FRigUnit
{
	char pad_8[8];  // 0x8(0x8)
	struct FQuat Input;  // 0x10(0x20)
	struct FRotator Result;  // 0x30(0x18)
	char pad_72[8];  // 0x48(0x8)

}; 
// ScriptStruct ControlRig.RigUnit_ConvertVectorToQuaternion
// Size: 0x40(Inherited: 0x8) 
struct FRigUnit_ConvertVectorToQuaternion : public FRigUnit
{
	struct FVector Input;  // 0x8(0x18)
	struct FQuat Result;  // 0x20(0x20)

}; 
// ScriptStruct ControlRig.RigUnit_GetTransformAnimationChannel
// Size: 0x90(Inherited: 0x30) 
struct FRigUnit_GetTransformAnimationChannel : public FRigUnit_GetAnimationChannelBase
{
	struct FTransform Value;  // 0x30(0x60)

}; 
// Function ControlRig.RigHierarchy.SetNameMetadata
// Size: 0x20(Inherited: 0x0) 
struct FSetNameMetadata
{
	struct FRigElementKey InItem;  // 0x0(0xC)
	struct FName InMetadataName;  // 0xC(0x8)
	struct FName InValue;  // 0x14(0x8)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool ReturnValue : 1;  // 0x1C(0x1)
	char pad_29[3];  // 0x1D(0x3)

}; 
// Function ControlRig.RigHierarchy.GetRigElementKeyMetadata
// Size: 0x2C(Inherited: 0x0) 
struct FGetRigElementKeyMetadata
{
	struct FRigElementKey InItem;  // 0x0(0xC)
	struct FName InMetadataName;  // 0xC(0x8)
	struct FRigElementKey DefaultValue;  // 0x14(0xC)
	struct FRigElementKey ReturnValue;  // 0x20(0xC)

}; 
// ScriptStruct ControlRig.RigUnit_BinaryFloatOp
// Size: 0x18(Inherited: 0x8) 
struct FRigUnit_BinaryFloatOp : public FRigUnit
{
	float Argument0;  // 0x8(0x4)
	float Argument1;  // 0xC(0x4)
	float Result;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)

}; 
// ScriptStruct ControlRig.RigUnit_HasMetadata
// Size: 0x40(Inherited: 0x8) 
struct FRigUnit_HasMetadata : public FRigUnit
{
	struct FRigElementKey Item;  // 0x8(0xC)
	struct FName Name;  // 0x14(0x8)
	uint8_t  Type;  // 0x1C(0x1)
	char pad_29_1 : 7;  // 0x1D(0x1)
	bool Found : 1;  // 0x1D(0x1)
	char pad_30[2];  // 0x1E(0x2)
	struct FCachedRigElement CachedIndex;  // 0x20(0x20)

}; 
// ScriptStruct ControlRig.RigUnit_Add_FloatFloat
// Size: 0x18(Inherited: 0x18) 
struct FRigUnit_Add_FloatFloat : public FRigUnit_BinaryFloatOp
{

}; 
// ScriptStruct ControlRig.RigUnit_CollectionChainArray
// Size: 0x38(Inherited: 0x8) 
struct FRigUnit_CollectionChainArray : public FRigUnit_CollectionBase
{
	struct FRigElementKey FirstItem;  // 0x8(0xC)
	struct FRigElementKey LastItem;  // 0x14(0xC)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool Reverse : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct TArray<struct FRigElementKey> Items;  // 0x28(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_Subtract_FloatFloat
// Size: 0x18(Inherited: 0x18) 
struct FRigUnit_Subtract_FloatFloat : public FRigUnit_BinaryFloatOp
{

}; 
// Function ControlRig.RigHierarchy.SetLinearColorArrayMetadata
// Size: 0x30(Inherited: 0x0) 
struct FSetLinearColorArrayMetadata
{
	struct FRigElementKey InItem;  // 0x0(0xC)
	struct FName InMetadataName;  // 0xC(0x8)
	char pad_20[4];  // 0x14(0x4)
	struct TArray<struct FLinearColor> InValue;  // 0x18(0x10)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool ReturnValue : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)

}; 
// ScriptStruct ControlRig.RigUnit_Divide_FloatFloat
// Size: 0x18(Inherited: 0x18) 
struct FRigUnit_Divide_FloatFloat : public FRigUnit_BinaryFloatOp
{

}; 
// Function ControlRig.RigHierarchyController.AddNull
// Size: 0x90(Inherited: 0x0) 
struct FAddNull
{
	struct FName InName;  // 0x0(0x8)
	struct FRigElementKey InParent;  // 0x8(0xC)
	char pad_20[12];  // 0x14(0xC)
	struct FTransform InTransform;  // 0x20(0x60)
	char pad_128_1 : 7;  // 0x80(0x1)
	bool bTransformInGlobal : 1;  // 0x80(0x1)
	char pad_129_1 : 7;  // 0x81(0x1)
	bool bSetupUndo : 1;  // 0x81(0x1)
	char pad_130_1 : 7;  // 0x82(0x1)
	bool bPrintPythonCommand : 1;  // 0x82(0x1)
	char pad_131[1];  // 0x83(0x1)
	struct FRigElementKey ReturnValue;  // 0x84(0xC)

}; 
// ScriptStruct ControlRig.RigUnit_MapRange_Float
// Size: 0x20(Inherited: 0x8) 
struct FRigUnit_MapRange_Float : public FRigUnit
{
	float Value;  // 0x8(0x4)
	float MinIn;  // 0xC(0x4)
	float MaxIn;  // 0x10(0x4)
	float MinOut;  // 0x14(0x4)
	float MaxOut;  // 0x18(0x4)
	float Result;  // 0x1C(0x4)

}; 
// ScriptStruct ControlRig.RigUnit_BinaryQuaternionOp
// Size: 0x70(Inherited: 0x8) 
struct FRigUnit_BinaryQuaternionOp : public FRigUnit
{
	char pad_8[8];  // 0x8(0x8)
	struct FQuat Argument0;  // 0x10(0x20)
	struct FQuat Argument1;  // 0x30(0x20)
	struct FQuat Result;  // 0x50(0x20)

}; 
// ScriptStruct ControlRig.RigUnit_MathIntSign
// Size: 0x10(Inherited: 0x10) 
struct FRigUnit_MathIntSign : public FRigUnit_MathIntUnaryOp
{

}; 
// Function ControlRig.RigHierarchy.GetTransformArrayMetadata
// Size: 0x28(Inherited: 0x0) 
struct FGetTransformArrayMetadata
{
	struct FRigElementKey InItem;  // 0x0(0xC)
	struct FName InMetadataName;  // 0xC(0x8)
	char pad_20[4];  // 0x14(0x4)
	struct TArray<struct FTransform> ReturnValue;  // 0x18(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_SetMultiControlFloat
// Size: 0x68(Inherited: 0x40) 
struct FRigUnit_SetMultiControlFloat : public FRigUnitMutable
{
	struct TArray<struct FRigUnit_SetMultiControlFloat_Entry> Entries;  // 0x40(0x10)
	float Weight;  // 0x50(0x4)
	char pad_84[4];  // 0x54(0x4)
	struct TArray<struct FCachedRigElement> CachedControlIndices;  // 0x58(0x10)

}; 
// ScriptStruct ControlRig.MathRBFInterpolateVectorFloat_Target
// Size: 0x20(Inherited: 0x0) 
struct FMathRBFInterpolateVectorFloat_Target
{
	struct FVector Target;  // 0x0(0x18)
	float Value;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)

}; 
// ScriptStruct ControlRig.RigUnit_UnaryQuaternionOp
// Size: 0x50(Inherited: 0x8) 
struct FRigUnit_UnaryQuaternionOp : public FRigUnit
{
	char pad_8[8];  // 0x8(0x8)
	struct FQuat Argument;  // 0x10(0x20)
	struct FQuat Result;  // 0x30(0x20)

}; 
// ScriptStruct ControlRig.RigUnit_AccumulateFloatAdd
// Size: 0x20(Inherited: 0x8) 
struct FRigUnit_AccumulateFloatAdd : public FRigUnit_AccumulateBase
{
	float Increment;  // 0x8(0x4)
	float InitialValue;  // 0xC(0x4)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bIntegrateDeltaTime : 1;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)
	float Result;  // 0x14(0x4)
	float AccumulatedValue;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)

}; 
// ScriptStruct ControlRig.RigUnit_HierarchyAddControlFloat_LimitSettings
// Size: 0x10(Inherited: 0x0) 
struct FRigUnit_HierarchyAddControlFloat_LimitSettings
{
	struct FRigControlLimitEnabled Limit;  // 0x0(0x2)
	char pad_2[2];  // 0x2(0x2)
	float MinValue;  // 0x4(0x4)
	float MaxValue;  // 0x8(0x4)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool bDrawLimits : 1;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)

}; 
// ScriptStruct ControlRig.RigUnit_MathTransformFromEulerTransformV2
// Size: 0xB0(Inherited: 0x8) 
struct FRigUnit_MathTransformFromEulerTransformV2 : public FRigUnit_MathTransformBase
{
	struct FEulerTransform Value;  // 0x8(0x48)
	struct FTransform Result;  // 0x50(0x60)

}; 
// ScriptStruct ControlRig.RigUnit_InverseQuaterion
// Size: 0x50(Inherited: 0x50) 
struct FRigUnit_InverseQuaterion : public FRigUnit_UnaryQuaternionOp
{

}; 
// ScriptStruct ControlRig.RigUnit_QuaternionToAxisAndAngle
// Size: 0x50(Inherited: 0x8) 
struct FRigUnit_QuaternionToAxisAndAngle : public FRigUnit
{
	char pad_8[8];  // 0x8(0x8)
	struct FQuat Argument;  // 0x10(0x20)
	struct FVector Axis;  // 0x30(0x18)
	float Angle;  // 0x48(0x4)
	char pad_76[4];  // 0x4C(0x4)

}; 
// ScriptStruct ControlRig.RigUnit_QuaternionToAngle
// Size: 0x50(Inherited: 0x8) 
struct FRigUnit_QuaternionToAngle : public FRigUnit
{
	struct FVector Axis;  // 0x8(0x18)
	struct FQuat Argument;  // 0x20(0x20)
	float Angle;  // 0x40(0x4)
	char pad_68[12];  // 0x44(0xC)

}; 
// ScriptStruct ControlRig.RigUnit_SetMultiControlInteger
// Size: 0x68(Inherited: 0x40) 
struct FRigUnit_SetMultiControlInteger : public FRigUnitMutable
{
	struct TArray<struct FRigUnit_SetMultiControlInteger_Entry> Entries;  // 0x40(0x10)
	float Weight;  // 0x50(0x4)
	char pad_84[4];  // 0x54(0x4)
	struct TArray<struct FCachedRigElement> CachedControlIndices;  // 0x58(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_BinaryTransformOp
// Size: 0x130(Inherited: 0x8) 
struct FRigUnit_BinaryTransformOp : public FRigUnit
{
	char pad_8[8];  // 0x8(0x8)
	struct FTransform Argument0;  // 0x10(0x60)
	struct FTransform Argument1;  // 0x70(0x60)
	struct FTransform Result;  // 0xD0(0x60)

}; 
// ScriptStruct ControlRig.RigUnit_HierarchyGetParent
// Size: 0x60(Inherited: 0x8) 
struct FRigUnit_HierarchyGetParent : public FRigUnit_HierarchyBase
{
	struct FRigElementKey Child;  // 0x8(0xC)
	struct FRigElementKey Parent;  // 0x14(0xC)
	struct FCachedRigElement CachedChild;  // 0x20(0x20)
	struct FCachedRigElement CachedParent;  // 0x40(0x20)

}; 
// ScriptStruct ControlRig.RigUnit_ToWorldSpace_Location
// Size: 0x38(Inherited: 0x8) 
struct FRigUnit_ToWorldSpace_Location : public FRigUnit
{
	struct FVector Value;  // 0x8(0x18)
	struct FVector World;  // 0x20(0x18)

}; 
// ScriptStruct ControlRig.RigUnit_CollectionGetParentIndicesItemArray
// Size: 0x28(Inherited: 0x8) 
struct FRigUnit_CollectionGetParentIndicesItemArray : public FRigUnit_CollectionBase
{
	struct TArray<struct FRigElementKey> Items;  // 0x8(0x10)
	struct TArray<int32_t> ParentIndices;  // 0x18(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_MathDoublePow
// Size: 0x20(Inherited: 0x20) 
struct FRigUnit_MathDoublePow : public FRigUnit_MathDoubleBinaryOp
{

}; 
// ScriptStruct ControlRig.RigUnit_MultiplyTransform
// Size: 0x130(Inherited: 0x130) 
struct FRigUnit_MultiplyTransform : public FRigUnit_BinaryTransformOp
{

}; 
// Function ControlRig.RigHierarchy.GetRotatorArrayMetadata
// Size: 0x28(Inherited: 0x0) 
struct FGetRotatorArrayMetadata
{
	struct FRigElementKey InItem;  // 0x0(0xC)
	struct FName InMetadataName;  // 0xC(0x8)
	char pad_20[4];  // 0x14(0x4)
	struct TArray<struct FRotator> ReturnValue;  // 0x18(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_HierarchyAddAnimationChannelVector2D
// Size: 0x90(Inherited: 0x60) 
struct FRigUnit_HierarchyAddAnimationChannelVector2D : public FRigUnit_HierarchyAddElement
{
	struct FVector2D InitialValue;  // 0x60(0x10)
	struct FVector2D MinimumValue;  // 0x70(0x10)
	struct FVector2D MaximumValue;  // 0x80(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_MathFloatEquals
// Size: 0x18(Inherited: 0x8) 
struct FRigUnit_MathFloatEquals : public FRigUnit_MathFloatBase
{
	float A;  // 0x8(0x4)
	float B;  // 0xC(0x4)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool Result : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// ScriptStruct ControlRig.RigUnit_BoneHarmonics_BoneTarget
// Size: 0xC(Inherited: 0x0) 
struct FRigUnit_BoneHarmonics_BoneTarget
{
	struct FName bone;  // 0x0(0x8)
	float Ratio;  // 0x8(0x4)

}; 
// ScriptStruct ControlRig.RigUnit_GetRelativeTransform
// Size: 0x130(Inherited: 0x130) 
struct FRigUnit_GetRelativeTransform : public FRigUnit_BinaryTransformOp
{

}; 
// ScriptStruct ControlRig.RigUnit_SetBoneTransform
// Size: 0x140(Inherited: 0x40) 
struct FRigUnit_SetBoneTransform : public FRigUnitMutable
{
	struct FName bone;  // 0x40(0x8)
	char pad_72[8];  // 0x48(0x8)
	struct FTransform Transform;  // 0x50(0x60)
	struct FTransform Result;  // 0xB0(0x60)
	uint8_t  Space;  // 0x110(0x1)
	char pad_273[3];  // 0x111(0x3)
	float Weight;  // 0x114(0x4)
	char pad_280_1 : 7;  // 0x118(0x1)
	bool bPropagateToChildren : 1;  // 0x118(0x1)
	char pad_281[7];  // 0x119(0x7)
	struct FCachedRigElement CachedBone;  // 0x120(0x20)

}; 
// ScriptStruct ControlRig.RigUnit_MathDoubleMul
// Size: 0x20(Inherited: 0x20) 
struct FRigUnit_MathDoubleMul : public FRigUnit_MathDoubleBinaryAggregateOp
{

}; 
// ScriptStruct ControlRig.RigUnit_DrawContainerSetColor
// Size: 0x58(Inherited: 0x40) 
struct FRigUnit_DrawContainerSetColor : public FRigUnitMutable
{
	struct FName InstructionName;  // 0x40(0x8)
	struct FLinearColor Color;  // 0x48(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_Add_VectorVector
// Size: 0x50(Inherited: 0x50) 
struct FRigUnit_Add_VectorVector : public FRigUnit_BinaryVectorOp
{

}; 
// ScriptStruct ControlRig.RigUnit_Subtract_VectorVector
// Size: 0x50(Inherited: 0x50) 
struct FRigUnit_Subtract_VectorVector : public FRigUnit_BinaryVectorOp
{

}; 
// ScriptStruct ControlRig.RigUnit_GetFloatAnimationChannel
// Size: 0x38(Inherited: 0x30) 
struct FRigUnit_GetFloatAnimationChannel : public FRigUnit_GetAnimationChannelBase
{
	float Value;  // 0x30(0x4)
	char pad_52[4];  // 0x34(0x4)

}; 
// ScriptStruct ControlRig.AimTarget
// Size: 0x90(Inherited: 0x0) 
struct FAimTarget
{
	float Weight;  // 0x0(0x4)
	char pad_4[12];  // 0x4(0xC)
	struct FTransform Transform;  // 0x10(0x60)
	struct FVector AlignVector;  // 0x70(0x18)
	char pad_136[8];  // 0x88(0x8)

}; 
// ScriptStruct ControlRig.RigUnit_MultiFABRIK
// Size: 0xD0(Inherited: 0x40) 
struct FRigUnit_MultiFABRIK : public FRigUnit_HighlevelBaseMutable
{
	struct FName RootBone;  // 0x40(0x8)
	struct TArray<struct FRigUnit_MultiFABRIK_EndEffector> Effectors;  // 0x48(0x10)
	float Precision;  // 0x58(0x4)
	char pad_92_1 : 7;  // 0x5C(0x1)
	bool bPropagateToChildren : 1;  // 0x5C(0x1)
	char pad_93[3];  // 0x5D(0x3)
	int32_t MaxIterations;  // 0x60(0x4)
	char pad_100[4];  // 0x64(0x4)
	struct FRigUnit_MultiFABRIK_WorkData WorkData;  // 0x68(0x68)

}; 
// ScriptStruct ControlRig.RigUnit_MathDoubleSign
// Size: 0x18(Inherited: 0x18) 
struct FRigUnit_MathDoubleSign : public FRigUnit_MathDoubleUnaryOp
{

}; 
// ScriptStruct ControlRig.RigUnit_AimConstraint_WorkData
// Size: 0x10(Inherited: 0x0) 
struct FRigUnit_AimConstraint_WorkData
{
	struct TArray<struct FConstraintData> ConstraintData;  // 0x0(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_MathDistanceToPlane
// Size: 0x70(Inherited: 0x8) 
struct FRigUnit_MathDistanceToPlane : public FRigUnit_MathVectorBase
{
	struct FVector Point;  // 0x8(0x18)
	struct FVector PlanePoint;  // 0x20(0x18)
	struct FVector PlaneNormal;  // 0x38(0x18)
	struct FVector ClosestPointOnPlane;  // 0x50(0x18)
	float SignedDistance;  // 0x68(0x4)
	char pad_108[4];  // 0x6C(0x4)

}; 
// ScriptStruct ControlRig.RigUnit_ChainHarmonics_Pendulum
// Size: 0x58(Inherited: 0x0) 
struct FRigUnit_ChainHarmonics_Pendulum
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bEnabled : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	float PendulumStiffness;  // 0x4(0x4)
	struct FVector PendulumGravity;  // 0x8(0x18)
	float PendulumBlend;  // 0x20(0x4)
	float PendulumDrag;  // 0x24(0x4)
	float PendulumMinimum;  // 0x28(0x4)
	float PendulumMaximum;  // 0x2C(0x4)
	uint8_t  PendulumEase;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)
	struct FVector UnwindAxis;  // 0x38(0x18)
	float UnwindMinimum;  // 0x50(0x4)
	float UnwindMaximum;  // 0x54(0x4)

}; 
// ScriptStruct ControlRig.RigUnit_MathQuaternionBase
// Size: 0x8(Inherited: 0x8) 
struct FRigUnit_MathQuaternionBase : public FRigUnit_MathBase
{

}; 
// ScriptStruct ControlRig.RigUnit_AimConstraint
// Size: 0xB0(Inherited: 0x40) 
struct FRigUnit_AimConstraint : public FRigUnitMutable
{
	struct FName Joint;  // 0x40(0x8)
	uint8_t  AimMode;  // 0x48(0x1)
	uint8_t  UpMode;  // 0x49(0x1)
	char pad_74[6];  // 0x4A(0x6)
	struct FVector AimVector;  // 0x50(0x18)
	struct FVector UpVector;  // 0x68(0x18)
	struct TArray<struct FAimTarget> AimTargets;  // 0x80(0x10)
	struct TArray<struct FAimTarget> UpTargets;  // 0x90(0x10)
	struct FRigUnit_AimConstraint_WorkData WorkData;  // 0xA0(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_SetRelativeRotationForItem
// Size: 0xD0(Inherited: 0x40) 
struct FRigUnit_SetRelativeRotationForItem : public FRigUnitMutable
{
	struct FRigElementKey Child;  // 0x40(0xC)
	struct FRigElementKey Parent;  // 0x4C(0xC)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool bParentInitial : 1;  // 0x58(0x1)
	char pad_89[7];  // 0x59(0x7)
	struct FQuat Value;  // 0x60(0x20)
	float Weight;  // 0x80(0x4)
	char pad_132_1 : 7;  // 0x84(0x1)
	bool bPropagateToChildren : 1;  // 0x84(0x1)
	char pad_133[3];  // 0x85(0x3)
	struct FCachedRigElement CachedChild;  // 0x88(0x20)
	struct FCachedRigElement CachedParent;  // 0xA8(0x20)
	char pad_200[8];  // 0xC8(0x8)

}; 
// ScriptStruct ControlRig.RigUnit_CollectionReplaceItems
// Size: 0x40(Inherited: 0x8) 
struct FRigUnit_CollectionReplaceItems : public FRigUnit_CollectionBase
{
	struct FRigElementKeyCollection Items;  // 0x8(0x10)
	struct FName Old;  // 0x18(0x8)
	struct FName New;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool RemoveInvalidItems : 1;  // 0x28(0x1)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool bAllowDuplicates : 1;  // 0x29(0x1)
	char pad_42[6];  // 0x2A(0x6)
	struct FRigElementKeyCollection Collection;  // 0x30(0x10)

}; 
// ScriptStruct ControlRig.BlendTarget
// Size: 0x70(Inherited: 0x0) 
struct FBlendTarget
{
	struct FTransform Transform;  // 0x0(0x60)
	float Weight;  // 0x60(0x4)
	char pad_100[12];  // 0x64(0xC)

}; 
// ScriptStruct ControlRig.RigUnit_CollectionGetParentIndices
// Size: 0x28(Inherited: 0x8) 
struct FRigUnit_CollectionGetParentIndices : public FRigUnit_CollectionBase
{
	struct FRigElementKeyCollection Collection;  // 0x8(0x10)
	struct TArray<int32_t> ParentIndices;  // 0x18(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_BlendTransform
// Size: 0xE0(Inherited: 0x8) 
struct FRigUnit_BlendTransform : public FRigUnit
{
	char pad_8[8];  // 0x8(0x8)
	struct FTransform Source;  // 0x10(0x60)
	struct TArray<struct FBlendTarget> Targets;  // 0x70(0x10)
	struct FTransform Result;  // 0x80(0x60)

}; 
// ScriptStruct ControlRig.RigUnit_MathQuaternionSwingTwist
// Size: 0x90(Inherited: 0x8) 
struct FRigUnit_MathQuaternionSwingTwist : public FRigUnit_MathQuaternionBase
{
	char pad_8[8];  // 0x8(0x8)
	struct FQuat Input;  // 0x10(0x20)
	struct FVector TwistAxis;  // 0x30(0x18)
	char pad_72[8];  // 0x48(0x8)
	struct FQuat Swing;  // 0x50(0x20)
	struct FQuat Twist;  // 0x70(0x20)

}; 
// ScriptStruct ControlRig.RigUnit_GetJointTransform
// Size: 0x120(Inherited: 0x40) 
struct FRigUnit_GetJointTransform : public FRigUnitMutable
{
	struct FName Joint;  // 0x40(0x8)
	uint8_t  Type;  // 0x48(0x1)
	uint8_t  TransformSpace;  // 0x49(0x1)
	char pad_74[6];  // 0x4A(0x6)
	struct FTransform BaseTransform;  // 0x50(0x60)
	struct FName BaseJoint;  // 0xB0(0x8)
	char pad_184[8];  // 0xB8(0x8)
	struct FTransform Output;  // 0xC0(0x60)

}; 
// ScriptStruct ControlRig.RigUnit_DistributeRotationForItemArray
// Size: 0xB8(Inherited: 0x40) 
struct FRigUnit_DistributeRotationForItemArray : public FRigUnit_HighlevelBaseMutable
{
	struct TArray<struct FRigElementKey> Items;  // 0x40(0x10)
	struct TArray<struct FRigUnit_DistributeRotation_Rotation> Rotations;  // 0x50(0x10)
	uint8_t  RotationEaseType;  // 0x60(0x1)
	char pad_97[3];  // 0x61(0x3)
	float Weight;  // 0x64(0x4)
	struct FRigUnit_DistributeRotation_WorkData WorkData;  // 0x68(0x50)

}; 
// ScriptStruct ControlRig.RigUnit_TwoBoneIKFK
// Size: 0x350(Inherited: 0x40) 
struct FRigUnit_TwoBoneIKFK : public FRigUnitMutable
{
	struct FName StartJoint;  // 0x40(0x8)
	struct FName EndJoint;  // 0x48(0x8)
	struct FVector PoleTarget;  // 0x50(0x18)
	float Spin;  // 0x68(0x4)
	char pad_108[4];  // 0x6C(0x4)
	struct FTransform EndEffector;  // 0x70(0x60)
	float IKBlend;  // 0xD0(0x4)
	char pad_212[12];  // 0xD4(0xC)
	struct FTransform StartJointFKTransform;  // 0xE0(0x60)
	struct FTransform MidJointFKTransform;  // 0x140(0x60)
	struct FTransform EndJointFKTransform;  // 0x1A0(0x60)
	float PreviousFKIKBlend;  // 0x200(0x4)
	char pad_516[12];  // 0x204(0xC)
	struct FTransform StartJointIKTransform;  // 0x210(0x60)
	struct FTransform MidJointIKTransform;  // 0x270(0x60)
	struct FTransform EndJointIKTransform;  // 0x2D0(0x60)
	int32_t StartJointIndex;  // 0x330(0x4)
	int32_t MidJointIndex;  // 0x334(0x4)
	int32_t EndJointIndex;  // 0x338(0x4)
	float UpperLimbLength;  // 0x33C(0x4)
	float LowerLimbLength;  // 0x340(0x4)
	char pad_836[12];  // 0x344(0xC)

}; 
// ScriptStruct ControlRig.RigUnit_ToRigSpace_Location
// Size: 0x38(Inherited: 0x8) 
struct FRigUnit_ToRigSpace_Location : public FRigUnit
{
	struct FVector Value;  // 0x8(0x18)
	struct FVector Global;  // 0x20(0x18)

}; 
// ScriptStruct ControlRig.RigUnit_DrawContainerGetInstruction
// Size: 0x80(Inherited: 0x8) 
struct FRigUnit_DrawContainerGetInstruction : public FRigUnit
{
	struct FName InstructionName;  // 0x8(0x8)
	struct FLinearColor Color;  // 0x10(0x10)
	struct FTransform Transform;  // 0x20(0x60)

}; 
// ScriptStruct ControlRig.RigUnit_MathVectorParallel
// Size: 0x40(Inherited: 0x8) 
struct FRigUnit_MathVectorParallel : public FRigUnit_MathVectorBase
{
	struct FVector A;  // 0x8(0x18)
	struct FVector B;  // 0x20(0x18)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool Result : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)

}; 
// ScriptStruct ControlRig.RigUnit_BeginExecution
// Size: 0x40(Inherited: 0x8) 
struct FRigUnit_BeginExecution : public FRigUnit
{
	struct FControlRigExecuteContext ExecuteContext;  // 0x8(0x38)

}; 
// Function ControlRig.RigHierarchyController.AddBone
// Size: 0x90(Inherited: 0x0) 
struct FAddBone
{
	struct FName InName;  // 0x0(0x8)
	struct FRigElementKey InParent;  // 0x8(0xC)
	char pad_20[12];  // 0x14(0xC)
	struct FTransform InTransform;  // 0x20(0x60)
	char pad_128_1 : 7;  // 0x80(0x1)
	bool bTransformInGlobal : 1;  // 0x80(0x1)
	uint8_t  InBoneType;  // 0x81(0x1)
	char pad_130_1 : 7;  // 0x82(0x1)
	bool bSetupUndo : 1;  // 0x82(0x1)
	char pad_131_1 : 7;  // 0x83(0x1)
	bool bPrintPythonCommand : 1;  // 0x83(0x1)
	struct FRigElementKey ReturnValue;  // 0x84(0xC)

}; 
// ScriptStruct ControlRig.RigUnit_MathDoubleRemap
// Size: 0x40(Inherited: 0x8) 
struct FRigUnit_MathDoubleRemap : public FRigUnit_MathDoubleBase
{
	double Value;  // 0x8(0x8)
	double SourceMinimum;  // 0x10(0x8)
	double SourceMaximum;  // 0x18(0x8)
	double TargetMinimum;  // 0x20(0x8)
	double TargetMaximum;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool bClamp : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)
	double Result;  // 0x38(0x8)

}; 
// ScriptStruct ControlRig.RigUnit_CollectionBase
// Size: 0x8(Inherited: 0x8) 
struct FRigUnit_CollectionBase : public FRigUnit
{

}; 
// ScriptStruct ControlRig.RigUnit_MathVectorAngle
// Size: 0x40(Inherited: 0x8) 
struct FRigUnit_MathVectorAngle : public FRigUnit_MathVectorBase
{
	struct FVector A;  // 0x8(0x18)
	struct FVector B;  // 0x20(0x18)
	float Result;  // 0x38(0x4)
	char pad_60[4];  // 0x3C(0x4)

}; 
// ScriptStruct ControlRig.RigUnit_CollectionBaseMutable
// Size: 0x40(Inherited: 0x40) 
struct FRigUnit_CollectionBaseMutable : public FRigUnitMutable
{

}; 
// ScriptStruct ControlRig.RigUnit_CollectionNameSearchArray
// Size: 0x28(Inherited: 0x8) 
struct FRigUnit_CollectionNameSearchArray : public FRigUnit_CollectionBase
{
	struct FName PartialName;  // 0x8(0x8)
	uint8_t  TypeToSearch;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct TArray<struct FRigElementKey> Items;  // 0x18(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_ChainHarmonics_WorkData
// Size: 0x98(Inherited: 0x0) 
struct FRigUnit_ChainHarmonics_WorkData
{
	struct FVector time;  // 0x0(0x18)
	struct TArray<struct FCachedRigElement> Items;  // 0x18(0x10)
	struct TArray<float> Ratio;  // 0x28(0x10)
	struct TArray<struct FVector> LocalTip;  // 0x38(0x10)
	struct TArray<struct FVector> PendulumTip;  // 0x48(0x10)
	struct TArray<struct FVector> PendulumPosition;  // 0x58(0x10)
	struct TArray<struct FVector> PendulumVelocity;  // 0x68(0x10)
	struct TArray<struct FVector> HierarchyLine;  // 0x78(0x10)
	struct TArray<struct FVector> VelocityLines;  // 0x88(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_HierarchyRemoveElement
// Size: 0x50(Inherited: 0x40) 
struct FRigUnit_HierarchyRemoveElement : public FRigUnit_DynamicHierarchyBaseMutable
{
	struct FRigElementKey Item;  // 0x40(0xC)
	char pad_76_1 : 7;  // 0x4C(0x1)
	bool bSuccess : 1;  // 0x4C(0x1)
	char pad_77[3];  // 0x4D(0x3)

}; 
// ScriptStruct ControlRig.RigUnit_CollectionChildren
// Size: 0x28(Inherited: 0x8) 
struct FRigUnit_CollectionChildren : public FRigUnit_CollectionBase
{
	struct FRigElementKey Parent;  // 0x8(0xC)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool bIncludeParent : 1;  // 0x14(0x1)
	char pad_21_1 : 7;  // 0x15(0x1)
	bool bRecursive : 1;  // 0x15(0x1)
	uint8_t  TypeToSearch;  // 0x16(0x1)
	char pad_23[1];  // 0x17(0x1)
	struct FRigElementKeyCollection Collection;  // 0x18(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_CollectionChildrenArray
// Size: 0x28(Inherited: 0x8) 
struct FRigUnit_CollectionChildrenArray : public FRigUnit_CollectionBase
{
	struct FRigElementKey Parent;  // 0x8(0xC)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool bIncludeParent : 1;  // 0x14(0x1)
	char pad_21_1 : 7;  // 0x15(0x1)
	bool bRecursive : 1;  // 0x15(0x1)
	uint8_t  TypeToSearch;  // 0x16(0x1)
	char pad_23[1];  // 0x17(0x1)
	struct TArray<struct FRigElementKey> Items;  // 0x18(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_AimBone_Target
// Size: 0x48(Inherited: 0x0) 
struct FRigUnit_AimBone_Target
{
	float Weight;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FVector Axis;  // 0x8(0x18)
	struct FVector Target;  // 0x20(0x18)
	uint8_t  Kind;  // 0x38(0x1)
	char pad_57[3];  // 0x39(0x3)
	struct FName Space;  // 0x3C(0x8)
	char pad_68[4];  // 0x44(0x4)

}; 
// ScriptStruct ControlRig.RigUnit_CollectionAddItem
// Size: 0x38(Inherited: 0x8) 
struct FRigUnit_CollectionAddItem : public FRigUnit_CollectionBase
{
	struct FRigElementKeyCollection Collection;  // 0x8(0x10)
	struct FRigElementKey Item;  // 0x18(0xC)
	char pad_36[4];  // 0x24(0x4)
	struct FRigElementKeyCollection Result;  // 0x28(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_CollectionItems
// Size: 0x30(Inherited: 0x8) 
struct FRigUnit_CollectionItems : public FRigUnit_CollectionBase
{
	struct TArray<struct FRigElementKey> Items;  // 0x8(0x10)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool bAllowDuplicates : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct FRigElementKeyCollection Collection;  // 0x20(0x10)

}; 
// Function ControlRig.RigHierarchy.SetBoolArrayMetadata
// Size: 0x30(Inherited: 0x0) 
struct FSetBoolArrayMetadata
{
	struct FRigElementKey InItem;  // 0x0(0xC)
	struct FName InMetadataName;  // 0xC(0x8)
	char pad_20[4];  // 0x14(0x4)
	struct TArray<bool> InValue;  // 0x18(0x10)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool ReturnValue : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)

}; 
// ScriptStruct ControlRig.RigUnit_MathDoubleUnaryOp
// Size: 0x18(Inherited: 0x8) 
struct FRigUnit_MathDoubleUnaryOp : public FRigUnit_MathDoubleBase
{
	double Value;  // 0x8(0x8)
	double Result;  // 0x10(0x8)

}; 
// ScriptStruct ControlRig.RigUnit_CollectionGetItems
// Size: 0x28(Inherited: 0x8) 
struct FRigUnit_CollectionGetItems : public FRigUnit_CollectionBase
{
	struct FRigElementKeyCollection Collection;  // 0x8(0x10)
	struct TArray<struct FRigElementKey> Items;  // 0x18(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_AimBone_DebugSettings
// Size: 0x70(Inherited: 0x0) 
struct FRigUnit_AimBone_DebugSettings
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bEnabled : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	float Scale;  // 0x4(0x4)
	char pad_8[8];  // 0x8(0x8)
	struct FTransform WorldOffset;  // 0x10(0x60)

}; 
// ScriptStruct ControlRig.RigUnit_CollectionIntersection
// Size: 0x38(Inherited: 0x8) 
struct FRigUnit_CollectionIntersection : public FRigUnit_CollectionBase
{
	struct FRigElementKeyCollection A;  // 0x8(0x10)
	struct FRigElementKeyCollection B;  // 0x18(0x10)
	struct FRigElementKeyCollection Collection;  // 0x28(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_MathIntPow
// Size: 0x18(Inherited: 0x18) 
struct FRigUnit_MathIntPow : public FRigUnit_MathIntBinaryOp
{

}; 
// Function ControlRig.RigHierarchy.GetLinearColorMetadata
// Size: 0x34(Inherited: 0x0) 
struct FGetLinearColorMetadata
{
	struct FRigElementKey InItem;  // 0x0(0xC)
	struct FName InMetadataName;  // 0xC(0x8)
	struct FLinearColor DefaultValue;  // 0x14(0x10)
	struct FLinearColor ReturnValue;  // 0x24(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_CollectionDifference
// Size: 0x38(Inherited: 0x8) 
struct FRigUnit_CollectionDifference : public FRigUnit_CollectionBase
{
	struct FRigElementKeyCollection A;  // 0x8(0x10)
	struct FRigElementKeyCollection B;  // 0x18(0x10)
	struct FRigElementKeyCollection Collection;  // 0x28(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_CollectionReverse
// Size: 0x28(Inherited: 0x8) 
struct FRigUnit_CollectionReverse : public FRigUnit_CollectionBase
{
	struct FRigElementKeyCollection Collection;  // 0x8(0x10)
	struct FRigElementKeyCollection Reversed;  // 0x18(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_CollectionCount
// Size: 0x20(Inherited: 0x8) 
struct FRigUnit_CollectionCount : public FRigUnit_CollectionBase
{
	struct FRigElementKeyCollection Collection;  // 0x8(0x10)
	int32_t Count;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)

}; 
// ScriptStruct ControlRig.RigUnit_SetControlVisibility
// Size: 0x78(Inherited: 0x40) 
struct FRigUnit_SetControlVisibility : public FRigUnitMutable
{
	struct FRigElementKey Item;  // 0x40(0xC)
	char pad_76[4];  // 0x4C(0x4)
	struct FString Pattern;  // 0x50(0x10)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool bVisible : 1;  // 0x60(0x1)
	char pad_97[7];  // 0x61(0x7)
	struct TArray<struct FCachedRigElement> CachedControlIndices;  // 0x68(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_DynamicHierarchyBaseMutable
// Size: 0x40(Inherited: 0x40) 
struct FRigUnit_DynamicHierarchyBaseMutable : public FRigUnitMutable
{

}; 
// ScriptStruct ControlRig.RigUnit_SetSpaceInitialTransform
// Size: 0x140(Inherited: 0x40) 
struct FRigUnit_SetSpaceInitialTransform : public FRigUnitMutable
{
	struct FName SpaceName;  // 0x40(0x8)
	char pad_72[8];  // 0x48(0x8)
	struct FTransform Transform;  // 0x50(0x60)
	struct FTransform Result;  // 0xB0(0x60)
	uint8_t  Space;  // 0x110(0x1)
	char pad_273[7];  // 0x111(0x7)
	struct FCachedRigElement CachedSpaceIndex;  // 0x118(0x20)
	char pad_312[8];  // 0x138(0x8)

}; 
// ScriptStruct ControlRig.RigUnit_SwitchParent
// Size: 0x60(Inherited: 0x40) 
struct FRigUnit_SwitchParent : public FRigUnit_DynamicHierarchyBaseMutable
{
	uint8_t  Mode;  // 0x40(0x1)
	char pad_65[3];  // 0x41(0x3)
	struct FRigElementKey Child;  // 0x44(0xC)
	struct FRigElementKey Parent;  // 0x50(0xC)
	char pad_92_1 : 7;  // 0x5C(0x1)
	bool bMaintainGlobal : 1;  // 0x5C(0x1)
	char pad_93[3];  // 0x5D(0x3)

}; 
// ScriptStruct ControlRig.RigUnit_Harmonics_TargetItem
// Size: 0x10(Inherited: 0x0) 
struct FRigUnit_Harmonics_TargetItem
{
	struct FRigElementKey Item;  // 0x0(0xC)
	float Ratio;  // 0xC(0x4)

}; 
// ScriptStruct ControlRig.RigUnit_HierarchyReset
// Size: 0x40(Inherited: 0x40) 
struct FRigUnit_HierarchyReset : public FRigUnit_DynamicHierarchyBaseMutable
{

}; 
// ScriptStruct ControlRig.RigUnit_MathTransformMakeRelative
// Size: 0x130(Inherited: 0x8) 
struct FRigUnit_MathTransformMakeRelative : public FRigUnit_MathTransformBase
{
	char pad_8[8];  // 0x8(0x8)
	struct FTransform Global;  // 0x10(0x60)
	struct FTransform Parent;  // 0x70(0x60)
	struct FTransform Local;  // 0xD0(0x60)

}; 
// ScriptStruct ControlRig.RigUnit_HierarchyAddElement
// Size: 0x60(Inherited: 0x40) 
struct FRigUnit_HierarchyAddElement : public FRigUnit_DynamicHierarchyBaseMutable
{
	struct FRigElementKey Parent;  // 0x40(0xC)
	struct FName Name;  // 0x4C(0x8)
	struct FRigElementKey Item;  // 0x54(0xC)

}; 
// ScriptStruct ControlRig.RigUnit_HierarchyAddBone
// Size: 0xD0(Inherited: 0x60) 
struct FRigUnit_HierarchyAddBone : public FRigUnit_HierarchyAddElement
{
	struct FTransform Transform;  // 0x60(0x60)
	uint8_t  Space;  // 0xC0(0x1)
	char pad_193[15];  // 0xC1(0xF)

}; 
// ScriptStruct ControlRig.RigUnit_CCDIK
// Size: 0x140(Inherited: 0x40) 
struct FRigUnit_CCDIK : public FRigUnit_HighlevelBaseMutable
{
	struct FName StartBone;  // 0x40(0x8)
	struct FName EffectorBone;  // 0x48(0x8)
	struct FTransform EffectorTransform;  // 0x50(0x60)
	float Precision;  // 0xB0(0x4)
	float Weight;  // 0xB4(0x4)
	int32_t MaxIterations;  // 0xB8(0x4)
	char pad_188_1 : 7;  // 0xBC(0x1)
	bool bStartFromTail : 1;  // 0xBC(0x1)
	char pad_189[3];  // 0xBD(0x3)
	float BaseRotationLimit;  // 0xC0(0x4)
	char pad_196[4];  // 0xC4(0x4)
	struct TArray<struct FRigUnit_CCDIK_RotationLimit> RotationLimits;  // 0xC8(0x10)
	char pad_216_1 : 7;  // 0xD8(0x1)
	bool bPropagateToChildren : 1;  // 0xD8(0x1)
	char pad_217[7];  // 0xD9(0x7)
	struct FRigUnit_CCDIK_WorkData WorkData;  // 0xE0(0x60)

}; 
// ScriptStruct ControlRig.RigUnit_MathMatrixBinaryOp
// Size: 0x190(Inherited: 0x8) 
struct FRigUnit_MathMatrixBinaryOp : public FRigUnit_MathMatrixBase
{
	char pad_8[8];  // 0x8(0x8)
	struct FMatrix A;  // 0x10(0x80)
	struct FMatrix B;  // 0x90(0x80)
	struct FMatrix Result;  // 0x110(0x80)

}; 
// ScriptStruct ControlRig.RigUnit_HierarchyAddControl_Settings
// Size: 0x10(Inherited: 0x0) 
struct FRigUnit_HierarchyAddControl_Settings
{
	char pad_0[8];  // 0x0(0x8)
	struct FName DisplayName;  // 0x8(0x8)

}; 
// ScriptStruct ControlRig.RigUnit_HierarchyAddControl_ShapeSettings
// Size: 0x80(Inherited: 0x0) 
struct FRigUnit_HierarchyAddControl_ShapeSettings
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bVisible : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	struct FName Name;  // 0x4(0x8)
	struct FLinearColor Color;  // 0xC(0x10)
	char pad_28[4];  // 0x1C(0x4)
	struct FTransform Transform;  // 0x20(0x60)

}; 
// ScriptStruct ControlRig.RigUnit_MathDoubleConstPi
// Size: 0x10(Inherited: 0x10) 
struct FRigUnit_MathDoubleConstPi : public FRigUnit_MathDoubleConstant
{

}; 
// ScriptStruct ControlRig.RigUnit_HierarchyAddControlFloat_Settings
// Size: 0xD0(Inherited: 0x10) 
struct FRigUnit_HierarchyAddControlFloat_Settings : public FRigUnit_HierarchyAddControl_Settings
{
	uint8_t  PrimaryAxis;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)
	struct FRigUnit_HierarchyAddControlFloat_LimitSettings Limits;  // 0x14(0x10)
	char pad_36[12];  // 0x24(0xC)
	struct FRigUnit_HierarchyAddControl_ShapeSettings Shape;  // 0x30(0x80)
	struct FRigUnit_HierarchyAddControl_ProxySettings Proxy;  // 0xB0(0x20)

}; 
// ScriptStruct ControlRig.RigUnit_HierarchyAddControlFloat
// Size: 0x1A0(Inherited: 0x60) 
struct FRigUnit_HierarchyAddControlFloat : public FRigUnit_HierarchyAddElement
{
	struct FTransform OffsetTransform;  // 0x60(0x60)
	float InitialValue;  // 0xC0(0x4)
	char pad_196[12];  // 0xC4(0xC)
	struct FRigUnit_HierarchyAddControlFloat_Settings Settings;  // 0xD0(0xD0)

}; 
// ScriptStruct ControlRig.RigUnit_MathBoolConstant
// Size: 0x10(Inherited: 0x8) 
struct FRigUnit_MathBoolConstant : public FRigUnit_MathBoolBase
{
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Value : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function ControlRig.ControlRigShapeActor.IsEnabled
// Size: 0x1(Inherited: 0x0) 
struct FIsEnabled
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// ScriptStruct ControlRig.RigUnit_HierarchyAddControlInteger_LimitSettings
// Size: 0x10(Inherited: 0x0) 
struct FRigUnit_HierarchyAddControlInteger_LimitSettings
{
	struct FRigControlLimitEnabled Limit;  // 0x0(0x2)
	char pad_2[2];  // 0x2(0x2)
	int32_t MinValue;  // 0x4(0x4)
	int32_t MaxValue;  // 0x8(0x4)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool bDrawLimits : 1;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)

}; 
// Function ControlRig.RigHierarchyController.RemoveElement
// Size: 0x10(Inherited: 0x0) 
struct FRemoveElement
{
	struct FRigElementKey InElement;  // 0x0(0xC)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool bSetupUndo : 1;  // 0xC(0x1)
	char pad_13_1 : 7;  // 0xD(0x1)
	bool bPrintPythonCommand : 1;  // 0xD(0x1)
	char pad_14_1 : 7;  // 0xE(0x1)
	bool ReturnValue : 1;  // 0xE(0x1)
	char pad_15[1];  // 0xF(0x1)

}; 
// ScriptStruct ControlRig.RigUnit_HierarchyAddControlVector2D_LimitSettings
// Size: 0x30(Inherited: 0x0) 
struct FRigUnit_HierarchyAddControlVector2D_LimitSettings
{
	struct FRigControlLimitEnabled LimitX;  // 0x0(0x2)
	struct FRigControlLimitEnabled LimitY;  // 0x2(0x2)
	char pad_4[4];  // 0x4(0x4)
	struct FVector2D MinValue;  // 0x8(0x10)
	struct FVector2D MaxValue;  // 0x18(0x10)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool bDrawLimits : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)

}; 
// ScriptStruct ControlRig.RigUnit_PositionConstraintLocalSpaceOffset
// Size: 0x98(Inherited: 0x40) 
struct FRigUnit_PositionConstraintLocalSpaceOffset : public FRigUnit_HighlevelBaseMutable
{
	struct FRigElementKey Child;  // 0x40(0xC)
	char pad_76_1 : 7;  // 0x4C(0x1)
	bool bMaintainOffset : 1;  // 0x4C(0x1)
	struct FFilterOptionPerAxis Filter;  // 0x4D(0x3)
	struct TArray<struct FConstraintParent> Parents;  // 0x50(0x10)
	float Weight;  // 0x60(0x4)
	char pad_100[4];  // 0x64(0x4)
	struct FCachedRigElement ChildCache;  // 0x68(0x20)
	struct TArray<struct FCachedRigElement> ParentCaches;  // 0x88(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_HierarchyAddControlVector2D_Settings
// Size: 0xF0(Inherited: 0x10) 
struct FRigUnit_HierarchyAddControlVector2D_Settings : public FRigUnit_HierarchyAddControl_Settings
{
	uint8_t  PrimaryAxis;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct FRigUnit_HierarchyAddControlVector2D_LimitSettings Limits;  // 0x18(0x30)
	char pad_72[8];  // 0x48(0x8)
	struct FRigUnit_HierarchyAddControl_ShapeSettings Shape;  // 0x50(0x80)
	struct FRigUnit_HierarchyAddControl_ProxySettings Proxy;  // 0xD0(0x20)

}; 
// Function ControlRig.RigHierarchy.GetNumberOfParents
// Size: 0x10(Inherited: 0x0) 
struct FGetNumberOfParents
{
	struct FRigElementKey InKey;  // 0x0(0xC)
	int32_t ReturnValue;  // 0xC(0x4)

}; 
// ScriptStruct ControlRig.RigUnit_HierarchyAddControlVector2D
// Size: 0x1C0(Inherited: 0x60) 
struct FRigUnit_HierarchyAddControlVector2D : public FRigUnit_HierarchyAddElement
{
	struct FTransform OffsetTransform;  // 0x60(0x60)
	struct FVector2D InitialValue;  // 0xC0(0x10)
	struct FRigUnit_HierarchyAddControlVector2D_Settings Settings;  // 0xD0(0xF0)

}; 
// Function ControlRig.RigHierarchy.GetRotatorMetadata
// Size: 0x48(Inherited: 0x0) 
struct FGetRotatorMetadata
{
	struct FRigElementKey InItem;  // 0x0(0xC)
	struct FName InMetadataName;  // 0xC(0x8)
	char pad_20[4];  // 0x14(0x4)
	struct FRotator DefaultValue;  // 0x18(0x18)
	struct FRotator ReturnValue;  // 0x30(0x18)

}; 
// ScriptStruct ControlRig.RigUnit_HierarchyAddControlVector_LimitSettings
// Size: 0x40(Inherited: 0x0) 
struct FRigUnit_HierarchyAddControlVector_LimitSettings
{
	struct FRigControlLimitEnabled LimitX;  // 0x0(0x2)
	struct FRigControlLimitEnabled LimitY;  // 0x2(0x2)
	struct FRigControlLimitEnabled LimitZ;  // 0x4(0x2)
	char pad_6[2];  // 0x6(0x2)
	struct FVector MinValue;  // 0x8(0x18)
	struct FVector MaxValue;  // 0x20(0x18)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool bDrawLimits : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)

}; 
// ScriptStruct ControlRig.RigUnit_HierarchyAddControlVector_Settings
// Size: 0x100(Inherited: 0x10) 
struct FRigUnit_HierarchyAddControlVector_Settings : public FRigUnit_HierarchyAddControl_Settings
{
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bIsPosition : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct FRigUnit_HierarchyAddControlVector_LimitSettings Limits;  // 0x18(0x40)
	char pad_88[8];  // 0x58(0x8)
	struct FRigUnit_HierarchyAddControl_ShapeSettings Shape;  // 0x60(0x80)
	struct FRigUnit_HierarchyAddControl_ProxySettings Proxy;  // 0xE0(0x20)

}; 
// ScriptStruct ControlRig.RigUnit_HierarchyAddControlVector
// Size: 0x1E0(Inherited: 0x60) 
struct FRigUnit_HierarchyAddControlVector : public FRigUnit_HierarchyAddElement
{
	struct FTransform OffsetTransform;  // 0x60(0x60)
	struct FVector InitialValue;  // 0xC0(0x18)
	char pad_216[8];  // 0xD8(0x8)
	struct FRigUnit_HierarchyAddControlVector_Settings Settings;  // 0xE0(0x100)

}; 
// ScriptStruct ControlRig.RigUnit_NoiseDouble
// Size: 0x40(Inherited: 0x8) 
struct FRigUnit_NoiseDouble : public FRigUnit_MathBase
{
	double Value;  // 0x8(0x8)
	double Speed;  // 0x10(0x8)
	double Frequency;  // 0x18(0x8)
	double Minimum;  // 0x20(0x8)
	double Maximum;  // 0x28(0x8)
	double Result;  // 0x30(0x8)
	double time;  // 0x38(0x8)

}; 
// ScriptStruct ControlRig.RigUnit_ToWorldSpace_Rotation
// Size: 0x50(Inherited: 0x8) 
struct FRigUnit_ToWorldSpace_Rotation : public FRigUnit
{
	char pad_8[8];  // 0x8(0x8)
	struct FQuat Value;  // 0x10(0x20)
	struct FQuat World;  // 0x30(0x20)

}; 
// ScriptStruct ControlRig.RigUnit_MathFloatSelectBool
// Size: 0x18(Inherited: 0x8) 
struct FRigUnit_MathFloatSelectBool : public FRigUnit_MathFloatBase
{
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Condition : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	float IfTrue;  // 0xC(0x4)
	float IfFalse;  // 0x10(0x4)
	float Result;  // 0x14(0x4)

}; 
// Function ControlRig.RigHierarchy.SwitchToDefaultParent
// Size: 0x10(Inherited: 0x0) 
struct FSwitchToDefaultParent
{
	struct FRigElementKey InChild;  // 0x0(0xC)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool bInitial : 1;  // 0xC(0x1)
	char pad_13_1 : 7;  // 0xD(0x1)
	bool bAffectChildren : 1;  // 0xD(0x1)
	char pad_14_1 : 7;  // 0xE(0x1)
	bool ReturnValue : 1;  // 0xE(0x1)
	char pad_15[1];  // 0xF(0x1)

}; 
// ScriptStruct ControlRig.RigUnit_MathTransformSelectBool
// Size: 0x130(Inherited: 0x8) 
struct FRigUnit_MathTransformSelectBool : public FRigUnit_MathTransformBase
{
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Condition : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct FTransform IfTrue;  // 0x10(0x60)
	struct FTransform IfFalse;  // 0x70(0x60)
	struct FTransform Result;  // 0xD0(0x60)

}; 
// ScriptStruct ControlRig.RigUnit_HierarchyAddControlRotator_Settings
// Size: 0xF0(Inherited: 0x10) 
struct FRigUnit_HierarchyAddControlRotator_Settings : public FRigUnit_HierarchyAddControl_Settings
{
	struct FRigUnit_HierarchyAddControlRotator_LimitSettings Limits;  // 0x10(0x40)
	struct FRigUnit_HierarchyAddControl_ShapeSettings Shape;  // 0x50(0x80)
	struct FRigUnit_HierarchyAddControl_ProxySettings Proxy;  // 0xD0(0x20)

}; 
// ScriptStruct ControlRig.RigUnit_HierarchyAddControlRotator
// Size: 0x1D0(Inherited: 0x60) 
struct FRigUnit_HierarchyAddControlRotator : public FRigUnit_HierarchyAddElement
{
	struct FTransform OffsetTransform;  // 0x60(0x60)
	struct FRotator InitialValue;  // 0xC0(0x18)
	char pad_216[8];  // 0xD8(0x8)
	struct FRigUnit_HierarchyAddControlRotator_Settings Settings;  // 0xE0(0xF0)

}; 
// Function ControlRig.ControlRigShapeActor.IsHovered
// Size: 0x1(Inherited: 0x0) 
struct FIsHovered
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function ControlRig.RigHierarchy.IsSelected
// Size: 0x10(Inherited: 0x0) 
struct FIsSelected
{
	struct FRigElementKey InKey;  // 0x0(0xC)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool ReturnValue : 1;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)

}; 
// ScriptStruct ControlRig.RigUnit_GetControlTransform
// Size: 0x160(Inherited: 0x8) 
struct FRigUnit_GetControlTransform : public FRigUnit
{
	struct FName Control;  // 0x8(0x8)
	uint8_t  Space;  // 0x10(0x1)
	char pad_17[15];  // 0x11(0xF)
	struct FTransform Transform;  // 0x20(0x60)
	struct FTransform Minimum;  // 0x80(0x60)
	struct FTransform Maximum;  // 0xE0(0x60)
	struct FCachedRigElement CachedControlIndex;  // 0x140(0x20)

}; 
// ScriptStruct ControlRig.RigUnit_HierarchyAddControlTransform_Settings
// Size: 0xB0(Inherited: 0x10) 
struct FRigUnit_HierarchyAddControlTransform_Settings : public FRigUnit_HierarchyAddControl_Settings
{
	struct FRigUnit_HierarchyAddControl_ShapeSettings Shape;  // 0x10(0x80)
	struct FRigUnit_HierarchyAddControl_ProxySettings Proxy;  // 0x90(0x20)

}; 
// ScriptStruct ControlRig.RigUnit_HierarchyAddAnimationChannelFloat
// Size: 0x70(Inherited: 0x60) 
struct FRigUnit_HierarchyAddAnimationChannelFloat : public FRigUnit_HierarchyAddElement
{
	float InitialValue;  // 0x60(0x4)
	float MinimumValue;  // 0x64(0x4)
	float MaximumValue;  // 0x68(0x4)
	char pad_108[4];  // 0x6C(0x4)

}; 
// ScriptStruct ControlRig.RigUnit_SetSpaceTransform
// Size: 0xE0(Inherited: 0x40) 
struct FRigUnit_SetSpaceTransform : public FRigUnitMutable
{
	struct FName Space;  // 0x40(0x8)
	float Weight;  // 0x48(0x4)
	char pad_76[4];  // 0x4C(0x4)
	struct FTransform Transform;  // 0x50(0x60)
	uint8_t  SpaceType;  // 0xB0(0x1)
	char pad_177[7];  // 0xB1(0x7)
	struct FCachedRigElement CachedSpaceIndex;  // 0xB8(0x20)
	char pad_216[8];  // 0xD8(0x8)

}; 
// Function ControlRig.RigHierarchy.SortKeys
// Size: 0x20(Inherited: 0x0) 
struct FSortKeys
{
	struct TArray<struct FRigElementKey> InKeys;  // 0x0(0x10)
	struct TArray<struct FRigElementKey> ReturnValue;  // 0x10(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_HierarchyAddAnimationChannelInteger
// Size: 0x70(Inherited: 0x60) 
struct FRigUnit_HierarchyAddAnimationChannelInteger : public FRigUnit_HierarchyAddElement
{
	int32_t InitialValue;  // 0x60(0x4)
	int32_t MinimumValue;  // 0x64(0x4)
	int32_t MaximumValue;  // 0x68(0x4)
	char pad_108[4];  // 0x6C(0x4)

}; 
// ScriptStruct ControlRig.RigUnit_HierarchyAddAnimationChannelVector
// Size: 0xA8(Inherited: 0x60) 
struct FRigUnit_HierarchyAddAnimationChannelVector : public FRigUnit_HierarchyAddElement
{
	struct FVector InitialValue;  // 0x60(0x18)
	struct FVector MinimumValue;  // 0x78(0x18)
	struct FVector MaximumValue;  // 0x90(0x18)

}; 
// ScriptStruct ControlRig.RigUnit_HierarchyAddAnimationChannelRotator
// Size: 0xA8(Inherited: 0x60) 
struct FRigUnit_HierarchyAddAnimationChannelRotator : public FRigUnit_HierarchyAddElement
{
	struct FRotator InitialValue;  // 0x60(0x18)
	struct FRotator MinimumValue;  // 0x78(0x18)
	struct FRotator MaximumValue;  // 0x90(0x18)

}; 
// Function ControlRig.RigHierarchy.GetTransformNoScaleFromControlValue
// Size: 0x130(Inherited: 0x0) 
struct FGetTransformNoScaleFromControlValue
{
	struct FRigControlValue InValue;  // 0x0(0xF0)
	struct FTransformNoScale ReturnValue;  // 0xF0(0x40)

}; 
// Function ControlRig.ControlRigWorkflowOptions.EnsureAtLeastOneRigElementSelected
// Size: 0x1(Inherited: 0x0) 
struct FEnsureAtLeastOneRigElementSelected
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// ScriptStruct ControlRig.RigUnit_MathIntNegate
// Size: 0x10(Inherited: 0x10) 
struct FRigUnit_MathIntNegate : public FRigUnit_MathIntUnaryOp
{

}; 
// ScriptStruct ControlRig.RigUnit_ForLoopCount
// Size: 0x88(Inherited: 0x40) 
struct FRigUnit_ForLoopCount : public FRigUnitMutable
{
	int32_t Count;  // 0x40(0x4)
	int32_t Index;  // 0x44(0x4)
	float Ratio;  // 0x48(0x4)
	char pad_76_1 : 7;  // 0x4C(0x1)
	bool Continue : 1;  // 0x4C(0x1)
	char pad_77[3];  // 0x4D(0x3)
	struct FControlRigExecuteContext Completed;  // 0x50(0x38)

}; 
// ScriptStruct ControlRig.RigUnit_GetMetadataTags
// Size: 0x48(Inherited: 0x8) 
struct FRigUnit_GetMetadataTags : public FRigUnit
{
	struct FRigElementKey Item;  // 0x8(0xC)
	char pad_20[4];  // 0x14(0x4)
	struct TArray<struct FName> Tags;  // 0x18(0x10)
	struct FCachedRigElement CachedIndex;  // 0x28(0x20)

}; 
// ScriptStruct ControlRig.RigUnit_HierarchyBaseMutable
// Size: 0x40(Inherited: 0x40) 
struct FRigUnit_HierarchyBaseMutable : public FRigUnitMutable
{

}; 
// ScriptStruct ControlRig.RigUnit_HierarchyGetParents
// Size: 0x58(Inherited: 0x8) 
struct FRigUnit_HierarchyGetParents : public FRigUnit_HierarchyBase
{
	struct FRigElementKey Child;  // 0x8(0xC)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool bIncludeChild : 1;  // 0x14(0x1)
	char pad_21_1 : 7;  // 0x15(0x1)
	bool bReverse : 1;  // 0x15(0x1)
	char pad_22[2];  // 0x16(0x2)
	struct FRigElementKeyCollection Parents;  // 0x18(0x10)
	struct FCachedRigElement CachedChild;  // 0x28(0x20)
	struct FRigElementKeyCollection CachedParents;  // 0x48(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_MathQuaternionMakeAbsolute
// Size: 0x70(Inherited: 0x8) 
struct FRigUnit_MathQuaternionMakeAbsolute : public FRigUnit_MathQuaternionBase
{
	char pad_8[8];  // 0x8(0x8)
	struct FQuat Local;  // 0x10(0x20)
	struct FQuat Parent;  // 0x30(0x20)
	struct FQuat Global;  // 0x50(0x20)

}; 
// ScriptStruct ControlRig.RigUnit_HierarchyGetParentsItemArray
// Size: 0x58(Inherited: 0x8) 
struct FRigUnit_HierarchyGetParentsItemArray : public FRigUnit_HierarchyBase
{
	struct FRigElementKey Child;  // 0x8(0xC)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool bIncludeChild : 1;  // 0x14(0x1)
	char pad_21_1 : 7;  // 0x15(0x1)
	bool bReverse : 1;  // 0x15(0x1)
	char pad_22[2];  // 0x16(0x2)
	struct TArray<struct FRigElementKey> Parents;  // 0x18(0x10)
	struct FCachedRigElement CachedChild;  // 0x28(0x20)
	struct FRigElementKeyCollection CachedParents;  // 0x48(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_HierarchyGetSiblings
// Size: 0x58(Inherited: 0x8) 
struct FRigUnit_HierarchyGetSiblings : public FRigUnit_HierarchyBase
{
	struct FRigElementKey Item;  // 0x8(0xC)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool bIncludeItem : 1;  // 0x14(0x1)
	char pad_21[3];  // 0x15(0x3)
	struct FRigElementKeyCollection Siblings;  // 0x18(0x10)
	struct FCachedRigElement CachedItem;  // 0x28(0x20)
	struct FRigElementKeyCollection CachedSiblings;  // 0x48(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_MathFloatLess
// Size: 0x18(Inherited: 0x8) 
struct FRigUnit_MathFloatLess : public FRigUnit_MathFloatBase
{
	float A;  // 0x8(0x4)
	float B;  // 0xC(0x4)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool Result : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// ScriptStruct ControlRig.RigUnit_HierarchyGetSiblingsItemArray
// Size: 0x58(Inherited: 0x8) 
struct FRigUnit_HierarchyGetSiblingsItemArray : public FRigUnit_HierarchyBase
{
	struct FRigElementKey Item;  // 0x8(0xC)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool bIncludeItem : 1;  // 0x14(0x1)
	char pad_21[3];  // 0x15(0x3)
	struct TArray<struct FRigElementKey> Siblings;  // 0x18(0x10)
	struct FCachedRigElement CachedItem;  // 0x28(0x20)
	struct FRigElementKeyCollection CachedSiblings;  // 0x48(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_MathDoubleSqrt
// Size: 0x18(Inherited: 0x18) 
struct FRigUnit_MathDoubleSqrt : public FRigUnit_MathDoubleUnaryOp
{

}; 
// ScriptStruct ControlRig.RigUnit_HierarchyGetPoseItemArray
// Size: 0x90(Inherited: 0x8) 
struct FRigUnit_HierarchyGetPoseItemArray : public FRigUnit_HierarchyBase
{
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Initial : 1;  // 0x8(0x1)
	uint8_t  ElementType;  // 0x9(0x1)
	char pad_10[6];  // 0xA(0x6)
	struct TArray<struct FRigElementKey> ItemsToGet;  // 0x10(0x10)
	struct FRigPose Pose;  // 0x20(0x70)

}; 
// Function ControlRig.RigHierarchy.GetLocalTransformByIndex
// Size: 0x70(Inherited: 0x0) 
struct FGetLocalTransformByIndex
{
	int32_t InElementIndex;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool bInitial : 1;  // 0x4(0x1)
	char pad_5[11];  // 0x5(0xB)
	struct FTransform ReturnValue;  // 0x10(0x60)

}; 
// ScriptStruct ControlRig.RigUnit_PoseGetItemsItemArray
// Size: 0x90(Inherited: 0x8) 
struct FRigUnit_PoseGetItemsItemArray : public FRigUnit_HierarchyBase
{
	struct FRigPose Pose;  // 0x8(0x70)
	uint8_t  ElementType;  // 0x78(0x1)
	char pad_121[7];  // 0x79(0x7)
	struct TArray<struct FRigElementKey> Items;  // 0x80(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_PoseGetDelta
// Size: 0x128(Inherited: 0x8) 
struct FRigUnit_PoseGetDelta : public FRigUnit_HierarchyBase
{
	struct FRigPose PoseA;  // 0x8(0x70)
	struct FRigPose PoseB;  // 0x78(0x70)
	float PositionThreshold;  // 0xE8(0x4)
	float RotationThreshold;  // 0xEC(0x4)
	float ScaleThreshold;  // 0xF0(0x4)
	float CurveThreshold;  // 0xF4(0x4)
	uint8_t  ElementType;  // 0xF8(0x1)
	uint8_t  Space;  // 0xF9(0x1)
	char pad_250[6];  // 0xFA(0x6)
	struct FRigElementKeyCollection ItemsToCompare;  // 0x100(0x10)
	char pad_272_1 : 7;  // 0x110(0x1)
	bool PosesAreEqual : 1;  // 0x110(0x1)
	char pad_273[7];  // 0x111(0x7)
	struct FRigElementKeyCollection ItemsWithDelta;  // 0x118(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_MathBoolNot
// Size: 0x10(Inherited: 0x10) 
struct FRigUnit_MathBoolNot : public FRigUnit_MathBoolUnaryOp
{

}; 
// ScriptStruct ControlRig.RigUnit_SetControlRotator
// Size: 0x90(Inherited: 0x40) 
struct FRigUnit_SetControlRotator : public FRigUnitMutable
{
	struct FName Control;  // 0x40(0x8)
	float Weight;  // 0x48(0x4)
	char pad_76[4];  // 0x4C(0x4)
	struct FRotator Rotator;  // 0x50(0x18)
	uint8_t  Space;  // 0x68(0x1)
	char pad_105[7];  // 0x69(0x7)
	struct FCachedRigElement CachedControlIndex;  // 0x70(0x20)

}; 
// ScriptStruct ControlRig.RigUnit_PoseGetTransformArray
// Size: 0x90(Inherited: 0x8) 
struct FRigUnit_PoseGetTransformArray : public FRigUnit_HierarchyBase
{
	struct FRigPose Pose;  // 0x8(0x70)
	uint8_t  Space;  // 0x78(0x1)
	char pad_121_1 : 7;  // 0x79(0x1)
	bool Valid : 1;  // 0x79(0x1)
	char pad_122[6];  // 0x7A(0x6)
	struct TArray<struct FTransform> Transforms;  // 0x80(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_PoseGetCurve
// Size: 0x90(Inherited: 0x8) 
struct FRigUnit_PoseGetCurve : public FRigUnit_HierarchyBase
{
	struct FRigPose Pose;  // 0x8(0x70)
	struct FName Curve;  // 0x78(0x8)
	char pad_128_1 : 7;  // 0x80(0x1)
	bool Valid : 1;  // 0x80(0x1)
	char pad_129[3];  // 0x81(0x3)
	float CurveValue;  // 0x84(0x4)
	int32_t CachedPoseElementIndex;  // 0x88(0x4)
	int32_t CachedPoseHash;  // 0x8C(0x4)

}; 
// Function ControlRig.ControlRigComponent.SetControlVector2D
// Size: 0x18(Inherited: 0x0) 
struct FSetControlVector2D
{
	struct FName ControlName;  // 0x0(0x8)
	struct FVector2D Value;  // 0x8(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_RotationConstraint_AdvancedSettings
// Size: 0x2(Inherited: 0x0) 
struct FRigUnit_RotationConstraint_AdvancedSettings
{
	uint8_t  InterpolationType;  // 0x0(0x1)
	uint8_t  RotationOrderForFilter;  // 0x1(0x1)

}; 
// ScriptStruct ControlRig.RigUnit_InverseExecution
// Size: 0x40(Inherited: 0x8) 
struct FRigUnit_InverseExecution : public FRigUnit
{
	struct FControlRigExecuteContext ExecuteContext;  // 0x8(0x38)

}; 
// ScriptStruct ControlRig.RigUnit_TimeOffsetVector
// Size: 0x70(Inherited: 0x8) 
struct FRigUnit_TimeOffsetVector : public FRigUnit_SimBase
{
	struct FVector Value;  // 0x8(0x18)
	float SecondsAgo;  // 0x20(0x4)
	int32_t BufferSize;  // 0x24(0x4)
	float TimeRange;  // 0x28(0x4)
	char pad_44[4];  // 0x2C(0x4)
	struct FVector Result;  // 0x30(0x18)
	struct TArray<struct FVector> Buffer;  // 0x48(0x10)
	struct TArray<float> DeltaTimes;  // 0x58(0x10)
	int32_t LastInsertIndex;  // 0x68(0x4)
	int32_t UpperBound;  // 0x6C(0x4)

}; 
// ScriptStruct ControlRig.RigUnit_ItemExists
// Size: 0x38(Inherited: 0x8) 
struct FRigUnit_ItemExists : public FRigUnit_ItemBase
{
	struct FRigElementKey Item;  // 0x8(0xC)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool Exists : 1;  // 0x14(0x1)
	char pad_21[3];  // 0x15(0x3)
	struct FCachedRigElement CachedIndex;  // 0x18(0x20)

}; 
// ScriptStruct ControlRig.RigUnit_ItemReplace
// Size: 0x30(Inherited: 0x8) 
struct FRigUnit_ItemReplace : public FRigUnit_ItemBase
{
	struct FRigElementKey Item;  // 0x8(0xC)
	struct FName Old;  // 0x14(0x8)
	struct FName New;  // 0x1C(0x8)
	struct FRigElementKey Result;  // 0x24(0xC)

}; 
// ScriptStruct ControlRig.RigUnit_MathDoubleAbs
// Size: 0x18(Inherited: 0x18) 
struct FRigUnit_MathDoubleAbs : public FRigUnit_MathDoubleUnaryOp
{

}; 
// Function ControlRig.ControlRigShapeActor.GetGlobalTransform
// Size: 0x60(Inherited: 0x0) 
struct FGetGlobalTransform
{
	struct FTransform ReturnValue;  // 0x0(0x60)

}; 
// ScriptStruct ControlRig.RigUnit_ItemEquals
// Size: 0x28(Inherited: 0x8) 
struct FRigUnit_ItemEquals : public FRigUnit_ItemBase
{
	struct FRigElementKey A;  // 0x8(0xC)
	struct FRigElementKey B;  // 0x14(0xC)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool Result : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// ScriptStruct ControlRig.RigUnit_ItemNotEquals
// Size: 0x28(Inherited: 0x8) 
struct FRigUnit_ItemNotEquals : public FRigUnit_ItemBase
{
	struct FRigElementKey A;  // 0x8(0xC)
	struct FRigElementKey B;  // 0x14(0xC)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool Result : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// ScriptStruct ControlRig.RigUnit_ItemTypeEquals
// Size: 0x28(Inherited: 0x8) 
struct FRigUnit_ItemTypeEquals : public FRigUnit_ItemBase
{
	struct FRigElementKey A;  // 0x8(0xC)
	struct FRigElementKey B;  // 0x14(0xC)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool Result : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// ScriptStruct ControlRig.RigUnit_MathDoubleDeg
// Size: 0x18(Inherited: 0x18) 
struct FRigUnit_MathDoubleDeg : public FRigUnit_MathDoubleUnaryOp
{

}; 
// ScriptStruct ControlRig.RigUnit_MathVectorDiv
// Size: 0x50(Inherited: 0x50) 
struct FRigUnit_MathVectorDiv : public FRigUnit_MathVectorBinaryOp
{

}; 
// Function ControlRig.RigHierarchy.SetCurveValue
// Size: 0x14(Inherited: 0x0) 
struct FSetCurveValue
{
	struct FRigElementKey InKey;  // 0x0(0xC)
	float InValue;  // 0xC(0x4)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bSetupUndo : 1;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)

}; 
// ScriptStruct ControlRig.RigUnit_FindItemsWithMetadataTag
// Size: 0x20(Inherited: 0x8) 
struct FRigUnit_FindItemsWithMetadataTag : public FRigUnit
{
	struct FName Tag;  // 0x8(0x8)
	struct TArray<struct FRigElementKey> Items;  // 0x10(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_PrepareForExecution
// Size: 0x40(Inherited: 0x8) 
struct FRigUnit_PrepareForExecution : public FRigUnit
{
	struct FControlRigExecuteContext ExecuteContext;  // 0x8(0x38)

}; 
// ScriptStruct ControlRig.RigUnit_SequenceExecution
// Size: 0x120(Inherited: 0x8) 
struct FRigUnit_SequenceExecution : public FRigUnit
{
	struct FControlRigExecuteContext ExecuteContext;  // 0x8(0x38)
	struct FControlRigExecuteContext A;  // 0x40(0x38)
	struct FControlRigExecuteContext B;  // 0x78(0x38)
	struct FControlRigExecuteContext C;  // 0xB0(0x38)
	struct FControlRigExecuteContext D;  // 0xE8(0x38)

}; 
// ScriptStruct ControlRig.RigUnit_UserDefinedEvent
// Size: 0x48(Inherited: 0x8) 
struct FRigUnit_UserDefinedEvent : public FRigUnit
{
	struct FControlRigExecuteContext ExecuteContext;  // 0x8(0x38)
	struct FName EventName;  // 0x40(0x8)

}; 
// ScriptStruct ControlRig.RigUnit_AddBoneTransform
// Size: 0xE0(Inherited: 0x40) 
struct FRigUnit_AddBoneTransform : public FRigUnitMutable
{
	struct FName bone;  // 0x40(0x8)
	char pad_72[8];  // 0x48(0x8)
	struct FTransform Transform;  // 0x50(0x60)
	float Weight;  // 0xB0(0x4)
	char pad_180_1 : 7;  // 0xB4(0x1)
	bool bPostMultiply : 1;  // 0xB4(0x1)
	char pad_181_1 : 7;  // 0xB5(0x1)
	bool bPropagateToChildren : 1;  // 0xB5(0x1)
	char pad_182[2];  // 0xB6(0x2)
	struct FCachedRigElement CachedBone;  // 0xB8(0x20)
	char pad_216[8];  // 0xD8(0x8)

}; 
// ScriptStruct ControlRig.RigUnit_Item
// Size: 0x18(Inherited: 0x8) 
struct FRigUnit_Item : public FRigUnit
{
	struct FRigElementKey Item;  // 0x8(0xC)
	char pad_20[4];  // 0x14(0x4)

}; 
// ScriptStruct ControlRig.RigUnit_MathDoubleAtan
// Size: 0x18(Inherited: 0x18) 
struct FRigUnit_MathDoubleAtan : public FRigUnit_MathDoubleUnaryOp
{

}; 
// ScriptStruct ControlRig.RigUnit_SpringIK
// Size: 0x210(Inherited: 0x40) 
struct FRigUnit_SpringIK : public FRigUnit_HighlevelBaseMutable
{
	struct FName StartBone;  // 0x40(0x8)
	struct FName EndBone;  // 0x48(0x8)
	float HierarchyStrength;  // 0x50(0x4)
	float EffectorStrength;  // 0x54(0x4)
	float EffectorRatio;  // 0x58(0x4)
	float RootStrength;  // 0x5C(0x4)
	float RootRatio;  // 0x60(0x4)
	float Damping;  // 0x64(0x4)
	struct FVector PoleVector;  // 0x68(0x18)
	char pad_128_1 : 7;  // 0x80(0x1)
	bool bFlipPolePlane : 1;  // 0x80(0x1)
	uint8_t  PoleVectorKind;  // 0x81(0x1)
	char pad_130[2];  // 0x82(0x2)
	struct FName PoleVectorSpace;  // 0x84(0x8)
	char pad_140[4];  // 0x8C(0x4)
	struct FVector PrimaryAxis;  // 0x90(0x18)
	struct FVector SecondaryAxis;  // 0xA8(0x18)
	char pad_192_1 : 7;  // 0xC0(0x1)
	bool bLiveSimulation : 1;  // 0xC0(0x1)
	char pad_193[3];  // 0xC1(0x3)
	int32_t Iterations;  // 0xC4(0x4)
	char pad_200_1 : 7;  // 0xC8(0x1)
	bool bLimitLocalPosition : 1;  // 0xC8(0x1)
	char pad_201_1 : 7;  // 0xC9(0x1)
	bool bPropagateToChildren : 1;  // 0xC9(0x1)
	char pad_202[6];  // 0xCA(0x6)
	struct FRigUnit_SpringIK_DebugSettings DebugSettings;  // 0xD0(0x80)
	struct FRigUnit_SpringIK_WorkData WorkData;  // 0x150(0xB8)
	char pad_520[8];  // 0x208(0x8)

}; 
// ScriptStruct ControlRig.RigUnit_GetInitialBoneTransform
// Size: 0xA0(Inherited: 0x8) 
struct FRigUnit_GetInitialBoneTransform : public FRigUnit
{
	struct FName bone;  // 0x8(0x8)
	uint8_t  Space;  // 0x10(0x1)
	char pad_17[15];  // 0x11(0xF)
	struct FTransform Transform;  // 0x20(0x60)
	struct FCachedRigElement CachedBone;  // 0x80(0x20)

}; 
// ScriptStruct ControlRig.RigUnit_ControlName
// Size: 0x10(Inherited: 0x8) 
struct FRigUnit_ControlName : public FRigUnit
{
	struct FName Control;  // 0x8(0x8)

}; 
// ScriptStruct ControlRig.RigUnit_MathQuaternionRotateVector
// Size: 0x60(Inherited: 0x8) 
struct FRigUnit_MathQuaternionRotateVector : public FRigUnit_MathQuaternionBase
{
	char pad_8[8];  // 0x8(0x8)
	struct FQuat Transform;  // 0x10(0x20)
	struct FVector Vector;  // 0x30(0x18)
	struct FVector Result;  // 0x48(0x18)

}; 
// ScriptStruct ControlRig.RigUnit_PointSimulation_BoneTarget
// Size: 0x14(Inherited: 0x0) 
struct FRigUnit_PointSimulation_BoneTarget
{
	struct FName bone;  // 0x0(0x8)
	int32_t TranslationPoint;  // 0x8(0x4)
	int32_t PrimaryAimPoint;  // 0xC(0x4)
	int32_t SecondaryAimPoint;  // 0x10(0x4)

}; 
// ScriptStruct ControlRig.RigUnit_GetBoolAnimationChannel
// Size: 0x38(Inherited: 0x30) 
struct FRigUnit_GetBoolAnimationChannel : public FRigUnit_GetAnimationChannelBase
{
	char pad_48_1 : 7;  // 0x30(0x1)
	bool Value : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)

}; 
// ScriptStruct ControlRig.RigUnit_GetIntAnimationChannel
// Size: 0x38(Inherited: 0x30) 
struct FRigUnit_GetIntAnimationChannel : public FRigUnit_GetAnimationChannelBase
{
	int32_t Value;  // 0x30(0x4)
	char pad_52[4];  // 0x34(0x4)

}; 
// ScriptStruct ControlRig.RigUnit_GetVectorAnimationChannel
// Size: 0x48(Inherited: 0x30) 
struct FRigUnit_GetVectorAnimationChannel : public FRigUnit_GetAnimationChannelBase
{
	struct FVector Value;  // 0x30(0x18)

}; 
// ScriptStruct ControlRig.RigUnit_SetAnimationChannelBase
// Size: 0x68(Inherited: 0x30) 
struct FRigUnit_SetAnimationChannelBase : public FRigUnit_GetAnimationChannelBase
{
	struct FControlRigExecuteContext ExecuteContext;  // 0x30(0x38)

}; 
// ScriptStruct ControlRig.RigUnit_SetFloatAnimationChannel
// Size: 0x70(Inherited: 0x68) 
struct FRigUnit_SetFloatAnimationChannel : public FRigUnit_SetAnimationChannelBase
{
	float Value;  // 0x68(0x4)
	char pad_108[4];  // 0x6C(0x4)

}; 
// Function ControlRig.RigHierarchy.SetLinearColorMetadata
// Size: 0x28(Inherited: 0x0) 
struct FSetLinearColorMetadata
{
	struct FRigElementKey InItem;  // 0x0(0xC)
	struct FName InMetadataName;  // 0xC(0x8)
	struct FLinearColor InValue;  // 0x14(0x10)
	char pad_36_1 : 7;  // 0x24(0x1)
	bool ReturnValue : 1;  // 0x24(0x1)
	char pad_37[3];  // 0x25(0x3)

}; 
// ScriptStruct ControlRig.RigUnit_SetVector2DAnimationChannel
// Size: 0x78(Inherited: 0x68) 
struct FRigUnit_SetVector2DAnimationChannel : public FRigUnit_SetAnimationChannelBase
{
	struct FVector2D Value;  // 0x68(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_SetVectorAnimationChannel
// Size: 0x80(Inherited: 0x68) 
struct FRigUnit_SetVectorAnimationChannel : public FRigUnit_SetAnimationChannelBase
{
	struct FVector Value;  // 0x68(0x18)

}; 
// ScriptStruct ControlRig.RigUnit_SetRotatorAnimationChannel
// Size: 0x80(Inherited: 0x68) 
struct FRigUnit_SetRotatorAnimationChannel : public FRigUnit_SetAnimationChannelBase
{
	struct FRotator Value;  // 0x68(0x18)

}; 
// ScriptStruct ControlRig.RigUnit_MathDoubleAdd
// Size: 0x20(Inherited: 0x20) 
struct FRigUnit_MathDoubleAdd : public FRigUnit_MathDoubleBinaryAggregateOp
{

}; 
// ScriptStruct ControlRig.RigUnit_SetTransformAnimationChannel
// Size: 0xD0(Inherited: 0x68) 
struct FRigUnit_SetTransformAnimationChannel : public FRigUnit_SetAnimationChannelBase
{
	char pad_104[8];  // 0x68(0x8)
	struct FTransform Value;  // 0x70(0x60)

}; 
// ScriptStruct ControlRig.RigUnit_MathFloatConstHalfPi
// Size: 0x10(Inherited: 0x10) 
struct FRigUnit_MathFloatConstHalfPi : public FRigUnit_MathFloatConstant
{

}; 
// ScriptStruct ControlRig.RigUnit_AimItem
// Size: 0x1C0(Inherited: 0x40) 
struct FRigUnit_AimItem : public FRigUnit_HighlevelBaseMutable
{
	struct FRigElementKey Item;  // 0x40(0xC)
	char pad_76[4];  // 0x4C(0x4)
	struct FRigUnit_AimItem_Target Primary;  // 0x50(0x48)
	struct FRigUnit_AimItem_Target Secondary;  // 0x98(0x48)
	float Weight;  // 0xE0(0x4)
	char pad_228[12];  // 0xE4(0xC)
	struct FRigUnit_AimBone_DebugSettings DebugSettings;  // 0xF0(0x70)
	struct FCachedRigElement CachedItem;  // 0x160(0x20)
	struct FCachedRigElement PrimaryCachedSpace;  // 0x180(0x20)
	struct FCachedRigElement SecondaryCachedSpace;  // 0x1A0(0x20)

}; 
// ScriptStruct ControlRig.RigUnit_GetBoneTransform
// Size: 0xA0(Inherited: 0x8) 
struct FRigUnit_GetBoneTransform : public FRigUnit
{
	struct FName bone;  // 0x8(0x8)
	uint8_t  Space;  // 0x10(0x1)
	char pad_17[15];  // 0x11(0xF)
	struct FTransform Transform;  // 0x20(0x60)
	struct FCachedRigElement CachedBone;  // 0x80(0x20)

}; 
// ScriptStruct ControlRig.RigUnit_GetControlBool
// Size: 0x38(Inherited: 0x8) 
struct FRigUnit_GetControlBool : public FRigUnit
{
	struct FName Control;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool BoolValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct FCachedRigElement CachedControlIndex;  // 0x18(0x20)

}; 
// ScriptStruct ControlRig.RigUnit_MathVectorRemap
// Size: 0xA0(Inherited: 0x8) 
struct FRigUnit_MathVectorRemap : public FRigUnit_MathVectorBase
{
	struct FVector Value;  // 0x8(0x18)
	struct FVector SourceMinimum;  // 0x20(0x18)
	struct FVector SourceMaximum;  // 0x38(0x18)
	struct FVector TargetMinimum;  // 0x50(0x18)
	struct FVector TargetMaximum;  // 0x68(0x18)
	char pad_128_1 : 7;  // 0x80(0x1)
	bool bClamp : 1;  // 0x80(0x1)
	char pad_129[7];  // 0x81(0x7)
	struct FVector Result;  // 0x88(0x18)

}; 
// ScriptStruct ControlRig.RigUnit_AimBoneMath
// Size: 0x220(Inherited: 0x8) 
struct FRigUnit_AimBoneMath : public FRigUnit_HighlevelBase
{
	char pad_8[8];  // 0x8(0x8)
	struct FTransform InputTransform;  // 0x10(0x60)
	struct FRigUnit_AimItem_Target Primary;  // 0x70(0x48)
	struct FRigUnit_AimItem_Target Secondary;  // 0xB8(0x48)
	float Weight;  // 0x100(0x4)
	char pad_260[12];  // 0x104(0xC)
	struct FTransform Result;  // 0x110(0x60)
	struct FRigUnit_AimBone_DebugSettings DebugSettings;  // 0x170(0x70)
	struct FCachedRigElement PrimaryCachedSpace;  // 0x1E0(0x20)
	struct FCachedRigElement SecondaryCachedSpace;  // 0x200(0x20)

}; 
// ScriptStruct ControlRig.RigUnit_RandomFloat
// Size: 0x30(Inherited: 0x8) 
struct FRigUnit_RandomFloat : public FRigUnit_MathBase
{
	int32_t Seed;  // 0x8(0x4)
	float Minimum;  // 0xC(0x4)
	float Maximum;  // 0x10(0x4)
	float Duration;  // 0x14(0x4)
	float Result;  // 0x18(0x4)
	float LastResult;  // 0x1C(0x4)
	int32_t LastSeed;  // 0x20(0x4)
	int32_t BaseSeed;  // 0x24(0x4)
	float TimeLeft;  // 0x28(0x4)
	char pad_44[4];  // 0x2C(0x4)

}; 
// ScriptStruct ControlRig.RigUnit_GetControlFloat
// Size: 0x40(Inherited: 0x8) 
struct FRigUnit_GetControlFloat : public FRigUnit
{
	struct FName Control;  // 0x8(0x8)
	float FloatValue;  // 0x10(0x4)
	float Minimum;  // 0x14(0x4)
	float Maximum;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct FCachedRigElement CachedControlIndex;  // 0x20(0x20)

}; 
// ScriptStruct ControlRig.RigUnit_GetControlVector2D
// Size: 0x60(Inherited: 0x8) 
struct FRigUnit_GetControlVector2D : public FRigUnit
{
	struct FName Control;  // 0x8(0x8)
	struct FVector2D Vector;  // 0x10(0x10)
	struct FVector2D Minimum;  // 0x20(0x10)
	struct FVector2D Maximum;  // 0x30(0x10)
	struct FCachedRigElement CachedControlIndex;  // 0x40(0x20)

}; 
// ScriptStruct ControlRig.RigUnit_GetControlRotator
// Size: 0x80(Inherited: 0x8) 
struct FRigUnit_GetControlRotator : public FRigUnit
{
	struct FName Control;  // 0x8(0x8)
	uint8_t  Space;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct FRotator Rotator;  // 0x18(0x18)
	struct FRotator Minimum;  // 0x30(0x18)
	struct FRotator Maximum;  // 0x48(0x18)
	struct FCachedRigElement CachedControlIndex;  // 0x60(0x20)

}; 
// ScriptStruct ControlRig.RigUnit_MathFloatUnaryOp
// Size: 0x10(Inherited: 0x8) 
struct FRigUnit_MathFloatUnaryOp : public FRigUnit_MathFloatBase
{
	float Value;  // 0x8(0x4)
	float Result;  // 0xC(0x4)

}; 
// ScriptStruct ControlRig.RigUnit_GetRelativeBoneTransform
// Size: 0xC0(Inherited: 0x8) 
struct FRigUnit_GetRelativeBoneTransform : public FRigUnit
{
	struct FName bone;  // 0x8(0x8)
	struct FName Space;  // 0x10(0x8)
	char pad_24[8];  // 0x18(0x8)
	struct FTransform Transform;  // 0x20(0x60)
	struct FCachedRigElement CachedBone;  // 0x80(0x20)
	struct FCachedRigElement CachedSpace;  // 0xA0(0x20)

}; 
// Function ControlRig.RigHierarchy.SetControlShapeTransform
// Size: 0x80(Inherited: 0x0) 
struct FSetControlShapeTransform
{
	struct FRigElementKey InKey;  // 0x0(0xC)
	char pad_12[4];  // 0xC(0x4)
	struct FTransform InTransform;  // 0x10(0x60)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool bInitial : 1;  // 0x70(0x1)
	char pad_113_1 : 7;  // 0x71(0x1)
	bool bSetupUndo : 1;  // 0x71(0x1)
	char pad_114[14];  // 0x72(0xE)

}; 
// ScriptStruct ControlRig.RigUnit_GetRelativeTransformForItem
// Size: 0xD0(Inherited: 0x8) 
struct FRigUnit_GetRelativeTransformForItem : public FRigUnit
{
	struct FRigElementKey Child;  // 0x8(0xC)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool bChildInitial : 1;  // 0x14(0x1)
	char pad_21[3];  // 0x15(0x3)
	struct FRigElementKey Parent;  // 0x18(0xC)
	char pad_36_1 : 7;  // 0x24(0x1)
	bool bParentInitial : 1;  // 0x24(0x1)
	char pad_37[11];  // 0x25(0xB)
	struct FTransform RelativeTransform;  // 0x30(0x60)
	struct FCachedRigElement CachedChild;  // 0x90(0x20)
	struct FCachedRigElement CachedParent;  // 0xB0(0x20)

}; 
// ScriptStruct ControlRig.RigUnit_GetSpaceTransform
// Size: 0xA0(Inherited: 0x8) 
struct FRigUnit_GetSpaceTransform : public FRigUnit
{
	struct FName Space;  // 0x8(0x8)
	uint8_t  SpaceType;  // 0x10(0x1)
	char pad_17[15];  // 0x11(0xF)
	struct FTransform Transform;  // 0x20(0x60)
	struct FCachedRigElement CachedSpaceIndex;  // 0x80(0x20)

}; 
// Function ControlRig.RigHierarchy.SetControlPreferredRotatorByIndex
// Size: 0x28(Inherited: 0x0) 
struct FSetControlPreferredRotatorByIndex
{
	int32_t InElementIndex;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FRotator InValue;  // 0x8(0x18)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool bInitial : 1;  // 0x20(0x1)
	char pad_33_1 : 7;  // 0x21(0x1)
	bool bFixEulerFlips : 1;  // 0x21(0x1)
	char pad_34[6];  // 0x22(0x6)

}; 
// ScriptStruct ControlRig.RigUnit_MathFloatAsin
// Size: 0x10(Inherited: 0x10) 
struct FRigUnit_MathFloatAsin : public FRigUnit_MathFloatUnaryOp
{

}; 
// Function ControlRig.RigHierarchy.GetInt32ArrayMetadata
// Size: 0x28(Inherited: 0x0) 
struct FGetInt32ArrayMetadata
{
	struct FRigElementKey InItem;  // 0x0(0xC)
	struct FName InMetadataName;  // 0xC(0x8)
	char pad_20[4];  // 0x14(0x4)
	struct TArray<int32_t> ReturnValue;  // 0x18(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_GetTransform
// Size: 0xA0(Inherited: 0x8) 
struct FRigUnit_GetTransform : public FRigUnit
{
	struct FRigElementKey Item;  // 0x8(0xC)
	uint8_t  Space;  // 0x14(0x1)
	char pad_21_1 : 7;  // 0x15(0x1)
	bool bInitial : 1;  // 0x15(0x1)
	char pad_22[10];  // 0x16(0xA)
	struct FTransform Transform;  // 0x20(0x60)
	struct FCachedRigElement CachedIndex;  // 0x80(0x20)

}; 
// ScriptStruct ControlRig.RigUnit_SetTransformItemArray
// Size: 0x80(Inherited: 0x40) 
struct FRigUnit_SetTransformItemArray : public FRigUnitMutable
{
	struct TArray<struct FRigElementKey> Items;  // 0x40(0x10)
	uint8_t  Space;  // 0x50(0x1)
	char pad_81_1 : 7;  // 0x51(0x1)
	bool bInitial : 1;  // 0x51(0x1)
	char pad_82[6];  // 0x52(0x6)
	struct TArray<struct FTransform> Transforms;  // 0x58(0x10)
	float Weight;  // 0x68(0x4)
	char pad_108_1 : 7;  // 0x6C(0x1)
	bool bPropagateToChildren : 1;  // 0x6C(0x1)
	char pad_109[3];  // 0x6D(0x3)
	struct TArray<struct FCachedRigElement> CachedIndex;  // 0x70(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_GetTransformItemArray
// Size: 0x40(Inherited: 0x8) 
struct FRigUnit_GetTransformItemArray : public FRigUnit
{
	struct TArray<struct FRigElementKey> Items;  // 0x8(0x10)
	uint8_t  Space;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool bInitial : 1;  // 0x19(0x1)
	char pad_26[6];  // 0x1A(0x6)
	struct TArray<struct FTransform> Transforms;  // 0x20(0x10)
	struct TArray<struct FCachedRigElement> CachedIndex;  // 0x30(0x10)

}; 
// ScriptStruct ControlRig.RigDispatch_MetadataBase
// Size: 0x48(Inherited: 0x18) 
struct FRigDispatch_MetadataBase : public FRigDispatchFactory
{
	char pad_24[48];  // 0x18(0x30)

}; 
// ScriptStruct ControlRig.RigUnit_MathVectorSign
// Size: 0x38(Inherited: 0x38) 
struct FRigUnit_MathVectorSign : public FRigUnit_MathVectorUnaryOp
{

}; 
// ScriptStruct ControlRig.RigDispatch_SetMetadata
// Size: 0x48(Inherited: 0x48) 
struct FRigDispatch_SetMetadata : public FRigDispatch_MetadataBase
{

}; 
// ScriptStruct ControlRig.RigUnit_MathRBFInterpolateVectorFloat
// Size: 0xE0(Inherited: 0xC0) 
struct FRigUnit_MathRBFInterpolateVectorFloat : public FRigUnit_MathRBFInterpolateVectorBase
{
	struct TArray<struct FMathRBFInterpolateVectorFloat_Target> Targets;  // 0xC0(0x10)
	float Output;  // 0xD0(0x4)
	char pad_212[12];  // 0xD4(0xC)

}; 
// ScriptStruct ControlRig.RigUnit_MathIntBinaryOp
// Size: 0x18(Inherited: 0x8) 
struct FRigUnit_MathIntBinaryOp : public FRigUnit_MathIntBase
{
	int32_t A;  // 0x8(0x4)
	int32_t B;  // 0xC(0x4)
	int32_t Result;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)

}; 
// ScriptStruct ControlRig.RigUnit_RemoveMetadata
// Size: 0x78(Inherited: 0x40) 
struct FRigUnit_RemoveMetadata : public FRigUnitMutable
{
	struct FRigElementKey Item;  // 0x40(0xC)
	struct FName Name;  // 0x4C(0x8)
	char pad_84_1 : 7;  // 0x54(0x1)
	bool Removed : 1;  // 0x54(0x1)
	char pad_85[3];  // 0x55(0x3)
	struct FCachedRigElement CachedIndex;  // 0x58(0x20)

}; 
// ScriptStruct ControlRig.RigUnit_TimeLoop
// Size: 0x30(Inherited: 0x8) 
struct FRigUnit_TimeLoop : public FRigUnit_SimBase
{
	float Speed;  // 0x8(0x4)
	float Duration;  // 0xC(0x4)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool Normalize : 1;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)
	float Absolute;  // 0x14(0x4)
	float Relative;  // 0x18(0x4)
	float FlipFlop;  // 0x1C(0x4)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool Even : 1;  // 0x20(0x1)
	char pad_33[3];  // 0x21(0x3)
	float AccumulatedAbsolute;  // 0x24(0x4)
	float AccumulatedRelative;  // 0x28(0x4)
	int32_t NumIterations;  // 0x2C(0x4)

}; 
// ScriptStruct ControlRig.RigUnit_SetRotation
// Size: 0xA0(Inherited: 0x40) 
struct FRigUnit_SetRotation : public FRigUnitMutable
{
	struct FRigElementKey Item;  // 0x40(0xC)
	uint8_t  Space;  // 0x4C(0x1)
	char pad_77_1 : 7;  // 0x4D(0x1)
	bool bInitial : 1;  // 0x4D(0x1)
	char pad_78[2];  // 0x4E(0x2)
	struct FQuat Value;  // 0x50(0x20)
	float Weight;  // 0x70(0x4)
	char pad_116_1 : 7;  // 0x74(0x1)
	bool bPropagateToChildren : 1;  // 0x74(0x1)
	char pad_117[3];  // 0x75(0x3)
	struct FCachedRigElement CachedIndex;  // 0x78(0x20)
	char pad_152[8];  // 0x98(0x8)

}; 
// ScriptStruct ControlRig.RigUnit_RemoveAllMetadata
// Size: 0x70(Inherited: 0x40) 
struct FRigUnit_RemoveAllMetadata : public FRigUnitMutable
{
	struct FRigElementKey Item;  // 0x40(0xC)
	char pad_76_1 : 7;  // 0x4C(0x1)
	bool Removed : 1;  // 0x4C(0x1)
	char pad_77[3];  // 0x4D(0x3)
	struct FCachedRigElement CachedIndex;  // 0x50(0x20)

}; 
// ScriptStruct ControlRig.RigUnit_TwistBonesPerItem
// Size: 0xC0(Inherited: 0x40) 
struct FRigUnit_TwistBonesPerItem : public FRigUnit_HighlevelBaseMutable
{
	struct FRigElementKeyCollection Items;  // 0x40(0x10)
	struct FVector TwistAxis;  // 0x50(0x18)
	struct FVector PoleAxis;  // 0x68(0x18)
	uint8_t  TwistEaseType;  // 0x80(0x1)
	char pad_129[3];  // 0x81(0x3)
	float Weight;  // 0x84(0x4)
	char pad_136_1 : 7;  // 0x88(0x1)
	bool bPropagateToChildren : 1;  // 0x88(0x1)
	char pad_137[7];  // 0x89(0x7)
	struct FRigUnit_TwistBones_WorkData WorkData;  // 0x90(0x30)

}; 
// ScriptStruct ControlRig.RigUnit_SetMetadataTagArray
// Size: 0x80(Inherited: 0x40) 
struct FRigUnit_SetMetadataTagArray : public FRigUnitMutable
{
	struct FRigElementKey Item;  // 0x40(0xC)
	char pad_76[4];  // 0x4C(0x4)
	struct TArray<struct FName> Tags;  // 0x50(0x10)
	struct FCachedRigElement CachedIndex;  // 0x60(0x20)

}; 
// ScriptStruct ControlRig.RigUnit_HasMetadataTag
// Size: 0x40(Inherited: 0x8) 
struct FRigUnit_HasMetadataTag : public FRigUnit
{
	struct FRigElementKey Item;  // 0x8(0xC)
	struct FName Tag;  // 0x14(0x8)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool Found : 1;  // 0x1C(0x1)
	char pad_29[3];  // 0x1D(0x3)
	struct FCachedRigElement CachedIndex;  // 0x20(0x20)

}; 
// ScriptStruct ControlRig.RigUnit_OffsetTransformForItem
// Size: 0xE0(Inherited: 0x40) 
struct FRigUnit_OffsetTransformForItem : public FRigUnitMutable
{
	struct FRigElementKey Item;  // 0x40(0xC)
	char pad_76[4];  // 0x4C(0x4)
	struct FTransform OffsetTransform;  // 0x50(0x60)
	float Weight;  // 0xB0(0x4)
	char pad_180_1 : 7;  // 0xB4(0x1)
	bool bPropagateToChildren : 1;  // 0xB4(0x1)
	char pad_181[3];  // 0xB5(0x3)
	struct FCachedRigElement CachedIndex;  // 0xB8(0x20)
	char pad_216[8];  // 0xD8(0x8)

}; 
// ScriptStruct ControlRig.RigUnit_ParentSwitchConstraint
// Size: 0x1E0(Inherited: 0x40) 
struct FRigUnit_ParentSwitchConstraint : public FRigUnitMutable
{
	struct FRigElementKey Subject;  // 0x40(0xC)
	int32_t ParentIndex;  // 0x4C(0x4)
	struct FRigElementKeyCollection Parents;  // 0x50(0x10)
	struct FTransform InitialGlobalTransform;  // 0x60(0x60)
	float Weight;  // 0xC0(0x4)
	char pad_196[12];  // 0xC4(0xC)
	struct FTransform Transform;  // 0xD0(0x60)
	char pad_304_1 : 7;  // 0x130(0x1)
	bool Switched : 1;  // 0x130(0x1)
	char pad_305[7];  // 0x131(0x7)
	struct FCachedRigElement CachedSubject;  // 0x138(0x20)
	struct FCachedRigElement CachedParent;  // 0x158(0x20)
	char pad_376[8];  // 0x178(0x8)
	struct FTransform RelativeOffset;  // 0x180(0x60)

}; 
// ScriptStruct ControlRig.RigUnit_MathQuaternionFromEuler
// Size: 0x50(Inherited: 0x8) 
struct FRigUnit_MathQuaternionFromEuler : public FRigUnit_MathQuaternionBase
{
	struct FVector Euler;  // 0x8(0x18)
	uint8_t  RotationOrder;  // 0x20(0x1)
	char pad_33[15];  // 0x21(0xF)
	struct FQuat Result;  // 0x30(0x20)

}; 
// ScriptStruct ControlRig.RigUnit_MathQuaternionBinaryOp
// Size: 0x70(Inherited: 0x8) 
struct FRigUnit_MathQuaternionBinaryOp : public FRigUnit_MathQuaternionBase
{
	char pad_8[8];  // 0x8(0x8)
	struct FQuat A;  // 0x10(0x20)
	struct FQuat B;  // 0x30(0x20)
	struct FQuat Result;  // 0x50(0x20)

}; 
// ScriptStruct ControlRig.RigUnit_ParentSwitchConstraintArray
// Size: 0x1E0(Inherited: 0x40) 
struct FRigUnit_ParentSwitchConstraintArray : public FRigUnitMutable
{
	struct FRigElementKey Subject;  // 0x40(0xC)
	int32_t ParentIndex;  // 0x4C(0x4)
	struct TArray<struct FRigElementKey> Parents;  // 0x50(0x10)
	struct FTransform InitialGlobalTransform;  // 0x60(0x60)
	float Weight;  // 0xC0(0x4)
	char pad_196[12];  // 0xC4(0xC)
	struct FTransform Transform;  // 0xD0(0x60)
	char pad_304_1 : 7;  // 0x130(0x1)
	bool Switched : 1;  // 0x130(0x1)
	char pad_305[7];  // 0x131(0x7)
	struct FCachedRigElement CachedSubject;  // 0x138(0x20)
	struct FCachedRigElement CachedParent;  // 0x158(0x20)
	char pad_376[8];  // 0x178(0x8)
	struct FTransform RelativeOffset;  // 0x180(0x60)

}; 
// ScriptStruct ControlRig.RigUnit_ProjectTransformToNewParent
// Size: 0x100(Inherited: 0x8) 
struct FRigUnit_ProjectTransformToNewParent : public FRigUnit
{
	struct FRigElementKey Child;  // 0x8(0xC)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool bChildInitial : 1;  // 0x14(0x1)
	char pad_21[3];  // 0x15(0x3)
	struct FRigElementKey OldParent;  // 0x18(0xC)
	char pad_36_1 : 7;  // 0x24(0x1)
	bool bOldParentInitial : 1;  // 0x24(0x1)
	char pad_37[3];  // 0x25(0x3)
	struct FRigElementKey NewParent;  // 0x28(0xC)
	char pad_52_1 : 7;  // 0x34(0x1)
	bool bNewParentInitial : 1;  // 0x34(0x1)
	char pad_53[11];  // 0x35(0xB)
	struct FTransform Transform;  // 0x40(0x60)
	struct FCachedRigElement CachedChild;  // 0xA0(0x20)
	struct FCachedRigElement CachedOldParent;  // 0xC0(0x20)
	struct FCachedRigElement CachedNewParent;  // 0xE0(0x20)

}; 
// ScriptStruct ControlRig.RigUnit_SendEvent
// Size: 0x58(Inherited: 0x40) 
struct FRigUnit_SendEvent : public FRigUnitMutable
{
	uint8_t  Event;  // 0x40(0x1)
	char pad_65[3];  // 0x41(0x3)
	struct FRigElementKey Item;  // 0x44(0xC)
	float OffsetInSeconds;  // 0x50(0x4)
	char pad_84_1 : 7;  // 0x54(0x1)
	bool bEnable : 1;  // 0x54(0x1)
	char pad_85_1 : 7;  // 0x55(0x1)
	bool bOnlyDuringInteraction : 1;  // 0x55(0x1)
	char pad_86[2];  // 0x56(0x2)

}; 
// ScriptStruct ControlRig.RigUnit_SetControlColor
// Size: 0x78(Inherited: 0x40) 
struct FRigUnit_SetControlColor : public FRigUnitMutable
{
	struct FName Control;  // 0x40(0x8)
	struct FLinearColor Color;  // 0x48(0x10)
	struct FCachedRigElement CachedControlIndex;  // 0x58(0x20)

}; 
// ScriptStruct ControlRig.RigUnit_AccumulateQuatLerp
// Size: 0xA0(Inherited: 0x8) 
struct FRigUnit_AccumulateQuatLerp : public FRigUnit_AccumulateBase
{
	char pad_8[8];  // 0x8(0x8)
	struct FQuat TargetValue;  // 0x10(0x20)
	struct FQuat InitialValue;  // 0x30(0x20)
	float Blend;  // 0x50(0x4)
	char pad_84_1 : 7;  // 0x54(0x1)
	bool bIntegrateDeltaTime : 1;  // 0x54(0x1)
	char pad_85[11];  // 0x55(0xB)
	struct FQuat Result;  // 0x60(0x20)
	struct FQuat AccumulatedValue;  // 0x80(0x20)

}; 
// ScriptStruct ControlRig.RigUnit_SetControlOffset
// Size: 0xE0(Inherited: 0x40) 
struct FRigUnit_SetControlOffset : public FRigUnitMutable
{
	struct FName Control;  // 0x40(0x8)
	char pad_72[8];  // 0x48(0x8)
	struct FTransform Offset;  // 0x50(0x60)
	uint8_t  Space;  // 0xB0(0x1)
	char pad_177[7];  // 0xB1(0x7)
	struct FCachedRigElement CachedControlIndex;  // 0xB8(0x20)
	char pad_216[8];  // 0xD8(0x8)

}; 
// ScriptStruct ControlRig.RigUnit_GetShapeTransform
// Size: 0x90(Inherited: 0x8) 
struct FRigUnit_GetShapeTransform : public FRigUnit
{
	struct FName Control;  // 0x8(0x8)
	struct FTransform Transform;  // 0x10(0x60)
	struct FCachedRigElement CachedControlIndex;  // 0x70(0x20)

}; 
// Function ControlRig.ControlRigShapeActor.OnTransformChanged
// Size: 0x60(Inherited: 0x0) 
struct FOnTransformChanged
{
	struct FTransform NewTransform;  // 0x0(0x60)

}; 
// ScriptStruct ControlRig.RigUnit_SetControlBool
// Size: 0x70(Inherited: 0x40) 
struct FRigUnit_SetControlBool : public FRigUnitMutable
{
	struct FName Control;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool BoolValue : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)
	struct FCachedRigElement CachedControlIndex;  // 0x50(0x20)

}; 
// Function ControlRig.RigHierarchy.FindNull_ForBlueprintOnly
// Size: 0x400(Inherited: 0x0) 
struct FFindNull_ForBlueprintOnly
{
	struct FRigElementKey InKey;  // 0x0(0xC)
	char pad_12[4];  // 0xC(0x4)
	struct FRigNullElement ReturnValue;  // 0x10(0x3F0)

}; 
// ScriptStruct ControlRig.RigUnit_SetMultiControlBool_Entry
// Size: 0xC(Inherited: 0x0) 
struct FRigUnit_SetMultiControlBool_Entry
{
	struct FName Control;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool BoolValue : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)

}; 
// ScriptStruct ControlRig.RigUnit_SpringInterpQuaternionV2
// Size: 0x130(Inherited: 0x8) 
struct FRigUnit_SpringInterpQuaternionV2 : public FRigUnit_SimBase
{
	char pad_8[8];  // 0x8(0x8)
	struct FQuat Target;  // 0x10(0x20)
	float Strength;  // 0x30(0x4)
	float CriticalDamping;  // 0x34(0x4)
	struct FVector Torque;  // 0x38(0x18)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool bUseCurrentInput : 1;  // 0x50(0x1)
	char pad_81[15];  // 0x51(0xF)
	struct FQuat Current;  // 0x60(0x20)
	float TargetVelocityAmount;  // 0x80(0x4)
	char pad_132_1 : 7;  // 0x84(0x1)
	bool bInitializeFromTarget : 1;  // 0x84(0x1)
	char pad_133[11];  // 0x85(0xB)
	struct FQuat Result;  // 0x90(0x20)
	struct FVector AngularVelocity;  // 0xB0(0x18)
	char pad_200[8];  // 0xC8(0x8)
	struct FQuat SimulatedResult;  // 0xD0(0x20)
	struct FQuaternionSpringState SpringState;  // 0xF0(0x40)

}; 
// ScriptStruct ControlRig.RigUnit_MathDoubleIsNearlyEqual
// Size: 0x28(Inherited: 0x8) 
struct FRigUnit_MathDoubleIsNearlyEqual : public FRigUnit_MathDoubleBase
{
	double A;  // 0x8(0x8)
	double B;  // 0x10(0x8)
	double Tolerance;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool Result : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// ScriptStruct ControlRig.RigUnit_SetControlFloat
// Size: 0x70(Inherited: 0x40) 
struct FRigUnit_SetControlFloat : public FRigUnitMutable
{
	struct FName Control;  // 0x40(0x8)
	float Weight;  // 0x48(0x4)
	float FloatValue;  // 0x4C(0x4)
	struct FCachedRigElement CachedControlIndex;  // 0x50(0x20)

}; 
// ScriptStruct ControlRig.RigUnit_SetControlInteger
// Size: 0x70(Inherited: 0x40) 
struct FRigUnit_SetControlInteger : public FRigUnitMutable
{
	struct FName Control;  // 0x40(0x8)
	int32_t Weight;  // 0x48(0x4)
	int32_t IntegerValue;  // 0x4C(0x4)
	struct FCachedRigElement CachedControlIndex;  // 0x50(0x20)

}; 
// ScriptStruct ControlRig.RigUnit_SetMultiControlInteger_Entry
// Size: 0xC(Inherited: 0x0) 
struct FRigUnit_SetMultiControlInteger_Entry
{
	struct FName Control;  // 0x0(0x8)
	int32_t IntegerValue;  // 0x8(0x4)

}; 
// ScriptStruct ControlRig.RigUnit_SetMultiControlVector2D_Entry
// Size: 0x18(Inherited: 0x0) 
struct FRigUnit_SetMultiControlVector2D_Entry
{
	struct FName Control;  // 0x0(0x8)
	struct FVector2D Vector;  // 0x8(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_SetMultiControlVector2D
// Size: 0x68(Inherited: 0x40) 
struct FRigUnit_SetMultiControlVector2D : public FRigUnitMutable
{
	struct TArray<struct FRigUnit_SetMultiControlVector2D_Entry> Entries;  // 0x40(0x10)
	float Weight;  // 0x50(0x4)
	char pad_84[4];  // 0x54(0x4)
	struct TArray<struct FCachedRigElement> CachedControlIndices;  // 0x58(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_SetMultiControlRotator
// Size: 0x68(Inherited: 0x40) 
struct FRigUnit_SetMultiControlRotator : public FRigUnitMutable
{
	struct TArray<struct FRigUnit_SetMultiControlRotator_Entry> Entries;  // 0x40(0x10)
	float Weight;  // 0x50(0x4)
	char pad_84[4];  // 0x54(0x4)
	struct TArray<struct FCachedRigElement> CachedControlIndices;  // 0x58(0x10)

}; 
// Function ControlRig.RigHierarchy.GetControlPreferredRotator
// Size: 0x28(Inherited: 0x0) 
struct FGetControlPreferredRotator
{
	struct FRigElementKey InKey;  // 0x0(0xC)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool bInitial : 1;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)
	struct FRotator ReturnValue;  // 0x10(0x18)

}; 
// ScriptStruct ControlRig.RigUnit_GetControlVisibility
// Size: 0x38(Inherited: 0x8) 
struct FRigUnit_GetControlVisibility : public FRigUnit
{
	struct FRigElementKey Item;  // 0x8(0xC)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool bVisible : 1;  // 0x14(0x1)
	char pad_21[3];  // 0x15(0x3)
	struct FCachedRigElement CachedControlIndex;  // 0x18(0x20)

}; 
// Function ControlRig.ControlRigComponent.AddMappedComponents
// Size: 0x10(Inherited: 0x0) 
struct FAddMappedComponents
{
	struct TArray<struct FControlRigComponentMappedComponent> Components;  // 0x0(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_SetCurveValue
// Size: 0x70(Inherited: 0x40) 
struct FRigUnit_SetCurveValue : public FRigUnitMutable
{
	struct FName Curve;  // 0x40(0x8)
	float Value;  // 0x48(0x4)
	char pad_76[4];  // 0x4C(0x4)
	struct FCachedRigElement CachedCurveIndex;  // 0x50(0x20)

}; 
// ScriptStruct ControlRig.RigUnit_SetRelativeBoneTransform
// Size: 0x100(Inherited: 0x40) 
struct FRigUnit_SetRelativeBoneTransform : public FRigUnitMutable
{
	struct FName bone;  // 0x40(0x8)
	struct FName Space;  // 0x48(0x8)
	struct FTransform Transform;  // 0x50(0x60)
	float Weight;  // 0xB0(0x4)
	char pad_180_1 : 7;  // 0xB4(0x1)
	bool bPropagateToChildren : 1;  // 0xB4(0x1)
	char pad_181[3];  // 0xB5(0x3)
	struct FCachedRigElement CachedBone;  // 0xB8(0x20)
	struct FCachedRigElement CachedSpaceIndex;  // 0xD8(0x20)
	char pad_248[8];  // 0xF8(0x8)

}; 
// ScriptStruct ControlRig.RigUnit_MathFloatExponential
// Size: 0x10(Inherited: 0x10) 
struct FRigUnit_MathFloatExponential : public FRigUnit_MathFloatUnaryOp
{

}; 
// ScriptStruct ControlRig.RigUnit_SetRelativeTranslationForItem
// Size: 0xC0(Inherited: 0x40) 
struct FRigUnit_SetRelativeTranslationForItem : public FRigUnitMutable
{
	struct FRigElementKey Child;  // 0x40(0xC)
	struct FRigElementKey Parent;  // 0x4C(0xC)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool bParentInitial : 1;  // 0x58(0x1)
	char pad_89[7];  // 0x59(0x7)
	struct FVector Value;  // 0x60(0x18)
	float Weight;  // 0x78(0x4)
	char pad_124_1 : 7;  // 0x7C(0x1)
	bool bPropagateToChildren : 1;  // 0x7C(0x1)
	char pad_125[3];  // 0x7D(0x3)
	struct FCachedRigElement CachedChild;  // 0x80(0x20)
	struct FCachedRigElement CachedParent;  // 0xA0(0x20)

}; 
// ScriptStruct ControlRig.RigUnit_SetScale
// Size: 0x90(Inherited: 0x40) 
struct FRigUnit_SetScale : public FRigUnitMutable
{
	struct FRigElementKey Item;  // 0x40(0xC)
	uint8_t  Space;  // 0x4C(0x1)
	char pad_77_1 : 7;  // 0x4D(0x1)
	bool bInitial : 1;  // 0x4D(0x1)
	char pad_78[2];  // 0x4E(0x2)
	struct FVector Scale;  // 0x50(0x18)
	float Weight;  // 0x68(0x4)
	char pad_108_1 : 7;  // 0x6C(0x1)
	bool bPropagateToChildren : 1;  // 0x6C(0x1)
	char pad_109[3];  // 0x6D(0x3)
	struct FCachedRigElement CachedIndex;  // 0x70(0x20)

}; 
// ScriptStruct ControlRig.RigUnit_SetTransformArray
// Size: 0x80(Inherited: 0x40) 
struct FRigUnit_SetTransformArray : public FRigUnitMutable
{
	struct FRigElementKeyCollection Items;  // 0x40(0x10)
	uint8_t  Space;  // 0x50(0x1)
	char pad_81_1 : 7;  // 0x51(0x1)
	bool bInitial : 1;  // 0x51(0x1)
	char pad_82[6];  // 0x52(0x6)
	struct TArray<struct FTransform> Transforms;  // 0x58(0x10)
	float Weight;  // 0x68(0x4)
	char pad_108_1 : 7;  // 0x6C(0x1)
	bool bPropagateToChildren : 1;  // 0x6C(0x1)
	char pad_109[3];  // 0x6D(0x3)
	struct TArray<struct FCachedRigElement> CachedIndex;  // 0x70(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_DeltaFromPreviousTransform
// Size: 0x190(Inherited: 0x8) 
struct FRigUnit_DeltaFromPreviousTransform : public FRigUnit_SimBase
{
	char pad_8[8];  // 0x8(0x8)
	struct FTransform Value;  // 0x10(0x60)
	struct FTransform Delta;  // 0x70(0x60)
	struct FTransform PreviousValue;  // 0xD0(0x60)
	struct FTransform Cache;  // 0x130(0x60)

}; 
// ScriptStruct ControlRig.RigUnit_ToRigSpace_Rotation
// Size: 0x50(Inherited: 0x8) 
struct FRigUnit_ToRigSpace_Rotation : public FRigUnit
{
	char pad_8[8];  // 0x8(0x8)
	struct FQuat Value;  // 0x10(0x20)
	struct FQuat Global;  // 0x30(0x20)

}; 
// ScriptStruct ControlRig.RigUnit_ParentConstraint_AdvancedSettings
// Size: 0x2(Inherited: 0x0) 
struct FRigUnit_ParentConstraint_AdvancedSettings
{
	uint8_t  InterpolationType;  // 0x0(0x1)
	uint8_t  RotationOrderForFilter;  // 0x1(0x1)

}; 
// ScriptStruct ControlRig.RigUnit_BoneHarmonics_WorkData
// Size: 0x28(Inherited: 0x0) 
struct FRigUnit_BoneHarmonics_WorkData
{
	struct TArray<struct FCachedRigElement> CachedItems;  // 0x0(0x10)
	struct FVector WaveTime;  // 0x10(0x18)

}; 
// ScriptStruct ControlRig.RigUnit_MathColorSub
// Size: 0x38(Inherited: 0x38) 
struct FRigUnit_MathColorSub : public FRigUnit_MathColorBinaryOp
{

}; 
// ScriptStruct ControlRig.RigUnit_ItemHarmonics
// Size: 0x100(Inherited: 0x40) 
struct FRigUnit_ItemHarmonics : public FRigUnit_HighlevelBaseMutable
{
	struct TArray<struct FRigUnit_Harmonics_TargetItem> Targets;  // 0x40(0x10)
	struct FVector WaveSpeed;  // 0x50(0x18)
	struct FVector WaveFrequency;  // 0x68(0x18)
	struct FVector WaveAmplitude;  // 0x80(0x18)
	struct FVector WaveOffset;  // 0x98(0x18)
	struct FVector WaveNoise;  // 0xB0(0x18)
	uint8_t  WaveEase;  // 0xC8(0x1)
	char pad_201[3];  // 0xC9(0x3)
	float WaveMinimum;  // 0xCC(0x4)
	float WaveMaximum;  // 0xD0(0x4)
	uint8_t  RotationOrder;  // 0xD4(0x1)
	char pad_213[3];  // 0xD5(0x3)
	struct FRigUnit_BoneHarmonics_WorkData WorkData;  // 0xD8(0x28)

}; 
// ScriptStruct ControlRig.RigUnit_MultiFABRIK_WorkData
// Size: 0x68(Inherited: 0x0) 
struct FRigUnit_MultiFABRIK_WorkData
{
	char pad_0[104];  // 0x0(0x68)

}; 
// ScriptStruct ControlRig.RigUnit_ChainHarmonics_Reach
// Size: 0x48(Inherited: 0x0) 
struct FRigUnit_ChainHarmonics_Reach
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bEnabled : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FVector ReachTarget;  // 0x8(0x18)
	struct FVector ReachAxis;  // 0x20(0x18)
	float ReachMinimum;  // 0x38(0x4)
	float ReachMaximum;  // 0x3C(0x4)
	uint8_t  ReachEase;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)

}; 
// ScriptStruct ControlRig.RigUnit_MathDoubleBinaryOp
// Size: 0x20(Inherited: 0x8) 
struct FRigUnit_MathDoubleBinaryOp : public FRigUnit_MathDoubleBase
{
	double A;  // 0x8(0x8)
	double B;  // 0x10(0x8)
	double Result;  // 0x18(0x8)

}; 
// ScriptStruct ControlRig.RigUnit_ChainHarmonics_Wave
// Size: 0x78(Inherited: 0x0) 
struct FRigUnit_ChainHarmonics_Wave
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bEnabled : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FVector WaveFrequency;  // 0x8(0x18)
	struct FVector WaveAmplitude;  // 0x20(0x18)
	struct FVector WaveOffset;  // 0x38(0x18)
	struct FVector WaveNoise;  // 0x50(0x18)
	float WaveMinimum;  // 0x68(0x4)
	float WaveMaximum;  // 0x6C(0x4)
	uint8_t  WaveEase;  // 0x70(0x1)
	char pad_113[7];  // 0x71(0x7)

}; 
// ScriptStruct ControlRig.RigUnit_ChainHarmonicsPerItem
// Size: 0x310(Inherited: 0x40) 
struct FRigUnit_ChainHarmonicsPerItem : public FRigUnit_HighlevelBaseMutable
{
	struct FRigElementKey ChainRoot;  // 0x40(0xC)
	char pad_76[4];  // 0x4C(0x4)
	struct FVector Speed;  // 0x50(0x18)
	struct FRigUnit_ChainHarmonics_Reach Reach;  // 0x68(0x48)
	struct FRigUnit_ChainHarmonics_Wave Wave;  // 0xB0(0x78)
	struct FRuntimeFloatCurve WaveCurve;  // 0x128(0x88)
	struct FRigUnit_ChainHarmonics_Pendulum Pendulum;  // 0x1B0(0x58)
	char pad_520_1 : 7;  // 0x208(0x1)
	bool bDrawDebug : 1;  // 0x208(0x1)
	char pad_521[7];  // 0x209(0x7)
	struct FTransform DrawWorldOffset;  // 0x210(0x60)
	struct FRigUnit_ChainHarmonics_WorkData WorkData;  // 0x270(0x98)
	char pad_776[8];  // 0x308(0x8)

}; 
// ScriptStruct ControlRig.MathRBFInterpolateVectorColor_Target
// Size: 0x28(Inherited: 0x0) 
struct FMathRBFInterpolateVectorColor_Target
{
	struct FVector Target;  // 0x0(0x18)
	struct FLinearColor Value;  // 0x18(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_MathIntLess
// Size: 0x18(Inherited: 0x8) 
struct FRigUnit_MathIntLess : public FRigUnit_MathIntBase
{
	int32_t A;  // 0x8(0x4)
	int32_t B;  // 0xC(0x4)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool Result : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// ScriptStruct ControlRig.RigUnit_AimItem_Target
// Size: 0x48(Inherited: 0x0) 
struct FRigUnit_AimItem_Target
{
	float Weight;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FVector Axis;  // 0x8(0x18)
	struct FVector Target;  // 0x20(0x18)
	uint8_t  Kind;  // 0x38(0x1)
	char pad_57[3];  // 0x39(0x3)
	struct FRigElementKey Space;  // 0x3C(0xC)

}; 
// ScriptStruct ControlRig.RigUnit_AimConstraint_WorldUp
// Size: 0x28(Inherited: 0x0) 
struct FRigUnit_AimConstraint_WorldUp
{
	struct FVector Target;  // 0x0(0x18)
	uint8_t  Kind;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)
	struct FRigElementKey Space;  // 0x1C(0xC)

}; 
// ScriptStruct ControlRig.RigUnit_MathDoubleLerp
// Size: 0x28(Inherited: 0x8) 
struct FRigUnit_MathDoubleLerp : public FRigUnit_MathDoubleBase
{
	double A;  // 0x8(0x8)
	double B;  // 0x10(0x8)
	double T;  // 0x18(0x8)
	double Result;  // 0x20(0x8)

}; 
// ScriptStruct ControlRig.RigUnit_AimConstraint_AdvancedSettings
// Size: 0x80(Inherited: 0x0) 
struct FRigUnit_AimConstraint_AdvancedSettings
{
	struct FRigUnit_AimBone_DebugSettings DebugSettings;  // 0x0(0x70)
	uint8_t  RotationOrderForFilter;  // 0x70(0x1)
	char pad_113[15];  // 0x71(0xF)

}; 
// ScriptStruct ControlRig.RigUnit_AimConstraintLocalSpaceOffset
// Size: 0x1A0(Inherited: 0x40) 
struct FRigUnit_AimConstraintLocalSpaceOffset : public FRigUnit_HighlevelBaseMutable
{
	struct FRigElementKey Child;  // 0x40(0xC)
	char pad_76_1 : 7;  // 0x4C(0x1)
	bool bMaintainOffset : 1;  // 0x4C(0x1)
	struct FFilterOptionPerAxis Filter;  // 0x4D(0x3)
	struct FVector AimAxis;  // 0x50(0x18)
	struct FVector UpAxis;  // 0x68(0x18)
	struct FRigUnit_AimConstraint_WorldUp WorldUp;  // 0x80(0x28)
	struct TArray<struct FConstraintParent> Parents;  // 0xA8(0x10)
	char pad_184[8];  // 0xB8(0x8)
	struct FRigUnit_AimConstraint_AdvancedSettings AdvancedSettings;  // 0xC0(0x80)
	float Weight;  // 0x140(0x4)
	char pad_324[4];  // 0x144(0x4)
	struct FCachedRigElement WorldUpSpaceCache;  // 0x148(0x20)
	struct FCachedRigElement ChildCache;  // 0x168(0x20)
	struct TArray<struct FCachedRigElement> ParentCaches;  // 0x188(0x10)
	char pad_408[8];  // 0x198(0x8)

}; 
// Function ControlRig.RigHierarchy.SetControlOffsetTransformByIndex
// Size: 0x80(Inherited: 0x0) 
struct FSetControlOffsetTransformByIndex
{
	int32_t InElementIndex;  // 0x0(0x4)
	char pad_4[12];  // 0x4(0xC)
	struct FTransform InTransform;  // 0x10(0x60)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool bInitial : 1;  // 0x70(0x1)
	char pad_113_1 : 7;  // 0x71(0x1)
	bool bAffectChildren : 1;  // 0x71(0x1)
	char pad_114_1 : 7;  // 0x72(0x1)
	bool bSetupUndo : 1;  // 0x72(0x1)
	char pad_115_1 : 7;  // 0x73(0x1)
	bool bPrintPythonCommands : 1;  // 0x73(0x1)
	char pad_116[12];  // 0x74(0xC)

}; 
// ScriptStruct ControlRig.RigUnit_CCDIK_RotationLimitPerItem
// Size: 0x10(Inherited: 0x0) 
struct FRigUnit_CCDIK_RotationLimitPerItem
{
	struct FRigElementKey Item;  // 0x0(0xC)
	float Limit;  // 0xC(0x4)

}; 
// ScriptStruct ControlRig.RigUnit_CCDIK_WorkData
// Size: 0x60(Inherited: 0x0) 
struct FRigUnit_CCDIK_WorkData
{
	struct TArray<struct FCCDIKChainLink> Chain;  // 0x0(0x10)
	struct TArray<struct FCachedRigElement> CachedItems;  // 0x10(0x10)
	struct TArray<int32_t> RotationLimitIndex;  // 0x20(0x10)
	struct TArray<float> RotationLimitsPerItem;  // 0x30(0x10)
	struct FCachedRigElement CachedEffector;  // 0x40(0x20)

}; 
// Function ControlRig.RigHierarchy.MakeControlValueFromTransformNoScale
// Size: 0x130(Inherited: 0x0) 
struct FMakeControlValueFromTransformNoScale
{
	struct FTransformNoScale InValue;  // 0x0(0x40)
	struct FRigControlValue ReturnValue;  // 0x40(0xF0)

}; 
// ScriptStruct ControlRig.RigUnit_AccumulateTransformLerp
// Size: 0x1A0(Inherited: 0x8) 
struct FRigUnit_AccumulateTransformLerp : public FRigUnit_AccumulateBase
{
	char pad_8[8];  // 0x8(0x8)
	struct FTransform TargetValue;  // 0x10(0x60)
	struct FTransform InitialValue;  // 0x70(0x60)
	float Blend;  // 0xD0(0x4)
	char pad_212_1 : 7;  // 0xD4(0x1)
	bool bIntegrateDeltaTime : 1;  // 0xD4(0x1)
	char pad_213[11];  // 0xD5(0xB)
	struct FTransform Result;  // 0xE0(0x60)
	struct FTransform AccumulatedValue;  // 0x140(0x60)

}; 
// ScriptStruct ControlRig.RigUnit_CCDIKPerItem
// Size: 0x140(Inherited: 0x40) 
struct FRigUnit_CCDIKPerItem : public FRigUnit_HighlevelBaseMutable
{
	struct FRigElementKeyCollection Items;  // 0x40(0x10)
	struct FTransform EffectorTransform;  // 0x50(0x60)
	float Precision;  // 0xB0(0x4)
	float Weight;  // 0xB4(0x4)
	int32_t MaxIterations;  // 0xB8(0x4)
	char pad_188_1 : 7;  // 0xBC(0x1)
	bool bStartFromTail : 1;  // 0xBC(0x1)
	char pad_189[3];  // 0xBD(0x3)
	float BaseRotationLimit;  // 0xC0(0x4)
	char pad_196[4];  // 0xC4(0x4)
	struct TArray<struct FRigUnit_CCDIK_RotationLimitPerItem> RotationLimits;  // 0xC8(0x10)
	char pad_216_1 : 7;  // 0xD8(0x1)
	bool bPropagateToChildren : 1;  // 0xD8(0x1)
	char pad_217[7];  // 0xD9(0x7)
	struct FRigUnit_CCDIK_WorkData WorkData;  // 0xE0(0x60)

}; 
// ScriptStruct ControlRig.RigUnit_MathVectorNotEquals
// Size: 0x40(Inherited: 0x8) 
struct FRigUnit_MathVectorNotEquals : public FRigUnit_MathVectorBase
{
	struct FVector A;  // 0x8(0x18)
	struct FVector B;  // 0x20(0x18)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool Result : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)

}; 
// ScriptStruct ControlRig.RigUnit_CCDIKItemArray
// Size: 0x140(Inherited: 0x40) 
struct FRigUnit_CCDIKItemArray : public FRigUnit_HighlevelBaseMutable
{
	struct TArray<struct FRigElementKey> Items;  // 0x40(0x10)
	struct FTransform EffectorTransform;  // 0x50(0x60)
	float Precision;  // 0xB0(0x4)
	float Weight;  // 0xB4(0x4)
	int32_t MaxIterations;  // 0xB8(0x4)
	char pad_188_1 : 7;  // 0xBC(0x1)
	bool bStartFromTail : 1;  // 0xBC(0x1)
	char pad_189[3];  // 0xBD(0x3)
	float BaseRotationLimit;  // 0xC0(0x4)
	char pad_196[4];  // 0xC4(0x4)
	struct TArray<struct FRigUnit_CCDIK_RotationLimitPerItem> RotationLimits;  // 0xC8(0x10)
	char pad_216_1 : 7;  // 0xD8(0x1)
	bool bPropagateToChildren : 1;  // 0xD8(0x1)
	char pad_217[7];  // 0xD9(0x7)
	struct FRigUnit_CCDIK_WorkData WorkData;  // 0xE0(0x60)

}; 
// ScriptStruct ControlRig.RigUnit_DistributeRotation_Rotation
// Size: 0x30(Inherited: 0x0) 
struct FRigUnit_DistributeRotation_Rotation
{
	struct FQuat Rotation;  // 0x0(0x20)
	float Ratio;  // 0x20(0x4)
	char pad_36[12];  // 0x24(0xC)

}; 
// ScriptStruct ControlRig.RigUnit_AccumulateQuatMul
// Size: 0xA0(Inherited: 0x8) 
struct FRigUnit_AccumulateQuatMul : public FRigUnit_AccumulateBase
{
	char pad_8[8];  // 0x8(0x8)
	struct FQuat Multiplier;  // 0x10(0x20)
	struct FQuat InitialValue;  // 0x30(0x20)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool bFlipOrder : 1;  // 0x50(0x1)
	char pad_81_1 : 7;  // 0x51(0x1)
	bool bIntegrateDeltaTime : 1;  // 0x51(0x1)
	char pad_82[14];  // 0x52(0xE)
	struct FQuat Result;  // 0x60(0x20)
	struct FQuat AccumulatedValue;  // 0x80(0x20)

}; 
// ScriptStruct ControlRig.RigUnit_DistributeRotation_WorkData
// Size: 0x50(Inherited: 0x0) 
struct FRigUnit_DistributeRotation_WorkData
{
	struct TArray<struct FCachedRigElement> CachedItems;  // 0x0(0x10)
	struct TArray<int32_t> ItemRotationA;  // 0x10(0x10)
	struct TArray<int32_t> ItemRotationB;  // 0x20(0x10)
	struct TArray<float> ItemRotationT;  // 0x30(0x10)
	struct TArray<struct FTransform> ItemLocalTransforms;  // 0x40(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_DistributeRotation
// Size: 0xC0(Inherited: 0x40) 
struct FRigUnit_DistributeRotation : public FRigUnit_HighlevelBaseMutable
{
	struct FName StartBone;  // 0x40(0x8)
	struct FName EndBone;  // 0x48(0x8)
	struct TArray<struct FRigUnit_DistributeRotation_Rotation> Rotations;  // 0x50(0x10)
	uint8_t  RotationEaseType;  // 0x60(0x1)
	char pad_97[3];  // 0x61(0x3)
	float Weight;  // 0x64(0x4)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool bPropagateToChildren : 1;  // 0x68(0x1)
	char pad_105[7];  // 0x69(0x7)
	struct FRigUnit_DistributeRotation_WorkData WorkData;  // 0x70(0x50)

}; 
// ScriptStruct ControlRig.RigUnit_DistributeRotationForCollection
// Size: 0xB8(Inherited: 0x40) 
struct FRigUnit_DistributeRotationForCollection : public FRigUnit_HighlevelBaseMutable
{
	struct FRigElementKeyCollection Items;  // 0x40(0x10)
	struct TArray<struct FRigUnit_DistributeRotation_Rotation> Rotations;  // 0x50(0x10)
	uint8_t  RotationEaseType;  // 0x60(0x1)
	char pad_97[3];  // 0x61(0x3)
	float Weight;  // 0x64(0x4)
	struct FRigUnit_DistributeRotation_WorkData WorkData;  // 0x68(0x50)

}; 
// ScriptStruct ControlRig.RigUnit_FABRIK_WorkData
// Size: 0x40(Inherited: 0x0) 
struct FRigUnit_FABRIK_WorkData
{
	struct TArray<struct FFABRIKChainLink> Chain;  // 0x0(0x10)
	struct TArray<struct FCachedRigElement> CachedItems;  // 0x10(0x10)
	struct FCachedRigElement CachedEffector;  // 0x20(0x20)

}; 
// ScriptStruct ControlRig.RigUnit_MathVectorDeg
// Size: 0x38(Inherited: 0x38) 
struct FRigUnit_MathVectorDeg : public FRigUnit_MathVectorUnaryOp
{

}; 
// ScriptStruct ControlRig.RigUnit_FABRIK
// Size: 0x110(Inherited: 0x40) 
struct FRigUnit_FABRIK : public FRigUnit_HighlevelBaseMutable
{
	struct FName StartBone;  // 0x40(0x8)
	struct FName EffectorBone;  // 0x48(0x8)
	struct FTransform EffectorTransform;  // 0x50(0x60)
	float Precision;  // 0xB0(0x4)
	float Weight;  // 0xB4(0x4)
	char pad_184_1 : 7;  // 0xB8(0x1)
	bool bPropagateToChildren : 1;  // 0xB8(0x1)
	char pad_185[3];  // 0xB9(0x3)
	int32_t MaxIterations;  // 0xBC(0x4)
	struct FRigUnit_FABRIK_WorkData WorkData;  // 0xC0(0x40)
	char pad_256_1 : 7;  // 0x100(0x1)
	bool bSetEffectorTransform : 1;  // 0x100(0x1)
	char pad_257[15];  // 0x101(0xF)

}; 
// ScriptStruct ControlRig.RigUnit_MathQuaternionMirrorTransform
// Size: 0xC0(Inherited: 0x8) 
struct FRigUnit_MathQuaternionMirrorTransform : public FRigUnit_MathQuaternionBase
{
	char pad_8[8];  // 0x8(0x8)
	struct FQuat Value;  // 0x10(0x20)
	char EAxis MirrorAxis;  // 0x30(0x1)
	char EAxis AxisToFlip;  // 0x31(0x1)
	char pad_50[14];  // 0x32(0xE)
	struct FTransform CentralTransform;  // 0x40(0x60)
	struct FQuat Result;  // 0xA0(0x20)

}; 
// ScriptStruct ControlRig.RigUnit_FABRIKPerItem
// Size: 0x110(Inherited: 0x40) 
struct FRigUnit_FABRIKPerItem : public FRigUnit_HighlevelBaseMutable
{
	struct FRigElementKeyCollection Items;  // 0x40(0x10)
	struct FTransform EffectorTransform;  // 0x50(0x60)
	float Precision;  // 0xB0(0x4)
	float Weight;  // 0xB4(0x4)
	char pad_184_1 : 7;  // 0xB8(0x1)
	bool bPropagateToChildren : 1;  // 0xB8(0x1)
	char pad_185[3];  // 0xB9(0x3)
	int32_t MaxIterations;  // 0xBC(0x4)
	struct FRigUnit_FABRIK_WorkData WorkData;  // 0xC0(0x40)
	char pad_256_1 : 7;  // 0x100(0x1)
	bool bSetEffectorTransform : 1;  // 0x100(0x1)
	char pad_257[15];  // 0x101(0xF)

}; 
// ScriptStruct ControlRig.RigUnit_FABRIKItemArray
// Size: 0x110(Inherited: 0x40) 
struct FRigUnit_FABRIKItemArray : public FRigUnit_HighlevelBaseMutable
{
	struct TArray<struct FRigElementKey> Items;  // 0x40(0x10)
	struct FTransform EffectorTransform;  // 0x50(0x60)
	float Precision;  // 0xB0(0x4)
	float Weight;  // 0xB4(0x4)
	char pad_184_1 : 7;  // 0xB8(0x1)
	bool bPropagateToChildren : 1;  // 0xB8(0x1)
	char pad_185[3];  // 0xB9(0x3)
	int32_t MaxIterations;  // 0xBC(0x4)
	struct FRigUnit_FABRIK_WorkData WorkData;  // 0xC0(0x40)
	char pad_256_1 : 7;  // 0x100(0x1)
	bool bSetEffectorTransform : 1;  // 0x100(0x1)
	char pad_257[15];  // 0x101(0xF)

}; 
// ScriptStruct ControlRig.RigUnit_FitChainToCurve
// Size: 0x260(Inherited: 0x40) 
struct FRigUnit_FitChainToCurve : public FRigUnit_HighlevelBaseMutable
{
	struct FName StartBone;  // 0x40(0x8)
	struct FName EndBone;  // 0x48(0x8)
	struct FCRFourPointBezier Bezier;  // 0x50(0x60)
	uint8_t  Alignment;  // 0xB0(0x1)
	char pad_177[3];  // 0xB1(0x3)
	float Minimum;  // 0xB4(0x4)
	float Maximum;  // 0xB8(0x4)
	int32_t SamplingPrecision;  // 0xBC(0x4)
	struct FVector PrimaryAxis;  // 0xC0(0x18)
	struct FVector SecondaryAxis;  // 0xD8(0x18)
	struct FVector PoleVectorPosition;  // 0xF0(0x18)
	struct TArray<struct FRigUnit_FitChainToCurve_Rotation> Rotations;  // 0x108(0x10)
	uint8_t  RotationEaseType;  // 0x118(0x1)
	char pad_281[3];  // 0x119(0x3)
	float Weight;  // 0x11C(0x4)
	char pad_288_1 : 7;  // 0x120(0x1)
	bool bPropagateToChildren : 1;  // 0x120(0x1)
	char pad_289[15];  // 0x121(0xF)
	struct FRigUnit_FitChainToCurve_DebugSettings DebugSettings;  // 0x130(0x90)
	struct FRigUnit_FitChainToCurve_WorkData WorkData;  // 0x1C0(0x98)
	char pad_600[8];  // 0x258(0x8)

}; 
// ScriptStruct ControlRig.RigUnit_MathIntUnaryOp
// Size: 0x10(Inherited: 0x8) 
struct FRigUnit_MathIntUnaryOp : public FRigUnit_MathIntBase
{
	int32_t Value;  // 0x8(0x4)
	int32_t Result;  // 0xC(0x4)

}; 
// ScriptStruct ControlRig.RigUnit_FitChainToCurvePerItem
// Size: 0x260(Inherited: 0x40) 
struct FRigUnit_FitChainToCurvePerItem : public FRigUnit_HighlevelBaseMutable
{
	struct FRigElementKeyCollection Items;  // 0x40(0x10)
	struct FCRFourPointBezier Bezier;  // 0x50(0x60)
	uint8_t  Alignment;  // 0xB0(0x1)
	char pad_177[3];  // 0xB1(0x3)
	float Minimum;  // 0xB4(0x4)
	float Maximum;  // 0xB8(0x4)
	int32_t SamplingPrecision;  // 0xBC(0x4)
	struct FVector PrimaryAxis;  // 0xC0(0x18)
	struct FVector SecondaryAxis;  // 0xD8(0x18)
	struct FVector PoleVectorPosition;  // 0xF0(0x18)
	struct TArray<struct FRigUnit_FitChainToCurve_Rotation> Rotations;  // 0x108(0x10)
	uint8_t  RotationEaseType;  // 0x118(0x1)
	char pad_281[3];  // 0x119(0x3)
	float Weight;  // 0x11C(0x4)
	char pad_288_1 : 7;  // 0x120(0x1)
	bool bPropagateToChildren : 1;  // 0x120(0x1)
	char pad_289[15];  // 0x121(0xF)
	struct FRigUnit_FitChainToCurve_DebugSettings DebugSettings;  // 0x130(0x90)
	struct FRigUnit_FitChainToCurve_WorkData WorkData;  // 0x1C0(0x98)
	char pad_600[8];  // 0x258(0x8)

}; 
// ScriptStruct ControlRig.RigUnit_FitChainToCurveItemArray
// Size: 0x260(Inherited: 0x40) 
struct FRigUnit_FitChainToCurveItemArray : public FRigUnit_HighlevelBaseMutable
{
	struct TArray<struct FRigElementKey> Items;  // 0x40(0x10)
	struct FCRFourPointBezier Bezier;  // 0x50(0x60)
	uint8_t  Alignment;  // 0xB0(0x1)
	char pad_177[3];  // 0xB1(0x3)
	float Minimum;  // 0xB4(0x4)
	float Maximum;  // 0xB8(0x4)
	int32_t SamplingPrecision;  // 0xBC(0x4)
	struct FVector PrimaryAxis;  // 0xC0(0x18)
	struct FVector SecondaryAxis;  // 0xD8(0x18)
	struct FVector PoleVectorPosition;  // 0xF0(0x18)
	struct TArray<struct FRigUnit_FitChainToCurve_Rotation> Rotations;  // 0x108(0x10)
	uint8_t  RotationEaseType;  // 0x118(0x1)
	char pad_281[3];  // 0x119(0x3)
	float Weight;  // 0x11C(0x4)
	char pad_288_1 : 7;  // 0x120(0x1)
	bool bPropagateToChildren : 1;  // 0x120(0x1)
	char pad_289[15];  // 0x121(0xF)
	struct FRigUnit_FitChainToCurve_DebugSettings DebugSettings;  // 0x130(0x90)
	struct FRigUnit_FitChainToCurve_WorkData WorkData;  // 0x1C0(0x98)
	char pad_600[8];  // 0x258(0x8)

}; 
// ScriptStruct ControlRig.RigUnit_ModifyBoneTransforms_PerBone
// Size: 0x70(Inherited: 0x0) 
struct FRigUnit_ModifyBoneTransforms_PerBone
{
	struct FName bone;  // 0x0(0x8)
	char pad_8[8];  // 0x8(0x8)
	struct FTransform Transform;  // 0x10(0x60)

}; 
// ScriptStruct ControlRig.RigUnit_ModifyTransforms_WorkData
// Size: 0x10(Inherited: 0x0) 
struct FRigUnit_ModifyTransforms_WorkData
{
	struct TArray<struct FCachedRigElement> CachedItems;  // 0x0(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_ModifyBoneTransforms_WorkData
// Size: 0x10(Inherited: 0x10) 
struct FRigUnit_ModifyBoneTransforms_WorkData : public FRigUnit_ModifyTransforms_WorkData
{

}; 
// ScriptStruct ControlRig.RigUnit_ModifyBoneTransforms
// Size: 0x70(Inherited: 0x40) 
struct FRigUnit_ModifyBoneTransforms : public FRigUnit_HighlevelBaseMutable
{
	struct TArray<struct FRigUnit_ModifyBoneTransforms_PerBone> BoneToModify;  // 0x40(0x10)
	float Weight;  // 0x50(0x4)
	float WeightMinimum;  // 0x54(0x4)
	float WeightMaximum;  // 0x58(0x4)
	uint8_t  Mode;  // 0x5C(0x1)
	char pad_93[3];  // 0x5D(0x3)
	struct FRigUnit_ModifyBoneTransforms_WorkData WorkData;  // 0x60(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_ModifyTransforms_PerItem
// Size: 0x70(Inherited: 0x0) 
struct FRigUnit_ModifyTransforms_PerItem
{
	struct FRigElementKey Item;  // 0x0(0xC)
	char pad_12[4];  // 0xC(0x4)
	struct FTransform Transform;  // 0x10(0x60)

}; 
// ScriptStruct ControlRig.RigUnit_NoiseVector2
// Size: 0x90(Inherited: 0x8) 
struct FRigUnit_NoiseVector2 : public FRigUnit_MathBase
{
	struct FVector Value;  // 0x8(0x18)
	struct FVector Speed;  // 0x20(0x18)
	struct FVector Frequency;  // 0x38(0x18)
	double Minimum;  // 0x50(0x8)
	double Maximum;  // 0x58(0x8)
	struct FVector Result;  // 0x60(0x18)
	struct FVector time;  // 0x78(0x18)

}; 
// ScriptStruct ControlRig.RigUnit_ModifyTransforms
// Size: 0x70(Inherited: 0x40) 
struct FRigUnit_ModifyTransforms : public FRigUnit_HighlevelBaseMutable
{
	struct TArray<struct FRigUnit_ModifyTransforms_PerItem> ItemToModify;  // 0x40(0x10)
	float Weight;  // 0x50(0x4)
	float WeightMinimum;  // 0x54(0x4)
	float WeightMaximum;  // 0x58(0x4)
	uint8_t  Mode;  // 0x5C(0x1)
	char pad_93[3];  // 0x5D(0x3)
	struct FRigUnit_ModifyTransforms_WorkData WorkData;  // 0x60(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_MultiFABRIK_EndEffector
// Size: 0x20(Inherited: 0x0) 
struct FRigUnit_MultiFABRIK_EndEffector
{
	struct FName bone;  // 0x0(0x8)
	struct FVector Location;  // 0x8(0x18)

}; 
// ScriptStruct ControlRig.RigUnit_MathDoubleIsNearlyZero
// Size: 0x20(Inherited: 0x8) 
struct FRigUnit_MathDoubleIsNearlyZero : public FRigUnit_MathDoubleBase
{
	double Value;  // 0x8(0x8)
	double Tolerance;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool Result : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)

}; 
// Function ControlRig.RigHierarchy.SetControlPreferredRotator
// Size: 0x30(Inherited: 0x0) 
struct FSetControlPreferredRotator
{
	struct FRigElementKey InKey;  // 0x0(0xC)
	char pad_12[4];  // 0xC(0x4)
	struct FRotator InValue;  // 0x10(0x18)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool bInitial : 1;  // 0x28(0x1)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool bFixEulerFlips : 1;  // 0x29(0x1)
	char pad_42[6];  // 0x2A(0x6)

}; 
// ScriptStruct ControlRig.RigUnit_SlideChain_WorkData
// Size: 0x48(Inherited: 0x0) 
struct FRigUnit_SlideChain_WorkData
{
	float ChainLength;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct TArray<float> ItemSegments;  // 0x8(0x10)
	struct TArray<struct FCachedRigElement> CachedItems;  // 0x18(0x10)
	struct TArray<struct FTransform> Transforms;  // 0x28(0x10)
	struct TArray<struct FTransform> BlendedTransforms;  // 0x38(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_SlideChainPerItem
// Size: 0xA0(Inherited: 0x40) 
struct FRigUnit_SlideChainPerItem : public FRigUnit_HighlevelBaseMutable
{
	struct FRigElementKeyCollection Items;  // 0x40(0x10)
	float SlideAmount;  // 0x50(0x4)
	char pad_84_1 : 7;  // 0x54(0x1)
	bool bPropagateToChildren : 1;  // 0x54(0x1)
	char pad_85[3];  // 0x55(0x3)
	struct FRigUnit_SlideChain_WorkData WorkData;  // 0x58(0x48)

}; 
// ScriptStruct ControlRig.RigUnit_SphericalPoseReader
// Size: 0x1E0(Inherited: 0x40) 
struct FRigUnit_SphericalPoseReader : public FRigUnit_HighlevelBaseMutable
{
	float OutputParam;  // 0x40(0x4)
	struct FRigElementKey DriverItem;  // 0x44(0xC)
	struct FVector DriverAxis;  // 0x50(0x18)
	struct FVector RotationOffset;  // 0x68(0x18)
	float ActiveRegionSize;  // 0x80(0x4)
	struct FRegionScaleFactors ActiveRegionScaleFactors;  // 0x84(0x10)
	float FalloffSize;  // 0x94(0x4)
	struct FRegionScaleFactors FalloffRegionScaleFactors;  // 0x98(0x10)
	char pad_168_1 : 7;  // 0xA8(0x1)
	bool FlipWidthScaling : 1;  // 0xA8(0x1)
	char pad_169_1 : 7;  // 0xA9(0x1)
	bool FlipHeightScaling : 1;  // 0xA9(0x1)
	char pad_170[2];  // 0xAA(0x2)
	struct FRigElementKey OptionalParentItem;  // 0xAC(0xC)
	struct FSphericalPoseReaderDebugSettings Debug;  // 0xB8(0x10)
	struct FSphericalRegion InnerRegion;  // 0xC8(0x14)
	struct FSphericalRegion OuterRegion;  // 0xDC(0x14)
	struct FVector DriverNormal;  // 0xF0(0x18)
	struct FVector Driver2D;  // 0x108(0x18)
	struct FCachedRigElement DriverCache;  // 0x120(0x20)
	struct FCachedRigElement OptionalParentCache;  // 0x140(0x20)
	struct FTransform LocalDriverTransformInit;  // 0x160(0x60)
	struct FVector CachedRotationOffset;  // 0x1C0(0x18)
	char pad_472_1 : 7;  // 0x1D8(0x1)
	bool bCachedInitTransforms : 1;  // 0x1D8(0x1)
	char pad_473[7];  // 0x1D9(0x7)

}; 
// ScriptStruct ControlRig.RigUnit_SpringIK_DebugSettings
// Size: 0x80(Inherited: 0x0) 
struct FRigUnit_SpringIK_DebugSettings
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bEnabled : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	float Scale;  // 0x4(0x4)
	struct FLinearColor Color;  // 0x8(0x10)
	char pad_24[8];  // 0x18(0x8)
	struct FTransform WorldOffset;  // 0x20(0x60)

}; 
// ScriptStruct ControlRig.RigUnit_SpringIK_WorkData
// Size: 0xB8(Inherited: 0x0) 
struct FRigUnit_SpringIK_WorkData
{
	struct TArray<struct FCachedRigElement> CachedBones;  // 0x0(0x10)
	struct FCachedRigElement CachedPoleVector;  // 0x10(0x20)
	struct TArray<struct FTransform> Transforms;  // 0x30(0x10)
	struct FCRSimPointContainer Simulation;  // 0x40(0x78)

}; 
// ScriptStruct ControlRig.RigUnit_TransformConstraint
// Size: 0x130(Inherited: 0x40) 
struct FRigUnit_TransformConstraint : public FRigUnit_HighlevelBaseMutable
{
	struct FName bone;  // 0x40(0x8)
	uint8_t  BaseTransformSpace;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)
	struct FTransform BaseTransform;  // 0x50(0x60)
	struct FName BaseBone;  // 0xB0(0x8)
	struct TArray<struct FConstraintTarget> Targets;  // 0xB8(0x10)
	char pad_200_1 : 7;  // 0xC8(0x1)
	bool bUseInitialTransforms : 1;  // 0xC8(0x1)
	char pad_201[7];  // 0xC9(0x7)
	struct FRigUnit_TransformConstraint_WorkData WorkData;  // 0xD0(0x60)

}; 
// ScriptStruct ControlRig.RigUnit_TransformConstraintPerItem
// Size: 0x140(Inherited: 0x40) 
struct FRigUnit_TransformConstraintPerItem : public FRigUnit_HighlevelBaseMutable
{
	struct FRigElementKey Item;  // 0x40(0xC)
	uint8_t  BaseTransformSpace;  // 0x4C(0x1)
	char pad_77[3];  // 0x4D(0x3)
	struct FTransform BaseTransform;  // 0x50(0x60)
	struct FRigElementKey BaseItem;  // 0xB0(0xC)
	char pad_188[4];  // 0xBC(0x4)
	struct TArray<struct FConstraintTarget> Targets;  // 0xC0(0x10)
	char pad_208_1 : 7;  // 0xD0(0x1)
	bool bUseInitialTransforms : 1;  // 0xD0(0x1)
	char pad_209[7];  // 0xD1(0x7)
	struct FRigUnit_TransformConstraint_WorkData WorkData;  // 0xD8(0x60)
	char pad_312[8];  // 0x138(0x8)

}; 
// ScriptStruct ControlRig.MathRBFInterpolateQuatColor_Target
// Size: 0x30(Inherited: 0x0) 
struct FMathRBFInterpolateQuatColor_Target
{
	struct FQuat Target;  // 0x0(0x20)
	struct FLinearColor Value;  // 0x20(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_ParentConstraint
// Size: 0xA0(Inherited: 0x40) 
struct FRigUnit_ParentConstraint : public FRigUnit_HighlevelBaseMutable
{
	struct FRigElementKey Child;  // 0x40(0xC)
	char pad_76_1 : 7;  // 0x4C(0x1)
	bool bMaintainOffset : 1;  // 0x4C(0x1)
	struct FTransformFilter Filter;  // 0x4D(0x9)
	char pad_86[2];  // 0x56(0x2)
	struct TArray<struct FConstraintParent> Parents;  // 0x58(0x10)
	struct FRigUnit_ParentConstraint_AdvancedSettings AdvancedSettings;  // 0x68(0x2)
	char pad_106[2];  // 0x6A(0x2)
	float Weight;  // 0x6C(0x4)
	struct FCachedRigElement ChildCache;  // 0x70(0x20)
	struct TArray<struct FCachedRigElement> ParentCaches;  // 0x90(0x10)

}; 
// Function ControlRig.RigHierarchy.SetTransformMetadata
// Size: 0x90(Inherited: 0x0) 
struct FSetTransformMetadata
{
	struct FRigElementKey InItem;  // 0x0(0xC)
	struct FName InMetadataName;  // 0xC(0x8)
	char pad_20[12];  // 0x14(0xC)
	struct FTransform InValue;  // 0x20(0x60)
	char pad_128_1 : 7;  // 0x80(0x1)
	bool ReturnValue : 1;  // 0x80(0x1)
	char pad_129[15];  // 0x81(0xF)

}; 
// ScriptStruct ControlRig.RigUnit_RotationConstraintLocalSpaceOffset
// Size: 0x98(Inherited: 0x40) 
struct FRigUnit_RotationConstraintLocalSpaceOffset : public FRigUnit_HighlevelBaseMutable
{
	struct FRigElementKey Child;  // 0x40(0xC)
	char pad_76_1 : 7;  // 0x4C(0x1)
	bool bMaintainOffset : 1;  // 0x4C(0x1)
	struct FFilterOptionPerAxis Filter;  // 0x4D(0x3)
	struct TArray<struct FConstraintParent> Parents;  // 0x50(0x10)
	struct FRigUnit_RotationConstraint_AdvancedSettings AdvancedSettings;  // 0x60(0x2)
	char pad_98[2];  // 0x62(0x2)
	float Weight;  // 0x64(0x4)
	struct FCachedRigElement ChildCache;  // 0x68(0x20)
	struct TArray<struct FCachedRigElement> ParentCaches;  // 0x88(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_MathDoubleEquals
// Size: 0x20(Inherited: 0x8) 
struct FRigUnit_MathDoubleEquals : public FRigUnit_MathDoubleBase
{
	double A;  // 0x8(0x8)
	double B;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool Result : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)

}; 
// ScriptStruct ControlRig.RigUnit_MathRBFInterpolateQuatVector
// Size: 0x120(Inherited: 0xF0) 
struct FRigUnit_MathRBFInterpolateQuatVector : public FRigUnit_MathRBFInterpolateQuatBase
{
	struct TArray<struct FMathRBFInterpolateQuatVector_Target> Targets;  // 0xF0(0x10)
	struct FVector Output;  // 0x100(0x18)
	char pad_280[8];  // 0x118(0x8)

}; 
// ScriptStruct ControlRig.RigUnit_MathVectorLerp
// Size: 0x58(Inherited: 0x8) 
struct FRigUnit_MathVectorLerp : public FRigUnit_MathVectorBase
{
	struct FVector A;  // 0x8(0x18)
	struct FVector B;  // 0x20(0x18)
	float T;  // 0x38(0x4)
	char pad_60[4];  // 0x3C(0x4)
	struct FVector Result;  // 0x40(0x18)

}; 
// Function ControlRig.RigHierarchy.GetDefaultParent
// Size: 0x18(Inherited: 0x0) 
struct FGetDefaultParent
{
	struct FRigElementKey InKey;  // 0x0(0xC)
	struct FRigElementKey ReturnValue;  // 0xC(0xC)

}; 
// Function ControlRig.RigHierarchy.GetReferenceKeys
// Size: 0x18(Inherited: 0x0) 
struct FGetReferenceKeys
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bTraverse : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct TArray<struct FRigElementKey> ReturnValue;  // 0x8(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_ScaleConstraint
// Size: 0x68(Inherited: 0x40) 
struct FRigUnit_ScaleConstraint : public FRigUnit_HighlevelBaseMutable
{
	struct FRigElementKey Child;  // 0x40(0xC)
	char pad_76_1 : 7;  // 0x4C(0x1)
	bool bMaintainOffset : 1;  // 0x4C(0x1)
	struct FFilterOptionPerAxis Filter;  // 0x4D(0x3)
	struct TArray<struct FConstraintParent> Parents;  // 0x50(0x10)
	float Weight;  // 0x60(0x4)
	char pad_100[4];  // 0x64(0x4)

}; 
// ScriptStruct ControlRig.RigUnit_ScaleConstraintLocalSpaceOffset
// Size: 0x98(Inherited: 0x40) 
struct FRigUnit_ScaleConstraintLocalSpaceOffset : public FRigUnit_HighlevelBaseMutable
{
	struct FRigElementKey Child;  // 0x40(0xC)
	char pad_76_1 : 7;  // 0x4C(0x1)
	bool bMaintainOffset : 1;  // 0x4C(0x1)
	struct FFilterOptionPerAxis Filter;  // 0x4D(0x3)
	struct TArray<struct FConstraintParent> Parents;  // 0x50(0x10)
	float Weight;  // 0x60(0x4)
	char pad_100[4];  // 0x64(0x4)
	struct FCachedRigElement ChildCache;  // 0x68(0x20)
	struct TArray<struct FCachedRigElement> ParentCaches;  // 0x88(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_TwistBones_WorkData
// Size: 0x30(Inherited: 0x0) 
struct FRigUnit_TwistBones_WorkData
{
	struct TArray<struct FCachedRigElement> CachedItems;  // 0x0(0x10)
	struct TArray<float> ItemRatios;  // 0x10(0x10)
	struct TArray<struct FTransform> ItemTransforms;  // 0x20(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_MathDoubleConstTwoPi
// Size: 0x10(Inherited: 0x10) 
struct FRigUnit_MathDoubleConstTwoPi : public FRigUnit_MathDoubleConstant
{

}; 
// ScriptStruct ControlRig.RigUnit_TwistBones
// Size: 0xC0(Inherited: 0x40) 
struct FRigUnit_TwistBones : public FRigUnit_HighlevelBaseMutable
{
	struct FName StartBone;  // 0x40(0x8)
	struct FName EndBone;  // 0x48(0x8)
	struct FVector TwistAxis;  // 0x50(0x18)
	struct FVector PoleAxis;  // 0x68(0x18)
	uint8_t  TwistEaseType;  // 0x80(0x1)
	char pad_129[3];  // 0x81(0x3)
	float Weight;  // 0x84(0x4)
	char pad_136_1 : 7;  // 0x88(0x1)
	bool bPropagateToChildren : 1;  // 0x88(0x1)
	char pad_137[7];  // 0x89(0x7)
	struct FRigUnit_TwistBones_WorkData WorkData;  // 0x90(0x30)

}; 
// ScriptStruct ControlRig.RigUnit_TwoBoneIKSimple_DebugSettings
// Size: 0x70(Inherited: 0x0) 
struct FRigUnit_TwoBoneIKSimple_DebugSettings
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bEnabled : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	float Scale;  // 0x4(0x4)
	char pad_8[8];  // 0x8(0x8)
	struct FTransform WorldOffset;  // 0x10(0x60)

}; 
// ScriptStruct ControlRig.RigUnit_TwoBoneIKSimple
// Size: 0x230(Inherited: 0x40) 
struct FRigUnit_TwoBoneIKSimple : public FRigUnit_HighlevelBaseMutable
{
	struct FName BoneA;  // 0x40(0x8)
	struct FName BoneB;  // 0x48(0x8)
	struct FName EffectorBone;  // 0x50(0x8)
	char pad_88[8];  // 0x58(0x8)
	struct FTransform Effector;  // 0x60(0x60)
	struct FVector PrimaryAxis;  // 0xC0(0x18)
	struct FVector SecondaryAxis;  // 0xD8(0x18)
	float SecondaryAxisWeight;  // 0xF0(0x4)
	char pad_244[4];  // 0xF4(0x4)
	struct FVector PoleVector;  // 0xF8(0x18)
	uint8_t  PoleVectorKind;  // 0x110(0x1)
	char pad_273[3];  // 0x111(0x3)
	struct FName PoleVectorSpace;  // 0x114(0x8)
	char pad_284_1 : 7;  // 0x11C(0x1)
	bool bEnableStretch : 1;  // 0x11C(0x1)
	char pad_285[3];  // 0x11D(0x3)
	float StretchStartRatio;  // 0x120(0x4)
	float StretchMaximumRatio;  // 0x124(0x4)
	float Weight;  // 0x128(0x4)
	float BoneALength;  // 0x12C(0x4)
	float BoneBLength;  // 0x130(0x4)
	char pad_308_1 : 7;  // 0x134(0x1)
	bool bPropagateToChildren : 1;  // 0x134(0x1)
	char pad_309[11];  // 0x135(0xB)
	struct FRigUnit_TwoBoneIKSimple_DebugSettings DebugSettings;  // 0x140(0x70)
	struct FCachedRigElement CachedBoneAIndex;  // 0x1B0(0x20)
	struct FCachedRigElement CachedBoneBIndex;  // 0x1D0(0x20)
	struct FCachedRigElement CachedEffectorBoneIndex;  // 0x1F0(0x20)
	struct FCachedRigElement CachedPoleVectorSpaceIndex;  // 0x210(0x20)

}; 
// ScriptStruct ControlRig.RigUnit_TwoBoneIKSimplePerItem
// Size: 0x240(Inherited: 0x40) 
struct FRigUnit_TwoBoneIKSimplePerItem : public FRigUnit_HighlevelBaseMutable
{
	struct FRigElementKey ItemA;  // 0x40(0xC)
	struct FRigElementKey ItemB;  // 0x4C(0xC)
	struct FRigElementKey EffectorItem;  // 0x58(0xC)
	char pad_100[12];  // 0x64(0xC)
	struct FTransform Effector;  // 0x70(0x60)
	struct FVector PrimaryAxis;  // 0xD0(0x18)
	struct FVector SecondaryAxis;  // 0xE8(0x18)
	float SecondaryAxisWeight;  // 0x100(0x4)
	char pad_260[4];  // 0x104(0x4)
	struct FVector PoleVector;  // 0x108(0x18)
	uint8_t  PoleVectorKind;  // 0x120(0x1)
	char pad_289[3];  // 0x121(0x3)
	struct FRigElementKey PoleVectorSpace;  // 0x124(0xC)
	char pad_304_1 : 7;  // 0x130(0x1)
	bool bEnableStretch : 1;  // 0x130(0x1)
	char pad_305[3];  // 0x131(0x3)
	float StretchStartRatio;  // 0x134(0x4)
	float StretchMaximumRatio;  // 0x138(0x4)
	float Weight;  // 0x13C(0x4)
	float ItemALength;  // 0x140(0x4)
	float ItemBLength;  // 0x144(0x4)
	char pad_328_1 : 7;  // 0x148(0x1)
	bool bPropagateToChildren : 1;  // 0x148(0x1)
	char pad_329[7];  // 0x149(0x7)
	struct FRigUnit_TwoBoneIKSimple_DebugSettings DebugSettings;  // 0x150(0x70)
	struct FCachedRigElement CachedItemAIndex;  // 0x1C0(0x20)
	struct FCachedRigElement CachedItemBIndex;  // 0x1E0(0x20)
	struct FCachedRigElement CachedEffectorItemIndex;  // 0x200(0x20)
	struct FCachedRigElement CachedPoleVectorSpaceIndex;  // 0x220(0x20)

}; 
// ScriptStruct ControlRig.RigUnit_MathTransformUnaryOp
// Size: 0xD0(Inherited: 0x8) 
struct FRigUnit_MathTransformUnaryOp : public FRigUnit_MathTransformBase
{
	char pad_8[8];  // 0x8(0x8)
	struct FTransform Value;  // 0x10(0x60)
	struct FTransform Result;  // 0x70(0x60)

}; 
// ScriptStruct ControlRig.RigUnit_MathIntBase
// Size: 0x8(Inherited: 0x8) 
struct FRigUnit_MathIntBase : public FRigUnit_MathBase
{

}; 
// ScriptStruct ControlRig.RigUnit_TwoBoneIKSimpleVectors
// Size: 0x80(Inherited: 0x8) 
struct FRigUnit_TwoBoneIKSimpleVectors : public FRigUnit_HighlevelBase
{
	struct FVector Root;  // 0x8(0x18)
	struct FVector PoleVector;  // 0x20(0x18)
	struct FVector Effector;  // 0x38(0x18)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool bEnableStretch : 1;  // 0x50(0x1)
	char pad_81[3];  // 0x51(0x3)
	float StretchStartRatio;  // 0x54(0x4)
	float StretchMaximumRatio;  // 0x58(0x4)
	float BoneALength;  // 0x5C(0x4)
	float BoneBLength;  // 0x60(0x4)
	char pad_100[4];  // 0x64(0x4)
	struct FVector Elbow;  // 0x68(0x18)

}; 
// ScriptStruct ControlRig.RigUnit_TwoBoneIKSimpleTransforms
// Size: 0x1A0(Inherited: 0x8) 
struct FRigUnit_TwoBoneIKSimpleTransforms : public FRigUnit_HighlevelBase
{
	char pad_8[8];  // 0x8(0x8)
	struct FTransform Root;  // 0x10(0x60)
	struct FVector PoleVector;  // 0x70(0x18)
	char pad_136[8];  // 0x88(0x8)
	struct FTransform Effector;  // 0x90(0x60)
	struct FVector PrimaryAxis;  // 0xF0(0x18)
	struct FVector SecondaryAxis;  // 0x108(0x18)
	float SecondaryAxisWeight;  // 0x120(0x4)
	char pad_292_1 : 7;  // 0x124(0x1)
	bool bEnableStretch : 1;  // 0x124(0x1)
	char pad_293[3];  // 0x125(0x3)
	float StretchStartRatio;  // 0x128(0x4)
	float StretchMaximumRatio;  // 0x12C(0x4)
	float BoneALength;  // 0x130(0x4)
	float BoneBLength;  // 0x134(0x4)
	char pad_312[8];  // 0x138(0x8)
	struct FTransform Elbow;  // 0x140(0x60)

}; 
// ScriptStruct ControlRig.RigUnit_AccumulateFloatMul
// Size: 0x20(Inherited: 0x8) 
struct FRigUnit_AccumulateFloatMul : public FRigUnit_AccumulateBase
{
	float Multiplier;  // 0x8(0x4)
	float InitialValue;  // 0xC(0x4)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bIntegrateDeltaTime : 1;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)
	float Result;  // 0x14(0x4)
	float AccumulatedValue;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)

}; 
// Function ControlRig.ControlRigComponent.GetControlInt
// Size: 0xC(Inherited: 0x0) 
struct FGetControlInt
{
	struct FName ControlName;  // 0x0(0x8)
	int32_t ReturnValue;  // 0x8(0x4)

}; 
// ScriptStruct ControlRig.RigUnit_MathBoolUnaryOp
// Size: 0x10(Inherited: 0x8) 
struct FRigUnit_MathBoolUnaryOp : public FRigUnit_MathBoolBase
{
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Value : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool Result : 1;  // 0x9(0x1)
	char pad_10[6];  // 0xA(0x6)

}; 
// ScriptStruct ControlRig.RigUnit_MathBoolBinaryOp
// Size: 0x10(Inherited: 0x8) 
struct FRigUnit_MathBoolBinaryOp : public FRigUnit_MathBoolBase
{
	char pad_8_1 : 7;  // 0x8(0x1)
	bool A : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool B : 1;  // 0x9(0x1)
	char pad_10_1 : 7;  // 0xA(0x1)
	bool Result : 1;  // 0xA(0x1)
	char pad_11[5];  // 0xB(0x5)

}; 
// ScriptStruct ControlRig.RigUnit_MathBoolConstTrue
// Size: 0x10(Inherited: 0x10) 
struct FRigUnit_MathBoolConstTrue : public FRigUnit_MathBoolConstant
{

}; 
// ScriptStruct ControlRig.RigUnit_MathBoolConstFalse
// Size: 0x10(Inherited: 0x10) 
struct FRigUnit_MathBoolConstFalse : public FRigUnit_MathBoolConstant
{

}; 
// ScriptStruct ControlRig.RigUnit_MathBoolAnd
// Size: 0x10(Inherited: 0x10) 
struct FRigUnit_MathBoolAnd : public FRigUnit_MathBoolBinaryAggregateOp
{

}; 
// ScriptStruct ControlRig.RigUnit_MathBoolNand
// Size: 0x10(Inherited: 0x10) 
struct FRigUnit_MathBoolNand : public FRigUnit_MathBoolBinaryOp
{

}; 
// Function ControlRig.ControlRigComponent.GetControlPosition
// Size: 0x28(Inherited: 0x0) 
struct FGetControlPosition
{
	struct FName ControlName;  // 0x0(0x8)
	uint8_t  Space;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct FVector ReturnValue;  // 0x10(0x18)

}; 
// ScriptStruct ControlRig.RigUnit_MathBoolNand2
// Size: 0x10(Inherited: 0x10) 
struct FRigUnit_MathBoolNand2 : public FRigUnit_MathBoolBinaryOp
{

}; 
// ScriptStruct ControlRig.RigUnit_MathBoolOr
// Size: 0x10(Inherited: 0x10) 
struct FRigUnit_MathBoolOr : public FRigUnit_MathBoolBinaryAggregateOp
{

}; 
// ScriptStruct ControlRig.RigUnit_MathBoolEquals
// Size: 0x10(Inherited: 0x8) 
struct FRigUnit_MathBoolEquals : public FRigUnit_MathBoolBase
{
	char pad_8_1 : 7;  // 0x8(0x1)
	bool A : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool B : 1;  // 0x9(0x1)
	char pad_10_1 : 7;  // 0xA(0x1)
	bool Result : 1;  // 0xA(0x1)
	char pad_11[5];  // 0xB(0x5)

}; 
// ScriptStruct ControlRig.RigUnit_MathBoolToggled
// Size: 0x10(Inherited: 0x8) 
struct FRigUnit_MathBoolToggled : public FRigUnit_MathBoolBase
{
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Value : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool Toggled : 1;  // 0x9(0x1)
	char pad_10_1 : 7;  // 0xA(0x1)
	bool Initialized : 1;  // 0xA(0x1)
	char pad_11_1 : 7;  // 0xB(0x1)
	bool LastValue : 1;  // 0xB(0x1)
	char pad_12[4];  // 0xC(0x4)

}; 
// Function ControlRig.RigHierarchy.MakeControlValueFromFloat
// Size: 0x100(Inherited: 0x0) 
struct FMakeControlValueFromFloat
{
	float InValue;  // 0x0(0x4)
	char pad_4[12];  // 0x4(0xC)
	struct FRigControlValue ReturnValue;  // 0x10(0xF0)

}; 
// ScriptStruct ControlRig.RigUnit_MathFloatLawOfCosine
// Size: 0x28(Inherited: 0x8) 
struct FRigUnit_MathFloatLawOfCosine : public FRigUnit_MathFloatBase
{
	float A;  // 0x8(0x4)
	float B;  // 0xC(0x4)
	float C;  // 0x10(0x4)
	float AlphaAngle;  // 0x14(0x4)
	float BetaAngle;  // 0x18(0x4)
	float GammaAngle;  // 0x1C(0x4)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool bValid : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// ScriptStruct ControlRig.RigUnit_MathBoolFlipFlop
// Size: 0x18(Inherited: 0x8) 
struct FRigUnit_MathBoolFlipFlop : public FRigUnit_MathBoolBase
{
	char pad_8_1 : 7;  // 0x8(0x1)
	bool StartValue : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	float Duration;  // 0xC(0x4)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool Result : 1;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool LastValue : 1;  // 0x11(0x1)
	char pad_18[2];  // 0x12(0x2)
	float TimeLeft;  // 0x14(0x4)

}; 
// ScriptStruct ControlRig.RigUnit_MathBoolOnce
// Size: 0x18(Inherited: 0x8) 
struct FRigUnit_MathBoolOnce : public FRigUnit_MathBoolBase
{
	float Duration;  // 0x8(0x4)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool Result : 1;  // 0xC(0x1)
	char pad_13_1 : 7;  // 0xD(0x1)
	bool LastValue : 1;  // 0xD(0x1)
	char pad_14[2];  // 0xE(0x2)
	float TimeLeft;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)

}; 
// ScriptStruct ControlRig.RigUnit_MathTransformBinaryAggregateOp
// Size: 0x130(Inherited: 0x8) 
struct FRigUnit_MathTransformBinaryAggregateOp : public FRigUnit_MathTransformBase
{
	char pad_8[8];  // 0x8(0x8)
	struct FTransform A;  // 0x10(0x60)
	struct FTransform B;  // 0x70(0x60)
	struct FTransform Result;  // 0xD0(0x60)

}; 
// ScriptStruct ControlRig.RigUnit_MathIntAbs
// Size: 0x10(Inherited: 0x10) 
struct FRigUnit_MathIntAbs : public FRigUnit_MathIntUnaryOp
{

}; 
// ScriptStruct ControlRig.RigUnit_MathBoolToFloat
// Size: 0x10(Inherited: 0x8) 
struct FRigUnit_MathBoolToFloat : public FRigUnit_MathBoolBase
{
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Value : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	float Result;  // 0xC(0x4)

}; 
// ScriptStruct ControlRig.RigUnit_MathVectorMod
// Size: 0x50(Inherited: 0x50) 
struct FRigUnit_MathVectorMod : public FRigUnit_MathVectorBinaryOp
{

}; 
// ScriptStruct ControlRig.RigUnit_MathColorBinaryAggregateOp
// Size: 0x38(Inherited: 0x8) 
struct FRigUnit_MathColorBinaryAggregateOp : public FRigUnit_MathColorBase
{
	struct FLinearColor A;  // 0x8(0x10)
	struct FLinearColor B;  // 0x18(0x10)
	struct FLinearColor Result;  // 0x28(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_MathColorMul
// Size: 0x38(Inherited: 0x38) 
struct FRigUnit_MathColorMul : public FRigUnit_MathColorBinaryAggregateOp
{

}; 
// ScriptStruct ControlRig.RigUnit_MathVectorFromFloat
// Size: 0x28(Inherited: 0x8) 
struct FRigUnit_MathVectorFromFloat : public FRigUnit_MathVectorBase
{
	float Value;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct FVector Result;  // 0x10(0x18)

}; 
// ScriptStruct ControlRig.RigUnit_MathQuaternionMakeRelative
// Size: 0x70(Inherited: 0x8) 
struct FRigUnit_MathQuaternionMakeRelative : public FRigUnit_MathQuaternionBase
{
	char pad_8[8];  // 0x8(0x8)
	struct FQuat Global;  // 0x10(0x20)
	struct FQuat Parent;  // 0x30(0x20)
	struct FQuat Local;  // 0x50(0x20)

}; 
// Function ControlRig.ControlRigPoseAsset.GetCurrentPose
// Size: 0x68(Inherited: 0x0) 
struct FGetCurrentPose
{
	struct UControlRig* InControlRig;  // 0x0(0x8)
	struct FControlRigControlPose OutPose;  // 0x8(0x60)

}; 
// ScriptStruct ControlRig.RigUnit_MathDoubleBase
// Size: 0x8(Inherited: 0x8) 
struct FRigUnit_MathDoubleBase : public FRigUnit_MathBase
{

}; 
// ScriptStruct ControlRig.RigUnit_MathDoubleConstant
// Size: 0x10(Inherited: 0x8) 
struct FRigUnit_MathDoubleConstant : public FRigUnit_MathDoubleBase
{
	double Value;  // 0x8(0x8)

}; 
// ScriptStruct ControlRig.RigUnit_MathDoubleBinaryAggregateOp
// Size: 0x20(Inherited: 0x8) 
struct FRigUnit_MathDoubleBinaryAggregateOp : public FRigUnit_MathDoubleBase
{
	double A;  // 0x8(0x8)
	double B;  // 0x10(0x8)
	double Result;  // 0x18(0x8)

}; 
// ScriptStruct ControlRig.RigUnit_MathMatrixInverse
// Size: 0x110(Inherited: 0x110) 
struct FRigUnit_MathMatrixInverse : public FRigUnit_MathMatrixUnaryOp
{

}; 
// Function ControlRig.RigHierarchy.GetVector2DFromControlValue
// Size: 0x100(Inherited: 0x0) 
struct FGetVector2DFromControlValue
{
	struct FRigControlValue InValue;  // 0x0(0xF0)
	struct FVector2D ReturnValue;  // 0xF0(0x10)

}; 
// Function ControlRig.RigHierarchy.SetInt32Metadata
// Size: 0x1C(Inherited: 0x0) 
struct FSetInt32Metadata
{
	struct FRigElementKey InItem;  // 0x0(0xC)
	struct FName InMetadataName;  // 0xC(0x8)
	int32_t InValue;  // 0x14(0x4)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool ReturnValue : 1;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)

}; 
// ScriptStruct ControlRig.RigUnit_MathDoubleConstE
// Size: 0x10(Inherited: 0x10) 
struct FRigUnit_MathDoubleConstE : public FRigUnit_MathDoubleConstant
{

}; 
// ScriptStruct ControlRig.RigUnit_MathDoubleSub
// Size: 0x20(Inherited: 0x20) 
struct FRigUnit_MathDoubleSub : public FRigUnit_MathDoubleBinaryOp
{

}; 
// ScriptStruct ControlRig.RigUnit_MathDoubleMod
// Size: 0x20(Inherited: 0x20) 
struct FRigUnit_MathDoubleMod : public FRigUnit_MathDoubleBinaryOp
{

}; 
// ScriptStruct ControlRig.RigUnit_MathDoubleMin
// Size: 0x20(Inherited: 0x20) 
struct FRigUnit_MathDoubleMin : public FRigUnit_MathDoubleBinaryAggregateOp
{

}; 
// ScriptStruct ControlRig.RigUnit_MathDoubleMax
// Size: 0x20(Inherited: 0x20) 
struct FRigUnit_MathDoubleMax : public FRigUnit_MathDoubleBinaryAggregateOp
{

}; 
// ScriptStruct ControlRig.RigUnit_MathFloatSub
// Size: 0x18(Inherited: 0x18) 
struct FRigUnit_MathFloatSub : public FRigUnit_MathFloatBinaryOp
{

}; 
// ScriptStruct ControlRig.RigUnit_MathDoubleNegate
// Size: 0x18(Inherited: 0x18) 
struct FRigUnit_MathDoubleNegate : public FRigUnit_MathDoubleUnaryOp
{

}; 
// ScriptStruct ControlRig.RigUnit_MathDoubleRound
// Size: 0x20(Inherited: 0x8) 
struct FRigUnit_MathDoubleRound : public FRigUnit_MathDoubleBase
{
	double Value;  // 0x8(0x8)
	double Result;  // 0x10(0x8)
	int32_t Int;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)

}; 
// ScriptStruct ControlRig.RigUnit_MathDoubleToInt
// Size: 0x18(Inherited: 0x8) 
struct FRigUnit_MathDoubleToInt : public FRigUnit_MathDoubleBase
{
	double Value;  // 0x8(0x8)
	int32_t Result;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)

}; 
// ScriptStruct ControlRig.RigUnit_MathFloatFloor
// Size: 0x18(Inherited: 0x8) 
struct FRigUnit_MathFloatFloor : public FRigUnit_MathFloatBase
{
	float Value;  // 0x8(0x4)
	float Result;  // 0xC(0x4)
	int32_t Int;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)

}; 
// Function ControlRig.RigHierarchyController.AddParent
// Size: 0x20(Inherited: 0x0) 
struct FAddParent
{
	struct FRigElementKey InChild;  // 0x0(0xC)
	struct FRigElementKey InParent;  // 0xC(0xC)
	float InWeight;  // 0x18(0x4)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool bMaintainGlobalTransform : 1;  // 0x1C(0x1)
	char pad_29_1 : 7;  // 0x1D(0x1)
	bool bSetupUndo : 1;  // 0x1D(0x1)
	char pad_30_1 : 7;  // 0x1E(0x1)
	bool ReturnValue : 1;  // 0x1E(0x1)
	char pad_31[1];  // 0x1F(0x1)

}; 
// ScriptStruct ControlRig.RigUnit_MathDoubleClamp
// Size: 0x28(Inherited: 0x8) 
struct FRigUnit_MathDoubleClamp : public FRigUnit_MathDoubleBase
{
	double Value;  // 0x8(0x8)
	double Minimum;  // 0x10(0x8)
	double Maximum;  // 0x18(0x8)
	double Result;  // 0x20(0x8)

}; 
// ScriptStruct ControlRig.RigUnit_MathDoubleGreater
// Size: 0x20(Inherited: 0x8) 
struct FRigUnit_MathDoubleGreater : public FRigUnit_MathDoubleBase
{
	double A;  // 0x8(0x8)
	double B;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool Result : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)

}; 
// ScriptStruct ControlRig.RigUnit_MathDoubleGreaterEqual
// Size: 0x20(Inherited: 0x8) 
struct FRigUnit_MathDoubleGreaterEqual : public FRigUnit_MathDoubleBase
{
	double A;  // 0x8(0x8)
	double B;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool Result : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)

}; 
// ScriptStruct ControlRig.RigUnit_MathDoubleLessEqual
// Size: 0x20(Inherited: 0x8) 
struct FRigUnit_MathDoubleLessEqual : public FRigUnit_MathDoubleBase
{
	double A;  // 0x8(0x8)
	double B;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool Result : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)

}; 
// ScriptStruct ControlRig.RigUnit_MathDoubleTan
// Size: 0x18(Inherited: 0x18) 
struct FRigUnit_MathDoubleTan : public FRigUnit_MathDoubleUnaryOp
{

}; 
// ScriptStruct ControlRig.RigUnit_MathFloatGreaterEqual
// Size: 0x18(Inherited: 0x8) 
struct FRigUnit_MathFloatGreaterEqual : public FRigUnit_MathFloatBase
{
	float A;  // 0x8(0x4)
	float B;  // 0xC(0x4)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool Result : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// ScriptStruct ControlRig.RigUnit_MathDoubleLawOfCosine
// Size: 0x40(Inherited: 0x8) 
struct FRigUnit_MathDoubleLawOfCosine : public FRigUnit_MathDoubleBase
{
	double A;  // 0x8(0x8)
	double B;  // 0x10(0x8)
	double C;  // 0x18(0x8)
	double AlphaAngle;  // 0x20(0x8)
	double BetaAngle;  // 0x28(0x8)
	double GammaAngle;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool bValid : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)

}; 
// ScriptStruct ControlRig.RigUnit_MathFloatToInt
// Size: 0x10(Inherited: 0x8) 
struct FRigUnit_MathFloatToInt : public FRigUnit_MathFloatBase
{
	float Value;  // 0x8(0x4)
	int32_t Result;  // 0xC(0x4)

}; 
// ScriptStruct ControlRig.RigUnit_MathDoubleExponential
// Size: 0x18(Inherited: 0x18) 
struct FRigUnit_MathDoubleExponential : public FRigUnit_MathDoubleUnaryOp
{

}; 
// ScriptStruct ControlRig.RigUnit_MathFloatBase
// Size: 0x8(Inherited: 0x8) 
struct FRigUnit_MathFloatBase : public FRigUnit_MathBase
{

}; 
// Function ControlRig.RigHierarchy.GetParents
// Size: 0x20(Inherited: 0x0) 
struct FGetParents
{
	struct FRigElementKey InKey;  // 0x0(0xC)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool bRecursive : 1;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)
	struct TArray<struct FRigElementKey> ReturnValue;  // 0x10(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_MathFloatConstant
// Size: 0x10(Inherited: 0x8) 
struct FRigUnit_MathFloatConstant : public FRigUnit_MathFloatBase
{
	float Value;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)

}; 
// ScriptStruct ControlRig.RigUnit_MathFloatConstTwoPi
// Size: 0x10(Inherited: 0x10) 
struct FRigUnit_MathFloatConstTwoPi : public FRigUnit_MathFloatConstant
{

}; 
// ScriptStruct ControlRig.RigUnit_MathFloatConstE
// Size: 0x10(Inherited: 0x10) 
struct FRigUnit_MathFloatConstE : public FRigUnit_MathFloatConstant
{

}; 
// ScriptStruct ControlRig.RigUnit_MathFloatDiv
// Size: 0x18(Inherited: 0x18) 
struct FRigUnit_MathFloatDiv : public FRigUnit_MathFloatBinaryOp
{

}; 
// ScriptStruct ControlRig.RigUnit_MathFloatMod
// Size: 0x18(Inherited: 0x18) 
struct FRigUnit_MathFloatMod : public FRigUnit_MathFloatBinaryOp
{

}; 
// ScriptStruct ControlRig.RigUnit_MathFloatMin
// Size: 0x18(Inherited: 0x18) 
struct FRigUnit_MathFloatMin : public FRigUnit_MathFloatBinaryAggregateOp
{

}; 
// ScriptStruct ControlRig.RigUnit_MathFloatMax
// Size: 0x18(Inherited: 0x18) 
struct FRigUnit_MathFloatMax : public FRigUnit_MathFloatBinaryAggregateOp
{

}; 
// ScriptStruct ControlRig.RigUnit_MathFloatAbs
// Size: 0x10(Inherited: 0x10) 
struct FRigUnit_MathFloatAbs : public FRigUnit_MathFloatUnaryOp
{

}; 
// ScriptStruct ControlRig.RigUnit_MathFloatCeil
// Size: 0x18(Inherited: 0x8) 
struct FRigUnit_MathFloatCeil : public FRigUnit_MathFloatBase
{
	float Value;  // 0x8(0x4)
	float Result;  // 0xC(0x4)
	int32_t Int;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)

}; 
// ScriptStruct ControlRig.RigUnit_MathFloatRound
// Size: 0x18(Inherited: 0x8) 
struct FRigUnit_MathFloatRound : public FRigUnit_MathFloatBase
{
	float Value;  // 0x8(0x4)
	float Result;  // 0xC(0x4)
	int32_t Int;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)

}; 
// ScriptStruct ControlRig.RigUnit_MathFloatLerp
// Size: 0x18(Inherited: 0x8) 
struct FRigUnit_MathFloatLerp : public FRigUnit_MathFloatBase
{
	float A;  // 0x8(0x4)
	float B;  // 0xC(0x4)
	float T;  // 0x10(0x4)
	float Result;  // 0x14(0x4)

}; 
// ScriptStruct ControlRig.RigUnit_MathFloatRemap
// Size: 0x28(Inherited: 0x8) 
struct FRigUnit_MathFloatRemap : public FRigUnit_MathFloatBase
{
	float Value;  // 0x8(0x4)
	float SourceMinimum;  // 0xC(0x4)
	float SourceMaximum;  // 0x10(0x4)
	float TargetMinimum;  // 0x14(0x4)
	float TargetMaximum;  // 0x18(0x4)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool bClamp : 1;  // 0x1C(0x1)
	char pad_29[3];  // 0x1D(0x3)
	float Result;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)

}; 
// ScriptStruct ControlRig.RigUnit_MathFloatNotEquals
// Size: 0x18(Inherited: 0x8) 
struct FRigUnit_MathFloatNotEquals : public FRigUnit_MathFloatBase
{
	float A;  // 0x8(0x4)
	float B;  // 0xC(0x4)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool Result : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// ScriptStruct ControlRig.RigUnit_MathFloatLessEqual
// Size: 0x18(Inherited: 0x8) 
struct FRigUnit_MathFloatLessEqual : public FRigUnit_MathFloatBase
{
	float A;  // 0x8(0x4)
	float B;  // 0xC(0x4)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool Result : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// ScriptStruct ControlRig.RigUnit_MathFloatIsNearlyEqual
// Size: 0x18(Inherited: 0x8) 
struct FRigUnit_MathFloatIsNearlyEqual : public FRigUnit_MathFloatBase
{
	float A;  // 0x8(0x4)
	float B;  // 0xC(0x4)
	float Tolerance;  // 0x10(0x4)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool Result : 1;  // 0x14(0x1)
	char pad_21[3];  // 0x15(0x3)

}; 
// Function ControlRig.RigHierarchy.GetRotatorFromControlValue
// Size: 0x110(Inherited: 0x0) 
struct FGetRotatorFromControlValue
{
	struct FRigControlValue InValue;  // 0x0(0xF0)
	struct FRotator ReturnValue;  // 0xF0(0x18)
	char pad_264[8];  // 0x108(0x8)

}; 
// ScriptStruct ControlRig.RigUnit_MathFloatDeg
// Size: 0x10(Inherited: 0x10) 
struct FRigUnit_MathFloatDeg : public FRigUnit_MathFloatUnaryOp
{

}; 
// ScriptStruct ControlRig.RigUnit_MathFloatRad
// Size: 0x10(Inherited: 0x10) 
struct FRigUnit_MathFloatRad : public FRigUnit_MathFloatUnaryOp
{

}; 
// ScriptStruct ControlRig.RigUnit_MathFloatCos
// Size: 0x10(Inherited: 0x10) 
struct FRigUnit_MathFloatCos : public FRigUnit_MathFloatUnaryOp
{

}; 
// ScriptStruct ControlRig.RigUnit_MathFloatTan
// Size: 0x10(Inherited: 0x10) 
struct FRigUnit_MathFloatTan : public FRigUnit_MathFloatUnaryOp
{

}; 
// Function ControlRig.RigHierarchy.SetFloatArrayMetadata
// Size: 0x30(Inherited: 0x0) 
struct FSetFloatArrayMetadata
{
	struct FRigElementKey InItem;  // 0x0(0xC)
	struct FName InMetadataName;  // 0xC(0x8)
	char pad_20[4];  // 0x14(0x4)
	struct TArray<float> InValue;  // 0x18(0x10)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool ReturnValue : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)

}; 
// ScriptStruct ControlRig.RigUnit_MathFloatAcos
// Size: 0x10(Inherited: 0x10) 
struct FRigUnit_MathFloatAcos : public FRigUnit_MathFloatUnaryOp
{

}; 
// ScriptStruct ControlRig.RigUnit_MathFloatAtan
// Size: 0x10(Inherited: 0x10) 
struct FRigUnit_MathFloatAtan : public FRigUnit_MathFloatUnaryOp
{

}; 
// ScriptStruct ControlRig.RigUnit_MathIntBinaryAggregateOp
// Size: 0x18(Inherited: 0x8) 
struct FRigUnit_MathIntBinaryAggregateOp : public FRigUnit_MathIntBase
{
	int32_t A;  // 0x8(0x4)
	int32_t B;  // 0xC(0x4)
	int32_t Result;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)

}; 
// Function ControlRig.RigHierarchy.IsControllerAvailable
// Size: 0x1(Inherited: 0x0) 
struct FIsControllerAvailable
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// ScriptStruct ControlRig.RigUnit_AlphaInterpVector
// Size: 0xA0(Inherited: 0x8) 
struct FRigUnit_AlphaInterpVector : public FRigUnit_SimBase
{
	struct FVector Value;  // 0x8(0x18)
	float Scale;  // 0x20(0x4)
	float Bias;  // 0x24(0x4)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool bMapRange : 1;  // 0x28(0x1)
	char pad_41[3];  // 0x29(0x3)
	struct FInputRange InRange;  // 0x2C(0x8)
	struct FInputRange OutRange;  // 0x34(0x8)
	char pad_60_1 : 7;  // 0x3C(0x1)
	bool bClampResult : 1;  // 0x3C(0x1)
	char pad_61[3];  // 0x3D(0x3)
	float ClampMin;  // 0x40(0x4)
	float ClampMax;  // 0x44(0x4)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool bInterpResult : 1;  // 0x48(0x1)
	char pad_73[3];  // 0x49(0x3)
	float InterpSpeedIncreasing;  // 0x4C(0x4)
	float InterpSpeedDecreasing;  // 0x50(0x4)
	char pad_84[4];  // 0x54(0x4)
	struct FVector Result;  // 0x58(0x18)
	struct FInputScaleBiasClamp ScaleBiasClamp;  // 0x70(0x30)

}; 
// ScriptStruct ControlRig.RigUnit_MathIntMul
// Size: 0x18(Inherited: 0x18) 
struct FRigUnit_MathIntMul : public FRigUnit_MathIntBinaryAggregateOp
{

}; 
// ScriptStruct ControlRig.RigUnit_MathIntDiv
// Size: 0x18(Inherited: 0x18) 
struct FRigUnit_MathIntDiv : public FRigUnit_MathIntBinaryOp
{

}; 
// ScriptStruct ControlRig.RigUnit_MathRBFInterpolateQuatQuat
// Size: 0x120(Inherited: 0xF0) 
struct FRigUnit_MathRBFInterpolateQuatQuat : public FRigUnit_MathRBFInterpolateQuatBase
{
	struct TArray<struct FMathRBFInterpolateQuatQuat_Target> Targets;  // 0xF0(0x10)
	struct FQuat Output;  // 0x100(0x20)

}; 
// ScriptStruct ControlRig.RigUnit_MathIntMod
// Size: 0x18(Inherited: 0x18) 
struct FRigUnit_MathIntMod : public FRigUnit_MathIntBinaryOp
{

}; 
// ScriptStruct ControlRig.RigUnit_MathIntMin
// Size: 0x18(Inherited: 0x18) 
struct FRigUnit_MathIntMin : public FRigUnit_MathIntBinaryAggregateOp
{

}; 
// Function ControlRig.RigHierarchy.SetBoolMetadata
// Size: 0x18(Inherited: 0x0) 
struct FSetBoolMetadata
{
	struct FRigElementKey InItem;  // 0x0(0xC)
	struct FName InMetadataName;  // 0xC(0x8)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool InValue : 1;  // 0x14(0x1)
	char pad_21_1 : 7;  // 0x15(0x1)
	bool ReturnValue : 1;  // 0x15(0x1)
	char pad_22[2];  // 0x16(0x2)

}; 
// ScriptStruct ControlRig.RigUnit_MathIntToFloat
// Size: 0x10(Inherited: 0x8) 
struct FRigUnit_MathIntToFloat : public FRigUnit_MathIntBase
{
	int32_t Value;  // 0x8(0x4)
	float Result;  // 0xC(0x4)

}; 
// ScriptStruct ControlRig.RigUnit_MathIntClamp
// Size: 0x18(Inherited: 0x8) 
struct FRigUnit_MathIntClamp : public FRigUnit_MathIntBase
{
	int32_t Value;  // 0x8(0x4)
	int32_t Minimum;  // 0xC(0x4)
	int32_t Maximum;  // 0x10(0x4)
	int32_t Result;  // 0x14(0x4)

}; 
// ScriptStruct ControlRig.RigUnit_MathIntGreater
// Size: 0x18(Inherited: 0x8) 
struct FRigUnit_MathIntGreater : public FRigUnit_MathIntBase
{
	int32_t A;  // 0x8(0x4)
	int32_t B;  // 0xC(0x4)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool Result : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// ScriptStruct ControlRig.RigUnit_MathIntGreaterEqual
// Size: 0x18(Inherited: 0x8) 
struct FRigUnit_MathIntGreaterEqual : public FRigUnit_MathIntBase
{
	int32_t A;  // 0x8(0x4)
	int32_t B;  // 0xC(0x4)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool Result : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// ScriptStruct ControlRig.RigUnit_MathMatrixBase
// Size: 0x8(Inherited: 0x8) 
struct FRigUnit_MathMatrixBase : public FRigUnit_MathBase
{

}; 
// ScriptStruct ControlRig.RigUnit_MathMatrixUnaryOp
// Size: 0x110(Inherited: 0x8) 
struct FRigUnit_MathMatrixUnaryOp : public FRigUnit_MathMatrixBase
{
	char pad_8[8];  // 0x8(0x8)
	struct FMatrix Value;  // 0x10(0x80)
	struct FMatrix Result;  // 0x90(0x80)

}; 
// ScriptStruct ControlRig.RigUnit_MathMatrixBinaryAggregateOp
// Size: 0x190(Inherited: 0x8) 
struct FRigUnit_MathMatrixBinaryAggregateOp : public FRigUnit_MathMatrixBase
{
	char pad_8[8];  // 0x8(0x8)
	struct FMatrix A;  // 0x10(0x80)
	struct FMatrix B;  // 0x90(0x80)
	struct FMatrix Result;  // 0x110(0x80)

}; 
// ScriptStruct ControlRig.RigUnit_MathMatrixToTransform
// Size: 0xF0(Inherited: 0x8) 
struct FRigUnit_MathMatrixToTransform : public FRigUnit_MathMatrixBase
{
	char pad_8[8];  // 0x8(0x8)
	struct FMatrix Value;  // 0x10(0x80)
	struct FTransform Result;  // 0x90(0x60)

}; 
// ScriptStruct ControlRig.RigUnit_MathMatrixFromTransform
// Size: 0xF0(Inherited: 0x8) 
struct FRigUnit_MathMatrixFromTransform : public FRigUnit_MathMatrixBase
{
	char pad_8[8];  // 0x8(0x8)
	struct FTransform Transform;  // 0x10(0x60)
	struct FMatrix Result;  // 0x70(0x80)

}; 
// ScriptStruct ControlRig.RigUnit_MathTransformRotateVector
// Size: 0xA0(Inherited: 0x8) 
struct FRigUnit_MathTransformRotateVector : public FRigUnit_MathTransformBase
{
	char pad_8[8];  // 0x8(0x8)
	struct FTransform Transform;  // 0x10(0x60)
	struct FVector Vector;  // 0x70(0x18)
	struct FVector Result;  // 0x88(0x18)

}; 
// ScriptStruct ControlRig.RigUnit_MathMatrixFromTransformV2
// Size: 0xF0(Inherited: 0x8) 
struct FRigUnit_MathMatrixFromTransformV2 : public FRigUnit_MathMatrixBase
{
	char pad_8[8];  // 0x8(0x8)
	struct FTransform Value;  // 0x10(0x60)
	struct FMatrix Result;  // 0x70(0x80)

}; 
// Function ControlRig.RigHierarchy.GetVectorMetadata
// Size: 0x48(Inherited: 0x0) 
struct FGetVectorMetadata
{
	struct FRigElementKey InItem;  // 0x0(0xC)
	struct FName InMetadataName;  // 0xC(0x8)
	char pad_20[4];  // 0x14(0x4)
	struct FVector DefaultValue;  // 0x18(0x18)
	struct FVector ReturnValue;  // 0x30(0x18)

}; 
// ScriptStruct ControlRig.RigUnit_MathMatrixFromVectors
// Size: 0xF0(Inherited: 0x8) 
struct FRigUnit_MathMatrixFromVectors : public FRigUnit_MathMatrixBase
{
	struct FVector Origin;  // 0x8(0x18)
	struct FVector X;  // 0x20(0x18)
	struct FVector Y;  // 0x38(0x18)
	struct FVector Z;  // 0x50(0x18)
	char pad_104[8];  // 0x68(0x8)
	struct FMatrix Result;  // 0x70(0x80)

}; 
// Function ControlRig.RigHierarchy.GetNameMetadata
// Size: 0x24(Inherited: 0x0) 
struct FGetNameMetadata
{
	struct FRigElementKey InItem;  // 0x0(0xC)
	struct FName InMetadataName;  // 0xC(0x8)
	struct FName DefaultValue;  // 0x14(0x8)
	struct FName ReturnValue;  // 0x1C(0x8)

}; 
// ScriptStruct ControlRig.RigUnit_MathMatrixMul
// Size: 0x190(Inherited: 0x190) 
struct FRigUnit_MathMatrixMul : public FRigUnit_MathMatrixBinaryAggregateOp
{

}; 
// ScriptStruct ControlRig.RigUnit_MathQuaternionFromAxisAndAngle
// Size: 0x50(Inherited: 0x8) 
struct FRigUnit_MathQuaternionFromAxisAndAngle : public FRigUnit_MathQuaternionBase
{
	struct FVector Axis;  // 0x8(0x18)
	float Angle;  // 0x20(0x4)
	char pad_36[12];  // 0x24(0xC)
	struct FQuat Result;  // 0x30(0x20)

}; 
// Function ControlRig.RigHierarchy.GetTags
// Size: 0x20(Inherited: 0x0) 
struct FGetTags
{
	struct FRigElementKey InItem;  // 0x0(0xC)
	char pad_12[4];  // 0xC(0x4)
	struct TArray<struct FName> ReturnValue;  // 0x10(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_MathQuaternionFromTwoVectors
// Size: 0x60(Inherited: 0x8) 
struct FRigUnit_MathQuaternionFromTwoVectors : public FRigUnit_MathQuaternionBase
{
	struct FVector A;  // 0x8(0x18)
	struct FVector B;  // 0x20(0x18)
	char pad_56[8];  // 0x38(0x8)
	struct FQuat Result;  // 0x40(0x20)

}; 
// Function ControlRig.RigHierarchy.GetKeys
// Size: 0x20(Inherited: 0x0) 
struct FGetKeys
{
	struct TArray<int32_t> InElementIndices;  // 0x0(0x10)
	struct TArray<struct FRigElementKey> ReturnValue;  // 0x10(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_MathQuaternionToAxisAndAngle
// Size: 0x50(Inherited: 0x8) 
struct FRigUnit_MathQuaternionToAxisAndAngle : public FRigUnit_MathQuaternionBase
{
	char pad_8[8];  // 0x8(0x8)
	struct FQuat Value;  // 0x10(0x20)
	struct FVector Axis;  // 0x30(0x18)
	float Angle;  // 0x48(0x4)
	char pad_76[4];  // 0x4C(0x4)

}; 
// ScriptStruct ControlRig.RigUnit_MathQuaternionScaleV2
// Size: 0x60(Inherited: 0x8) 
struct FRigUnit_MathQuaternionScaleV2 : public FRigUnit_MathQuaternionBase
{
	char pad_8[8];  // 0x8(0x8)
	struct FQuat Value;  // 0x10(0x20)
	float Factor;  // 0x30(0x4)
	char pad_52[12];  // 0x34(0xC)
	struct FQuat Result;  // 0x40(0x20)

}; 
// ScriptStruct ControlRig.RigUnit_MathQuaternionToEuler
// Size: 0x50(Inherited: 0x8) 
struct FRigUnit_MathQuaternionToEuler : public FRigUnit_MathQuaternionBase
{
	char pad_8[8];  // 0x8(0x8)
	struct FQuat Value;  // 0x10(0x20)
	uint8_t  RotationOrder;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)
	struct FVector Result;  // 0x38(0x18)

}; 
// ScriptStruct ControlRig.RigUnit_MathQuaternionToRotator
// Size: 0x50(Inherited: 0x8) 
struct FRigUnit_MathQuaternionToRotator : public FRigUnit_MathQuaternionBase
{
	char pad_8[8];  // 0x8(0x8)
	struct FQuat Value;  // 0x10(0x20)
	struct FRotator Result;  // 0x30(0x18)
	char pad_72[8];  // 0x48(0x8)

}; 
// ScriptStruct ControlRig.RigUnit_MathQuaternionMul
// Size: 0x70(Inherited: 0x70) 
struct FRigUnit_MathQuaternionMul : public FRigUnit_MathQuaternionBinaryAggregateOp
{

}; 
// ScriptStruct ControlRig.RigUnit_MathQuaternionSlerp
// Size: 0x80(Inherited: 0x8) 
struct FRigUnit_MathQuaternionSlerp : public FRigUnit_MathQuaternionBase
{
	char pad_8[8];  // 0x8(0x8)
	struct FQuat A;  // 0x10(0x20)
	struct FQuat B;  // 0x30(0x20)
	float T;  // 0x50(0x4)
	char pad_84[12];  // 0x54(0xC)
	struct FQuat Result;  // 0x60(0x20)

}; 
// ScriptStruct ControlRig.RigUnit_MathQuaternionEquals
// Size: 0x60(Inherited: 0x8) 
struct FRigUnit_MathQuaternionEquals : public FRigUnit_MathQuaternionBase
{
	char pad_8[8];  // 0x8(0x8)
	struct FQuat A;  // 0x10(0x20)
	struct FQuat B;  // 0x30(0x20)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool Result : 1;  // 0x50(0x1)
	char pad_81[15];  // 0x51(0xF)

}; 
// Function ControlRig.RigHierarchy.GetSelectedKeys
// Size: 0x18(Inherited: 0x0) 
struct FGetSelectedKeys
{
	uint8_t  InTypeFilter;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct TArray<struct FRigElementKey> ReturnValue;  // 0x8(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_MathQuaternionNotEquals
// Size: 0x60(Inherited: 0x8) 
struct FRigUnit_MathQuaternionNotEquals : public FRigUnit_MathQuaternionBase
{
	char pad_8[8];  // 0x8(0x8)
	struct FQuat A;  // 0x10(0x20)
	struct FQuat B;  // 0x30(0x20)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool Result : 1;  // 0x50(0x1)
	char pad_81[15];  // 0x51(0xF)

}; 
// ScriptStruct ControlRig.RigUnit_MathQuaternionSelectBool
// Size: 0x70(Inherited: 0x8) 
struct FRigUnit_MathQuaternionSelectBool : public FRigUnit_MathQuaternionBase
{
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Condition : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct FQuat IfTrue;  // 0x10(0x20)
	struct FQuat IfFalse;  // 0x30(0x20)
	struct FQuat Result;  // 0x50(0x20)

}; 
// ScriptStruct ControlRig.RigUnit_MathQuaternionDot
// Size: 0x60(Inherited: 0x8) 
struct FRigUnit_MathQuaternionDot : public FRigUnit_MathQuaternionBase
{
	char pad_8[8];  // 0x8(0x8)
	struct FQuat A;  // 0x10(0x20)
	struct FQuat B;  // 0x30(0x20)
	float Result;  // 0x50(0x4)
	char pad_84[12];  // 0x54(0xC)

}; 
// ScriptStruct ControlRig.RigUnit_MathQuaternionGetAxis
// Size: 0x50(Inherited: 0x8) 
struct FRigUnit_MathQuaternionGetAxis : public FRigUnit_MathQuaternionBase
{
	char pad_8[8];  // 0x8(0x8)
	struct FQuat Quaternion;  // 0x10(0x20)
	char EAxis Axis;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)
	struct FVector Result;  // 0x38(0x18)

}; 
// ScriptStruct ControlRig.RigUnit_MathQuaternionRotationOrder
// Size: 0x10(Inherited: 0x8) 
struct FRigUnit_MathQuaternionRotationOrder : public FRigUnit_MathBase
{
	uint8_t  RotationOrder;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// ScriptStruct ControlRig.RigUnit_MathRBFInterpolateQuatFloat
// Size: 0x110(Inherited: 0xF0) 
struct FRigUnit_MathRBFInterpolateQuatFloat : public FRigUnit_MathRBFInterpolateQuatBase
{
	struct TArray<struct FMathRBFInterpolateQuatFloat_Target> Targets;  // 0xF0(0x10)
	float Output;  // 0x100(0x4)
	char pad_260[12];  // 0x104(0xC)

}; 
// ScriptStruct ControlRig.MathRBFInterpolateQuatVector_Target
// Size: 0x40(Inherited: 0x0) 
struct FMathRBFInterpolateQuatVector_Target
{
	struct FQuat Target;  // 0x0(0x20)
	struct FVector Value;  // 0x20(0x18)
	char pad_56[8];  // 0x38(0x8)

}; 
// ScriptStruct ControlRig.RigUnit_MathRBFInterpolateQuatColor
// Size: 0x110(Inherited: 0xF0) 
struct FRigUnit_MathRBFInterpolateQuatColor : public FRigUnit_MathRBFInterpolateQuatBase
{
	struct TArray<struct FMathRBFInterpolateQuatColor_Target> Targets;  // 0xF0(0x10)
	struct FLinearColor Output;  // 0x100(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_AccumulateFloatRange
// Size: 0x20(Inherited: 0x8) 
struct FRigUnit_AccumulateFloatRange : public FRigUnit_AccumulateBase
{
	float Value;  // 0x8(0x4)
	float Minimum;  // 0xC(0x4)
	float Maximum;  // 0x10(0x4)
	float AccumulatedMinimum;  // 0x14(0x4)
	float AccumulatedMaximum;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)

}; 
// ScriptStruct ControlRig.MathRBFInterpolateQuatQuat_Target
// Size: 0x40(Inherited: 0x0) 
struct FMathRBFInterpolateQuatQuat_Target
{
	struct FQuat Target;  // 0x0(0x20)
	struct FQuat Value;  // 0x20(0x20)

}; 
// ScriptStruct ControlRig.RigUnit_MathTransformFromEulerTransform
// Size: 0xB0(Inherited: 0x8) 
struct FRigUnit_MathTransformFromEulerTransform : public FRigUnit_MathTransformBase
{
	struct FEulerTransform EulerTransform;  // 0x8(0x48)
	struct FTransform Result;  // 0x50(0x60)

}; 
// Function ControlRig.RigHierarchy.GetKey
// Size: 0x10(Inherited: 0x0) 
struct FGetKey
{
	int32_t InElementIndex;  // 0x0(0x4)
	struct FRigElementKey ReturnValue;  // 0x4(0xC)

}; 
// Function ControlRig.RigHierarchyController.SelectElement
// Size: 0x10(Inherited: 0x0) 
struct FSelectElement
{
	struct FRigElementKey InKey;  // 0x0(0xC)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool bSelect : 1;  // 0xC(0x1)
	char pad_13_1 : 7;  // 0xD(0x1)
	bool bClearSelection : 1;  // 0xD(0x1)
	char pad_14_1 : 7;  // 0xE(0x1)
	bool ReturnValue : 1;  // 0xE(0x1)
	char pad_15[1];  // 0xF(0x1)

}; 
// ScriptStruct ControlRig.RigUnit_MathRBFInterpolateQuatXform
// Size: 0x160(Inherited: 0xF0) 
struct FRigUnit_MathRBFInterpolateQuatXform : public FRigUnit_MathRBFInterpolateQuatBase
{
	struct TArray<struct FMathRBFInterpolateQuatXform_Target> Targets;  // 0xF0(0x10)
	struct FTransform Output;  // 0x100(0x60)

}; 
// ScriptStruct ControlRig.MathRBFInterpolateVectorVector_Target
// Size: 0x30(Inherited: 0x0) 
struct FMathRBFInterpolateVectorVector_Target
{
	struct FVector Target;  // 0x0(0x18)
	struct FVector Value;  // 0x18(0x18)

}; 
// ScriptStruct ControlRig.RigUnit_MathVectorAbs
// Size: 0x38(Inherited: 0x38) 
struct FRigUnit_MathVectorAbs : public FRigUnit_MathVectorUnaryOp
{

}; 
// ScriptStruct ControlRig.RigUnit_MathRBFInterpolateVectorVector
// Size: 0xF0(Inherited: 0xC0) 
struct FRigUnit_MathRBFInterpolateVectorVector : public FRigUnit_MathRBFInterpolateVectorBase
{
	struct TArray<struct FMathRBFInterpolateVectorVector_Target> Targets;  // 0xC0(0x10)
	struct FVector Output;  // 0xD0(0x18)
	char pad_232[8];  // 0xE8(0x8)

}; 
// ScriptStruct ControlRig.RigUnit_MathRBFInterpolateVectorQuat
// Size: 0xF0(Inherited: 0xC0) 
struct FRigUnit_MathRBFInterpolateVectorQuat : public FRigUnit_MathRBFInterpolateVectorBase
{
	struct TArray<struct FMathRBFInterpolateVectorQuat_Target> Targets;  // 0xC0(0x10)
	struct FQuat Output;  // 0xD0(0x20)

}; 
// ScriptStruct ControlRig.RigUnit_MathVectorSelectBool
// Size: 0x58(Inherited: 0x8) 
struct FRigUnit_MathVectorSelectBool : public FRigUnit_MathVectorBase
{
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Condition : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct FVector IfTrue;  // 0x10(0x18)
	struct FVector IfFalse;  // 0x28(0x18)
	struct FVector Result;  // 0x40(0x18)

}; 
// Function ControlRig.RigHierarchyController.AddRigidBody
// Size: 0x90(Inherited: 0x0) 
struct FAddRigidBody
{
	struct FName InName;  // 0x0(0x8)
	struct FRigElementKey InParent;  // 0x8(0xC)
	struct FRigRigidBodySettings InSettings;  // 0x14(0x4)
	char pad_24[8];  // 0x18(0x8)
	struct FTransform InLocalTransform;  // 0x20(0x60)
	char pad_128_1 : 7;  // 0x80(0x1)
	bool bSetupUndo : 1;  // 0x80(0x1)
	char pad_129_1 : 7;  // 0x81(0x1)
	bool bPrintPythonCommand : 1;  // 0x81(0x1)
	char pad_130[2];  // 0x82(0x2)
	struct FRigElementKey ReturnValue;  // 0x84(0xC)

}; 
// ScriptStruct ControlRig.RigUnit_MathRBFInterpolateVectorXform
// Size: 0x130(Inherited: 0xC0) 
struct FRigUnit_MathRBFInterpolateVectorXform : public FRigUnit_MathRBFInterpolateVectorBase
{
	struct TArray<struct FMathRBFInterpolateVectorXform_Target> Targets;  // 0xC0(0x10)
	struct FTransform Output;  // 0xD0(0x60)

}; 
// ScriptStruct ControlRig.RigUnit_MathTransformBinaryOp
// Size: 0x130(Inherited: 0x8) 
struct FRigUnit_MathTransformBinaryOp : public FRigUnit_MathTransformBase
{
	char pad_8[8];  // 0x8(0x8)
	struct FTransform A;  // 0x10(0x60)
	struct FTransform B;  // 0x70(0x60)
	struct FTransform Result;  // 0xD0(0x60)

}; 
// ScriptStruct ControlRig.RigUnit_MathTransformToEulerTransform
// Size: 0xC0(Inherited: 0x8) 
struct FRigUnit_MathTransformToEulerTransform : public FRigUnit_MathTransformBase
{
	char pad_8[8];  // 0x8(0x8)
	struct FTransform Value;  // 0x10(0x60)
	struct FEulerTransform Result;  // 0x70(0x48)
	char pad_184[8];  // 0xB8(0x8)

}; 
// ScriptStruct ControlRig.RigUnit_MathTransformMakeAbsolute
// Size: 0x130(Inherited: 0x8) 
struct FRigUnit_MathTransformMakeAbsolute : public FRigUnit_MathTransformBase
{
	char pad_8[8];  // 0x8(0x8)
	struct FTransform Local;  // 0x10(0x60)
	struct FTransform Parent;  // 0x70(0x60)
	struct FTransform Global;  // 0xD0(0x60)

}; 
// ScriptStruct ControlRig.RigUnit_MathTransformFromSRT
// Size: 0x110(Inherited: 0x8) 
struct FRigUnit_MathTransformFromSRT : public FRigUnit_MathTransformBase
{
	struct FVector Location;  // 0x8(0x18)
	struct FVector Rotation;  // 0x20(0x18)
	uint8_t  RotationOrder;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct FVector Scale;  // 0x40(0x18)
	char pad_88[8];  // 0x58(0x8)
	struct FTransform Transform;  // 0x60(0x60)
	struct FEulerTransform EulerTransform;  // 0xC0(0x48)
	char pad_264[8];  // 0x108(0x8)

}; 
// ScriptStruct ControlRig.RigUnit_MathTransformArrayToSRT
// Size: 0x48(Inherited: 0x8) 
struct FRigUnit_MathTransformArrayToSRT : public FRigUnit_MathTransformBase
{
	struct TArray<struct FTransform> Transforms;  // 0x8(0x10)
	struct TArray<struct FVector> Translations;  // 0x18(0x10)
	struct TArray<struct FQuat> Rotations;  // 0x28(0x10)
	struct TArray<struct FVector> Scales;  // 0x38(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_MathTransformClampSpatially
// Size: 0x160(Inherited: 0x8) 
struct FRigUnit_MathTransformClampSpatially : public FRigUnit_MathTransformBase
{
	char pad_8[8];  // 0x8(0x8)
	struct FTransform Value;  // 0x10(0x60)
	char EAxis Axis;  // 0x70(0x1)
	char EControlRigClampSpatialMode Type;  // 0x71(0x1)
	char pad_114[2];  // 0x72(0x2)
	float Minimum;  // 0x74(0x4)
	float Maximum;  // 0x78(0x4)
	char pad_124[4];  // 0x7C(0x4)
	struct FTransform Space;  // 0x80(0x60)
	char pad_224_1 : 7;  // 0xE0(0x1)
	bool bDrawDebug : 1;  // 0xE0(0x1)
	char pad_225[3];  // 0xE1(0x3)
	struct FLinearColor DebugColor;  // 0xE4(0x10)
	float DebugThickness;  // 0xF4(0x4)
	char pad_248[8];  // 0xF8(0x8)
	struct FTransform Result;  // 0x100(0x60)

}; 
// Function ControlRig.RigHierarchy.SetVectorArrayMetadata
// Size: 0x30(Inherited: 0x0) 
struct FSetVectorArrayMetadata
{
	struct FRigElementKey InItem;  // 0x0(0xC)
	struct FName InMetadataName;  // 0xC(0x8)
	char pad_20[4];  // 0x14(0x4)
	struct TArray<struct FVector> InValue;  // 0x18(0x10)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool ReturnValue : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)

}; 
// ScriptStruct ControlRig.RigUnit_MathTransformMirrorTransform
// Size: 0x140(Inherited: 0x8) 
struct FRigUnit_MathTransformMirrorTransform : public FRigUnit_MathTransformBase
{
	char pad_8[8];  // 0x8(0x8)
	struct FTransform Value;  // 0x10(0x60)
	char EAxis MirrorAxis;  // 0x70(0x1)
	char EAxis AxisToFlip;  // 0x71(0x1)
	char pad_114[14];  // 0x72(0xE)
	struct FTransform CentralTransform;  // 0x80(0x60)
	struct FTransform Result;  // 0xE0(0x60)

}; 
// ScriptStruct ControlRig.RigUnit_MathVectorBase
// Size: 0x8(Inherited: 0x8) 
struct FRigUnit_MathVectorBase : public FRigUnit_MathBase
{

}; 
// ScriptStruct ControlRig.RigUnit_MathVectorUnaryOp
// Size: 0x38(Inherited: 0x8) 
struct FRigUnit_MathVectorUnaryOp : public FRigUnit_MathVectorBase
{
	struct FVector Value;  // 0x8(0x18)
	struct FVector Result;  // 0x20(0x18)

}; 
// ScriptStruct ControlRig.RigUnit_MathVectorBinaryOp
// Size: 0x50(Inherited: 0x8) 
struct FRigUnit_MathVectorBinaryOp : public FRigUnit_MathVectorBase
{
	struct FVector A;  // 0x8(0x18)
	struct FVector B;  // 0x20(0x18)
	struct FVector Result;  // 0x38(0x18)

}; 
// ScriptStruct ControlRig.RigUnit_MathVectorBinaryAggregateOp
// Size: 0x50(Inherited: 0x8) 
struct FRigUnit_MathVectorBinaryAggregateOp : public FRigUnit_MathVectorBase
{
	struct FVector A;  // 0x8(0x18)
	struct FVector B;  // 0x20(0x18)
	struct FVector Result;  // 0x38(0x18)

}; 
// ScriptStruct ControlRig.RigUnit_MathVectorAdd
// Size: 0x50(Inherited: 0x50) 
struct FRigUnit_MathVectorAdd : public FRigUnit_MathVectorBinaryAggregateOp
{

}; 
// ScriptStruct ControlRig.RigUnit_MathVectorSub
// Size: 0x50(Inherited: 0x50) 
struct FRigUnit_MathVectorSub : public FRigUnit_MathVectorBinaryOp
{

}; 
// ScriptStruct ControlRig.RigUnit_MathVectorMul
// Size: 0x50(Inherited: 0x50) 
struct FRigUnit_MathVectorMul : public FRigUnit_MathVectorBinaryAggregateOp
{

}; 
// Function ControlRig.RigHierarchy.Num
// Size: 0x4(Inherited: 0x0) 
struct FNum
{
	int32_t ReturnValue;  // 0x0(0x4)

}; 
// ScriptStruct ControlRig.RigUnit_MathVectorScale
// Size: 0x40(Inherited: 0x8) 
struct FRigUnit_MathVectorScale : public FRigUnit_MathVectorBase
{
	struct FVector Value;  // 0x8(0x18)
	float Factor;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)
	struct FVector Result;  // 0x28(0x18)

}; 
// ScriptStruct ControlRig.RigUnit_MathVectorMin
// Size: 0x50(Inherited: 0x50) 
struct FRigUnit_MathVectorMin : public FRigUnit_MathVectorBinaryAggregateOp
{

}; 
// ScriptStruct ControlRig.RigUnit_MathVectorFloor
// Size: 0x38(Inherited: 0x38) 
struct FRigUnit_MathVectorFloor : public FRigUnit_MathVectorUnaryOp
{

}; 
// ScriptStruct ControlRig.RigUnit_MathVectorCeil
// Size: 0x38(Inherited: 0x38) 
struct FRigUnit_MathVectorCeil : public FRigUnit_MathVectorUnaryOp
{

}; 
// ScriptStruct ControlRig.RigUnit_MathVectorEquals
// Size: 0x40(Inherited: 0x8) 
struct FRigUnit_MathVectorEquals : public FRigUnit_MathVectorBase
{
	struct FVector A;  // 0x8(0x18)
	struct FVector B;  // 0x20(0x18)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool Result : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)

}; 
// ScriptStruct ControlRig.RigUnit_MathVectorDistance
// Size: 0x40(Inherited: 0x8) 
struct FRigUnit_MathVectorDistance : public FRigUnit_MathVectorBase
{
	struct FVector A;  // 0x8(0x18)
	struct FVector B;  // 0x20(0x18)
	float Result;  // 0x38(0x4)
	char pad_60[4];  // 0x3C(0x4)

}; 
// ScriptStruct ControlRig.RigUnit_MathVectorCross
// Size: 0x50(Inherited: 0x50) 
struct FRigUnit_MathVectorCross : public FRigUnit_MathVectorBinaryOp
{

}; 
// ScriptStruct ControlRig.RigUnit_MathVectorDot
// Size: 0x40(Inherited: 0x8) 
struct FRigUnit_MathVectorDot : public FRigUnit_MathVectorBase
{
	struct FVector A;  // 0x8(0x18)
	struct FVector B;  // 0x20(0x18)
	float Result;  // 0x38(0x4)
	char pad_60[4];  // 0x3C(0x4)

}; 
// Function ControlRig.ControlRigComponent.SetControlRotator
// Size: 0x28(Inherited: 0x0) 
struct FSetControlRotator
{
	struct FName ControlName;  // 0x0(0x8)
	struct FRotator Value;  // 0x8(0x18)
	uint8_t  Space;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// ScriptStruct ControlRig.RigUnit_MathVectorSetLength
// Size: 0x40(Inherited: 0x8) 
struct FRigUnit_MathVectorSetLength : public FRigUnit_MathVectorBase
{
	struct FVector Value;  // 0x8(0x18)
	float Length;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)
	struct FVector Result;  // 0x28(0x18)

}; 
// ScriptStruct ControlRig.RigUnit_MathVectorClampLength
// Size: 0x40(Inherited: 0x8) 
struct FRigUnit_MathVectorClampLength : public FRigUnit_MathVectorBase
{
	struct FVector Value;  // 0x8(0x18)
	float MinimumLength;  // 0x20(0x4)
	float MaximumLength;  // 0x24(0x4)
	struct FVector Result;  // 0x28(0x18)

}; 
// ScriptStruct ControlRig.RigUnit_MathVectorMakeAbsolute
// Size: 0x50(Inherited: 0x8) 
struct FRigUnit_MathVectorMakeAbsolute : public FRigUnit_MathVectorBase
{
	struct FVector Local;  // 0x8(0x18)
	struct FVector Parent;  // 0x20(0x18)
	struct FVector Global;  // 0x38(0x18)

}; 
// ScriptStruct ControlRig.RigUnit_MathVectorMirror
// Size: 0x50(Inherited: 0x8) 
struct FRigUnit_MathVectorMirror : public FRigUnit_MathVectorBase
{
	struct FVector Value;  // 0x8(0x18)
	struct FVector Normal;  // 0x20(0x18)
	struct FVector Result;  // 0x38(0x18)

}; 
// Function ControlRig.RigHierarchy.GetVectorFromControlValue
// Size: 0x110(Inherited: 0x0) 
struct FGetVectorFromControlValue
{
	struct FRigControlValue InValue;  // 0x0(0xF0)
	struct FVector ReturnValue;  // 0xF0(0x18)
	char pad_264[8];  // 0x108(0x8)

}; 
// ScriptStruct ControlRig.RigUnit_MathVectorOrthogonal
// Size: 0x40(Inherited: 0x8) 
struct FRigUnit_MathVectorOrthogonal : public FRigUnit_MathVectorBase
{
	struct FVector A;  // 0x8(0x18)
	struct FVector B;  // 0x20(0x18)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool Result : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)

}; 
// ScriptStruct ControlRig.RigUnit_MathVectorBezierFourPoint
// Size: 0xA0(Inherited: 0x8) 
struct FRigUnit_MathVectorBezierFourPoint : public FRigUnit_MathVectorBase
{
	struct FCRFourPointBezier Bezier;  // 0x8(0x60)
	float T;  // 0x68(0x4)
	char pad_108[4];  // 0x6C(0x4)
	struct FVector Result;  // 0x70(0x18)
	struct FVector Tangent;  // 0x88(0x18)

}; 
// ScriptStruct ControlRig.RigUnit_MathIntersectPlane
// Size: 0x88(Inherited: 0x8) 
struct FRigUnit_MathIntersectPlane : public FRigUnit_MathVectorBase
{
	struct FVector Start;  // 0x8(0x18)
	struct FVector Direction;  // 0x20(0x18)
	struct FVector PlanePoint;  // 0x38(0x18)
	struct FVector PlaneNormal;  // 0x50(0x18)
	struct FVector Result;  // 0x68(0x18)
	float Distance;  // 0x80(0x4)
	char pad_132[4];  // 0x84(0x4)

}; 
// ScriptStruct ControlRig.RigUnit_MathVectorMakeRelative
// Size: 0x50(Inherited: 0x8) 
struct FRigUnit_MathVectorMakeRelative : public FRigUnit_MathVectorBase
{
	struct FVector Global;  // 0x8(0x18)
	struct FVector Parent;  // 0x20(0x18)
	struct FVector Local;  // 0x38(0x18)

}; 
// ScriptStruct ControlRig.RigUnit_MathVectorMirrorTransform
// Size: 0xB0(Inherited: 0x8) 
struct FRigUnit_MathVectorMirrorTransform : public FRigUnit_MathVectorBase
{
	struct FVector Value;  // 0x8(0x18)
	char EAxis MirrorAxis;  // 0x20(0x1)
	char EAxis AxisToFlip;  // 0x21(0x1)
	char pad_34[14];  // 0x22(0xE)
	struct FTransform CentralTransform;  // 0x30(0x60)
	struct FVector Result;  // 0x90(0x18)
	char pad_168[8];  // 0xA8(0x8)

}; 
// Function ControlRig.RigHierarchy.GetTransformFromControlValue
// Size: 0x150(Inherited: 0x0) 
struct FGetTransformFromControlValue
{
	struct FRigControlValue InValue;  // 0x0(0xF0)
	struct FTransform ReturnValue;  // 0xF0(0x60)

}; 
// ScriptStruct ControlRig.RigUnit_NoiseFloat
// Size: 0x28(Inherited: 0x8) 
struct FRigUnit_NoiseFloat : public FRigUnit_MathBase
{
	float Value;  // 0x8(0x4)
	float Speed;  // 0xC(0x4)
	float Frequency;  // 0x10(0x4)
	float Minimum;  // 0x14(0x4)
	float Maximum;  // 0x18(0x4)
	float Result;  // 0x1C(0x4)
	float time;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)

}; 
// ScriptStruct ControlRig.RigUnit_NoiseVector
// Size: 0x88(Inherited: 0x8) 
struct FRigUnit_NoiseVector : public FRigUnit_MathBase
{
	struct FVector position;  // 0x8(0x18)
	struct FVector Speed;  // 0x20(0x18)
	struct FVector Frequency;  // 0x38(0x18)
	float Minimum;  // 0x50(0x4)
	float Maximum;  // 0x54(0x4)
	struct FVector Result;  // 0x58(0x18)
	struct FVector time;  // 0x70(0x18)

}; 
// ScriptStruct ControlRig.RigUnit_RandomVector
// Size: 0x58(Inherited: 0x8) 
struct FRigUnit_RandomVector : public FRigUnit_MathBase
{
	int32_t Seed;  // 0x8(0x4)
	float Minimum;  // 0xC(0x4)
	float Maximum;  // 0x10(0x4)
	float Duration;  // 0x14(0x4)
	struct FVector Result;  // 0x18(0x18)
	struct FVector LastResult;  // 0x30(0x18)
	int32_t LastSeed;  // 0x48(0x4)
	int32_t BaseSeed;  // 0x4C(0x4)
	float TimeLeft;  // 0x50(0x4)
	char pad_84[4];  // 0x54(0x4)

}; 
// ScriptStruct ControlRig.RigUnit_AccumulateBase
// Size: 0x8(Inherited: 0x8) 
struct FRigUnit_AccumulateBase : public FRigUnit_SimBase
{

}; 
// ScriptStruct ControlRig.RigUnit_AccumulateVectorAdd
// Size: 0x70(Inherited: 0x8) 
struct FRigUnit_AccumulateVectorAdd : public FRigUnit_AccumulateBase
{
	struct FVector Increment;  // 0x8(0x18)
	struct FVector InitialValue;  // 0x20(0x18)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool bIntegrateDeltaTime : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct FVector Result;  // 0x40(0x18)
	struct FVector AccumulatedValue;  // 0x58(0x18)

}; 
// Function ControlRig.RigHierarchy.GetChildren
// Size: 0x20(Inherited: 0x0) 
struct FGetChildren
{
	struct FRigElementKey InKey;  // 0x0(0xC)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool bRecursive : 1;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)
	struct TArray<struct FRigElementKey> ReturnValue;  // 0x10(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_AccumulateVectorMul
// Size: 0x70(Inherited: 0x8) 
struct FRigUnit_AccumulateVectorMul : public FRigUnit_AccumulateBase
{
	struct FVector Multiplier;  // 0x8(0x18)
	struct FVector InitialValue;  // 0x20(0x18)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool bIntegrateDeltaTime : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct FVector Result;  // 0x40(0x18)
	struct FVector AccumulatedValue;  // 0x58(0x18)

}; 
// ScriptStruct ControlRig.RigUnit_AccumulateTransformMul
// Size: 0x1A0(Inherited: 0x8) 
struct FRigUnit_AccumulateTransformMul : public FRigUnit_AccumulateBase
{
	char pad_8[8];  // 0x8(0x8)
	struct FTransform Multiplier;  // 0x10(0x60)
	struct FTransform InitialValue;  // 0x70(0x60)
	char pad_208_1 : 7;  // 0xD0(0x1)
	bool bFlipOrder : 1;  // 0xD0(0x1)
	char pad_209_1 : 7;  // 0xD1(0x1)
	bool bIntegrateDeltaTime : 1;  // 0xD1(0x1)
	char pad_210[14];  // 0xD2(0xE)
	struct FTransform Result;  // 0xE0(0x60)
	struct FTransform AccumulatedValue;  // 0x140(0x60)

}; 
// ScriptStruct ControlRig.RigUnit_AccumulateVectorRange
// Size: 0x80(Inherited: 0x8) 
struct FRigUnit_AccumulateVectorRange : public FRigUnit_AccumulateBase
{
	struct FVector Value;  // 0x8(0x18)
	struct FVector Minimum;  // 0x20(0x18)
	struct FVector Maximum;  // 0x38(0x18)
	struct FVector AccumulatedMinimum;  // 0x50(0x18)
	struct FVector AccumulatedMaximum;  // 0x68(0x18)

}; 
// ScriptStruct ControlRig.RigUnit_AlphaInterpQuat
// Size: 0xC0(Inherited: 0x8) 
struct FRigUnit_AlphaInterpQuat : public FRigUnit_SimBase
{
	char pad_8[8];  // 0x8(0x8)
	struct FQuat Value;  // 0x10(0x20)
	float Scale;  // 0x30(0x4)
	float Bias;  // 0x34(0x4)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool bMapRange : 1;  // 0x38(0x1)
	char pad_57[3];  // 0x39(0x3)
	struct FInputRange InRange;  // 0x3C(0x8)
	struct FInputRange OutRange;  // 0x44(0x8)
	char pad_76_1 : 7;  // 0x4C(0x1)
	bool bClampResult : 1;  // 0x4C(0x1)
	char pad_77[3];  // 0x4D(0x3)
	float ClampMin;  // 0x50(0x4)
	float ClampMax;  // 0x54(0x4)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool bInterpResult : 1;  // 0x58(0x1)
	char pad_89[3];  // 0x59(0x3)
	float InterpSpeedIncreasing;  // 0x5C(0x4)
	float InterpSpeedDecreasing;  // 0x60(0x4)
	char pad_100[12];  // 0x64(0xC)
	struct FQuat Result;  // 0x70(0x20)
	struct FInputScaleBiasClamp ScaleBiasClamp;  // 0x90(0x30)

}; 
// Function ControlRig.RigHierarchy.FindBone_ForBlueprintOnly
// Size: 0x310(Inherited: 0x0) 
struct FFindBone_ForBlueprintOnly
{
	struct FRigElementKey InKey;  // 0x0(0xC)
	char pad_12[4];  // 0xC(0x4)
	struct FRigBoneElement ReturnValue;  // 0x10(0x300)

}; 
// ScriptStruct ControlRig.RigUnit_DeltaFromPreviousFloat
// Size: 0x18(Inherited: 0x8) 
struct FRigUnit_DeltaFromPreviousFloat : public FRigUnit_SimBase
{
	float Value;  // 0x8(0x4)
	float Delta;  // 0xC(0x4)
	float PreviousValue;  // 0x10(0x4)
	float Cache;  // 0x14(0x4)

}; 
// ScriptStruct ControlRig.RigUnit_DeltaFromPreviousVector
// Size: 0x68(Inherited: 0x8) 
struct FRigUnit_DeltaFromPreviousVector : public FRigUnit_SimBase
{
	struct FVector Value;  // 0x8(0x18)
	struct FVector Delta;  // 0x20(0x18)
	struct FVector PreviousValue;  // 0x38(0x18)
	struct FVector Cache;  // 0x50(0x18)

}; 
// ScriptStruct ControlRig.RigUnit_DeltaFromPreviousQuat
// Size: 0x90(Inherited: 0x8) 
struct FRigUnit_DeltaFromPreviousQuat : public FRigUnit_SimBase
{
	char pad_8[8];  // 0x8(0x8)
	struct FQuat Value;  // 0x10(0x20)
	struct FQuat Delta;  // 0x30(0x20)
	struct FQuat PreviousValue;  // 0x50(0x20)
	struct FQuat Cache;  // 0x70(0x20)

}; 
// ScriptStruct ControlRig.RigUnit_KalmanFloat
// Size: 0x30(Inherited: 0x8) 
struct FRigUnit_KalmanFloat : public FRigUnit_SimBase
{
	float Value;  // 0x8(0x4)
	int32_t BufferSize;  // 0xC(0x4)
	float Result;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct TArray<float> Buffer;  // 0x18(0x10)
	int32_t LastInsertIndex;  // 0x28(0x4)
	char pad_44[4];  // 0x2C(0x4)

}; 
// ScriptStruct ControlRig.RigUnit_KalmanVector
// Size: 0x58(Inherited: 0x8) 
struct FRigUnit_KalmanVector : public FRigUnit_SimBase
{
	struct FVector Value;  // 0x8(0x18)
	int32_t BufferSize;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)
	struct FVector Result;  // 0x28(0x18)
	struct TArray<struct FVector> Buffer;  // 0x40(0x10)
	int32_t LastInsertIndex;  // 0x50(0x4)
	char pad_84[4];  // 0x54(0x4)

}; 
// ScriptStruct ControlRig.RigUnit_KalmanTransform
// Size: 0x100(Inherited: 0x8) 
struct FRigUnit_KalmanTransform : public FRigUnit_SimBase
{
	char pad_8[8];  // 0x8(0x8)
	struct FTransform Value;  // 0x10(0x60)
	int32_t BufferSize;  // 0x70(0x4)
	char pad_116[12];  // 0x74(0xC)
	struct FTransform Result;  // 0x80(0x60)
	struct TArray<struct FTransform> Buffer;  // 0xE0(0x10)
	int32_t LastInsertIndex;  // 0xF0(0x4)
	char pad_244[12];  // 0xF4(0xC)

}; 
// ScriptStruct ControlRig.RigUnit_PointSimulation_WorkData
// Size: 0x88(Inherited: 0x0) 
struct FRigUnit_PointSimulation_WorkData
{
	struct FCRSimPointContainer Simulation;  // 0x0(0x78)
	struct TArray<struct FCachedRigElement> BoneIndices;  // 0x78(0x10)

}; 
// ScriptStruct ControlRig.RigUnit_SpringInterp
// Size: 0x30(Inherited: 0x8) 
struct FRigUnit_SpringInterp : public FRigUnit_SimBase
{
	float Current;  // 0x8(0x4)
	float Target;  // 0xC(0x4)
	float Stiffness;  // 0x10(0x4)
	float CriticalDamping;  // 0x14(0x4)
	float Mass;  // 0x18(0x4)
	float Result;  // 0x1C(0x4)
	struct FFloatSpringState SpringState;  // 0x20(0xC)
	char pad_44[4];  // 0x2C(0x4)

}; 
// Function ControlRig.RigHierarchyController.SetControlSettings
// Size: 0x2A0(Inherited: 0x0) 
struct FSetControlSettings
{
	struct FRigElementKey InKey;  // 0x0(0xC)
	char pad_12[4];  // 0xC(0x4)
	struct FRigControlSettings InSettings;  // 0x10(0x280)
	char pad_656_1 : 7;  // 0x290(0x1)
	bool bSetupUndo : 1;  // 0x290(0x1)
	char pad_657_1 : 7;  // 0x291(0x1)
	bool ReturnValue : 1;  // 0x291(0x1)
	char pad_658[14];  // 0x292(0xE)

}; 
// ScriptStruct ControlRig.RigUnit_SpringInterpVector
// Size: 0x98(Inherited: 0x8) 
struct FRigUnit_SpringInterpVector : public FRigUnit_SimBase
{
	struct FVector Current;  // 0x8(0x18)
	struct FVector Target;  // 0x20(0x18)
	float Stiffness;  // 0x38(0x4)
	float CriticalDamping;  // 0x3C(0x4)
	float Mass;  // 0x40(0x4)
	char pad_68[4];  // 0x44(0x4)
	struct FVector Result;  // 0x48(0x18)
	struct FVectorSpringState SpringState;  // 0x60(0x38)

}; 
// ScriptStruct ControlRig.RigUnit_SpringInterpVectorV2
// Size: 0xE8(Inherited: 0x8) 
struct FRigUnit_SpringInterpVectorV2 : public FRigUnit_SimBase
{
	struct FVector Target;  // 0x8(0x18)
	float Strength;  // 0x20(0x4)
	float CriticalDamping;  // 0x24(0x4)
	struct FVector Force;  // 0x28(0x18)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool bUseCurrentInput : 1;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)
	struct FVector Current;  // 0x48(0x18)
	float TargetVelocityAmount;  // 0x60(0x4)
	char pad_100_1 : 7;  // 0x64(0x1)
	bool bInitializeFromTarget : 1;  // 0x64(0x1)
	char pad_101[3];  // 0x65(0x3)
	struct FVector Result;  // 0x68(0x18)
	struct FVector Velocity;  // 0x80(0x18)
	struct FVector SimulatedResult;  // 0x98(0x18)
	struct FVectorSpringState SpringState;  // 0xB0(0x38)

}; 
// ScriptStruct ControlRig.RigUnit_Timeline
// Size: 0x18(Inherited: 0x8) 
struct FRigUnit_Timeline : public FRigUnit_SimBase
{
	float Speed;  // 0x8(0x4)
	float time;  // 0xC(0x4)
	float AccumulatedValue;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)

}; 
// ScriptStruct ControlRig.RigUnit_TimeOffsetFloat
// Size: 0x48(Inherited: 0x8) 
struct FRigUnit_TimeOffsetFloat : public FRigUnit_SimBase
{
	float Value;  // 0x8(0x4)
	float SecondsAgo;  // 0xC(0x4)
	int32_t BufferSize;  // 0x10(0x4)
	float TimeRange;  // 0x14(0x4)
	float Result;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct TArray<float> Buffer;  // 0x20(0x10)
	struct TArray<float> DeltaTimes;  // 0x30(0x10)
	int32_t LastInsertIndex;  // 0x40(0x4)
	int32_t UpperBound;  // 0x44(0x4)

}; 
// Function ControlRig.ControlRigComponent.Update
// Size: 0x4(Inherited: 0x0) 
struct FUpdate
{
	float DeltaTime;  // 0x0(0x4)

}; 
// ScriptStruct ControlRig.RigUnit_TimeOffsetTransform
// Size: 0x110(Inherited: 0x8) 
struct FRigUnit_TimeOffsetTransform : public FRigUnit_SimBase
{
	char pad_8[8];  // 0x8(0x8)
	struct FTransform Value;  // 0x10(0x60)
	float SecondsAgo;  // 0x70(0x4)
	int32_t BufferSize;  // 0x74(0x4)
	float TimeRange;  // 0x78(0x4)
	char pad_124[4];  // 0x7C(0x4)
	struct FTransform Result;  // 0x80(0x60)
	struct TArray<struct FTransform> Buffer;  // 0xE0(0x10)
	struct TArray<float> DeltaTimes;  // 0xF0(0x10)
	int32_t LastInsertIndex;  // 0x100(0x4)
	int32_t UpperBound;  // 0x104(0x4)
	char pad_264[8];  // 0x108(0x8)

}; 
// Function ControlRig.RigHierarchy.GetTransformMetadata
// Size: 0xE0(Inherited: 0x0) 
struct FGetTransformMetadata
{
	struct FRigElementKey InItem;  // 0x0(0xC)
	struct FName InMetadataName;  // 0xC(0x8)
	char pad_20[12];  // 0x14(0xC)
	struct FTransform DefaultValue;  // 0x20(0x60)
	struct FTransform ReturnValue;  // 0x80(0x60)

}; 
// ScriptStruct ControlRig.RigUnit_VerletIntegrateVector
// Size: 0xD8(Inherited: 0x8) 
struct FRigUnit_VerletIntegrateVector : public FRigUnit_SimBase
{
	struct FVector Target;  // 0x8(0x18)
	float Strength;  // 0x20(0x4)
	float Damp;  // 0x24(0x4)
	float Blend;  // 0x28(0x4)
	char pad_44[4];  // 0x2C(0x4)
	struct FVector Force;  // 0x30(0x18)
	struct FVector position;  // 0x48(0x18)
	struct FVector Velocity;  // 0x60(0x18)
	struct FVector Acceleration;  // 0x78(0x18)
	struct FCRSimPoint Point;  // 0x90(0x40)
	char pad_208_1 : 7;  // 0xD0(0x1)
	bool bInitialized : 1;  // 0xD0(0x1)
	char pad_209[7];  // 0xD1(0x7)

}; 
// Function ControlRig.RigHierarchy.Contains_ForBlueprint
// Size: 0x10(Inherited: 0x0) 
struct FContains_ForBlueprint
{
	struct FRigElementKey InKey;  // 0x0(0xC)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool ReturnValue : 1;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)

}; 
// Function ControlRig.RigHierarchy.CopyPose
// Size: 0x10(Inherited: 0x0) 
struct FCopyPose
{
	struct URigHierarchy* InHierarchy;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bCurrent : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool bInitial : 1;  // 0x9(0x1)
	char pad_10_1 : 7;  // 0xA(0x1)
	bool bWeights : 1;  // 0xA(0x1)
	char pad_11_1 : 7;  // 0xB(0x1)
	bool bMatchPoseInGlobalIfNeeded : 1;  // 0xB(0x1)
	char pad_12[4];  // 0xC(0x4)

}; 
// Function ControlRig.RigHierarchy.FindControl_ForBlueprintOnly
// Size: 0xA40(Inherited: 0x0) 
struct FFindControl_ForBlueprintOnly
{
	struct FRigElementKey InKey;  // 0x0(0xC)
	char pad_12[4];  // 0xC(0x4)
	struct FRigControlElement ReturnValue;  // 0x10(0xA30)

}; 
// Function ControlRig.RigHierarchy.GetBoneKeys
// Size: 0x18(Inherited: 0x0) 
struct FGetBoneKeys
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bTraverse : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct TArray<struct FRigElementKey> ReturnValue;  // 0x8(0x10)

}; 
// Function ControlRig.RigHierarchy.GetBoolArrayMetadata
// Size: 0x28(Inherited: 0x0) 
struct FGetBoolArrayMetadata
{
	struct FRigElementKey InItem;  // 0x0(0xC)
	struct FName InMetadataName;  // 0xC(0x8)
	char pad_20[4];  // 0x14(0x4)
	struct TArray<bool> ReturnValue;  // 0x18(0x10)

}; 
// Function ControlRig.ControlRigComponent.SetControlScale
// Size: 0x28(Inherited: 0x0) 
struct FSetControlScale
{
	struct FName ControlName;  // 0x0(0x8)
	struct FVector Value;  // 0x8(0x18)
	uint8_t  Space;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// Function ControlRig.RigHierarchy.GetBoolMetadata
// Size: 0x18(Inherited: 0x0) 
struct FGetBoolMetadata
{
	struct FRigElementKey InItem;  // 0x0(0xC)
	struct FName InMetadataName;  // 0xC(0x8)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool DefaultValue : 1;  // 0x14(0x1)
	char pad_21_1 : 7;  // 0x15(0x1)
	bool ReturnValue : 1;  // 0x15(0x1)
	char pad_22[2];  // 0x16(0x2)

}; 
// Function ControlRig.RigHierarchy.GetControlKeys
// Size: 0x18(Inherited: 0x0) 
struct FGetControlKeys
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bTraverse : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct TArray<struct FRigElementKey> ReturnValue;  // 0x8(0x10)

}; 
// Function ControlRig.RigHierarchy.GetControlPreferredRotatorByIndex
// Size: 0x20(Inherited: 0x0) 
struct FGetControlPreferredRotatorByIndex
{
	int32_t InElementIndex;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool bInitial : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct FRotator ReturnValue;  // 0x8(0x18)

}; 
// Function ControlRig.RigHierarchy.HasTag
// Size: 0x18(Inherited: 0x0) 
struct FHasTag
{
	struct FRigElementKey InItem;  // 0x0(0xC)
	struct FName InTag;  // 0xC(0x8)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool ReturnValue : 1;  // 0x14(0x1)
	char pad_21[3];  // 0x15(0x3)

}; 
// Function ControlRig.RigHierarchy.GetControlValue
// Size: 0x100(Inherited: 0x0) 
struct FGetControlValue
{
	struct FRigElementKey InKey;  // 0x0(0xC)
	uint8_t  InValueType;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)
	struct FRigControlValue ReturnValue;  // 0x10(0xF0)

}; 
// Function ControlRig.RigHierarchy.GetControlValueByIndex
// Size: 0x100(Inherited: 0x0) 
struct FGetControlValueByIndex
{
	int32_t InElementIndex;  // 0x0(0x4)
	uint8_t  InValueType;  // 0x4(0x1)
	char pad_5[11];  // 0x5(0xB)
	struct FRigControlValue ReturnValue;  // 0x10(0xF0)

}; 
// Function ControlRig.RigHierarchy.GetCurveKeys
// Size: 0x10(Inherited: 0x0) 
struct FGetCurveKeys
{
	struct TArray<struct FRigElementKey> ReturnValue;  // 0x0(0x10)

}; 
// Function ControlRig.RigHierarchy.GetEulerTransformFromControlValue
// Size: 0x140(Inherited: 0x0) 
struct FGetEulerTransformFromControlValue
{
	struct FRigControlValue InValue;  // 0x0(0xF0)
	struct FEulerTransform ReturnValue;  // 0xF0(0x48)
	char pad_312[8];  // 0x138(0x8)

}; 
// Function ControlRig.RigHierarchy.GetQuatMetadata
// Size: 0x60(Inherited: 0x0) 
struct FGetQuatMetadata
{
	struct FRigElementKey InItem;  // 0x0(0xC)
	struct FName InMetadataName;  // 0xC(0x8)
	char pad_20[12];  // 0x14(0xC)
	struct FQuat DefaultValue;  // 0x20(0x20)
	struct FQuat ReturnValue;  // 0x40(0x20)

}; 
// Function ControlRig.RigHierarchy.GetFloatArrayMetadata
// Size: 0x28(Inherited: 0x0) 
struct FGetFloatArrayMetadata
{
	struct FRigElementKey InItem;  // 0x0(0xC)
	struct FName InMetadataName;  // 0xC(0x8)
	char pad_20[4];  // 0x14(0x4)
	struct TArray<float> ReturnValue;  // 0x18(0x10)

}; 
// Function ControlRig.RigHierarchy.GetGlobalControlOffsetTransform
// Size: 0x70(Inherited: 0x0) 
struct FGetGlobalControlOffsetTransform
{
	struct FRigElementKey InKey;  // 0x0(0xC)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool bInitial : 1;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)
	struct FTransform ReturnValue;  // 0x10(0x60)

}; 
// Function ControlRig.RigHierarchy.GetGlobalControlShapeTransform
// Size: 0x70(Inherited: 0x0) 
struct FGetGlobalControlShapeTransform
{
	struct FRigElementKey InKey;  // 0x0(0xC)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool bInitial : 1;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)
	struct FTransform ReturnValue;  // 0x10(0x60)

}; 
// Function ControlRig.RigHierarchy.GetGlobalControlShapeTransformByIndex
// Size: 0x70(Inherited: 0x0) 
struct FGetGlobalControlShapeTransformByIndex
{
	int32_t InElementIndex;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool bInitial : 1;  // 0x4(0x1)
	char pad_5[11];  // 0x5(0xB)
	struct FTransform ReturnValue;  // 0x10(0x60)

}; 
// Function ControlRig.RigHierarchy.GetGlobalTransformByIndex
// Size: 0x70(Inherited: 0x0) 
struct FGetGlobalTransformByIndex
{
	int32_t InElementIndex;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool bInitial : 1;  // 0x4(0x1)
	char pad_5[11];  // 0x5(0xB)
	struct FTransform ReturnValue;  // 0x10(0x60)

}; 
// Function ControlRig.ControlRigComponent.OnPreConstruction
// Size: 0x8(Inherited: 0x0) 
struct FOnPreConstruction
{
	struct UControlRigComponent* Component;  // 0x0(0x8)

}; 
// Function ControlRig.RigHierarchy.GetIndex_ForBlueprint
// Size: 0x10(Inherited: 0x0) 
struct FGetIndex_ForBlueprint
{
	struct FRigElementKey InKey;  // 0x0(0xC)
	int32_t ReturnValue;  // 0xC(0x4)

}; 
// Function ControlRig.RigHierarchy.GetInt32Metadata
// Size: 0x1C(Inherited: 0x0) 
struct FGetInt32Metadata
{
	struct FRigElementKey InItem;  // 0x0(0xC)
	struct FName InMetadataName;  // 0xC(0x8)
	int32_t DefaultValue;  // 0x14(0x4)
	int32_t ReturnValue;  // 0x18(0x4)

}; 
// Function ControlRig.RigHierarchy.GetIntFromControlValue
// Size: 0x100(Inherited: 0x0) 
struct FGetIntFromControlValue
{
	struct FRigControlValue InValue;  // 0x0(0xF0)
	int32_t ReturnValue;  // 0xF0(0x4)
	char pad_244[12];  // 0xF4(0xC)

}; 
// Function ControlRig.RigHierarchy.GetPreviousParent
// Size: 0x18(Inherited: 0x0) 
struct FGetPreviousParent
{
	struct FRigElementKey InKey;  // 0x0(0xC)
	struct FRigElementKey ReturnValue;  // 0xC(0xC)

}; 
// Function ControlRig.RigHierarchy.SetCurveValueByIndex
// Size: 0xC(Inherited: 0x0) 
struct FSetCurveValueByIndex
{
	int32_t InElementIndex;  // 0x0(0x4)
	float InValue;  // 0x4(0x4)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bSetupUndo : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)

}; 
// Function ControlRig.RigHierarchy.GetLinearColorArrayMetadata
// Size: 0x28(Inherited: 0x0) 
struct FGetLinearColorArrayMetadata
{
	struct FRigElementKey InItem;  // 0x0(0xC)
	struct FName InMetadataName;  // 0xC(0x8)
	char pad_20[4];  // 0x14(0x4)
	struct TArray<struct FLinearColor> ReturnValue;  // 0x18(0x10)

}; 
// Function ControlRig.RigHierarchy.GetLocalControlShapeTransform
// Size: 0x70(Inherited: 0x0) 
struct FGetLocalControlShapeTransform
{
	struct FRigElementKey InKey;  // 0x0(0xC)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool bInitial : 1;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)
	struct FTransform ReturnValue;  // 0x10(0x60)

}; 
// Function ControlRig.RigHierarchy.GetLocalControlShapeTransformByIndex
// Size: 0x70(Inherited: 0x0) 
struct FGetLocalControlShapeTransformByIndex
{
	int32_t InElementIndex;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool bInitial : 1;  // 0x4(0x1)
	char pad_5[11];  // 0x5(0xB)
	struct FTransform ReturnValue;  // 0x10(0x60)

}; 
// Function ControlRig.RigHierarchy.GetMetadataNames
// Size: 0x20(Inherited: 0x0) 
struct FGetMetadataNames
{
	struct FRigElementKey InItem;  // 0x0(0xC)
	char pad_12[4];  // 0xC(0x4)
	struct TArray<struct FName> ReturnValue;  // 0x10(0x10)

}; 
// Function ControlRig.RigHierarchy.GetMetadataType
// Size: 0x18(Inherited: 0x0) 
struct FGetMetadataType
{
	struct FRigElementKey InItem;  // 0x0(0xC)
	struct FName InMetadataName;  // 0xC(0x8)
	uint8_t  ReturnValue;  // 0x14(0x1)
	char pad_21[3];  // 0x15(0x3)

}; 
// Function ControlRig.RigHierarchy.GetNameArrayMetadata
// Size: 0x28(Inherited: 0x0) 
struct FGetNameArrayMetadata
{
	struct FRigElementKey InItem;  // 0x0(0xC)
	struct FName InMetadataName;  // 0xC(0x8)
	char pad_20[4];  // 0x14(0x4)
	struct TArray<struct FName> ReturnValue;  // 0x18(0x10)

}; 
// Function ControlRig.RigHierarchy.GetNullKeys
// Size: 0x18(Inherited: 0x0) 
struct FGetNullKeys
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bTraverse : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct TArray<struct FRigElementKey> ReturnValue;  // 0x8(0x10)

}; 
// Function ControlRig.RigHierarchy.GetParentTransform
// Size: 0x70(Inherited: 0x0) 
struct FGetParentTransform
{
	struct FRigElementKey InKey;  // 0x0(0xC)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool bInitial : 1;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)
	struct FTransform ReturnValue;  // 0x10(0x60)

}; 
// Function ControlRig.RigHierarchy.GetParentTransformByIndex
// Size: 0x70(Inherited: 0x0) 
struct FGetParentTransformByIndex
{
	int32_t InElementIndex;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool bInitial : 1;  // 0x4(0x1)
	char pad_5[11];  // 0x5(0xB)
	struct FTransform ReturnValue;  // 0x10(0x60)

}; 
// Function ControlRig.RigHierarchy.GetPose
// Size: 0x78(Inherited: 0x0) 
struct FGetPose
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bInitial : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FRigPose ReturnValue;  // 0x8(0x70)

}; 
// Function ControlRig.RigHierarchy.GetPreviousName
// Size: 0x14(Inherited: 0x0) 
struct FGetPreviousName
{
	struct FRigElementKey InKey;  // 0x0(0xC)
	struct FName ReturnValue;  // 0xC(0x8)

}; 
// Function ControlRig.RigHierarchy.GetQuatArrayMetadata
// Size: 0x28(Inherited: 0x0) 
struct FGetQuatArrayMetadata
{
	struct FRigElementKey InItem;  // 0x0(0xC)
	struct FName InMetadataName;  // 0xC(0x8)
	char pad_20[4];  // 0x14(0x4)
	struct TArray<struct FQuat> ReturnValue;  // 0x18(0x10)

}; 
// Function ControlRig.RigHierarchy.SetNameArrayMetadata
// Size: 0x30(Inherited: 0x0) 
struct FSetNameArrayMetadata
{
	struct FRigElementKey InItem;  // 0x0(0xC)
	struct FName InMetadataName;  // 0xC(0x8)
	char pad_20[4];  // 0x14(0x4)
	struct TArray<struct FName> InValue;  // 0x18(0x10)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool ReturnValue : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)

}; 
// Function ControlRig.RigHierarchy.GetRigElementKeyArrayMetadata
// Size: 0x28(Inherited: 0x0) 
struct FGetRigElementKeyArrayMetadata
{
	struct FRigElementKey InItem;  // 0x0(0xC)
	struct FName InMetadataName;  // 0xC(0x8)
	char pad_20[4];  // 0x14(0x4)
	struct TArray<struct FRigElementKey> ReturnValue;  // 0x18(0x10)

}; 
// Function ControlRig.RigHierarchy.GetRigidBodyKeys
// Size: 0x18(Inherited: 0x0) 
struct FGetRigidBodyKeys
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bTraverse : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct TArray<struct FRigElementKey> ReturnValue;  // 0x8(0x10)

}; 
// Function ControlRig.RigHierarchy.GetVectorArrayMetadata
// Size: 0x28(Inherited: 0x0) 
struct FGetVectorArrayMetadata
{
	struct FRigElementKey InItem;  // 0x0(0xC)
	struct FName InMetadataName;  // 0xC(0x8)
	char pad_20[4];  // 0x14(0x4)
	struct TArray<struct FVector> ReturnValue;  // 0x18(0x10)

}; 
// Function ControlRig.RigHierarchy.IsCurveValueSet
// Size: 0x10(Inherited: 0x0) 
struct FIsCurveValueSet
{
	struct FRigElementKey InKey;  // 0x0(0xC)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool ReturnValue : 1;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)

}; 
// Function ControlRig.RigHierarchy.IsCurveValueSetByIndex
// Size: 0x8(Inherited: 0x0) 
struct FIsCurveValueSetByIndex
{
	int32_t InElementIndex;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool ReturnValue : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)

}; 
// Function ControlRig.RigHierarchy.IsProcedural
// Size: 0x10(Inherited: 0x0) 
struct FIsProcedural
{
	struct FRigElementKey InKey;  // 0x0(0xC)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool ReturnValue : 1;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)

}; 
// Function ControlRig.RigHierarchy.MakeControlValueFromEulerTransform
// Size: 0x140(Inherited: 0x0) 
struct FMakeControlValueFromEulerTransform
{
	struct FEulerTransform InValue;  // 0x0(0x48)
	char pad_72[8];  // 0x48(0x8)
	struct FRigControlValue ReturnValue;  // 0x50(0xF0)

}; 
// Function ControlRig.RigHierarchy.MakeControlValueFromInt
// Size: 0x100(Inherited: 0x0) 
struct FMakeControlValueFromInt
{
	int32_t InValue;  // 0x0(0x4)
	char pad_4[12];  // 0x4(0xC)
	struct FRigControlValue ReturnValue;  // 0x10(0xF0)

}; 
// Function ControlRig.RigHierarchy.MakeControlValueFromVector
// Size: 0x110(Inherited: 0x0) 
struct FMakeControlValueFromVector
{
	struct FVector InValue;  // 0x0(0x18)
	char pad_24[8];  // 0x18(0x8)
	struct FRigControlValue ReturnValue;  // 0x20(0xF0)

}; 
// Function ControlRig.RigHierarchy.MakeControlValueFromVector2D
// Size: 0x100(Inherited: 0x0) 
struct FMakeControlValueFromVector2D
{
	struct FVector2D InValue;  // 0x0(0x10)
	struct FRigControlValue ReturnValue;  // 0x10(0xF0)

}; 
// Function ControlRig.RigHierarchy.RemoveAllMetadata
// Size: 0x10(Inherited: 0x0) 
struct FRemoveAllMetadata
{
	struct FRigElementKey InItem;  // 0x0(0xC)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool ReturnValue : 1;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)

}; 
// Function ControlRig.RigHierarchy.RemoveMetadata
// Size: 0x18(Inherited: 0x0) 
struct FRemoveMetadata
{
	struct FRigElementKey InItem;  // 0x0(0xC)
	struct FName InMetadataName;  // 0xC(0x8)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool ReturnValue : 1;  // 0x14(0x1)
	char pad_21[3];  // 0x15(0x3)

}; 
// Function ControlRig.RigHierarchy.SendAutoKeyEvent
// Size: 0x14(Inherited: 0x0) 
struct FSendAutoKeyEvent
{
	struct FRigElementKey InElement;  // 0x0(0xC)
	float InOffsetInSeconds;  // 0xC(0x4)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bAsynchronous : 1;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)

}; 
// Function ControlRig.RigHierarchy.SetControlSettingsByIndex
// Size: 0x2A0(Inherited: 0x0) 
struct FSetControlSettingsByIndex
{
	int32_t InElementIndex;  // 0x0(0x4)
	char pad_4[12];  // 0x4(0xC)
	struct FRigControlSettings InSettings;  // 0x10(0x280)
	char pad_656_1 : 7;  // 0x290(0x1)
	bool bSetupUndo : 1;  // 0x290(0x1)
	char pad_657_1 : 7;  // 0x291(0x1)
	bool bForce : 1;  // 0x291(0x1)
	char pad_658_1 : 7;  // 0x292(0x1)
	bool bPrintPythonCommands : 1;  // 0x292(0x1)
	char pad_659[13];  // 0x293(0xD)

}; 
// Function ControlRig.RigHierarchy.SetControlShapeTransformByIndex
// Size: 0x80(Inherited: 0x0) 
struct FSetControlShapeTransformByIndex
{
	int32_t InElementIndex;  // 0x0(0x4)
	char pad_4[12];  // 0x4(0xC)
	struct FTransform InTransform;  // 0x10(0x60)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool bInitial : 1;  // 0x70(0x1)
	char pad_113_1 : 7;  // 0x71(0x1)
	bool bSetupUndo : 1;  // 0x71(0x1)
	char pad_114[14];  // 0x72(0xE)

}; 
// Function ControlRig.RigHierarchy.SetControlValue
// Size: 0x110(Inherited: 0x0) 
struct FSetControlValue
{
	struct FRigElementKey InKey;  // 0x0(0xC)
	char pad_12[4];  // 0xC(0x4)
	struct FRigControlValue InValue;  // 0x10(0xF0)
	uint8_t  InValueType;  // 0x100(0x1)
	char pad_257_1 : 7;  // 0x101(0x1)
	bool bSetupUndo : 1;  // 0x101(0x1)
	char pad_258_1 : 7;  // 0x102(0x1)
	bool bPrintPythonCommands : 1;  // 0x102(0x1)
	char pad_259[13];  // 0x103(0xD)

}; 
// Function ControlRig.RigHierarchy.SetControlVisibilityByIndex
// Size: 0x8(Inherited: 0x0) 
struct FSetControlVisibilityByIndex
{
	int32_t InElementIndex;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool bVisibility : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)

}; 
// Function ControlRig.RigHierarchy.SetFloatMetadata
// Size: 0x1C(Inherited: 0x0) 
struct FSetFloatMetadata
{
	struct FRigElementKey InItem;  // 0x0(0xC)
	struct FName InMetadataName;  // 0xC(0x8)
	float InValue;  // 0x14(0x4)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool ReturnValue : 1;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)

}; 
// Function ControlRig.RigHierarchy.SetInt32ArrayMetadata
// Size: 0x30(Inherited: 0x0) 
struct FSetInt32ArrayMetadata
{
	struct FRigElementKey InItem;  // 0x0(0xC)
	struct FName InMetadataName;  // 0xC(0x8)
	char pad_20[4];  // 0x14(0x4)
	struct TArray<int32_t> InValue;  // 0x18(0x10)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool ReturnValue : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)

}; 
// Function ControlRig.RigHierarchy.SetLocalTransform
// Size: 0x80(Inherited: 0x0) 
struct FSetLocalTransform
{
	struct FRigElementKey InKey;  // 0x0(0xC)
	char pad_12[4];  // 0xC(0x4)
	struct FTransform InTransform;  // 0x10(0x60)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool bInitial : 1;  // 0x70(0x1)
	char pad_113_1 : 7;  // 0x71(0x1)
	bool bAffectChildren : 1;  // 0x71(0x1)
	char pad_114_1 : 7;  // 0x72(0x1)
	bool bSetupUndo : 1;  // 0x72(0x1)
	char pad_115_1 : 7;  // 0x73(0x1)
	bool bPrintPythonCommands : 1;  // 0x73(0x1)
	char pad_116[12];  // 0x74(0xC)

}; 
// Function ControlRig.RigHierarchy.SetLocalTransformByIndex
// Size: 0x80(Inherited: 0x0) 
struct FSetLocalTransformByIndex
{
	int32_t InElementIndex;  // 0x0(0x4)
	char pad_4[12];  // 0x4(0xC)
	struct FTransform InTransform;  // 0x10(0x60)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool bInitial : 1;  // 0x70(0x1)
	char pad_113_1 : 7;  // 0x71(0x1)
	bool bAffectChildren : 1;  // 0x71(0x1)
	char pad_114_1 : 7;  // 0x72(0x1)
	bool bSetupUndo : 1;  // 0x72(0x1)
	char pad_115_1 : 7;  // 0x73(0x1)
	bool bPrintPythonCommands : 1;  // 0x73(0x1)
	char pad_116[12];  // 0x74(0xC)

}; 
// Function ControlRig.RigHierarchy.SetPose_ForBlueprint
// Size: 0x70(Inherited: 0x0) 
struct FSetPose_ForBlueprint
{
	struct FRigPose InPose;  // 0x0(0x70)

}; 
// Function ControlRig.RigHierarchy.SetQuatArrayMetadata
// Size: 0x30(Inherited: 0x0) 
struct FSetQuatArrayMetadata
{
	struct FRigElementKey InItem;  // 0x0(0xC)
	struct FName InMetadataName;  // 0xC(0x8)
	char pad_20[4];  // 0x14(0x4)
	struct TArray<struct FQuat> InValue;  // 0x18(0x10)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool ReturnValue : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)

}; 
// Function ControlRig.RigHierarchy.SetQuatMetadata
// Size: 0x50(Inherited: 0x0) 
struct FSetQuatMetadata
{
	struct FRigElementKey InItem;  // 0x0(0xC)
	struct FName InMetadataName;  // 0xC(0x8)
	char pad_20[12];  // 0x14(0xC)
	struct FQuat InValue;  // 0x20(0x20)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool ReturnValue : 1;  // 0x40(0x1)
	char pad_65[15];  // 0x41(0xF)

}; 
// Function ControlRig.RigHierarchy.SetRigElementKeyArrayMetadata
// Size: 0x30(Inherited: 0x0) 
struct FSetRigElementKeyArrayMetadata
{
	struct FRigElementKey InItem;  // 0x0(0xC)
	struct FName InMetadataName;  // 0xC(0x8)
	char pad_20[4];  // 0x14(0x4)
	struct TArray<struct FRigElementKey> InValue;  // 0x18(0x10)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool ReturnValue : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)

}; 
// Function ControlRig.RigHierarchy.SetRigElementKeyMetadata
// Size: 0x24(Inherited: 0x0) 
struct FSetRigElementKeyMetadata
{
	struct FRigElementKey InItem;  // 0x0(0xC)
	struct FName InMetadataName;  // 0xC(0x8)
	struct FRigElementKey InValue;  // 0x14(0xC)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool ReturnValue : 1;  // 0x20(0x1)
	char pad_33[3];  // 0x21(0x3)

}; 
// Function ControlRig.RigHierarchy.SetRotatorArrayMetadata
// Size: 0x30(Inherited: 0x0) 
struct FSetRotatorArrayMetadata
{
	struct FRigElementKey InItem;  // 0x0(0xC)
	struct FName InMetadataName;  // 0xC(0x8)
	char pad_20[4];  // 0x14(0x4)
	struct TArray<struct FRotator> InValue;  // 0x18(0x10)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool ReturnValue : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)

}; 
// Function ControlRig.RigHierarchy.SetRotatorMetadata
// Size: 0x38(Inherited: 0x0) 
struct FSetRotatorMetadata
{
	struct FRigElementKey InItem;  // 0x0(0xC)
	struct FName InMetadataName;  // 0xC(0x8)
	char pad_20[4];  // 0x14(0x4)
	struct FRotator InValue;  // 0x18(0x18)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool ReturnValue : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)

}; 
// Function ControlRig.RigHierarchy.UnsetCurveValueByIndex
// Size: 0x8(Inherited: 0x0) 
struct FUnsetCurveValueByIndex
{
	int32_t InElementIndex;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool bSetupUndo : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)

}; 
// Function ControlRig.RigHierarchy.SetTag
// Size: 0x18(Inherited: 0x0) 
struct FSetTag
{
	struct FRigElementKey InItem;  // 0x0(0xC)
	struct FName InTag;  // 0xC(0x8)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool ReturnValue : 1;  // 0x14(0x1)
	char pad_21[3];  // 0x15(0x3)

}; 
// Function ControlRig.RigHierarchy.SetTransformArrayMetadata
// Size: 0x30(Inherited: 0x0) 
struct FSetTransformArrayMetadata
{
	struct FRigElementKey InItem;  // 0x0(0xC)
	struct FName InMetadataName;  // 0xC(0x8)
	char pad_20[4];  // 0x14(0x4)
	struct TArray<struct FTransform> InValue;  // 0x18(0x10)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool ReturnValue : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)

}; 
// Function ControlRig.RigHierarchy.SwitchToParent
// Size: 0x1C(Inherited: 0x0) 
struct FSwitchToParent
{
	struct FRigElementKey InChild;  // 0x0(0xC)
	struct FRigElementKey InParent;  // 0xC(0xC)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool bInitial : 1;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool bAffectChildren : 1;  // 0x19(0x1)
	char pad_26_1 : 7;  // 0x1A(0x1)
	bool ReturnValue : 1;  // 0x1A(0x1)
	char pad_27[1];  // 0x1B(0x1)

}; 
// Function ControlRig.RigHierarchy.SwitchToWorldSpace
// Size: 0x10(Inherited: 0x0) 
struct FSwitchToWorldSpace
{
	struct FRigElementKey InChild;  // 0x0(0xC)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool bInitial : 1;  // 0xC(0x1)
	char pad_13_1 : 7;  // 0xD(0x1)
	bool bAffectChildren : 1;  // 0xD(0x1)
	char pad_14_1 : 7;  // 0xE(0x1)
	bool ReturnValue : 1;  // 0xE(0x1)
	char pad_15[1];  // 0xF(0x1)

}; 
// Function ControlRig.ControlRigComponent.AddMappedCompleteSkeletalMesh
// Size: 0x8(Inherited: 0x0) 
struct FAddMappedCompleteSkeletalMesh
{
	struct USkeletalMeshComponent* SkeletalMeshComponent;  // 0x0(0x8)

}; 
// Function ControlRig.RigHierarchy.UnsetCurveValue
// Size: 0x10(Inherited: 0x0) 
struct FUnsetCurveValue
{
	struct FRigElementKey InKey;  // 0x0(0xC)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool bSetupUndo : 1;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)

}; 
// Function ControlRig.ControlRigComponent.SetInitialBoneTransform
// Size: 0x80(Inherited: 0x0) 
struct FSetInitialBoneTransform
{
	struct FName BoneName;  // 0x0(0x8)
	char pad_8[8];  // 0x8(0x8)
	struct FTransform InitialTransform;  // 0x10(0x60)
	uint8_t  Space;  // 0x70(0x1)
	char pad_113_1 : 7;  // 0x71(0x1)
	bool bPropagateToChildren : 1;  // 0x71(0x1)
	char pad_114[14];  // 0x72(0xE)

}; 
// Function ControlRig.ControlRigComponent.AddMappedSkeletalMesh
// Size: 0x28(Inherited: 0x0) 
struct FAddMappedSkeletalMesh
{
	struct USkeletalMeshComponent* SkeletalMeshComponent;  // 0x0(0x8)
	struct TArray<struct FControlRigComponentMappedBone> Bones;  // 0x8(0x10)
	struct TArray<struct FControlRigComponentMappedCurve> Curves;  // 0x18(0x10)

}; 
// Function ControlRig.ControlRigComponent.DoesElementExist
// Size: 0xC(Inherited: 0x0) 
struct FDoesElementExist
{
	struct FName Name;  // 0x0(0x8)
	uint8_t  ElementType;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool ReturnValue : 1;  // 0x9(0x1)
	char pad_10[2];  // 0xA(0x2)

}; 
// Function ControlRig.ControlRigComponent.GetBoneTransform
// Size: 0x70(Inherited: 0x0) 
struct FGetBoneTransform
{
	struct FName BoneName;  // 0x0(0x8)
	uint8_t  Space;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct FTransform ReturnValue;  // 0x10(0x60)

}; 
// Function ControlRig.ControlRigComponent.GetControlBool
// Size: 0xC(Inherited: 0x0) 
struct FGetControlBool
{
	struct FName ControlName;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)

}; 
// Function ControlRig.ControlRigComponent.GetControlFloat
// Size: 0xC(Inherited: 0x0) 
struct FGetControlFloat
{
	struct FName ControlName;  // 0x0(0x8)
	float ReturnValue;  // 0x8(0x4)

}; 
// Function ControlRig.ControlRigComponent.GetControlRig
// Size: 0x8(Inherited: 0x0) 
struct FGetControlRig
{
	struct UControlRig* ReturnValue;  // 0x0(0x8)

}; 
// Function ControlRig.ControlRigComponent.GetControlRotator
// Size: 0x28(Inherited: 0x0) 
struct FGetControlRotator
{
	struct FName ControlName;  // 0x0(0x8)
	uint8_t  Space;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct FRotator ReturnValue;  // 0x10(0x18)

}; 
// Function ControlRig.ControlRigComponent.GetControlScale
// Size: 0x28(Inherited: 0x0) 
struct FGetControlScale
{
	struct FName ControlName;  // 0x0(0x8)
	uint8_t  Space;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct FVector ReturnValue;  // 0x10(0x18)

}; 
// Function ControlRig.ControlRigComponent.GetControlTransform
// Size: 0x70(Inherited: 0x0) 
struct FGetControlTransform
{
	struct FName ControlName;  // 0x0(0x8)
	uint8_t  Space;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct FTransform ReturnValue;  // 0x10(0x60)

}; 
// Function ControlRig.ControlRigComponent.GetControlVector2D
// Size: 0x18(Inherited: 0x0) 
struct FGetControlVector2D
{
	struct FName ControlName;  // 0x0(0x8)
	struct FVector2D ReturnValue;  // 0x8(0x10)

}; 
// Function ControlRig.ControlRigComponent.GetElementNames
// Size: 0x18(Inherited: 0x0) 
struct FGetElementNames
{
	uint8_t  ElementType;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct TArray<struct FName> ReturnValue;  // 0x8(0x10)

}; 
// Function ControlRig.ControlRigComponent.GetInitialBoneTransform
// Size: 0x70(Inherited: 0x0) 
struct FGetInitialBoneTransform
{
	struct FName BoneName;  // 0x0(0x8)
	uint8_t  Space;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct FTransform ReturnValue;  // 0x10(0x60)

}; 
// Function ControlRig.ControlRigComponent.GetInitialSpaceTransform
// Size: 0x70(Inherited: 0x0) 
struct FGetInitialSpaceTransform
{
	struct FName SpaceName;  // 0x0(0x8)
	uint8_t  Space;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct FTransform ReturnValue;  // 0x10(0x60)

}; 
// Function ControlRig.ControlRigComponent.GetSpaceTransform
// Size: 0x70(Inherited: 0x0) 
struct FGetSpaceTransform
{
	struct FName SpaceName;  // 0x0(0x8)
	uint8_t  Space;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct FTransform ReturnValue;  // 0x10(0x60)

}; 
// Function ControlRig.ControlRigComponent.OnPostConstruction
// Size: 0x8(Inherited: 0x0) 
struct FOnPostConstruction
{
	struct UControlRigComponent* Component;  // 0x0(0x8)

}; 
// Function ControlRig.ControlRigComponent.OnPostForwardsSolve
// Size: 0x8(Inherited: 0x0) 
struct FOnPostForwardsSolve
{
	struct UControlRigComponent* Component;  // 0x0(0x8)

}; 
// Function ControlRig.ControlRigComponent.OnPostInitialize
// Size: 0x8(Inherited: 0x0) 
struct FOnPostInitialize
{
	struct UControlRigComponent* Component;  // 0x0(0x8)

}; 
// Function ControlRig.ControlRigComponent.SetBoneInitialTransformsFromSkeletalMesh
// Size: 0x8(Inherited: 0x0) 
struct FSetBoneInitialTransformsFromSkeletalMesh
{
	struct USkeletalMesh* InSkeletalMesh;  // 0x0(0x8)

}; 
// Function ControlRig.ControlRigComponent.SetBoneTransform
// Size: 0x80(Inherited: 0x0) 
struct FSetBoneTransform
{
	struct FName BoneName;  // 0x0(0x8)
	char pad_8[8];  // 0x8(0x8)
	struct FTransform Transform;  // 0x10(0x60)
	uint8_t  Space;  // 0x70(0x1)
	char pad_113[3];  // 0x71(0x3)
	float Weight;  // 0x74(0x4)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool bPropagateToChildren : 1;  // 0x78(0x1)
	char pad_121[7];  // 0x79(0x7)

}; 
// Function ControlRig.ControlRigComponent.SetControlBool
// Size: 0xC(Inherited: 0x0) 
struct FSetControlBool
{
	struct FName ControlName;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Value : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)

}; 
// Function ControlRig.ControlRigComponent.SetControlInt
// Size: 0xC(Inherited: 0x0) 
struct FSetControlInt
{
	struct FName ControlName;  // 0x0(0x8)
	int32_t Value;  // 0x8(0x4)

}; 
// Function ControlRig.ControlRigComponent.SetControlOffset
// Size: 0x80(Inherited: 0x0) 
struct FSetControlOffset
{
	struct FName ControlName;  // 0x0(0x8)
	char pad_8[8];  // 0x8(0x8)
	struct FTransform OffsetTransform;  // 0x10(0x60)
	uint8_t  Space;  // 0x70(0x1)
	char pad_113[15];  // 0x71(0xF)

}; 
// Function ControlRig.ControlRigComponent.SetControlPosition
// Size: 0x28(Inherited: 0x0) 
struct FSetControlPosition
{
	struct FName ControlName;  // 0x0(0x8)
	struct FVector Value;  // 0x8(0x18)
	uint8_t  Space;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// Function ControlRig.ControlRigComponent.SetControlRigClass
// Size: 0x8(Inherited: 0x0) 
struct FSetControlRigClass
{
	UControlRig* InControlRigClass;  // 0x0(0x8)

}; 
// Function ControlRig.ControlRigComponent.SetControlTransform
// Size: 0x80(Inherited: 0x0) 
struct FSetControlTransform
{
	struct FName ControlName;  // 0x0(0x8)
	char pad_8[8];  // 0x8(0x8)
	struct FTransform Value;  // 0x10(0x60)
	uint8_t  Space;  // 0x70(0x1)
	char pad_113[15];  // 0x71(0xF)

}; 
// Function ControlRig.RigHierarchyController.DuplicateElements
// Size: 0x28(Inherited: 0x0) 
struct FDuplicateElements
{
	struct TArray<struct FRigElementKey> InKeys;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bSelectNewElements : 1;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool bSetupUndo : 1;  // 0x11(0x1)
	char pad_18_1 : 7;  // 0x12(0x1)
	bool bPrintPythonCommands : 1;  // 0x12(0x1)
	char pad_19[5];  // 0x13(0x5)
	struct TArray<struct FRigElementKey> ReturnValue;  // 0x18(0x10)

}; 
// Function ControlRig.ControlRigComponent.SetInitialSpaceTransform
// Size: 0x80(Inherited: 0x0) 
struct FSetInitialSpaceTransform
{
	struct FName SpaceName;  // 0x0(0x8)
	char pad_8[8];  // 0x8(0x8)
	struct FTransform InitialTransform;  // 0x10(0x60)
	uint8_t  Space;  // 0x70(0x1)
	char pad_113[15];  // 0x71(0xF)

}; 
// Function ControlRig.ControlRigComponent.SetMappedElements
// Size: 0x10(Inherited: 0x0) 
struct FSetMappedElements
{
	struct TArray<struct FControlRigComponentMappedElement> NewMappedElements;  // 0x0(0x10)

}; 
// Function ControlRig.ControlRigShapeActor.IsSelectedInEditor
// Size: 0x1(Inherited: 0x0) 
struct FIsSelectedInEditor
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function ControlRig.ControlRigShapeActor.OnEnabledChanged
// Size: 0x1(Inherited: 0x0) 
struct FOnEnabledChanged
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bIsEnabled : 1;  // 0x0(0x1)

}; 
// Function ControlRig.ControlRigShapeActor.OnHoveredChanged
// Size: 0x1(Inherited: 0x0) 
struct FOnHoveredChanged
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bIsSelected : 1;  // 0x0(0x1)

}; 
// Function ControlRig.ControlRigShapeActor.OnSelectionChanged
// Size: 0x1(Inherited: 0x0) 
struct FOnSelectionChanged
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bIsSelected : 1;  // 0x0(0x1)

}; 
// Function ControlRig.ControlRigShapeActor.SetEnabled
// Size: 0x1(Inherited: 0x0) 
struct FSetEnabled
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bInEnabled : 1;  // 0x0(0x1)

}; 
// Function ControlRig.ControlRigShapeActor.SetSelectable
// Size: 0x1(Inherited: 0x0) 
struct FSetSelectable
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bInSelectable : 1;  // 0x0(0x1)

}; 
// Function ControlRig.ControlRigShapeActor.SetSelected
// Size: 0x1(Inherited: 0x0) 
struct FSetSelected
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bInSelected : 1;  // 0x0(0x1)

}; 
// Function ControlRig.RigHierarchyController.AddAnimationChannel_ForBlueprint
// Size: 0x2B0(Inherited: 0x0) 
struct FAddAnimationChannel_ForBlueprint
{
	struct FName InName;  // 0x0(0x8)
	struct FRigElementKey InParentControl;  // 0x8(0xC)
	char pad_20[12];  // 0x14(0xC)
	struct FRigControlSettings InSettings;  // 0x20(0x280)
	char pad_672_1 : 7;  // 0x2A0(0x1)
	bool bSetupUndo : 1;  // 0x2A0(0x1)
	char pad_673_1 : 7;  // 0x2A1(0x1)
	bool bPrintPythonCommand : 1;  // 0x2A1(0x1)
	char pad_674[2];  // 0x2A2(0x2)
	struct FRigElementKey ReturnValue;  // 0x2A4(0xC)

}; 
// Function ControlRig.RigHierarchyController.AddControl_ForBlueprint
// Size: 0x3A0(Inherited: 0x0) 
struct FAddControl_ForBlueprint
{
	struct FName InName;  // 0x0(0x8)
	struct FRigElementKey InParent;  // 0x8(0xC)
	char pad_20[12];  // 0x14(0xC)
	struct FRigControlSettings InSettings;  // 0x20(0x280)
	struct FRigControlValue InValue;  // 0x2A0(0xF0)
	char pad_912_1 : 7;  // 0x390(0x1)
	bool bSetupUndo : 1;  // 0x390(0x1)
	char pad_913_1 : 7;  // 0x391(0x1)
	bool bPrintPythonCommand : 1;  // 0x391(0x1)
	char pad_914[2];  // 0x392(0x2)
	struct FRigElementKey ReturnValue;  // 0x394(0xC)

}; 
// Function ControlRig.RigHierarchyController.ClearSelection
// Size: 0x1(Inherited: 0x0) 
struct FClearSelection
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function ControlRig.RigHierarchyController.GetControlSettings
// Size: 0x290(Inherited: 0x0) 
struct FGetControlSettings
{
	struct FRigElementKey InKey;  // 0x0(0xC)
	char pad_12[4];  // 0xC(0x4)
	struct FRigControlSettings ReturnValue;  // 0x10(0x280)

}; 
// Function ControlRig.RigHierarchyController.ImportFromText
// Size: 0x28(Inherited: 0x0) 
struct FImportFromText
{
	struct FString InContent;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bReplaceExistingElements : 1;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool bSelectNewElements : 1;  // 0x11(0x1)
	char pad_18_1 : 7;  // 0x12(0x1)
	bool bSetupUndo : 1;  // 0x12(0x1)
	char pad_19_1 : 7;  // 0x13(0x1)
	bool bPrintPythonCommands : 1;  // 0x13(0x1)
	char pad_20[4];  // 0x14(0x4)
	struct TArray<struct FRigElementKey> ReturnValue;  // 0x18(0x10)

}; 
// Function ControlRig.RigHierarchyController.MirrorElements
// Size: 0x50(Inherited: 0x0) 
struct FMirrorElements
{
	struct TArray<struct FRigElementKey> InKeys;  // 0x0(0x10)
	struct FRigMirrorSettings InSettings;  // 0x10(0x28)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool bSelectNewElements : 1;  // 0x38(0x1)
	char pad_57_1 : 7;  // 0x39(0x1)
	bool bSetupUndo : 1;  // 0x39(0x1)
	char pad_58_1 : 7;  // 0x3A(0x1)
	bool bPrintPythonCommands : 1;  // 0x3A(0x1)
	char pad_59[5];  // 0x3B(0x5)
	struct TArray<struct FRigElementKey> ReturnValue;  // 0x40(0x10)

}; 
// Function ControlRig.RigHierarchyController.RemoveAllParents
// Size: 0x10(Inherited: 0x0) 
struct FRemoveAllParents
{
	struct FRigElementKey InChild;  // 0x0(0xC)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool bMaintainGlobalTransform : 1;  // 0xC(0x1)
	char pad_13_1 : 7;  // 0xD(0x1)
	bool bSetupUndo : 1;  // 0xD(0x1)
	char pad_14_1 : 7;  // 0xE(0x1)
	bool bPrintPythonCommand : 1;  // 0xE(0x1)
	char pad_15_1 : 7;  // 0xF(0x1)
	bool ReturnValue : 1;  // 0xF(0x1)

}; 
// Function ControlRig.RigHierarchyController.RemoveParent
// Size: 0x1C(Inherited: 0x0) 
struct FRemoveParent
{
	struct FRigElementKey InChild;  // 0x0(0xC)
	struct FRigElementKey InParent;  // 0xC(0xC)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool bMaintainGlobalTransform : 1;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool bSetupUndo : 1;  // 0x19(0x1)
	char pad_26_1 : 7;  // 0x1A(0x1)
	bool bPrintPythonCommand : 1;  // 0x1A(0x1)
	char pad_27_1 : 7;  // 0x1B(0x1)
	bool ReturnValue : 1;  // 0x1B(0x1)

}; 
// Function ControlRig.RigHierarchyController.RenameElement
// Size: 0x24(Inherited: 0x0) 
struct FRenameElement
{
	struct FRigElementKey InElement;  // 0x0(0xC)
	struct FName InName;  // 0xC(0x8)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool bSetupUndo : 1;  // 0x14(0x1)
	char pad_21_1 : 7;  // 0x15(0x1)
	bool bPrintPythonCommand : 1;  // 0x15(0x1)
	char pad_22_1 : 7;  // 0x16(0x1)
	bool bClearSelection : 1;  // 0x16(0x1)
	char pad_23[1];  // 0x17(0x1)
	struct FRigElementKey ReturnValue;  // 0x18(0xC)

}; 
// Function ControlRig.RigHierarchyController.SetDisplayName
// Size: 0x20(Inherited: 0x0) 
struct FSetDisplayName
{
	struct FRigElementKey InControl;  // 0x0(0xC)
	struct FName InDisplayName;  // 0xC(0x8)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool bRenameElement : 1;  // 0x14(0x1)
	char pad_21_1 : 7;  // 0x15(0x1)
	bool bSetupUndo : 1;  // 0x15(0x1)
	char pad_22_1 : 7;  // 0x16(0x1)
	bool bPrintPythonCommand : 1;  // 0x16(0x1)
	char pad_23[1];  // 0x17(0x1)
	struct FName ReturnValue;  // 0x18(0x8)

}; 
// Function ControlRig.RigHierarchyController.SetHierarchy
// Size: 0x8(Inherited: 0x0) 
struct FSetHierarchy
{
	struct URigHierarchy* InHierarchy;  // 0x0(0x8)

}; 
// Function ControlRig.ControlRigPoseAsset.DoesMirrorMatch
// Size: 0x18(Inherited: 0x0) 
struct FDoesMirrorMatch
{
	struct UControlRig* ControlRig;  // 0x0(0x8)
	struct FName ControlName;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function ControlRig.ControlRigPoseAsset.GetControlNames
// Size: 0x10(Inherited: 0x0) 
struct FGetControlNames
{
	struct TArray<struct FName> ReturnValue;  // 0x0(0x10)

}; 
// Function ControlRig.ControlRigPoseAsset.PastePose
// Size: 0x10(Inherited: 0x0) 
struct FPastePose
{
	struct UControlRig* InControlRig;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bDoKey : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool bDoMirror : 1;  // 0x9(0x1)
	char pad_10[6];  // 0xA(0x6)

}; 
// Function ControlRig.ControlRigPoseAsset.ReplaceControlName
// Size: 0x10(Inherited: 0x0) 
struct FReplaceControlName
{
	struct FName CurrentName;  // 0x0(0x8)
	struct FName NewName;  // 0x8(0x8)

}; 
// Function ControlRig.ControlRigPoseAsset.SelectControls
// Size: 0x10(Inherited: 0x0) 
struct FSelectControls
{
	struct UControlRig* InControlRig;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bDoMirror : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function ControlRig.ControlRigTransformWorkflowOptions.ProvideWorkflows
// Size: 0x18(Inherited: 0x0) 
struct FProvideWorkflows
{
	struct UObject* InSubject;  // 0x0(0x8)
	struct TArray<struct FRigVMUserWorkflow> ReturnValue;  // 0x8(0x10)

}; 
