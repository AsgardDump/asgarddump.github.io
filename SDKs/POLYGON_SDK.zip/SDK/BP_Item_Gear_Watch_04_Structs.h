#pragma once 
#include "SDK.h" 
 
 
// Function BP_Item_Gear_Watch_04.BP_Item_Gear_Watch_04_C.ReceiveTick
// Size: 0x4(Inherited: 0x4) 
struct FReceiveTick : public FReceiveTick
{
	float DeltaSeconds;  // 0x0(0x4)

}; 
// Function BP_Item_Gear_Watch_04.BP_Item_Gear_Watch_04_C.ExecuteUbergraph_BP_Item_Gear_Watch_04
// Size: 0x128(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Item_Gear_Watch_04
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0x8(0x8)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_NotEqual_ObjectObject_ReturnValue : 1;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)
	float K2Node_Event_DeltaSeconds;  // 0x1C(0x4)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_Event_useFovMaterial : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct FRotator CallFunc_ComposeRotators_ReturnValue;  // 0x28(0x18)
	struct FHitResult CallFunc_K2_SetRelativeRotation_SweepHitResult;  // 0x40(0xE8)

}; 
// Function BP_Item_Gear_Watch_04.BP_Item_Gear_Watch_04_C.SetCorrectiveFovMaterial
// Size: 0x1(Inherited: 0x1) 
struct FSetCorrectiveFovMaterial : public FSetCorrectiveFovMaterial
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool useFovMaterial : 1;  // 0x0(0x1)

}; 
