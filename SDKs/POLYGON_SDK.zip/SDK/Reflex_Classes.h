#pragma once 
#include <Reflex_Structs.h>
 
 
 
// Class Reflex.ReflexBlueprintLibrary
// Size: 0x28(Inherited: 0x28) 
struct UReflexBlueprintLibrary : public UBlueprintFunctionLibrary
{

	void SetReflexMode(uint8_t  Mode); // Function Reflex.ReflexBlueprintLibrary.SetReflexMode
	void SetFlashIndicatorEnabled(bool bEnabled); // Function Reflex.ReflexBlueprintLibrary.SetFlashIndicatorEnabled
	float GetRenderLatencyInMs(); // Function Reflex.ReflexBlueprintLibrary.GetRenderLatencyInMs
	uint8_t  GetReflexMode(); // Function Reflex.ReflexBlueprintLibrary.GetReflexMode
	bool GetReflexAvailable(); // Function Reflex.ReflexBlueprintLibrary.GetReflexAvailable
	float GetGameToRenderLatencyInMs(); // Function Reflex.ReflexBlueprintLibrary.GetGameToRenderLatencyInMs
	float GetGameLatencyInMs(); // Function Reflex.ReflexBlueprintLibrary.GetGameLatencyInMs
	bool GetFlashIndicatorEnabled(); // Function Reflex.ReflexBlueprintLibrary.GetFlashIndicatorEnabled
}; 



