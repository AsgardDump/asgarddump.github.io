#pragma once 
#include "SDK.h" 
 
 
// Function BP_FOVManagerComponent_Game.BP_FOVManagerComponent_Game_C.OnAiming_Event
// Size: 0x8(Inherited: 0x0) 
struct FOnAiming_Event
{
	struct AItem_Module_Optic* OpticItem;  // 0x0(0x8)

}; 
// Function BP_FOVManagerComponent_Game.BP_FOVManagerComponent_Game_C.ExecuteUbergraph_BP_FOVManagerComponent_Game
// Size: 0x70(Inherited: 0x0) 
struct FExecuteUbergraph_BP_FOVManagerComponent_Game
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AItem_Module_Optic* K2Node_CustomEvent_OpticItem;  // 0x8(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x10(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x20(0x10)
	struct UTask_FOVManagerComponent_AimingInterpolation_C* CallFunc_CreateAction_ReturnValue;  // 0x30(0x8)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue;  // 0x38(0x8)
	struct APawn* K2Node_CustomEvent_OldPawn;  // 0x40(0x8)
	struct APawn* K2Node_CustomEvent_NewPawn;  // 0x48(0x8)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool CallFunc_IsLocalPlayerController_ReturnValue : 1;  // 0x50(0x1)
	char pad_81[7];  // 0x51(0x7)
	struct APG_Game_Character* K2Node_DynamicCast_AsPG_Game_Character;  // 0x58(0x8)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x60(0x1)
	char pad_97[7];  // 0x61(0x7)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue_2;  // 0x68(0x8)

}; 
// Function BP_FOVManagerComponent_Game.BP_FOVManagerComponent_Game_C.OnPossessedPawnChanged_Event
// Size: 0x10(Inherited: 0x0) 
struct FOnPossessedPawnChanged_Event
{
	struct APawn* OldPawn;  // 0x0(0x8)
	struct APawn* NewPawn;  // 0x8(0x8)

}; 
