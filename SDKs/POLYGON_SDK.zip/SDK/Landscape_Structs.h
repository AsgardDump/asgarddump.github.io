#pragma once 
#include "SDK.h" 
 
 
// ScriptStruct Landscape.WeightmapData
// Size: 0x30(Inherited: 0x0) 
struct FWeightmapData
{
	struct TArray<struct UTexture2D*> Textures;  // 0x0(0x10)
	struct TArray<struct FWeightmapLayerAllocationInfo> LayerAllocations;  // 0x10(0x10)
	struct TArray<struct ULandscapeWeightmapUsage*> TextureUsages;  // 0x20(0x10)

}; 
// ScriptStruct Landscape.LandscapeSplineInterpPoint
// Size: 0xE0(Inherited: 0x0) 
struct FLandscapeSplineInterpPoint
{
	struct FVector Center;  // 0x0(0x18)
	struct FVector Left;  // 0x18(0x18)
	struct FVector Right;  // 0x30(0x18)
	struct FVector FalloffLeft;  // 0x48(0x18)
	struct FVector FalloffRight;  // 0x60(0x18)
	struct FVector LayerLeft;  // 0x78(0x18)
	struct FVector LayerRight;  // 0x90(0x18)
	struct FVector LayerFalloffLeft;  // 0xA8(0x18)
	struct FVector LayerFalloffRight;  // 0xC0(0x18)
	float StartEndFalloff;  // 0xD8(0x4)
	char pad_220[4];  // 0xDC(0x4)

}; 
// ScriptStruct Landscape.LandscapePerLODMaterialOverride
// Size: 0x10(Inherited: 0x0) 
struct FLandscapePerLODMaterialOverride
{
	int32_t LODIndex;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UMaterialInterface* Material;  // 0x8(0x8)

}; 
// Function Landscape.LandscapeProxy.SetLandscapeMaterialScalarParameterValue
// Size: 0xC(Inherited: 0x0) 
struct FSetLandscapeMaterialScalarParameterValue
{
	struct FName ParameterName;  // 0x0(0x8)
	float Value;  // 0x8(0x4)

}; 
// ScriptStruct Landscape.LandscapeLayerBrush
// Size: 0x1(Inherited: 0x0) 
struct FLandscapeLayerBrush
{
	char pad_0[1];  // 0x0(0x1)

}; 
// ScriptStruct Landscape.LandscapeLayer
// Size: 0x88(Inherited: 0x0) 
struct FLandscapeLayer
{
	struct FGuid Guid;  // 0x0(0x10)
	struct FName Name;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool bVisible : 1;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool Blocked : 1;  // 0x19(0x1)
	char pad_26[2];  // 0x1A(0x2)
	float HeightmapAlpha;  // 0x1C(0x4)
	float WeightmapAlpha;  // 0x20(0x4)
	char ELandscapeBlendMode BlendMode;  // 0x24(0x1)
	char pad_37[3];  // 0x25(0x3)
	struct TArray<struct FLandscapeLayerBrush> Brushes;  // 0x28(0x10)
	struct TMap<struct ULandscapeLayerInfoObject*, bool> WeightmapLayerAllocationBlend;  // 0x38(0x50)

}; 
// ScriptStruct Landscape.LandscapeEditToolRenderData
// Size: 0x38(Inherited: 0x0) 
struct FLandscapeEditToolRenderData
{
	struct UMaterialInterface* ToolMaterial;  // 0x0(0x8)
	struct UMaterialInterface* GizmoMaterial;  // 0x8(0x8)
	int32_t SelectedType;  // 0x10(0x4)
	int32_t DebugChannelR;  // 0x14(0x4)
	int32_t DebugChannelG;  // 0x18(0x4)
	int32_t DebugChannelB;  // 0x1C(0x4)
	struct UTexture2D* DataTexture;  // 0x20(0x8)
	struct UTexture2D* LayerContributionTexture;  // 0x28(0x8)
	struct UTexture2D* DirtyTexture;  // 0x30(0x8)

}; 
// ScriptStruct Landscape.WeightmapLayerAllocationInfo
// Size: 0x10(Inherited: 0x0) 
struct FWeightmapLayerAllocationInfo
{
	struct ULandscapeLayerInfoObject* LayerInfo;  // 0x0(0x8)
	char WeightmapTextureIndex;  // 0x8(0x1)
	char WeightmapTextureChannel;  // 0x9(0x1)
	char pad_10[6];  // 0xA(0x6)

}; 
// Function Landscape.LandscapeProxy.SetLandscapeMaterialTextureParameterValue
// Size: 0x10(Inherited: 0x0) 
struct FSetLandscapeMaterialTextureParameterValue
{
	struct FName ParameterName;  // 0x0(0x8)
	struct UTexture* Value;  // 0x8(0x8)

}; 
// ScriptStruct Landscape.HeightmapData
// Size: 0x8(Inherited: 0x0) 
struct FHeightmapData
{
	struct UTexture2D* Texture;  // 0x0(0x8)

}; 
// ScriptStruct Landscape.LandscapeComponentMaterialOverride
// Size: 0x10(Inherited: 0x0) 
struct FLandscapeComponentMaterialOverride
{
	struct FPerPlatformInt LODIndex;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UMaterialInterface* Material;  // 0x8(0x8)

}; 
// ScriptStruct Landscape.LandscapeLayerComponentData
// Size: 0x38(Inherited: 0x0) 
struct FLandscapeLayerComponentData
{
	struct FHeightmapData HeightmapData;  // 0x0(0x8)
	struct FWeightmapData WeightmapData;  // 0x8(0x30)

}; 
// Function Landscape.LandscapeProxy.EditorApplySpline
// Size: 0x38(Inherited: 0x0) 
struct FEditorApplySpline
{
	struct USplineComponent* InSplineComponent;  // 0x0(0x8)
	float StartWidth;  // 0x8(0x4)
	float EndWidth;  // 0xC(0x4)
	float StartSideFalloff;  // 0x10(0x4)
	float EndSideFalloff;  // 0x14(0x4)
	float StartRoll;  // 0x18(0x4)
	float EndRoll;  // 0x1C(0x4)
	int32_t NumSubdivisions;  // 0x20(0x4)
	char pad_36_1 : 7;  // 0x24(0x1)
	bool bRaiseHeights : 1;  // 0x24(0x1)
	char pad_37_1 : 7;  // 0x25(0x1)
	bool bLowerHeights : 1;  // 0x25(0x1)
	char pad_38[2];  // 0x26(0x2)
	struct ULandscapeLayerInfoObject* PaintLayer;  // 0x28(0x8)
	struct FName EditLayerName;  // 0x30(0x8)

}; 
// ScriptStruct Landscape.GizmoSelectData
// Size: 0x50(Inherited: 0x0) 
struct FGizmoSelectData
{
	char pad_0[80];  // 0x0(0x50)

}; 
// ScriptStruct Landscape.GrassVariety
// Size: 0x58(Inherited: 0x0) 
struct FGrassVariety
{
	struct UStaticMesh* GrassMesh;  // 0x0(0x8)
	struct TArray<struct UMaterialInterface*> OverrideMaterials;  // 0x8(0x10)
	struct FPerPlatformFloat GrassDensity;  // 0x18(0x4)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool bUseGrid : 1;  // 0x1C(0x1)
	char pad_29[3];  // 0x1D(0x3)
	float PlacementJitter;  // 0x20(0x4)
	struct FPerPlatformInt StartCullDistance;  // 0x24(0x4)
	struct FPerPlatformInt EndCullDistance;  // 0x28(0x4)
	int32_t MinLOD;  // 0x2C(0x4)
	uint8_t  Scaling;  // 0x30(0x1)
	char pad_49[3];  // 0x31(0x3)
	struct FFloatInterval ScaleX;  // 0x34(0x8)
	struct FFloatInterval ScaleY;  // 0x3C(0x8)
	struct FFloatInterval ScaleZ;  // 0x44(0x8)
	char pad_76_1 : 7;  // 0x4C(0x1)
	bool RandomRotation : 1;  // 0x4C(0x1)
	char pad_77_1 : 7;  // 0x4D(0x1)
	bool AlignToSurface : 1;  // 0x4D(0x1)
	char pad_78_1 : 7;  // 0x4E(0x1)
	bool bUseLandscapeLightmap : 1;  // 0x4E(0x1)
	struct FLightingChannels LightingChannels;  // 0x4F(0x1)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool bReceivesDecals : 1;  // 0x50(0x1)
	char pad_81_1 : 7;  // 0x51(0x1)
	bool bCastDynamicShadow : 1;  // 0x51(0x1)
	char pad_82_1 : 7;  // 0x52(0x1)
	bool bCastContactShadow : 1;  // 0x52(0x1)
	char pad_83_1 : 7;  // 0x53(0x1)
	bool bKeepInstanceBufferCPUCopy : 1;  // 0x53(0x1)
	uint32_t InstanceWorldPositionOffsetDisableDistance;  // 0x54(0x4)

}; 
// ScriptStruct Landscape.LandscapeMaterialTextureStreamingInfo
// Size: 0xC(Inherited: 0x0) 
struct FLandscapeMaterialTextureStreamingInfo
{
	struct FName TextureName;  // 0x0(0x8)
	float TexelFactor;  // 0x8(0x4)

}; 
// Function Landscape.LandscapeSplinesComponent.GetSplineMeshComponents
// Size: 0x10(Inherited: 0x0) 
struct FGetSplineMeshComponents
{
	struct TArray<struct USplineMeshComponent*> ReturnValue;  // 0x0(0x10)

}; 
// ScriptStruct Landscape.LandscapeSplineConnection
// Size: 0x10(Inherited: 0x0) 
struct FLandscapeSplineConnection
{
	struct ULandscapeSplineSegment* Segment;  // 0x0(0x8)
	char End : 1;  // 0x8(0x1)
	char pad_8_1 : 7;  // 0x8(0x1)
	char pad_9[8];  // 0x9(0x8)

}; 
// ScriptStruct Landscape.LandscapeInfoLayerSettings
// Size: 0x10(Inherited: 0x0) 
struct FLandscapeInfoLayerSettings
{
	struct ULandscapeLayerInfoObject* LayerInfoObj;  // 0x0(0x8)
	struct FName LayerName;  // 0x8(0x8)

}; 
// ScriptStruct Landscape.ForeignControlPointData
// Size: 0x1(Inherited: 0x0) 
struct FForeignControlPointData
{
	char pad_0[1];  // 0x0(0x1)

}; 
// ScriptStruct Landscape.ForeignSplineSegmentData
// Size: 0x1(Inherited: 0x0) 
struct FForeignSplineSegmentData
{
	char pad_0[1];  // 0x0(0x1)

}; 
// ScriptStruct Landscape.ForeignWorldSplineData
// Size: 0x1(Inherited: 0x0) 
struct FForeignWorldSplineData
{
	char pad_0[1];  // 0x0(0x1)

}; 
// Function Landscape.Landscape.RenderHeightmap
// Size: 0x90(Inherited: 0x0) 
struct FRenderHeightmap
{
	struct FTransform InWorldTransform;  // 0x0(0x60)
	struct FBox2D InExtents;  // 0x60(0x28)
	struct UTextureRenderTarget2D* OutRenderTarget;  // 0x88(0x8)

}; 
// ScriptStruct Landscape.LandscapeSplineSegmentConnection
// Size: 0x18(Inherited: 0x0) 
struct FLandscapeSplineSegmentConnection
{
	struct ULandscapeSplineControlPoint* ControlPoint;  // 0x0(0x8)
	float TangentLen;  // 0x8(0x4)
	struct FName SocketName;  // 0xC(0x8)
	char pad_20[4];  // 0x14(0x4)

}; 
// ScriptStruct Landscape.LandscapeSplineMeshEntry
// Size: 0x58(Inherited: 0x0) 
struct FLandscapeSplineMeshEntry
{
	struct UStaticMesh* Mesh;  // 0x0(0x8)
	struct TArray<struct UMaterialInterface*> MaterialOverrides;  // 0x8(0x10)
	char bCenterH : 1;  // 0x18(0x1)
	char pad_24_1 : 7;  // 0x18(0x1)
	char pad_25[8];  // 0x19(0x8)
	struct FVector2D CenterAdjust;  // 0x20(0x10)
	char bScaleToWidth : 1;  // 0x30(0x1)
	char pad_48_1 : 7;  // 0x30(0x1)
	char pad_49[8];  // 0x31(0x8)
	struct FVector Scale;  // 0x38(0x18)
	char LandscapeSplineMeshOrientation Orientation;  // 0x50(0x1)
	char ESplineMeshAxis ForwardAxis;  // 0x51(0x1)
	char ESplineMeshAxis UpAxis;  // 0x52(0x1)
	char pad_83[5];  // 0x53(0x5)

}; 
// Function Landscape.LandscapeBlueprintBrushBase.GetBlueprintRenderDependencies
// Size: 0x10(Inherited: 0x0) 
struct FGetBlueprintRenderDependencies
{
	struct TArray<struct UObject*> OutStreamableAssets;  // 0x0(0x10)

}; 
// Function Landscape.LandscapeComponent.SetLODBias
// Size: 0x4(Inherited: 0x0) 
struct FSetLODBias
{
	int32_t InLODBias;  // 0x0(0x4)

}; 
// Function Landscape.LandscapeProxy.LandscapeExportHeightmapToRenderTarget
// Size: 0x10(Inherited: 0x0) 
struct FLandscapeExportHeightmapToRenderTarget
{
	struct UTextureRenderTarget2D* InRenderTarget;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool InExportHeightIntoRGChannel : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool InExportLandscapeProxies : 1;  // 0x9(0x1)
	char pad_10_1 : 7;  // 0xA(0x1)
	bool ReturnValue : 1;  // 0xA(0x1)
	char pad_11[5];  // 0xB(0x5)

}; 
// ScriptStruct Landscape.GrassInput
// Size: 0x38(Inherited: 0x0) 
struct FGrassInput
{
	struct FName Name;  // 0x0(0x8)
	struct ULandscapeGrassType* GrassType;  // 0x8(0x8)
	struct FExpressionInput Input;  // 0x10(0x28)

}; 
// ScriptStruct Landscape.LandscapeProxyMaterialOverride
// Size: 0x10(Inherited: 0x0) 
struct FLandscapeProxyMaterialOverride
{
	struct FPerPlatformInt LODIndex;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UMaterialInterface* Material;  // 0x8(0x8)

}; 
// ScriptStruct Landscape.LayerBlendInput
// Size: 0x88(Inherited: 0x0) 
struct FLayerBlendInput
{
	struct FName LayerName;  // 0x0(0x8)
	char ELandscapeLayerBlendType BlendType;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct FExpressionInput LayerInput;  // 0x10(0x28)
	struct FExpressionInput HeightInput;  // 0x38(0x28)
	float PreviewWeight;  // 0x60(0x4)
	char pad_100[4];  // 0x64(0x4)
	struct FVector ConstLayerInput;  // 0x68(0x18)
	float ConstHeightInput;  // 0x80(0x4)
	char pad_132[4];  // 0x84(0x4)

}; 
// ScriptStruct Landscape.LandscapeEditorLayerSettings
// Size: 0x1(Inherited: 0x0) 
struct FLandscapeEditorLayerSettings
{
	char pad_0[1];  // 0x0(0x1)

}; 
// Function Landscape.LandscapeHeightfieldCollisionComponent.GetRenderComponent
// Size: 0x8(Inherited: 0x0) 
struct FGetRenderComponent
{
	struct ULandscapeComponent* ReturnValue;  // 0x0(0x8)

}; 
// ScriptStruct Landscape.LandscapeLayerStruct
// Size: 0x8(Inherited: 0x0) 
struct FLandscapeLayerStruct
{
	struct ULandscapeLayerInfoObject* LayerInfoObj;  // 0x0(0x8)

}; 
// Function Landscape.LandscapeProxy.SetVirtualTextureRenderPassType
// Size: 0x1(Inherited: 0x0) 
struct FSetVirtualTextureRenderPassType
{
	uint8_t  InType;  // 0x0(0x1)

}; 
// ScriptStruct Landscape.LandscapeImportLayerInfo
// Size: 0x1(Inherited: 0x0) 
struct FLandscapeImportLayerInfo
{
	char pad_0[1];  // 0x0(0x1)

}; 
// ScriptStruct Landscape.PhysicalMaterialInput
// Size: 0x30(Inherited: 0x0) 
struct FPhysicalMaterialInput
{
	struct UPhysicalMaterial* PhysicalMaterial;  // 0x0(0x8)
	struct FExpressionInput Input;  // 0x8(0x28)

}; 
// Function Landscape.LandscapeProxy.ChangeComponentScreenSizeToUseSubSections
// Size: 0x4(Inherited: 0x0) 
struct FChangeComponentScreenSizeToUseSubSections
{
	float InComponentScreenSizeToUseSubSections;  // 0x0(0x4)

}; 
// Function Landscape.LandscapeProxy.ChangeLODDistanceFactor
// Size: 0x4(Inherited: 0x0) 
struct FChangeLODDistanceFactor
{
	float InLODDistanceFactor;  // 0x0(0x4)

}; 
// Function Landscape.LandscapeProxy.EditorSetLandscapeMaterial
// Size: 0x8(Inherited: 0x0) 
struct FEditorSetLandscapeMaterial
{
	struct UMaterialInterface* NewLandscapeMaterial;  // 0x0(0x8)

}; 
// Function Landscape.LandscapeComponent.SetForcedLOD
// Size: 0x4(Inherited: 0x0) 
struct FSetForcedLOD
{
	int32_t InForcedLOD;  // 0x0(0x4)

}; 
// Function Landscape.LandscapeProxy.GetLandscapeActor
// Size: 0x8(Inherited: 0x0) 
struct FGetLandscapeActor
{
	struct ALandscape* ReturnValue;  // 0x0(0x8)

}; 
// Function Landscape.LandscapeProxy.SetLandscapeMaterialVectorParameterValue
// Size: 0x18(Inherited: 0x0) 
struct FSetLandscapeMaterialVectorParameterValue
{
	struct FName ParameterName;  // 0x0(0x8)
	struct FLinearColor Value;  // 0x8(0x10)

}; 
// Function Landscape.LandscapeBlueprintBrushBase.Initialize
// Size: 0x70(Inherited: 0x0) 
struct FInitialize
{
	struct FTransform InLandscapeTransform;  // 0x0(0x60)
	struct FIntPoint InLandscapeSize;  // 0x60(0x8)
	struct FIntPoint InLandscapeRenderTargetSize;  // 0x68(0x8)

}; 
// Function Landscape.LandscapeComponent.EditorGetPaintLayerWeightAtLocation
// Size: 0x28(Inherited: 0x0) 
struct FEditorGetPaintLayerWeightAtLocation
{
	struct FVector InLocation;  // 0x0(0x18)
	struct ULandscapeLayerInfoObject* PaintLayer;  // 0x18(0x8)
	float ReturnValue;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)

}; 
// Function Landscape.LandscapeComponent.EditorGetPaintLayerWeightByNameAtLocation
// Size: 0x28(Inherited: 0x0) 
struct FEditorGetPaintLayerWeightByNameAtLocation
{
	struct FVector InLocation;  // 0x0(0x18)
	struct FName InPaintLayerName;  // 0x18(0x8)
	float ReturnValue;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)

}; 
// Function Landscape.LandscapeComponent.GetMaterialInstanceDynamic
// Size: 0x10(Inherited: 0x0) 
struct FGetMaterialInstanceDynamic
{
	int32_t InIndex;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UMaterialInstanceDynamic* ReturnValue;  // 0x8(0x8)

}; 
// Function Landscape.LandscapeBlueprintBrushBase.Render
// Size: 0x20(Inherited: 0x0) 
struct FRender
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool InIsHeightmap : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct UTextureRenderTarget2D* InCombinedResult;  // 0x8(0x8)
	struct FName InWeightmapLayerName;  // 0x10(0x8)
	struct UTextureRenderTarget2D* ReturnValue;  // 0x18(0x8)

}; 
