#pragma once 
#include <BP_Item_Gear_Watch_04_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Item_Gear_Watch_04.BP_Item_Gear_Watch_04_C
// Size: 0x320(Inherited: 0x310) 
struct ABP_Item_Gear_Watch_04_C : public AItem_Watch_General
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x310(0x8)
	struct UStaticMeshComponent* Bezel;  // 0x318(0x8)

	void ReceiveBeginPlay(); // Function BP_Item_Gear_Watch_04.BP_Item_Gear_Watch_04_C.ReceiveBeginPlay
	void ReceiveTick(float DeltaSeconds); // Function BP_Item_Gear_Watch_04.BP_Item_Gear_Watch_04_C.ReceiveTick
	void SetCorrectiveFovMaterial(bool useFovMaterial); // Function BP_Item_Gear_Watch_04.BP_Item_Gear_Watch_04_C.SetCorrectiveFovMaterial
	void ExecuteUbergraph_BP_Item_Gear_Watch_04(int32_t EntryPoint); // Function BP_Item_Gear_Watch_04.BP_Item_Gear_Watch_04_C.ExecuteUbergraph_BP_Item_Gear_Watch_04
}; 



