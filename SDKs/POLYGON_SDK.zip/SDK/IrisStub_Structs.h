#pragma once 
#include "SDK.h" 
 
 
// ScriptStruct IrisStub.NetSerializerConfig
// Size: 0x1(Inherited: 0x0) 
struct FNetSerializerConfig
{
	char pad_0[1];  // 0x0(0x1)

}; 
// ScriptStruct IrisStub.PolymorphicStructNetSerializerConfig
// Size: 0x1(Inherited: 0x1) 
struct FPolymorphicStructNetSerializerConfig : public FNetSerializerConfig
{

}; 
// ScriptStruct IrisStub.PolymorphicArrayStructNetSerializerConfig
// Size: 0x1(Inherited: 0x1) 
struct FPolymorphicArrayStructNetSerializerConfig : public FNetSerializerConfig
{

}; 
