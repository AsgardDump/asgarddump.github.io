#pragma once 
#include "SDK.h" 
 
 
// ScriptStruct NiagaraCore.NiagaraCompileHash
// Size: 0x10(Inherited: 0x0) 
struct FNiagaraCompileHash
{
	struct TArray<char> DataHash;  // 0x0(0x10)

}; 
