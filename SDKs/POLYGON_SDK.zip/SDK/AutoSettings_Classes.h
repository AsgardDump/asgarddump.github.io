#pragma once 
#include <AutoSettings_Structs.h>
 
 
 
// Class AutoSettings.AutoSettingsConfig
// Size: 0x58(Inherited: 0x38) 
struct UAutoSettingsConfig : public UDeveloperSettings
{
	struct FString SettingsIniName;  // 0x38(0x10)
	struct FString SettingsSectionName;  // 0x48(0x10)

}; 



// Class AutoSettings.CheckBoxSetting
// Size: 0x2D0(Inherited: 0x2C8) 
struct UCheckBoxSetting : public UToggleSetting
{
	struct UCheckBox* CheckBox;  // 0x2C8(0x8)

	void CheckBoxStateChanged(bool IsChecked); // Function AutoSettings.CheckBoxSetting.CheckBoxStateChanged
}; 



// Class AutoSettings.Spinner
// Size: 0x2A8(Inherited: 0x278) 
struct USpinner : public UUserWidget
{
	struct TArray<struct FSettingOption> Options;  // 0x278(0x10)
	char pad_648_1 : 7;  // 0x288(0x1)
	bool bAllowWrapping : 1;  // 0x288(0x1)
	char pad_649[7];  // 0x289(0x7)
	struct FMulticastInlineDelegate SelectionChangedEvent;  // 0x290(0x10)
	char pad_672[8];  // 0x2A0(0x8)

	void SelectValue(struct FString Value); // Function AutoSettings.Spinner.SelectValue
	void SelectIndex(int32_t Index); // Function AutoSettings.Spinner.SelectIndex
	void Previous(); // Function AutoSettings.Spinner.Previous
	void OnSelectionChanged(struct FSettingOption SelectedOption); // Function AutoSettings.Spinner.OnSelectionChanged
	void Next(); // Function AutoSettings.Spinner.Next
	bool HasValidPrevious(); // Function AutoSettings.Spinner.HasValidPrevious
	bool HasValidNext(); // Function AutoSettings.Spinner.HasValidNext
	struct FSettingOption GetCurrentOption(); // Function AutoSettings.Spinner.GetCurrentOption
	int32_t GetCurrentIndex(); // Function AutoSettings.Spinner.GetCurrentIndex
}; 



// Class AutoSettings.ConsoleUtils
// Size: 0x28(Inherited: 0x28) 
struct UConsoleUtils : public UBlueprintFunctionLibrary
{

	void SetStringCVar(struct FName Name, struct FString Value); // Function AutoSettings.ConsoleUtils.SetStringCVar
	void SetIntCVar(struct FName Name, int32_t Value); // Function AutoSettings.ConsoleUtils.SetIntCVar
	void SetFloatCVar(struct FName Name, float Value); // Function AutoSettings.ConsoleUtils.SetFloatCVar
	void SetBoolCVar(struct FName Name, bool Value); // Function AutoSettings.ConsoleUtils.SetBoolCVar
	bool IsCVarRegistered(struct FName Name); // Function AutoSettings.ConsoleUtils.IsCVarRegistered
	struct FString GetStringCVar(struct FName Name); // Function AutoSettings.ConsoleUtils.GetStringCVar
	int32_t GetIntCVar(struct FName Name); // Function AutoSettings.ConsoleUtils.GetIntCVar
	float GetFloatCVar(struct FName Name); // Function AutoSettings.ConsoleUtils.GetFloatCVar
	bool GetBoolCVar(struct FName Name); // Function AutoSettings.ConsoleUtils.GetBoolCVar
}; 



// Class AutoSettings.SettingValueMask
// Size: 0x28(Inherited: 0x28) 
struct USettingValueMask : public UObject
{

	struct FString RecombineValues(struct FString SettingValue, struct FString ConsoleValue); // Function AutoSettings.SettingValueMask.RecombineValues
	struct FString MaskValue(struct FString ConsoleValue); // Function AutoSettings.SettingValueMask.MaskValue
}; 



// Class AutoSettings.AutoSettingWidget
// Size: 0x2C8(Inherited: 0x278) 
struct UAutoSettingWidget : public UUserWidget
{
	struct FName CVarName;  // 0x278(0x8)
	USettingValueMask* ValueMask;  // 0x280(0x8)
	char pad_648_1 : 7;  // 0x288(0x1)
	bool bAutoSave : 1;  // 0x288(0x1)
	char pad_649_1 : 7;  // 0x289(0x1)
	bool bAutoApply : 1;  // 0x289(0x1)
	char pad_650[6];  // 0x28A(0x6)
	struct FGameplayTagContainer SettingTags;  // 0x290(0x20)
	struct FString CurrentValue;  // 0x2B0(0x10)
	char pad_704_1 : 7;  // 0x2C0(0x1)
	bool bHasUnappliedChange : 1;  // 0x2C0(0x1)
	char pad_705_1 : 7;  // 0x2C1(0x1)
	bool bHasUnsavedChange : 1;  // 0x2C1(0x1)
	char pad_706_1 : 7;  // 0x2C2(0x1)
	bool bUpdatingSettingSelection : 1;  // 0x2C2(0x1)
	char pad_707[5];  // 0x2C3(0x5)

	void UpdateSelection(struct FString Value); // Function AutoSettings.AutoSettingWidget.UpdateSelection
	void Save(); // Function AutoSettings.AutoSettingWidget.Save
	bool HasUnsavedChange(); // Function AutoSettings.AutoSettingWidget.HasUnsavedChange
	bool HasUnappliedChange(); // Function AutoSettings.AutoSettingWidget.HasUnappliedChange
	void Cancel(); // Function AutoSettings.AutoSettingWidget.Cancel
	void ApplySettingValue(struct FString Value, bool bSaveIfPossible); // Function AutoSettings.AutoSettingWidget.ApplySettingValue
	void Apply(); // Function AutoSettings.AutoSettingWidget.Apply
}; 



// Class AutoSettings.ComboBoxSetting
// Size: 0x2F0(Inherited: 0x2E8) 
struct UComboBoxSetting : public USelectSetting
{
	struct UComboBoxString* ComboBox;  // 0x2E8(0x8)

	void ComboBoxSelectionChanged(struct FString SelectedItem, char ESelectInfo SelectionType); // Function AutoSettings.ComboBoxSetting.ComboBoxSelectionChanged
}; 



// Class AutoSettings.ToggleSetting
// Size: 0x2C8(Inherited: 0x2C8) 
struct UToggleSetting : public UAutoSettingWidget
{

	void UpdateToggleState(bool State); // Function AutoSettings.ToggleSetting.UpdateToggleState
	void ToggleStateUpdated(bool State); // Function AutoSettings.ToggleSetting.ToggleStateUpdated
}; 



// Class AutoSettings.NativeSliderSetting
// Size: 0x2E0(Inherited: 0x2D0) 
struct UNativeSliderSetting : public USliderSetting
{
	struct USlider* Slider;  // 0x2D0(0x8)
	char pad_728_1 : 7;  // 0x2D8(0x1)
	bool bMouseCaptureInProgress : 1;  // 0x2D8(0x1)
	char pad_729[7];  // 0x2D9(0x7)

	void SliderValueChanged(float NewValue); // Function AutoSettings.NativeSliderSetting.SliderValueChanged
	void SliderMouseCaptureEnd(); // Function AutoSettings.NativeSliderSetting.SliderMouseCaptureEnd
	void SliderMouseCaptureBegin(); // Function AutoSettings.NativeSliderSetting.SliderMouseCaptureBegin
}; 



// Class AutoSettings.CVarChangeListener
// Size: 0x80(Inherited: 0x28) 
struct UCVarChangeListener : public UObject
{
	char pad_40[88];  // 0x28(0x58)

}; 



// Class AutoSettings.SelectSetting
// Size: 0x2E8(Inherited: 0x2C8) 
struct USelectSetting : public UAutoSettingWidget
{
	struct TArray<struct FSettingOption> Options;  // 0x2C8(0x10)
	USettingOptionFactory* OptionFactory;  // 0x2D8(0x8)
	char pad_736_1 : 7;  // 0x2E0(0x1)
	bool bUpdatingSettingOptions : 1;  // 0x2E0(0x1)
	char pad_737[7];  // 0x2E1(0x7)

	void UpdateOptions(struct TArray<struct FSettingOption>& InOptions); // Function AutoSettings.SelectSetting.UpdateOptions
	void RegenerateOptions(); // Function AutoSettings.SelectSetting.RegenerateOptions
}; 



// Class AutoSettings.CVarChangeListenerManager
// Size: 0x78(Inherited: 0x28) 
struct UCVarChangeListenerManager : public UObject
{
	struct TMap<struct FName, struct UCVarChangeListener*> Listeners;  // 0x28(0x50)

	void AddStringCVarCallbackStatic(struct FName Name, struct FDelegate ChangedCallback, bool CallbackImmediately); // Function AutoSettings.CVarChangeListenerManager.AddStringCVarCallbackStatic
	void AddIntCVarCallbackStatic(struct FName Name, struct FDelegate ChangedCallback, bool CallbackImmediately); // Function AutoSettings.CVarChangeListenerManager.AddIntCVarCallbackStatic
	void AddFloatCVarCallbackStatic(struct FName Name, struct FDelegate ChangedCallback, bool CallbackImmediately); // Function AutoSettings.CVarChangeListenerManager.AddFloatCVarCallbackStatic
	void AddBoolCVarCallbackStatic(struct FName Name, struct FDelegate ChangedCallback, bool CallbackImmediately); // Function AutoSettings.CVarChangeListenerManager.AddBoolCVarCallbackStatic
}; 



// Class AutoSettings.ResolutionStringUtils
// Size: 0x28(Inherited: 0x28) 
struct UResolutionStringUtils : public UBlueprintFunctionLibrary
{

}; 



// Class AutoSettings.SliderSetting
// Size: 0x2D0(Inherited: 0x2C8) 
struct USliderSetting : public UAutoSettingWidget
{
	float LeftValue;  // 0x2C8(0x4)
	float RightValue;  // 0x2CC(0x4)

	void UpdateSliderValue(float NormalizedValue, float RawValue); // Function AutoSettings.SliderSetting.UpdateSliderValue
	void SliderValueUpdated(float NormalizedValue); // Function AutoSettings.SliderSetting.SliderValueUpdated
	bool ShouldSaveCurrentValue(); // Function AutoSettings.SliderSetting.ShouldSaveCurrentValue
	float RawValueToNormalized(float RawValue); // Function AutoSettings.SliderSetting.RawValueToNormalized
	void OnSliderValueUpdated(float NormalizedValue, float RawValue); // Function AutoSettings.SliderSetting.OnSliderValueUpdated
	float NormalizedValueToRaw(float NormalizedValue); // Function AutoSettings.SliderSetting.NormalizedValueToRaw
	float ClampRawValue(float RawValue); // Function AutoSettings.SliderSetting.ClampRawValue
}; 



// Class AutoSettings.RadioButton
// Size: 0x2B8(Inherited: 0x278) 
struct URadioButton : public UUserWidget
{
	struct FMulticastInlineDelegate OnSelected;  // 0x278(0x10)
	struct FText Label;  // 0x288(0x18)
	struct FString Value;  // 0x2A0(0x10)
	char pad_688_1 : 7;  // 0x2B0(0x1)
	bool Selected : 1;  // 0x2B0(0x1)
	char pad_689[7];  // 0x2B1(0x7)

	void UpdateSelected(bool InSelected); // Function AutoSettings.RadioButton.UpdateSelected
	void UpdateLabel(struct FText& InLabel); // Function AutoSettings.RadioButton.UpdateLabel
	void TriggerSelection(); // Function AutoSettings.RadioButton.TriggerSelection
	void SetValue(struct FString InValue); // Function AutoSettings.RadioButton.SetValue
	void SetSelected(bool InSelected); // Function AutoSettings.RadioButton.SetSelected
	void SetLabel(struct FText InLabel); // Function AutoSettings.RadioButton.SetLabel
	struct FString GetValue(); // Function AutoSettings.RadioButton.GetValue
	bool GetSelected(); // Function AutoSettings.RadioButton.GetSelected
	struct FText GetLabel(); // Function AutoSettings.RadioButton.GetLabel
}; 



// Class AutoSettings.RadioSelect
// Size: 0x2B8(Inherited: 0x278) 
struct URadioSelect : public UUserWidget
{
	struct TArray<struct FSettingOption> Options;  // 0x278(0x10)
	URadioButton* RadioButtonClass;  // 0x288(0x8)
	struct FMulticastInlineDelegate SelectionChangedEvent;  // 0x290(0x10)
	struct UPanelWidget* ButtonContainer;  // 0x2A0(0x8)
	struct TArray<struct URadioButton*> RadioButtons;  // 0x2A8(0x10)

	void SetOptions(struct TArray<struct FSettingOption> InOptions); // Function AutoSettings.RadioSelect.SetOptions
	void Select(struct FString Value); // Function AutoSettings.RadioSelect.Select
	void OnButtonCreated(struct URadioButton* Button, struct UPanelSlot* NewSlot); // Function AutoSettings.RadioSelect.OnButtonCreated
	struct TArray<struct URadioButton*> GetRadioButtonWidgets(); // Function AutoSettings.RadioSelect.GetRadioButtonWidgets
	struct TArray<struct FSettingOption> GetOptions(); // Function AutoSettings.RadioSelect.GetOptions
	void ButtonSelected(struct FString Value); // Function AutoSettings.RadioSelect.ButtonSelected
}; 



// Class AutoSettings.WindowModeValueMask
// Size: 0x28(Inherited: 0x28) 
struct UWindowModeValueMask : public USettingValueMask
{

}; 



// Class AutoSettings.RadioSelectSetting
// Size: 0x2F8(Inherited: 0x2E8) 
struct URadioSelectSetting : public USelectSetting
{
	URadioButton* RadioButtonClass;  // 0x2E8(0x8)
	struct URadioSelect* RadioSelect;  // 0x2F0(0x8)

	void RadioSelectionChanged(struct FString Value); // Function AutoSettings.RadioSelectSetting.RadioSelectionChanged
}; 



// Class AutoSettings.SettingOptionFactory
// Size: 0x28(Inherited: 0x28) 
struct USettingOptionFactory : public UObject
{

	struct TArray<struct FSettingOption> ConstructOptions(); // Function AutoSettings.SettingOptionFactory.ConstructOptions
}; 



// Class AutoSettings.ResolutionOptionFactory
// Size: 0x28(Inherited: 0x28) 
struct UResolutionOptionFactory : public USettingOptionFactory
{

}; 



// Class AutoSettings.ResolutionValueMask
// Size: 0x28(Inherited: 0x28) 
struct UResolutionValueMask : public USettingValueMask
{

}; 



// Class AutoSettings.SettingContainerUtils
// Size: 0x28(Inherited: 0x28) 
struct USettingContainerUtils : public UBlueprintFunctionLibrary
{

	void SaveChildSettings(struct UUserWidget* UserWidget, struct UWidget* Parent); // Function AutoSettings.SettingContainerUtils.SaveChildSettings
	struct TArray<struct UAutoSettingWidget*> GetChildSettings(struct UUserWidget* UserWidget, struct UWidget* Parent); // Function AutoSettings.SettingContainerUtils.GetChildSettings
	bool DoesAnyChildSettingHaveUnsavedChange(struct UUserWidget* UserWidget, struct UWidget* Parent); // Function AutoSettings.SettingContainerUtils.DoesAnyChildSettingHaveUnsavedChange
	bool DoesAnyChildSettingHaveUnappliedChange(struct UUserWidget* UserWidget, struct UWidget* Parent); // Function AutoSettings.SettingContainerUtils.DoesAnyChildSettingHaveUnappliedChange
	void CancelChildSettings(struct UUserWidget* UserWidget, struct UWidget* Parent); // Function AutoSettings.SettingContainerUtils.CancelChildSettings
	void ApplyChildSettings(struct UUserWidget* UserWidget, struct UWidget* Parent); // Function AutoSettings.SettingContainerUtils.ApplyChildSettings
}; 



// Class AutoSettings.SettingsManager
// Size: 0x50(Inherited: 0x30) 
struct USettingsManager : public UEngineSubsystem
{
	struct FMulticastInlineDelegate OnSettingSaved;  // 0x30(0x10)
	struct FString IniFilename;  // 0x40(0x10)

	void SaveSettingStatic(struct FAutoSettingData SettingData); // Function AutoSettings.SettingsManager.SaveSettingStatic
	void RegisterStringCVarSettingWithCallback(struct FName Name, struct FString DefaultValue, struct FString Help, struct FDelegate ChangedCallback, bool CallbackImmediately); // Function AutoSettings.SettingsManager.RegisterStringCVarSettingWithCallback
	void RegisterStringCVarSetting(struct FName Name, struct FString DefaultValue, struct FString Help); // Function AutoSettings.SettingsManager.RegisterStringCVarSetting
	void RegisterIntCVarSettingWithCallback(struct FName Name, int32_t DefaultValue, struct FString Help, struct FDelegate ChangedCallback, bool CallbackImmediately); // Function AutoSettings.SettingsManager.RegisterIntCVarSettingWithCallback
	void RegisterIntCVarSetting(struct FName Name, int32_t DefaultValue, struct FString Help); // Function AutoSettings.SettingsManager.RegisterIntCVarSetting
	void RegisterFloatCVarSettingWithCallback(struct FName Name, float DefaultValue, struct FString Help, struct FDelegate ChangedCallback, bool CallbackImmediately); // Function AutoSettings.SettingsManager.RegisterFloatCVarSettingWithCallback
	void RegisterFloatCVarSetting(struct FName Name, float DefaultValue, struct FString Help); // Function AutoSettings.SettingsManager.RegisterFloatCVarSetting
	void RegisterBoolCVarSettingWithCallback(struct FName Name, bool DefaultValue, struct FString Help, struct FDelegate ChangedCallback, bool CallbackImmediately); // Function AutoSettings.SettingsManager.RegisterBoolCVarSettingWithCallback
	void RegisterBoolCVarSetting(struct FName Name, bool DefaultValue, struct FString Help); // Function AutoSettings.SettingsManager.RegisterBoolCVarSetting
	struct FString GetValue(struct FName Key, bool bPreferConfigValue); // Function AutoSettings.SettingsManager.GetValue
	void AutoDetectSettingsStatic(int32_t WorkScale, float CPUMultiplier, float GPUMultiplier); // Function AutoSettings.SettingsManager.AutoDetectSettingsStatic
	void ApplySettingStatic(struct FAutoSettingData SettingData); // Function AutoSettings.SettingsManager.ApplySettingStatic
}; 



// Class AutoSettings.SpinnerSetting
// Size: 0x2F0(Inherited: 0x2E8) 
struct USpinnerSetting : public USelectSetting
{
	struct USpinner* Spinner;  // 0x2E8(0x8)

	void SpinnerSelectionChanged(struct FString Value); // Function AutoSettings.SpinnerSetting.SpinnerSelectionChanged
}; 



