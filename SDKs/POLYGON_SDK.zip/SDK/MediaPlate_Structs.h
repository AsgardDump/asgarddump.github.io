#pragma once 
#include "SDK.h" 
 
 
// Function MediaPlate.MediaPlateComponent.GetMeshRange
// Size: 0x10(Inherited: 0x0) 
struct FGetMeshRange
{
	struct FVector2D ReturnValue;  // 0x0(0x10)

}; 
// Function MediaPlate.MediaPlateComponent.GetLetterboxAspectRatio
// Size: 0x4(Inherited: 0x0) 
struct FGetLetterboxAspectRatio
{
	float ReturnValue;  // 0x0(0x4)

}; 
// Function MediaPlate.MediaPlateComponent.OnMediaOpened
// Size: 0x10(Inherited: 0x0) 
struct FOnMediaOpened
{
	struct FString DeviceUrl;  // 0x0(0x10)

}; 
// Function MediaPlate.MediaPlateComponent.IsMediaPlatePlaying
// Size: 0x1(Inherited: 0x0) 
struct FIsMediaPlatePlaying
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function MediaPlate.MediaPlateComponent.GetLoop
// Size: 0x1(Inherited: 0x0) 
struct FGetLoop
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function MediaPlate.MediaPlateComponent.GetMediaPlayer
// Size: 0x8(Inherited: 0x0) 
struct FGetMediaPlayer
{
	struct UMediaPlayer* ReturnValue;  // 0x0(0x8)

}; 
// Function MediaPlate.MediaPlateComponent.GetMediaTexture
// Size: 0x8(Inherited: 0x0) 
struct FGetMediaTexture
{
	struct UMediaTexture* ReturnValue;  // 0x0(0x8)

}; 
// Function MediaPlate.MediaPlateComponent.Rewind
// Size: 0x1(Inherited: 0x0) 
struct FRewind
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function MediaPlate.MediaPlateComponent.SetLoop
// Size: 0x1(Inherited: 0x0) 
struct FSetLoop
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bInLoop : 1;  // 0x0(0x1)

}; 
// Function MediaPlate.MediaPlateComponent.Seek
// Size: 0x10(Inherited: 0x0) 
struct FSeek
{
	struct FTimespan time;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function MediaPlate.MediaPlateComponent.SetPlayOnlyWhenVisible
// Size: 0x1(Inherited: 0x0) 
struct FSetPlayOnlyWhenVisible
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bInPlayOnlyWhenVisible : 1;  // 0x0(0x1)

}; 
// Function MediaPlate.MediaPlateComponent.SetLetterboxAspectRatio
// Size: 0x4(Inherited: 0x0) 
struct FSetLetterboxAspectRatio
{
	float AspectRatio;  // 0x0(0x4)

}; 
// Function MediaPlate.MediaPlateComponent.SetMeshRange
// Size: 0x10(Inherited: 0x0) 
struct FSetMeshRange
{
	struct FVector2D InMeshRange;  // 0x0(0x10)

}; 
