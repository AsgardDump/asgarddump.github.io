#pragma once 
#include <BlueprintFileUtils_Structs.h>
 
 
 
// Class BlueprintFileUtils.BlueprintFileUtilsBPLibrary
// Size: 0x28(Inherited: 0x28) 
struct UBlueprintFileUtilsBPLibrary : public UBlueprintFunctionLibrary
{

	bool MoveFile(struct FString DestFilename, struct FString SrcFilename, bool bReplace, bool bEvenIfReadOnly); // Function BlueprintFileUtils.BlueprintFileUtilsBPLibrary.MoveFile
	bool MakeDirectory(struct FString Path, bool bCreateTree); // Function BlueprintFileUtils.BlueprintFileUtilsBPLibrary.MakeDirectory
	struct FString GetUserDirectory(); // Function BlueprintFileUtils.BlueprintFileUtilsBPLibrary.GetUserDirectory
	bool FindRecursive(struct FString StartDirectory, struct TArray<struct FString>& FoundPaths, struct FString Wildcard, bool bFindFiles, bool bFindDirectories); // Function BlueprintFileUtils.BlueprintFileUtilsBPLibrary.FindRecursive
	bool FindFiles(struct FString Directory, struct TArray<struct FString>& FoundFiles, struct FString FileExtension); // Function BlueprintFileUtils.BlueprintFileUtilsBPLibrary.FindFiles
	bool FileExists(struct FString Filename); // Function BlueprintFileUtils.BlueprintFileUtilsBPLibrary.FileExists
	bool DirectoryExists(struct FString Directory); // Function BlueprintFileUtils.BlueprintFileUtilsBPLibrary.DirectoryExists
	bool DeleteFile(struct FString Filename, bool bMustExist, bool bEvenIfReadOnly); // Function BlueprintFileUtils.BlueprintFileUtilsBPLibrary.DeleteFile
	bool DeleteDirectory(struct FString Directory, bool bMustExist, bool bDeleteRecursively); // Function BlueprintFileUtils.BlueprintFileUtilsBPLibrary.DeleteDirectory
	bool CopyFile(struct FString DestFilename, struct FString SrcFilename, bool bReplace, bool bEvenIfReadOnly); // Function BlueprintFileUtils.BlueprintFileUtilsBPLibrary.CopyFile
}; 



