#pragma once 
#include "SDK.h" 
 
 
// ScriptStruct JsonUtilities.JsonObjectWrapper
// Size: 0x20(Inherited: 0x0) 
struct FJsonObjectWrapper
{
	struct FString JsonString;  // 0x0(0x10)
	char pad_16[16];  // 0x10(0x10)

}; 
