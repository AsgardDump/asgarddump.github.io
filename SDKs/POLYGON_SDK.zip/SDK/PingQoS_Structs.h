#pragma once 
#include "SDK.h" 
 
 
// DelegateFunction PingQoS.PingQoSDelegate__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FPingQoSDelegate__DelegateSignature
{
	struct TArray<struct FPingQoSInfo> Result;  // 0x0(0x10)

}; 
// ScriptStruct PingQoS.PingQoSInfo
// Size: 0x40(Inherited: 0x0) 
struct FPingQoSInfo
{
	struct FString URL;  // 0x0(0x10)
	struct FString IP;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool bUseIP : 1;  // 0x20(0x1)
	char pad_33[3];  // 0x21(0x3)
	int32_t Port;  // 0x24(0x4)
	struct FString Region;  // 0x28(0x10)
	int32_t Ping;  // 0x38(0x4)
	char pad_60[4];  // 0x3C(0x4)

}; 
// Function PingQoS.PingQoSSubsystem.Init
// Size: 0x10(Inherited: 0x0) 
struct FInit
{
	struct TArray<struct FPingQoSInfo> SetInfo;  // 0x0(0x10)

}; 
// Function PingQoS.PingQoSSubsystem.Recv
// Size: 0x10(Inherited: 0x0) 
struct FRecv
{
	struct TArray<struct FPingQoSInfo> ResultInfos;  // 0x0(0x10)

}; 
// Function PingQoS.PingQoSSubsystem.Update
// Size: 0x1(Inherited: 0x0) 
struct FUpdate
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
