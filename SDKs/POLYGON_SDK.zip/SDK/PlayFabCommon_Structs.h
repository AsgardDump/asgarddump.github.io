#pragma once 
#include "SDK.h" 
 
 
// Function PlayFabCommon.PlayFabAuthenticationContext.GetClientSessionTicket
// Size: 0x10(Inherited: 0x0) 
struct FGetClientSessionTicket
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// Function PlayFabCommon.PlayFabAuthenticationContext.GetDeveloperSecretKey
// Size: 0x10(Inherited: 0x0) 
struct FGetDeveloperSecretKey
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// Function PlayFabCommon.PlayFabAuthenticationContext.GetEntityToken
// Size: 0x10(Inherited: 0x0) 
struct FGetEntityToken
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// Function PlayFabCommon.PlayFabAuthenticationContext.GetPlayFabId
// Size: 0x10(Inherited: 0x0) 
struct FGetPlayFabId
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// Function PlayFabCommon.PlayFabAuthenticationContext.SetClientSessionTicket
// Size: 0x10(Inherited: 0x0) 
struct FSetClientSessionTicket
{
	struct FString InTicket;  // 0x0(0x10)

}; 
// Function PlayFabCommon.PlayFabAuthenticationContext.SetDeveloperSecretKey
// Size: 0x10(Inherited: 0x0) 
struct FSetDeveloperSecretKey
{
	struct FString InKey;  // 0x0(0x10)

}; 
// Function PlayFabCommon.PlayFabAuthenticationContext.SetEntityToken
// Size: 0x10(Inherited: 0x0) 
struct FSetEntityToken
{
	struct FString InToken;  // 0x0(0x10)

}; 
// Function PlayFabCommon.PlayFabAuthenticationContext.SetPlayFabId
// Size: 0x10(Inherited: 0x0) 
struct FSetPlayFabId
{
	struct FString InKey;  // 0x0(0x10)

}; 
