#pragma once 
#include <BP_Item_Skin_G36C_06_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Item_Skin_G36C_06.BP_Item_Skin_G36C_06_C
// Size: 0x360(Inherited: 0x358) 
struct ABP_Item_Skin_G36C_06_C : public AItem_Module_Skin
{
	struct USceneComponent* DefaultSceneRoot;  // 0x358(0x8)

}; 



