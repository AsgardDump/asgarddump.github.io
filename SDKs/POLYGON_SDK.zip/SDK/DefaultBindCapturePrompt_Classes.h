#pragma once 
#include <DefaultBindCapturePrompt_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass DefaultBindCapturePrompt.DefaultBindCapturePrompt_C
// Size: 0x2E0(Inherited: 0x2E0) 
struct UDefaultBindCapturePrompt_C : public UBindCapturePrompt
{

}; 



