#pragma once 
#include "SDK.h" 
 
 
// ScriptStruct CoreOnline.JoinabilitySettings
// Size: 0x14(Inherited: 0x0) 
struct FJoinabilitySettings
{
	struct FName SessionName;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bPublicSearchable : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool bAllowInvites : 1;  // 0x9(0x1)
	char pad_10_1 : 7;  // 0xA(0x1)
	bool bJoinViaPresence : 1;  // 0xA(0x1)
	char pad_11_1 : 7;  // 0xB(0x1)
	bool bJoinViaPresenceFriendsOnly : 1;  // 0xB(0x1)
	int32_t MaxPlayers;  // 0xC(0x4)
	int32_t MaxPartySize;  // 0x10(0x4)

}; 
// ScriptStruct CoreOnline.UniqueNetIdWrapper
// Size: 0x1(Inherited: 0x0) 
struct FUniqueNetIdWrapper
{
	char pad_0[1];  // 0x0(0x1)

}; 
