#pragma once 
#include <BP_Item_Strap_ScarH_03_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Item_Strap_ScarH_03.BP_Item_Strap_ScarH_03_C
// Size: 0x350(Inherited: 0x350) 
struct ABP_Item_Strap_ScarH_03_C : public AItem_Module_Strap
{

}; 



