#pragma once 
#include <BP_Item_Underbarrel_Grip_02_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Item_Underbarrel_Grip_02.BP_Item_Underbarrel_Grip_02_C
// Size: 0x3C0(Inherited: 0x3C0) 
struct ABP_Item_Underbarrel_Grip_02_C : public AItem_Module_Underbarrel_Grip
{

}; 



