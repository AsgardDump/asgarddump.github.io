#pragma once 
#include <BP_Item_Sniper_M24_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Item_Sniper_M24.BP_Item_Sniper_M24_C
// Size: 0x760(Inherited: 0x750) 
struct ABP_Item_Sniper_M24_C : public AItem_Gun_Sniper
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x750(0x8)
	struct UStaticMeshComponent* IronSight;  // 0x758(0x8)

	void SetSight(); // Function BP_Item_Sniper_M24.BP_Item_Sniper_M24_C.SetSight
	void ReceiveBeginPlay(); // Function BP_Item_Sniper_M24.BP_Item_Sniper_M24_C.ReceiveBeginPlay
	void OnSetGunModules_Event(); // Function BP_Item_Sniper_M24.BP_Item_Sniper_M24_C.OnSetGunModules_Event
	void ExecuteUbergraph_BP_Item_Sniper_M24(int32_t EntryPoint); // Function BP_Item_Sniper_M24.BP_Item_Sniper_M24_C.ExecuteUbergraph_BP_Item_Sniper_M24
}; 



