#pragma once 
#include <ModelingComponents_Structs.h>
 
 
 
// Class ModelingComponents.MultiSelectionMeshEditingToolBuilder
// Size: 0x28(Inherited: 0x28) 
struct UMultiSelectionMeshEditingToolBuilder : public UInteractiveToolWithToolTargetsBuilder
{

}; 



// Class ModelingComponents.MultiSelectionMeshEditingTool
// Size: 0xB8(Inherited: 0xB0) 
struct UMultiSelectionMeshEditingTool : public UMultiSelectionTool
{
	struct TWeakObjectPtr<UWorld> TargetWorld;  // 0xB0(0x8)

}; 



// Class ModelingComponents.BaseMeshProcessingToolBuilder
// Size: 0x28(Inherited: 0x28) 
struct UBaseMeshProcessingToolBuilder : public UInteractiveToolWithToolTargetsBuilder
{

}; 



// Class ModelingComponents.PreviewGeometry
// Size: 0xD0(Inherited: 0x28) 
struct UPreviewGeometry : public UObject
{
	struct APreviewGeometryActor* ParentActor;  // 0x28(0x8)
	struct TMap<struct FString, struct ULineSetComponent*> LineSets;  // 0x30(0x50)
	struct TMap<struct FString, struct UPointSetComponent*> PointSets;  // 0x80(0x50)

	bool SetPointSetVisibility(struct FString PointSetIdentifier, bool bVisible); // Function ModelingComponents.PreviewGeometry.SetPointSetVisibility
	bool SetPointSetMaterial(struct FString PointSetIdentifier, struct UMaterialInterface* NewMaterial); // Function ModelingComponents.PreviewGeometry.SetPointSetMaterial
	bool SetLineSetVisibility(struct FString LineSetIdentifier, bool bVisible); // Function ModelingComponents.PreviewGeometry.SetLineSetVisibility
	bool SetLineSetMaterial(struct FString LineSetIdentifier, struct UMaterialInterface* NewMaterial); // Function ModelingComponents.PreviewGeometry.SetLineSetMaterial
	void SetAllPointSetsMaterial(struct UMaterialInterface* Material); // Function ModelingComponents.PreviewGeometry.SetAllPointSetsMaterial
	void SetAllLineSetsMaterial(struct UMaterialInterface* Material); // Function ModelingComponents.PreviewGeometry.SetAllLineSetsMaterial
	bool RemovePointSet(struct FString PointSetIdentifier, bool bDestroy); // Function ModelingComponents.PreviewGeometry.RemovePointSet
	bool RemoveLineSet(struct FString LineSetIdentifier, bool bDestroy); // Function ModelingComponents.PreviewGeometry.RemoveLineSet
	void RemoveAllPointSets(bool bDestroy); // Function ModelingComponents.PreviewGeometry.RemoveAllPointSets
	void RemoveAllLineSets(bool bDestroy); // Function ModelingComponents.PreviewGeometry.RemoveAllLineSets
	struct APreviewGeometryActor* GetActor(); // Function ModelingComponents.PreviewGeometry.GetActor
	struct UPointSetComponent* FindPointSet(struct FString PointSetIdentifier); // Function ModelingComponents.PreviewGeometry.FindPointSet
	struct ULineSetComponent* FindLineSet(struct FString LineSetIdentifier); // Function ModelingComponents.PreviewGeometry.FindLineSet
	void Disconnect(); // Function ModelingComponents.PreviewGeometry.Disconnect
	void CreateInWorld(struct UWorld* World, struct FTransform& WithTransform); // Function ModelingComponents.PreviewGeometry.CreateInWorld
	struct UPointSetComponent* AddPointSet(struct FString PointSetIdentifier); // Function ModelingComponents.PreviewGeometry.AddPointSet
	struct ULineSetComponent* AddLineSet(struct FString LineSetIdentifier); // Function ModelingComponents.PreviewGeometry.AddLineSet
}; 



// Class ModelingComponents.SingleSelectionMeshEditingToolBuilder
// Size: 0x28(Inherited: 0x28) 
struct USingleSelectionMeshEditingToolBuilder : public UInteractiveToolWithToolTargetsBuilder
{

}; 



// Class ModelingComponents.TriangleSetComponent
// Size: 0x670(Inherited: 0x570) 
struct UTriangleSetComponent : public UMeshComponent
{
	struct FBoxSphereBounds Bounds;  // 0x570(0x38)
	char pad_1448_1 : 7;  // 0x5A8(0x1)
	bool bBoundsDirty : 1;  // 0x5A8(0x1)
	char pad_1449[199];  // 0x5A9(0xC7)

}; 



// Class ModelingComponents.SingleSelectionMeshEditingTool
// Size: 0xB8(Inherited: 0xA8) 
struct USingleSelectionMeshEditingTool : public USingleSelectionTool
{
	struct TWeakObjectPtr<UWorld> TargetWorld;  // 0xA8(0x8)
	struct UPersistentMeshSelection* InputSelection;  // 0xB0(0x8)

}; 



// Class ModelingComponents.BaseVoxelTool
// Size: 0x118(Inherited: 0x100) 
struct UBaseVoxelTool : public UBaseCreateFromSelectedTool
{
	struct UVoxelProperties* VoxProperties;  // 0x100(0x8)
	char pad_264[16];  // 0x108(0x10)

}; 



// Class ModelingComponents.BaseMeshProcessingTool
// Size: 0x400(Inherited: 0xA8) 
struct UBaseMeshProcessingTool : public USingleSelectionTool
{
	char pad_168[32];  // 0xA8(0x20)
	struct UMeshOpPreviewWithBackgroundCompute* Preview;  // 0xC8(0x8)
	char pad_208[816];  // 0xD0(0x330)

}; 



// Class ModelingComponents.MeshSurfacePointMeshEditingToolBuilder
// Size: 0x30(Inherited: 0x30) 
struct UMeshSurfacePointMeshEditingToolBuilder : public UMeshSurfacePointToolBuilder
{

}; 



// Class ModelingComponents.PreviewMesh
// Size: 0x140(Inherited: 0x28) 
struct UPreviewMesh : public UObject
{
	char pad_40[24];  // 0x28(0x18)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool bBuildSpatialDataStructure : 1;  // 0x40(0x1)
	char pad_65[15];  // 0x41(0xF)
	struct UDynamicMeshComponent* DynamicMeshComponent;  // 0x50(0x8)
	char pad_88[232];  // 0x58(0xE8)

}; 



// Class ModelingComponents.WeightMapSetProperties
// Size: 0xC8(Inherited: 0xA8) 
struct UWeightMapSetProperties : public UInteractiveToolPropertySet
{
	struct FName WeightMap;  // 0xA8(0x8)
	struct TArray<struct FString> WeightMapsList;  // 0xB0(0x10)
	char pad_192_1 : 7;  // 0xC0(0x1)
	bool bInvertWeightMap : 1;  // 0xC0(0x1)
	char pad_193[7];  // 0xC1(0x7)

	struct TArray<struct FString> GetWeightMapsFunc(); // Function ModelingComponents.WeightMapSetProperties.GetWeightMapsFunc
}; 



// Class ModelingComponents.BaseCreateFromSelectedTool
// Size: 0x100(Inherited: 0xB8) 
struct UBaseCreateFromSelectedTool : public UMultiSelectionMeshEditingTool
{
	char pad_184[8];  // 0xB8(0x8)
	struct UTransformInputsToolProperties* TransformProperties;  // 0xC0(0x8)
	struct UCreateMeshObjectTypeProperties* OutputTypeProperties;  // 0xC8(0x8)
	struct UBaseCreateFromSelectedHandleSourceProperties* HandleSourcesProperties;  // 0xD0(0x8)
	struct UMeshOpPreviewWithBackgroundCompute* Preview;  // 0xD8(0x8)
	struct TArray<struct UTransformProxy*> TransformProxies;  // 0xE0(0x10)
	struct TArray<struct UCombinedTransformGizmo*> TransformGizmos;  // 0xF0(0x10)

}; 



// Class ModelingComponents.BaseCreateFromSelectedToolBuilder
// Size: 0x28(Inherited: 0x28) 
struct UBaseCreateFromSelectedToolBuilder : public UMultiSelectionMeshEditingToolBuilder
{

}; 



// Class ModelingComponents.CreateMeshObjectTypeProperties
// Size: 0xD8(Inherited: 0xA8) 
struct UCreateMeshObjectTypeProperties : public UInteractiveToolPropertySet
{
	struct FString OutputType;  // 0xA8(0x10)
	AVolume* VolumeType;  // 0xB8(0x8)
	struct TArray<struct FString> OutputTypeNamesList;  // 0xC0(0x10)
	char pad_208_1 : 7;  // 0xD0(0x1)
	bool bShowVolumeList : 1;  // 0xD0(0x1)
	char pad_209[7];  // 0xD1(0x7)

	bool ShouldShowPropertySet(); // Function ModelingComponents.CreateMeshObjectTypeProperties.ShouldShowPropertySet
	struct TArray<struct FString> GetOutputTypeNamesFunc(); // Function ModelingComponents.CreateMeshObjectTypeProperties.GetOutputTypeNamesFunc
	uint8_t  GetCurrentCreateMeshType(); // Function ModelingComponents.CreateMeshObjectTypeProperties.GetCurrentCreateMeshType
}; 



// Class ModelingComponents.OnAcceptHandleSourcesPropertiesBase
// Size: 0xA8(Inherited: 0xA8) 
struct UOnAcceptHandleSourcesPropertiesBase : public UInteractiveToolPropertySet
{

}; 



// Class ModelingComponents.GeometrySelectionEditCommand
// Size: 0x28(Inherited: 0x28) 
struct UGeometrySelectionEditCommand : public UInteractiveCommand
{

}; 



// Class ModelingComponents.PointSetComponent
// Size: 0x5F0(Inherited: 0x570) 
struct UPointSetComponent : public UMeshComponent
{
	struct UMaterialInterface* PointMaterial;  // 0x570(0x8)
	struct FBoxSphereBounds Bounds;  // 0x578(0x38)
	char pad_1456_1 : 7;  // 0x5B0(0x1)
	bool bBoundsDirty : 1;  // 0x5B0(0x1)
	char pad_1457[63];  // 0x5B1(0x3F)

}; 



// Class ModelingComponents.InteractiveToolActivity
// Size: 0x30(Inherited: 0x30) 
struct UInteractiveToolActivity : public UInteractionMechanic
{

}; 



// Class ModelingComponents.UVLayoutPreviewProperties
// Size: 0xD0(Inherited: 0xA8) 
struct UUVLayoutPreviewProperties : public UInteractiveToolPropertySet
{
	char pad_168_1 : 7;  // 0xA8(0x1)
	bool bEnabled : 1;  // 0xA8(0x1)
	char pad_169[3];  // 0xA9(0x3)
	uint8_t  Side;  // 0xAC(0x4)
	float Scale;  // 0xB0(0x4)
	char pad_180[4];  // 0xB4(0x4)
	struct FVector2D Offset;  // 0xB8(0x10)
	char pad_200_1 : 7;  // 0xC8(0x1)
	bool bShowWireframe : 1;  // 0xC8(0x1)
	char pad_201[7];  // 0xC9(0x7)

}; 



// Class ModelingComponents.DynamicMeshCommitter
// Size: 0x28(Inherited: 0x28) 
struct UDynamicMeshCommitter : public UInterface
{

}; 



// Class ModelingComponents.DynamicMeshProvider
// Size: 0x28(Inherited: 0x28) 
struct UDynamicMeshProvider : public UInterface
{

}; 



// Class ModelingComponents.LineSetComponent
// Size: 0x5F0(Inherited: 0x570) 
struct ULineSetComponent : public UMeshComponent
{
	struct UMaterialInterface* LineMaterial;  // 0x570(0x8)
	struct FBoxSphereBounds Bounds;  // 0x578(0x38)
	char pad_1456_1 : 7;  // 0x5B0(0x1)
	bool bBoundsDirty : 1;  // 0x5B0(0x1)
	char pad_1457[63];  // 0x5B1(0x3F)

}; 



// Class ModelingComponents.PersistentDynamicMeshSource
// Size: 0x28(Inherited: 0x28) 
struct UPersistentDynamicMeshSource : public UInterface
{

}; 



// Class ModelingComponents.PreviewMeshActor
// Size: 0x298(Inherited: 0x298) 
struct APreviewMeshActor : public AInternalToolFrameworkActor
{

}; 



// Class ModelingComponents.GeometrySelectionManager
// Size: 0x150(Inherited: 0x28) 
struct UGeometrySelectionManager : public UObject
{
	char pad_40[40];  // 0x28(0x28)
	struct UGeometrySelectionEditCommandArguments* SelectionArguments;  // 0x50(0x8)
	char pad_88[8];  // 0x58(0x8)
	struct UInteractiveToolsContext* ToolsContext;  // 0x60(0x8)
	char pad_104[224];  // 0x68(0xE0)
	struct UPersistentMeshSelection* OldSelection;  // 0x148(0x8)

}; 



// Class ModelingComponents.UVLayoutPreview
// Size: 0x160(Inherited: 0x28) 
struct UUVLayoutPreview : public UObject
{
	struct UUVLayoutPreviewProperties* Settings;  // 0x28(0x8)
	struct UPreviewMesh* PreviewMesh;  // 0x30(0x8)
	struct UTriangleSetComponent* TriangleComponent;  // 0x38(0x8)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool bShowBackingRectangle : 1;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)
	struct UMaterialInterface* BackingRectangleMaterial;  // 0x48(0x8)
	char pad_80[272];  // 0x50(0x110)

}; 



// Class ModelingComponents.ToolActivityHost
// Size: 0x28(Inherited: 0x28) 
struct UToolActivityHost : public UInterface
{

}; 



// Class ModelingComponents.GeometrySelectionEditCommandArguments
// Size: 0x48(Inherited: 0x30) 
struct UGeometrySelectionEditCommandArguments : public UInteractiveCommandArguments
{
	char pad_48[24];  // 0x30(0x18)

}; 



// Class ModelingComponents.VoxelProperties
// Size: 0xC0(Inherited: 0xA8) 
struct UVoxelProperties : public UInteractiveToolPropertySet
{
	int32_t VoxelCount;  // 0xA8(0x4)
	char pad_172_1 : 7;  // 0xAC(0x1)
	bool bAutoSimplify : 1;  // 0xAC(0x1)
	char pad_173_1 : 7;  // 0xAD(0x1)
	bool bRemoveInternalSurfaces : 1;  // 0xAD(0x1)
	char pad_174[2];  // 0xAE(0x2)
	double SimplifyMaxErrorFactor;  // 0xB0(0x8)
	double CubeRootMinComponentVolume;  // 0xB8(0x8)

}; 



// Class ModelingComponents.PreviewGeometryActor
// Size: 0x298(Inherited: 0x298) 
struct APreviewGeometryActor : public AInternalToolFrameworkActor
{

}; 



// Class ModelingComponents.OnAcceptHandleSourcesProperties
// Size: 0xB0(Inherited: 0xA8) 
struct UOnAcceptHandleSourcesProperties : public UOnAcceptHandleSourcesPropertiesBase
{
	uint8_t  HandleInputs;  // 0xA8(0x1)
	char pad_169[7];  // 0xA9(0x7)

}; 



// Class ModelingComponents.DynamicMeshReplacementChangeTarget
// Size: 0x58(Inherited: 0x28) 
struct UDynamicMeshReplacementChangeTarget : public UObject
{
	char pad_40[48];  // 0x28(0x30)

}; 



// Class ModelingComponents.BaseCreateFromSelectedHandleSourceProperties
// Size: 0xD8(Inherited: 0xB0) 
struct UBaseCreateFromSelectedHandleSourceProperties : public UOnAcceptHandleSourcesProperties
{
	uint8_t  OutputWriteTo;  // 0xB0(0x4)
	char pad_180[4];  // 0xB4(0x4)
	struct FString OutputNewName;  // 0xB8(0x10)
	struct FString OutputExistingName;  // 0xC8(0x10)

}; 



// Class ModelingComponents.TransformInputsToolProperties
// Size: 0xB0(Inherited: 0xA8) 
struct UTransformInputsToolProperties : public UInteractiveToolPropertySet
{
	char pad_168_1 : 7;  // 0xA8(0x1)
	bool bShowTransformGizmo : 1;  // 0xA8(0x1)
	char pad_169[7];  // 0xA9(0x7)

}; 



// Class ModelingComponents.OctreeDynamicMeshComponent
// Size: 0x6F0(Inherited: 0x5E0) 
struct UOctreeDynamicMeshComponent : public UBaseDynamicMeshComponent
{
	char pad_1504[80];  // 0x5E0(0x50)
	struct UDynamicMesh* MeshObject;  // 0x630(0x8)
	char pad_1592[184];  // 0x638(0xB8)

	void SetDynamicMesh(struct UDynamicMesh* NewMesh); // Function ModelingComponents.OctreeDynamicMeshComponent.SetDynamicMesh
}; 



// Class ModelingComponents.MeshElementsVisualizerProperties
// Size: 0xD0(Inherited: 0xA8) 
struct UMeshElementsVisualizerProperties : public UInteractiveToolPropertySet
{
	char pad_168_1 : 7;  // 0xA8(0x1)
	bool bVisible : 1;  // 0xA8(0x1)
	char pad_169_1 : 7;  // 0xA9(0x1)
	bool bShowWireframe : 1;  // 0xA9(0x1)
	char pad_170_1 : 7;  // 0xAA(0x1)
	bool bShowBorders : 1;  // 0xAA(0x1)
	char pad_171_1 : 7;  // 0xAB(0x1)
	bool bShowUVSeams : 1;  // 0xAB(0x1)
	char pad_172_1 : 7;  // 0xAC(0x1)
	bool bShowNormalSeams : 1;  // 0xAC(0x1)
	char pad_173_1 : 7;  // 0xAD(0x1)
	bool bShowColorSeams : 1;  // 0xAD(0x1)
	char pad_174[2];  // 0xAE(0x2)
	float ThicknessScale;  // 0xB0(0x4)
	struct FColor WireframeColor;  // 0xB4(0x4)
	struct FColor BoundaryEdgeColor;  // 0xB8(0x4)
	struct FColor UVSeamColor;  // 0xBC(0x4)
	struct FColor NormalSeamColor;  // 0xC0(0x4)
	struct FColor ColorSeamColor;  // 0xC4(0x4)
	float DepthBias;  // 0xC8(0x4)
	char pad_204_1 : 7;  // 0xCC(0x1)
	bool bAdjustDepthBiasUsingMeshSize : 1;  // 0xCC(0x1)
	char pad_205[3];  // 0xCD(0x3)

}; 



// Class ModelingComponents.PersistentMeshSelectionManager
// Size: 0x40(Inherited: 0x28) 
struct UPersistentMeshSelectionManager : public UObject
{
	struct UInteractiveToolsContext* ParentContext;  // 0x28(0x8)
	struct UPersistentMeshSelection* ActiveSelection;  // 0x30(0x8)
	struct UPreviewGeometry* SelectionDisplay;  // 0x38(0x8)

}; 



// Class ModelingComponents.SpatialCurveDistanceMechanic
// Size: 0x410(Inherited: 0x30) 
struct USpatialCurveDistanceMechanic : public UInteractionMechanic
{
	char pad_48[992];  // 0x30(0x3E0)

}; 



// Class ModelingComponents.LatticeControlPointsMechanic
// Size: 0x500(Inherited: 0x30) 
struct ULatticeControlPointsMechanic : public UInteractionMechanic
{
	char pad_48[496];  // 0x30(0x1F0)
	struct APreviewGeometryActor* PreviewGeometryActor;  // 0x220(0x8)
	struct UPointSetComponent* DrawnControlPoints;  // 0x228(0x8)
	struct ULineSetComponent* DrawnLatticeEdges;  // 0x230(0x8)
	char pad_568[168];  // 0x238(0xA8)
	struct UTransformProxy* PointTransformProxy;  // 0x2E0(0x8)
	struct UCombinedTransformGizmo* PointTransformGizmo;  // 0x2E8(0x8)
	char pad_752[88];  // 0x2F0(0x58)
	struct URectangleMarqueeMechanic* MarqueeMechanic;  // 0x348(0x8)
	char pad_848[432];  // 0x350(0x1B0)

}; 



// Class ModelingComponents.MeshElementsVisualizer
// Size: 0xF8(Inherited: 0xD0) 
struct UMeshElementsVisualizer : public UPreviewGeometry
{
	struct UMeshElementsVisualizerProperties* Settings;  // 0xD0(0x8)
	struct UMeshWireframeComponent* WireframeComponent;  // 0xD8(0x8)
	char pad_224[24];  // 0xE0(0x18)

}; 



// Class ModelingComponents.MeshWireframeComponent
// Size: 0x610(Inherited: 0x570) 
struct UMeshWireframeComponent : public UMeshComponent
{
	float LineDepthBias;  // 0x570(0x4)
	float LineDepthBiasSizeScale;  // 0x574(0x4)
	float ThicknessScale;  // 0x578(0x4)
	char pad_1404_1 : 7;  // 0x57C(0x1)
	bool bEnableWireframe : 1;  // 0x57C(0x1)
	char pad_1405[3];  // 0x57D(0x3)
	struct FColor WireframeColor;  // 0x580(0x4)
	float WireframeThickness;  // 0x584(0x4)
	char pad_1416_1 : 7;  // 0x588(0x1)
	bool bEnableBoundaryEdges : 1;  // 0x588(0x1)
	char pad_1417[3];  // 0x589(0x3)
	struct FColor BoundaryEdgeColor;  // 0x58C(0x4)
	float BoundaryEdgeThickness;  // 0x590(0x4)
	char pad_1428_1 : 7;  // 0x594(0x1)
	bool bEnableUVSeams : 1;  // 0x594(0x1)
	char pad_1429[3];  // 0x595(0x3)
	struct FColor UVSeamColor;  // 0x598(0x4)
	float UVSeamThickness;  // 0x59C(0x4)
	char pad_1440_1 : 7;  // 0x5A0(0x1)
	bool bEnableNormalSeams : 1;  // 0x5A0(0x1)
	char pad_1441[3];  // 0x5A1(0x3)
	struct FColor NormalSeamColor;  // 0x5A4(0x4)
	float NormalSeamThickness;  // 0x5A8(0x4)
	char pad_1452_1 : 7;  // 0x5AC(0x1)
	bool bEnableColorSeams : 1;  // 0x5AC(0x1)
	char pad_1453[3];  // 0x5AD(0x3)
	struct FColor ColorSeamColor;  // 0x5B0(0x4)
	float ColorSeamThickness;  // 0x5B4(0x4)
	struct UMaterialInterface* LineMaterial;  // 0x5B8(0x8)
	struct FBoxSphereBounds LocalBounds;  // 0x5C0(0x38)
	char pad_1528[24];  // 0x5F8(0x18)

}; 



// Class ModelingComponents.PolyEditPreviewMesh
// Size: 0x550(Inherited: 0x140) 
struct UPolyEditPreviewMesh : public UPreviewMesh
{
	char pad_320[1040];  // 0x140(0x410)

}; 



// Class ModelingComponents.CollectSurfacePathMechanic
// Size: 0x5C0(Inherited: 0x30) 
struct UCollectSurfacePathMechanic : public UInteractionMechanic
{
	char pad_48[1424];  // 0x30(0x590)

}; 



// Class ModelingComponents.SpaceCurveDeformationMechanic
// Size: 0x2D0(Inherited: 0x30) 
struct USpaceCurveDeformationMechanic : public UInteractionMechanic
{
	char pad_48[16];  // 0x30(0x10)
	struct USingleClickInputBehavior* ClickBehavior;  // 0x40(0x8)
	struct UMouseHoverBehavior* HoverBehavior;  // 0x48(0x8)
	char pad_80[24];  // 0x50(0x18)
	struct USpaceCurveDeformationMechanicPropertySet* TransformProperties;  // 0x68(0x8)
	char pad_112[248];  // 0x70(0xF8)
	struct APreviewGeometryActor* PreviewGeometryActor;  // 0x168(0x8)
	struct UPointSetComponent* RenderPoints;  // 0x170(0x8)
	struct ULineSetComponent* RenderSegments;  // 0x178(0x8)
	char pad_384[56];  // 0x180(0x38)
	struct UTransformProxy* PointTransformProxy;  // 0x1B8(0x8)
	struct UCombinedTransformGizmo* PointTransformGizmo;  // 0x1C0(0x8)
	char pad_456[264];  // 0x1C8(0x108)

}; 



// Class ModelingComponents.ConstructionPlaneMechanic
// Size: 0xF0(Inherited: 0x30) 
struct UConstructionPlaneMechanic : public UInteractionMechanic
{
	char pad_48[152];  // 0x30(0x98)
	struct UCombinedTransformGizmo* PlaneTransformGizmo;  // 0xC8(0x8)
	struct UTransformProxy* PlaneTransformProxy;  // 0xD0(0x8)
	char pad_216[8];  // 0xD8(0x8)
	struct USingleClickInputBehavior* ClickToSetPlaneBehavior;  // 0xE0(0x8)
	char pad_232[8];  // 0xE8(0x8)

}; 



// Class ModelingComponents.SpaceCurveDeformationMechanicPropertySet
// Size: 0xB8(Inherited: 0xA8) 
struct USpaceCurveDeformationMechanicPropertySet : public UInteractiveToolPropertySet
{
	uint8_t  TransformMode;  // 0xA8(0x4)
	uint8_t  TransformOrigin;  // 0xAC(0x4)
	float Softness;  // 0xB0(0x4)
	uint8_t  SoftFalloff;  // 0xB4(0x4)

}; 



// Class ModelingComponents.CurveControlPointsMechanic
// Size: 0x680(Inherited: 0x30) 
struct UCurveControlPointsMechanic : public UInteractionMechanic
{
	char pad_48[16];  // 0x30(0x10)
	struct USingleClickInputBehavior* ClickBehavior;  // 0x40(0x8)
	struct UMouseHoverBehavior* HoverBehavior;  // 0x48(0x8)
	char pad_80[1176];  // 0x50(0x498)
	struct APreviewGeometryActor* PreviewGeometryActor;  // 0x4E8(0x8)
	struct UPointSetComponent* DrawnControlPoints;  // 0x4F0(0x8)
	struct ULineSetComponent* DrawnControlSegments;  // 0x4F8(0x8)
	struct UPointSetComponent* PreviewPoint;  // 0x500(0x8)
	struct ULineSetComponent* PreviewSegment;  // 0x508(0x8)
	char pad_1296[120];  // 0x510(0x78)
	struct UTransformProxy* PointTransformProxy;  // 0x588(0x8)
	struct UCombinedTransformGizmo* PointTransformGizmo;  // 0x590(0x8)
	char pad_1432[232];  // 0x598(0xE8)

}; 



// Class ModelingComponents.PolygroupLayersProperties
// Size: 0xC0(Inherited: 0xA8) 
struct UPolygroupLayersProperties : public UInteractiveToolPropertySet
{
	struct FName ActiveGroupLayer;  // 0xA8(0x8)
	struct TArray<struct FString> GroupLayersList;  // 0xB0(0x10)

	struct TArray<struct FString> GetGroupLayersFunc(); // Function ModelingComponents.PolygroupLayersProperties.GetGroupLayersFunc
}; 



// Class ModelingComponents.DragAlignmentMechanic
// Size: 0x260(Inherited: 0x30) 
struct UDragAlignmentMechanic : public UInteractionMechanic
{
	char pad_48[560];  // 0x30(0x230)

}; 



// Class ModelingComponents.PlaneDistanceFromHitMechanic
// Size: 0x510(Inherited: 0x30) 
struct UPlaneDistanceFromHitMechanic : public UInteractionMechanic
{
	char pad_48[1248];  // 0x30(0x4E0)

}; 



// Class ModelingComponents.PolyLassoMarqueeMechanic
// Size: 0x1D0(Inherited: 0x30) 
struct UPolyLassoMarqueeMechanic : public UInteractionMechanic
{
	char pad_48[88];  // 0x30(0x58)
	float SpacingTolerance;  // 0x88(0x4)
	float LineThickness;  // 0x8C(0x4)
	struct FLinearColor LineColor;  // 0x90(0x10)
	struct FLinearColor ClosedColor;  // 0xA0(0x10)
	char pad_176_1 : 7;  // 0xB0(0x1)
	bool bEnableFreehandPolygons : 1;  // 0xB0(0x1)
	char pad_177_1 : 7;  // 0xB1(0x1)
	bool bEnableMultiClickPolygons : 1;  // 0xB1(0x1)
	char pad_178[6];  // 0xB2(0x6)
	struct UClickDragInputBehavior* ClickDragBehavior;  // 0xB8(0x8)
	struct UMouseHoverBehavior* HoverBehavior;  // 0xC0(0x8)
	char pad_200[264];  // 0xC8(0x108)

}; 



// Class ModelingComponents.ModelingObjectsCreationAPI
// Size: 0x28(Inherited: 0x28) 
struct UModelingObjectsCreationAPI : public UObject
{

	struct FCreateTextureObjectResult CreateTextureObject(struct FCreateTextureObjectParams& CreateTexParams); // Function ModelingComponents.ModelingObjectsCreationAPI.CreateTextureObject
	struct FCreateMeshObjectResult CreateMeshObject(struct FCreateMeshObjectParams& CreateMeshParams); // Function ModelingComponents.ModelingObjectsCreationAPI.CreateMeshObject
}; 



// Class ModelingComponents.RectangleMarqueeMechanic
// Size: 0x220(Inherited: 0x30) 
struct URectangleMarqueeMechanic : public UInteractionMechanic
{
	char pad_48[8];  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool bUseExternalClickDragBehavior : 1;  // 0x38(0x1)
	char pad_57_1 : 7;  // 0x39(0x1)
	bool bUseExternalUpdateCameraState : 1;  // 0x39(0x1)
	char pad_58[70];  // 0x3A(0x46)
	double OnDragRectangleChangedDeferredThreshold;  // 0x80(0x8)
	char pad_136[72];  // 0x88(0x48)
	struct UClickDragInputBehavior* ClickDragBehavior;  // 0xD0(0x8)
	char pad_216[328];  // 0xD8(0x148)

}; 



// Class ModelingComponents.MeshOpPreviewWithBackgroundCompute
// Size: 0xB8(Inherited: 0x28) 
struct UMeshOpPreviewWithBackgroundCompute : public UObject
{
	char pad_40[48];  // 0x28(0x30)
	struct UPreviewMesh* PreviewMesh;  // 0x58(0x8)
	struct TArray<struct UMaterialInterface*> StandardMaterials;  // 0x60(0x10)
	struct UMaterialInterface* OverrideMaterial;  // 0x70(0x8)
	struct UMaterialInterface* WorkingMaterial;  // 0x78(0x8)
	struct UMaterialInterface* SecondaryMaterial;  // 0x80(0x8)
	struct TWeakObjectPtr<UWorld> PreviewWorld;  // 0x88(0x8)
	char pad_144[40];  // 0x90(0x28)

}; 



// Class ModelingComponents.ModelingComponentsSettings
// Size: 0x40(Inherited: 0x38) 
struct UModelingComponentsSettings : public UDeveloperSettings
{
	char pad_56_1 : 7;  // 0x38(0x1)
	bool bEnableRayTracingWhileEditing : 1;  // 0x38(0x1)
	char pad_57_1 : 7;  // 0x39(0x1)
	bool bEnableRayTracing : 1;  // 0x39(0x1)
	char pad_58_1 : 7;  // 0x3A(0x1)
	bool bEnableCollision : 1;  // 0x3A(0x1)
	char ECollisionTraceFlag CollisionMode;  // 0x3B(0x1)
	char pad_60[4];  // 0x3C(0x4)

}; 



// Class ModelingComponents.OnAcceptHandleSourcesPropertiesSingle
// Size: 0xB0(Inherited: 0xA8) 
struct UOnAcceptHandleSourcesPropertiesSingle : public UOnAcceptHandleSourcesPropertiesBase
{
	uint8_t  HandleInputs;  // 0xA8(0x1)
	char pad_169[7];  // 0xA9(0x7)

}; 



// Class ModelingComponents.PersistentMeshSelection
// Size: 0x88(Inherited: 0x28) 
struct UPersistentMeshSelection : public UObject
{
	char pad_40[96];  // 0x28(0x60)

}; 



// Class ModelingComponents.PolygonSelectionMechanic
// Size: 0xB00(Inherited: 0x30) 
struct UPolygonSelectionMechanic : public UInteractionMechanic
{
	char pad_48[72];  // 0x30(0x48)
	struct UPolygonSelectionMechanicProperties* Properties;  // 0x78(0x8)
	char pad_128[96];  // 0x80(0x60)
	struct UMouseHoverBehavior* HoverBehavior;  // 0xE0(0x8)
	struct USingleClickOrDragInputBehavior* ClickOrDragBehavior;  // 0xE8(0x8)
	struct URectangleMarqueeMechanic* MarqueeMechanic;  // 0xF0(0x8)
	char pad_248[1496];  // 0xF8(0x5D8)
	struct APreviewGeometryActor* PreviewGeometryActor;  // 0x6D0(0x8)
	struct UTriangleSetComponent* DrawnTriangleSetComponent;  // 0x6D8(0x8)
	char pad_1760[80];  // 0x6E0(0x50)
	struct UMaterialInterface* HighlightedFaceMaterial;  // 0x730(0x8)
	char pad_1848[968];  // 0x738(0x3C8)

}; 



// Class ModelingComponents.PolygonSelectionMechanicProperties
// Size: 0xC0(Inherited: 0xA8) 
struct UPolygonSelectionMechanicProperties : public UInteractiveToolPropertySet
{
	char pad_168_1 : 7;  // 0xA8(0x1)
	bool bSelectVertices : 1;  // 0xA8(0x1)
	char pad_169_1 : 7;  // 0xA9(0x1)
	bool bSelectEdges : 1;  // 0xA9(0x1)
	char pad_170_1 : 7;  // 0xAA(0x1)
	bool bSelectFaces : 1;  // 0xAA(0x1)
	char pad_171_1 : 7;  // 0xAB(0x1)
	bool bSelectEdgeLoops : 1;  // 0xAB(0x1)
	char pad_172_1 : 7;  // 0xAC(0x1)
	bool bSelectEdgeRings : 1;  // 0xAC(0x1)
	char pad_173_1 : 7;  // 0xAD(0x1)
	bool bHitBackFaces : 1;  // 0xAD(0x1)
	char pad_174_1 : 7;  // 0xAE(0x1)
	bool bEnableMarquee : 1;  // 0xAE(0x1)
	char pad_175_1 : 7;  // 0xAF(0x1)
	bool bMarqueeIgnoreOcclusion : 1;  // 0xAF(0x1)
	char pad_176_1 : 7;  // 0xB0(0x1)
	bool bPreferProjectedElement : 1;  // 0xB0(0x1)
	char pad_177_1 : 7;  // 0xB1(0x1)
	bool bSelectDownRay : 1;  // 0xB1(0x1)
	char pad_178_1 : 7;  // 0xB2(0x1)
	bool bIgnoreOcclusion : 1;  // 0xB2(0x1)
	char pad_179[13];  // 0xB3(0xD)

	void SelectAll(); // Function ModelingComponents.PolygonSelectionMechanicProperties.SelectAll
	void InvertSelection(); // Function ModelingComponents.PolygonSelectionMechanicProperties.InvertSelection
}; 



// Class ModelingComponents.MultiTransformer
// Size: 0x1B0(Inherited: 0x28) 
struct UMultiTransformer : public UObject
{
	char pad_40[96];  // 0x28(0x60)
	struct UInteractiveGizmoManager* GizmoManager;  // 0x88(0x8)
	char pad_144[112];  // 0x90(0x70)
	struct UCombinedTransformGizmo* TransformGizmo;  // 0x100(0x8)
	struct UTransformProxy* TransformProxy;  // 0x108(0x8)
	struct UDragAlignmentMechanic* DragAlignmentMechanic;  // 0x110(0x8)
	char pad_280[152];  // 0x118(0x98)

}; 



// Class ModelingComponents.ModelingSceneSnappingManager
// Size: 0x150(Inherited: 0x28) 
struct UModelingSceneSnappingManager : public USceneSnappingManager
{
	struct UInteractiveToolsContext* ParentContext;  // 0x28(0x8)
	char pad_48[288];  // 0x30(0x120)

}; 



