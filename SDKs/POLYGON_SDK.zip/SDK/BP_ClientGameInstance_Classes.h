#pragma once 
#include <BP_ClientGameInstance_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_ClientGameInstance.BP_ClientGameInstance_C
// Size: 0x88(Inherited: 0x88) 
struct UBP_ClientGameInstance_C : public UClientGameInstance
{

}; 



