#pragma once 
#include <MediaFrameworkUtilities_Structs.h>
 
 
 
// Class MediaFrameworkUtilities.MediaProfileSettings
// Size: 0x80(Inherited: 0x28) 
struct UMediaProfileSettings : public UObject
{
	char pad_40_1 : 7;  // 0x28(0x1)
	bool bApplyInCommandlet : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct TArray<struct TSoftObjectPtr<UProxyMediaSource>> MediaSourceProxy;  // 0x30(0x10)
	struct TArray<struct TSoftObjectPtr<UProxyMediaOutput>> MediaOutputProxy;  // 0x40(0x10)
	struct TSoftObjectPtr<UMediaProfile> StartupMediaProfile;  // 0x50(0x30)

}; 



// Class MediaFrameworkUtilities.MediaProfileBlueprintLibrary
// Size: 0x28(Inherited: 0x28) 
struct UMediaProfileBlueprintLibrary : public UBlueprintFunctionLibrary
{

	void SetMediaProfile(struct UMediaProfile* MediaProfile); // Function MediaFrameworkUtilities.MediaProfileBlueprintLibrary.SetMediaProfile
	struct UMediaProfile* GetMediaProfile(); // Function MediaFrameworkUtilities.MediaProfileBlueprintLibrary.GetMediaProfile
	struct TArray<struct UProxyMediaSource*> GetAllMediaSourceProxy(); // Function MediaFrameworkUtilities.MediaProfileBlueprintLibrary.GetAllMediaSourceProxy
	struct TArray<struct UProxyMediaOutput*> GetAllMediaOutputProxy(); // Function MediaFrameworkUtilities.MediaProfileBlueprintLibrary.GetAllMediaOutputProxy
}; 



// Class MediaFrameworkUtilities.MediaBundle
// Size: 0x118(Inherited: 0x28) 
struct UMediaBundle : public UObject
{
	struct UMediaSource* MediaSource;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool bLoopMediaSource : 1;  // 0x30(0x1)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool bReopenSourceOnError : 1;  // 0x31(0x1)
	char pad_50[6];  // 0x32(0x6)
	struct UMediaPlayer* MediaPlayer;  // 0x38(0x8)
	struct UMediaTexture* MediaTexture;  // 0x40(0x8)
	struct UMaterialInterface* Material;  // 0x48(0x8)
	struct FOpenCVLensDistortionParameters LensParameters;  // 0x50(0x48)
	struct FOpenCVCameraViewInfo UndistortedCameraViewInfo;  // 0x98(0xC)
	char pad_164[4];  // 0xA4(0x4)
	struct FOpenCVLensDistortionParameters CurrentLensParameters;  // 0xA8(0x48)
	struct UTextureRenderTarget2D* LensDisplacementMap;  // 0xF0(0x8)
	int32_t ReferenceCount;  // 0xF8(0x4)
	char pad_252[28];  // 0xFC(0x1C)

	void OnMediaOpenOpened(struct FString DeviceUrl); // Function MediaFrameworkUtilities.MediaBundle.OnMediaOpenOpened
	void OnMediaOpenFailed(struct FString DeviceUrl); // Function MediaFrameworkUtilities.MediaBundle.OnMediaOpenFailed
	void OnMediaClosed(); // Function MediaFrameworkUtilities.MediaBundle.OnMediaClosed
	struct FOpenCVCameraViewInfo GetUndistortedCameraViewInfo(); // Function MediaFrameworkUtilities.MediaBundle.GetUndistortedCameraViewInfo
	struct UMediaTexture* GetMediaTexture(); // Function MediaFrameworkUtilities.MediaBundle.GetMediaTexture
	struct UMediaSource* GetMediaSource(); // Function MediaFrameworkUtilities.MediaBundle.GetMediaSource
	struct UMediaPlayer* GetMediaPlayer(); // Function MediaFrameworkUtilities.MediaBundle.GetMediaPlayer
	struct UMaterialInterface* GetMaterial(); // Function MediaFrameworkUtilities.MediaBundle.GetMaterial
	struct UTextureRenderTarget2D* GetLensDisplacementTexture(); // Function MediaFrameworkUtilities.MediaBundle.GetLensDisplacementTexture
}; 



// Class MediaFrameworkUtilities.MediaBundleActorBase
// Size: 0x2D0(Inherited: 0x290) 
struct AMediaBundleActorBase : public AActor
{
	struct UTextureRenderTarget2D* GarbageMatteMask;  // 0x290(0x8)
	struct UMediaBundle* MediaBundle;  // 0x298(0x8)
	char pad_672_1 : 7;  // 0x2A0(0x1)
	bool bAutoPlay : 1;  // 0x2A0(0x1)
	char pad_673_1 : 7;  // 0x2A1(0x1)
	bool bPlayWhileEditing : 1;  // 0x2A1(0x1)
	char pad_674[6];  // 0x2A2(0x6)
	struct UPrimitiveComponent* PrimitiveCmp;  // 0x2A8(0x8)
	struct UMediaSoundComponent* MediaSoundCmp;  // 0x2B0(0x8)
	struct UMaterialInstanceDynamic* Material;  // 0x2B8(0x8)
	int32_t PrimitiveMaterialIndex;  // 0x2C0(0x4)
	char pad_708[12];  // 0x2C4(0xC)

	void SetComponent(struct UPrimitiveComponent* InPrimitive, struct UMediaSoundComponent* InMediaSound); // Function MediaFrameworkUtilities.MediaBundleActorBase.SetComponent
	bool RequestOpenMediaSource(); // Function MediaFrameworkUtilities.MediaBundleActorBase.RequestOpenMediaSource
	void RequestCloseMediaSource(); // Function MediaFrameworkUtilities.MediaBundleActorBase.RequestCloseMediaSource
	struct UMediaBundle* GetMediaBundle(); // Function MediaFrameworkUtilities.MediaBundleActorBase.GetMediaBundle
}; 



// Class MediaFrameworkUtilities.ProxyMediaOutput
// Size: 0x48(Inherited: 0x30) 
struct UProxyMediaOutput : public UMediaOutput
{
	struct UMediaOutput* DynamicProxy;  // 0x30(0x8)
	struct UMediaOutput* Proxy;  // 0x38(0x8)
	char pad_64[8];  // 0x40(0x8)

	bool IsProxyValid(); // Function MediaFrameworkUtilities.ProxyMediaOutput.IsProxyValid
}; 



// Class MediaFrameworkUtilities.MediaBundleTimeSynchronizationSource
// Size: 0x60(Inherited: 0x30) 
struct UMediaBundleTimeSynchronizationSource : public UTimeSynchronizationSource
{
	struct UMediaBundle* MediaBundle;  // 0x30(0x8)
	char pad_56[40];  // 0x38(0x28)

}; 



// Class MediaFrameworkUtilities.MediaPlayerTimeSynchronizationSource
// Size: 0x68(Inherited: 0x30) 
struct UMediaPlayerTimeSynchronizationSource : public UTimeSynchronizationSource
{
	struct UMediaSource* MediaSource;  // 0x30(0x8)
	struct UMediaTexture* MediaTexture;  // 0x38(0x8)
	char pad_64[40];  // 0x40(0x28)

}; 



// Class MediaFrameworkUtilities.MediaProfileEditorSettings
// Size: 0x28(Inherited: 0x28) 
struct UMediaProfileEditorSettings : public UObject
{

}; 



// Class MediaFrameworkUtilities.MediaProfile
// Size: 0x98(Inherited: 0x28) 
struct UMediaProfile : public UObject
{
	struct TArray<struct UMediaSource*> MediaSources;  // 0x28(0x10)
	struct TArray<struct UMediaOutput*> MediaOutputs;  // 0x38(0x10)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool bOverrideTimecodeProvider : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)
	struct UTimecodeProvider* TimecodeProvider;  // 0x50(0x8)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool bOverrideCustomTimeStep : 1;  // 0x58(0x1)
	char pad_89[7];  // 0x59(0x7)
	struct UEngineCustomTimeStep* CustomTimeStep;  // 0x60(0x8)
	char pad_104[8];  // 0x68(0x8)
	struct UTimecodeProvider* AppliedTimecodeProvider;  // 0x70(0x8)
	struct UTimecodeProvider* PreviousTimecodeProvider;  // 0x78(0x8)
	char pad_128[8];  // 0x80(0x8)
	struct UEngineCustomTimeStep* AppliedCustomTimeStep;  // 0x88(0x8)
	struct UEngineCustomTimeStep* PreviousCustomTimeStep;  // 0x90(0x8)

}; 



// Class MediaFrameworkUtilities.ProxyMediaSource
// Size: 0x98(Inherited: 0x80) 
struct UProxyMediaSource : public UMediaSource
{
	struct UMediaSource* DynamicProxy;  // 0x80(0x8)
	struct UMediaSource* Proxy;  // 0x88(0x8)
	char pad_144[8];  // 0x90(0x8)

	bool IsProxyValid(); // Function MediaFrameworkUtilities.ProxyMediaSource.IsProxyValid
}; 



