#pragma once 
#include "SDK.h" 
 
 
// Function OpenCVLensCalibration.OpenCVLensCalibrator.CalculateLensParameters
// Size: 0x60(Inherited: 0x0) 
struct FCalculateLensParameters
{
	struct FOpenCVLensDistortionParameters LensDistortionParameters;  // 0x0(0x48)
	float MarginOfError;  // 0x48(0x4)
	struct FOpenCVCameraViewInfo CameraViewInfo;  // 0x4C(0xC)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool ReturnValue : 1;  // 0x58(0x1)
	char pad_89[7];  // 0x59(0x7)

}; 
// Function OpenCVLensCalibration.OpenCVLensCalibrator.FeedImage
// Size: 0x18(Inherited: 0x0) 
struct FFeedImage
{
	struct FString FilePath;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function OpenCVLensCalibration.OpenCVLensCalibrator.CreateCalibrator
// Size: 0x18(Inherited: 0x0) 
struct FCreateCalibrator
{
	int32_t BoardWidth;  // 0x0(0x4)
	int32_t BoardHeight;  // 0x4(0x4)
	float SquareSize;  // 0x8(0x4)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool bUseFisheyeModel : 1;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)
	struct UOpenCVLensCalibrator* ReturnValue;  // 0x10(0x8)

}; 
// Function OpenCVLensCalibration.OpenCVLensCalibrator.FeedRenderTarget
// Size: 0x10(Inherited: 0x0) 
struct FFeedRenderTarget
{
	struct UTextureRenderTarget2D* TextureRenderTarget;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
