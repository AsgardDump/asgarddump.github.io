#pragma once 
#include <SignificanceManager_Structs.h>
 
 
 
// Class SignificanceManager.SignificanceManager
// Size: 0x140(Inherited: 0x28) 
struct USignificanceManager : public UObject
{
	char pad_40[248];  // 0x28(0xF8)
	struct FSoftClassPath SignificanceManagerClassName;  // 0x120(0x20)

}; 



