#pragma once 
#include <DefaultActionMapping_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass DefaultActionMapping.DefaultActionMapping_C
// Size: 0x2C0(Inherited: 0x2C0) 
struct UDefaultActionMapping_C : public UActionMapping
{

}; 



