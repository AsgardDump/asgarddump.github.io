#pragma once 
#include "SDK.h" 
 
 
// Function BP_HUDFunctionLibrary.BP_HUDFunctionLibrary_C.GetColorByID
// Size: 0x35(Inherited: 0x0) 
struct FGetColorByID
{
	struct FName RowName;  // 0x0(0x8)
	struct UObject* __WorldContext;  // 0x8(0x8)
	struct FLinearColor Color;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool Found : 1;  // 0x20(0x1)
	char pad_33[3];  // 0x21(0x3)
	struct FST_HUDColor CallFunc_GetDataTableRowFromName_OutRow;  // 0x24(0x10)
	char pad_52_1 : 7;  // 0x34(0x1)
	bool CallFunc_GetDataTableRowFromName_ReturnValue : 1;  // 0x34(0x1)

}; 
