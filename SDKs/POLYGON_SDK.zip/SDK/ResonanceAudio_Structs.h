#pragma once 
#include "SDK.h" 
 
 
// ScriptStruct ResonanceAudio.ResonanceAudioReverbPluginSettings
// Size: 0x70(Inherited: 0x0) 
struct FResonanceAudioReverbPluginSettings
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bEnableRoomEffects : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool bGetTransformFromAudioVolume : 1;  // 0x1(0x1)
	char pad_2[6];  // 0x2(0x6)
	struct FVector RoomPosition;  // 0x8(0x18)
	struct FQuat RoomRotation;  // 0x20(0x20)
	struct FVector RoomDimensions;  // 0x40(0x18)
	uint8_t  LeftWallMaterial;  // 0x58(0x1)
	uint8_t  RightWallMaterial;  // 0x59(0x1)
	uint8_t  FloorMaterial;  // 0x5A(0x1)
	uint8_t  CeilingMaterial;  // 0x5B(0x1)
	uint8_t  FrontWallMaterial;  // 0x5C(0x1)
	uint8_t  BackWallMaterial;  // 0x5D(0x1)
	char pad_94[2];  // 0x5E(0x2)
	float ReflectionScalar;  // 0x60(0x4)
	float ReverbGain;  // 0x64(0x4)
	float ReverbTimeModifier;  // 0x68(0x4)
	float ReverbBrightness;  // 0x6C(0x4)

}; 
// Function ResonanceAudio.ResonanceAudioReverbPluginPreset.SetReverbTimeModifier
// Size: 0x4(Inherited: 0x0) 
struct FSetReverbTimeModifier
{
	float InReverbTimeModifier;  // 0x0(0x4)

}; 
// Function ResonanceAudio.ResonanceAudioReverbPluginPreset.SetRoomPosition
// Size: 0x18(Inherited: 0x0) 
struct FSetRoomPosition
{
	struct FVector InPosition;  // 0x0(0x18)

}; 
// Function ResonanceAudio.ResonanceAudioBlueprintFunctionLibrary.GetGlobalReverbPreset
// Size: 0x8(Inherited: 0x0) 
struct FGetGlobalReverbPreset
{
	struct UResonanceAudioReverbPluginPreset* ReturnValue;  // 0x0(0x8)

}; 
// Function ResonanceAudio.ResonanceAudioReverbPluginPreset.SetEnableRoomEffects
// Size: 0x1(Inherited: 0x0) 
struct FSetEnableRoomEffects
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bInEnableRoomEffects : 1;  // 0x0(0x1)

}; 
// Function ResonanceAudio.ResonanceAudioBlueprintFunctionLibrary.SetGlobalReverbPreset
// Size: 0x8(Inherited: 0x0) 
struct FSetGlobalReverbPreset
{
	struct UResonanceAudioReverbPluginPreset* InPreset;  // 0x0(0x8)

}; 
// Function ResonanceAudio.ResonanceAudioReverbPluginPreset.SetReflectionScalar
// Size: 0x4(Inherited: 0x0) 
struct FSetReflectionScalar
{
	float InReflectionScalar;  // 0x0(0x4)

}; 
// Function ResonanceAudio.ResonanceAudioReverbPluginPreset.SetReverbBrightness
// Size: 0x4(Inherited: 0x0) 
struct FSetReverbBrightness
{
	float InReverbBrightness;  // 0x0(0x4)

}; 
// Function ResonanceAudio.ResonanceAudioReverbPluginPreset.SetReverbGain
// Size: 0x4(Inherited: 0x0) 
struct FSetReverbGain
{
	float InReverbGain;  // 0x0(0x4)

}; 
// Function ResonanceAudio.ResonanceAudioReverbPluginPreset.SetRoomDimensions
// Size: 0x18(Inherited: 0x0) 
struct FSetRoomDimensions
{
	struct FVector InDimensions;  // 0x0(0x18)

}; 
// Function ResonanceAudio.ResonanceAudioReverbPluginPreset.SetRoomMaterials
// Size: 0x10(Inherited: 0x0) 
struct FSetRoomMaterials
{
	struct TArray<uint8_t > InMaterials;  // 0x0(0x10)

}; 
// Function ResonanceAudio.ResonanceAudioReverbPluginPreset.SetRoomRotation
// Size: 0x20(Inherited: 0x0) 
struct FSetRoomRotation
{
	struct FQuat InRotation;  // 0x0(0x20)

}; 
// Function ResonanceAudio.ResonanceAudioSpatializationSourceSettings.SetSoundSourceDirectivity
// Size: 0x8(Inherited: 0x0) 
struct FSetSoundSourceDirectivity
{
	float InPattern;  // 0x0(0x4)
	float InSharpness;  // 0x4(0x4)

}; 
// Function ResonanceAudio.ResonanceAudioSpatializationSourceSettings.SetSoundSourceSpread
// Size: 0x4(Inherited: 0x0) 
struct FSetSoundSourceSpread
{
	float InSpread;  // 0x0(0x4)

}; 
