#pragma once 
#include <BI_OfferInteract_Structs.h>
 
 
 
// BlueprintGeneratedClass BI_OfferInteract.BI_OfferInteract_C
// Size: 0x28(Inherited: 0x28) 
struct UBI_OfferInteract_C : public UInterface
{

	void RemoveOffer(); // Function BI_OfferInteract.BI_OfferInteract_C.RemoveOffer
}; 



