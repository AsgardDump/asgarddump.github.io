#pragma once 
#include "SDK.h" 
 
 
// Function MediaIOCore.MediaCapture.CaptureTextureRenderTarget2D
// Size: 0x28(Inherited: 0x0) 
struct FCaptureTextureRenderTarget2D
{
	struct UTextureRenderTarget2D* RenderTarget;  // 0x0(0x8)
	struct FMediaCaptureOptions CaptureOptions;  // 0x8(0x18)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool ReturnValue : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// ScriptStruct MediaIOCore.MediaIOAutoDetectableTimecodeFormat_Backup
// Size: 0x8(Inherited: 0x0) 
struct FMediaIOAutoDetectableTimecodeFormat_Backup
{
	uint8_t  TimecodeFormat;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool bAutoDetect : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)

}; 
// ScriptStruct MediaIOCore.MediaCaptureOptions
// Size: 0x18(Inherited: 0x0) 
struct FMediaCaptureOptions
{
	uint8_t  OverrunAction;  // 0x0(0x1)
	uint8_t  Crop;  // 0x1(0x1)
	char pad_2[2];  // 0x2(0x2)
	struct FIntPoint CustomCapturePoint;  // 0x4(0x8)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool bResizeSourceBuffer : 1;  // 0xC(0x1)
	char pad_13_1 : 7;  // 0xD(0x1)
	bool bSkipFrameWhenRunningExpensiveTasks : 1;  // 0xD(0x1)
	char pad_14_1 : 7;  // 0xE(0x1)
	bool bConvertToDesiredPixelFormat : 1;  // 0xE(0x1)
	char pad_15_1 : 7;  // 0xF(0x1)
	bool bForceAlphaToOneOnConversion : 1;  // 0xF(0x1)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bApplyLinearToSRGBConversion : 1;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool bAutostopOnCapture : 1;  // 0x11(0x1)
	char pad_18[2];  // 0x12(0x2)
	int32_t NumberOfFramesToCapture;  // 0x14(0x4)

}; 
// ScriptStruct MediaIOCore.MediaIODevice
// Size: 0xC(Inherited: 0x0) 
struct FMediaIODevice
{
	struct FName DeviceName;  // 0x0(0x8)
	int32_t DeviceIdentifier;  // 0x8(0x4)

}; 
// Function MediaIOCore.MediaOutput.CreateMediaCapture
// Size: 0x8(Inherited: 0x0) 
struct FCreateMediaCapture
{
	struct UMediaCapture* ReturnValue;  // 0x0(0x8)

}; 
// ScriptStruct MediaIOCore.MediaIOConfiguration
// Size: 0x3C(Inherited: 0x0) 
struct FMediaIOConfiguration
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bIsInput : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	struct FMediaIOConnection MediaConnection;  // 0x4(0x20)
	struct FMediaIOMode MediaMode;  // 0x24(0x18)

}; 
// Function MediaIOCore.MediaOutput.Validate
// Size: 0x18(Inherited: 0x0) 
struct FValidate
{
	struct FString OutFailureReason;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// ScriptStruct MediaIOCore.MediaIOConnection
// Size: 0x20(Inherited: 0x0) 
struct FMediaIOConnection
{
	struct FMediaIODevice Device;  // 0x0(0xC)
	struct FName protocol;  // 0xC(0x8)
	uint8_t  TransportType;  // 0x14(0x4)
	uint8_t  QuadTransportType;  // 0x18(0x4)
	int32_t PortIdentifier;  // 0x1C(0x4)

}; 
// ScriptStruct MediaIOCore.MediaIOOutputConfiguration
// Size: 0x4C(Inherited: 0x0) 
struct FMediaIOOutputConfiguration
{
	struct FMediaIOConfiguration MediaConfiguration;  // 0x0(0x3C)
	uint8_t  OutputType;  // 0x3C(0x4)
	int32_t KeyPortIdentifier;  // 0x40(0x4)
	uint8_t  OutputReference;  // 0x44(0x4)
	int32_t ReferencePortIdentifier;  // 0x48(0x4)

}; 
// ScriptStruct MediaIOCore.MediaIOMode
// Size: 0x18(Inherited: 0x0) 
struct FMediaIOMode
{
	struct FFrameRate FrameRate;  // 0x0(0x8)
	struct FIntPoint Resolution;  // 0x8(0x8)
	uint8_t  Standard;  // 0x10(0x4)
	int32_t DeviceModeIdentifier;  // 0x14(0x4)

}; 
// ScriptStruct MediaIOCore.MediaIOInputConfiguration
// Size: 0x44(Inherited: 0x0) 
struct FMediaIOInputConfiguration
{
	struct FMediaIOConfiguration MediaConfiguration;  // 0x0(0x3C)
	uint8_t  InputType;  // 0x3C(0x4)
	int32_t KeyPortIdentifier;  // 0x40(0x4)

}; 
// ScriptStruct MediaIOCore.MediaIOVideoTimecodeConfiguration
// Size: 0x40(Inherited: 0x0) 
struct FMediaIOVideoTimecodeConfiguration
{
	struct FMediaIOConfiguration MediaConfiguration;  // 0x0(0x3C)
	uint8_t  TimecodeFormat;  // 0x3C(0x1)
	char pad_61[3];  // 0x3D(0x3)

}; 
// Function MediaIOCore.MediaCapture.CaptureActiveSceneViewport
// Size: 0x1C(Inherited: 0x0) 
struct FCaptureActiveSceneViewport
{
	struct FMediaCaptureOptions CaptureOptions;  // 0x0(0x18)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool ReturnValue : 1;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)

}; 
// Function MediaIOCore.MediaCapture.GetDesiredPixelFormat
// Size: 0x1(Inherited: 0x0) 
struct FGetDesiredPixelFormat
{
	char EPixelFormat ReturnValue;  // 0x0(0x1)

}; 
// Function MediaIOCore.MediaCapture.GetDesiredSize
// Size: 0x8(Inherited: 0x0) 
struct FGetDesiredSize
{
	struct FIntPoint ReturnValue;  // 0x0(0x8)

}; 
// Function MediaIOCore.MediaCapture.GetState
// Size: 0x1(Inherited: 0x0) 
struct FGetState
{
	uint8_t  ReturnValue;  // 0x0(0x1)

}; 
// Function MediaIOCore.MediaCapture.SetMediaOutput
// Size: 0x8(Inherited: 0x0) 
struct FSetMediaOutput
{
	struct UMediaOutput* InMediaOutput;  // 0x0(0x8)

}; 
// Function MediaIOCore.MediaCapture.StopCapture
// Size: 0x1(Inherited: 0x0) 
struct FStopCapture
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bAllowPendingFrameToBeProcess : 1;  // 0x0(0x1)

}; 
// Function MediaIOCore.MediaCapture.UpdateTextureRenderTarget2D
// Size: 0x10(Inherited: 0x0) 
struct FUpdateTextureRenderTarget2D
{
	struct UTextureRenderTarget2D* RenderTarget;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
