#pragma once 
#include <HairStrandsCore_Structs.h>
 
 
 
// Class HairStrandsCore.GroomBindingAssetList
// Size: 0x38(Inherited: 0x28) 
struct UGroomBindingAssetList : public UObject
{
	struct TArray<struct UGroomBindingAsset*> Bindings;  // 0x28(0x10)

}; 



// Class HairStrandsCore.GroomCacheImportOptions
// Size: 0x58(Inherited: 0x28) 
struct UGroomCacheImportOptions : public UObject
{
	struct FGroomCacheImportSettings ImportSettings;  // 0x28(0x30)

}; 



// Class HairStrandsCore.GroomBindingAsset
// Size: 0xB0(Inherited: 0x28) 
struct UGroomBindingAsset : public UObject
{
	uint8_t  GroomBindingType;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct UGroomAsset* Groom;  // 0x30(0x8)
	struct USkeletalMesh* SourceSkeletalMesh;  // 0x38(0x8)
	struct USkeletalMesh* TargetSkeletalMesh;  // 0x40(0x8)
	struct UGeometryCache* SourceGeometryCache;  // 0x48(0x8)
	struct UGeometryCache* TargetGeometryCache;  // 0x50(0x8)
	int32_t NumInterpolationPoints;  // 0x58(0x4)
	int32_t MatchingSection;  // 0x5C(0x4)
	struct TArray<struct FGoomBindingGroupInfo> GroupInfos;  // 0x60(0x10)
	char pad_112[64];  // 0x70(0x40)

}; 



// Class HairStrandsCore.HairCardGenerationSettings
// Size: 0x28(Inherited: 0x28) 
struct UHairCardGenerationSettings : public UObject
{

}; 



// Class HairStrandsCore.GroomCacheImportData
// Size: 0x58(Inherited: 0x28) 
struct UGroomCacheImportData : public UAssetImportData
{
	struct FGroomCacheImportSettings Settings;  // 0x28(0x30)

}; 



// Class HairStrandsCore.GroomAssetImportData
// Size: 0x30(Inherited: 0x28) 
struct UGroomAssetImportData : public UAssetImportData
{
	struct UGroomImportOptions* ImportOptions;  // 0x28(0x8)

}; 



// Class HairStrandsCore.GroomImportOptions
// Size: 0x68(Inherited: 0x28) 
struct UGroomImportOptions : public UObject
{
	struct FGroomConversionSettings ConversionSettings;  // 0x28(0x30)
	struct TArray<struct FHairGroupsInterpolation> InterpolationSettings;  // 0x58(0x10)

}; 



// Class HairStrandsCore.GroomBlueprintLibrary
// Size: 0x28(Inherited: 0x28) 
struct UGroomBlueprintLibrary : public UBlueprintFunctionLibrary
{

	struct UGroomBindingAsset* CreateNewGroomBindingAssetWithPath(struct FString InDesiredPackagePath, struct UGroomAsset* InGroomAsset, struct USkeletalMesh* InSkeletalMesh, int32_t InNumInterpolationPoints, struct USkeletalMesh* InSourceSkeletalMeshForTransfer, int32_t InMatchingSection); // Function HairStrandsCore.GroomBlueprintLibrary.CreateNewGroomBindingAssetWithPath
	struct UGroomBindingAsset* CreateNewGroomBindingAsset(struct UGroomAsset* InGroomAsset, struct USkeletalMesh* InSkeletalMesh, int32_t InNumInterpolationPoints, struct USkeletalMesh* InSourceSkeletalMeshForTransfer, int32_t InMatchingSection); // Function HairStrandsCore.GroomBlueprintLibrary.CreateNewGroomBindingAsset
	struct UGroomBindingAsset* CreateNewGeometryCacheGroomBindingAssetWithPath(struct FString DesiredPackagePath, struct UGroomAsset* GroomAsset, struct UGeometryCache* GeometryCache, int32_t NumInterpolationPoints, struct UGeometryCache* SourceGeometryCacheForTransfer, int32_t MatchingSection); // Function HairStrandsCore.GroomBlueprintLibrary.CreateNewGeometryCacheGroomBindingAssetWithPath
	struct UGroomBindingAsset* CreateNewGeometryCacheGroomBindingAsset(struct UGroomAsset* GroomAsset, struct UGeometryCache* GeometryCache, int32_t NumInterpolationPoints, struct UGeometryCache* SourceGeometryCacheForTransfer, int32_t MatchingSection); // Function HairStrandsCore.GroomBlueprintLibrary.CreateNewGeometryCacheGroomBindingAsset
}; 



// Class HairStrandsCore.GroomActor
// Size: 0x298(Inherited: 0x290) 
struct AGroomActor : public AActor
{
	struct UGroomComponent* GroomComponent;  // 0x290(0x8)

}; 



// Class HairStrandsCore.GroomAsset
// Size: 0x110(Inherited: 0x28) 
struct UGroomAsset : public UObject
{
	char pad_40[8];  // 0x28(0x8)
	struct TArray<struct FHairGroupInfoWithVisibility> HairGroupsInfo;  // 0x30(0x10)
	struct TArray<struct FHairGroupsRendering> HairGroupsRendering;  // 0x40(0x10)
	struct TArray<struct FHairGroupsPhysics> HairGroupsPhysics;  // 0x50(0x10)
	struct TArray<struct FHairGroupsInterpolation> HairGroupsInterpolation;  // 0x60(0x10)
	struct TArray<struct FHairGroupsLOD> HairGroupsLOD;  // 0x70(0x10)
	struct TArray<struct FHairGroupsCardsSourceDescription> HairGroupsCards;  // 0x80(0x10)
	struct TArray<struct FHairGroupsMeshesSourceDescription> HairGroupsMeshes;  // 0x90(0x10)
	struct TArray<struct FHairGroupsMaterial> HairGroupsMaterials;  // 0xA0(0x10)
	char pad_176[16];  // 0xB0(0x10)
	char pad_192_1 : 7;  // 0xC0(0x1)
	bool EnableGlobalInterpolation : 1;  // 0xC0(0x1)
	uint8_t  HairInterpolationType;  // 0xC1(0x1)
	char pad_194[6];  // 0xC2(0x6)
	struct USkeletalMesh* RiggedSkeletalMesh;  // 0xC8(0x8)
	struct TArray<int32_t> DeformedGroupSections;  // 0xD0(0x10)
	struct FPerPlatformInt MinLOD;  // 0xE0(0x4)
	struct FPerPlatformBool DisableBelowMinLodStripping;  // 0xE4(0x1)
	char pad_229[3];  // 0xE5(0x3)
	struct TArray<float> EffectiveLODBias;  // 0xE8(0x10)
	struct TArray<struct UAssetUserData*> AssetUserData;  // 0xF8(0x10)
	char pad_264[8];  // 0x108(0x8)

}; 



// Class HairStrandsCore.GroomCache
// Size: 0x78(Inherited: 0x28) 
struct UGroomCache : public UObject
{
	char pad_40[20];  // 0x28(0x14)
	struct FGroomCacheInfo GroomCacheInfo;  // 0x3C(0x28)
	char pad_100[20];  // 0x64(0x14)

}; 



// Class HairStrandsCore.GroomComponent
// Size: 0x7B0(Inherited: 0x570) 
struct UGroomComponent : public UMeshComponent
{
	char pad_1392[16];  // 0x570(0x10)
	struct UGroomAsset* GroomAsset;  // 0x580(0x8)
	struct UGroomCache* GroomCache;  // 0x588(0x8)
	struct TArray<struct UNiagaraComponent*> NiagaraComponents;  // 0x590(0x10)
	struct USkeletalMesh* SourceSkeletalMesh;  // 0x5A0(0x8)
	struct UGroomBindingAsset* BindingAsset;  // 0x5A8(0x8)
	struct UPhysicsAsset* PhysicsAsset;  // 0x5B0(0x8)
	char pad_1464[16];  // 0x5B8(0x10)
	struct FHairSimulationSettings SimulationSettings;  // 0x5C8(0x90)
	struct UMaterialInterface* Strands_DebugMaterial;  // 0x658(0x8)
	struct UMaterialInterface* Strands_DefaultMaterial;  // 0x660(0x8)
	struct UMaterialInterface* Cards_DefaultMaterial;  // 0x668(0x8)
	struct UMaterialInterface* Meshes_DefaultMaterial;  // 0x670(0x8)
	struct UNiagaraSystem* AngularSpringsSystem;  // 0x678(0x8)
	struct UNiagaraSystem* CosseratRodsSystem;  // 0x680(0x8)
	struct FString AttachmentName;  // 0x688(0x10)
	char pad_1688[136];  // 0x698(0x88)
	struct TArray<struct FHairGroupDesc> GroomGroupsDesc;  // 0x720(0x10)
	char pad_1840_1 : 7;  // 0x730(0x1)
	bool bUseCards : 1;  // 0x730(0x1)
	char pad_1841_1 : 7;  // 0x731(0x1)
	bool bRunning : 1;  // 0x731(0x1)
	char pad_1842_1 : 7;  // 0x732(0x1)
	bool bLooping : 1;  // 0x732(0x1)
	char pad_1843_1 : 7;  // 0x733(0x1)
	bool bManualTick : 1;  // 0x733(0x1)
	float ElapsedTime;  // 0x734(0x4)
	char pad_1848[120];  // 0x738(0x78)

	void SetPhysicsAsset(struct UPhysicsAsset* InPhysicsAsset); // Function HairStrandsCore.GroomComponent.SetPhysicsAsset
	void SetHairLengthScaleEnable(bool bEnable); // Function HairStrandsCore.GroomComponent.SetHairLengthScaleEnable
	void SetHairLengthScale(float Scale); // Function HairStrandsCore.GroomComponent.SetHairLengthScale
	void SetGroomAsset(struct UGroomAsset* Asset); // Function HairStrandsCore.GroomComponent.SetGroomAsset
	void SetEnableSimulation(bool bInEnableSimulation); // Function HairStrandsCore.GroomComponent.SetEnableSimulation
	void SetBindingAsset(struct UGroomBindingAsset* InBinding); // Function HairStrandsCore.GroomComponent.SetBindingAsset
	void ResetSimulation(); // Function HairStrandsCore.GroomComponent.ResetSimulation
	void ResetCollisionComponents(); // Function HairStrandsCore.GroomComponent.ResetCollisionComponents
	struct UNiagaraComponent* GetNiagaraComponent(int32_t GroupIndex); // Function HairStrandsCore.GroomComponent.GetNiagaraComponent
	bool GetIsHairLengthScaleEnabled(); // Function HairStrandsCore.GroomComponent.GetIsHairLengthScaleEnabled
	void AddCollisionComponent(struct USkeletalMeshComponent* SkeletalMeshComponent); // Function HairStrandsCore.GroomComponent.AddCollisionComponent
}; 



// Class HairStrandsCore.GroomCreateBindingOptions
// Size: 0x58(Inherited: 0x28) 
struct UGroomCreateBindingOptions : public UObject
{
	uint8_t  GroomBindingType;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct USkeletalMesh* SourceSkeletalMesh;  // 0x30(0x8)
	struct USkeletalMesh* TargetSkeletalMesh;  // 0x38(0x8)
	struct UGeometryCache* SourceGeometryCache;  // 0x40(0x8)
	struct UGeometryCache* TargetGeometryCache;  // 0x48(0x8)
	int32_t NumInterpolationPoints;  // 0x50(0x4)
	int32_t MatchingSection;  // 0x54(0x4)

}; 



// Class HairStrandsCore.GroomCreateFollicleMaskOptions
// Size: 0x40(Inherited: 0x28) 
struct UGroomCreateFollicleMaskOptions : public UObject
{
	int32_t Resolution;  // 0x28(0x4)
	int32_t RootRadius;  // 0x2C(0x4)
	struct TArray<struct FFollicleMaskOptions> Grooms;  // 0x30(0x10)

}; 



// Class HairStrandsCore.GroomCreateStrandsTexturesOptions
// Size: 0x68(Inherited: 0x28) 
struct UGroomCreateStrandsTexturesOptions : public UObject
{
	int32_t Resolution;  // 0x28(0x4)
	uint8_t  TraceType;  // 0x2C(0x1)
	char pad_45[3];  // 0x2D(0x3)
	float TraceDistance;  // 0x30(0x4)
	uint8_t  MeshType;  // 0x34(0x1)
	char pad_53[3];  // 0x35(0x3)
	struct UStaticMesh* StaticMesh;  // 0x38(0x8)
	struct USkeletalMesh* SkeletalMesh;  // 0x40(0x8)
	int32_t LODIndex;  // 0x48(0x4)
	int32_t SectionIndex;  // 0x4C(0x4)
	int32_t UVChannelIndex;  // 0x50(0x4)
	char pad_84[4];  // 0x54(0x4)
	struct TArray<int32_t> GroupIndex;  // 0x58(0x10)

}; 



// Class HairStrandsCore.GroomHairGroupsPreview
// Size: 0x38(Inherited: 0x28) 
struct UGroomHairGroupsPreview : public UObject
{
	struct TArray<struct FGroomHairGroupPreview> Groups;  // 0x28(0x10)

}; 



// Class HairStrandsCore.GroomPluginSettings
// Size: 0x30(Inherited: 0x28) 
struct UGroomPluginSettings : public UObject
{
	float GroomCacheLookAheadBuffer;  // 0x28(0x4)
	char pad_44[4];  // 0x2C(0x4)

}; 



// Class HairStrandsCore.MovieSceneGroomCacheSection
// Size: 0x110(Inherited: 0xF0) 
struct UMovieSceneGroomCacheSection : public UMovieSceneSection
{
	struct FMovieSceneGroomCacheParams Params;  // 0xF0(0x20)

}; 



// Class HairStrandsCore.MovieSceneGroomCacheTrack
// Size: 0xB0(Inherited: 0x98) 
struct UMovieSceneGroomCacheTrack : public UMovieSceneNameableTrack
{
	char pad_152[8];  // 0x98(0x8)
	struct TArray<struct UMovieSceneSection*> AnimationSections;  // 0xA0(0x10)

}; 



// Class HairStrandsCore.NiagaraDataInterfaceHairStrands
// Size: 0x50(Inherited: 0x38) 
struct UNiagaraDataInterfaceHairStrands : public UNiagaraDataInterface
{
	struct UGroomAsset* DefaultSource;  // 0x38(0x8)
	struct AActor* SourceActor;  // 0x40(0x8)
	char pad_72[8];  // 0x48(0x8)

}; 



// Class HairStrandsCore.NiagaraDataInterfaceVelocityGrid
// Size: 0x48(Inherited: 0x38) 
struct UNiagaraDataInterfaceVelocityGrid : public UNiagaraDataInterfaceRWBase
{
	struct FIntVector GridSize;  // 0x38(0xC)
	char pad_68[4];  // 0x44(0x4)

}; 



// Class HairStrandsCore.NiagaraDataInterfacePressureGrid
// Size: 0x48(Inherited: 0x48) 
struct UNiagaraDataInterfacePressureGrid : public UNiagaraDataInterfaceVelocityGrid
{

}; 



