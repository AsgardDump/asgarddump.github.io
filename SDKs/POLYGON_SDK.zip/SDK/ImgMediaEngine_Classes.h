#pragma once 
#include <ImgMediaEngine_Structs.h>
 
 
 
// Class ImgMediaEngine.ImgMediaPlaybackComponent
// Size: 0xC8(Inherited: 0xA0) 
struct UImgMediaPlaybackComponent : public UActorComponent
{
	float LODBias;  // 0xA0(0x4)
	char pad_164[36];  // 0xA4(0x24)

}; 



