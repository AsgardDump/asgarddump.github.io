#pragma once 
#include "SDK.h" 
 
 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.LessByteFloat
// Size: 0x18(Inherited: 0x0) 
struct FLessByteFloat
{
	char A;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	double B;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.HashcashCustomCreationDate
// Size: 0x30(Inherited: 0x0) 
struct FHashcashCustomCreationDate
{
	struct FString Resource;  // 0x0(0x10)
	struct FDateTime UtcDate;  // 0x10(0x8)
	int32_t Bits;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct FString ReturnValue;  // 0x20(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryByteDataReader.SetPosition
// Size: 0x4(Inherited: 0x0) 
struct FSetPosition
{
	int32_t Position_;  // 0x0(0x4)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryByteDataReader.GetPositiveInteger3Array
// Size: 0x10(Inherited: 0x0) 
struct FGetPositiveInteger3Array
{
	struct TArray<int32_t> ReturnValue;  // 0x0(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryBitDataReader.GetByteArrayMostSignificantBits
// Size: 0x18(Inherited: 0x0) 
struct FGetByteArrayMostSignificantBits
{
	int32_t BitCount;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct TArray<char> ReturnValue;  // 0x8(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.SortByteArray
// Size: 0x28(Inherited: 0x0) 
struct FSortByteArray
{
	struct TArray<char> ByteArray;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool Reversed : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct TArray<char> ReturnValue;  // 0x18(0x10)

}; 
// DelegateFunction LowEntryExtendedStandardLibrary.DelegateULowEntryExtendedStandardLibraryCompareObjects__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FDelegateULowEntryExtendedStandardLibraryCompareObjects__DelegateSignature
{
	struct UObject* ObjectA;  // 0x0(0x8)
	struct UObject* ObjectB;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool Result : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// ScriptStruct LowEntryExtendedStandardLibrary.LowEntryRegexMatch
// Size: 0x30(Inherited: 0x0) 
struct FLowEntryRegexMatch
{
	int32_t MatchNumber;  // 0x0(0x4)
	int32_t BeginIndex;  // 0x4(0x4)
	int32_t EndIndex;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct FString Match;  // 0x10(0x10)
	struct TArray<struct FLowEntryRegexCaptureGroup> CaptureGroups;  // 0x20(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryLong.LongBytes_Subtract
// Size: 0x8(Inherited: 0x0) 
struct FLongBytes_Subtract
{
	struct ULowEntryLong* Value;  // 0x0(0x8)

}; 
// ScriptStruct LowEntryExtendedStandardLibrary.LowEntryRegexCaptureGroup
// Size: 0x20(Inherited: 0x0) 
struct FLowEntryRegexCaptureGroup
{
	int32_t CaptureGroupNumber;  // 0x0(0x4)
	int32_t BeginIndex;  // 0x4(0x4)
	int32_t EndIndex;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct FString Match;  // 0x10(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.SortByteArrayDirectly
// Size: 0x18(Inherited: 0x0) 
struct FSortByteArrayDirectly
{
	struct TArray<char> ByteArray;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool Reversed : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.ByteToBoolean
// Size: 0x2(Inherited: 0x0) 
struct FByteToBoolean
{
	char Byte;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool ReturnValue : 1;  // 0x1(0x1)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.ByteDataWriter_GetBytes
// Size: 0x18(Inherited: 0x0) 
struct FByteDataWriter_GetBytes
{
	struct ULowEntryByteDataWriter* ByteDataWriter;  // 0x0(0x8)
	struct TArray<char> ReturnValue;  // 0x8(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryByteDataReader.GetLongArray
// Size: 0x10(Inherited: 0x0) 
struct FGetLongArray
{
	struct TArray<int64_t> ReturnValue;  // 0x0(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryBitDataReader.GetBit
// Size: 0x1(Inherited: 0x0) 
struct FGetBit
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GreaterByteInteger
// Size: 0xC(Inherited: 0x0) 
struct FGreaterByteInteger
{
	char A;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	int32_t B;  // 0x4(0x4)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryByteDataReader.GetPositiveInteger3
// Size: 0x4(Inherited: 0x0) 
struct FGetPositiveInteger3
{
	int32_t ReturnValue;  // 0x0(0x4)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryBitDataReader.GetBitArray
// Size: 0x10(Inherited: 0x0) 
struct FGetBitArray
{
	struct TArray<bool> ReturnValue;  // 0x0(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.ByteDataEntry_CreateFromFloatArray
// Size: 0x18(Inherited: 0x0) 
struct FByteDataEntry_CreateFromFloatArray
{
	struct TArray<float> Value;  // 0x0(0x10)
	struct ULowEntryByteDataEntry* ReturnValue;  // 0x10(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryByteDataReader.GetBoolean
// Size: 0x1(Inherited: 0x0) 
struct FGetBoolean
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryLong.Integer_Add
// Size: 0x4(Inherited: 0x0) 
struct FInteger_Add
{
	int32_t Value;  // 0x0(0x4)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryByteDataReader.GetByte
// Size: 0x1(Inherited: 0x0) 
struct FGetByte
{
	char ReturnValue;  // 0x0(0x1)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryByteDataReader.GetByteArray
// Size: 0x10(Inherited: 0x0) 
struct FGetByteArray
{
	struct TArray<char> ReturnValue;  // 0x0(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryLong.LongBytes_Add
// Size: 0x8(Inherited: 0x0) 
struct FLongBytes_Add
{
	struct ULowEntryLong* Value;  // 0x0(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryByteDataReader.GetBooleanArray
// Size: 0x10(Inherited: 0x0) 
struct FGetBooleanArray
{
	struct TArray<bool> ReturnValue;  // 0x0(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryBitDataReader.GetByteArrayLeastSignificantBits
// Size: 0x18(Inherited: 0x0) 
struct FGetByteArrayLeastSignificantBits
{
	int32_t BitCount;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct TArray<char> ReturnValue;  // 0x8(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryBitDataReader.GetByteLeastSignificantBits
// Size: 0x8(Inherited: 0x0) 
struct FGetByteLeastSignificantBits
{
	int32_t BitCount;  // 0x0(0x4)
	char ReturnValue;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryByteDataReader.GetPositiveInteger2Array
// Size: 0x10(Inherited: 0x0) 
struct FGetPositiveInteger2Array
{
	struct TArray<int32_t> ReturnValue;  // 0x0(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryByteDataReader.GetDoubleBytes
// Size: 0x8(Inherited: 0x0) 
struct FGetDoubleBytes
{
	struct ULowEntryDouble* ReturnValue;  // 0x0(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryBitDataReader.GetByteMostSignificantBits
// Size: 0x8(Inherited: 0x0) 
struct FGetByteMostSignificantBits
{
	int32_t BitCount;  // 0x0(0x4)
	char ReturnValue;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.MergeEncapsulatedByteArrays
// Size: 0x20(Inherited: 0x0) 
struct FMergeEncapsulatedByteArrays
{
	struct TArray<struct ULowEntryByteArray*> ByteArrays;  // 0x0(0x10)
	struct TArray<char> ReturnValue;  // 0x10(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryByteDataReader.GetClone
// Size: 0x8(Inherited: 0x0) 
struct FGetClone
{
	struct ULowEntryByteDataReader* ReturnValue;  // 0x0(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryByteDataReader.GetIntegerArray
// Size: 0x10(Inherited: 0x0) 
struct FGetIntegerArray
{
	struct TArray<int32_t> ReturnValue;  // 0x0(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryDouble.GetDouble
// Size: 0x8(Inherited: 0x0) 
struct FGetDouble
{
	double ReturnValue;  // 0x0(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BitDataEntry_CreateFromByteMostSignificantBits
// Size: 0x10(Inherited: 0x0) 
struct FBitDataEntry_CreateFromByteMostSignificantBits
{
	char Value;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	int32_t BitCount;  // 0x4(0x4)
	struct ULowEntryBitDataEntry* ReturnValue;  // 0x8(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryByteDataReader.GetFloat
// Size: 0x4(Inherited: 0x0) 
struct FGetFloat
{
	float ReturnValue;  // 0x0(0x4)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GetWindowPositiomInPercentagesCentered
// Size: 0x18(Inherited: 0x0) 
struct FGetWindowPositiomInPercentagesCentered
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Success : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	double X;  // 0x8(0x8)
	double Y;  // 0x10(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryByteDataReader.GetDoubleArray
// Size: 0x10(Inherited: 0x0) 
struct FGetDoubleArray
{
	struct TArray<double> ReturnValue;  // 0x0(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryByteDataReader.GetDoubleBytesArray
// Size: 0x10(Inherited: 0x0) 
struct FGetDoubleBytesArray
{
	struct TArray<struct ULowEntryDouble*> ReturnValue;  // 0x0(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryBitDataReader.GetIntegerArrayMostSignificantBits
// Size: 0x18(Inherited: 0x0) 
struct FGetIntegerArrayMostSignificantBits
{
	int32_t BitCount;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct TArray<int32_t> ReturnValue;  // 0x8(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryByteDataWriter.AddDoubleBytes
// Size: 0x8(Inherited: 0x0) 
struct FAddDoubleBytes
{
	struct ULowEntryDouble* Value;  // 0x0(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.LessIntegerByte
// Size: 0x8(Inherited: 0x0) 
struct FLessIntegerByte
{
	int32_t A;  // 0x0(0x4)
	char B;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool ReturnValue : 1;  // 0x5(0x1)
	char pad_6[2];  // 0x6(0x2)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryBitDataReader.GetIntegerArrayLeastSignificantBits
// Size: 0x18(Inherited: 0x0) 
struct FGetIntegerArrayLeastSignificantBits
{
	int32_t BitCount;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct TArray<int32_t> ReturnValue;  // 0x8(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.SceneCaptureComponent2DToBytes
// Size: 0x28(Inherited: 0x0) 
struct FSceneCaptureComponent2DToBytes
{
	struct USceneCaptureComponent2D* SceneCaptureComponent2D;  // 0x0(0x8)
	uint8_t  ImageFormat;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct TArray<char> ByteArray;  // 0x10(0x10)
	int32_t CompressionQuality;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryByteDataReader.GetFloatArray
// Size: 0x10(Inherited: 0x0) 
struct FGetFloatArray
{
	struct TArray<float> ReturnValue;  // 0x0(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryBitDataWriter.AddIntegerArrayMostSignificantBits
// Size: 0x18(Inherited: 0x0) 
struct FAddIntegerArrayMostSignificantBits
{
	struct TArray<int32_t> Value;  // 0x0(0x10)
	int32_t BitCount;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryByteDataWriter.AddIntegerArray
// Size: 0x10(Inherited: 0x0) 
struct FAddIntegerArray
{
	struct TArray<int32_t> Value;  // 0x0(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GreaterEqualFloatInteger
// Size: 0x10(Inherited: 0x0) 
struct FGreaterEqualFloatInteger
{
	double A;  // 0x0(0x8)
	int32_t B;  // 0x8(0x4)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool ReturnValue : 1;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryBitDataWriter.AddByteArrayMostSignificantBits
// Size: 0x18(Inherited: 0x0) 
struct FAddByteArrayMostSignificantBits
{
	struct TArray<char> Value;  // 0x0(0x10)
	int32_t BitCount;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryByteDataWriter.AddByteArray
// Size: 0x10(Inherited: 0x0) 
struct FAddByteArray
{
	struct TArray<char> Value;  // 0x0(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryByteDataReader.GetInteger
// Size: 0x4(Inherited: 0x0) 
struct FGetInteger
{
	int32_t ReturnValue;  // 0x0(0x4)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryBitDataReader.GetIntegerMostSignificantBits
// Size: 0x8(Inherited: 0x0) 
struct FGetIntegerMostSignificantBits
{
	int32_t BitCount;  // 0x0(0x4)
	int32_t ReturnValue;  // 0x4(0x4)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryBitDataWriter.AddIntegerArrayLeastSignificantBits
// Size: 0x18(Inherited: 0x0) 
struct FAddIntegerArrayLeastSignificantBits
{
	struct TArray<int32_t> Value;  // 0x0(0x10)
	int32_t BitCount;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryLatentActionString.WaitTillDone
// Size: 0x30(Inherited: 0x0) 
struct FWaitTillDone
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct FLatentActionInfo LatentInfo;  // 0x8(0x18)
	struct FString Result_;  // 0x20(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.SetMousePositionInPercentages
// Size: 0x10(Inherited: 0x0) 
struct FSetMousePositionInPercentages
{
	double X;  // 0x0(0x8)
	double Y;  // 0x8(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryBitDataWriter.AddByteArrayLeastSignificantBits
// Size: 0x18(Inherited: 0x0) 
struct FAddByteArrayLeastSignificantBits
{
	struct TArray<char> Value;  // 0x0(0x10)
	int32_t BitCount;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryBitDataReader.GetIntegerLeastSignificantBits
// Size: 0x8(Inherited: 0x0) 
struct FGetIntegerLeastSignificantBits
{
	int32_t BitCount;  // 0x0(0x4)
	int32_t ReturnValue;  // 0x4(0x4)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryLong.GetLong
// Size: 0x8(Inherited: 0x0) 
struct FGetLong
{
	int64_t ReturnValue;  // 0x0(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryByteDataReader.GetLongBytes
// Size: 0x8(Inherited: 0x0) 
struct FGetLongBytes
{
	struct ULowEntryLong* ReturnValue;  // 0x0(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryByteDataReader.GetLongBytesArray
// Size: 0x10(Inherited: 0x0) 
struct FGetLongBytesArray
{
	struct TArray<struct ULowEntryLong*> ReturnValue;  // 0x0(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryByteDataReader.GetPosition
// Size: 0x4(Inherited: 0x0) 
struct FGetPosition
{
	int32_t ReturnValue;  // 0x0(0x4)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryByteDataReader.GetPositiveInteger1
// Size: 0x4(Inherited: 0x0) 
struct FGetPositiveInteger1
{
	int32_t ReturnValue;  // 0x0(0x4)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.SortIntegerArray
// Size: 0x28(Inherited: 0x0) 
struct FSortIntegerArray
{
	struct TArray<int32_t> IntegerArray;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool Reversed : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct TArray<int32_t> ReturnValue;  // 0x18(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GetCurrentVolumePercentage
// Size: 0x10(Inherited: 0x0) 
struct FGetCurrentVolumePercentage
{
	double Percentage;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Success : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GetAndroidOsLanguage
// Size: 0x10(Inherited: 0x0) 
struct FGetAndroidOsLanguage
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.ByteDataEntry_CreateFromDoubleBytes
// Size: 0x10(Inherited: 0x0) 
struct FByteDataEntry_CreateFromDoubleBytes
{
	struct ULowEntryDouble* Value;  // 0x0(0x8)
	struct ULowEntryByteDataEntry* ReturnValue;  // 0x8(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryByteDataReader.GetPositiveInteger1Array
// Size: 0x10(Inherited: 0x0) 
struct FGetPositiveInteger1Array
{
	struct TArray<int32_t> ReturnValue;  // 0x0(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BitDataReader_Create
// Size: 0x20(Inherited: 0x0) 
struct FBitDataReader_Create
{
	struct TArray<char> Bytes;  // 0x0(0x10)
	int32_t Index;  // 0x10(0x4)
	int32_t Length;  // 0x14(0x4)
	struct ULowEntryBitDataReader* ReturnValue;  // 0x18(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryByteDataReader.GetPositiveInteger2
// Size: 0x4(Inherited: 0x0) 
struct FGetPositiveInteger2
{
	int32_t ReturnValue;  // 0x0(0x4)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryByteDataReader.GetStringUtf8
// Size: 0x10(Inherited: 0x0) 
struct FGetStringUtf8
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryBitDataWriter.AddIntegerLeastSignificantBits
// Size: 0x8(Inherited: 0x0) 
struct FAddIntegerLeastSignificantBits
{
	int32_t Value;  // 0x0(0x4)
	int32_t BitCount;  // 0x4(0x4)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.SceneCaptureComponent2D_GetFov
// Size: 0x10(Inherited: 0x0) 
struct FSceneCaptureComponent2D_GetFov
{
	struct USceneCaptureComponent2D* SceneCaptureComponent2D;  // 0x0(0x8)
	double FOV;  // 0x8(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GetWindowSize
// Size: 0xC(Inherited: 0x0) 
struct FGetWindowSize
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Success : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	int32_t Width;  // 0x4(0x4)
	int32_t Height;  // 0x8(0x4)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryBitDataWriter.AddByteLeastSignificantBits
// Size: 0x8(Inherited: 0x0) 
struct FAddByteLeastSignificantBits
{
	char Value;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	int32_t BitCount;  // 0x4(0x4)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryByteDataReader.GetStringUtf8Array
// Size: 0x10(Inherited: 0x0) 
struct FGetStringUtf8Array
{
	struct TArray<struct FString> ReturnValue;  // 0x0(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BytesToBase64Url
// Size: 0x28(Inherited: 0x0) 
struct FBytesToBase64Url
{
	struct TArray<char> ByteArray;  // 0x0(0x10)
	int32_t Index;  // 0x10(0x4)
	int32_t Length;  // 0x14(0x4)
	struct FString ReturnValue;  // 0x18(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryByteDataReader.Remaining
// Size: 0x4(Inherited: 0x0) 
struct FRemaining
{
	int32_t ReturnValue;  // 0x0(0x4)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.SortStringArrayDirectly
// Size: 0x18(Inherited: 0x0) 
struct FSortStringArrayDirectly
{
	struct TArray<struct FString> StringArray;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool Reversed : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryBitDataWriter.AddBit
// Size: 0x1(Inherited: 0x0) 
struct FAddBit
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Value : 1;  // 0x0(0x1)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryBitDataWriter.AddBitArray
// Size: 0x10(Inherited: 0x0) 
struct FAddBitArray
{
	struct TArray<bool> Value;  // 0x0(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryByteDataWriter.AddBoolean
// Size: 0x1(Inherited: 0x0) 
struct FAddBoolean
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Value : 1;  // 0x0(0x1)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryByteDataWriter.AddBooleanArray
// Size: 0x10(Inherited: 0x0) 
struct FAddBooleanArray
{
	struct TArray<bool> Value;  // 0x0(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryByteDataWriter.AddInteger
// Size: 0x4(Inherited: 0x0) 
struct FAddInteger
{
	int32_t Value;  // 0x0(0x4)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryLong.LongBytes_Equals
// Size: 0x10(Inherited: 0x0) 
struct FLongBytes_Equals
{
	struct ULowEntryLong* Value;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryByteDataWriter.AddByte
// Size: 0x1(Inherited: 0x0) 
struct FAddByte
{
	char Value;  // 0x0(0x1)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryBitDataWriter.AddIntegerMostSignificantBits
// Size: 0x8(Inherited: 0x0) 
struct FAddIntegerMostSignificantBits
{
	int32_t Value;  // 0x0(0x4)
	int32_t BitCount;  // 0x4(0x4)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryBitDataWriter.AddByteMostSignificantBits
// Size: 0x8(Inherited: 0x0) 
struct FAddByteMostSignificantBits
{
	char Value;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	int32_t BitCount;  // 0x4(0x4)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryByteDataWriter.AddDouble
// Size: 0x8(Inherited: 0x0) 
struct FAddDouble
{
	double Value;  // 0x0(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryByteDataWriter.AddDoubleArray
// Size: 0x10(Inherited: 0x0) 
struct FAddDoubleArray
{
	struct TArray<double> Value;  // 0x0(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BytesToFloat
// Size: 0x20(Inherited: 0x0) 
struct FBytesToFloat
{
	struct TArray<char> ByteArray;  // 0x0(0x10)
	int32_t Index;  // 0x10(0x4)
	int32_t Length;  // 0x14(0x4)
	float ReturnValue;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryByteDataWriter.AddDoubleBytesArray
// Size: 0x10(Inherited: 0x0) 
struct FAddDoubleBytesArray
{
	struct TArray<struct ULowEntryDouble*> Value;  // 0x0(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.SplitBytes
// Size: 0x38(Inherited: 0x0) 
struct FSplitBytes
{
	struct TArray<char> ByteArray;  // 0x0(0x10)
	int32_t LengthA;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct TArray<char> A;  // 0x18(0x10)
	struct TArray<char> B;  // 0x28(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryByteDataWriter.AddFloat
// Size: 0x4(Inherited: 0x0) 
struct FAddFloat
{
	float Value;  // 0x0(0x4)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryByteDataWriter.AddFloatArray
// Size: 0x10(Inherited: 0x0) 
struct FAddFloatArray
{
	struct TArray<float> Value;  // 0x0(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryByteDataWriter.AddLong
// Size: 0x8(Inherited: 0x0) 
struct FAddLong
{
	int64_t Value;  // 0x0(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.ParsedHashcashIsValid
// Size: 0x10(Inherited: 0x0) 
struct FParsedHashcashIsValid
{
	struct ULowEntryParsedHashcash* Target;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryByteDataWriter.AddLongArray
// Size: 0x10(Inherited: 0x0) 
struct FAddLongArray
{
	struct TArray<int64_t> Value;  // 0x0(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryLatentActionString.Done
// Size: 0x10(Inherited: 0x0) 
struct FDone
{
	struct FString Result_;  // 0x0(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryByteDataWriter.AddLongBytes
// Size: 0x8(Inherited: 0x0) 
struct FAddLongBytes
{
	struct ULowEntryLong* Value;  // 0x0(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryByteDataWriter.AddLongBytesArray
// Size: 0x10(Inherited: 0x0) 
struct FAddLongBytesArray
{
	struct TArray<struct ULowEntryLong*> Value;  // 0x0(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryByteDataWriter.AddPositiveInteger1
// Size: 0x4(Inherited: 0x0) 
struct FAddPositiveInteger1
{
	int32_t Value;  // 0x0(0x4)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryByteDataWriter.AddPositiveInteger1Array
// Size: 0x10(Inherited: 0x0) 
struct FAddPositiveInteger1Array
{
	struct TArray<int32_t> Value;  // 0x0(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.IntegerToBytes
// Size: 0x18(Inherited: 0x0) 
struct FIntegerToBytes
{
	int32_t Value;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct TArray<char> ReturnValue;  // 0x8(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.CaseSwitchByte
// Size: 0x10(Inherited: 0x0) 
struct FCaseSwitchByte
{
	int32_t OnlyCheckFirstX;  // 0x0(0x4)
	char Value;  // 0x4(0x1)
	char _1__;  // 0x5(0x1)
	char _2__;  // 0x6(0x1)
	char _3__;  // 0x7(0x1)
	char _4__;  // 0x8(0x1)
	char _5__;  // 0x9(0x1)
	char _6__;  // 0xA(0x1)
	char _7__;  // 0xB(0x1)
	char _8__;  // 0xC(0x1)
	char _9__;  // 0xD(0x1)
	char _10__;  // 0xE(0x1)
	uint8_t  Branch;  // 0xF(0x1)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryByteDataWriter.AddPositiveInteger2
// Size: 0x4(Inherited: 0x0) 
struct FAddPositiveInteger2
{
	int32_t Value;  // 0x0(0x4)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryByteDataWriter.AddPositiveInteger2Array
// Size: 0x10(Inherited: 0x0) 
struct FAddPositiveInteger2Array
{
	struct TArray<int32_t> Value;  // 0x0(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryByteDataWriter.AddPositiveInteger3
// Size: 0x4(Inherited: 0x0) 
struct FAddPositiveInteger3
{
	int32_t Value;  // 0x0(0x4)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryByteDataWriter.AddPositiveInteger3Array
// Size: 0x10(Inherited: 0x0) 
struct FAddPositiveInteger3Array
{
	struct TArray<int32_t> Value;  // 0x0(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryByteDataWriter.AddStringUtf8
// Size: 0x10(Inherited: 0x0) 
struct FAddStringUtf8
{
	struct FString Value;  // 0x0(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryByteDataWriter.AddStringUtf8Array
// Size: 0x10(Inherited: 0x0) 
struct FAddStringUtf8Array
{
	struct TArray<struct FString> Value;  // 0x0(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.SortIntegerArrayDirectly
// Size: 0x18(Inherited: 0x0) 
struct FSortIntegerArrayDirectly
{
	struct TArray<int32_t> IntegerArray;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool Reversed : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GetAbsoluteToLocalScale
// Size: 0x50(Inherited: 0x0) 
struct FGetAbsoluteToLocalScale
{
	struct FGeometry Geometry;  // 0x0(0x40)
	struct FVector2D ReturnValue;  // 0x40(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.AreBytesEqual
// Size: 0x38(Inherited: 0x0) 
struct FAreBytesEqual
{
	struct TArray<char> A;  // 0x0(0x10)
	struct TArray<char> B;  // 0x10(0x10)
	int32_t IndexA;  // 0x20(0x4)
	int32_t LengthA;  // 0x24(0x4)
	int32_t IndexB;  // 0x28(0x4)
	int32_t LengthB;  // 0x2C(0x4)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool ReturnValue : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryDouble.CastToLongBytes
// Size: 0x8(Inherited: 0x0) 
struct FCastToLongBytes
{
	struct ULowEntryLong* ReturnValue;  // 0x0(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryLong.CastToString
// Size: 0x10(Inherited: 0x0) 
struct FCastToString
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.Long_CreateZero
// Size: 0x8(Inherited: 0x0) 
struct FLong_CreateZero
{
	struct ULowEntryLong* ReturnValue;  // 0x0(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BitsToByte
// Size: 0x9(Inherited: 0x0) 
struct FBitsToByte
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Bit1 : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool Bit2 : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool Bit3 : 1;  // 0x2(0x1)
	char pad_3_1 : 7;  // 0x3(0x1)
	bool Bit4 : 1;  // 0x3(0x1)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Bit5 : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool Bit6 : 1;  // 0x5(0x1)
	char pad_6_1 : 7;  // 0x6(0x1)
	bool Bit7 : 1;  // 0x6(0x1)
	char pad_7_1 : 7;  // 0x7(0x1)
	bool Bit8 : 1;  // 0x7(0x1)
	char Byte;  // 0x8(0x1)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryLong.CreateClone
// Size: 0x8(Inherited: 0x0) 
struct FCreateClone
{
	struct ULowEntryLong* ReturnValue;  // 0x0(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryDouble.DoubleBytes_Add
// Size: 0x8(Inherited: 0x0) 
struct FDoubleBytes_Add
{
	struct ULowEntryDouble* Value;  // 0x0(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryDouble.DoubleBytes_Equals
// Size: 0x10(Inherited: 0x0) 
struct FDoubleBytes_Equals
{
	struct ULowEntryDouble* Value;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.SortStringArray
// Size: 0x28(Inherited: 0x0) 
struct FSortStringArray
{
	struct TArray<struct FString> StringArray;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool Reversed : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct TArray<struct FString> ReturnValue;  // 0x18(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryLong.DoubleBytes_GreaterThan
// Size: 0x10(Inherited: 0x0) 
struct FDoubleBytes_GreaterThan
{
	struct ULowEntryDouble* Value;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.Texture2DToPixels
// Size: 0x20(Inherited: 0x0) 
struct FTexture2DToPixels
{
	struct UTexture2D* Texture2D;  // 0x0(0x8)
	int32_t Width;  // 0x8(0x4)
	int32_t Height;  // 0xC(0x4)
	struct TArray<struct FColor> Pixels;  // 0x10(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryLong.DoubleBytes_LessThan
// Size: 0x10(Inherited: 0x0) 
struct FDoubleBytes_LessThan
{
	struct ULowEntryDouble* Value;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.ByteDataEntry_CreateFromFloat
// Size: 0x10(Inherited: 0x0) 
struct FByteDataEntry_CreateFromFloat
{
	float Value;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct ULowEntryByteDataEntry* ReturnValue;  // 0x8(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryDouble.DoubleBytes_Subtract
// Size: 0x8(Inherited: 0x0) 
struct FDoubleBytes_Subtract
{
	struct ULowEntryDouble* Value;  // 0x0(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.ByteDataReader_Create
// Size: 0x20(Inherited: 0x0) 
struct FByteDataReader_Create
{
	struct TArray<char> Bytes;  // 0x0(0x10)
	int32_t Index;  // 0x10(0x4)
	int32_t Length;  // 0x14(0x4)
	struct ULowEntryByteDataReader* ReturnValue;  // 0x18(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.ByteDataEntry_CreateFromPositiveInteger1Array
// Size: 0x18(Inherited: 0x0) 
struct FByteDataEntry_CreateFromPositiveInteger1Array
{
	struct TArray<int32_t> Value;  // 0x0(0x10)
	struct ULowEntryByteDataEntry* ReturnValue;  // 0x10(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.Base64UrlToBytes
// Size: 0x20(Inherited: 0x0) 
struct FBase64UrlToBytes
{
	struct FString Base64Url;  // 0x0(0x10)
	struct TArray<char> ReturnValue;  // 0x10(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryDouble.Float_Add
// Size: 0x8(Inherited: 0x0) 
struct FFloat_Add
{
	double Value;  // 0x0(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryDouble.Float_Equals
// Size: 0x10(Inherited: 0x0) 
struct FFloat_Equals
{
	double Value;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BytesToByte
// Size: 0x20(Inherited: 0x0) 
struct FBytesToByte
{
	struct TArray<char> ByteArray;  // 0x0(0x10)
	int32_t Index;  // 0x10(0x4)
	int32_t Length;  // 0x14(0x4)
	char ReturnValue;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.ByteDataEntry_CreateFromLongBytes
// Size: 0x10(Inherited: 0x0) 
struct FByteDataEntry_CreateFromLongBytes
{
	struct ULowEntryLong* Value;  // 0x0(0x8)
	struct ULowEntryByteDataEntry* ReturnValue;  // 0x8(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BitDataEntry_CreateFromDoubleBytes
// Size: 0x10(Inherited: 0x0) 
struct FBitDataEntry_CreateFromDoubleBytes
{
	struct ULowEntryDouble* Value;  // 0x0(0x8)
	struct ULowEntryBitDataEntry* ReturnValue;  // 0x8(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BitDataEntry_CreateFromByteLeastSignificantBits
// Size: 0x10(Inherited: 0x0) 
struct FBitDataEntry_CreateFromByteLeastSignificantBits
{
	char Value;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	int32_t BitCount;  // 0x4(0x4)
	struct ULowEntryBitDataEntry* ReturnValue;  // 0x8(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryLong.Float_GreaterThan
// Size: 0x10(Inherited: 0x0) 
struct FFloat_GreaterThan
{
	double Value;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GrayscalePixel
// Size: 0x8(Inherited: 0x0) 
struct FGrayscalePixel
{
	struct FColor Pixel;  // 0x0(0x4)
	struct FColor ReturnValue;  // 0x4(0x4)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryLong.Float_LessThan
// Size: 0x10(Inherited: 0x0) 
struct FFloat_LessThan
{
	double Value;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.ByteToBits
// Size: 0x9(Inherited: 0x0) 
struct FByteToBits
{
	char Byte;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool Bit1 : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool Bit2 : 1;  // 0x2(0x1)
	char pad_3_1 : 7;  // 0x3(0x1)
	bool Bit3 : 1;  // 0x3(0x1)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Bit4 : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool Bit5 : 1;  // 0x5(0x1)
	char pad_6_1 : 7;  // 0x6(0x1)
	bool Bit6 : 1;  // 0x6(0x1)
	char pad_7_1 : 7;  // 0x7(0x1)
	bool Bit7 : 1;  // 0x7(0x1)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Bit8 : 1;  // 0x8(0x1)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryDouble.Float_Subtract
// Size: 0x8(Inherited: 0x0) 
struct FFloat_Subtract
{
	double Value;  // 0x0(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.PixelsToTexture2D
// Size: 0x20(Inherited: 0x0) 
struct FPixelsToTexture2D
{
	int32_t Width;  // 0x0(0x4)
	int32_t Height;  // 0x4(0x4)
	struct TArray<struct FColor> Pixels;  // 0x8(0x10)
	struct UTexture2D* ReturnValue;  // 0x18(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.DevelopmentBuild
// Size: 0x1(Inherited: 0x0) 
struct FDevelopmentBuild
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryLong.GetBytes
// Size: 0x10(Inherited: 0x0) 
struct FGetBytes
{
	struct TArray<char> ReturnValue;  // 0x0(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryLong.Integer_GreaterThan
// Size: 0x8(Inherited: 0x0) 
struct FInteger_GreaterThan
{
	int32_t Value;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool ReturnValue : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryLong.Integer_LessThan
// Size: 0x8(Inherited: 0x0) 
struct FInteger_LessThan
{
	int32_t Value;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool ReturnValue : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryLong.LongBytes_GreaterThan
// Size: 0x10(Inherited: 0x0) 
struct FLongBytes_GreaterThan
{
	struct ULowEntryLong* Value;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.SortTimespanArray
// Size: 0x28(Inherited: 0x0) 
struct FSortTimespanArray
{
	struct TArray<struct FTimespan> TimespanArray;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool Reversed : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct TArray<struct FTimespan> ReturnValue;  // 0x18(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.IosPlatform
// Size: 0x1(Inherited: 0x0) 
struct FIosPlatform
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.HostGame
// Size: 0x30(Inherited: 0x0) 
struct FHostGame
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct FString Map;  // 0x8(0x10)
	struct FString Args;  // 0x18(0x10)
	struct APlayerController* SpecificPlayer;  // 0x28(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryLong.LongBytes_LessThan
// Size: 0x10(Inherited: 0x0) 
struct FLongBytes_LessThan
{
	struct ULowEntryLong* Value;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryLong.SetBytes
// Size: 0x18(Inherited: 0x0) 
struct FSetBytes
{
	struct TArray<char> ByteArray;  // 0x0(0x10)
	int32_t Index;  // 0x10(0x4)
	int32_t Length;  // 0x14(0x4)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.LatentAction_Create_String
// Size: 0x8(Inherited: 0x0) 
struct FLatentAction_Create_String
{
	struct ULowEntryLatentActionString* LatentAction;  // 0x0(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryDouble.SetDouble
// Size: 0x8(Inherited: 0x0) 
struct FSetDouble
{
	double Value;  // 0x0(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BitDataWriter_GetBytes
// Size: 0x18(Inherited: 0x0) 
struct FBitDataWriter_GetBytes
{
	struct ULowEntryBitDataWriter* BitDataWriter;  // 0x0(0x8)
	struct TArray<char> ReturnValue;  // 0x8(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.AndroidPlatform
// Size: 0x1(Inherited: 0x0) 
struct FAndroidPlatform
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.AreAndroidHeadphonesPluggedIn
// Size: 0x1(Inherited: 0x0) 
struct FAreAndroidHeadphonesPluggedIn
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryLatentActionString.IsDone
// Size: 0x1(Inherited: 0x0) 
struct FIsDone
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.Base64ToBase64Url
// Size: 0x20(Inherited: 0x0) 
struct FBase64ToBase64Url
{
	struct FString Base64;  // 0x0(0x10)
	struct FString ReturnValue;  // 0x10(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.ReplaceCharactersExcept
// Size: 0x48(Inherited: 0x0) 
struct FReplaceCharactersExcept
{
	struct FString String;  // 0x0(0x10)
	struct FString ReplacementCharacter;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool KeepLowercaseAZ : 1;  // 0x20(0x1)
	char pad_33_1 : 7;  // 0x21(0x1)
	bool KeepUppercaseAZ : 1;  // 0x21(0x1)
	char pad_34_1 : 7;  // 0x22(0x1)
	bool KeepNumbers : 1;  // 0x22(0x1)
	char pad_35[5];  // 0x23(0x5)
	struct FString OtherCharactersToKeep;  // 0x28(0x10)
	struct FString ReturnValue;  // 0x38(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.Base64ToBytes
// Size: 0x20(Inherited: 0x0) 
struct FBase64ToBytes
{
	struct FString Base64;  // 0x0(0x10)
	struct TArray<char> ReturnValue;  // 0x10(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.Base64UrlToBase64
// Size: 0x20(Inherited: 0x0) 
struct FBase64UrlToBase64
{
	struct FString Base64Url;  // 0x0(0x10)
	struct FString ReturnValue;  // 0x10(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GetMousePositionInPercentages
// Size: 0x18(Inherited: 0x0) 
struct FGetMousePositionInPercentages
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Success : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	double X;  // 0x8(0x8)
	double Y;  // 0x10(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BCrypt
// Size: 0x40(Inherited: 0x0) 
struct FBCrypt
{
	struct TArray<char> ByteArray;  // 0x0(0x10)
	struct TArray<char> Salt;  // 0x10(0x10)
	int32_t Strength;  // 0x20(0x4)
	int32_t Index;  // 0x24(0x4)
	int32_t Length;  // 0x28(0x4)
	char pad_44[4];  // 0x2C(0x4)
	struct TArray<char> ReturnValue;  // 0x30(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.SetWindowPositionInPercentagesCentered
// Size: 0x10(Inherited: 0x0) 
struct FSetWindowPositionInPercentagesCentered
{
	double X;  // 0x0(0x8)
	double Y;  // 0x8(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.SetWindowMode
// Size: 0x2(Inherited: 0x0) 
struct FSetWindowMode
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Fullscreen : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool IsFullscreenWindowed : 1;  // 0x1(0x1)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BinaryToBytes
// Size: 0x20(Inherited: 0x0) 
struct FBinaryToBytes
{
	struct FString Binary;  // 0x0(0x10)
	struct TArray<char> ReturnValue;  // 0x10(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.SortFloatArrayDirectly
// Size: 0x18(Inherited: 0x0) 
struct FSortFloatArrayDirectly
{
	struct TArray<float> FloatArray;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool Reversed : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.SetSplitScreenType_ThreePlayers
// Size: 0x1(Inherited: 0x0) 
struct FSetSplitScreenType_ThreePlayers
{
	uint8_t  Type;  // 0x0(0x1)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BitDataEntry_CreateFromBit
// Size: 0x10(Inherited: 0x0) 
struct FBitDataEntry_CreateFromBit
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Value : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct ULowEntryBitDataEntry* ReturnValue;  // 0x8(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BitDataEntry_CreateFromBitArray
// Size: 0x18(Inherited: 0x0) 
struct FBitDataEntry_CreateFromBitArray
{
	struct TArray<bool> Value;  // 0x0(0x10)
	struct ULowEntryBitDataEntry* ReturnValue;  // 0x10(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BitDataEntry_CreateFromBoolean
// Size: 0x10(Inherited: 0x0) 
struct FBitDataEntry_CreateFromBoolean
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Value : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct ULowEntryBitDataEntry* ReturnValue;  // 0x8(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.SetGenericTeamId
// Size: 0x10(Inherited: 0x0) 
struct FSetGenericTeamId
{
	struct AActor* Target;  // 0x0(0x8)
	char TeamID;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BitDataEntry_CreateFromBooleanArray
// Size: 0x18(Inherited: 0x0) 
struct FBitDataEntry_CreateFromBooleanArray
{
	struct TArray<bool> Value;  // 0x0(0x10)
	struct ULowEntryBitDataEntry* ReturnValue;  // 0x10(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.Double_CreateZero
// Size: 0x8(Inherited: 0x0) 
struct FDouble_CreateZero
{
	struct ULowEntryDouble* ReturnValue;  // 0x0(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BitDataEntry_CreateFromByte
// Size: 0x10(Inherited: 0x0) 
struct FBitDataEntry_CreateFromByte
{
	char Value;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct ULowEntryBitDataEntry* ReturnValue;  // 0x8(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.ByteDataEntry_CreateFromPositiveInteger1
// Size: 0x10(Inherited: 0x0) 
struct FByteDataEntry_CreateFromPositiveInteger1
{
	int32_t Value;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct ULowEntryByteDataEntry* ReturnValue;  // 0x8(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BitDataEntry_CreateFromByteArray
// Size: 0x18(Inherited: 0x0) 
struct FBitDataEntry_CreateFromByteArray
{
	struct TArray<char> Value;  // 0x0(0x10)
	struct ULowEntryBitDataEntry* ReturnValue;  // 0x10(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BitDataEntry_CreateFromByteArrayLeastSignificantBits
// Size: 0x20(Inherited: 0x0) 
struct FBitDataEntry_CreateFromByteArrayLeastSignificantBits
{
	struct TArray<char> Value;  // 0x0(0x10)
	int32_t BitCount;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct ULowEntryBitDataEntry* ReturnValue;  // 0x18(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BitDataEntry_CreateFromByteArrayMostSignificantBits
// Size: 0x20(Inherited: 0x0) 
struct FBitDataEntry_CreateFromByteArrayMostSignificantBits
{
	struct TArray<char> Value;  // 0x0(0x10)
	int32_t BitCount;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct ULowEntryBitDataEntry* ReturnValue;  // 0x18(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.Sha1
// Size: 0x28(Inherited: 0x0) 
struct FSha1
{
	struct TArray<char> ByteArray;  // 0x0(0x10)
	int32_t Index;  // 0x10(0x4)
	int32_t Length;  // 0x14(0x4)
	struct TArray<char> ReturnValue;  // 0x18(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.RemoveCharactersExcept
// Size: 0x38(Inherited: 0x0) 
struct FRemoveCharactersExcept
{
	struct FString String;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool KeepLowercaseAZ : 1;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool KeepUppercaseAZ : 1;  // 0x11(0x1)
	char pad_18_1 : 7;  // 0x12(0x1)
	bool KeepNumbers : 1;  // 0x12(0x1)
	char pad_19[5];  // 0x13(0x5)
	struct FString OtherCharactersToKeep;  // 0x18(0x10)
	struct FString ReturnValue;  // 0x28(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.ByteDataEntry_CreateFromLong
// Size: 0x10(Inherited: 0x0) 
struct FByteDataEntry_CreateFromLong
{
	int64_t Value;  // 0x0(0x8)
	struct ULowEntryByteDataEntry* ReturnValue;  // 0x8(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BitDataEntry_CreateFromDouble
// Size: 0x10(Inherited: 0x0) 
struct FBitDataEntry_CreateFromDouble
{
	double Value;  // 0x0(0x8)
	struct ULowEntryBitDataEntry* ReturnValue;  // 0x8(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.ByteDataEntry_CreateFromLongArray
// Size: 0x18(Inherited: 0x0) 
struct FByteDataEntry_CreateFromLongArray
{
	struct TArray<int64_t> Value;  // 0x0(0x10)
	struct ULowEntryByteDataEntry* ReturnValue;  // 0x10(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BitDataEntry_CreateFromDoubleArray
// Size: 0x18(Inherited: 0x0) 
struct FBitDataEntry_CreateFromDoubleArray
{
	struct TArray<double> Value;  // 0x0(0x10)
	struct ULowEntryBitDataEntry* ReturnValue;  // 0x10(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.CeilDecimals
// Size: 0x18(Inherited: 0x0) 
struct FCeilDecimals
{
	double Number;  // 0x0(0x8)
	int32_t Decimals;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	double ReturnValue;  // 0x10(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.ByteDataEntry_CreateFromLongBytesArray
// Size: 0x18(Inherited: 0x0) 
struct FByteDataEntry_CreateFromLongBytesArray
{
	struct TArray<struct ULowEntryLong*> Value;  // 0x0(0x10)
	struct ULowEntryByteDataEntry* ReturnValue;  // 0x10(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BitDataEntry_CreateFromDoubleBytesArray
// Size: 0x18(Inherited: 0x0) 
struct FBitDataEntry_CreateFromDoubleBytesArray
{
	struct TArray<struct ULowEntryDouble*> Value;  // 0x0(0x10)
	struct ULowEntryBitDataEntry* ReturnValue;  // 0x10(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BitDataEntry_CreateFromFloat
// Size: 0x10(Inherited: 0x0) 
struct FBitDataEntry_CreateFromFloat
{
	float Value;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct ULowEntryBitDataEntry* ReturnValue;  // 0x8(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryLong.Integer_Subtract
// Size: 0x4(Inherited: 0x0) 
struct FInteger_Subtract
{
	int32_t Value;  // 0x0(0x4)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BitDataEntry_CreateFromFloatArray
// Size: 0x18(Inherited: 0x0) 
struct FBitDataEntry_CreateFromFloatArray
{
	struct TArray<float> Value;  // 0x0(0x10)
	struct ULowEntryBitDataEntry* ReturnValue;  // 0x10(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BitDataEntry_CreateFromInteger
// Size: 0x10(Inherited: 0x0) 
struct FBitDataEntry_CreateFromInteger
{
	int32_t Value;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct ULowEntryBitDataEntry* ReturnValue;  // 0x8(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.MinString
// Size: 0x30(Inherited: 0x0) 
struct FMinString
{
	struct FString A;  // 0x0(0x10)
	struct FString B;  // 0x10(0x10)
	struct FString ReturnValue;  // 0x20(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.LinuxPlatform
// Size: 0x1(Inherited: 0x0) 
struct FLinuxPlatform
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BitDataEntry_CreateFromLongBytes
// Size: 0x10(Inherited: 0x0) 
struct FBitDataEntry_CreateFromLongBytes
{
	struct ULowEntryLong* Value;  // 0x0(0x8)
	struct ULowEntryBitDataEntry* ReturnValue;  // 0x8(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BitDataEntry_CreateFromIntegerArrayLeastSignificantBits
// Size: 0x20(Inherited: 0x0) 
struct FBitDataEntry_CreateFromIntegerArrayLeastSignificantBits
{
	struct TArray<int32_t> Value;  // 0x0(0x10)
	int32_t BitCount;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct ULowEntryBitDataEntry* ReturnValue;  // 0x18(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BitDataEntry_CreateFromIntegerArray
// Size: 0x18(Inherited: 0x0) 
struct FBitDataEntry_CreateFromIntegerArray
{
	struct TArray<int32_t> Value;  // 0x0(0x10)
	struct ULowEntryBitDataEntry* ReturnValue;  // 0x10(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BitDataEntry_CreateFromIntegerArrayMostSignificantBits
// Size: 0x20(Inherited: 0x0) 
struct FBitDataEntry_CreateFromIntegerArrayMostSignificantBits
{
	struct TArray<int32_t> Value;  // 0x0(0x10)
	int32_t BitCount;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct ULowEntryBitDataEntry* ReturnValue;  // 0x18(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BitDataEntry_CreateFromIntegerLeastSignificantBits
// Size: 0x10(Inherited: 0x0) 
struct FBitDataEntry_CreateFromIntegerLeastSignificantBits
{
	int32_t Value;  // 0x0(0x4)
	int32_t BitCount;  // 0x4(0x4)
	struct ULowEntryBitDataEntry* ReturnValue;  // 0x8(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BitDataEntry_CreateFromIntegerMostSignificantBits
// Size: 0x10(Inherited: 0x0) 
struct FBitDataEntry_CreateFromIntegerMostSignificantBits
{
	int32_t Value;  // 0x0(0x4)
	int32_t BitCount;  // 0x4(0x4)
	struct ULowEntryBitDataEntry* ReturnValue;  // 0x8(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BitDataEntry_CreateFromLong
// Size: 0x10(Inherited: 0x0) 
struct FBitDataEntry_CreateFromLong
{
	int64_t Value;  // 0x0(0x8)
	struct ULowEntryBitDataEntry* ReturnValue;  // 0x8(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BitDataEntry_CreateFromLongArray
// Size: 0x18(Inherited: 0x0) 
struct FBitDataEntry_CreateFromLongArray
{
	struct TArray<int64_t> Value;  // 0x0(0x10)
	struct ULowEntryBitDataEntry* ReturnValue;  // 0x10(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BitDataEntry_CreateFromLongBytesArray
// Size: 0x18(Inherited: 0x0) 
struct FBitDataEntry_CreateFromLongBytesArray
{
	struct TArray<struct ULowEntryLong*> Value;  // 0x0(0x10)
	struct ULowEntryBitDataEntry* ReturnValue;  // 0x10(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BitDataEntry_CreateFromPositiveInteger1
// Size: 0x10(Inherited: 0x0) 
struct FBitDataEntry_CreateFromPositiveInteger1
{
	int32_t Value;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct ULowEntryBitDataEntry* ReturnValue;  // 0x8(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BitDataEntry_CreateFromPositiveInteger1Array
// Size: 0x18(Inherited: 0x0) 
struct FBitDataEntry_CreateFromPositiveInteger1Array
{
	struct TArray<int32_t> Value;  // 0x0(0x10)
	struct ULowEntryBitDataEntry* ReturnValue;  // 0x10(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.ByteDataEntry_CreateFromPositiveInteger3
// Size: 0x10(Inherited: 0x0) 
struct FByteDataEntry_CreateFromPositiveInteger3
{
	int32_t Value;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct ULowEntryByteDataEntry* ReturnValue;  // 0x8(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BitDataEntry_CreateFromPositiveInteger2
// Size: 0x10(Inherited: 0x0) 
struct FBitDataEntry_CreateFromPositiveInteger2
{
	int32_t Value;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct ULowEntryBitDataEntry* ReturnValue;  // 0x8(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.ByteDataEntry_CreateFromPositiveInteger3Array
// Size: 0x18(Inherited: 0x0) 
struct FByteDataEntry_CreateFromPositiveInteger3Array
{
	struct TArray<int32_t> Value;  // 0x0(0x10)
	struct ULowEntryByteDataEntry* ReturnValue;  // 0x10(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BitDataEntry_CreateFromPositiveInteger2Array
// Size: 0x18(Inherited: 0x0) 
struct FBitDataEntry_CreateFromPositiveInteger2Array
{
	struct TArray<int32_t> Value;  // 0x0(0x10)
	struct ULowEntryBitDataEntry* ReturnValue;  // 0x10(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.ByteDataEntry_CreateFromPositiveInteger2
// Size: 0x10(Inherited: 0x0) 
struct FByteDataEntry_CreateFromPositiveInteger2
{
	int32_t Value;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct ULowEntryByteDataEntry* ReturnValue;  // 0x8(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BitDataEntry_CreateFromPositiveInteger3
// Size: 0x10(Inherited: 0x0) 
struct FBitDataEntry_CreateFromPositiveInteger3
{
	int32_t Value;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct ULowEntryBitDataEntry* ReturnValue;  // 0x8(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.ByteDataEntry_CreateFromPositiveInteger2Array
// Size: 0x18(Inherited: 0x0) 
struct FByteDataEntry_CreateFromPositiveInteger2Array
{
	struct TArray<int32_t> Value;  // 0x0(0x10)
	struct ULowEntryByteDataEntry* ReturnValue;  // 0x10(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BitDataEntry_CreateFromPositiveInteger3Array
// Size: 0x18(Inherited: 0x0) 
struct FBitDataEntry_CreateFromPositiveInteger3Array
{
	struct TArray<int32_t> Value;  // 0x0(0x10)
	struct ULowEntryBitDataEntry* ReturnValue;  // 0x10(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BitDataEntry_CreateFromStringUtf8
// Size: 0x18(Inherited: 0x0) 
struct FBitDataEntry_CreateFromStringUtf8
{
	struct FString Value;  // 0x0(0x10)
	struct ULowEntryBitDataEntry* ReturnValue;  // 0x10(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BitDataEntry_CreateFromStringUtf8Array
// Size: 0x18(Inherited: 0x0) 
struct FBitDataEntry_CreateFromStringUtf8Array
{
	struct TArray<struct FString> Value;  // 0x0(0x10)
	struct ULowEntryBitDataEntry* ReturnValue;  // 0x10(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BitDataWriter_CreateFromEntryArray
// Size: 0x18(Inherited: 0x0) 
struct FBitDataWriter_CreateFromEntryArray
{
	struct TArray<struct ULowEntryBitDataEntry*> Array;  // 0x0(0x10)
	struct ULowEntryBitDataWriter* ReturnValue;  // 0x10(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.RoundDecimals
// Size: 0x18(Inherited: 0x0) 
struct FRoundDecimals
{
	double Number;  // 0x0(0x8)
	int32_t Decimals;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	double ReturnValue;  // 0x10(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BitDataWriter_CreateFromEntryArrayPure
// Size: 0x18(Inherited: 0x0) 
struct FBitDataWriter_CreateFromEntryArrayPure
{
	struct TArray<struct ULowEntryBitDataEntry*> Array;  // 0x0(0x10)
	struct ULowEntryBitDataWriter* ReturnValue;  // 0x10(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BitStringToBytes
// Size: 0x20(Inherited: 0x0) 
struct FBitStringToBytes
{
	struct FString Bits;  // 0x0(0x10)
	struct TArray<char> ReturnValue;  // 0x10(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.CreateString
// Size: 0x28(Inherited: 0x0) 
struct FCreateString
{
	int32_t Length;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FString Filler;  // 0x8(0x10)
	struct FString ReturnValue;  // 0x18(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.ByteDataWriter_CreateFromEntryArray
// Size: 0x18(Inherited: 0x0) 
struct FByteDataWriter_CreateFromEntryArray
{
	struct TArray<struct ULowEntryByteDataEntry*> Array;  // 0x0(0x10)
	struct ULowEntryByteDataWriter* ReturnValue;  // 0x10(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BooleanToByte
// Size: 0x2(Inherited: 0x0) 
struct FBooleanToByte
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Value : 1;  // 0x0(0x1)
	char ReturnValue;  // 0x1(0x1)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BooleanToBytes
// Size: 0x18(Inherited: 0x0) 
struct FBooleanToBytes
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Value : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct TArray<char> ReturnValue;  // 0x8(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.ByteDataEntry_CreateFromBoolean
// Size: 0x10(Inherited: 0x0) 
struct FByteDataEntry_CreateFromBoolean
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Value : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct ULowEntryByteDataEntry* ReturnValue;  // 0x8(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.ByteDataEntry_CreateFromBooleanArray
// Size: 0x18(Inherited: 0x0) 
struct FByteDataEntry_CreateFromBooleanArray
{
	struct TArray<bool> Value;  // 0x0(0x10)
	struct ULowEntryByteDataEntry* ReturnValue;  // 0x10(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.ByteDataEntry_CreateFromByte
// Size: 0x10(Inherited: 0x0) 
struct FByteDataEntry_CreateFromByte
{
	char Value;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct ULowEntryByteDataEntry* ReturnValue;  // 0x8(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.ByteDataEntry_CreateFromByteArray
// Size: 0x18(Inherited: 0x0) 
struct FByteDataEntry_CreateFromByteArray
{
	struct TArray<char> Value;  // 0x0(0x10)
	struct ULowEntryByteDataEntry* ReturnValue;  // 0x10(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.SetMouseLockedToViewport
// Size: 0x1(Inherited: 0x0) 
struct FSetMouseLockedToViewport
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Locked : 1;  // 0x0(0x1)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.ByteDataEntry_CreateFromDouble
// Size: 0x10(Inherited: 0x0) 
struct FByteDataEntry_CreateFromDouble
{
	double Value;  // 0x0(0x8)
	struct ULowEntryByteDataEntry* ReturnValue;  // 0x8(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.ByteDataEntry_CreateFromDoubleArray
// Size: 0x18(Inherited: 0x0) 
struct FByteDataEntry_CreateFromDoubleArray
{
	struct TArray<double> Value;  // 0x0(0x10)
	struct ULowEntryByteDataEntry* ReturnValue;  // 0x10(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GreaterIntegerByte
// Size: 0x8(Inherited: 0x0) 
struct FGreaterIntegerByte
{
	int32_t A;  // 0x0(0x4)
	char B;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool ReturnValue : 1;  // 0x5(0x1)
	char pad_6[2];  // 0x6(0x2)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GenerateRandomBytesRandomLength
// Size: 0x18(Inherited: 0x0) 
struct FGenerateRandomBytesRandomLength
{
	int32_t MinLength;  // 0x0(0x4)
	int32_t MaxLength;  // 0x4(0x4)
	struct TArray<char> ByteArray;  // 0x8(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.ByteDataEntry_CreateFromDoubleBytesArray
// Size: 0x18(Inherited: 0x0) 
struct FByteDataEntry_CreateFromDoubleBytesArray
{
	struct TArray<struct ULowEntryDouble*> Value;  // 0x0(0x10)
	struct ULowEntryByteDataEntry* ReturnValue;  // 0x10(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.ByteDataEntry_CreateFromInteger
// Size: 0x10(Inherited: 0x0) 
struct FByteDataEntry_CreateFromInteger
{
	int32_t Value;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct ULowEntryByteDataEntry* ReturnValue;  // 0x8(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.ByteDataEntry_CreateFromIntegerArray
// Size: 0x18(Inherited: 0x0) 
struct FByteDataEntry_CreateFromIntegerArray
{
	struct TArray<int32_t> Value;  // 0x0(0x10)
	struct ULowEntryByteDataEntry* ReturnValue;  // 0x10(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.SetWorldRenderingEnabled
// Size: 0x1(Inherited: 0x0) 
struct FSetWorldRenderingEnabled
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Enabled : 1;  // 0x0(0x1)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.LessStringString
// Size: 0x28(Inherited: 0x0) 
struct FLessStringString
{
	struct FString A;  // 0x0(0x10)
	struct FString B;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool ReturnValue : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.ByteDataEntry_CreateFromStringUtf8
// Size: 0x18(Inherited: 0x0) 
struct FByteDataEntry_CreateFromStringUtf8
{
	struct FString Value;  // 0x0(0x10)
	struct ULowEntryByteDataEntry* ReturnValue;  // 0x10(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.SceneCapture2D_SetFov
// Size: 0x10(Inherited: 0x0) 
struct FSceneCapture2D_SetFov
{
	struct ASceneCapture2D* SceneCapture2D;  // 0x0(0x8)
	double FOV;  // 0x8(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.ByteDataEntry_CreateFromStringUtf8Array
// Size: 0x18(Inherited: 0x0) 
struct FByteDataEntry_CreateFromStringUtf8Array
{
	struct TArray<struct FString> Value;  // 0x0(0x10)
	struct ULowEntryByteDataEntry* ReturnValue;  // 0x10(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.SetSplitScreenType_TwoPlayers
// Size: 0x1(Inherited: 0x0) 
struct FSetSplitScreenType_TwoPlayers
{
	uint8_t  Type;  // 0x0(0x1)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.ByteDataWriter_CreateFromEntryArrayPure
// Size: 0x18(Inherited: 0x0) 
struct FByteDataWriter_CreateFromEntryArrayPure
{
	struct TArray<struct ULowEntryByteDataEntry*> Array;  // 0x0(0x10)
	struct ULowEntryByteDataWriter* ReturnValue;  // 0x10(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.SortDateTimeArrayDirectly
// Size: 0x18(Inherited: 0x0) 
struct FSortDateTimeArrayDirectly
{
	struct TArray<struct FDateTime> DateTimeArray;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool Reversed : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BytesToStringUtf8
// Size: 0x28(Inherited: 0x0) 
struct FBytesToStringUtf8
{
	struct TArray<char> ByteArray;  // 0x0(0x10)
	int32_t Index;  // 0x10(0x4)
	int32_t Length;  // 0x14(0x4)
	struct FString ReturnValue;  // 0x18(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BytesSubArray
// Size: 0x28(Inherited: 0x0) 
struct FBytesSubArray
{
	struct TArray<char> ByteArray;  // 0x0(0x10)
	int32_t Index;  // 0x10(0x4)
	int32_t Length;  // 0x14(0x4)
	struct TArray<char> ReturnValue;  // 0x18(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BytesToBase64
// Size: 0x28(Inherited: 0x0) 
struct FBytesToBase64
{
	struct TArray<char> ByteArray;  // 0x0(0x10)
	int32_t Index;  // 0x10(0x4)
	int32_t Length;  // 0x14(0x4)
	struct FString ReturnValue;  // 0x18(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.SimpleKismetSystemLibraryPrintString
// Size: 0x10(Inherited: 0x0) 
struct FSimpleKismetSystemLibraryPrintString
{
	struct FString InString;  // 0x0(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BytesToBinary
// Size: 0x30(Inherited: 0x0) 
struct FBytesToBinary
{
	struct TArray<char> ByteArray;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool AddSpaces : 1;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)
	int32_t Index;  // 0x14(0x4)
	int32_t Length;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct FString ReturnValue;  // 0x20(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GreaterFloatInteger
// Size: 0x10(Inherited: 0x0) 
struct FGreaterFloatInteger
{
	double A;  // 0x0(0x8)
	int32_t B;  // 0x8(0x4)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool ReturnValue : 1;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BytesToBitString
// Size: 0x30(Inherited: 0x0) 
struct FBytesToBitString
{
	struct TArray<char> ByteArray;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool AddSpaces : 1;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)
	int32_t Index;  // 0x14(0x4)
	int32_t Length;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct FString ReturnValue;  // 0x20(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BytesToBoolean
// Size: 0x20(Inherited: 0x0) 
struct FBytesToBoolean
{
	struct TArray<char> ByteArray;  // 0x0(0x10)
	int32_t Index;  // 0x10(0x4)
	int32_t Length;  // 0x14(0x4)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool ReturnValue : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GetProjectVersion
// Size: 0x10(Inherited: 0x0) 
struct FGetProjectVersion
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BytesToDouble
// Size: 0x20(Inherited: 0x0) 
struct FBytesToDouble
{
	struct TArray<char> ByteArray;  // 0x0(0x10)
	int32_t Index;  // 0x10(0x4)
	int32_t Length;  // 0x14(0x4)
	double ReturnValue;  // 0x18(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.LatentAction_Create_Integer
// Size: 0x8(Inherited: 0x0) 
struct FLatentAction_Create_Integer
{
	struct ULowEntryLatentActionInteger* LatentAction;  // 0x0(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BytesToLong
// Size: 0x20(Inherited: 0x0) 
struct FBytesToLong
{
	struct TArray<char> ByteArray;  // 0x0(0x10)
	int32_t Index;  // 0x10(0x4)
	int32_t Length;  // 0x14(0x4)
	int64_t ReturnValue;  // 0x18(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BytesToDoubleBytes
// Size: 0x20(Inherited: 0x0) 
struct FBytesToDoubleBytes
{
	struct TArray<char> ByteArray;  // 0x0(0x10)
	int32_t Index;  // 0x10(0x4)
	int32_t Length;  // 0x14(0x4)
	struct ULowEntryDouble* ReturnValue;  // 0x18(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GreaterEqualByteInteger
// Size: 0xC(Inherited: 0x0) 
struct FGreaterEqualByteInteger
{
	char A;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	int32_t B;  // 0x4(0x4)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BytesToExistingImage
// Size: 0x38(Inherited: 0x0) 
struct FBytesToExistingImage
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReusedGivenTexture2D : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct UTexture2D* Texture2D;  // 0x8(0x8)
	struct TArray<char> ByteArray;  // 0x10(0x10)
	uint8_t  ImageFormat;  // 0x20(0x1)
	char pad_33[3];  // 0x21(0x3)
	int32_t Index;  // 0x24(0x4)
	int32_t Length;  // 0x28(0x4)
	char pad_44[4];  // 0x2C(0x4)
	struct UTexture2D* ReturnValue;  // 0x30(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BytesToHex
// Size: 0x30(Inherited: 0x0) 
struct FBytesToHex
{
	struct TArray<char> ByteArray;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool AddSpaces : 1;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)
	int32_t Index;  // 0x14(0x4)
	int32_t Length;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct FString ReturnValue;  // 0x20(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BytesToImage
// Size: 0x28(Inherited: 0x0) 
struct FBytesToImage
{
	struct TArray<char> ByteArray;  // 0x0(0x10)
	uint8_t  ImageFormat;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)
	int32_t Index;  // 0x14(0x4)
	int32_t Length;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct UTexture2D* ReturnValue;  // 0x20(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BytesToInteger
// Size: 0x20(Inherited: 0x0) 
struct FBytesToInteger
{
	struct TArray<char> ByteArray;  // 0x0(0x10)
	int32_t Index;  // 0x10(0x4)
	int32_t Length;  // 0x14(0x4)
	int32_t ReturnValue;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GetAndroidNumberOfCores
// Size: 0x4(Inherited: 0x0) 
struct FGetAndroidNumberOfCores
{
	int32_t ReturnValue;  // 0x0(0x4)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BytesToLongBytes
// Size: 0x20(Inherited: 0x0) 
struct FBytesToLongBytes
{
	struct TArray<char> ByteArray;  // 0x0(0x10)
	int32_t Index;  // 0x10(0x4)
	int32_t Length;  // 0x14(0x4)
	struct ULowEntryLong* ReturnValue;  // 0x18(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.BytesToPixels
// Size: 0x38(Inherited: 0x0) 
struct FBytesToPixels
{
	struct TArray<char> ByteArray;  // 0x0(0x10)
	uint8_t  ImageFormat;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)
	int32_t Width;  // 0x14(0x4)
	int32_t Height;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct TArray<struct FColor> Pixels;  // 0x20(0x10)
	int32_t Index;  // 0x30(0x4)
	int32_t Length;  // 0x34(0x4)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.ByteToBytes
// Size: 0x18(Inherited: 0x0) 
struct FByteToBytes
{
	char Value;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct TArray<char> ReturnValue;  // 0x8(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.CarriageReturnCharacter
// Size: 0x10(Inherited: 0x0) 
struct FCarriageReturnCharacter
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.CaseSwitchInteger
// Size: 0x34(Inherited: 0x0) 
struct FCaseSwitchInteger
{
	int32_t OnlyCheckFirstX;  // 0x0(0x4)
	int32_t Value;  // 0x4(0x4)
	int32_t _1__;  // 0x8(0x4)
	int32_t _2__;  // 0xC(0x4)
	int32_t _3__;  // 0x10(0x4)
	int32_t _4__;  // 0x14(0x4)
	int32_t _5__;  // 0x18(0x4)
	int32_t _6__;  // 0x1C(0x4)
	int32_t _7__;  // 0x20(0x4)
	int32_t _8__;  // 0x24(0x4)
	int32_t _9__;  // 0x28(0x4)
	int32_t _10__;  // 0x2C(0x4)
	uint8_t  Branch;  // 0x30(0x1)
	char pad_49[3];  // 0x31(0x3)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.CaseSwitchObject
// Size: 0x68(Inherited: 0x0) 
struct FCaseSwitchObject
{
	int32_t OnlyCheckFirstX;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UObject* Value;  // 0x8(0x8)
	struct UObject* _1__;  // 0x10(0x8)
	struct UObject* _2__;  // 0x18(0x8)
	struct UObject* _3__;  // 0x20(0x8)
	struct UObject* _4__;  // 0x28(0x8)
	struct UObject* _5__;  // 0x30(0x8)
	struct UObject* _6__;  // 0x38(0x8)
	struct UObject* _7__;  // 0x40(0x8)
	struct UObject* _8__;  // 0x48(0x8)
	struct UObject* _9__;  // 0x50(0x8)
	struct UObject* _10__;  // 0x58(0x8)
	uint8_t  Branch;  // 0x60(0x1)
	char pad_97[7];  // 0x61(0x7)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.ChangeMap
// Size: 0x30(Inherited: 0x0) 
struct FChangeMap
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct FString Map;  // 0x8(0x10)
	struct FString Args;  // 0x18(0x10)
	struct APlayerController* SpecificPlayer;  // 0x28(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.ClearUserFocus
// Size: 0x4(Inherited: 0x0) 
struct FClearUserFocus
{
	int32_t UserIndex;  // 0x0(0x4)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.ClipboardGet
// Size: 0x10(Inherited: 0x0) 
struct FClipboardGet
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.ClipboardSet
// Size: 0x10(Inherited: 0x0) 
struct FClipboardSet
{
	struct FString Value;  // 0x0(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.ConvertLocalDateToUtcDate
// Size: 0x10(Inherited: 0x0) 
struct FConvertLocalDateToUtcDate
{
	struct FDateTime Local;  // 0x0(0x8)
	struct FDateTime Utc;  // 0x8(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.SetWindowSize
// Size: 0x8(Inherited: 0x0) 
struct FSetWindowSize
{
	int32_t Width;  // 0x0(0x4)
	int32_t Height;  // 0x4(0x4)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.ConvertUtcDateToLocalDate
// Size: 0x10(Inherited: 0x0) 
struct FConvertUtcDateToLocalDate
{
	struct FDateTime Utc;  // 0x0(0x8)
	struct FDateTime Local;  // 0x8(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GetAndroidBuildVersion
// Size: 0x4(Inherited: 0x0) 
struct FGetAndroidBuildVersion
{
	int32_t ReturnValue;  // 0x0(0x4)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.CreateObject
// Size: 0x10(Inherited: 0x0) 
struct FCreateObject
{
	UObject* Class;  // 0x0(0x8)
	struct UObject* Object;  // 0x8(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.DateTime_FromUnixTimestamp
// Size: 0x10(Inherited: 0x0) 
struct FDateTime_FromUnixTimestamp
{
	struct ULowEntryLong* Timestamp;  // 0x0(0x8)
	struct FDateTime DateTime;  // 0x8(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.DateTime_ToIso8601
// Size: 0x18(Inherited: 0x0) 
struct FDateTime_ToIso8601
{
	struct FDateTime DateTime;  // 0x0(0x8)
	struct FString String;  // 0x8(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryLong.SetLong
// Size: 0x8(Inherited: 0x0) 
struct FSetLong
{
	int64_t Value;  // 0x0(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.TextureUpdateResource
// Size: 0x8(Inherited: 0x0) 
struct FTextureUpdateResource
{
	struct UTexture* Texture;  // 0x0(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GetMousePosition
// Size: 0xC(Inherited: 0x0) 
struct FGetMousePosition
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Success : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	int32_t X;  // 0x4(0x4)
	int32_t Y;  // 0x8(0x4)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.DateTime_ToString
// Size: 0x28(Inherited: 0x0) 
struct FDateTime_ToString
{
	struct FDateTime DateTime;  // 0x0(0x8)
	struct FString String;  // 0x8(0x10)
	struct FString Format;  // 0x18(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.DateTime_ToUnixTimestamp
// Size: 0x10(Inherited: 0x0) 
struct FDateTime_ToUnixTimestamp
{
	struct FDateTime DateTime;  // 0x0(0x8)
	struct ULowEntryLong* Timestamp;  // 0x8(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.LessFloatByte
// Size: 0x10(Inherited: 0x0) 
struct FLessFloatByte
{
	double A;  // 0x0(0x8)
	char B;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool ReturnValue : 1;  // 0x9(0x1)
	char pad_10[6];  // 0xA(0x6)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.DebugBuild
// Size: 0x1(Inherited: 0x0) 
struct FDebugBuild
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.DelayFrames
// Size: 0x28(Inherited: 0x0) 
struct FDelayFrames
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	int32_t Frames;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct FLatentActionInfo LatentInfo;  // 0x10(0x18)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GetWindowPosition
// Size: 0xC(Inherited: 0x0) 
struct FGetWindowPosition
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Success : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	int32_t X;  // 0x4(0x4)
	int32_t Y;  // 0x8(0x4)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.DesktopPlatform
// Size: 0x1(Inherited: 0x0) 
struct FDesktopPlatform
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.Divide_Vector2dVector2d
// Size: 0x30(Inherited: 0x0) 
struct FDivide_Vector2dVector2d
{
	struct FVector2D A;  // 0x0(0x10)
	struct FVector2D B;  // 0x10(0x10)
	struct FVector2D ReturnValue;  // 0x20(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.Double_Create
// Size: 0x20(Inherited: 0x0) 
struct FDouble_Create
{
	struct TArray<char> ByteArray;  // 0x0(0x10)
	int32_t Index;  // 0x10(0x4)
	int32_t Length;  // 0x14(0x4)
	struct ULowEntryDouble* ReturnValue;  // 0x18(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.LoadVideo
// Size: 0x38(Inherited: 0x0) 
struct FLoadVideo
{
	struct UMediaSoundComponent* MediaSoundComponent;  // 0x0(0x8)
	struct FString URL;  // 0x8(0x10)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool Success : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct UMediaPlayer* MediaPlayer;  // 0x20(0x8)
	struct UMediaTexture* MediaTexture;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool PlayOnOpen : 1;  // 0x30(0x1)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool Loop : 1;  // 0x31(0x1)
	char pad_50[6];  // 0x32(0x6)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.DoubleToBytes
// Size: 0x18(Inherited: 0x0) 
struct FDoubleToBytes
{
	double Value;  // 0x0(0x8)
	struct TArray<char> ReturnValue;  // 0x8(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.RegexGetMatches
// Size: 0x30(Inherited: 0x0) 
struct FRegexGetMatches
{
	struct FString String;  // 0x0(0x10)
	struct FString Pattern;  // 0x10(0x10)
	struct TArray<struct FLowEntryRegexMatch> ReturnValue;  // 0x20(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.EncapsulateByteArray
// Size: 0x18(Inherited: 0x0) 
struct FEncapsulateByteArray
{
	struct TArray<char> ByteArray;  // 0x0(0x10)
	struct ULowEntryByteArray* ReturnValue;  // 0x10(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.ExecToBoolean
// Size: 0x2(Inherited: 0x0) 
struct FExecToBoolean
{
	uint8_t  Branch;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool Value : 1;  // 0x1(0x1)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.ExecToByte
// Size: 0x2(Inherited: 0x0) 
struct FExecToByte
{
	uint8_t  Branch;  // 0x0(0x1)
	char Value;  // 0x1(0x1)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.ExecToInteger
// Size: 0x8(Inherited: 0x0) 
struct FExecToInteger
{
	uint8_t  Branch;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	int32_t Value;  // 0x4(0x4)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.RandomDelayFrames
// Size: 0x28(Inherited: 0x0) 
struct FRandomDelayFrames
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	int32_t MinFrames;  // 0x8(0x4)
	int32_t MaxFrames;  // 0xC(0x4)
	struct FLatentActionInfo LatentInfo;  // 0x10(0x18)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.FloatToBytes
// Size: 0x18(Inherited: 0x0) 
struct FFloatToBytes
{
	float Value;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct TArray<char> ReturnValue;  // 0x8(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.SortObjectArrayDirectly
// Size: 0x28(Inherited: 0x0) 
struct FSortObjectArrayDirectly
{
	struct TArray<struct UObject*> ObjectArray;  // 0x0(0x10)
	struct FDelegate Comparator;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool Reversed : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.FloorDecimals
// Size: 0x18(Inherited: 0x0) 
struct FFloorDecimals
{
	double Number;  // 0x0(0x8)
	int32_t Decimals;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	double ReturnValue;  // 0x10(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GenerateRandomBytes
// Size: 0x18(Inherited: 0x0) 
struct FGenerateRandomBytes
{
	int32_t Length;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct TArray<char> ByteArray;  // 0x8(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GetAbsoluteSize
// Size: 0x50(Inherited: 0x0) 
struct FGetAbsoluteSize
{
	struct FGeometry Geometry;  // 0x0(0x40)
	struct FVector2D ReturnValue;  // 0x40(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GetUserFocusedWidgetType
// Size: 0xC(Inherited: 0x0) 
struct FGetUserFocusedWidgetType
{
	int32_t UserIndex;  // 0x0(0x4)
	struct FName ReturnValue;  // 0x4(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GetAndroidDefaultLocale
// Size: 0x10(Inherited: 0x0) 
struct FGetAndroidDefaultLocale
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GetAndroidDeviceMake
// Size: 0x10(Inherited: 0x0) 
struct FGetAndroidDeviceMake
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.TextureRenderTarget2DToBytes
// Size: 0x28(Inherited: 0x0) 
struct FTextureRenderTarget2DToBytes
{
	struct UTextureRenderTarget2D* TextureRenderTarget2D;  // 0x0(0x8)
	uint8_t  ImageFormat;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct TArray<char> ByteArray;  // 0x10(0x10)
	int32_t CompressionQuality;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GetPrimaryMonitorResolution
// Size: 0x8(Inherited: 0x0) 
struct FGetPrimaryMonitorResolution
{
	int32_t Width;  // 0x0(0x4)
	int32_t Height;  // 0x4(0x4)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GetAndroidDeviceModel
// Size: 0x10(Inherited: 0x0) 
struct FGetAndroidDeviceModel
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GreaterEqualStringString
// Size: 0x28(Inherited: 0x0) 
struct FGreaterEqualStringString
{
	struct FString A;  // 0x0(0x10)
	struct FString B;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool ReturnValue : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GetAndroidGlVersion
// Size: 0x10(Inherited: 0x0) 
struct FGetAndroidGlVersion
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GetAndroidGpuFamily
// Size: 0x10(Inherited: 0x0) 
struct FGetAndroidGpuFamily
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.NewlineCharacter
// Size: 0x10(Inherited: 0x0) 
struct FNewlineCharacter
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GetAndroidVersion
// Size: 0x10(Inherited: 0x0) 
struct FGetAndroidVersion
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.SceneCaptureComponent2DToPixels
// Size: 0x20(Inherited: 0x0) 
struct FSceneCaptureComponent2DToPixels
{
	struct USceneCaptureComponent2D* SceneCaptureComponent2D;  // 0x0(0x8)
	int32_t Width;  // 0x8(0x4)
	int32_t Height;  // 0xC(0x4)
	struct TArray<struct FColor> Pixels;  // 0x10(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GetAndroidVolume
// Size: 0x4(Inherited: 0x0) 
struct FGetAndroidVolume
{
	int32_t Volume;  // 0x0(0x4)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GetBatteryCharge
// Size: 0x8(Inherited: 0x0) 
struct FGetBatteryCharge
{
	int32_t Percentage;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Success : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GetMaximumVolume
// Size: 0x8(Inherited: 0x0) 
struct FGetMaximumVolume
{
	int32_t Volume;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Success : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GetBatteryState
// Size: 0x2(Inherited: 0x0) 
struct FGetBatteryState
{
	uint8_t  State;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool Success : 1;  // 0x1(0x1)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GetBatteryTemperature
// Size: 0x10(Inherited: 0x0) 
struct FGetBatteryTemperature
{
	double Celsius;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Success : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GetByteWithBitSet
// Size: 0xC(Inherited: 0x0) 
struct FGetByteWithBitSet
{
	char Byte;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	int32_t Bit;  // 0x4(0x4)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Value : 1;  // 0x8(0x1)
	char ReturnValue;  // 0x9(0x1)
	char pad_10[2];  // 0xA(0x2)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GetClassWithName
// Size: 0x20(Inherited: 0x0) 
struct FGetClassWithName
{
	struct FString ClassName;  // 0x0(0x10)
	UObject* Class_;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool Success : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GetCurrentVolume
// Size: 0x8(Inherited: 0x0) 
struct FGetCurrentVolume
{
	int32_t Volume;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Success : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GetGenericTeamId
// Size: 0x10(Inherited: 0x0) 
struct FGetGenericTeamId
{
	struct AActor* Target;  // 0x0(0x8)
	char TeamID;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.Ps4Platform
// Size: 0x1(Inherited: 0x0) 
struct FPs4Platform
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GetKeyboardFocusedWidgetType
// Size: 0x8(Inherited: 0x0) 
struct FGetKeyboardFocusedWidgetType
{
	struct FName ReturnValue;  // 0x0(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.LessEqualStringString
// Size: 0x28(Inherited: 0x0) 
struct FLessEqualStringString
{
	struct FString A;  // 0x0(0x10)
	struct FString B;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool ReturnValue : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GetLocalToAbsoluteScale
// Size: 0x50(Inherited: 0x0) 
struct FGetLocalToAbsoluteScale
{
	struct FGeometry Geometry;  // 0x0(0x40)
	struct FVector2D ReturnValue;  // 0x40(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GetPrimaryMonitorWorkArea
// Size: 0x10(Inherited: 0x0) 
struct FGetPrimaryMonitorWorkArea
{
	int32_t X;  // 0x0(0x4)
	int32_t Y;  // 0x4(0x4)
	int32_t Width;  // 0x8(0x4)
	int32_t Height;  // 0xC(0x4)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GetProjectName
// Size: 0x10(Inherited: 0x0) 
struct FGetProjectName
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GetSplitScreenType
// Size: 0x1(Inherited: 0x0) 
struct FGetSplitScreenType
{
	uint8_t  Type;  // 0x0(0x1)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.SetWindowPosition
// Size: 0x8(Inherited: 0x0) 
struct FSetWindowPosition
{
	int32_t X;  // 0x0(0x4)
	int32_t Y;  // 0x4(0x4)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GetWindowBorderSize
// Size: 0x14(Inherited: 0x0) 
struct FGetWindowBorderSize
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Success : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	struct FMargin Margin;  // 0x4(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GetWindowBounds
// Size: 0x14(Inherited: 0x0) 
struct FGetWindowBounds
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Success : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	int32_t X;  // 0x4(0x4)
	int32_t Y;  // 0x8(0x4)
	int32_t Width;  // 0xC(0x4)
	int32_t Height;  // 0x10(0x4)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GetWindowPositionInPercentagesCentered
// Size: 0x18(Inherited: 0x0) 
struct FGetWindowPositionInPercentagesCentered
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Success : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	double X;  // 0x8(0x8)
	double Y;  // 0x10(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GetWindowMode
// Size: 0x3(Inherited: 0x0) 
struct FGetWindowMode
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Success : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool Fullscreen : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool IsFullscreenWindowed : 1;  // 0x2(0x1)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.HashcashArrayCustomCreationDate
// Size: 0x30(Inherited: 0x0) 
struct FHashcashArrayCustomCreationDate
{
	struct TArray<struct FString> Resources;  // 0x0(0x10)
	struct FDateTime UtcDate;  // 0x10(0x8)
	int32_t Bits;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct TArray<struct FString> ReturnValue;  // 0x20(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GrayscalePixels
// Size: 0x20(Inherited: 0x0) 
struct FGrayscalePixels
{
	struct TArray<struct FColor> Pixel;  // 0x0(0x10)
	struct TArray<struct FColor> ReturnValue;  // 0x10(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GreaterByteFloat
// Size: 0x18(Inherited: 0x0) 
struct FGreaterByteFloat
{
	char A;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	double B;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.SoundClass_SetVolume
// Size: 0x10(Inherited: 0x0) 
struct FSoundClass_SetVolume
{
	struct USoundClass* SoundClass;  // 0x0(0x8)
	double Volume;  // 0x8(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GreaterEqualByteFloat
// Size: 0x18(Inherited: 0x0) 
struct FGreaterEqualByteFloat
{
	char A;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	double B;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.LatentAction_Create_None
// Size: 0x8(Inherited: 0x0) 
struct FLatentAction_Create_None
{
	struct ULowEntryLatentActionNone* LatentAction;  // 0x0(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GreaterEqualFloatByte
// Size: 0x10(Inherited: 0x0) 
struct FGreaterEqualFloatByte
{
	double A;  // 0x0(0x8)
	char B;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool ReturnValue : 1;  // 0x9(0x1)
	char pad_10[6];  // 0xA(0x6)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GreaterEqualIntegerByte
// Size: 0x8(Inherited: 0x0) 
struct FGreaterEqualIntegerByte
{
	int32_t A;  // 0x0(0x4)
	char B;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool ReturnValue : 1;  // 0x5(0x1)
	char pad_6[2];  // 0x6(0x2)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GreaterEqualIntegerFloat
// Size: 0x18(Inherited: 0x0) 
struct FGreaterEqualIntegerFloat
{
	int32_t A;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	double B;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GreaterFloatByte
// Size: 0x10(Inherited: 0x0) 
struct FGreaterFloatByte
{
	double A;  // 0x0(0x8)
	char B;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool ReturnValue : 1;  // 0x9(0x1)
	char pad_10[6];  // 0xA(0x6)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GreaterIntegerFloat
// Size: 0x18(Inherited: 0x0) 
struct FGreaterIntegerFloat
{
	int32_t A;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	double B;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.GreaterStringString
// Size: 0x28(Inherited: 0x0) 
struct FGreaterStringString
{
	struct FString A;  // 0x0(0x10)
	struct FString B;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool ReturnValue : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.Hashcash
// Size: 0x28(Inherited: 0x0) 
struct FHashcash
{
	struct FString Resource;  // 0x0(0x10)
	int32_t Bits;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct FString ReturnValue;  // 0x18(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.SoundClass_GetPitch
// Size: 0x10(Inherited: 0x0) 
struct FSoundClass_GetPitch
{
	struct USoundClass* SoundClass;  // 0x0(0x8)
	double ReturnValue;  // 0x8(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.SceneCapture2DToBytes
// Size: 0x28(Inherited: 0x0) 
struct FSceneCapture2DToBytes
{
	struct ASceneCapture2D* SceneCapture2D;  // 0x0(0x8)
	uint8_t  ImageFormat;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct TArray<char> ByteArray;  // 0x10(0x10)
	int32_t CompressionQuality;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.HashcashArray
// Size: 0x28(Inherited: 0x0) 
struct FHashcashArray
{
	struct TArray<struct FString> Resources;  // 0x0(0x10)
	int32_t Bits;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct TArray<struct FString> ReturnValue;  // 0x18(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.WindowsNewlineCharacter
// Size: 0x10(Inherited: 0x0) 
struct FWindowsNewlineCharacter
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.HashcashParse
// Size: 0x18(Inherited: 0x0) 
struct FHashcashParse
{
	struct FString Hash;  // 0x0(0x10)
	struct ULowEntryParsedHashcash* ReturnValue;  // 0x10(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.HashcashParseArray
// Size: 0x20(Inherited: 0x0) 
struct FHashcashParseArray
{
	struct TArray<struct FString> Hashes;  // 0x0(0x10)
	struct TArray<struct ULowEntryParsedHashcash*> ReturnValue;  // 0x10(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.SortFloatArray
// Size: 0x28(Inherited: 0x0) 
struct FSortFloatArray
{
	struct TArray<float> FloatArray;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool Reversed : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct TArray<float> ReturnValue;  // 0x18(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.MaxOfDateTimeArray
// Size: 0x20(Inherited: 0x0) 
struct FMaxOfDateTimeArray
{
	struct TArray<struct FDateTime> DateTimeArray;  // 0x0(0x10)
	int32_t IndexOfMaxValue;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct FDateTime MaxValue;  // 0x18(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.HexToBytes
// Size: 0x20(Inherited: 0x0) 
struct FHexToBytes
{
	struct FString Hex;  // 0x0(0x10)
	struct TArray<char> ReturnValue;  // 0x10(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.HMAC
// Size: 0x40(Inherited: 0x0) 
struct FHMAC
{
	struct TArray<char> ByteArray;  // 0x0(0x10)
	struct TArray<char> Key;  // 0x10(0x10)
	uint8_t  Algorithm;  // 0x20(0x1)
	char pad_33[3];  // 0x21(0x3)
	int32_t Index;  // 0x24(0x4)
	int32_t Length;  // 0x28(0x4)
	char pad_44[4];  // 0x2C(0x4)
	struct TArray<char> ReturnValue;  // 0x30(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.LessEqualByteFloat
// Size: 0x18(Inherited: 0x0) 
struct FLessEqualByteFloat
{
	char A;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	double B;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.Html5Platform
// Size: 0x1(Inherited: 0x0) 
struct FHtml5Platform
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.LessIntegerFloat
// Size: 0x18(Inherited: 0x0) 
struct FLessIntegerFloat
{
	int32_t A;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	double B;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.IsBitSet
// Size: 0xC(Inherited: 0x0) 
struct FIsBitSet
{
	char B;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	int32_t Bit;  // 0x4(0x4)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.IsWorldRenderingEnabled
// Size: 0x2(Inherited: 0x0) 
struct FIsWorldRenderingEnabled
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Success : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool Enabled : 1;  // 0x1(0x1)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.JoinGame
// Size: 0x30(Inherited: 0x0) 
struct FJoinGame
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct FString ServerAddress;  // 0x8(0x10)
	struct FString Args;  // 0x18(0x10)
	struct APlayerController* SpecificPlayer;  // 0x28(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.RegexMatch
// Size: 0x28(Inherited: 0x0) 
struct FRegexMatch
{
	struct FString String;  // 0x0(0x10)
	struct FString Pattern;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool ReturnValue : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.LatentAction_Create_Boolean
// Size: 0x8(Inherited: 0x0) 
struct FLatentAction_Create_Boolean
{
	struct ULowEntryLatentActionBoolean* LatentAction;  // 0x0(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.LatentAction_Create_Float
// Size: 0x8(Inherited: 0x0) 
struct FLatentAction_Create_Float
{
	struct ULowEntryLatentActionFloat* LatentAction;  // 0x0(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.LatentAction_Create_Object
// Size: 0x8(Inherited: 0x0) 
struct FLatentAction_Create_Object
{
	struct ULowEntryLatentActionObject* LatentAction;  // 0x0(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.LessByteInteger
// Size: 0xC(Inherited: 0x0) 
struct FLessByteInteger
{
	char A;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	int32_t B;  // 0x4(0x4)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.LessEqualByteInteger
// Size: 0xC(Inherited: 0x0) 
struct FLessEqualByteInteger
{
	char A;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	int32_t B;  // 0x4(0x4)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.LessEqualFloatByte
// Size: 0x10(Inherited: 0x0) 
struct FLessEqualFloatByte
{
	double A;  // 0x0(0x8)
	char B;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool ReturnValue : 1;  // 0x9(0x1)
	char pad_10[6];  // 0xA(0x6)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.LessEqualFloatInteger
// Size: 0x10(Inherited: 0x0) 
struct FLessEqualFloatInteger
{
	double A;  // 0x0(0x8)
	int32_t B;  // 0x8(0x4)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool ReturnValue : 1;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.LessEqualIntegerByte
// Size: 0x8(Inherited: 0x0) 
struct FLessEqualIntegerByte
{
	int32_t A;  // 0x0(0x4)
	char B;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool ReturnValue : 1;  // 0x5(0x1)
	char pad_6[2];  // 0x6(0x2)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.LessEqualIntegerFloat
// Size: 0x18(Inherited: 0x0) 
struct FLessEqualIntegerFloat
{
	int32_t A;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	double B;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.LessFloatInteger
// Size: 0x10(Inherited: 0x0) 
struct FLessFloatInteger
{
	double A;  // 0x0(0x8)
	int32_t B;  // 0x8(0x4)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool ReturnValue : 1;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.Long_Create
// Size: 0x20(Inherited: 0x0) 
struct FLong_Create
{
	struct TArray<char> ByteArray;  // 0x0(0x10)
	int32_t Index;  // 0x10(0x4)
	int32_t Length;  // 0x14(0x4)
	struct ULowEntryLong* ReturnValue;  // 0x18(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.LongToBytes
// Size: 0x18(Inherited: 0x0) 
struct FLongToBytes
{
	int64_t Value;  // 0x0(0x8)
	struct TArray<char> ReturnValue;  // 0x8(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.MacPlatform
// Size: 0x1(Inherited: 0x0) 
struct FMacPlatform
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.MaxOfStringArray
// Size: 0x28(Inherited: 0x0) 
struct FMaxOfStringArray
{
	struct TArray<struct FString> StringArray;  // 0x0(0x10)
	int32_t IndexOfMaxValue;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct FString MaxValue;  // 0x18(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.MaxOfTimespanArray
// Size: 0x20(Inherited: 0x0) 
struct FMaxOfTimespanArray
{
	struct TArray<struct FTimespan> TimespanArray;  // 0x0(0x10)
	int32_t IndexOfMaxValue;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct FTimespan MaxValue;  // 0x18(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.MaxString
// Size: 0x30(Inherited: 0x0) 
struct FMaxString
{
	struct FString A;  // 0x0(0x10)
	struct FString B;  // 0x10(0x10)
	struct FString ReturnValue;  // 0x20(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.Md5
// Size: 0x28(Inherited: 0x0) 
struct FMd5
{
	struct TArray<char> ByteArray;  // 0x0(0x10)
	int32_t Index;  // 0x10(0x4)
	int32_t Length;  // 0x14(0x4)
	struct TArray<char> ReturnValue;  // 0x18(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.MergeBytes
// Size: 0x30(Inherited: 0x0) 
struct FMergeBytes
{
	struct TArray<char> A;  // 0x0(0x10)
	struct TArray<char> B;  // 0x10(0x10)
	struct TArray<char> ReturnValue;  // 0x20(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.MinOfDateTimeArray
// Size: 0x20(Inherited: 0x0) 
struct FMinOfDateTimeArray
{
	struct TArray<struct FDateTime> DateTimeArray;  // 0x0(0x10)
	int32_t IndexOfMinValue;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct FDateTime MinValue;  // 0x18(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.MinOfStringArray
// Size: 0x28(Inherited: 0x0) 
struct FMinOfStringArray
{
	struct TArray<struct FString> StringArray;  // 0x0(0x10)
	int32_t IndexOfMinValue;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct FString MinValue;  // 0x18(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.MinOfTimespanArray
// Size: 0x20(Inherited: 0x0) 
struct FMinOfTimespanArray
{
	struct TArray<struct FTimespan> TimespanArray;  // 0x0(0x10)
	int32_t IndexOfMinValue;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct FTimespan MinValue;  // 0x18(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.SetWindowPositiomInPercentagesCentered
// Size: 0x10(Inherited: 0x0) 
struct FSetWindowPositiomInPercentagesCentered
{
	double X;  // 0x0(0x8)
	double Y;  // 0x8(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.NextQueueExecution
// Size: 0x8(Inherited: 0x0) 
struct FNextQueueExecution
{
	struct ULowEntryExecutionQueue* Queue;  // 0x0(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.ParseStringIntoDoubleBytes
// Size: 0x18(Inherited: 0x0) 
struct FParseStringIntoDoubleBytes
{
	struct FString String;  // 0x0(0x10)
	struct ULowEntryDouble* ReturnValue;  // 0x10(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.ParseStringIntoLong
// Size: 0x18(Inherited: 0x0) 
struct FParseStringIntoLong
{
	struct FString String;  // 0x0(0x10)
	int64_t ReturnValue;  // 0x10(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.ParseStringIntoLongBytes
// Size: 0x18(Inherited: 0x0) 
struct FParseStringIntoLongBytes
{
	struct FString String;  // 0x0(0x10)
	struct ULowEntryLong* ReturnValue;  // 0x10(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.Pearson
// Size: 0x30(Inherited: 0x0) 
struct FPearson
{
	struct TArray<char> ByteArray;  // 0x0(0x10)
	int32_t HashLength;  // 0x10(0x4)
	int32_t Index;  // 0x14(0x4)
	int32_t Length;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct TArray<char> ReturnValue;  // 0x20(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.PixelsToBytes
// Size: 0x38(Inherited: 0x0) 
struct FPixelsToBytes
{
	int32_t Width;  // 0x0(0x4)
	int32_t Height;  // 0x4(0x4)
	struct TArray<struct FColor> Pixels;  // 0x8(0x10)
	uint8_t  ImageFormat;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct TArray<char> ByteArray;  // 0x20(0x10)
	int32_t CompressionQuality;  // 0x30(0x4)
	char pad_52[4];  // 0x34(0x4)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.PixelsToExistingTexture2D
// Size: 0x30(Inherited: 0x0) 
struct FPixelsToExistingTexture2D
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReusedGivenTexture2D : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct UTexture2D* Texture2D;  // 0x8(0x8)
	int32_t Width;  // 0x10(0x4)
	int32_t Height;  // 0x14(0x4)
	struct TArray<struct FColor> Pixels;  // 0x18(0x10)
	struct UTexture2D* ReturnValue;  // 0x28(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.PlayerControllerGetLocalPlayer
// Size: 0x18(Inherited: 0x0) 
struct FPlayerControllerGetLocalPlayer
{
	struct APlayerController* PlayerController;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Success : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct ULocalPlayer* LocalPlayer;  // 0x10(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.QueueExecutions
// Size: 0x28(Inherited: 0x0) 
struct FQueueExecutions
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct ULowEntryExecutionQueue* Queue;  // 0x8(0x8)
	struct FLatentActionInfo LatentInfo;  // 0x10(0x18)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.SceneCapture2D_GetFov
// Size: 0x10(Inherited: 0x0) 
struct FSceneCapture2D_GetFov
{
	struct ASceneCapture2D* SceneCapture2D;  // 0x0(0x8)
	double FOV;  // 0x8(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.RandomDelay
// Size: 0x30(Inherited: 0x0) 
struct FRandomDelay
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	double MinDuration;  // 0x8(0x8)
	double MaxDuration;  // 0x10(0x8)
	struct FLatentActionInfo LatentInfo;  // 0x18(0x18)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.RegexCount
// Size: 0x28(Inherited: 0x0) 
struct FRegexCount
{
	struct FString String;  // 0x0(0x10)
	struct FString Pattern;  // 0x10(0x10)
	int32_t ReturnValue;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.RegexReplace
// Size: 0x40(Inherited: 0x0) 
struct FRegexReplace
{
	struct FString String;  // 0x0(0x10)
	struct FString Pattern;  // 0x10(0x10)
	struct FString Replacement;  // 0x20(0x10)
	struct FString ReturnValue;  // 0x30(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.RetriggerableDelayFrames
// Size: 0x28(Inherited: 0x0) 
struct FRetriggerableDelayFrames
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	int32_t Frames;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct FLatentActionInfo LatentInfo;  // 0x10(0x18)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.RetriggerableRandomDelay
// Size: 0x30(Inherited: 0x0) 
struct FRetriggerableRandomDelay
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	double MinDuration;  // 0x8(0x8)
	double MaxDuration;  // 0x10(0x8)
	struct FLatentActionInfo LatentInfo;  // 0x18(0x18)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.RetriggerableRandomDelayFrames
// Size: 0x28(Inherited: 0x0) 
struct FRetriggerableRandomDelayFrames
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	int32_t MinFrames;  // 0x8(0x4)
	int32_t MaxFrames;  // 0xC(0x4)
	struct FLatentActionInfo LatentInfo;  // 0x10(0x18)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.SceneCapture2DToPixels
// Size: 0x20(Inherited: 0x0) 
struct FSceneCapture2DToPixels
{
	struct ASceneCapture2D* SceneCapture2D;  // 0x0(0x8)
	int32_t Width;  // 0x8(0x4)
	int32_t Height;  // 0xC(0x4)
	struct TArray<struct FColor> Pixels;  // 0x10(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.SceneCaptureComponent2D_SetFov
// Size: 0x10(Inherited: 0x0) 
struct FSceneCaptureComponent2D_SetFov
{
	struct USceneCaptureComponent2D* SceneCaptureComponent2D;  // 0x0(0x8)
	double FOV;  // 0x8(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.ServerChangeMap
// Size: 0x30(Inherited: 0x0) 
struct FServerChangeMap
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct FString Map;  // 0x8(0x10)
	struct FString Args;  // 0x18(0x10)
	struct APlayerController* SpecificPlayer;  // 0x28(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.SetMousePosition
// Size: 0x8(Inherited: 0x0) 
struct FSetMousePosition
{
	int32_t X;  // 0x0(0x4)
	int32_t Y;  // 0x4(0x4)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.SetSplitScreenEnabled
// Size: 0x1(Inherited: 0x0) 
struct FSetSplitScreenEnabled
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Enabled : 1;  // 0x0(0x1)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.Sha256
// Size: 0x28(Inherited: 0x0) 
struct FSha256
{
	struct TArray<char> ByteArray;  // 0x0(0x10)
	int32_t Index;  // 0x10(0x4)
	int32_t Length;  // 0x14(0x4)
	struct TArray<char> ReturnValue;  // 0x18(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.Sha512
// Size: 0x28(Inherited: 0x0) 
struct FSha512
{
	struct TArray<char> ByteArray;  // 0x0(0x10)
	int32_t Index;  // 0x10(0x4)
	int32_t Length;  // 0x14(0x4)
	struct TArray<char> ReturnValue;  // 0x18(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.ShippingBuild
// Size: 0x1(Inherited: 0x0) 
struct FShippingBuild
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.SortDateTimeArray
// Size: 0x28(Inherited: 0x0) 
struct FSortDateTimeArray
{
	struct TArray<struct FDateTime> DateTimeArray;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool Reversed : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct TArray<struct FDateTime> ReturnValue;  // 0x18(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.SortDoubleArray
// Size: 0x28(Inherited: 0x0) 
struct FSortDoubleArray
{
	struct TArray<double> DoubleArray;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool Reversed : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct TArray<double> ReturnValue;  // 0x18(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.SortDoubleArrayDirectly
// Size: 0x18(Inherited: 0x0) 
struct FSortDoubleArrayDirectly
{
	struct TArray<double> DoubleArray;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool Reversed : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.SortObjectArray
// Size: 0x38(Inherited: 0x0) 
struct FSortObjectArray
{
	struct TArray<struct UObject*> ObjectArray;  // 0x0(0x10)
	struct FDelegate Comparator;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool Reversed : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct TArray<struct UObject*> ReturnValue;  // 0x28(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.SortTimespanArrayDirectly
// Size: 0x18(Inherited: 0x0) 
struct FSortTimespanArrayDirectly
{
	struct TArray<struct FTimespan> TimespanArray;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool Reversed : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.SoundClass_GetVolume
// Size: 0x10(Inherited: 0x0) 
struct FSoundClass_GetVolume
{
	struct USoundClass* SoundClass;  // 0x0(0x8)
	double ReturnValue;  // 0x8(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.SoundClass_SetPitch
// Size: 0x10(Inherited: 0x0) 
struct FSoundClass_SetPitch
{
	struct USoundClass* SoundClass;  // 0x0(0x8)
	double Pitch;  // 0x8(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.StringToBytesUtf8
// Size: 0x20(Inherited: 0x0) 
struct FStringToBytesUtf8
{
	struct FString String;  // 0x0(0x10)
	struct TArray<char> ReturnValue;  // 0x10(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryLatentActionString.GetResult
// Size: 0x10(Inherited: 0x0) 
struct FGetResult
{
	struct FString Result_;  // 0x0(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.SwitchPlatform
// Size: 0x1(Inherited: 0x0) 
struct FSwitchPlatform
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.TabCharacter
// Size: 0x10(Inherited: 0x0) 
struct FTabCharacter
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.TestBuild
// Size: 0x1(Inherited: 0x0) 
struct FTestBuild
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.Texture2DToBytes
// Size: 0x28(Inherited: 0x0) 
struct FTexture2DToBytes
{
	struct UTexture2D* Texture2D;  // 0x0(0x8)
	uint8_t  ImageFormat;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct TArray<char> ByteArray;  // 0x10(0x10)
	int32_t CompressionQuality;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryParsedHashcash.GetBits
// Size: 0x4(Inherited: 0x0) 
struct FGetBits
{
	int32_t ReturnValue;  // 0x0(0x4)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.TextureRenderTarget2DToPixels
// Size: 0x20(Inherited: 0x0) 
struct FTextureRenderTarget2DToPixels
{
	struct UTextureRenderTarget2D* TextureRenderTarget2D;  // 0x0(0x8)
	int32_t Width;  // 0x8(0x4)
	int32_t Height;  // 0xC(0x4)
	struct TArray<struct FColor> Pixels;  // 0x10(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.TickFrames
// Size: 0x30(Inherited: 0x0) 
struct FTickFrames
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct FLatentActionInfo LatentInfo;  // 0x8(0x18)
	int32_t Ticks;  // 0x20(0x4)
	int32_t FramesInterval;  // 0x24(0x4)
	int32_t Tick;  // 0x28(0x4)
	char pad_44[4];  // 0x2C(0x4)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.TickSeconds
// Size: 0x38(Inherited: 0x0) 
struct FTickSeconds
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct FLatentActionInfo LatentInfo;  // 0x8(0x18)
	int32_t Ticks;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)
	double SecondsInterval;  // 0x28(0x8)
	int32_t Tick;  // 0x30(0x4)
	char pad_52[4];  // 0x34(0x4)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.Windows32Platform
// Size: 0x1(Inherited: 0x0) 
struct FWindows32Platform
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.Windows64Platform
// Size: 0x1(Inherited: 0x0) 
struct FWindows64Platform
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.WindowsPlatform
// Size: 0x1(Inherited: 0x0) 
struct FWindowsPlatform
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.WindowsRtArmPlatform
// Size: 0x1(Inherited: 0x0) 
struct FWindowsRtArmPlatform
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.WindowsRtPlatform
// Size: 0x1(Inherited: 0x0) 
struct FWindowsRtPlatform
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.WithEditor
// Size: 0x1(Inherited: 0x0) 
struct FWithEditor
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryExtendedStandardLibrary.XboxOnePlatform
// Size: 0x1(Inherited: 0x0) 
struct FXboxOnePlatform
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryLong.CastToDoubleBytes
// Size: 0x8(Inherited: 0x0) 
struct FCastToDoubleBytes
{
	struct ULowEntryDouble* ReturnValue;  // 0x0(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryLong.Integer_Equals
// Size: 0x8(Inherited: 0x0) 
struct FInteger_Equals
{
	int32_t Value;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool ReturnValue : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryParsedHashcash.GetDate
// Size: 0x8(Inherited: 0x0) 
struct FGetDate
{
	struct FDateTime ReturnValue;  // 0x0(0x8)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryParsedHashcash.GetResource
// Size: 0x10(Inherited: 0x0) 
struct FGetResource
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// Function LowEntryExtendedStandardLibrary.LowEntryParsedHashcash.ToString
// Size: 0x10(Inherited: 0x0) 
struct FToString
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
