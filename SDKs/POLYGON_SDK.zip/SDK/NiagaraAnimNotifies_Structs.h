#pragma once 
#include "SDK.h" 
 
 
// ScriptStruct NiagaraAnimNotifies.CurveParameterPair
// Size: 0x10(Inherited: 0x0) 
struct FCurveParameterPair
{
	struct FName AnimCurveName;  // 0x0(0x8)
	struct FName UserVariableName;  // 0x8(0x8)

}; 
// Function NiagaraAnimNotifies.AnimNotify_PlayNiagaraEffect.GetSpawnedEffect
// Size: 0x8(Inherited: 0x0) 
struct FGetSpawnedEffect
{
	struct UFXSystemComponent* ReturnValue;  // 0x0(0x8)

}; 
// Function NiagaraAnimNotifies.AnimNotifyState_TimedNiagaraEffectAdvanced.GetNotifyProgress
// Size: 0x10(Inherited: 0x0) 
struct FGetNotifyProgress
{
	struct UMeshComponent* MeshComp;  // 0x0(0x8)
	float ReturnValue;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)

}; 
