#pragma once 
#include <BP_Item_Accessory_DefaultAccessory_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Item_Accessory_DefaultAccessory.BP_Item_Accessory_DefaultAccessory_C
// Size: 0x350(Inherited: 0x350) 
struct ABP_Item_Accessory_DefaultAccessory_C : public AItem_Module_Accessory
{

}; 



