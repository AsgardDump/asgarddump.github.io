#pragma once 
#include "SDK.h" 
 
 
// Function BP_PG_PlayerController_Menu.BP_PG_PlayerController_Menu_C.ExecuteUbergraph_BP_PG_PlayerController_Menu
// Size: 0x68(Inherited: 0x0) 
struct FExecuteUbergraph_BP_PG_PlayerController_Menu
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UAudioComponent* CallFunc_CreateSound2D_ReturnValue;  // 0x8(0x8)
	struct UUI_Menu_GeneralMenuScreen_C* CallFunc_Create_ReturnValue;  // 0x10(0x8)
	struct FText K2Node_Event_errorMessage;  // 0x18(0x18)
	struct FText K2Node_Event_errorDetails;  // 0x30(0x18)
	struct UUI_ErrorMessage_C* CallFunc_Create_ReturnValue_2;  // 0x48(0x8)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x50(0x1)
	char pad_81[7];  // 0x51(0x7)
	struct TArray<struct ACameraActor*> CallFunc_GetAllActorsOfClass_OutActors;  // 0x58(0x10)

}; 
// Function BP_PG_PlayerController_Menu.BP_PG_PlayerController_Menu_C.SwitchCamera
// Size: 0x60(Inherited: 0x0) 
struct FSwitchCamera
{
	struct FName CameraTag;  // 0x0(0x8)
	double BlendTime;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool L_UseDarkTransition : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	double L_BlendTime;  // 0x18(0x8)
	struct ACameraActor* L_NewCamera;  // 0x20(0x8)
	struct FName L_CameraTag;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool Temp_bool_True_if_break_was_hit_Variable : 1;  // 0x30(0x1)
	char pad_49[3];  // 0x31(0x3)
	int32_t Temp_int_Array_Index_Variable;  // 0x34(0x4)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x38(0x1)
	char pad_57_1 : 7;  // 0x39(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x39(0x1)
	char pad_58[2];  // 0x3A(0x2)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x3C(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x40(0x4)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x44(0x4)
	struct ACameraActor* CallFunc_Array_Get_Item;  // 0x48(0x8)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x50(0x1)
	char pad_81_1 : 7;  // 0x51(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x51(0x1)
	char pad_82[2];  // 0x52(0x2)
	int32_t CallFunc_Array_Find_ReturnValue;  // 0x54(0x4)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool CallFunc_NotEqual_IntInt_ReturnValue : 1;  // 0x58(0x1)
	char pad_89[3];  // 0x59(0x3)
	float CallFunc_SetViewTargetWithBlend_BlendTime_ImplicitCast;  // 0x5C(0x4)

}; 
// Function BP_PG_PlayerController_Menu.BP_PG_PlayerController_Menu_C.SetVisibleHardLoadingScreen
// Size: 0x12(Inherited: 0x0) 
struct FSetVisibleHardLoadingScreen
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool IsVisible : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool L_IsVisible : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x2(0x1)
	char pad_3_1 : 7;  // 0x3(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x3(0x1)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x5(0x1)
	char pad_6[2];  // 0x6(0x2)
	struct UUI_HardLoadingScreen_C* CallFunc_Create_ReturnValue;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_2 : 1;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool CallFunc_BooleanAND_ReturnValue_2 : 1;  // 0x11(0x1)

}; 
// Function BP_PG_PlayerController_Menu.BP_PG_PlayerController_Menu_C.SetVisibleSoftLoadingScreen
// Size: 0x14(Inherited: 0x0) 
struct FSetVisibleSoftLoadingScreen
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool IsVisible : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool L_IsVisible : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x2(0x1)
	char pad_3_1 : 7;  // 0x3(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x3(0x1)
	char pad_4[4];  // 0x4(0x4)
	struct UUI_SoftLoadingScreen_C* CallFunc_Create_ReturnValue;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_2 : 1;  // 0x11(0x1)
	char pad_18_1 : 7;  // 0x12(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x12(0x1)
	char pad_19_1 : 7;  // 0x13(0x1)
	bool CallFunc_BooleanAND_ReturnValue_2 : 1;  // 0x13(0x1)

}; 
// Function BP_PG_PlayerController_Menu.BP_PG_PlayerController_Menu_C.ShowError
// Size: 0x30(Inherited: 0x30) 
struct FShowError : public FShowError
{
	struct FText ErrorMessage;  // 0x0(0x18)
	struct FText ErrorDetails;  // 0x18(0x18)

}; 
