#pragma once 
#include <BP_Item_Gear_Watch_02_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Item_Gear_Watch_02.BP_Item_Gear_Watch_02_C
// Size: 0x338(Inherited: 0x310) 
struct ABP_Item_Gear_Watch_02_C : public AItem_Watch_General
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x310(0x8)
	struct UWidgetComponent* Widget_Functional;  // 0x318(0x8)
	int32_t KillsCounter;  // 0x320(0x4)
	int32_t SavedKills;  // 0x324(0x4)
	struct UUI_Item_Gear_Watch_02_Display_C* DisplayWidget;  // 0x328(0x8)
	struct UPlayFabJsonObject* AsInventoryItem;  // 0x330(0x8)

	void OnPlayFabResponse_D4021632417204A9C90586BD0E48DBCA(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function BP_Item_Gear_Watch_02.BP_Item_Gear_Watch_02_C.OnPlayFabResponse_D4021632417204A9C90586BD0E48DBCA
	void ReceiveBeginPlay(); // Function BP_Item_Gear_Watch_02.BP_Item_Gear_Watch_02_C.ReceiveBeginPlay
	void EnableFunctional(); // Function BP_Item_Gear_Watch_02.BP_Item_Gear_Watch_02_C.EnableFunctional
	void SaveKillsProgress(); // Function BP_Item_Gear_Watch_02.BP_Item_Gear_Watch_02_C.SaveKillsProgress
	void OnAddedGameScore_Event(struct TArray<struct FScoreInfoBlueprint>& ScoreInfos); // Function BP_Item_Gear_Watch_02.BP_Item_Gear_Watch_02_C.OnAddedGameScore_Event
	void SaveWatchProgress_Success(struct FClientExecuteCloudScriptResult Result, struct UObject* customData); // Function BP_Item_Gear_Watch_02.BP_Item_Gear_Watch_02_C.SaveWatchProgress_Success
	void SaveWatchProgress_Failure(struct FPlayFabError Error, struct UObject* customData); // Function BP_Item_Gear_Watch_02.BP_Item_Gear_Watch_02_C.SaveWatchProgress_Failure
	void ExecuteUbergraph_BP_Item_Gear_Watch_02(int32_t EntryPoint); // Function BP_Item_Gear_Watch_02.BP_Item_Gear_Watch_02_C.ExecuteUbergraph_BP_Item_Gear_Watch_02
}; 



