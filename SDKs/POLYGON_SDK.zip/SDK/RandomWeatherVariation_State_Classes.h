#pragma once 
#include <RandomWeatherVariation_State_Structs.h>
 
 
 
