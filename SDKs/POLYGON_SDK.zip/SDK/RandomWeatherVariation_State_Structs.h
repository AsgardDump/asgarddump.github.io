#pragma once 
#include "SDK.h" 
 
 
// UserDefinedStruct RandomWeatherVariation_State.RandomWeatherVariation_State
// Size: 0x20(Inherited: 0x0) 
struct FRandomWeatherVariation_State
{
	struct UUDS_Weather_Settings_C* TargetRandomWeatherType_22_BBFDBC5E46C25F1DFB0037A44AB6D268;  // 0x0(0x8)
	double CurrentLerpAlpha_5_659CCE944698D027E31F1C9F648EBD85;  // 0x8(0x8)
	double CurrentTimerLength_7_6CC4C61F4528647B419BE189C0944ADF;  // 0x10(0x8)
	struct UUDS_Weather_Settings_C* LastRandomWeatherType_24_4367B1AC4E64A2564E3960B3ED6E25D8;  // 0x18(0x8)

}; 
