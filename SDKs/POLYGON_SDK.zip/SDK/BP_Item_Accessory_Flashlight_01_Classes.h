#pragma once 
#include <BP_Item_Accessory_Flashlight_01_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Item_Accessory_Flashlight_01.BP_Item_Accessory_Flashlight_01_C
// Size: 0x380(Inherited: 0x368) 
struct ABP_Item_Accessory_Flashlight_01_C : public AItem_Module_Flashlight
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x368(0x8)
	struct UParticleSystemComponent* ParticleSystem;  // 0x370(0x8)
	struct USpotLightComponent* SpotLight;  // 0x378(0x8)

	void InpActEvt_Flashlight_K2Node_InputActionEvent_1(struct FKey Key); // Function BP_Item_Accessory_Flashlight_01.BP_Item_Accessory_Flashlight_01_C.InpActEvt_Flashlight_K2Node_InputActionEvent_1
	void ReceiveBeginPlay(); // Function BP_Item_Accessory_Flashlight_01.BP_Item_Accessory_Flashlight_01_C.ReceiveBeginPlay
	void OnChangeEnableState(bool bPlaySound); // Function BP_Item_Accessory_Flashlight_01.BP_Item_Accessory_Flashlight_01_C.OnChangeEnableState
	void ExecuteUbergraph_BP_Item_Accessory_Flashlight_01(int32_t EntryPoint); // Function BP_Item_Accessory_Flashlight_01.BP_Item_Accessory_Flashlight_01_C.ExecuteUbergraph_BP_Item_Accessory_Flashlight_01
}; 



