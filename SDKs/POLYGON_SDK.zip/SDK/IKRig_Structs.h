#pragma once 
#include "SDK.h" 
 
 
// Function IKRig.IKRigComponent.SetIKRigGoalPositionAndRotation
// Size: 0x50(Inherited: 0x0) 
struct FSetIKRigGoalPositionAndRotation
{
	struct FName GoalName;  // 0x0(0x8)
	struct FVector position;  // 0x8(0x18)
	struct FQuat Rotation;  // 0x20(0x20)
	float PositionAlpha;  // 0x40(0x4)
	float RotationAlpha;  // 0x44(0x4)
	char pad_72[8];  // 0x48(0x8)

}; 
// ScriptStruct IKRig.RetargetProfile
// Size: 0x108(Inherited: 0x0) 
struct FRetargetProfile
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bApplyTargetRetargetPose : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	struct FName TargetRetargetPoseName;  // 0x4(0x8)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool bApplySourceRetargetPose : 1;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)
	struct FName SourceRetargetPoseName;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool bApplyChainSettings : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct TMap<struct FName, struct FTargetChainSettings> ChainSettings;  // 0x20(0x50)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool bApplyRootSettings : 1;  // 0x70(0x1)
	char pad_113[7];  // 0x71(0x7)
	struct FTargetRootSettings RootSettings;  // 0x78(0x68)
	char pad_224_1 : 7;  // 0xE0(0x1)
	bool bApplyGlobalSettings : 1;  // 0xE0(0x1)
	char pad_225[3];  // 0xE1(0x3)
	struct FRetargetGlobalSettings GlobalSettings;  // 0xE4(0x20)
	char pad_260[4];  // 0x104(0x4)

}; 
// ScriptStruct IKRig.TargetChainFKSettings
// Size: 0x18(Inherited: 0x0) 
struct FTargetChainFKSettings
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool EnableFK : 1;  // 0x0(0x1)
	uint8_t  RotationMode;  // 0x1(0x1)
	char pad_2[2];  // 0x2(0x2)
	float RotationAlpha;  // 0x4(0x4)
	uint8_t  TranslationMode;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	float TranslationAlpha;  // 0xC(0x4)
	float PoleVectorMatching;  // 0x10(0x4)
	float PoleVectorOffset;  // 0x14(0x4)

}; 
// ScriptStruct IKRig.RetargetGlobalSettings
// Size: 0x20(Inherited: 0x0) 
struct FRetargetGlobalSettings
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bEnableRoot : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool bEnableFK : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool bEnableIK : 1;  // 0x2(0x1)
	char pad_3_1 : 7;  // 0x3(0x1)
	bool bWarping : 1;  // 0x3(0x1)
	uint8_t  DirectionSource;  // 0x4(0x4)
	uint8_t  ForwardDirection;  // 0x8(0x4)
	struct FName DirectionChain;  // 0xC(0x8)
	float WarpForwards;  // 0x14(0x4)
	float SidewaysOffset;  // 0x18(0x4)
	float WarpSplay;  // 0x1C(0x4)

}; 
// ScriptStruct IKRig.LimbLink
// Size: 0x68(Inherited: 0x0) 
struct FLimbLink
{
	char pad_0[104];  // 0x0(0x68)

}; 
// ScriptStruct IKRig.AnimNode_RetargetPoseFromMesh
// Size: 0x258(Inherited: 0x10) 
struct FAnimNode_RetargetPoseFromMesh : public FAnimNode_Base
{
	struct TWeakObjectPtr<USkeletalMeshComponent> SourceMeshComponent;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool bUseAttachedParent : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct UIKRetargeter* IKRetargeterAsset;  // 0x20(0x8)
	struct FRetargetProfile CustomRetargetProfile;  // 0x28(0x108)
	char pad_304_1 : 7;  // 0x130(0x1)
	bool bSuppressWarnings : 1;  // 0x130(0x1)
	char pad_305_1 : 7;  // 0x131(0x1)
	bool bCopyCurves : 1;  // 0x131(0x1)
	char pad_306[6];  // 0x132(0x6)
	struct UIKRetargetProcessor* Processor;  // 0x138(0x8)
	char pad_320[280];  // 0x140(0x118)

}; 
// ScriptStruct IKRig.TargetRootSettings
// Size: 0x68(Inherited: 0x0) 
struct FTargetRootSettings
{
	float RotationAlpha;  // 0x0(0x4)
	float TranslationAlpha;  // 0x4(0x4)
	float BlendToSource;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct FVector BlendToSourceWeights;  // 0x10(0x18)
	float ScaleHorizontal;  // 0x28(0x4)
	float ScaleVertical;  // 0x2C(0x4)
	struct FVector TranslationOffset;  // 0x30(0x18)
	struct FRotator RotationOffset;  // 0x48(0x18)
	float AffectIKHorizontal;  // 0x60(0x4)
	float AffectIKVertical;  // 0x64(0x4)

}; 
// ScriptStruct IKRig.RetargetChainMap
// Size: 0x10(Inherited: 0x0) 
struct FRetargetChainMap
{
	struct FName SourceChain;  // 0x0(0x8)
	struct FName TargetChain;  // 0x8(0x8)

}; 
// ScriptStruct IKRig.TargetChainIKSettings
// Size: 0x70(Inherited: 0x0) 
struct FTargetChainIKSettings
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool EnableIK : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	float BlendToSource;  // 0x4(0x4)
	struct FVector BlendToSourceWeights;  // 0x8(0x18)
	struct FVector StaticOffset;  // 0x20(0x18)
	struct FVector StaticLocalOffset;  // 0x38(0x18)
	struct FRotator StaticRotationOffset;  // 0x50(0x18)
	float Extension;  // 0x68(0x4)
	char pad_108_1 : 7;  // 0x6C(0x1)
	bool bAffectedByIKWarping : 1;  // 0x6C(0x1)
	char pad_109[3];  // 0x6D(0x3)

}; 
// ScriptStruct IKRig.TargetChainSettings
// Size: 0xA0(Inherited: 0x0) 
struct FTargetChainSettings
{
	struct FTargetChainFKSettings FK;  // 0x0(0x18)
	struct FTargetChainIKSettings IK;  // 0x18(0x70)
	struct FTargetChainSpeedPlantSettings SpeedPlanting;  // 0x88(0x18)

}; 
// ScriptStruct IKRig.TargetChainSpeedPlantSettings
// Size: 0x18(Inherited: 0x0) 
struct FTargetChainSpeedPlantSettings
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool EnableSpeedPlanting : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	struct FName SpeedCurveName;  // 0x4(0x8)
	float SpeedThreshold;  // 0xC(0x4)
	float UnplantStiffness;  // 0x10(0x4)
	float UnplantCriticalDamping;  // 0x14(0x4)

}; 
// ScriptStruct IKRig.AnimNode_IKRig
// Size: 0x1E0(Inherited: 0x58) 
struct FAnimNode_IKRig : public FAnimNode_CustomProperty
{
	struct FPoseLink Source;  // 0x58(0x10)
	struct UIKRigDefinition* RigDefinitionAsset;  // 0x68(0x8)
	struct TArray<struct FIKRigGoal> Goals;  // 0x70(0x10)
	char pad_128_1 : 7;  // 0x80(0x1)
	bool bStartFromRefPose : 1;  // 0x80(0x1)
	uint8_t  AlphaInputType;  // 0x81(0x1)
	char pad_130_1 : 7;  // 0x82(0x1)
	bool bAlphaBoolEnabled : 1;  // 0x82(0x1)
	char pad_131[1];  // 0x83(0x1)
	float Alpha;  // 0x84(0x4)
	struct FInputScaleBias AlphaScaleBias;  // 0x88(0x8)
	struct FInputAlphaBoolBlend AlphaBoolBlend;  // 0x90(0x48)
	struct FName AlphaCurveName;  // 0xD8(0x8)
	struct FInputScaleBiasClamp AlphaScaleBiasClamp;  // 0xE0(0x30)
	struct UIKRigProcessor* IKRigProcessor;  // 0x110(0x8)
	char pad_280[192];  // 0x118(0xC0)
	float ActualAlpha;  // 0x1D8(0x4)
	char pad_476[4];  // 0x1DC(0x4)

}; 
// ScriptStruct IKRig.IKRigGoal
// Size: 0xA0(Inherited: 0x0) 
struct FIKRigGoal
{
	struct FName Name;  // 0x0(0x8)
	uint8_t  TransformSource;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	struct FBoneReference SourceBone;  // 0xC(0x10)
	char pad_28[4];  // 0x1C(0x4)
	struct FVector position;  // 0x20(0x18)
	struct FRotator Rotation;  // 0x38(0x18)
	float PositionAlpha;  // 0x50(0x4)
	float RotationAlpha;  // 0x54(0x4)
	uint8_t  PositionSpace;  // 0x58(0x1)
	uint8_t  RotationSpace;  // 0x59(0x1)
	char pad_90[6];  // 0x5A(0x6)
	struct FVector FinalBlendedPosition;  // 0x60(0x18)
	char pad_120[8];  // 0x78(0x8)
	struct FQuat FinalBlendedRotation;  // 0x80(0x20)

}; 
// ScriptStruct IKRig.IKRigGoalContainer
// Size: 0x10(Inherited: 0x0) 
struct FIKRigGoalContainer
{
	char pad_0[16];  // 0x0(0x10)

}; 
// ScriptStruct IKRig.BoneChain
// Size: 0x30(Inherited: 0x0) 
struct FBoneChain
{
	struct FName ChainName;  // 0x0(0x8)
	struct FBoneReference StartBone;  // 0x8(0x10)
	struct FBoneReference EndBone;  // 0x18(0x10)
	struct FName IKGoalName;  // 0x28(0x8)

}; 
// Function IKRig.IKGoalCreatorInterface.AddIKGoals
// Size: 0x50(Inherited: 0x0) 
struct FAddIKGoals
{
	struct TMap<struct FName, struct FIKRigGoal> OutGoals;  // 0x0(0x50)

}; 
// ScriptStruct IKRig.RetargetDefinition
// Size: 0x18(Inherited: 0x0) 
struct FRetargetDefinition
{
	struct FName RootBone;  // 0x0(0x8)
	struct TArray<struct FBoneChain> BoneChains;  // 0x8(0x10)

}; 
// ScriptStruct IKRig.GoalBone
// Size: 0x10(Inherited: 0x0) 
struct FGoalBone
{
	char pad_0[16];  // 0x0(0x10)

}; 
// ScriptStruct IKRig.IKRigInputSkeleton
// Size: 0x38(Inherited: 0x0) 
struct FIKRigInputSkeleton
{
	char pad_0[56];  // 0x0(0x38)

}; 
// ScriptStruct IKRig.IKRigSkeleton
// Size: 0x70(Inherited: 0x0) 
struct FIKRigSkeleton
{
	struct TArray<struct FName> BoneNames;  // 0x0(0x10)
	struct TArray<int32_t> ParentIndices;  // 0x10(0x10)
	struct TArray<struct FName> ExcludedBones;  // 0x20(0x10)
	struct TArray<struct FTransform> CurrentPoseGlobal;  // 0x30(0x10)
	struct TArray<struct FTransform> CurrentPoseLocal;  // 0x40(0x10)
	struct TArray<struct FTransform> RefPoseGlobal;  // 0x50(0x10)
	char pad_96[16];  // 0x60(0x10)

}; 
// ScriptStruct IKRig.IKRetargetPose
// Size: 0x68(Inherited: 0x0) 
struct FIKRetargetPose
{
	struct FVector RootTranslationOffset;  // 0x0(0x18)
	struct TMap<struct FName, struct FQuat> BoneRotationOffsets;  // 0x18(0x50)

}; 
// ScriptStruct IKRig.LimbSolverSettings
// Size: 0x24(Inherited: 0x0) 
struct FLimbSolverSettings
{
	float ReachPrecision;  // 0x0(0x4)
	char EAxis HingeRotationAxis;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	int32_t MaxIterations;  // 0x8(0x4)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool bEnableLimit : 1;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)
	float MinRotationAngle;  // 0x10(0x4)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool bAveragePull : 1;  // 0x14(0x1)
	char pad_21[3];  // 0x15(0x3)
	float PullDistribution;  // 0x18(0x4)
	float ReachStepAlpha;  // 0x1C(0x4)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool bEnableTwistCorrection : 1;  // 0x20(0x1)
	char EAxis EndBoneForwardAxis;  // 0x21(0x1)
	char pad_34[2];  // 0x22(0x2)

}; 
// ScriptStruct IKRig.LimbSolver
// Size: 0x18(Inherited: 0x0) 
struct FLimbSolver
{
	char pad_0[24];  // 0x0(0x18)

}; 
// Function IKRig.IKRigComponent.SetIKRigGoal
// Size: 0xA0(Inherited: 0x0) 
struct FSetIKRigGoal
{
	struct FIKRigGoal Goal;  // 0x0(0xA0)

}; 
// Function IKRig.IKRigComponent.SetIKRigGoalTransform
// Size: 0x80(Inherited: 0x0) 
struct FSetIKRigGoalTransform
{
	struct FName GoalName;  // 0x0(0x8)
	char pad_8[8];  // 0x8(0x8)
	struct FTransform Transform;  // 0x10(0x60)
	float PositionAlpha;  // 0x70(0x4)
	float RotationAlpha;  // 0x74(0x4)
	char pad_120[8];  // 0x78(0x8)

}; 
// Function IKRig.IKRetargeter.GetChainSettingsFromRetargetAsset
// Size: 0xB8(Inherited: 0x0) 
struct FGetChainSettingsFromRetargetAsset
{
	struct UIKRetargeter* RetargetAsset;  // 0x0(0x8)
	struct FName TargetChainName;  // 0x8(0x8)
	struct FName OptionalProfileName;  // 0x10(0x8)
	struct FTargetChainSettings ReturnValue;  // 0x18(0xA0)

}; 
// Function IKRig.IKRetargeter.GetChainSettingsFromRetargetProfile
// Size: 0x1B0(Inherited: 0x0) 
struct FGetChainSettingsFromRetargetProfile
{
	struct FRetargetProfile RetargetProfile;  // 0x0(0x108)
	struct FName TargetChainName;  // 0x108(0x8)
	struct FTargetChainSettings ReturnValue;  // 0x110(0xA0)

}; 
// Function IKRig.IKRetargeter.GetChainUsingGoalFromRetargetAsset
// Size: 0xB0(Inherited: 0x0) 
struct FGetChainUsingGoalFromRetargetAsset
{
	struct UIKRetargeter* RetargetAsset;  // 0x0(0x8)
	struct FName IKGoalName;  // 0x8(0x8)
	struct FTargetChainSettings ReturnValue;  // 0x10(0xA0)

}; 
// Function IKRig.IKRetargeter.GetGlobalSettingsFromRetargetAsset
// Size: 0x30(Inherited: 0x0) 
struct FGetGlobalSettingsFromRetargetAsset
{
	struct UIKRetargeter* RetargetAsset;  // 0x0(0x8)
	struct FName OptionalProfileName;  // 0x8(0x8)
	struct FRetargetGlobalSettings OutSettings;  // 0x10(0x20)

}; 
// Function IKRig.IKRetargeter.GetGlobalSettingsFromRetargetProfile
// Size: 0x128(Inherited: 0x0) 
struct FGetGlobalSettingsFromRetargetProfile
{
	struct FRetargetProfile RetargetProfile;  // 0x0(0x108)
	struct FRetargetGlobalSettings ReturnValue;  // 0x108(0x20)

}; 
// Function IKRig.IKRetargeter.GetRootSettingsFromRetargetAsset
// Size: 0x78(Inherited: 0x0) 
struct FGetRootSettingsFromRetargetAsset
{
	struct UIKRetargeter* RetargetAsset;  // 0x0(0x8)
	struct FName OptionalProfileName;  // 0x8(0x8)
	struct FTargetRootSettings OutSettings;  // 0x10(0x68)

}; 
// Function IKRig.IKRetargeter.GetRootSettingsFromRetargetProfile
// Size: 0x170(Inherited: 0x0) 
struct FGetRootSettingsFromRetargetProfile
{
	struct FRetargetProfile RetargetProfile;  // 0x0(0x108)
	struct FTargetRootSettings ReturnValue;  // 0x108(0x68)

}; 
// Function IKRig.IKRetargeter.SetChainFKSettingsInRetargetProfile
// Size: 0x128(Inherited: 0x0) 
struct FSetChainFKSettingsInRetargetProfile
{
	struct FRetargetProfile RetargetProfile;  // 0x0(0x108)
	struct FTargetChainFKSettings FKSettings;  // 0x108(0x18)
	struct FName TargetChainName;  // 0x120(0x8)

}; 
// Function IKRig.IKRetargeter.SetChainSpeedPlantSettingsInRetargetProfile
// Size: 0x128(Inherited: 0x0) 
struct FSetChainSpeedPlantSettingsInRetargetProfile
{
	struct FRetargetProfile RetargetProfile;  // 0x0(0x108)
	struct FTargetChainSpeedPlantSettings SpeedPlantSettings;  // 0x108(0x18)
	struct FName TargetChainName;  // 0x120(0x8)

}; 
// Function IKRig.IKRetargeter.SetChainIKSettingsInRetargetProfile
// Size: 0x180(Inherited: 0x0) 
struct FSetChainIKSettingsInRetargetProfile
{
	struct FRetargetProfile RetargetProfile;  // 0x0(0x108)
	struct FTargetChainIKSettings IKSettings;  // 0x108(0x70)
	struct FName TargetChainName;  // 0x178(0x8)

}; 
// Function IKRig.IKRetargeter.SetChainSettingsInRetargetProfile
// Size: 0x1B0(Inherited: 0x0) 
struct FSetChainSettingsInRetargetProfile
{
	struct FRetargetProfile RetargetProfile;  // 0x0(0x108)
	struct FTargetChainSettings ChainSettings;  // 0x108(0xA0)
	struct FName TargetChainName;  // 0x1A8(0x8)

}; 
// Function IKRig.IKRetargeter.SetGlobalSettingsInRetargetProfile
// Size: 0x128(Inherited: 0x0) 
struct FSetGlobalSettingsInRetargetProfile
{
	struct FRetargetProfile RetargetProfile;  // 0x0(0x108)
	struct FRetargetGlobalSettings GlobalSettings;  // 0x108(0x20)

}; 
// Function IKRig.IKRetargeter.SetRootSettingsInRetargetProfile
// Size: 0x170(Inherited: 0x0) 
struct FSetRootSettingsInRetargetProfile
{
	struct FRetargetProfile RetargetProfile;  // 0x0(0x108)
	struct FTargetRootSettings RootSettings;  // 0x108(0x68)

}; 
