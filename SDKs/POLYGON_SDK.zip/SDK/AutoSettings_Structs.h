#pragma once 
#include "SDK.h" 
 
 
// Function AutoSettings.ConsoleUtils.GetStringCVar
// Size: 0x18(Inherited: 0x0) 
struct FGetStringCVar
{
	struct FName Name;  // 0x0(0x8)
	struct FString ReturnValue;  // 0x8(0x10)

}; 
// DelegateFunction AutoSettings.OnSettingSaved__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FOnSettingSaved__DelegateSignature
{
	struct FAutoSettingData SettingData;  // 0x0(0x38)

}; 
// DelegateFunction AutoSettings.FloatCVarChangedEvent__DelegateSignature
// Size: 0x4(Inherited: 0x0) 
struct FFloatCVarChangedEvent__DelegateSignature
{
	float NewValue;  // 0x0(0x4)

}; 
// Function AutoSettings.RadioSelect.ButtonSelected
// Size: 0x10(Inherited: 0x0) 
struct FButtonSelected
{
	struct FString Value;  // 0x0(0x10)

}; 
// DelegateFunction AutoSettings.BoolCVarChangedEvent__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FBoolCVarChangedEvent__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool NewValue : 1;  // 0x0(0x1)

}; 
// DelegateFunction AutoSettings.FloatCVarChangedSignature__DelegateSignature
// Size: 0x4(Inherited: 0x0) 
struct FFloatCVarChangedSignature__DelegateSignature
{
	float NewValue;  // 0x0(0x4)

}; 
// Function AutoSettings.AutoSettingWidget.ApplySettingValue
// Size: 0x18(Inherited: 0x0) 
struct FApplySettingValue
{
	struct FString Value;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bSaveIfPossible : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function AutoSettings.SliderSetting.NormalizedValueToRaw
// Size: 0x8(Inherited: 0x0) 
struct FNormalizedValueToRaw
{
	float NormalizedValue;  // 0x0(0x4)
	float ReturnValue;  // 0x4(0x4)

}; 
// ScriptStruct AutoSettings.SettingOption
// Size: 0x28(Inherited: 0x0) 
struct FSettingOption
{
	struct FText Label;  // 0x0(0x18)
	struct FString Value;  // 0x18(0x10)

}; 
// Function AutoSettings.CVarChangeListenerManager.AddStringCVarCallbackStatic
// Size: 0x1C(Inherited: 0x0) 
struct FAddStringCVarCallbackStatic
{
	struct FName Name;  // 0x0(0x8)
	struct FDelegate ChangedCallback;  // 0x8(0x10)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallbackImmediately : 1;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)

}; 
// DelegateFunction AutoSettings.BoolCVarChangedSignature__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FBoolCVarChangedSignature__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool NewValue : 1;  // 0x0(0x1)

}; 
// DelegateFunction AutoSettings.IntCVarChangedEvent__DelegateSignature
// Size: 0x4(Inherited: 0x0) 
struct FIntCVarChangedEvent__DelegateSignature
{
	int32_t NewValue;  // 0x0(0x4)

}; 
// Function AutoSettings.RadioButton.SetLabel
// Size: 0x18(Inherited: 0x0) 
struct FSetLabel
{
	struct FText InLabel;  // 0x0(0x18)

}; 
// DelegateFunction AutoSettings.IntCVarChangedSignature__DelegateSignature
// Size: 0x4(Inherited: 0x0) 
struct FIntCVarChangedSignature__DelegateSignature
{
	int32_t NewValue;  // 0x0(0x4)

}; 
// ScriptStruct AutoSettings.AutoSettingData
// Size: 0x38(Inherited: 0x0) 
struct FAutoSettingData
{
	struct FName Key;  // 0x0(0x8)
	struct FString Value;  // 0x8(0x10)
	struct FGameplayTagContainer Tags;  // 0x18(0x20)

}; 
// DelegateFunction AutoSettings.RadioSelectedSignature__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FRadioSelectedSignature__DelegateSignature
{
	struct FString Value;  // 0x0(0x10)

}; 
// Function AutoSettings.SettingContainerUtils.ApplyChildSettings
// Size: 0x10(Inherited: 0x0) 
struct FApplyChildSettings
{
	struct UUserWidget* UserWidget;  // 0x0(0x8)
	struct UWidget* Parent;  // 0x8(0x8)

}; 
// Function AutoSettings.CVarChangeListenerManager.AddIntCVarCallbackStatic
// Size: 0x1C(Inherited: 0x0) 
struct FAddIntCVarCallbackStatic
{
	struct FName Name;  // 0x0(0x8)
	struct FDelegate ChangedCallback;  // 0x8(0x10)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallbackImmediately : 1;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)

}; 
// Function AutoSettings.CVarChangeListenerManager.AddFloatCVarCallbackStatic
// Size: 0x1C(Inherited: 0x0) 
struct FAddFloatCVarCallbackStatic
{
	struct FName Name;  // 0x0(0x8)
	struct FDelegate ChangedCallback;  // 0x8(0x10)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallbackImmediately : 1;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)

}; 
// DelegateFunction AutoSettings.SpinnerSelectionChanged__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FSpinnerSelectionChanged__DelegateSignature
{
	struct FString Value;  // 0x0(0x10)

}; 
// DelegateFunction AutoSettings.StringCVarChangedEvent__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FStringCVarChangedEvent__DelegateSignature
{
	struct FString NewValue;  // 0x0(0x10)

}; 
// Function AutoSettings.AutoSettingWidget.HasUnsavedChange
// Size: 0x1(Inherited: 0x0) 
struct FHasUnsavedChange
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function AutoSettings.RadioSelect.GetOptions
// Size: 0x10(Inherited: 0x0) 
struct FGetOptions
{
	struct TArray<struct FSettingOption> ReturnValue;  // 0x0(0x10)

}; 
// DelegateFunction AutoSettings.StringCVarChangedSignature__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FStringCVarChangedSignature__DelegateSignature
{
	struct FString NewValue;  // 0x0(0x10)

}; 
// Function AutoSettings.AutoSettingWidget.HasUnappliedChange
// Size: 0x1(Inherited: 0x0) 
struct FHasUnappliedChange
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function AutoSettings.AutoSettingWidget.UpdateSelection
// Size: 0x10(Inherited: 0x0) 
struct FUpdateSelection
{
	struct FString Value;  // 0x0(0x10)

}; 
// Function AutoSettings.ToggleSetting.ToggleStateUpdated
// Size: 0x1(Inherited: 0x0) 
struct FToggleStateUpdated
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool State : 1;  // 0x0(0x1)

}; 
// Function AutoSettings.ConsoleUtils.SetBoolCVar
// Size: 0xC(Inherited: 0x0) 
struct FSetBoolCVar
{
	struct FName Name;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Value : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)

}; 
// Function AutoSettings.ToggleSetting.UpdateToggleState
// Size: 0x1(Inherited: 0x0) 
struct FUpdateToggleState
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool State : 1;  // 0x0(0x1)

}; 
// Function AutoSettings.ConsoleUtils.IsCVarRegistered
// Size: 0xC(Inherited: 0x0) 
struct FIsCVarRegistered
{
	struct FName Name;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)

}; 
// Function AutoSettings.CheckBoxSetting.CheckBoxStateChanged
// Size: 0x1(Inherited: 0x0) 
struct FCheckBoxStateChanged
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool IsChecked : 1;  // 0x0(0x1)

}; 
// Function AutoSettings.SelectSetting.UpdateOptions
// Size: 0x10(Inherited: 0x0) 
struct FUpdateOptions
{
	struct TArray<struct FSettingOption> InOptions;  // 0x0(0x10)

}; 
// Function AutoSettings.ConsoleUtils.SetStringCVar
// Size: 0x18(Inherited: 0x0) 
struct FSetStringCVar
{
	struct FName Name;  // 0x0(0x8)
	struct FString Value;  // 0x8(0x10)

}; 
// Function AutoSettings.ComboBoxSetting.ComboBoxSelectionChanged
// Size: 0x18(Inherited: 0x0) 
struct FComboBoxSelectionChanged
{
	struct FString SelectedItem;  // 0x0(0x10)
	char ESelectInfo SelectionType;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function AutoSettings.ConsoleUtils.GetBoolCVar
// Size: 0xC(Inherited: 0x0) 
struct FGetBoolCVar
{
	struct FName Name;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)

}; 
// Function AutoSettings.ConsoleUtils.GetFloatCVar
// Size: 0xC(Inherited: 0x0) 
struct FGetFloatCVar
{
	struct FName Name;  // 0x0(0x8)
	float ReturnValue;  // 0x8(0x4)

}; 
// Function AutoSettings.ConsoleUtils.GetIntCVar
// Size: 0xC(Inherited: 0x0) 
struct FGetIntCVar
{
	struct FName Name;  // 0x0(0x8)
	int32_t ReturnValue;  // 0x8(0x4)

}; 
// Function AutoSettings.SliderSetting.OnSliderValueUpdated
// Size: 0x8(Inherited: 0x0) 
struct FOnSliderValueUpdated
{
	float NormalizedValue;  // 0x0(0x4)
	float RawValue;  // 0x4(0x4)

}; 
// Function AutoSettings.ConsoleUtils.SetFloatCVar
// Size: 0xC(Inherited: 0x0) 
struct FSetFloatCVar
{
	struct FName Name;  // 0x0(0x8)
	float Value;  // 0x8(0x4)

}; 
// Function AutoSettings.ConsoleUtils.SetIntCVar
// Size: 0xC(Inherited: 0x0) 
struct FSetIntCVar
{
	struct FName Name;  // 0x0(0x8)
	int32_t Value;  // 0x8(0x4)

}; 
// Function AutoSettings.SettingsManager.ApplySettingStatic
// Size: 0x38(Inherited: 0x0) 
struct FApplySettingStatic
{
	struct FAutoSettingData SettingData;  // 0x0(0x38)

}; 
// Function AutoSettings.CVarChangeListenerManager.AddBoolCVarCallbackStatic
// Size: 0x1C(Inherited: 0x0) 
struct FAddBoolCVarCallbackStatic
{
	struct FName Name;  // 0x0(0x8)
	struct FDelegate ChangedCallback;  // 0x8(0x10)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallbackImmediately : 1;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)

}; 
// Function AutoSettings.SliderSetting.ClampRawValue
// Size: 0x8(Inherited: 0x0) 
struct FClampRawValue
{
	float RawValue;  // 0x0(0x4)
	float ReturnValue;  // 0x4(0x4)

}; 
// Function AutoSettings.RadioButton.GetSelected
// Size: 0x1(Inherited: 0x0) 
struct FGetSelected
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function AutoSettings.SettingsManager.RegisterStringCVarSettingWithCallback
// Size: 0x40(Inherited: 0x0) 
struct FRegisterStringCVarSettingWithCallback
{
	struct FName Name;  // 0x0(0x8)
	struct FString DefaultValue;  // 0x8(0x10)
	struct FString Help;  // 0x18(0x10)
	struct FDelegate ChangedCallback;  // 0x28(0x10)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool CallbackImmediately : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)

}; 
// Function AutoSettings.SliderSetting.RawValueToNormalized
// Size: 0x8(Inherited: 0x0) 
struct FRawValueToNormalized
{
	float RawValue;  // 0x0(0x4)
	float ReturnValue;  // 0x4(0x4)

}; 
// Function AutoSettings.SliderSetting.ShouldSaveCurrentValue
// Size: 0x1(Inherited: 0x0) 
struct FShouldSaveCurrentValue
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function AutoSettings.SliderSetting.SliderValueUpdated
// Size: 0x4(Inherited: 0x0) 
struct FSliderValueUpdated
{
	float NormalizedValue;  // 0x0(0x4)

}; 
// Function AutoSettings.SliderSetting.UpdateSliderValue
// Size: 0x8(Inherited: 0x0) 
struct FUpdateSliderValue
{
	float NormalizedValue;  // 0x0(0x4)
	float RawValue;  // 0x4(0x4)

}; 
// Function AutoSettings.NativeSliderSetting.SliderValueChanged
// Size: 0x4(Inherited: 0x0) 
struct FSliderValueChanged
{
	float NewValue;  // 0x0(0x4)

}; 
// Function AutoSettings.RadioButton.GetLabel
// Size: 0x18(Inherited: 0x0) 
struct FGetLabel
{
	struct FText ReturnValue;  // 0x0(0x18)

}; 
// Function AutoSettings.SettingsManager.GetValue
// Size: 0x20(Inherited: 0x0) 
struct FGetValue
{
	struct FName Key;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bPreferConfigValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct FString ReturnValue;  // 0x10(0x10)

}; 
// Function AutoSettings.SettingContainerUtils.DoesAnyChildSettingHaveUnappliedChange
// Size: 0x18(Inherited: 0x0) 
struct FDoesAnyChildSettingHaveUnappliedChange
{
	struct UUserWidget* UserWidget;  // 0x0(0x8)
	struct UWidget* Parent;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function AutoSettings.RadioButton.SetSelected
// Size: 0x1(Inherited: 0x0) 
struct FSetSelected
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool InSelected : 1;  // 0x0(0x1)

}; 
// Function AutoSettings.RadioButton.SetValue
// Size: 0x10(Inherited: 0x0) 
struct FSetValue
{
	struct FString InValue;  // 0x0(0x10)

}; 
// Function AutoSettings.RadioButton.UpdateLabel
// Size: 0x18(Inherited: 0x0) 
struct FUpdateLabel
{
	struct FText InLabel;  // 0x0(0x18)

}; 
// Function AutoSettings.RadioButton.UpdateSelected
// Size: 0x1(Inherited: 0x0) 
struct FUpdateSelected
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool InSelected : 1;  // 0x0(0x1)

}; 
// Function AutoSettings.SettingsManager.RegisterFloatCVarSettingWithCallback
// Size: 0x38(Inherited: 0x0) 
struct FRegisterFloatCVarSettingWithCallback
{
	struct FName Name;  // 0x0(0x8)
	float DefaultValue;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct FString Help;  // 0x10(0x10)
	struct FDelegate ChangedCallback;  // 0x20(0x10)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallbackImmediately : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)

}; 
// Function AutoSettings.RadioSelect.GetRadioButtonWidgets
// Size: 0x10(Inherited: 0x0) 
struct FGetRadioButtonWidgets
{
	struct TArray<struct URadioButton*> ReturnValue;  // 0x0(0x10)

}; 
// Function AutoSettings.RadioSelect.OnButtonCreated
// Size: 0x10(Inherited: 0x0) 
struct FOnButtonCreated
{
	struct URadioButton* Button;  // 0x0(0x8)
	struct UPanelSlot* NewSlot;  // 0x8(0x8)

}; 
// Function AutoSettings.RadioSelect.Select
// Size: 0x10(Inherited: 0x0) 
struct FSelect
{
	struct FString Value;  // 0x0(0x10)

}; 
// Function AutoSettings.RadioSelect.SetOptions
// Size: 0x10(Inherited: 0x0) 
struct FSetOptions
{
	struct TArray<struct FSettingOption> InOptions;  // 0x0(0x10)

}; 
// Function AutoSettings.SettingContainerUtils.CancelChildSettings
// Size: 0x10(Inherited: 0x0) 
struct FCancelChildSettings
{
	struct UUserWidget* UserWidget;  // 0x0(0x8)
	struct UWidget* Parent;  // 0x8(0x8)

}; 
// Function AutoSettings.SettingValueMask.MaskValue
// Size: 0x20(Inherited: 0x0) 
struct FMaskValue
{
	struct FString ConsoleValue;  // 0x0(0x10)
	struct FString ReturnValue;  // 0x10(0x10)

}; 
// Function AutoSettings.RadioSelectSetting.RadioSelectionChanged
// Size: 0x10(Inherited: 0x0) 
struct FRadioSelectionChanged
{
	struct FString Value;  // 0x0(0x10)

}; 
// Function AutoSettings.SettingOptionFactory.ConstructOptions
// Size: 0x10(Inherited: 0x0) 
struct FConstructOptions
{
	struct TArray<struct FSettingOption> ReturnValue;  // 0x0(0x10)

}; 
// Function AutoSettings.SettingValueMask.RecombineValues
// Size: 0x30(Inherited: 0x0) 
struct FRecombineValues
{
	struct FString SettingValue;  // 0x0(0x10)
	struct FString ConsoleValue;  // 0x10(0x10)
	struct FString ReturnValue;  // 0x20(0x10)

}; 
// Function AutoSettings.SettingContainerUtils.DoesAnyChildSettingHaveUnsavedChange
// Size: 0x18(Inherited: 0x0) 
struct FDoesAnyChildSettingHaveUnsavedChange
{
	struct UUserWidget* UserWidget;  // 0x0(0x8)
	struct UWidget* Parent;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function AutoSettings.SettingContainerUtils.GetChildSettings
// Size: 0x20(Inherited: 0x0) 
struct FGetChildSettings
{
	struct UUserWidget* UserWidget;  // 0x0(0x8)
	struct UWidget* Parent;  // 0x8(0x8)
	struct TArray<struct UAutoSettingWidget*> ReturnValue;  // 0x10(0x10)

}; 
// Function AutoSettings.SettingContainerUtils.SaveChildSettings
// Size: 0x10(Inherited: 0x0) 
struct FSaveChildSettings
{
	struct UUserWidget* UserWidget;  // 0x0(0x8)
	struct UWidget* Parent;  // 0x8(0x8)

}; 
// Function AutoSettings.SettingsManager.AutoDetectSettingsStatic
// Size: 0xC(Inherited: 0x0) 
struct FAutoDetectSettingsStatic
{
	int32_t WorkScale;  // 0x0(0x4)
	float CPUMultiplier;  // 0x4(0x4)
	float GPUMultiplier;  // 0x8(0x4)

}; 
// Function AutoSettings.SettingsManager.RegisterBoolCVarSetting
// Size: 0x20(Inherited: 0x0) 
struct FRegisterBoolCVarSetting
{
	struct FName Name;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool DefaultValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct FString Help;  // 0x10(0x10)

}; 
// Function AutoSettings.SettingsManager.RegisterBoolCVarSettingWithCallback
// Size: 0x38(Inherited: 0x0) 
struct FRegisterBoolCVarSettingWithCallback
{
	struct FName Name;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool DefaultValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct FString Help;  // 0x10(0x10)
	struct FDelegate ChangedCallback;  // 0x20(0x10)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallbackImmediately : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)

}; 
// Function AutoSettings.SettingsManager.RegisterFloatCVarSetting
// Size: 0x20(Inherited: 0x0) 
struct FRegisterFloatCVarSetting
{
	struct FName Name;  // 0x0(0x8)
	float DefaultValue;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct FString Help;  // 0x10(0x10)

}; 
// Function AutoSettings.SettingsManager.RegisterIntCVarSetting
// Size: 0x20(Inherited: 0x0) 
struct FRegisterIntCVarSetting
{
	struct FName Name;  // 0x0(0x8)
	int32_t DefaultValue;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct FString Help;  // 0x10(0x10)

}; 
// Function AutoSettings.SettingsManager.RegisterIntCVarSettingWithCallback
// Size: 0x38(Inherited: 0x0) 
struct FRegisterIntCVarSettingWithCallback
{
	struct FName Name;  // 0x0(0x8)
	int32_t DefaultValue;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct FString Help;  // 0x10(0x10)
	struct FDelegate ChangedCallback;  // 0x20(0x10)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallbackImmediately : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)

}; 
// Function AutoSettings.SettingsManager.RegisterStringCVarSetting
// Size: 0x28(Inherited: 0x0) 
struct FRegisterStringCVarSetting
{
	struct FName Name;  // 0x0(0x8)
	struct FString DefaultValue;  // 0x8(0x10)
	struct FString Help;  // 0x18(0x10)

}; 
// Function AutoSettings.SettingsManager.SaveSettingStatic
// Size: 0x38(Inherited: 0x0) 
struct FSaveSettingStatic
{
	struct FAutoSettingData SettingData;  // 0x0(0x38)

}; 
// Function AutoSettings.Spinner.GetCurrentIndex
// Size: 0x4(Inherited: 0x0) 
struct FGetCurrentIndex
{
	int32_t ReturnValue;  // 0x0(0x4)

}; 
// Function AutoSettings.Spinner.GetCurrentOption
// Size: 0x28(Inherited: 0x0) 
struct FGetCurrentOption
{
	struct FSettingOption ReturnValue;  // 0x0(0x28)

}; 
// Function AutoSettings.Spinner.HasValidNext
// Size: 0x1(Inherited: 0x0) 
struct FHasValidNext
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function AutoSettings.Spinner.HasValidPrevious
// Size: 0x1(Inherited: 0x0) 
struct FHasValidPrevious
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function AutoSettings.Spinner.OnSelectionChanged
// Size: 0x28(Inherited: 0x0) 
struct FOnSelectionChanged
{
	struct FSettingOption SelectedOption;  // 0x0(0x28)

}; 
// Function AutoSettings.Spinner.SelectIndex
// Size: 0x4(Inherited: 0x0) 
struct FSelectIndex
{
	int32_t Index;  // 0x0(0x4)

}; 
// Function AutoSettings.Spinner.SelectValue
// Size: 0x10(Inherited: 0x0) 
struct FSelectValue
{
	struct FString Value;  // 0x0(0x10)

}; 
// Function AutoSettings.SpinnerSetting.SpinnerSelectionChanged
// Size: 0x10(Inherited: 0x0) 
struct FSpinnerSelectionChanged
{
	struct FString Value;  // 0x0(0x10)

}; 
