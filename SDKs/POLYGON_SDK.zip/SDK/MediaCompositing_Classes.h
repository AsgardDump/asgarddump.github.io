#pragma once 
#include <MediaCompositing_Structs.h>
 
 
 
// Class MediaCompositing.MovieSceneMediaSection
// Size: 0x130(Inherited: 0xF0) 
struct UMovieSceneMediaSection : public UMovieSceneSection
{
	struct UMediaSource* MediaSource;  // 0xF0(0x8)
	char pad_248_1 : 7;  // 0xF8(0x1)
	bool bLooping : 1;  // 0xF8(0x1)
	char pad_249[3];  // 0xF9(0x3)
	struct FFrameNumber StartFrameOffset;  // 0xFC(0x4)
	struct UMediaTexture* MediaTexture;  // 0x100(0x8)
	struct UMediaSoundComponent* MediaSoundComponent;  // 0x108(0x8)
	char pad_272_1 : 7;  // 0x110(0x1)
	bool bUseExternalMediaPlayer : 1;  // 0x110(0x1)
	char pad_273[7];  // 0x111(0x7)
	struct UMediaPlayer* ExternalMediaPlayer;  // 0x118(0x8)
	struct FMediaSourceCacheSettings CacheSettings;  // 0x120(0x8)
	char pad_296_1 : 7;  // 0x128(0x1)
	bool bHasMediaPlayerProxy : 1;  // 0x128(0x1)
	char pad_297[7];  // 0x129(0x7)

}; 



// Class MediaCompositing.MovieSceneMediaPlayerPropertySection
// Size: 0x100(Inherited: 0xF0) 
struct UMovieSceneMediaPlayerPropertySection : public UMovieSceneSection
{
	struct UMediaSource* MediaSource;  // 0xF0(0x8)
	char pad_248_1 : 7;  // 0xF8(0x1)
	bool bLoop : 1;  // 0xF8(0x1)
	char pad_249[7];  // 0xF9(0x7)

}; 



// Class MediaCompositing.MovieSceneMediaPlayerPropertyTrack
// Size: 0xD0(Inherited: 0xC8) 
struct UMovieSceneMediaPlayerPropertyTrack : public UMovieScenePropertyTrack
{
	char pad_200[8];  // 0xC8(0x8)

}; 



// Class MediaCompositing.MovieSceneMediaTrack
// Size: 0xB0(Inherited: 0x98) 
struct UMovieSceneMediaTrack : public UMovieSceneNameableTrack
{
	char pad_152[8];  // 0x98(0x8)
	struct TArray<struct UMovieSceneSection*> MediaSections;  // 0xA0(0x10)

}; 



