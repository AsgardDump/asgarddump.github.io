#pragma once 
#include "SDK.h" 
 
 
// Function AnimationLocomotionLibraryRuntime.AnimCharacterMovementLibrary.PredictGroundMovementPivotLocation
// Size: 0x50(Inherited: 0x0) 
struct FPredictGroundMovementPivotLocation
{
	struct FVector Acceleration;  // 0x0(0x18)
	struct FVector Velocity;  // 0x18(0x18)
	float GroundFriction;  // 0x30(0x4)
	char pad_52[4];  // 0x34(0x4)
	struct FVector ReturnValue;  // 0x38(0x18)

}; 
// Function AnimationLocomotionLibraryRuntime.AnimDistanceMatchingLibrary.DistanceMatchToTarget
// Size: 0x30(Inherited: 0x0) 
struct FDistanceMatchToTarget
{
	struct FSequenceEvaluatorReference SequenceEvaluator;  // 0x0(0x10)
	float DistanceToTarget;  // 0x10(0x4)
	struct FName DistanceCurveName;  // 0x14(0x8)
	char pad_28[4];  // 0x1C(0x4)
	struct FSequenceEvaluatorReference ReturnValue;  // 0x20(0x10)

}; 
// Function AnimationLocomotionLibraryRuntime.AnimCharacterMovementLibrary.PredictGroundMovementStopLocation
// Size: 0x48(Inherited: 0x0) 
struct FPredictGroundMovementStopLocation
{
	struct FVector Velocity;  // 0x0(0x18)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool bUseSeparateBrakingFriction : 1;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)
	float BrakingFriction;  // 0x1C(0x4)
	float GroundFriction;  // 0x20(0x4)
	float BrakingFrictionFactor;  // 0x24(0x4)
	float BrakingDecelerationWalking;  // 0x28(0x4)
	char pad_44[4];  // 0x2C(0x4)
	struct FVector ReturnValue;  // 0x30(0x18)

}; 
// Function AnimationLocomotionLibraryRuntime.AnimDistanceMatchingLibrary.AdvanceTimeByDistanceMatching
// Size: 0x50(Inherited: 0x0) 
struct FAdvanceTimeByDistanceMatching
{
	struct FAnimUpdateContext UpdateContext;  // 0x0(0x10)
	struct FSequenceEvaluatorReference SequenceEvaluator;  // 0x10(0x10)
	float DistanceTraveled;  // 0x20(0x4)
	struct FName DistanceCurveName;  // 0x24(0x8)
	char pad_44[4];  // 0x2C(0x4)
	struct FVector2D PlayRateClamp;  // 0x30(0x10)
	struct FSequenceEvaluatorReference ReturnValue;  // 0x40(0x10)

}; 
// Function AnimationLocomotionLibraryRuntime.AnimDistanceMatchingLibrary.SetPlayrateToMatchSpeed
// Size: 0x38(Inherited: 0x0) 
struct FSetPlayrateToMatchSpeed
{
	struct FSequencePlayerReference SequencePlayer;  // 0x0(0x10)
	float SpeedToMatch;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct FVector2D PlayRateClamp;  // 0x18(0x10)
	struct FSequencePlayerReference ReturnValue;  // 0x28(0x10)

}; 
