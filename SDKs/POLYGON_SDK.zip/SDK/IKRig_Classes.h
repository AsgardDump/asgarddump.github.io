#pragma once 
#include <IKRig_Structs.h>
 
 
 
// Class IKRig.RetargetChainSettings
// Size: 0x170(Inherited: 0x28) 
struct URetargetChainSettings : public UObject
{
	struct FName SourceChain;  // 0x28(0x8)
	struct FName TargetChain;  // 0x30(0x8)
	struct FTargetChainSettings Settings;  // 0x38(0xA0)
	char pad_216_1 : 7;  // 0xD8(0x1)
	bool CopyPoseUsingFK : 1;  // 0xD8(0x1)
	uint8_t  RotationMode;  // 0xD9(0x1)
	char pad_218[2];  // 0xDA(0x2)
	float RotationAlpha;  // 0xDC(0x4)
	uint8_t  TranslationMode;  // 0xE0(0x1)
	char pad_225[3];  // 0xE1(0x3)
	float TranslationAlpha;  // 0xE4(0x4)
	char pad_232_1 : 7;  // 0xE8(0x1)
	bool DriveIKGoal : 1;  // 0xE8(0x1)
	char pad_233[3];  // 0xE9(0x3)
	float BlendToSource;  // 0xEC(0x4)
	struct FVector BlendToSourceWeights;  // 0xF0(0x18)
	struct FVector StaticOffset;  // 0x108(0x18)
	struct FVector StaticLocalOffset;  // 0x120(0x18)
	struct FRotator StaticRotationOffset;  // 0x138(0x18)
	float Extension;  // 0x150(0x4)
	char pad_340_1 : 7;  // 0x154(0x1)
	bool UseSpeedCurveToPlantIK : 1;  // 0x154(0x1)
	char pad_341[3];  // 0x155(0x3)
	struct FName SpeedCurveName;  // 0x158(0x8)
	float VelocityThreshold;  // 0x160(0x4)
	float UnplantStiffness;  // 0x164(0x4)
	float UnplantCriticalDamping;  // 0x168(0x4)
	char pad_364[4];  // 0x16C(0x4)

}; 



// Class IKRig.IKRetargetProcessor
// Size: 0x370(Inherited: 0x28) 
struct UIKRetargetProcessor : public UObject
{
	char pad_40[328];  // 0x28(0x148)
	struct UIKRigProcessor* IKRigProcessor;  // 0x170(0x8)
	char pad_376[504];  // 0x178(0x1F8)

}; 



// Class IKRig.IKGoalCreatorInterface
// Size: 0x28(Inherited: 0x28) 
struct UIKGoalCreatorInterface : public UInterface
{

	void AddIKGoals(struct TMap<struct FName, struct FIKRigGoal>& OutGoals); // Function IKRig.IKGoalCreatorInterface.AddIKGoals
}; 



// Class IKRig.IKRigComponent
// Size: 0xB8(Inherited: 0xA0) 
struct UIKRigComponent : public UActorComponent
{
	char pad_160[24];  // 0xA0(0x18)

	void SetIKRigGoalTransform(struct FName GoalName, struct FTransform Transform, float PositionAlpha, float RotationAlpha); // Function IKRig.IKRigComponent.SetIKRigGoalTransform
	void SetIKRigGoalPositionAndRotation(struct FName GoalName, struct FVector position, struct FQuat Rotation, float PositionAlpha, float RotationAlpha); // Function IKRig.IKRigComponent.SetIKRigGoalPositionAndRotation
	void SetIKRigGoal(struct FIKRigGoal& Goal); // Function IKRig.IKRigComponent.SetIKRigGoal
	void ClearAllGoals(); // Function IKRig.IKRigComponent.ClearAllGoals
}; 



// Class IKRig.IKRigEffectorGoal
// Size: 0x100(Inherited: 0x28) 
struct UIKRigEffectorGoal : public UObject
{
	struct FName GoalName;  // 0x28(0x8)
	struct FName BoneName;  // 0x30(0x8)
	float PositionAlpha;  // 0x38(0x4)
	float RotationAlpha;  // 0x3C(0x4)
	struct FTransform CurrentTransform;  // 0x40(0x60)
	struct FTransform InitialTransform;  // 0xA0(0x60)

}; 



// Class IKRig.IKRigDefinition
// Size: 0x108(Inherited: 0x28) 
struct UIKRigDefinition : public UObject
{
	char pad_40[8];  // 0x28(0x8)
	struct TSoftObjectPtr<USkeletalMesh> PreviewSkeletalMesh;  // 0x30(0x30)
	struct FIKRigSkeleton Skeleton;  // 0x60(0x70)
	struct TArray<struct UIKRigEffectorGoal*> Goals;  // 0xD0(0x10)
	struct TArray<struct UIKRigSolver*> Solvers;  // 0xE0(0x10)
	struct FRetargetDefinition RetargetDefinition;  // 0xF0(0x18)

}; 



// Class IKRig.IKRig_PoleSolverEffector
// Size: 0x40(Inherited: 0x28) 
struct UIKRig_PoleSolverEffector : public UObject
{
	struct FName GoalName;  // 0x28(0x8)
	struct FName BoneName;  // 0x30(0x8)
	float Alpha;  // 0x38(0x4)
	char pad_60[4];  // 0x3C(0x4)

}; 



// Class IKRig.IKRigProcessor
// Size: 0x148(Inherited: 0x28) 
struct UIKRigProcessor : public UObject
{
	char pad_40[56];  // 0x28(0x38)
	struct TArray<struct UIKRigSolver*> Solvers;  // 0x60(0x10)
	char pad_112[216];  // 0x70(0xD8)

}; 



// Class IKRig.RetargetRootSettings
// Size: 0xE8(Inherited: 0x28) 
struct URetargetRootSettings : public UObject
{
	struct FTargetRootSettings Settings;  // 0x28(0x68)
	char pad_144_1 : 7;  // 0x90(0x1)
	bool RetargetRootTranslation : 1;  // 0x90(0x1)
	char pad_145[3];  // 0x91(0x3)
	float GlobalScaleHorizontal;  // 0x94(0x4)
	float GlobalScaleVertical;  // 0x98(0x4)
	char pad_156[4];  // 0x9C(0x4)
	struct FVector BlendToSource;  // 0xA0(0x18)
	struct FVector StaticOffset;  // 0xB8(0x18)
	struct FRotator StaticRotationOffset;  // 0xD0(0x18)

}; 



// Class IKRig.IKRigSolver
// Size: 0x30(Inherited: 0x28) 
struct UIKRigSolver : public UObject
{
	char pad_40_1 : 7;  // 0x28(0x1)
	bool bIsEnabled : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)

}; 



// Class IKRig.IKRetargetGlobalSettings
// Size: 0x48(Inherited: 0x28) 
struct UIKRetargetGlobalSettings : public UObject
{
	struct FRetargetGlobalSettings Settings;  // 0x28(0x20)

}; 



// Class IKRig.IKRetargeter
// Size: 0x218(Inherited: 0x28) 
struct UIKRetargeter : public UObject
{
	struct TSoftObjectPtr<UIKRigDefinition> SourceIKRigAsset;  // 0x28(0x30)
	struct TSoftObjectPtr<UIKRigDefinition> TargetIKRigAsset;  // 0x58(0x30)
	struct TArray<struct FRetargetChainMap> ChainMapping;  // 0x88(0x10)
	struct TArray<struct URetargetChainSettings*> ChainSettings;  // 0x98(0x10)
	struct URetargetRootSettings* RootSettings;  // 0xA8(0x8)
	struct UIKRetargetGlobalSettings* GlobalSettings;  // 0xB0(0x8)
	struct TMap<struct FName, struct FRetargetProfile> Profiles;  // 0xB8(0x50)
	struct FName CurrentProfile;  // 0x108(0x8)
	struct TMap<struct FName, struct FIKRetargetPose> SourceRetargetPoses;  // 0x110(0x50)
	struct TMap<struct FName, struct FIKRetargetPose> TargetRetargetPoses;  // 0x160(0x50)
	struct FName CurrentSourceRetargetPose;  // 0x1B0(0x8)
	struct FName CurrentTargetRetargetPose;  // 0x1B8(0x8)
	struct TMap<struct FName, struct FIKRetargetPose> RetargetPoses;  // 0x1C0(0x50)
	struct FName CurrentRetargetPose;  // 0x210(0x8)

	void SetRootSettingsInRetargetProfile(struct FRetargetProfile& RetargetProfile, struct FTargetRootSettings& RootSettings); // Function IKRig.IKRetargeter.SetRootSettingsInRetargetProfile
	void SetGlobalSettingsInRetargetProfile(struct FRetargetProfile& RetargetProfile, struct FRetargetGlobalSettings& GlobalSettings); // Function IKRig.IKRetargeter.SetGlobalSettingsInRetargetProfile
	void SetChainSpeedPlantSettingsInRetargetProfile(struct FRetargetProfile& RetargetProfile, struct FTargetChainSpeedPlantSettings& SpeedPlantSettings, struct FName TargetChainName); // Function IKRig.IKRetargeter.SetChainSpeedPlantSettingsInRetargetProfile
	void SetChainSettingsInRetargetProfile(struct FRetargetProfile& RetargetProfile, struct FTargetChainSettings& ChainSettings, struct FName TargetChainName); // Function IKRig.IKRetargeter.SetChainSettingsInRetargetProfile
	void SetChainIKSettingsInRetargetProfile(struct FRetargetProfile& RetargetProfile, struct FTargetChainIKSettings& IKSettings, struct FName TargetChainName); // Function IKRig.IKRetargeter.SetChainIKSettingsInRetargetProfile
	void SetChainFKSettingsInRetargetProfile(struct FRetargetProfile& RetargetProfile, struct FTargetChainFKSettings& FKSettings, struct FName TargetChainName); // Function IKRig.IKRetargeter.SetChainFKSettingsInRetargetProfile
	struct FTargetRootSettings GetRootSettingsFromRetargetProfile(struct FRetargetProfile& RetargetProfile); // Function IKRig.IKRetargeter.GetRootSettingsFromRetargetProfile
	void GetRootSettingsFromRetargetAsset(struct UIKRetargeter* RetargetAsset, struct FName OptionalProfileName, struct FTargetRootSettings& OutSettings); // Function IKRig.IKRetargeter.GetRootSettingsFromRetargetAsset
	struct FRetargetGlobalSettings GetGlobalSettingsFromRetargetProfile(struct FRetargetProfile& RetargetProfile); // Function IKRig.IKRetargeter.GetGlobalSettingsFromRetargetProfile
	void GetGlobalSettingsFromRetargetAsset(struct UIKRetargeter* RetargetAsset, struct FName OptionalProfileName, struct FRetargetGlobalSettings& OutSettings); // Function IKRig.IKRetargeter.GetGlobalSettingsFromRetargetAsset
	struct FTargetChainSettings GetChainUsingGoalFromRetargetAsset(struct UIKRetargeter* RetargetAsset, struct FName IKGoalName); // Function IKRig.IKRetargeter.GetChainUsingGoalFromRetargetAsset
	struct FTargetChainSettings GetChainSettingsFromRetargetProfile(struct FRetargetProfile& RetargetProfile, struct FName TargetChainName); // Function IKRig.IKRetargeter.GetChainSettingsFromRetargetProfile
	struct FTargetChainSettings GetChainSettingsFromRetargetAsset(struct UIKRetargeter* RetargetAsset, struct FName TargetChainName, struct FName OptionalProfileName); // Function IKRig.IKRetargeter.GetChainSettingsFromRetargetAsset
}; 



// Class IKRig.IKRig_BodyMoverEffector
// Size: 0x40(Inherited: 0x28) 
struct UIKRig_BodyMoverEffector : public UObject
{
	struct FName GoalName;  // 0x28(0x8)
	struct FName BoneName;  // 0x30(0x8)
	float InfluenceMultiplier;  // 0x38(0x4)
	char pad_60[4];  // 0x3C(0x4)

}; 



// Class IKRig.IKRig_BodyMover
// Size: 0x80(Inherited: 0x30) 
struct UIKRig_BodyMover : public UIKRigSolver
{
	struct FName RootBone;  // 0x30(0x8)
	float PositionAlpha;  // 0x38(0x4)
	float PositionPositiveX;  // 0x3C(0x4)
	float PositionNegativeX;  // 0x40(0x4)
	float PositionPositiveY;  // 0x44(0x4)
	float PositionNegativeY;  // 0x48(0x4)
	float PositionPositiveZ;  // 0x4C(0x4)
	float PositionNegativeZ;  // 0x50(0x4)
	float RotationAlpha;  // 0x54(0x4)
	float RotateXAlpha;  // 0x58(0x4)
	float RotateYAlpha;  // 0x5C(0x4)
	float RotateZAlpha;  // 0x60(0x4)
	char pad_100[4];  // 0x64(0x4)
	struct TArray<struct UIKRig_BodyMoverEffector*> Effectors;  // 0x68(0x10)
	char pad_120[8];  // 0x78(0x8)

}; 



// Class IKRig.IKRig_LimbEffector
// Size: 0x38(Inherited: 0x28) 
struct UIKRig_LimbEffector : public UObject
{
	struct FName GoalName;  // 0x28(0x8)
	struct FName BoneName;  // 0x30(0x8)

}; 



// Class IKRig.IKRig_PBIKBoneSettings
// Size: 0x78(Inherited: 0x28) 
struct UIKRig_PBIKBoneSettings : public UObject
{
	struct FName bone;  // 0x28(0x8)
	float RotationStiffness;  // 0x30(0x4)
	float PositionStiffness;  // 0x34(0x4)
	uint8_t  X;  // 0x38(0x1)
	char pad_57[3];  // 0x39(0x3)
	float MinX;  // 0x3C(0x4)
	float MaxX;  // 0x40(0x4)
	uint8_t  Y;  // 0x44(0x1)
	char pad_69[3];  // 0x45(0x3)
	float MinY;  // 0x48(0x4)
	float MaxY;  // 0x4C(0x4)
	uint8_t  Z;  // 0x50(0x1)
	char pad_81[3];  // 0x51(0x3)
	float MinZ;  // 0x54(0x4)
	float MaxZ;  // 0x58(0x4)
	char pad_92_1 : 7;  // 0x5C(0x1)
	bool bUsePreferredAngles : 1;  // 0x5C(0x1)
	char pad_93[3];  // 0x5D(0x3)
	struct FVector PreferredAngles;  // 0x60(0x18)

}; 



// Class IKRig.IKRig_LimbSolver
// Size: 0x90(Inherited: 0x30) 
struct UIKRig_LimbSolver : public UIKRigSolver
{
	struct FName RootName;  // 0x30(0x8)
	float ReachPrecision;  // 0x38(0x4)
	char EAxis HingeRotationAxis;  // 0x3C(0x1)
	char pad_61[3];  // 0x3D(0x3)
	int32_t MaxIterations;  // 0x40(0x4)
	char pad_68_1 : 7;  // 0x44(0x1)
	bool bEnableLimit : 1;  // 0x44(0x1)
	char pad_69[3];  // 0x45(0x3)
	float MinRotationAngle;  // 0x48(0x4)
	char pad_76_1 : 7;  // 0x4C(0x1)
	bool bAveragePull : 1;  // 0x4C(0x1)
	char pad_77[3];  // 0x4D(0x3)
	float PullDistribution;  // 0x50(0x4)
	float ReachStepAlpha;  // 0x54(0x4)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool bEnableTwistCorrection : 1;  // 0x58(0x1)
	char EAxis EndBoneForwardAxis;  // 0x59(0x1)
	char pad_90[6];  // 0x5A(0x6)
	struct UIKRig_LimbEffector* Effector;  // 0x60(0x8)
	char pad_104[40];  // 0x68(0x28)

}; 



// Class IKRig.IKRig_FBIKEffector
// Size: 0x48(Inherited: 0x28) 
struct UIKRig_FBIKEffector : public UObject
{
	struct FName GoalName;  // 0x28(0x8)
	struct FName BoneName;  // 0x30(0x8)
	float StrengthAlpha;  // 0x38(0x4)
	float PullChainAlpha;  // 0x3C(0x4)
	float PinRotation;  // 0x40(0x4)
	int32_t IndexInSolver;  // 0x44(0x4)

}; 



// Class IKRig.IKRigPBIKSolver
// Size: 0xD0(Inherited: 0x30) 
struct UIKRigPBIKSolver : public UIKRigSolver
{
	struct FName RootBone;  // 0x30(0x8)
	int32_t Iterations;  // 0x38(0x4)
	float MassMultiplier;  // 0x3C(0x4)
	float MinMassMultiplier;  // 0x40(0x4)
	char pad_68_1 : 7;  // 0x44(0x1)
	bool bAllowStretch : 1;  // 0x44(0x1)
	uint8_t  RootBehavior;  // 0x45(0x1)
	char pad_70_1 : 7;  // 0x46(0x1)
	bool bStartSolveFromInputPose : 1;  // 0x46(0x1)
	char pad_71[1];  // 0x47(0x1)
	struct TArray<struct UIKRig_FBIKEffector*> Effectors;  // 0x48(0x10)
	struct TArray<struct UIKRig_PBIKBoneSettings*> BoneSettings;  // 0x58(0x10)
	char pad_104[104];  // 0x68(0x68)

}; 



// Class IKRig.IKRig_PoleSolver
// Size: 0x68(Inherited: 0x30) 
struct UIKRig_PoleSolver : public UIKRigSolver
{
	struct FName RootName;  // 0x30(0x8)
	struct FName EndName;  // 0x38(0x8)
	struct UIKRig_PoleSolverEffector* Effector;  // 0x40(0x8)
	char pad_72[32];  // 0x48(0x20)

}; 



// Class IKRig.IKRig_SetTransformEffector
// Size: 0x30(Inherited: 0x28) 
struct UIKRig_SetTransformEffector : public UObject
{
	char pad_40_1 : 7;  // 0x28(0x1)
	bool bEnablePosition : 1;  // 0x28(0x1)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool bEnableRotation : 1;  // 0x29(0x1)
	char pad_42[2];  // 0x2A(0x2)
	float Alpha;  // 0x2C(0x4)

}; 



// Class IKRig.IKRig_SetTransform
// Size: 0x50(Inherited: 0x30) 
struct UIKRig_SetTransform : public UIKRigSolver
{
	struct FName Goal;  // 0x30(0x8)
	struct FName RootBone;  // 0x38(0x8)
	struct UIKRig_SetTransformEffector* Effector;  // 0x40(0x8)
	char pad_72[8];  // 0x48(0x8)

}; 



