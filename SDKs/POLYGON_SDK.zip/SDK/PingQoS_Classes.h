#pragma once 
#include <PingQoS_Structs.h>
 
 
 
// Class PingQoS.PingQoSSubsystem
// Size: 0x60(Inherited: 0x30) 
struct UPingQoSSubsystem : public UEngineSubsystem
{
	struct FMulticastInlineDelegate OnPingCompleted;  // 0x30(0x10)
	char pad_64[8];  // 0x40(0x8)
	struct TArray<struct FPingQoSInfo> Infos;  // 0x48(0x10)
	char pad_88[8];  // 0x58(0x8)

	bool Update(); // Function PingQoS.PingQoSSubsystem.Update
	void Recv(struct TArray<struct FPingQoSInfo>& ResultInfos); // Function PingQoS.PingQoSSubsystem.Recv
	void Init(struct TArray<struct FPingQoSInfo> SetInfo); // Function PingQoS.PingQoSSubsystem.Init
}; 



