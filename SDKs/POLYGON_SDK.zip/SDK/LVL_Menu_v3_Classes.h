#pragma once 
#include <LVL_Menu_v3_Structs.h>
 
 
 
// BlueprintGeneratedClass LVL_Menu_v3.LVL_Menu_v3_C
// Size: 0x2B0(Inherited: 0x298) 
struct ALVL_Menu_v3_C : public ALevelScriptActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x298(0x8)
	struct ASpotLight* SpotLight_7_ExecuteUbergraph_LVL_Menu_v3_RefProperty;  // 0x2A0(0x8)
	struct ASpotLight* SpotLight_6_ExecuteUbergraph_LVL_Menu_v3_RefProperty;  // 0x2A8(0x8)

	void ReceiveBeginPlay(); // Function LVL_Menu_v3.LVL_Menu_v3_C.ReceiveBeginPlay
	void ChangeLobbyFPSLimit(int32_t NewValue); // Function LVL_Menu_v3.LVL_Menu_v3_C.ChangeLobbyFPSLimit
	void ChangeShadowQualitySettings(int32_t NewValue); // Function LVL_Menu_v3.LVL_Menu_v3_C.ChangeShadowQualitySettings
	void ExecuteUbergraph_LVL_Menu_v3(int32_t EntryPoint); // Function LVL_Menu_v3.LVL_Menu_v3_C.ExecuteUbergraph_LVL_Menu_v3
}; 



