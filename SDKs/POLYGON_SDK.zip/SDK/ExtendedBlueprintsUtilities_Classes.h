#pragma once 
#include <ExtendedBlueprintsUtilities_Structs.h>
 
 
 
// Class ExtendedBlueprintsUtilities.ExtendedBlueprintsUtilitiesBPLibrary
// Size: 0x28(Inherited: 0x28) 
struct UExtendedBlueprintsUtilitiesBPLibrary : public UBlueprintFunctionLibrary
{

	struct AActor* SpawnActorFromTemplate(struct UObject* WorldContextObject, struct AActor* templateActor, struct FTransform& SpawnTransform, struct AActor* Owner); // Function ExtendedBlueprintsUtilities.ExtendedBlueprintsUtilitiesBPLibrary.SpawnActorFromTemplate
	void GetDefaultComponentsByClass(UObject* ActorClass, UObject* ComponentClass, struct TArray<struct UActorComponent*>& outArray); // Function ExtendedBlueprintsUtilities.ExtendedBlueprintsUtilitiesBPLibrary.GetDefaultComponentsByClass
	struct AActor* ClassDefaultObject(UObject* objectClass); // Function ExtendedBlueprintsUtilities.ExtendedBlueprintsUtilitiesBPLibrary.ClassDefaultObject
}; 



