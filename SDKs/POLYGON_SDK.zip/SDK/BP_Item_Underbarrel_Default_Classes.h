#pragma once 
#include <BP_Item_Underbarrel_Default_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Item_Underbarrel_Default.BP_Item_Underbarrel_Default_C
// Size: 0x348(Inherited: 0x348) 
struct ABP_Item_Underbarrel_Default_C : public AItem_Module_Underbarrel
{

}; 



