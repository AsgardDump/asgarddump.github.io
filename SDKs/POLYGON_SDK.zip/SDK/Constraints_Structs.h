#pragma once 
#include "SDK.h" 
 
 
// SparseDelegateFunction Constraints.ConstraintsManager.OnConstraintRemoved__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FOnConstraintRemoved__DelegateSignature
{
	struct UConstraintsManager* Mananger;  // 0x0(0x8)
	struct UTickableConstraint* Constraint;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bDoNotCompensate : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function Constraints.ConstraintsScriptingLibrary.CreateTransformableComponentHandle
// Size: 0x20(Inherited: 0x0) 
struct FCreateTransformableComponentHandle
{
	struct UWorld* InWorld;  // 0x0(0x8)
	struct USceneComponent* InSceneComponent;  // 0x8(0x8)
	struct FName InSocketName;  // 0x10(0x8)
	struct UTransformableComponentHandle* ReturnValue;  // 0x18(0x8)

}; 
// ScriptStruct Constraints.ConstraintAndActiveChannel
// Size: 0x138(Inherited: 0x0) 
struct FConstraintAndActiveChannel
{
	struct TSoftObjectPtr<UTickableConstraint> Constraint;  // 0x0(0x30)
	struct FMovieSceneConstraintChannel ActiveChannel;  // 0x30(0x100)
	struct UTickableConstraint* ConstraintCopyToSpawn;  // 0x130(0x8)

}; 
// SparseDelegateFunction Constraints.ConstraintsManager.OnConstraintAdded__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FOnConstraintAdded__DelegateSignature
{
	struct UConstraintsManager* Mananger;  // 0x0(0x8)
	struct UTickableConstraint* Constraint;  // 0x8(0x8)

}; 
// ScriptStruct Constraints.ConstraintTickFunction
// Size: 0x40(Inherited: 0x28) 
struct FConstraintTickFunction : public FTickFunction
{
	char pad_40[24];  // 0x28(0x18)

}; 
// ScriptStruct Constraints.MovieSceneConstraintChannel
// Size: 0x100(Inherited: 0x100) 
struct FMovieSceneConstraintChannel : public FMovieSceneBoolChannel
{

}; 
// Function Constraints.ConstraintsScriptingLibrary.AddConstraint
// Size: 0x28(Inherited: 0x0) 
struct FAddConstraint
{
	struct UWorld* InWorld;  // 0x0(0x8)
	struct UTransformableHandle* InParentHandle;  // 0x8(0x8)
	struct UTransformableHandle* InChildHandle;  // 0x10(0x8)
	struct UTickableTransformConstraint* InConstraint;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool bMaintainOffset : 1;  // 0x20(0x1)
	char pad_33_1 : 7;  // 0x21(0x1)
	bool ReturnValue : 1;  // 0x21(0x1)
	char pad_34[6];  // 0x22(0x6)

}; 
// Function Constraints.ConstraintsScriptingLibrary.CreateFromType
// Size: 0x18(Inherited: 0x0) 
struct FCreateFromType
{
	struct UWorld* InWorld;  // 0x0(0x8)
	uint8_t  InType;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct UTickableTransformConstraint* ReturnValue;  // 0x10(0x8)

}; 
// Function Constraints.ConstraintsScriptingLibrary.GetManager
// Size: 0x10(Inherited: 0x0) 
struct FGetManager
{
	struct UWorld* InWorld;  // 0x0(0x8)
	struct UConstraintsManager* ReturnValue;  // 0x8(0x8)

}; 
// Function Constraints.ConstraintsScriptingLibrary.RemoveConstraint
// Size: 0x10(Inherited: 0x0) 
struct FRemoveConstraint
{
	struct UWorld* InWorld;  // 0x0(0x8)
	int32_t InIndex;  // 0x8(0x4)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool ReturnValue : 1;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)

}; 
