#pragma once 
#include <NavigationSystem_Structs.h>
 
 
 
// Class NavigationSystem.CrowdManagerBase
// Size: 0x28(Inherited: 0x28) 
struct UCrowdManagerBase : public UObject
{

}; 



// Class NavigationSystem.NavigationGraphNode
// Size: 0x290(Inherited: 0x290) 
struct ANavigationGraphNode : public AActor
{

}; 



// Class NavigationSystem.RecastFilter_UseDefaultArea
// Size: 0x48(Inherited: 0x48) 
struct URecastFilter_UseDefaultArea : public UNavigationQueryFilter
{

}; 



// Class NavigationSystem.NavigationGraphNodeComponent
// Size: 0x2D0(Inherited: 0x2A0) 
struct UNavigationGraphNodeComponent : public USceneComponent
{
	struct FNavGraphNode Node;  // 0x2A0(0x18)
	struct UNavigationGraphNodeComponent* NextNodeComponent;  // 0x2B8(0x8)
	struct UNavigationGraphNodeComponent* PrevNodeComponent;  // 0x2C0(0x8)
	char pad_712[8];  // 0x2C8(0x8)

}; 



// Class NavigationSystem.NavigationPathGenerator
// Size: 0x28(Inherited: 0x28) 
struct UNavigationPathGenerator : public UInterface
{

}; 



// Class NavigationSystem.NavLinkCustomInterface
// Size: 0x28(Inherited: 0x28) 
struct UNavLinkCustomInterface : public UInterface
{

}; 



// Class NavigationSystem.NavigationInvokerComponent
// Size: 0xA8(Inherited: 0xA0) 
struct UNavigationInvokerComponent : public UActorComponent
{
	float TileGenerationRadius;  // 0xA0(0x4)
	float TileRemovalRadius;  // 0xA4(0x4)

}; 



// Class NavigationSystem.NavLinkHostInterface
// Size: 0x28(Inherited: 0x28) 
struct UNavLinkHostInterface : public UInterface
{

}; 



// Class NavigationSystem.NavLinkTrivial
// Size: 0x50(Inherited: 0x50) 
struct UNavLinkTrivial : public UNavLinkDefinition
{

}; 



// Class NavigationSystem.NavNodeInterface
// Size: 0x28(Inherited: 0x28) 
struct UNavNodeInterface : public UInterface
{

}; 



// Class NavigationSystem.NavigationData
// Size: 0x4B8(Inherited: 0x290) 
struct ANavigationData : public AActor
{
	char pad_656[8];  // 0x290(0x8)
	struct UPrimitiveComponent* RenderingComp;  // 0x298(0x8)
	struct FNavDataConfig NavDataConfig;  // 0x2A0(0x98)
	char bEnableDrawing : 1;  // 0x338(0x1)
	char bForceRebuildOnLoad : 1;  // 0x338(0x1)
	char bAutoDestroyWhenNoNavigation : 1;  // 0x338(0x1)
	char bCanBeMainNavData : 1;  // 0x338(0x1)
	char bCanSpawnOnRebuild : 1;  // 0x338(0x1)
	char bRebuildAtRuntime : 1;  // 0x338(0x1)
	char pad_824_1 : 2;  // 0x338(0x1)
	char pad_825[4];  // 0x339(0x4)
	uint8_t  RuntimeGeneration;  // 0x33C(0x1)
	char pad_829[3];  // 0x33D(0x3)
	float ObservedPathsTickInterval;  // 0x340(0x4)
	uint32_t DataVersion;  // 0x344(0x4)
	char pad_840[264];  // 0x348(0x108)
	struct TArray<struct FSupportedAreaData> SupportedAreas;  // 0x450(0x10)
	char pad_1120[88];  // 0x460(0x58)

}; 



// Class NavigationSystem.AbstractNavData
// Size: 0x4B8(Inherited: 0x4B8) 
struct AAbstractNavData : public ANavigationData
{

}; 



// Class NavigationSystem.NavArea
// Size: 0x48(Inherited: 0x30) 
struct UNavArea : public UNavAreaBase
{
	float DefaultCost;  // 0x30(0x4)
	float FixedAreaEnteringCost;  // 0x34(0x4)
	struct FColor DrawColor;  // 0x38(0x4)
	struct FNavAgentSelector SupportedAgents;  // 0x3C(0x4)
	char bSupportsAgent0 : 1;  // 0x40(0x1)
	char bSupportsAgent1 : 1;  // 0x40(0x1)
	char bSupportsAgent2 : 1;  // 0x40(0x1)
	char bSupportsAgent3 : 1;  // 0x40(0x1)
	char bSupportsAgent4 : 1;  // 0x40(0x1)
	char bSupportsAgent5 : 1;  // 0x40(0x1)
	char bSupportsAgent6 : 1;  // 0x40(0x1)
	char bSupportsAgent7 : 1;  // 0x40(0x1)
	char bSupportsAgent8 : 1;  // 0x41(0x1)
	char bSupportsAgent9 : 1;  // 0x41(0x1)
	char bSupportsAgent10 : 1;  // 0x41(0x1)
	char bSupportsAgent11 : 1;  // 0x41(0x1)
	char bSupportsAgent12 : 1;  // 0x41(0x1)
	char bSupportsAgent13 : 1;  // 0x41(0x1)
	char bSupportsAgent14 : 1;  // 0x41(0x1)
	char bSupportsAgent15 : 1;  // 0x41(0x1)
	char pad_66[6];  // 0x42(0x6)

}; 



// Class NavigationSystem.NavAreaMeta
// Size: 0x48(Inherited: 0x48) 
struct UNavAreaMeta : public UNavArea
{

}; 



// Class NavigationSystem.NavAreaMeta_SwitchByAgent
// Size: 0xC8(Inherited: 0x48) 
struct UNavAreaMeta_SwitchByAgent : public UNavAreaMeta
{
	UNavArea* Agent0Area;  // 0x48(0x8)
	UNavArea* Agent1Area;  // 0x50(0x8)
	UNavArea* Agent2Area;  // 0x58(0x8)
	UNavArea* Agent3Area;  // 0x60(0x8)
	UNavArea* Agent4Area;  // 0x68(0x8)
	UNavArea* Agent5Area;  // 0x70(0x8)
	UNavArea* Agent6Area;  // 0x78(0x8)
	UNavArea* Agent7Area;  // 0x80(0x8)
	UNavArea* Agent8Area;  // 0x88(0x8)
	UNavArea* Agent9Area;  // 0x90(0x8)
	UNavArea* Agent10Area;  // 0x98(0x8)
	UNavArea* Agent11Area;  // 0xA0(0x8)
	UNavArea* Agent12Area;  // 0xA8(0x8)
	UNavArea* Agent13Area;  // 0xB0(0x8)
	UNavArea* Agent14Area;  // 0xB8(0x8)
	UNavArea* Agent15Area;  // 0xC0(0x8)

}; 



// Class NavigationSystem.NavArea_Default
// Size: 0x48(Inherited: 0x48) 
struct UNavArea_Default : public UNavArea
{

}; 



// Class NavigationSystem.NavArea_LowHeight
// Size: 0x48(Inherited: 0x48) 
struct UNavArea_LowHeight : public UNavArea
{

}; 



// Class NavigationSystem.NavArea_Null
// Size: 0x48(Inherited: 0x48) 
struct UNavArea_Null : public UNavArea
{

}; 



// Class NavigationSystem.NavigationSystemV1
// Size: 0x1530(Inherited: 0x28) 
struct UNavigationSystemV1 : public UNavigationSystemBase
{
	struct ANavigationData* MainNavData;  // 0x28(0x8)
	struct ANavigationData* AbstractNavData;  // 0x30(0x8)
	struct FName DefaultAgentName;  // 0x38(0x8)
	struct TSoftClassPtr<UObject> CrowdManagerClass;  // 0x40(0x30)
	char bAutoCreateNavigationData : 1;  // 0x70(0x1)
	char bSpawnNavDataInNavBoundsLevel : 1;  // 0x70(0x1)
	char bAllowClientSideNavigation : 1;  // 0x70(0x1)
	char bShouldDiscardSubLevelNavData : 1;  // 0x70(0x1)
	char bTickWhilePaused : 1;  // 0x70(0x1)
	char bSupportRebuilding : 1;  // 0x70(0x1)
	char bInitialBuildingLocked : 1;  // 0x70(0x1)
	char pad_112_1 : 1;  // 0x70(0x1)
	char bSkipAgentHeightCheckWhenPickingNavData : 1;  // 0x71(0x1)
	char pad_113_1 : 7;  // 0x71(0x1)
	char pad_114[3];  // 0x72(0x3)
	int32_t GeometryExportVertexCountWarningThreshold;  // 0x74(0x4)
	char bGenerateNavigationOnlyAroundNavigationInvokers : 1;  // 0x78(0x1)
	char pad_120_1 : 7;  // 0x78(0x1)
	char pad_121[4];  // 0x79(0x4)
	float ActiveTilesUpdateInterval;  // 0x7C(0x4)
	uint8_t  DataGatheringMode;  // 0x80(0x1)
	char pad_129[3];  // 0x81(0x3)
	float DirtyAreaWarningSizeThreshold;  // 0x84(0x4)
	float GatheringNavModifiersWarningLimitTime;  // 0x88(0x4)
	char pad_140[4];  // 0x8C(0x4)
	struct TArray<struct FNavDataConfig> SupportedAgents;  // 0x90(0x10)
	struct FNavAgentSelector SupportedAgentsMask;  // 0xA0(0x4)
	char pad_164[4];  // 0xA4(0x4)
	struct FBox BuildBounds;  // 0xA8(0x38)
	struct TArray<struct ANavigationData*> NavDataSet;  // 0xE0(0x10)
	struct TArray<struct ANavigationData*> NavDataRegistrationQueue;  // 0xF0(0x10)
	char pad_256[16];  // 0x100(0x10)
	struct FMulticastInlineDelegate OnNavDataRegisteredEvent;  // 0x110(0x10)
	struct FMulticastInlineDelegate OnNavigationGenerationFinishedDelegate;  // 0x120(0x10)
	char pad_304[220];  // 0x130(0xDC)
	uint8_t  OperationMode;  // 0x20C(0x1)
	char pad_525[4899];  // 0x20D(0x1323)

	void UnregisterNavigationInvoker(struct AActor* Invoker); // Function NavigationSystem.NavigationSystemV1.UnregisterNavigationInvoker
	void SetMaxSimultaneousTileGenerationJobsCount(int32_t MaxNumberOfJobs); // Function NavigationSystem.NavigationSystemV1.SetMaxSimultaneousTileGenerationJobsCount
	void SetGeometryGatheringMode(uint8_t  NewMode); // Function NavigationSystem.NavigationSystemV1.SetGeometryGatheringMode
	void ResetMaxSimultaneousTileGenerationJobsCount(); // Function NavigationSystem.NavigationSystemV1.ResetMaxSimultaneousTileGenerationJobsCount
	void RegisterNavigationInvoker(struct AActor* Invoker, float TileGenerationRadius, float TileRemovalRadius); // Function NavigationSystem.NavigationSystemV1.RegisterNavigationInvoker
	void OnNavigationBoundsUpdated(struct ANavMeshBoundsVolume* NavVolume); // Function NavigationSystem.NavigationSystemV1.OnNavigationBoundsUpdated
	bool NavigationRaycast(struct UObject* WorldContextObject, struct FVector& RayStart, struct FVector& RayEnd, struct FVector& HitLocation, UNavigationQueryFilter* FilterClass, struct AController* Querier); // Function NavigationSystem.NavigationSystemV1.NavigationRaycast
	bool K2_ReplaceAreaInOctreeData(struct UObject* Object, UNavArea* OldArea, UNavArea* NewArea); // Function NavigationSystem.NavigationSystemV1.K2_ReplaceAreaInOctreeData
	bool K2_ProjectPointToNavigation(struct UObject* WorldContextObject, struct FVector& Point, struct FVector& ProjectedLocation, struct ANavigationData* NavData, UNavigationQueryFilter* FilterClass, struct FVector QueryExtent); // Function NavigationSystem.NavigationSystemV1.K2_ProjectPointToNavigation
	bool K2_GetRandomReachablePointInRadius(struct UObject* WorldContextObject, struct FVector& Origin, struct FVector& RandomLocation, float Radius, struct ANavigationData* NavData, UNavigationQueryFilter* FilterClass); // Function NavigationSystem.NavigationSystemV1.K2_GetRandomReachablePointInRadius
	bool K2_GetRandomPointInNavigableRadius(struct UObject* WorldContextObject, struct FVector& Origin, struct FVector& RandomLocation, float Radius, struct ANavigationData* NavData, UNavigationQueryFilter* FilterClass); // Function NavigationSystem.NavigationSystemV1.K2_GetRandomPointInNavigableRadius
	bool K2_GetRandomLocationInNavigableRadius(struct UObject* WorldContextObject, struct FVector& Origin, struct FVector& RandomLocation, float Radius, struct ANavigationData* NavData, UNavigationQueryFilter* FilterClass); // Function NavigationSystem.NavigationSystemV1.K2_GetRandomLocationInNavigableRadius
	bool IsNavigationBeingBuiltOrLocked(struct UObject* WorldContextObject); // Function NavigationSystem.NavigationSystemV1.IsNavigationBeingBuiltOrLocked
	bool IsNavigationBeingBuilt(struct UObject* WorldContextObject); // Function NavigationSystem.NavigationSystemV1.IsNavigationBeingBuilt
	char ENavigationQueryResult GetPathLength(struct UObject* WorldContextObject, struct FVector& PathStart, struct FVector& PathEnd, float& PathLength, struct ANavigationData* NavData, UNavigationQueryFilter* FilterClass); // Function NavigationSystem.NavigationSystemV1.GetPathLength
	char ENavigationQueryResult GetPathCost(struct UObject* WorldContextObject, struct FVector& PathStart, struct FVector& PathEnd, float& PathCost, struct ANavigationData* NavData, UNavigationQueryFilter* FilterClass); // Function NavigationSystem.NavigationSystemV1.GetPathCost
	struct UNavigationSystemV1* GetNavigationSystem(struct UObject* WorldContextObject); // Function NavigationSystem.NavigationSystemV1.GetNavigationSystem
	struct UNavigationPath* FindPathToLocationSynchronously(struct UObject* WorldContextObject, struct FVector& PathStart, struct FVector& PathEnd, struct AActor* PathfindingContext, UNavigationQueryFilter* FilterClass); // Function NavigationSystem.NavigationSystemV1.FindPathToLocationSynchronously
	struct UNavigationPath* FindPathToActorSynchronously(struct UObject* WorldContextObject, struct FVector& PathStart, struct AActor* GoalActor, float TetherDistance, struct AActor* PathfindingContext, UNavigationQueryFilter* FilterClass); // Function NavigationSystem.NavigationSystemV1.FindPathToActorSynchronously
}; 



// Class NavigationSystem.NavArea_Obstacle
// Size: 0x48(Inherited: 0x48) 
struct UNavArea_Obstacle : public UNavArea
{

}; 



// Class NavigationSystem.NavCollision
// Size: 0xD0(Inherited: 0x70) 
struct UNavCollision : public UNavCollisionBase
{
	char pad_112[16];  // 0x70(0x10)
	struct TArray<struct FNavCollisionCylinder> CylinderCollision;  // 0x80(0x10)
	struct TArray<struct FNavCollisionBox> BoxCollision;  // 0x90(0x10)
	UNavArea* AreaClass;  // 0xA0(0x8)
	char bGatherConvexGeometry : 1;  // 0xA8(0x1)
	char bCreateOnClient : 1;  // 0xA8(0x1)
	char pad_168_1 : 6;  // 0xA8(0x1)
	char pad_169[40];  // 0xA9(0x28)

}; 



// Class NavigationSystem.NavigationQueryFilter
// Size: 0x48(Inherited: 0x28) 
struct UNavigationQueryFilter : public UObject
{
	struct TArray<struct FNavigationFilterArea> Areas;  // 0x28(0x10)
	struct FNavigationFilterFlags IncludeFlags;  // 0x38(0x4)
	struct FNavigationFilterFlags ExcludeFlags;  // 0x3C(0x4)
	char pad_64[8];  // 0x40(0x8)

}; 



// Class NavigationSystem.NavigationGraph
// Size: 0x4B8(Inherited: 0x4B8) 
struct ANavigationGraph : public ANavigationData
{

}; 



// Class NavigationSystem.NavModifierVolume
// Size: 0x2E0(Inherited: 0x2C8) 
struct ANavModifierVolume : public AVolume
{
	char pad_712[8];  // 0x2C8(0x8)
	UNavArea* AreaClass;  // 0x2D0(0x8)
	char pad_728_1 : 7;  // 0x2D8(0x1)
	bool bMaskFillCollisionUnderneathForNavmesh : 1;  // 0x2D8(0x1)
	char pad_729[7];  // 0x2D9(0x7)

	void SetAreaClass(UNavArea* NewAreaClass); // Function NavigationSystem.NavModifierVolume.SetAreaClass
}; 



// Class NavigationSystem.RecastNavMeshDataChunk
// Size: 0x40(Inherited: 0x30) 
struct URecastNavMeshDataChunk : public UNavigationDataChunk
{
	char pad_48[16];  // 0x30(0x10)

}; 



// Class NavigationSystem.RecastNavMesh
// Size: 0x598(Inherited: 0x4B8) 
struct ARecastNavMesh : public ANavigationData
{
	char bDrawTriangleEdges : 1;  // 0x4B8(0x1)
	char bDrawPolyEdges : 1;  // 0x4B8(0x1)
	char bDrawFilledPolys : 1;  // 0x4B8(0x1)
	char bDrawNavMeshEdges : 1;  // 0x4B8(0x1)
	char bDrawTileBounds : 1;  // 0x4B8(0x1)
	char bDrawPathCollidingGeometry : 1;  // 0x4B8(0x1)
	char bDrawTileLabels : 1;  // 0x4B8(0x1)
	char bDrawPolygonLabels : 1;  // 0x4B8(0x1)
	char bDrawDefaultPolygonCost : 1;  // 0x4B9(0x1)
	char bDrawPolygonFlags : 1;  // 0x4B9(0x1)
	char bDrawLabelsOnPathNodes : 1;  // 0x4B9(0x1)
	char bDrawNavLinks : 1;  // 0x4B9(0x1)
	char bDrawFailedNavLinks : 1;  // 0x4B9(0x1)
	char bDrawClusters : 1;  // 0x4B9(0x1)
	char bDrawOctree : 1;  // 0x4B9(0x1)
	char bDrawOctreeDetails : 1;  // 0x4B9(0x1)
	char bDrawMarkedForbiddenPolys : 1;  // 0x4BA(0x1)
	char bDistinctlyDrawTilesBeingBuilt : 1;  // 0x4BA(0x1)
	char pad_1210_1 : 6;  // 0x4BA(0x1)
	char pad_1211[2];  // 0x4BB(0x2)
	float DrawOffset;  // 0x4BC(0x4)
	struct FRecastNavMeshTileGenerationDebug TileGenerationDebug;  // 0x4C0(0x14)
	char bFixedTilePoolSize : 1;  // 0x4D4(0x1)
	char pad_1236_1 : 7;  // 0x4D4(0x1)
	char pad_1237[4];  // 0x4D5(0x4)
	int32_t TilePoolSize;  // 0x4D8(0x4)
	float TileSizeUU;  // 0x4DC(0x4)
	float CellSize;  // 0x4E0(0x4)
	float CellHeight;  // 0x4E4(0x4)
	float AgentRadius;  // 0x4E8(0x4)
	float AgentHeight;  // 0x4EC(0x4)
	float AgentMaxSlope;  // 0x4F0(0x4)
	float AgentMaxStepHeight;  // 0x4F4(0x4)
	float MinRegionArea;  // 0x4F8(0x4)
	float MergeRegionSize;  // 0x4FC(0x4)
	float MaxSimplificationError;  // 0x500(0x4)
	int32_t MaxSimultaneousTileGenerationJobsCount;  // 0x504(0x4)
	int32_t TileNumberHardLimit;  // 0x508(0x4)
	int32_t PolyRefTileBits;  // 0x50C(0x4)
	int32_t PolyRefNavPolyBits;  // 0x510(0x4)
	int32_t PolyRefSaltBits;  // 0x514(0x4)
	struct FVector NavMeshOriginOffset;  // 0x518(0x18)
	float DefaultDrawDistance;  // 0x530(0x4)
	float DefaultMaxSearchNodes;  // 0x534(0x4)
	float DefaultMaxHierarchicalSearchNodes;  // 0x538(0x4)
	char ERecastPartitioning RegionPartitioning;  // 0x53C(0x1)
	char ERecastPartitioning LayerPartitioning;  // 0x53D(0x1)
	char pad_1342[2];  // 0x53E(0x2)
	int32_t RegionChunkSplits;  // 0x540(0x4)
	int32_t LayerChunkSplits;  // 0x544(0x4)
	char bSortNavigationAreasByCost : 1;  // 0x548(0x1)
	char bIsWorldPartitioned : 1;  // 0x548(0x1)
	char bPerformVoxelFiltering : 1;  // 0x548(0x1)
	char bMarkLowHeightAreas : 1;  // 0x548(0x1)
	char bUseExtraTopCellWhenMarkingAreas : 1;  // 0x548(0x1)
	char bFilterLowSpanSequences : 1;  // 0x548(0x1)
	char bFilterLowSpanFromTileCache : 1;  // 0x548(0x1)
	char bDoFullyAsyncNavDataGathering : 1;  // 0x548(0x1)
	char bUseBetterOffsetsFromCorners : 1;  // 0x549(0x1)
	char bStoreEmptyTileLayers : 1;  // 0x549(0x1)
	char bUseVirtualFilters : 1;  // 0x549(0x1)
	char bUseVirtualGeometryFilteringAndDirtying : 1;  // 0x549(0x1)
	char bAllowNavLinkAsPathEnd : 1;  // 0x549(0x1)
	char pad_1353_1 : 3;  // 0x549(0x1)
	char pad_1354[3];  // 0x54A(0x3)
	int32_t TimeSliceFilterLedgeSpansMaxYProcess;  // 0x54C(0x4)
	double TimeSliceLongDurationDebug;  // 0x550(0x8)
	char bUseVoxelCache : 1;  // 0x558(0x1)
	char pad_1368_1 : 7;  // 0x558(0x1)
	char pad_1369[4];  // 0x559(0x4)
	float TileSetUpdateInterval;  // 0x55C(0x4)
	float HeuristicScale;  // 0x560(0x4)
	float VerticalDeviationFromGroundCompensation;  // 0x564(0x4)
	char pad_1384[48];  // 0x568(0x30)

	bool K2_ReplaceAreaInTileBounds(struct FBox Bounds, UNavArea* OldArea, UNavArea* NewArea, bool ReplaceLinks); // Function NavigationSystem.RecastNavMesh.K2_ReplaceAreaInTileBounds
}; 



// Class NavigationSystem.NavLinkCustomComponent
// Size: 0x1D0(Inherited: 0xF0) 
struct UNavLinkCustomComponent : public UNavRelevantComponent
{
	char pad_240[8];  // 0xF0(0x8)
	uint32_t NavLinkUserId;  // 0xF8(0x4)
	char pad_252[4];  // 0xFC(0x4)
	UNavArea* EnabledAreaClass;  // 0x100(0x8)
	UNavArea* DisabledAreaClass;  // 0x108(0x8)
	struct FNavAgentSelector SupportedAgents;  // 0x110(0x4)
	char pad_276[4];  // 0x114(0x4)
	struct FVector LinkRelativeStart;  // 0x118(0x18)
	struct FVector LinkRelativeEnd;  // 0x130(0x18)
	char ENavLinkDirection LinkDirection;  // 0x148(0x1)
	char pad_329[3];  // 0x149(0x3)
	char bLinkEnabled : 1;  // 0x14C(0x1)
	char bNotifyWhenEnabled : 1;  // 0x14C(0x1)
	char bNotifyWhenDisabled : 1;  // 0x14C(0x1)
	char bCreateBoxObstacle : 1;  // 0x14C(0x1)
	char pad_332_1 : 4;  // 0x14C(0x1)
	char pad_333[4];  // 0x14D(0x4)
	struct FVector ObstacleOffset;  // 0x150(0x18)
	struct FVector ObstacleExtent;  // 0x168(0x18)
	UNavArea* ObstacleAreaClass;  // 0x180(0x8)
	float BroadcastRadius;  // 0x188(0x4)
	float BroadcastInterval;  // 0x18C(0x4)
	char ECollisionChannel BroadcastChannel;  // 0x190(0x1)
	char pad_401[63];  // 0x191(0x3F)

}; 



// Class NavigationSystem.NavigationPath
// Size: 0x88(Inherited: 0x28) 
struct UNavigationPath : public UObject
{
	struct FMulticastInlineDelegate PathUpdatedNotifier;  // 0x28(0x10)
	struct TArray<struct FVector> PathPoints;  // 0x38(0x10)
	char ENavigationOptionFlag RecalculateOnInvalidation;  // 0x48(0x1)
	char pad_73[63];  // 0x49(0x3F)

	bool IsValid(); // Function NavigationSystem.NavigationPath.IsValid
	bool IsStringPulled(); // Function NavigationSystem.NavigationPath.IsStringPulled
	bool IsPartial(); // Function NavigationSystem.NavigationPath.IsPartial
	float GetPathLength(); // Function NavigationSystem.NavigationPath.GetPathLength
	float GetPathCost(); // Function NavigationSystem.NavigationPath.GetPathCost
	struct FString GetDebugString(); // Function NavigationSystem.NavigationPath.GetDebugString
	void EnableRecalculationOnInvalidation(char ENavigationOptionFlag DoRecalculation); // Function NavigationSystem.NavigationPath.EnableRecalculationOnInvalidation
	void EnableDebugDrawing(bool bShouldDrawDebugData, struct FLinearColor PathColor); // Function NavigationSystem.NavigationPath.EnableDebugDrawing
}; 



// Class NavigationSystem.NavigationSystemModuleConfig
// Size: 0x60(Inherited: 0x58) 
struct UNavigationSystemModuleConfig : public UNavigationSystemConfig
{
	char bStrictlyStatic : 1;  // 0x58(0x1)
	char bCreateOnClient : 1;  // 0x58(0x1)
	char bAutoSpawnMissingNavData : 1;  // 0x58(0x1)
	char bSpawnNavDataInNavBoundsLevel : 1;  // 0x58(0x1)
	char pad_88_1 : 4;  // 0x58(0x1)
	char pad_89[8];  // 0x59(0x8)

}; 



// Class NavigationSystem.NavigationTestingActor
// Size: 0x3B0(Inherited: 0x290) 
struct ANavigationTestingActor : public AActor
{
	char pad_656[16];  // 0x290(0x10)
	struct UCapsuleComponent* CapsuleComponent;  // 0x2A0(0x8)
	struct UNavigationInvokerComponent* InvokerComponent;  // 0x2A8(0x8)
	char bActAsNavigationInvoker : 1;  // 0x2B0(0x1)
	char pad_688_1 : 7;  // 0x2B0(0x1)
	char pad_689[8];  // 0x2B1(0x8)
	struct FNavAgentProperties NavAgentProps;  // 0x2B8(0x38)
	struct FVector QueryingExtent;  // 0x2F0(0x18)
	struct ANavigationData* MyNavData;  // 0x308(0x8)
	struct FVector ProjectedLocation;  // 0x310(0x18)
	char bProjectedLocationValid : 1;  // 0x328(0x1)
	char bSearchStart : 1;  // 0x328(0x1)
	char pad_808_1 : 6;  // 0x328(0x1)
	char pad_809[4];  // 0x329(0x4)
	float CostLimitFactor;  // 0x32C(0x4)
	float MinimumCostLimit;  // 0x330(0x4)
	char bBacktracking : 1;  // 0x334(0x1)
	char bUseHierarchicalPathfinding : 1;  // 0x334(0x1)
	char bGatherDetailedInfo : 1;  // 0x334(0x1)
	char bDrawDistanceToWall : 1;  // 0x334(0x1)
	char bShowNodePool : 1;  // 0x334(0x1)
	char bShowBestPath : 1;  // 0x334(0x1)
	char bShowDiffWithPreviousStep : 1;  // 0x334(0x1)
	char bShouldBeVisibleInGame : 1;  // 0x334(0x1)
	char pad_821[3];  // 0x335(0x3)
	char ENavCostDisplay CostDisplayMode;  // 0x338(0x1)
	char pad_825[7];  // 0x339(0x7)
	struct FVector2D TextCanvasOffset;  // 0x340(0x10)
	char bPathExist : 1;  // 0x350(0x1)
	char bPathIsPartial : 1;  // 0x350(0x1)
	char bPathSearchOutOfNodes : 1;  // 0x350(0x1)
	char pad_848_1 : 5;  // 0x350(0x1)
	char pad_849[4];  // 0x351(0x4)
	float PathfindingTime;  // 0x354(0x4)
	float PathCost;  // 0x358(0x4)
	int32_t PathfindingSteps;  // 0x35C(0x4)
	struct ANavigationTestingActor* OtherActor;  // 0x360(0x8)
	UNavigationQueryFilter* FilterClass;  // 0x368(0x8)
	int32_t ShowStepIndex;  // 0x370(0x4)
	float OffsetFromCornersDistance;  // 0x374(0x4)
	char pad_888[56];  // 0x378(0x38)

}; 



// Class NavigationSystem.NavLinkComponent
// Size: 0x550(Inherited: 0x540) 
struct UNavLinkComponent : public UPrimitiveComponent
{
	struct TArray<struct FNavigationLink> Links;  // 0x540(0x10)

}; 



// Class NavigationSystem.NavRelevantComponent
// Size: 0xF0(Inherited: 0xA0) 
struct UNavRelevantComponent : public UActorComponent
{
	char pad_160[64];  // 0xA0(0x40)
	char bAttachToOwnersRoot : 1;  // 0xE0(0x1)
	char pad_224_1 : 7;  // 0xE0(0x1)
	char pad_225[8];  // 0xE1(0x8)
	struct UObject* CachedNavParent;  // 0xE8(0x8)

	void SetNavigationRelevancy(bool bRelevant); // Function NavigationSystem.NavRelevantComponent.SetNavigationRelevancy
}; 



// Class NavigationSystem.NavLinkRenderingComponent
// Size: 0x540(Inherited: 0x540) 
struct UNavLinkRenderingComponent : public UPrimitiveComponent
{

}; 



// Class NavigationSystem.NavMeshBoundsVolume
// Size: 0x2D0(Inherited: 0x2C8) 
struct ANavMeshBoundsVolume : public AVolume
{
	struct FNavAgentSelector SupportedAgents;  // 0x2C8(0x4)
	char pad_716[4];  // 0x2CC(0x4)

}; 



// Class NavigationSystem.NavMeshRenderingComponent
// Size: 0x5A0(Inherited: 0x590) 
struct UNavMeshRenderingComponent : public UDebugDrawComponent
{
	char pad_1424[16];  // 0x590(0x10)

}; 



// Class NavigationSystem.NavTestRenderingComponent
// Size: 0x590(Inherited: 0x590) 
struct UNavTestRenderingComponent : public UDebugDrawComponent
{

}; 



// Class NavigationSystem.NavModifierComponent
// Size: 0x190(Inherited: 0xF0) 
struct UNavModifierComponent : public UNavRelevantComponent
{
	UNavArea* AreaClass;  // 0xF0(0x8)
	struct FVector FailsafeExtent;  // 0xF8(0x18)
	char bIncludeAgentHeight : 1;  // 0x110(0x1)
	char pad_272_1 : 7;  // 0x110(0x1)
	char pad_273[128];  // 0x111(0x80)

	void SetAreaClass(UNavArea* NewAreaClass); // Function NavigationSystem.NavModifierComponent.SetAreaClass
}; 



// Class NavigationSystem.NavSystemConfigOverride
// Size: 0x2A0(Inherited: 0x290) 
struct ANavSystemConfigOverride : public AActor
{
	struct UNavigationSystemConfig* NavigationSystemConfig;  // 0x290(0x8)
	uint8_t  OverridePolicy;  // 0x298(0x1)
	char bLoadOnClient : 1;  // 0x299(0x1)
	char pad_665_1 : 7;  // 0x299(0x1)
	char pad_666[7];  // 0x29A(0x7)

}; 



