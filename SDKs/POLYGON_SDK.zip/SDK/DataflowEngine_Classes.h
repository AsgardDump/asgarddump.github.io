#pragma once 
#include <DataflowEngine_Structs.h>
 
 
 
// Class DataflowEngine.DataflowEdNode
// Size: 0xB8(Inherited: 0x98) 
struct UDataflowEdNode : public UEdGraphNode
{
	char pad_152[32];  // 0x98(0x20)

}; 



// Class DataflowEngine.Dataflow
// Size: 0x88(Inherited: 0x60) 
struct UDataflow : public UEdGraph
{
	char pad_96[16];  // 0x60(0x10)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool bActive : 1;  // 0x70(0x1)
	char pad_113[7];  // 0x71(0x7)
	struct TArray<struct UObject*> Targets;  // 0x78(0x10)

}; 



