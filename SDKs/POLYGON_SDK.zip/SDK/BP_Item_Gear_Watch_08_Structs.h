#pragma once 
#include "SDK.h" 
 
 
// Function BP_Item_Gear_Watch_08.BP_Item_Gear_Watch_08_C.ExecuteUbergraph_BP_Item_Gear_Watch_08
// Size: 0x2F4(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Item_Gear_Watch_08
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FDateTime CallFunc_Now_ReturnValue;  // 0x8(0x8)
	struct FDateTime K2Node_LowEntry_LocalVariable_Value__Object;  // 0x10(0x8)
	int32_t CallFunc_BreakDateTime_Year;  // 0x18(0x4)
	int32_t CallFunc_BreakDateTime_Month;  // 0x1C(0x4)
	int32_t CallFunc_BreakDateTime_Day;  // 0x20(0x4)
	int32_t CallFunc_BreakDateTime_Hour;  // 0x24(0x4)
	int32_t CallFunc_BreakDateTime_Minute;  // 0x28(0x4)
	int32_t CallFunc_BreakDateTime_Second;  // 0x2C(0x4)
	int32_t CallFunc_BreakDateTime_Millisecond;  // 0x30(0x4)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x34(0x10)
	float CallFunc_Conv_IntToFloat_ReturnValue;  // 0x44(0x4)
	struct FTimerHandle CallFunc_K2_SetTimerDelegate_ReturnValue;  // 0x48(0x8)
	double CallFunc_Divide_DoubleDouble_ReturnValue;  // 0x50(0x8)
	float CallFunc_Conv_IntToFloat_ReturnValue_2;  // 0x58(0x4)
	int32_t CallFunc_BreakDateTime_Year_2;  // 0x5C(0x4)
	int32_t CallFunc_BreakDateTime_Month_2;  // 0x60(0x4)
	int32_t CallFunc_BreakDateTime_Day_2;  // 0x64(0x4)
	int32_t CallFunc_BreakDateTime_Hour_2;  // 0x68(0x4)
	int32_t CallFunc_BreakDateTime_Minute_2;  // 0x6C(0x4)
	int32_t CallFunc_BreakDateTime_Second_2;  // 0x70(0x4)
	int32_t CallFunc_BreakDateTime_Millisecond_2;  // 0x74(0x4)
	double CallFunc_Add_DoubleDouble_ReturnValue;  // 0x78(0x8)
	float CallFunc_Conv_IntToFloat_ReturnValue_3;  // 0x80(0x4)
	char pad_132[4];  // 0x84(0x4)
	double CallFunc_Multiply_DoubleDouble_ReturnValue;  // 0x88(0x8)
	double CallFunc_Divide_DoubleDouble_ReturnValue_2;  // 0x90(0x8)
	struct FRotator CallFunc_MakeRotator_ReturnValue;  // 0x98(0x18)
	float CallFunc_Conv_IntToFloat_ReturnValue_4;  // 0xB0(0x4)
	char pad_180[4];  // 0xB4(0x4)
	double CallFunc_Add_DoubleDouble_ReturnValue_2;  // 0xB8(0x8)
	struct FHitResult CallFunc_K2_SetRelativeRotation_SweepHitResult;  // 0xC0(0xE8)
	double CallFunc_Multiply_DoubleDouble_ReturnValue_2;  // 0x1A8(0x8)
	struct FRotator CallFunc_MakeRotator_ReturnValue_2;  // 0x1B0(0x18)
	struct FHitResult CallFunc_K2_SetRelativeRotation_SweepHitResult_2;  // 0x1C8(0xE8)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue;  // 0x2B0(0x8)
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0x2B8(0x8)
	char pad_704_1 : 7;  // 0x2C0(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue : 1;  // 0x2C0(0x1)
	char pad_705_1 : 7;  // 0x2C1(0x1)
	bool K2Node_Event_useFovMaterial : 1;  // 0x2C1(0x1)
	char pad_706[6];  // 0x2C2(0x6)
	double CallFunc_Divide_DoubleDouble_A_ImplicitCast;  // 0x2C8(0x8)
	double CallFunc_Add_DoubleDouble_A_ImplicitCast;  // 0x2D0(0x8)
	double CallFunc_Divide_DoubleDouble_A_ImplicitCast_2;  // 0x2D8(0x8)
	float CallFunc_MakeRotator_Pitch_ImplicitCast;  // 0x2E0(0x4)
	char pad_740[4];  // 0x2E4(0x4)
	double CallFunc_Add_DoubleDouble_A_ImplicitCast_2;  // 0x2E8(0x8)
	float CallFunc_MakeRotator_Pitch_ImplicitCast_2;  // 0x2F0(0x4)

}; 
// Function BP_Item_Gear_Watch_08.BP_Item_Gear_Watch_08_C.SetCorrectiveFovMaterial
// Size: 0x1(Inherited: 0x1) 
struct FSetCorrectiveFovMaterial : public FSetCorrectiveFovMaterial
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool useFovMaterial : 1;  // 0x0(0x1)

}; 
