#pragma once 
#include "SDK.h" 
 
 
// Function OnlineSubsystem.TurnBasedMatchInterface.OnMatchReceivedTurn
// Size: 0x18(Inherited: 0x0) 
struct FOnMatchReceivedTurn
{
	struct FString Match;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bDidBecomeActive : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// ScriptStruct OnlineSubsystem.NamedInterface
// Size: 0x10(Inherited: 0x0) 
struct FNamedInterface
{
	struct FName InterfaceName;  // 0x0(0x8)
	struct UObject* InterfaceObject;  // 0x8(0x8)

}; 
// ScriptStruct OnlineSubsystem.NamedInterfaceDef
// Size: 0x18(Inherited: 0x0) 
struct FNamedInterfaceDef
{
	struct FName InterfaceName;  // 0x0(0x8)
	struct FString InterfaceClassName;  // 0x8(0x10)

}; 
// Function OnlineSubsystem.TurnBasedMatchInterface.OnMatchEnded
// Size: 0x10(Inherited: 0x0) 
struct FOnMatchEnded
{
	struct FString Match;  // 0x0(0x10)

}; 
