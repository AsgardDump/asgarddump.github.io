#pragma once 
#include "SDK.h" 
 
 
// ScriptStruct DataflowCore.DataflowOutput
// Size: 0x68(Inherited: 0x40) 
struct FDataflowOutput : public FDataflowConnection
{
	char pad_64[40];  // 0x40(0x28)

}; 
// ScriptStruct DataflowCore.DataflowNode
// Size: 0xD0(Inherited: 0x0) 
struct FDataflowNode
{
	char pad_0[200];  // 0x0(0xC8)
	char pad_200_1 : 7;  // 0xC8(0x1)
	bool bActive : 1;  // 0xC8(0x1)
	char pad_201[7];  // 0xC9(0x7)

}; 
// ScriptStruct DataflowCore.DataflowConnection
// Size: 0x40(Inherited: 0x0) 
struct FDataflowConnection
{
	char pad_0[64];  // 0x0(0x40)

}; 
// ScriptStruct DataflowCore.DataflowInput
// Size: 0x48(Inherited: 0x40) 
struct FDataflowInput : public FDataflowConnection
{
	char pad_64[8];  // 0x40(0x8)

}; 
