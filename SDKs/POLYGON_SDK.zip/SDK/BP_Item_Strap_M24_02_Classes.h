#pragma once 
#include <BP_Item_Strap_M24_02_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Item_Strap_M24_02.BP_Item_Strap_M24_02_C
// Size: 0x350(Inherited: 0x350) 
struct ABP_Item_Strap_M24_02_C : public AItem_Module_Strap
{

}; 



