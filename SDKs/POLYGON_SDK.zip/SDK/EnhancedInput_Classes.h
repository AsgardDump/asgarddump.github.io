#pragma once 
#include <EnhancedInput_Structs.h>
 
 
 
// Class EnhancedInput.EnhancedInputPlatformData
// Size: 0x78(Inherited: 0x28) 
struct UEnhancedInputPlatformData : public UObject
{
	struct TMap<struct UInputMappingContext*, struct UInputMappingContext*> MappingContextRedirects;  // 0x28(0x50)

	struct UInputMappingContext* GetContextRedirect(struct UInputMappingContext* InContext); // Function EnhancedInput.EnhancedInputPlatformData.GetContextRedirect
}; 



// Class EnhancedInput.InputModifierFOVScaling
// Size: 0x30(Inherited: 0x28) 
struct UInputModifierFOVScaling : public UInputModifier
{
	float FOVScale;  // 0x28(0x4)
	uint8_t  FOVScalingType;  // 0x2C(0x1)
	char pad_45[3];  // 0x2D(0x3)

}; 



// Class EnhancedInput.EnhancedInputDeveloperSettings
// Size: 0x50(Inherited: 0x38) 
struct UEnhancedInputDeveloperSettings : public UDeveloperSettingsBackedByCVars
{
	struct FPerPlatformSettings PlatformSettings;  // 0x38(0x10)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool bShouldOnlyTriggerLastActionInChord : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 



// Class EnhancedInput.EnhancedInputActionDelegateBinding
// Size: 0x38(Inherited: 0x28) 
struct UEnhancedInputActionDelegateBinding : public UInputDelegateBinding
{
	struct TArray<struct FBlueprintEnhancedInputActionBinding> InputActionDelegateBindings;  // 0x28(0x10)

}; 



// Class EnhancedInput.EnhancedInputPlatformSettings
// Size: 0x68(Inherited: 0x40) 
struct UEnhancedInputPlatformSettings : public UPlatformSettings
{
	struct TArray<struct TSoftClassPtr<UObject>> InputData;  // 0x40(0x10)
	struct TArray<UEnhancedInputPlatformData*> InputDataClasses;  // 0x50(0x10)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool bShouldLogMappingContextRedirects : 1;  // 0x60(0x1)
	char pad_97[7];  // 0x61(0x7)

}; 



// Class EnhancedInput.InputModifierNegate
// Size: 0x30(Inherited: 0x28) 
struct UInputModifierNegate : public UInputModifier
{
	char pad_40_1 : 7;  // 0x28(0x1)
	bool bX : 1;  // 0x28(0x1)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool bY : 1;  // 0x29(0x1)
	char pad_42_1 : 7;  // 0x2A(0x1)
	bool bZ : 1;  // 0x2A(0x1)
	char pad_43[5];  // 0x2B(0x5)

}; 



// Class EnhancedInput.EnhancedInputActionValueBinding
// Size: 0x38(Inherited: 0x28) 
struct UEnhancedInputActionValueBinding : public UInputDelegateBinding
{
	struct TArray<struct FBlueprintEnhancedInputActionBinding> InputActionValueBindings;  // 0x28(0x10)

}; 



// Class EnhancedInput.InputModifierScalar
// Size: 0x40(Inherited: 0x28) 
struct UInputModifierScalar : public UInputModifier
{
	struct FVector Scalar;  // 0x28(0x18)

}; 



// Class EnhancedInput.EnhancedInputComponent
// Size: 0x160(Inherited: 0x128) 
struct UEnhancedInputComponent : public UInputComponent
{
	char pad_296[56];  // 0x128(0x38)

	struct FInputActionValue GetBoundActionValue(struct UInputAction* Action); // Function EnhancedInput.EnhancedInputComponent.GetBoundActionValue
}; 



// Class EnhancedInput.EnhancedInputLibrary
// Size: 0x28(Inherited: 0x28) 
struct UEnhancedInputLibrary : public UBlueprintFunctionLibrary
{

	void RequestRebuildControlMappingsUsingContext(struct UInputMappingContext* Context, bool bForceImmediately); // Function EnhancedInput.EnhancedInputLibrary.RequestRebuildControlMappingsUsingContext
	struct FInputActionValue MakeInputActionValueOfType(double X, double Y, double Z, uint8_t  ValueType); // Function EnhancedInput.EnhancedInputLibrary.MakeInputActionValueOfType
	struct FInputActionValue MakeInputActionValue(double X, double Y, double Z, struct FInputActionValue& MatchValueType); // Function EnhancedInput.EnhancedInputLibrary.MakeInputActionValue
	struct FInputActionValue GetBoundActionValue(struct AActor* Actor, struct UInputAction* Action); // Function EnhancedInput.EnhancedInputLibrary.GetBoundActionValue
	struct FString Conv_InputActionValueToString(struct FInputActionValue ActionValue); // Function EnhancedInput.EnhancedInputLibrary.Conv_InputActionValueToString
	bool Conv_InputActionValueToBool(struct FInputActionValue InValue); // Function EnhancedInput.EnhancedInputLibrary.Conv_InputActionValueToBool
	struct FVector Conv_InputActionValueToAxis3D(struct FInputActionValue ActionValue); // Function EnhancedInput.EnhancedInputLibrary.Conv_InputActionValueToAxis3D
	struct FVector2D Conv_InputActionValueToAxis2D(struct FInputActionValue InValue); // Function EnhancedInput.EnhancedInputLibrary.Conv_InputActionValueToAxis2D
	double Conv_InputActionValueToAxis1D(struct FInputActionValue InValue); // Function EnhancedInput.EnhancedInputLibrary.Conv_InputActionValueToAxis1D
	void BreakInputActionValue(struct FInputActionValue InActionValue, double& X, double& Y, double& Z, uint8_t & Type); // Function EnhancedInput.EnhancedInputLibrary.BreakInputActionValue
}; 



// Class EnhancedInput.EnhancedInputSubsystemInterface
// Size: 0x28(Inherited: 0x28) 
struct UEnhancedInputSubsystemInterface : public UInterface
{

	void RequestRebuildControlMappings(struct FModifyContextOptions& Options, uint8_t  RebuildType); // Function EnhancedInput.EnhancedInputSubsystemInterface.RequestRebuildControlMappings
	int32_t RemovePlayerMappedKey(struct FName MappingName, struct FModifyContextOptions& Options); // Function EnhancedInput.EnhancedInputSubsystemInterface.RemovePlayerMappedKey
	void RemovePlayerMappableConfig(struct UPlayerMappableInputConfig* Config, struct FModifyContextOptions& Options); // Function EnhancedInput.EnhancedInputSubsystemInterface.RemovePlayerMappableConfig
	void RemoveMappingContext(struct UInputMappingContext* MappingContext, struct FModifyContextOptions& Options); // Function EnhancedInput.EnhancedInputSubsystemInterface.RemoveMappingContext
	void RemoveAllPlayerMappedKeys(struct FModifyContextOptions& Options); // Function EnhancedInput.EnhancedInputSubsystemInterface.RemoveAllPlayerMappedKeys
	uint8_t  QueryMapKeyInContextSet(struct TArray<struct UInputMappingContext*>& PrioritizedActiveContexts, struct UInputMappingContext* InputContext, struct UInputAction* Action, struct FKey Key, struct TArray<struct FMappingQueryIssue>& OutIssues, uint8_t  BlockingIssues); // Function EnhancedInput.EnhancedInputSubsystemInterface.QueryMapKeyInContextSet
	uint8_t  QueryMapKeyInActiveContextSet(struct UInputMappingContext* InputContext, struct UInputAction* Action, struct FKey Key, struct TArray<struct FMappingQueryIssue>& OutIssues, uint8_t  BlockingIssues); // Function EnhancedInput.EnhancedInputSubsystemInterface.QueryMapKeyInActiveContextSet
	struct TArray<struct FKey> QueryKeysMappedToAction(struct UInputAction* Action); // Function EnhancedInput.EnhancedInputSubsystemInterface.QueryKeysMappedToAction
	void InjectInputVectorForAction(struct UInputAction* Action, struct FVector Value, struct TArray<struct UInputModifier*>& Modifiers, struct TArray<struct UInputTrigger*>& Triggers); // Function EnhancedInput.EnhancedInputSubsystemInterface.InjectInputVectorForAction
	void InjectInputForAction(struct UInputAction* Action, struct FInputActionValue RawValue, struct TArray<struct UInputModifier*>& Modifiers, struct TArray<struct UInputTrigger*>& Triggers); // Function EnhancedInput.EnhancedInputSubsystemInterface.InjectInputForAction
	bool HasMappingContext(struct UInputMappingContext* MappingContext, int32_t& OutFoundPriority); // Function EnhancedInput.EnhancedInputSubsystemInterface.HasMappingContext
	struct FKey GetPlayerMappedKey(struct FName MappingName); // Function EnhancedInput.EnhancedInputSubsystemInterface.GetPlayerMappedKey
	struct TArray<struct FEnhancedActionKeyMapping> GetAllPlayerMappableActionKeyMappings(); // Function EnhancedInput.EnhancedInputSubsystemInterface.GetAllPlayerMappableActionKeyMappings
	void ClearAllMappings(); // Function EnhancedInput.EnhancedInputSubsystemInterface.ClearAllMappings
	int32_t AddPlayerMappedKey(struct FName MappingName, struct FKey NewKey, struct FModifyContextOptions& Options); // Function EnhancedInput.EnhancedInputSubsystemInterface.AddPlayerMappedKey
	void AddPlayerMappableConfig(struct UPlayerMappableInputConfig* Config, struct FModifyContextOptions& Options); // Function EnhancedInput.EnhancedInputSubsystemInterface.AddPlayerMappableConfig
	void AddMappingContext(struct UInputMappingContext* MappingContext, int32_t Priority, struct FModifyContextOptions& Options); // Function EnhancedInput.EnhancedInputSubsystemInterface.AddMappingContext
}; 



// Class EnhancedInput.EnhancedInputLocalPlayerSubsystem
// Size: 0x1E0(Inherited: 0x30) 
struct UEnhancedInputLocalPlayerSubsystem : public ULocalPlayerSubsystem
{
	char pad_48[416];  // 0x30(0x1A0)
	struct FMulticastInlineDelegate ControlMappingsRebuiltDelegate;  // 0x1D0(0x10)

}; 



// Class EnhancedInput.EnhancedPlayerInput
// Size: 0x740(Inherited: 0x498) 
struct UEnhancedPlayerInput : public UPlayerInput
{
	struct TMap<struct UInputMappingContext*, int32_t> AppliedInputContexts;  // 0x498(0x50)
	struct TArray<struct FEnhancedActionKeyMapping> EnhancedActionMappings;  // 0x4E8(0x10)
	char pad_1272[80];  // 0x4F8(0x50)
	struct TMap<struct UInputAction*, struct FInputActionInstance> ActionInstanceData;  // 0x548(0x50)
	char pad_1432[160];  // 0x598(0xA0)
	struct TMap<struct FKey, struct FVector> KeysPressedThisTick;  // 0x638(0x50)
	struct TMap<struct UInputAction*, struct FInjectedInputArray> InputsInjectedThisTick;  // 0x688(0x50)
	struct TSet<struct UInputAction*> LastInjectedActions;  // 0x6D8(0x50)
	char pad_1832[24];  // 0x728(0x18)

}; 



// Class EnhancedInput.InputModifierSmooth
// Size: 0x58(Inherited: 0x28) 
struct UInputModifierSmooth : public UInputModifier
{
	char pad_40[48];  // 0x28(0x30)

}; 



// Class EnhancedInput.InputModifierScaleByDeltaTime
// Size: 0x28(Inherited: 0x28) 
struct UInputModifierScaleByDeltaTime : public UInputModifier
{

}; 



// Class EnhancedInput.InputAction
// Size: 0x70(Inherited: 0x30) 
struct UInputAction : public UDataAsset
{
	struct FText ActionDescription;  // 0x30(0x18)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool bConsumeInput : 1;  // 0x48(0x1)
	char pad_73_1 : 7;  // 0x49(0x1)
	bool bTriggerWhenPaused : 1;  // 0x49(0x1)
	char pad_74_1 : 7;  // 0x4A(0x1)
	bool bReserveAllMappings : 1;  // 0x4A(0x1)
	uint8_t  ValueType;  // 0x4B(0x1)
	char pad_76[4];  // 0x4C(0x4)
	struct TArray<struct UInputTrigger*> Triggers;  // 0x50(0x10)
	struct TArray<struct UInputModifier*> Modifiers;  // 0x60(0x10)

}; 



// Class EnhancedInput.InputDebugKeyDelegateBinding
// Size: 0x38(Inherited: 0x28) 
struct UInputDebugKeyDelegateBinding : public UInputDelegateBinding
{
	struct TArray<struct FBlueprintInputDebugKeyDelegateBinding> InputDebugKeyDelegateBindings;  // 0x28(0x10)

}; 



// Class EnhancedInput.InputMappingContext
// Size: 0x58(Inherited: 0x30) 
struct UInputMappingContext : public UDataAsset
{
	struct TArray<struct FEnhancedActionKeyMapping> Mappings;  // 0x30(0x10)
	struct FText ContextDescription;  // 0x40(0x18)

	void UnmapKey(struct UInputAction* Action, struct FKey Key); // Function EnhancedInput.InputMappingContext.UnmapKey
	void UnmapAllKeysFromAction(struct UInputAction* Action); // Function EnhancedInput.InputMappingContext.UnmapAllKeysFromAction
	void UnmapAll(); // Function EnhancedInput.InputMappingContext.UnmapAll
	void UnmapAction(struct UInputAction* Action); // Function EnhancedInput.InputMappingContext.UnmapAction
	struct FEnhancedActionKeyMapping MapKey(struct UInputAction* Action, struct FKey ToKey); // Function EnhancedInput.InputMappingContext.MapKey
}; 



// Class EnhancedInput.InputModifier
// Size: 0x28(Inherited: 0x28) 
struct UInputModifier : public UObject
{

	struct FInputActionValue ModifyRaw(struct UEnhancedPlayerInput* PlayerInput, struct FInputActionValue CurrentValue, float DeltaTime); // Function EnhancedInput.InputModifier.ModifyRaw
	struct FLinearColor GetVisualizationColor(struct FInputActionValue SampleValue, struct FInputActionValue FinalValue); // Function EnhancedInput.InputModifier.GetVisualizationColor
}; 



// Class EnhancedInput.InputTriggerChordBlocker
// Size: 0x58(Inherited: 0x58) 
struct UInputTriggerChordBlocker : public UInputTriggerChordAction
{

}; 



// Class EnhancedInput.InputModifierDeadZone
// Size: 0x38(Inherited: 0x28) 
struct UInputModifierDeadZone : public UInputModifier
{
	float LowerThreshold;  // 0x28(0x4)
	float UpperThreshold;  // 0x2C(0x4)
	uint8_t  Type;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)

}; 



// Class EnhancedInput.InputModifierResponseCurveExponential
// Size: 0x40(Inherited: 0x28) 
struct UInputModifierResponseCurveExponential : public UInputModifier
{
	struct FVector CurveExponent;  // 0x28(0x18)

}; 



// Class EnhancedInput.InputTrigger
// Size: 0x50(Inherited: 0x28) 
struct UInputTrigger : public UObject
{
	float ActuationThreshold;  // 0x28(0x4)
	char pad_44_1 : 7;  // 0x2C(0x1)
	bool bShouldAlwaysTick : 1;  // 0x2C(0x1)
	char pad_45[3];  // 0x2D(0x3)
	struct FInputActionValue LastValue;  // 0x30(0x20)

	uint8_t  UpdateState(struct UEnhancedPlayerInput* PlayerInput, struct FInputActionValue ModifiedValue, float DeltaTime); // Function EnhancedInput.InputTrigger.UpdateState
	bool IsActuated(struct FInputActionValue& ForValue); // Function EnhancedInput.InputTrigger.IsActuated
	uint8_t  GetTriggerType(); // Function EnhancedInput.InputTrigger.GetTriggerType
}; 



// Class EnhancedInput.InputModifierResponseCurveUser
// Size: 0x40(Inherited: 0x28) 
struct UInputModifierResponseCurveUser : public UInputModifier
{
	struct UCurveFloat* ResponseX;  // 0x28(0x8)
	struct UCurveFloat* ResponseY;  // 0x30(0x8)
	struct UCurveFloat* ResponseZ;  // 0x38(0x8)

}; 



// Class EnhancedInput.InputModifierToWorldSpace
// Size: 0x28(Inherited: 0x28) 
struct UInputModifierToWorldSpace : public UInputModifier
{

}; 



// Class EnhancedInput.InputModifierSwizzleAxis
// Size: 0x30(Inherited: 0x28) 
struct UInputModifierSwizzleAxis : public UInputModifier
{
	uint8_t  Order;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)

}; 



// Class EnhancedInput.InputTriggerTimedBase
// Size: 0x58(Inherited: 0x50) 
struct UInputTriggerTimedBase : public UInputTrigger
{
	float HeldDuration;  // 0x50(0x4)
	char pad_84_1 : 7;  // 0x54(0x1)
	bool bAffectedByTimeDilation : 1;  // 0x54(0x1)
	char pad_85[3];  // 0x55(0x3)

}; 



// Class EnhancedInput.InputTriggerDown
// Size: 0x50(Inherited: 0x50) 
struct UInputTriggerDown : public UInputTrigger
{

}; 



// Class EnhancedInput.InputTriggerPressed
// Size: 0x50(Inherited: 0x50) 
struct UInputTriggerPressed : public UInputTrigger
{

}; 



// Class EnhancedInput.InputTriggerReleased
// Size: 0x50(Inherited: 0x50) 
struct UInputTriggerReleased : public UInputTrigger
{

}; 



// Class EnhancedInput.InputTriggerHold
// Size: 0x68(Inherited: 0x58) 
struct UInputTriggerHold : public UInputTriggerTimedBase
{
	char pad_88[4];  // 0x58(0x4)
	float HoldTimeThreshold;  // 0x5C(0x4)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool bIsOneShot : 1;  // 0x60(0x1)
	char pad_97[7];  // 0x61(0x7)

}; 



// Class EnhancedInput.InputTriggerHoldAndRelease
// Size: 0x60(Inherited: 0x58) 
struct UInputTriggerHoldAndRelease : public UInputTriggerTimedBase
{
	float HoldTimeThreshold;  // 0x58(0x4)
	char pad_92[4];  // 0x5C(0x4)

}; 



// Class EnhancedInput.InputTriggerTap
// Size: 0x60(Inherited: 0x58) 
struct UInputTriggerTap : public UInputTriggerTimedBase
{
	float TapReleaseTimeThreshold;  // 0x58(0x4)
	char pad_92[4];  // 0x5C(0x4)

}; 



// Class EnhancedInput.InputTriggerPulse
// Size: 0x68(Inherited: 0x58) 
struct UInputTriggerPulse : public UInputTriggerTimedBase
{
	char pad_88[4];  // 0x58(0x4)
	char pad_92_1 : 7;  // 0x5C(0x1)
	bool bTriggerOnStart : 1;  // 0x5C(0x1)
	char pad_93[3];  // 0x5D(0x3)
	float interval;  // 0x60(0x4)
	int32_t TriggerLimit;  // 0x64(0x4)

}; 



// Class EnhancedInput.InputTriggerChordAction
// Size: 0x58(Inherited: 0x50) 
struct UInputTriggerChordAction : public UInputTrigger
{
	struct UInputAction* ChordAction;  // 0x50(0x8)

}; 



// Class EnhancedInput.InputTriggerCombo
// Size: 0x78(Inherited: 0x50) 
struct UInputTriggerCombo : public UInputTrigger
{
	int32_t CurrentComboStepIndex;  // 0x50(0x4)
	float CurrentTimeBetweenComboSteps;  // 0x54(0x4)
	struct TArray<struct FInputComboStepData> ComboActions;  // 0x58(0x10)
	struct TArray<struct UInputAction*> CancelActions;  // 0x68(0x10)

}; 



// Class EnhancedInput.PlayerMappableInputConfig
// Size: 0xB0(Inherited: 0x30) 
struct UPlayerMappableInputConfig : public UPrimaryDataAsset
{
	struct FName ConfigName;  // 0x30(0x8)
	struct FText ConfigDisplayName;  // 0x38(0x18)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool bIsDeprecated : 1;  // 0x50(0x1)
	char pad_81[7];  // 0x51(0x7)
	struct UObject* MetaData;  // 0x58(0x8)
	struct TMap<struct UInputMappingContext*, int32_t> Contexts;  // 0x60(0x50)

	void ResetToDefault(); // Function EnhancedInput.PlayerMappableInputConfig.ResetToDefault
	bool IsDeprecated(); // Function EnhancedInput.PlayerMappableInputConfig.IsDeprecated
	struct TArray<struct FEnhancedActionKeyMapping> GetPlayerMappableKeys(); // Function EnhancedInput.PlayerMappableInputConfig.GetPlayerMappableKeys
	struct UObject* GetMetadata(); // Function EnhancedInput.PlayerMappableInputConfig.GetMetadata
	struct TMap<struct UInputMappingContext*, int32_t> GetMappingContexts(); // Function EnhancedInput.PlayerMappableInputConfig.GetMappingContexts
	struct FEnhancedActionKeyMapping GetMappingByName(struct FName MappingName); // Function EnhancedInput.PlayerMappableInputConfig.GetMappingByName
	struct TArray<struct FEnhancedActionKeyMapping> GetKeysBoundToAction(struct UInputAction* InAction); // Function EnhancedInput.PlayerMappableInputConfig.GetKeysBoundToAction
	struct FText GetDisplayName(); // Function EnhancedInput.PlayerMappableInputConfig.GetDisplayName
	struct FName GetConfigName(); // Function EnhancedInput.PlayerMappableInputConfig.GetConfigName
}; 



