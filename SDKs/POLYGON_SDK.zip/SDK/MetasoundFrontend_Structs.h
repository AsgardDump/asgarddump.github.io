#pragma once 
#include "SDK.h" 
 
 
// ScriptStruct MetasoundFrontend.MetasoundFrontendVersionNumber
// Size: 0x8(Inherited: 0x0) 
struct FMetasoundFrontendVersionNumber
{
	int32_t Major;  // 0x0(0x4)
	int32_t Minor;  // 0x4(0x4)

}; 
// ScriptStruct MetasoundFrontend.MetasoundFrontendVertex
// Size: 0x20(Inherited: 0x0) 
struct FMetasoundFrontendVertex
{
	struct FName Name;  // 0x0(0x8)
	struct FName TypeName;  // 0x8(0x8)
	struct FGuid VertexID;  // 0x10(0x10)

}; 
// ScriptStruct MetasoundFrontend.MetasoundFrontendVersion
// Size: 0x10(Inherited: 0x0) 
struct FMetasoundFrontendVersion
{
	struct FName Name;  // 0x0(0x8)
	struct FMetasoundFrontendVersionNumber Number;  // 0x8(0x8)

}; 
// ScriptStruct MetasoundFrontend.MetasoundFrontendClassVariable
// Size: 0x90(Inherited: 0x34) 
struct FMetasoundFrontendClassVariable : public FMetasoundFrontendClassVertex
{
	char pad_52[4];  // 0x34(0x4)
	struct FMetasoundFrontendLiteral DefaultLiteral;  // 0x38(0x58)

}; 
// ScriptStruct MetasoundFrontend.MetasoundFrontendClassStyleDisplay
// Size: 0x1(Inherited: 0x0) 
struct FMetasoundFrontendClassStyleDisplay
{
	char pad_0[1];  // 0x0(0x1)

}; 
// ScriptStruct MetasoundFrontend.MetasoundFrontendVertexLiteral
// Size: 0x68(Inherited: 0x0) 
struct FMetasoundFrontendVertexLiteral
{
	struct FGuid VertexID;  // 0x0(0x10)
	struct FMetasoundFrontendLiteral Value;  // 0x10(0x58)

}; 
// ScriptStruct MetasoundFrontend.MetasoundFrontendGraphStyle
// Size: 0x18(Inherited: 0x0) 
struct FMetasoundFrontendGraphStyle
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bIsGraphEditable : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct TArray<struct FMetasoundFrontendEdgeStyle> EdgeStyles;  // 0x8(0x10)

}; 
// ScriptStruct MetasoundFrontend.MetasoundFrontendNodeStyleDisplay
// Size: 0x1(Inherited: 0x0) 
struct FMetasoundFrontendNodeStyleDisplay
{
	char pad_0[1];  // 0x0(0x1)

}; 
// ScriptStruct MetasoundFrontend.MetasoundFrontendNodeInterface
// Size: 0x30(Inherited: 0x0) 
struct FMetasoundFrontendNodeInterface
{
	struct TArray<struct FMetasoundFrontendVertex> Inputs;  // 0x0(0x10)
	struct TArray<struct FMetasoundFrontendVertex> Outputs;  // 0x10(0x10)
	struct TArray<struct FMetasoundFrontendVertex> Environment;  // 0x20(0x10)

}; 
// ScriptStruct MetasoundFrontend.MetasoundFrontendLiteral
// Size: 0x58(Inherited: 0x0) 
struct FMetasoundFrontendLiteral
{
	uint8_t  Type;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	int32_t AsNumDefault;  // 0x4(0x4)
	struct TArray<bool> AsBoolean;  // 0x8(0x10)
	struct TArray<int32_t> AsInteger;  // 0x18(0x10)
	struct TArray<float> AsFloat;  // 0x28(0x10)
	struct TArray<struct FString> AsString;  // 0x38(0x10)
	struct TArray<struct UObject*> AsUObject;  // 0x48(0x10)

}; 
// ScriptStruct MetasoundFrontend.MetasoundFrontendVariable
// Size: 0xB8(Inherited: 0x0) 
struct FMetasoundFrontendVariable
{
	struct FName Name;  // 0x0(0x8)
	struct FName TypeName;  // 0x8(0x8)
	struct FMetasoundFrontendLiteral Literal;  // 0x10(0x58)
	struct FGuid ID;  // 0x68(0x10)
	struct FGuid VariableNodeID;  // 0x78(0x10)
	struct FGuid MutatorNodeID;  // 0x88(0x10)
	struct TArray<struct FGuid> AccessorNodeIDs;  // 0x98(0x10)
	struct TArray<struct FGuid> DeferredAccessorNodeIDs;  // 0xA8(0x10)

}; 
// ScriptStruct MetasoundFrontend.MetasoundFrontendNodeStyle
// Size: 0x1(Inherited: 0x0) 
struct FMetasoundFrontendNodeStyle
{
	char pad_0[1];  // 0x0(0x1)

}; 
// ScriptStruct MetasoundFrontend.MetasoundFrontendEdgeStyle
// Size: 0x28(Inherited: 0x0) 
struct FMetasoundFrontendEdgeStyle
{
	struct FGuid NodeID;  // 0x0(0x10)
	struct FName OutputName;  // 0x10(0x8)
	struct TArray<struct FMetasoundFrontendEdgeStyleLiteralColorPair> LiteralColorPairs;  // 0x18(0x10)

}; 
// ScriptStruct MetasoundFrontend.MetasoundFrontendNode
// Size: 0x68(Inherited: 0x0) 
struct FMetasoundFrontendNode
{
	struct FGuid ID;  // 0x0(0x10)
	struct FGuid ClassID;  // 0x10(0x10)
	struct FName Name;  // 0x20(0x8)
	struct FMetasoundFrontendNodeInterface Interface;  // 0x28(0x30)
	struct TArray<struct FMetasoundFrontendVertexLiteral> InputLiterals;  // 0x58(0x10)

}; 
// ScriptStruct MetasoundFrontend.MetasoundFrontendDocument
// Size: 0x1C8(Inherited: 0x0) 
struct FMetasoundFrontendDocument
{
	char pad_0[16];  // 0x0(0x10)
	struct FMetasoundFrontendDocumentMetadata MetaData;  // 0x10(0x10)
	struct TSet<struct FMetasoundFrontendVersion> Interfaces;  // 0x20(0x50)
	struct FMetasoundFrontendGraphClass RootGraph;  // 0x70(0x118)
	struct TArray<struct FMetasoundFrontendGraphClass> Subgraphs;  // 0x188(0x10)
	struct TArray<struct FMetasoundFrontendClass> Dependencies;  // 0x198(0x10)
	struct FMetasoundFrontendVersion ArchetypeVersion;  // 0x1A8(0x10)
	struct TArray<struct FMetasoundFrontendVersion> InterfaceVersions;  // 0x1B8(0x10)

}; 
// ScriptStruct MetasoundFrontend.MetasoundFrontendEdge
// Size: 0x40(Inherited: 0x0) 
struct FMetasoundFrontendEdge
{
	struct FGuid FromNodeID;  // 0x0(0x10)
	struct FGuid FromVertexID;  // 0x10(0x10)
	struct FGuid ToNodeID;  // 0x20(0x10)
	struct FGuid ToVertexID;  // 0x30(0x10)

}; 
// ScriptStruct MetasoundFrontend.MetasoundFrontendEdgeStyleLiteralColorPair
// Size: 0x68(Inherited: 0x0) 
struct FMetasoundFrontendEdgeStyleLiteralColorPair
{
	struct FMetasoundFrontendLiteral Value;  // 0x0(0x58)
	struct FLinearColor Color;  // 0x58(0x10)

}; 
// ScriptStruct MetasoundFrontend.MetasoundFrontendGraph
// Size: 0x30(Inherited: 0x0) 
struct FMetasoundFrontendGraph
{
	struct TArray<struct FMetasoundFrontendNode> Nodes;  // 0x0(0x10)
	struct TArray<struct FMetasoundFrontendEdge> Edges;  // 0x10(0x10)
	struct TArray<struct FMetasoundFrontendVariable> Variables;  // 0x20(0x10)

}; 
// ScriptStruct MetasoundFrontend.MetasoundFrontendVertexMetadata
// Size: 0x1(Inherited: 0x0) 
struct FMetasoundFrontendVertexMetadata
{
	char pad_0[1];  // 0x0(0x1)

}; 
// ScriptStruct MetasoundFrontend.MetasoundFrontendClassEnvironmentVariable
// Size: 0x14(Inherited: 0x0) 
struct FMetasoundFrontendClassEnvironmentVariable
{
	struct FName Name;  // 0x0(0x8)
	struct FName TypeName;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bIsRequired : 1;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)

}; 
// ScriptStruct MetasoundFrontend.MetasoundFrontendClassVertex
// Size: 0x34(Inherited: 0x20) 
struct FMetasoundFrontendClassVertex : public FMetasoundFrontendVertex
{
	struct FGuid NodeID;  // 0x20(0x10)
	uint8_t  AccessType;  // 0x30(0x4)

}; 
// ScriptStruct MetasoundFrontend.MetasoundFrontendClassInput
// Size: 0x90(Inherited: 0x34) 
struct FMetasoundFrontendClassInput : public FMetasoundFrontendClassVertex
{
	char pad_52[4];  // 0x34(0x4)
	struct FMetasoundFrontendLiteral DefaultLiteral;  // 0x38(0x58)

}; 
// ScriptStruct MetasoundFrontend.MetasoundFrontendClassOutput
// Size: 0x34(Inherited: 0x34) 
struct FMetasoundFrontendClassOutput : public FMetasoundFrontendClassVertex
{

}; 
// ScriptStruct MetasoundFrontend.MetasoundFrontendInterfaceStyle
// Size: 0x1(Inherited: 0x0) 
struct FMetasoundFrontendInterfaceStyle
{
	char pad_0[1];  // 0x0(0x1)

}; 
// ScriptStruct MetasoundFrontend.MetasoundFrontendClassInterface
// Size: 0x40(Inherited: 0x0) 
struct FMetasoundFrontendClassInterface
{
	struct TArray<struct FMetasoundFrontendClassInput> Inputs;  // 0x0(0x10)
	struct TArray<struct FMetasoundFrontendClassOutput> Outputs;  // 0x10(0x10)
	struct TArray<struct FMetasoundFrontendClassEnvironmentVariable> Environment;  // 0x20(0x10)
	struct FGuid ChangeID;  // 0x30(0x10)

}; 
// ScriptStruct MetasoundFrontend.MetasoundFrontendInterface
// Size: 0x50(Inherited: 0x40) 
struct FMetasoundFrontendInterface : public FMetasoundFrontendClassInterface
{
	struct FMetasoundFrontendVersion Version;  // 0x40(0x10)

}; 
// ScriptStruct MetasoundFrontend.MetasoundFrontendClassName
// Size: 0x18(Inherited: 0x0) 
struct FMetasoundFrontendClassName
{
	struct FName Namespace;  // 0x0(0x8)
	struct FName Name;  // 0x8(0x8)
	struct FName Variant;  // 0x10(0x8)

}; 
// ScriptStruct MetasoundFrontend.MetasoundFrontendClassMetadata
// Size: 0x34(Inherited: 0x0) 
struct FMetasoundFrontendClassMetadata
{
	struct FMetasoundFrontendClassName ClassName;  // 0x0(0x18)
	struct FMetasoundFrontendVersionNumber Version;  // 0x18(0x8)
	uint8_t  Type;  // 0x20(0x1)
	char pad_33_1 : 7;  // 0x21(0x1)
	bool bIsDeprecated : 1;  // 0x21(0x1)
	char pad_34_1 : 7;  // 0x22(0x1)
	bool bAutoUpdateManagesInterface : 1;  // 0x22(0x1)
	char pad_35[1];  // 0x23(0x1)
	struct FGuid ChangeID;  // 0x24(0x10)

}; 
// ScriptStruct MetasoundFrontend.MetasoundFrontendClassStyle
// Size: 0x1(Inherited: 0x0) 
struct FMetasoundFrontendClassStyle
{
	char pad_0[1];  // 0x0(0x1)

}; 
// ScriptStruct MetasoundFrontend.MetasoundFrontendClass
// Size: 0x90(Inherited: 0x0) 
struct FMetasoundFrontendClass
{
	char pad_0[8];  // 0x0(0x8)
	struct FGuid ID;  // 0x8(0x10)
	struct FMetasoundFrontendClassMetadata MetaData;  // 0x18(0x34)
	char pad_76[4];  // 0x4C(0x4)
	struct FMetasoundFrontendClassInterface Interface;  // 0x50(0x40)

}; 
// ScriptStruct MetasoundFrontend.MetasoundFrontendGraphClassPresetOptions
// Size: 0x58(Inherited: 0x0) 
struct FMetasoundFrontendGraphClassPresetOptions
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bIsPreset : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct TSet<struct FName> InputsInheritingDefault;  // 0x8(0x50)

}; 
// ScriptStruct MetasoundFrontend.MetasoundFrontendGraphClass
// Size: 0x118(Inherited: 0x90) 
struct FMetasoundFrontendGraphClass : public FMetasoundFrontendClass
{
	struct FMetasoundFrontendGraph Graph;  // 0x90(0x30)
	struct FMetasoundFrontendGraphClassPresetOptions PresetOptions;  // 0xC0(0x58)

}; 
// ScriptStruct MetasoundFrontend.MetasoundFrontendDocumentMetadata
// Size: 0x10(Inherited: 0x0) 
struct FMetasoundFrontendDocumentMetadata
{
	struct FMetasoundFrontendVersion Version;  // 0x0(0x10)

}; 
