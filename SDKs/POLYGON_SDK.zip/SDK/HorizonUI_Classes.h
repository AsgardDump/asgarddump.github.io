#pragma once 
#include <HorizonUI_Structs.h>
 
 
 
// Class HorizonUI.HorizonImage
// Size: 0x2D0(Inherited: 0x2B0) 
struct UHorizonImage : public UImage
{
	struct FBox2D UVRegion;  // 0x2A8(0x28)

}; 



// Class HorizonUI.HorizonButton
// Size: 0x6B0(Inherited: 0x5F0) 
struct UHorizonButton : public UButton
{
	struct FMulticastInlineDelegate OnClickedDelegate;  // 0x5E8(0x10)
	struct FMulticastInlineDelegate OnPressedDelegate;  // 0x5F8(0x10)
	struct FMulticastInlineDelegate OnReleasedDelegate;  // 0x608(0x10)
	struct FMulticastInlineDelegate OnHoveredDelegate;  // 0x618(0x10)
	struct FMulticastInlineDelegate OnUnhoveredDelegate;  // 0x628(0x10)
	char pad_1600[112];  // 0x640(0x70)

	void OnUnhoveredButton(); // Function HorizonUI.HorizonButton.OnUnhoveredButton
	void OnReleasedButton(); // Function HorizonUI.HorizonButton.OnReleasedButton
	void OnPressedButton(); // Function HorizonUI.HorizonButton.OnPressedButton
	void OnHoveredButton(); // Function HorizonUI.HorizonButton.OnHoveredButton
	void OnHorizonButtonEvent__DelegateSignature(struct UHorizonButton* Button); // DelegateFunction HorizonUI.HorizonButton.OnHorizonButtonEvent__DelegateSignature
	void OnClickedButton(); // Function HorizonUI.HorizonButton.OnClickedButton
}; 



// Class HorizonUI.HorizonUserWidget
// Size: 0x278(Inherited: 0x278) 
struct UHorizonUserWidget : public UUserWidget
{

}; 



// Class HorizonUI.HorizonDialogueMsgDecorator
// Size: 0x28(Inherited: 0x28) 
struct UHorizonDialogueMsgDecorator : public UObject
{

	bool Run(struct UHorizonDialogueMsgTextBlock* InMsgTextBlock, struct FHorizonDialogueBlockInfo& InDialogueBlockInfo, struct FHorizonDialogueSegmentInfo& InSegInfo); // Function HorizonUI.HorizonDialogueMsgDecorator.Run
	bool PreRun(struct UHorizonDialogueMsgTextBlock* InMsgTextBlock, struct FHorizonDialogueBlockInfo& InDialogueBlockInfo, struct FHorizonDialogueSegmentInfo& InSegInfo); // Function HorizonUI.HorizonDialogueMsgDecorator.PreRun
	bool BuildSegment(struct UHorizonDialogueMsgTextBlock* InMsgTextBlock, int32_t InCurrentSegInfoIndex, struct FHorizonDialogueSegmentInfo& InCurrentSegInfo, struct TArray<struct FHorizonDialogueSegmentInfo>& InSegInfos); // Function HorizonUI.HorizonDialogueMsgDecorator.BuildSegment
}; 



// Class HorizonUI.HorizonDialogueMsgSpaceDecorator
// Size: 0x60(Inherited: 0x28) 
struct UHorizonDialogueMsgSpaceDecorator : public UHorizonDialogueMsgDecorator
{
	struct FText FirstLineSpaceL;  // 0x28(0x18)
	struct FText Space;  // 0x40(0x18)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool bDefaultWithSpaceL_AlphabeticOnly : 1;  // 0x58(0x1)
	char pad_89[7];  // 0x59(0x7)

}; 



// Class HorizonUI.HorizonButtonUserWidget
// Size: 0x4A0(Inherited: 0x278) 
struct UHorizonButtonUserWidget : public UHorizonDesignableUserWidget
{
	struct FMulticastInlineDelegate OnButtonClickedDelegate;  // 0x278(0x10)
	struct FMulticastInlineDelegate OnButtonPressedDelegate;  // 0x288(0x10)
	struct FMulticastInlineDelegate OnButtonReleasedDelegate;  // 0x298(0x10)
	struct FMulticastInlineDelegate OnButtonHoveredDelegate;  // 0x2A8(0x10)
	struct FMulticastInlineDelegate OnButtonUnhoveredDelegate;  // 0x2B8(0x10)
	struct FMulticastInlineDelegate OnButtonFocusDelegate;  // 0x2C8(0x10)
	struct FMulticastInlineDelegate OnButtonFocusLostDelegate;  // 0x2D8(0x10)
	char pad_744[168];  // 0x2E8(0xA8)
	struct UButton* Button_Main;  // 0x390(0x8)
	struct UTextBlock* TextBlock_Main;  // 0x398(0x8)
	struct UImage* Image_Main;  // 0x3A0(0x8)
	struct FText Text_Main;  // 0x3A8(0x18)
	struct FSlateBrush SlateBrush_ImageMain;  // 0x3C0(0xD0)
	char pad_1168_1 : 7;  // 0x490(0x1)
	bool bFocusOnHovered : 1;  // 0x490(0x1)
	char pad_1169_1 : 7;  // 0x491(0x1)
	bool bButtonFocused : 1;  // 0x491(0x1)
	char pad_1170[14];  // 0x492(0xE)

	void ReceiveOnOnButtonFocusLost(struct FFocusEvent& InFocusEvent); // Function HorizonUI.HorizonButtonUserWidget.ReceiveOnOnButtonFocusLost
	void ReceiveOnButtonUnhovered(); // Function HorizonUI.HorizonButtonUserWidget.ReceiveOnButtonUnhovered
	void ReceiveOnButtonReleased(); // Function HorizonUI.HorizonButtonUserWidget.ReceiveOnButtonReleased
	void ReceiveOnButtonPressed(); // Function HorizonUI.HorizonButtonUserWidget.ReceiveOnButtonPressed
	void ReceiveOnButtonHovered(); // Function HorizonUI.HorizonButtonUserWidget.ReceiveOnButtonHovered
	void ReceiveOnButtonFocus(struct FFocusEvent& InFocusEvent); // Function HorizonUI.HorizonButtonUserWidget.ReceiveOnButtonFocus
	void ReceiveOnButtonClicked(); // Function HorizonUI.HorizonButtonUserWidget.ReceiveOnButtonClicked
	void OnHorizonButtonFocusEvent__DelegateSignature(struct UHorizonButtonUserWidget* InButton, struct FFocusEvent& InFocusEvent); // DelegateFunction HorizonUI.HorizonButtonUserWidget.OnHorizonButtonFocusEvent__DelegateSignature
	void OnHorizonButtonEvent__DelegateSignature(struct UHorizonButtonUserWidget* InButton); // DelegateFunction HorizonUI.HorizonButtonUserWidget.OnHorizonButtonEvent__DelegateSignature
	void NativeOnButtonUnhovered(); // Function HorizonUI.HorizonButtonUserWidget.NativeOnButtonUnhovered
	void NativeOnButtonReleased(); // Function HorizonUI.HorizonButtonUserWidget.NativeOnButtonReleased
	void NativeOnButtonPressed(); // Function HorizonUI.HorizonButtonUserWidget.NativeOnButtonPressed
	void NativeOnButtonHovered(); // Function HorizonUI.HorizonButtonUserWidget.NativeOnButtonHovered
	void NativeOnButtonClicked(); // Function HorizonUI.HorizonButtonUserWidget.NativeOnButtonClicked
}; 



// Class HorizonUI.HorizonDesignableUserWidget
// Size: 0x278(Inherited: 0x278) 
struct UHorizonDesignableUserWidget : public UHorizonUserWidget
{

	void SynchronizeProperties(); // Function HorizonUI.HorizonDesignableUserWidget.SynchronizeProperties
	void OnSynchronizeProperties(); // Function HorizonUI.HorizonDesignableUserWidget.OnSynchronizeProperties
}; 



// Class HorizonUI.HorizonDialogueMsgTextBlock
// Size: 0x568(Inherited: 0x178) 
struct UHorizonDialogueMsgTextBlock : public UCanvasPanel
{
	char pad_376[8];  // 0x178(0x8)
	struct FMulticastInlineDelegate OnHypertextClickedDelegate;  // 0x180(0x10)
	char pad_400[24];  // 0x190(0x18)
	struct FMulticastInlineDelegate OnHypertextPressedDelegate;  // 0x1A8(0x10)
	char pad_440[24];  // 0x1B8(0x18)
	struct FMulticastInlineDelegate OnHypertextReleasedDelegate;  // 0x1D0(0x10)
	char pad_480[24];  // 0x1E0(0x18)
	struct FMulticastInlineDelegate OnHypertextHoveredDelegate;  // 0x1F8(0x10)
	char pad_520[24];  // 0x208(0x18)
	struct FMulticastInlineDelegate OnHypertextUnhoveredDelegate;  // 0x220(0x10)
	char pad_560[24];  // 0x230(0x18)
	struct FMulticastInlineDelegate OnDialogueMsgLoopFunction;  // 0x248(0x10)
	char pad_600[24];  // 0x258(0x18)
	struct FMulticastInlineDelegate OnDialogueMsgCompleteFunction;  // 0x270(0x10)
	char pad_640[24];  // 0x280(0x18)
	struct FMulticastInlineDelegate OnSetDialoguePageFunction;  // 0x298(0x10)
	char pad_680[24];  // 0x2A8(0x18)
	struct FMulticastInlineDelegate OnDialoguePageEndFunction;  // 0x2C0(0x10)
	char pad_720[24];  // 0x2D0(0x18)
	struct FMulticastInlineDelegate OnRebuildDialogueDelegate;  // 0x2E8(0x10)
	char pad_760[24];  // 0x2F8(0x18)
	struct FMulticastInlineDelegate OnCustomEventDelegate;  // 0x310(0x10)
	char pad_800[24];  // 0x320(0x18)
	struct FMulticastInlineDelegate OnCharAdvancedDelegate;  // 0x338(0x10)
	char pad_840[24];  // 0x348(0x18)
	struct FText Text;  // 0x360(0x18)
	uint8_t  TextOverFlowWrapMethod;  // 0x378(0x1)
	uint8_t  TextOverFlowWarpMethod;  // 0x379(0x1)
	char pad_890[2];  // 0x37A(0x2)
	float DialogueMsgSpeed;  // 0x37C(0x4)
	char pad_896_1 : 7;  // 0x380(0x1)
	bool bIsStartTickDialogueMsg : 1;  // 0x380(0x1)
	char pad_897_1 : 7;  // 0x381(0x1)
	bool bIsRepeatDialogueMsg : 1;  // 0x381(0x1)
	char pad_898[2];  // 0x382(0x2)
	float RepeatDialogueMsgInterval;  // 0x384(0x4)
	char pad_904_1 : 7;  // 0x388(0x1)
	bool bIsDialogueMsgText : 1;  // 0x388(0x1)
	char pad_905_1 : 7;  // 0x389(0x1)
	bool bIsAutoNextDialogueMsgPage : 1;  // 0x389(0x1)
	char pad_906[2];  // 0x38A(0x2)
	float AutoNextDialogueMsgPageIntervalRate;  // 0x38C(0x4)
	float AutoNextDialogueMsgPageIntervalMin;  // 0x390(0x4)
	float AutoNextDialogueMsgPageIntervalMax;  // 0x394(0x4)
	char pad_920_1 : 7;  // 0x398(0x1)
	bool bIgnoreTimeDilation : 1;  // 0x398(0x1)
	char pad_921[3];  // 0x399(0x3)
	float CustomTimeDilation;  // 0x39C(0x4)
	char pad_928_1 : 7;  // 0x3A0(0x1)
	bool bForceRebuildDialogueMsgText : 1;  // 0x3A0(0x1)
	char pad_929_1 : 7;  // 0x3A1(0x1)
	bool bEnableBlinkingCursor : 1;  // 0x3A1(0x1)
	char pad_930[6];  // 0x3A2(0x6)
	struct FHorizonDialogueBlinkingCursorInfo BlinkCursorInfo;  // 0x3A8(0x70)
	struct TArray<UHorizonDialogueStyleInfo*> StyleInfoClassList;  // 0x418(0x10)
	struct TArray<struct FHorizonDialogueSegmentInfoStyle> SegmentStyleList;  // 0x428(0x10)
	char pad_1080_1 : 7;  // 0x438(0x1)
	bool bIsRichText : 1;  // 0x438(0x1)
	char pad_1081[3];  // 0x439(0x3)
	struct FSlateColor ColorAndOpacity;  // 0x43C(0x14)
	struct FSlateFontInfo Font;  // 0x450(0x58)
	struct FVector2D ShadowOffset;  // 0x4A8(0x10)
	struct FLinearColor ShadowColorAndOpacity;  // 0x4B8(0x10)
	char ETextJustify Justification;  // 0x4C8(0x1)
	char pad_1225[3];  // 0x4C9(0x3)
	struct FMargin LineMargin;  // 0x4CC(0x10)
	char pad_1244[4];  // 0x4DC(0x4)
	UHorizonButton* DefaultButtonStyleWidgetClass;  // 0x4E0(0x8)
	struct TArray<UHorizonDialogueMsgDecorator*> DecoratorClasses;  // 0x4E8(0x10)
	char pad_1272[80];  // 0x4F8(0x50)
	struct TArray<struct UHorizonDialogueStyleInfo*> StyleInfoList;  // 0x548(0x10)
	char pad_1368[16];  // 0x558(0x10)

	void StopDialogue(); // Function HorizonUI.HorizonDialogueMsgTextBlock.StopDialogue
	void StartDialogue(); // Function HorizonUI.HorizonDialogueMsgTextBlock.StartDialogue
	void SkipDialogue(); // Function HorizonUI.HorizonDialogueMsgTextBlock.SkipDialogue
	void SkipCurrentDialoguePage(); // Function HorizonUI.HorizonDialogueMsgTextBlock.SkipCurrentDialoguePage
	void SkipCurrentDialogueMsgPageTick(); // Function HorizonUI.HorizonDialogueMsgTextBlock.SkipCurrentDialogueMsgPageTick
	void SetTextOverflowWrapMethod(uint8_t  InOverflowWrapMethod); // Function HorizonUI.HorizonDialogueMsgTextBlock.SetTextOverflowWrapMethod
	void SetTextAndRebuildDialogue(struct FText& InText); // Function HorizonUI.HorizonDialogueMsgTextBlock.SetTextAndRebuildDialogue
	void SetShadowOffset(struct FVector2D InShadowOffset, bool bForce); // Function HorizonUI.HorizonDialogueMsgTextBlock.SetShadowOffset
	void SetShadowColorAndOpacity(struct FLinearColor InShadowColorAndOpacity, bool bForce); // Function HorizonUI.HorizonDialogueMsgTextBlock.SetShadowColorAndOpacity
	void SetRepeatDialogueMsgInterval(float interval); // Function HorizonUI.HorizonDialogueMsgTextBlock.SetRepeatDialogueMsgInterval
	void SetOpacity(float InOpacity); // Function HorizonUI.HorizonDialogueMsgTextBlock.SetOpacity
	void SetJustification(char ETextJustify InJustification, bool bForce); // Function HorizonUI.HorizonDialogueMsgTextBlock.SetJustification
	void SetIsStartTickDialogueMsg(bool bShouldStartTick, bool bShouldResetDialogue); // Function HorizonUI.HorizonDialogueMsgTextBlock.SetIsStartTickDialogueMsg
	void SetIsRepeatDialogueMsg(bool B); // Function HorizonUI.HorizonDialogueMsgTextBlock.SetIsRepeatDialogueMsg
	void SetIsDialogueMsgText(bool B); // Function HorizonUI.HorizonDialogueMsgTextBlock.SetIsDialogueMsgText
	void SetIsAutoNextDialogueMsgPage(bool B); // Function HorizonUI.HorizonDialogueMsgTextBlock.SetIsAutoNextDialogueMsgPage
	void SetFontSize(int32_t FontSize); // Function HorizonUI.HorizonDialogueMsgTextBlock.SetFontSize
	void SetFont(struct FSlateFontInfo InFontInfo, bool bForce); // Function HorizonUI.HorizonDialogueMsgTextBlock.SetFont
	void SetDialogueMsgSpeed(float Speed, bool bForce); // Function HorizonUI.HorizonDialogueMsgTextBlock.SetDialogueMsgSpeed
	void SetDialogueMsgPage(int32_t InPageIndex, bool bShouldStartTick); // Function HorizonUI.HorizonDialogueMsgTextBlock.SetDialogueMsgPage
	void SetColorAndOpacity(struct FSlateColor InColorAndOpacity); // Function HorizonUI.HorizonDialogueMsgTextBlock.SetColorAndOpacity
	void SetAutoNextDialogueMsgPageIntervalRate(float InAutoNextDialogueMsgPageIntervalRate); // Function HorizonUI.HorizonDialogueMsgTextBlock.SetAutoNextDialogueMsgPageIntervalRate
	void ResumeDialogue(); // Function HorizonUI.HorizonDialogueMsgTextBlock.ResumeDialogue
	void RequestRebuildDialogue(); // Function HorizonUI.HorizonDialogueMsgTextBlock.RequestRebuildDialogue
	void PrevDialogueMsgPage(bool bShouldStartTick); // Function HorizonUI.HorizonDialogueMsgTextBlock.PrevDialogueMsgPage
	void PauseDialogue(); // Function HorizonUI.HorizonDialogueMsgTextBlock.PauseDialogue
	void OnHorizonHypertextEvent__DelegateSignature(struct FHorizonDialogueHypertextResult& InResult); // DelegateFunction HorizonUI.HorizonDialogueMsgTextBlock.OnHorizonHypertextEvent__DelegateSignature
	void OnHorizonDialoguePageEvent__DelegateSignature(struct FHorizonDialogueDialoguePageResult& InResult); // DelegateFunction HorizonUI.HorizonDialogueMsgTextBlock.OnHorizonDialoguePageEvent__DelegateSignature
	void OnHorizonDialogueMsgEvent__DelegateSignature(); // DelegateFunction HorizonUI.HorizonDialogueMsgTextBlock.OnHorizonDialogueMsgEvent__DelegateSignature
	void OnHorizonDialogueCustomEvent__DelegateSignature(struct FString InEventName, struct FHorizonDialogueSegmentInfo& InSegInfo); // DelegateFunction HorizonUI.HorizonDialogueMsgTextBlock.OnHorizonDialogueCustomEvent__DelegateSignature
	void OnHorizonDialogueCharAdvancedEvent__DelegateSignature(struct FHorizonDialogueBlockInfo& InCurrentBlockInfo); // DelegateFunction HorizonUI.HorizonDialogueMsgTextBlock.OnHorizonDialogueCharAdvancedEvent__DelegateSignature
	void NextDialogueMsgPage(bool bShouldStartTick); // Function HorizonUI.HorizonDialogueMsgTextBlock.NextDialogueMsgPage
	bool IsDialogueMsgPageEnd(); // Function HorizonUI.HorizonDialogueMsgTextBlock.IsDialogueMsgPageEnd
	bool IsDialogueMsgCompleted(); // Function HorizonUI.HorizonDialogueMsgTextBlock.IsDialogueMsgCompleted
	uint8_t  GetTextOverflowWrapMethod(); // Function HorizonUI.HorizonDialogueMsgTextBlock.GetTextOverflowWrapMethod
	int32_t GetTextLength(); // Function HorizonUI.HorizonDialogueMsgTextBlock.GetTextLength
	struct FText GetText(); // Function HorizonUI.HorizonDialogueMsgTextBlock.GetText
	struct FText GetPageTextByIndex(int32_t PageIndex); // Function HorizonUI.HorizonDialogueMsgTextBlock.GetPageTextByIndex
	int32_t GetNumPage(); // Function HorizonUI.HorizonDialogueMsgTextBlock.GetNumPage
	char ETextJustify GetJustification(); // Function HorizonUI.HorizonDialogueMsgTextBlock.GetJustification
	int32_t GetCurrentPageTextLength(); // Function HorizonUI.HorizonDialogueMsgTextBlock.GetCurrentPageTextLength
	int32_t GetCurrentPageIndex(); // Function HorizonUI.HorizonDialogueMsgTextBlock.GetCurrentPageIndex
	struct UHorizonFlipbookWidget* GetBlinkCursorWidget(); // Function HorizonUI.HorizonDialogueMsgTextBlock.GetBlinkCursorWidget
}; 



// Class HorizonUI.HorizonDialogueStyleInfo
// Size: 0x38(Inherited: 0x28) 
struct UHorizonDialogueStyleInfo : public UObject
{
	struct TArray<struct FHorizonDialogueSegmentInfoStyle> SegmentStyleList;  // 0x28(0x10)

}; 



// Class HorizonUI.HorizonFileSystem
// Size: 0x38(Inherited: 0x28) 
struct UHorizonFileSystem : public UObject
{
	char pad_40[16];  // 0x28(0x10)

	struct UObject* LoadUAsset(struct FString InPackageFilePath); // Function HorizonUI.HorizonFileSystem.LoadUAsset
	struct UTexture2D* LoadTexture2D(struct FString InPackageFilePath, int32_t& OutWidth, int32_t& OutHeight); // Function HorizonUI.HorizonFileSystem.LoadTexture2D
	struct USoundBase* LoadSound(struct FString InPackageFilePath); // Function HorizonUI.HorizonFileSystem.LoadSound
	struct UPaperFlipbook* LoadPaperFlipbook(struct FString InPackageFilePath); // Function HorizonUI.HorizonFileSystem.LoadPaperFlipbook
	struct UMaterial* LoadMaterial(struct FString InPackageFilePath); // Function HorizonUI.HorizonFileSystem.LoadMaterial
	struct UFont* LoadFont(struct FString InPackageFilePath); // Function HorizonUI.HorizonFileSystem.LoadFont
	struct UHorizonFileSystem* GetInstance(); // Function HorizonUI.HorizonFileSystem.GetInstance
	void DestroyInstance(); // Function HorizonUI.HorizonFileSystem.DestroyInstance
	void CreateDirectoryRecursively(struct FString InFolderToMake); // Function HorizonUI.HorizonFileSystem.CreateDirectoryRecursively
}; 



// Class HorizonUI.HorizonFlipbookWidget
// Size: 0x330(Inherited: 0x2B0) 
struct UHorizonFlipbookWidget : public UImage
{
	char pad_688_1 : 7;  // 0x2B0(0x1)
	bool bIsStartTick : 1;  // 0x2B0(0x1)
	char pad_689[3];  // 0x2B1(0x3)
	int32_t NumOfLoop;  // 0x2B4(0x4)
	char pad_696_1 : 7;  // 0x2B8(0x1)
	bool bAnimationFinished : 1;  // 0x2B8(0x1)
	char pad_697[7];  // 0x2B9(0x7)
	struct UPaperFlipbook* PaperFlipbook;  // 0x2C0(0x8)
	struct FMulticastInlineDelegate OnAnimationStart;  // 0x2C8(0x10)
	char pad_728[24];  // 0x2D8(0x18)
	struct FMulticastInlineDelegate OnAnimationFinished;  // 0x2F0(0x10)
	char pad_768[48];  // 0x300(0x30)

	void StopAnimation(); // Function HorizonUI.HorizonFlipbookWidget.StopAnimation
	void SetFlipbook(struct UPaperFlipbook* InFlipbook); // Function HorizonUI.HorizonFlipbookWidget.SetFlipbook
	void SetCurrentAnimationDuration(float InDuration); // Function HorizonUI.HorizonFlipbookWidget.SetCurrentAnimationDuration
	void ResumeAnimation(); // Function HorizonUI.HorizonFlipbookWidget.ResumeAnimation
	void ResetAnimation(); // Function HorizonUI.HorizonFlipbookWidget.ResetAnimation
	void PlayAnimation(); // Function HorizonUI.HorizonFlipbookWidget.PlayAnimation
	void PauseAnimation(); // Function HorizonUI.HorizonFlipbookWidget.PauseAnimation
	void OnHorizonFlipbookStartEvent__DelegateSignature(int32_t InCurrentNumOfLoop); // DelegateFunction HorizonUI.HorizonFlipbookWidget.OnHorizonFlipbookStartEvent__DelegateSignature
	void OnHorizonFlipbookEvent__DelegateSignature(); // DelegateFunction HorizonUI.HorizonFlipbookWidget.OnHorizonFlipbookEvent__DelegateSignature
	float GetCurrentAnimationDuration(); // Function HorizonUI.HorizonFlipbookWidget.GetCurrentAnimationDuration
}; 



// Class HorizonUI.HorizonListViewItemObject
// Size: 0x28(Inherited: 0x28) 
struct UHorizonListViewItemObject : public UObject
{

}; 



// Class HorizonUI.HorizonListViewItemWidget
// Size: 0x288(Inherited: 0x278) 
struct UHorizonListViewItemWidget : public UUserWidget
{
	char pad_632[8];  // 0x278(0x8)
	struct UButton* Button_ClickArea;  // 0x280(0x8)

	void SynchronizeProperties(); // Function HorizonUI.HorizonListViewItemWidget.SynchronizeProperties
	void OnSynchronizeProperties(); // Function HorizonUI.HorizonListViewItemWidget.OnSynchronizeProperties
	void OnListItemObjectUnhovered(); // Function HorizonUI.HorizonListViewItemWidget.OnListItemObjectUnhovered
	void OnListItemObjectReleased(); // Function HorizonUI.HorizonListViewItemWidget.OnListItemObjectReleased
	void OnListItemObjectPressed(); // Function HorizonUI.HorizonListViewItemWidget.OnListItemObjectPressed
	void OnListItemObjectHovered(); // Function HorizonUI.HorizonListViewItemWidget.OnListItemObjectHovered
	void OnListItemObjectClicked(); // Function HorizonUI.HorizonListViewItemWidget.OnListItemObjectClicked
	void OnListItemObjectButtonUnhovered(); // Function HorizonUI.HorizonListViewItemWidget.OnListItemObjectButtonUnhovered
	void OnListItemObjectButtonReleased(); // Function HorizonUI.HorizonListViewItemWidget.OnListItemObjectButtonReleased
	void OnListItemObjectButtonPressed(); // Function HorizonUI.HorizonListViewItemWidget.OnListItemObjectButtonPressed
	void OnListItemObjectButtonHovered(); // Function HorizonUI.HorizonListViewItemWidget.OnListItemObjectButtonHovered
	void OnListItemObjectButtonClicked(); // Function HorizonUI.HorizonListViewItemWidget.OnListItemObjectButtonClicked
}; 



// Class HorizonUI.HorizonMultiToggleButtonWidget
// Size: 0x300(Inherited: 0x278) 
struct UHorizonMultiToggleButtonWidget : public UHorizonDesignableUserWidget
{
	struct FMulticastInlineDelegate OnStateSyncDelegate;  // 0x278(0x10)
	char pad_648[24];  // 0x288(0x18)
	struct FMulticastInlineDelegate OnStateChangedDelegate;  // 0x2A0(0x10)
	char pad_688[24];  // 0x2B0(0x18)
	struct UButton* Button_ToggleState_Prev;  // 0x2C8(0x8)
	struct UButton* Button_ToggleState_Next;  // 0x2D0(0x8)
	struct UTextBlock* TextBlock_CurrentState;  // 0x2D8(0x8)
	struct UImage* Image_CurrentState;  // 0x2E0(0x8)
	struct TArray<struct FHorizonMultiToggleButtonState> StateList;  // 0x2E8(0x10)
	char pad_760_1 : 7;  // 0x2F8(0x1)
	bool bLoopToggleState : 1;  // 0x2F8(0x1)
	char pad_761[3];  // 0x2F9(0x3)
	int32_t CurrentStateIndex;  // 0x2FC(0x4)

	void ToggleState_Prev(); // Function HorizonUI.HorizonMultiToggleButtonWidget.ToggleState_Prev
	void ToggleState_Next(); // Function HorizonUI.HorizonMultiToggleButtonWidget.ToggleState_Next
	void SetLoopToggleState(bool InLoopToggleState); // Function HorizonUI.HorizonMultiToggleButtonWidget.SetLoopToggleState
	void SetCurrentStateIndex(int32_t InStateIndex); // Function HorizonUI.HorizonMultiToggleButtonWidget.SetCurrentStateIndex
	void OnHorizonMultiToggleButtonSyncEvent__DelegateSignature(int32_t InCurrentStateIndex); // DelegateFunction HorizonUI.HorizonMultiToggleButtonWidget.OnHorizonMultiToggleButtonSyncEvent__DelegateSignature
	void OnHorizonMultiToggleButtonEvent__DelegateSignature(int32_t InCurrentStateIndex, int32_t InToStateIndex); // DelegateFunction HorizonUI.HorizonMultiToggleButtonWidget.OnHorizonMultiToggleButtonEvent__DelegateSignature
	int32_t GetToggleState_PrevIndex(); // Function HorizonUI.HorizonMultiToggleButtonWidget.GetToggleState_PrevIndex
	int32_t GetToggleState_NextIndex(); // Function HorizonUI.HorizonMultiToggleButtonWidget.GetToggleState_NextIndex
	bool GetLoopToggleState(); // Function HorizonUI.HorizonMultiToggleButtonWidget.GetLoopToggleState
	int32_t GetCurrentStateIndex(); // Function HorizonUI.HorizonMultiToggleButtonWidget.GetCurrentStateIndex
}; 



// Class HorizonUI.HorizonRadioButtonUserWidget
// Size: 0x308(Inherited: 0x278) 
struct UHorizonRadioButtonUserWidget : public UHorizonDesignableUserWidget
{
	struct FMulticastInlineDelegate OnCheckedDelegate;  // 0x278(0x10)
	struct FMulticastInlineDelegate OnUnCheckedDelegate;  // 0x288(0x10)
	char pad_664[48];  // 0x298(0x30)
	struct UCheckBox* CheckBox_Main;  // 0x2C8(0x8)
	struct UTextBlock* TextBlock_Main;  // 0x2D0(0x8)
	struct FText Text_Main;  // 0x2D8(0x18)
	char pad_752_1 : 7;  // 0x2F0(0x1)
	bool bCheckedByDefault : 1;  // 0x2F0(0x1)
	char pad_753[23];  // 0x2F1(0x17)

	void SetChecked(); // Function HorizonUI.HorizonRadioButtonUserWidget.SetChecked
	void OnHorizonRadioButtonEvent__DelegateSignature(); // DelegateFunction HorizonUI.HorizonRadioButtonUserWidget.OnHorizonRadioButtonEvent__DelegateSignature
	void NativeOnCheckStateChanged(bool bIsChecked); // Function HorizonUI.HorizonRadioButtonUserWidget.NativeOnCheckStateChanged
	void BP_OnCheckStateChanged(bool bIsChecked); // Function HorizonUI.HorizonRadioButtonUserWidget.BP_OnCheckStateChanged
}; 



// Class HorizonUI.HorizonTextBlock
// Size: 0x340(Inherited: 0x340) 
struct UHorizonTextBlock : public UTextBlock
{

	char ETextJustify GetJustification(); // Function HorizonUI.HorizonTextBlock.GetJustification
}; 



// Class HorizonUI.HorizonTileView
// Size: 0xD50(Inherited: 0xC40) 
struct UHorizonTileView : public UTileView
{
	char pad_3136[8];  // 0xC40(0x8)
	struct FMulticastInlineDelegate OnInitListItemEvent;  // 0xC48(0x10)
	char pad_3160[24];  // 0xC58(0x18)
	struct FMulticastInlineDelegate OnItemPressedEvent;  // 0xC70(0x10)
	char pad_3200[24];  // 0xC80(0x18)
	struct FMulticastInlineDelegate OnItemReleasedEvent;  // 0xC98(0x10)
	char pad_3240[24];  // 0xCA8(0x18)
	struct FMulticastInlineDelegate OnItemHoveredEvent;  // 0xCC0(0x10)
	char pad_3280[24];  // 0xCD0(0x18)
	struct FMulticastInlineDelegate OnItemUnhoveredEvent;  // 0xCE8(0x10)
	char pad_3320[24];  // 0xCF8(0x18)
	struct FMulticastInlineDelegate OnItemClickedEvent;  // 0xD10(0x10)
	char pad_3360[48];  // 0xD20(0x30)

	void SynchronizeProperties(); // Function HorizonUI.HorizonTileView.SynchronizeProperties
	void RerouteItemUnhovered(struct UObject* InItem); // Function HorizonUI.HorizonTileView.RerouteItemUnhovered
	void RerouteItemReleased(struct UObject* InItem); // Function HorizonUI.HorizonTileView.RerouteItemReleased
	void RerouteItemPressed(struct UObject* InItem); // Function HorizonUI.HorizonTileView.RerouteItemPressed
	void RerouteItemHovered(struct UObject* InItem); // Function HorizonUI.HorizonTileView.RerouteItemHovered
	void RerouteItemClicked(struct UObject* InItem); // Function HorizonUI.HorizonTileView.RerouteItemClicked
	void OnItemEvent__DelegateSignature(struct UObject* InItem); // DelegateFunction HorizonUI.HorizonTileView.OnItemEvent__DelegateSignature
	void OnInitListItemEvent__DelegateSignature(struct UHorizonTileView* InTileView); // DelegateFunction HorizonUI.HorizonTileView.OnInitListItemEvent__DelegateSignature
	void NavigateToAndSelectIndex(int32_t InIndex); // Function HorizonUI.HorizonTileView.NavigateToAndSelectIndex
	bool IsPendingRefresh(); // Function HorizonUI.HorizonTileView.IsPendingRefresh
	bool IsFocusable(); // Function HorizonUI.HorizonTileView.IsFocusable
	void InitListItem(); // Function HorizonUI.HorizonTileView.InitListItem
	int32_t GetNumGeneratedChildren(); // Function HorizonUI.HorizonTileView.GetNumGeneratedChildren
	struct UHorizonListViewItemWidget* BP_GetEntryWidgetFromItem(struct UObject* InItem); // Function HorizonUI.HorizonTileView.BP_GetEntryWidgetFromItem
}; 



// Class HorizonUI.HorizonWidgetFunctionLibrary
// Size: 0x28(Inherited: 0x28) 
struct UHorizonWidgetFunctionLibrary : public UBlueprintFunctionLibrary
{

	struct UWidget* SetWidgetVisibility(struct UUserWidget* UserWidget, struct FName WidgetName, uint8_t  eVisiblity); // Function HorizonUI.HorizonWidgetFunctionLibrary.SetWidgetVisibility
	void SetInputMode(struct APlayerController* InPC, uint8_t  InInputMode, struct UWidget* InWidgetToFocus, uint8_t  InMouseLockMode, bool bInHideCursorDuringCapture); // Function HorizonUI.HorizonWidgetFunctionLibrary.SetInputMode
	bool IsIdeographic(int32_t InCodePoint); // Function HorizonUI.HorizonWidgetFunctionLibrary.IsIdeographic
	bool IsAlphabetic(int32_t InCodePoint); // Function HorizonUI.HorizonWidgetFunctionLibrary.IsAlphabetic
	struct UWidget* GetWidgetFromNameRecursively(struct UUserWidget* pUserWidget, struct FName& InWidgetName); // Function HorizonUI.HorizonWidgetFunctionLibrary.GetWidgetFromNameRecursively
	struct UWidgetAnimation* GetUserWidgetAnimation(struct UUserWidget* pUserWidget, struct FName& animeName); // Function HorizonUI.HorizonWidgetFunctionLibrary.GetUserWidgetAnimation
	int32_t GetUserIndex(struct UWidget* InWidget); // Function HorizonUI.HorizonWidgetFunctionLibrary.GetUserIndex
	struct UCanvasPanelSlot* GetParentCanvasPanelSlot(struct UWidget* pWidget); // Function HorizonUI.HorizonWidgetFunctionLibrary.GetParentCanvasPanelSlot
	uint8_t  GetInputMode(struct APlayerController* InPC); // Function HorizonUI.HorizonWidgetFunctionLibrary.GetInputMode
}; 



