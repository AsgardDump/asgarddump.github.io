#pragma once 
#include <ClothingSystemRuntimeNv_Structs.h>
 
 
 
// Class ClothingSystemRuntimeNv.ClothConfigNv
// Size: 0x1A0(Inherited: 0x28) 
struct UClothConfigNv : public UClothConfigCommon
{
	uint8_t  ClothingWindMethod;  // 0x28(0x1)
	char pad_41[3];  // 0x29(0x3)
	struct FClothConstraintSetupNv VerticalConstraint;  // 0x2C(0x10)
	struct FClothConstraintSetupNv HorizontalConstraint;  // 0x3C(0x10)
	struct FClothConstraintSetupNv BendConstraint;  // 0x4C(0x10)
	struct FClothConstraintSetupNv ShearConstraint;  // 0x5C(0x10)
	float SelfCollisionRadius;  // 0x6C(0x4)
	float SelfCollisionStiffness;  // 0x70(0x4)
	float SelfCollisionCullScale;  // 0x74(0x4)
	struct FVector Damping;  // 0x78(0x18)
	float Friction;  // 0x90(0x4)
	float WindDragCoefficient;  // 0x94(0x4)
	float WindLiftCoefficient;  // 0x98(0x4)
	char pad_156[4];  // 0x9C(0x4)
	struct FVector LinearDrag;  // 0xA0(0x18)
	struct FVector AngularDrag;  // 0xB8(0x18)
	struct FVector LinearInertiaScale;  // 0xD0(0x18)
	struct FVector AngularInertiaScale;  // 0xE8(0x18)
	struct FVector CentrifugalInertiaScale;  // 0x100(0x18)
	float SolverFrequency;  // 0x118(0x4)
	float StiffnessFrequency;  // 0x11C(0x4)
	float GravityScale;  // 0x120(0x4)
	char pad_292[4];  // 0x124(0x4)
	struct FVector GravityOverride;  // 0x128(0x18)
	char pad_320_1 : 7;  // 0x140(0x1)
	bool bUseGravityOverride : 1;  // 0x140(0x1)
	char pad_321[3];  // 0x141(0x3)
	float TetherStiffness;  // 0x144(0x4)
	float TetherLimit;  // 0x148(0x4)
	float CollisionThickness;  // 0x14C(0x4)
	float AnimDriveSpringStiffness;  // 0x150(0x4)
	float AnimDriveDamperStiffness;  // 0x154(0x4)
	uint8_t  WindMethod;  // 0x158(0x1)
	char pad_345[3];  // 0x159(0x3)
	struct FClothConstraintSetup_Legacy VerticalConstraintConfig;  // 0x15C(0x10)
	struct FClothConstraintSetup_Legacy HorizontalConstraintConfig;  // 0x16C(0x10)
	struct FClothConstraintSetup_Legacy BendConstraintConfig;  // 0x17C(0x10)
	struct FClothConstraintSetup_Legacy ShearConstraintConfig;  // 0x18C(0x10)
	char pad_412[4];  // 0x19C(0x4)

}; 



// Class ClothingSystemRuntimeNv.ClothingSimulationFactoryNv
// Size: 0x28(Inherited: 0x28) 
struct UClothingSimulationFactoryNv : public UClothingSimulationFactory
{

}; 



// Class ClothingSystemRuntimeNv.ClothingSimulationInteractorNv
// Size: 0x90(Inherited: 0x90) 
struct UClothingSimulationInteractorNv : public UClothingSimulationInteractor
{

	void SetAnimDriveDamperStiffness(float InStiffness); // Function ClothingSystemRuntimeNv.ClothingSimulationInteractorNv.SetAnimDriveDamperStiffness
}; 



// Class ClothingSystemRuntimeNv.ClothPhysicalMeshDataNv_Legacy
// Size: 0x120(Inherited: 0xE0) 
struct UClothPhysicalMeshDataNv_Legacy : public UClothPhysicalMeshDataBase_Legacy
{
	struct TArray<float> MaxDistances;  // 0xE0(0x10)
	struct TArray<float> BackstopDistances;  // 0xF0(0x10)
	struct TArray<float> BackstopRadiuses;  // 0x100(0x10)
	struct TArray<float> AnimDriveMultipliers;  // 0x110(0x10)

}; 



