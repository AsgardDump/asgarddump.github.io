#pragma once 
#include <CommonInput_Structs.h>
 
 
 
// Class CommonInput.CommonInputSettings
// Size: 0x130(Inherited: 0x38) 
struct UCommonInputSettings : public UDeveloperSettings
{
	struct TSoftClassPtr<UObject> InputData;  // 0x38(0x30)
	struct FPerPlatformSettings PlatformInput;  // 0x68(0x10)
	struct TMap<struct FName, struct FCommonInputPlatformBaseData> CommonInputPlatformData;  // 0x78(0x50)
	char pad_200_1 : 7;  // 0xC8(0x1)
	bool bEnableInputMethodThrashingProtection : 1;  // 0xC8(0x1)
	char pad_201[3];  // 0xC9(0x3)
	int32_t InputMethodThrashingLimit;  // 0xCC(0x4)
	double InputMethodThrashingWindowInSeconds;  // 0xD0(0x8)
	double InputMethodThrashingCooldownInSeconds;  // 0xD8(0x8)
	char pad_224_1 : 7;  // 0xE0(0x1)
	bool bAllowOutOfFocusDeviceInput : 1;  // 0xE0(0x1)
	char pad_225_1 : 7;  // 0xE1(0x1)
	bool bEnableDefaultInputConfig : 1;  // 0xE1(0x1)
	char pad_226[6];  // 0xE2(0x6)
	struct TSoftObjectPtr<UCommonInputActionDomainTable> ActionDomainTable;  // 0xE8(0x30)
	char pad_280[8];  // 0x118(0x8)
	UCommonUIInputData* InputDataClass;  // 0x120(0x8)
	struct UCommonInputActionDomainTable* ActionDomainTablePtr;  // 0x128(0x8)

}; 



// Class CommonInput.CommonInputPlatformSettings
// Size: 0x70(Inherited: 0x40) 
struct UCommonInputPlatformSettings : public UPlatformSettings
{
	uint8_t  DefaultInputType;  // 0x40(0x1)
	char pad_65_1 : 7;  // 0x41(0x1)
	bool bSupportsMouseAndKeyboard : 1;  // 0x41(0x1)
	char pad_66_1 : 7;  // 0x42(0x1)
	bool bSupportsTouch : 1;  // 0x42(0x1)
	char pad_67_1 : 7;  // 0x43(0x1)
	bool bSupportsGamepad : 1;  // 0x43(0x1)
	struct FName DefaultGamepadName;  // 0x44(0x8)
	char pad_76_1 : 7;  // 0x4C(0x1)
	bool bCanChangeGamepadType : 1;  // 0x4C(0x1)
	char pad_77[3];  // 0x4D(0x3)
	struct TArray<struct TSoftClassPtr<UObject>> ControllerData;  // 0x50(0x10)
	struct TArray<UCommonInputBaseControllerData*> ControllerDataClasses;  // 0x60(0x10)

}; 



// Class CommonInput.CommonInputBaseControllerData
// Size: 0x110(Inherited: 0x28) 
struct UCommonInputBaseControllerData : public UObject
{
	uint8_t  InputType;  // 0x28(0x1)
	char pad_41[3];  // 0x29(0x3)
	struct FName GamepadName;  // 0x2C(0x8)
	char pad_52[4];  // 0x34(0x4)
	struct FText GamepadDisplayName;  // 0x38(0x18)
	struct FText GamepadCategory;  // 0x50(0x18)
	struct FText GamepadPlatformName;  // 0x68(0x18)
	struct TArray<struct FInputDeviceIdentifierPair> GamepadHardwareIdMapping;  // 0x80(0x10)
	struct TSoftObjectPtr<UTexture2D> ControllerTexture;  // 0x90(0x30)
	struct TSoftObjectPtr<UTexture2D> ControllerButtonMaskTexture;  // 0xC0(0x30)
	struct TArray<struct FCommonInputKeyBrushConfiguration> InputBrushDataMap;  // 0xF0(0x10)
	struct TArray<struct FCommonInputKeySetBrushConfiguration> InputBrushKeySets;  // 0x100(0x10)

	struct TArray<struct FName> GetRegisteredGamepads(); // Function CommonInput.CommonInputBaseControllerData.GetRegisteredGamepads
}; 



// Class CommonInput.CommonInputActionDomain
// Size: 0x40(Inherited: 0x30) 
struct UCommonInputActionDomain : public UDataAsset
{
	uint8_t  Behavior;  // 0x30(0x4)
	uint8_t  InnerBehavior;  // 0x34(0x4)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool bUseActionDomainDesiredInputConfig : 1;  // 0x38(0x1)
	uint8_t  InputMode;  // 0x39(0x1)
	uint8_t  MouseCaptureMode;  // 0x3A(0x1)
	char pad_59[5];  // 0x3B(0x5)

}; 



// Class CommonInput.CommonInputSubsystem
// Size: 0x108(Inherited: 0x30) 
struct UCommonInputSubsystem : public ULocalPlayerSubsystem
{
	char pad_48[40];  // 0x30(0x28)
	struct FMulticastInlineDelegate OnInputMethodChanged;  // 0x58(0x10)
	int32_t NumberOfInputMethodChangesRecently;  // 0x68(0x4)
	char pad_108[4];  // 0x6C(0x4)
	double LastInputMethodChangeTime;  // 0x70(0x8)
	double LastTimeInputMethodThrashingBegan;  // 0x78(0x8)
	uint8_t  LastInputType;  // 0x80(0x1)
	uint8_t  CurrentInputType;  // 0x81(0x1)
	char pad_130[2];  // 0x82(0x2)
	struct FName GamepadInputType;  // 0x84(0x8)
	char pad_140[4];  // 0x8C(0x4)
	struct TMap<struct FName, uint8_t > CurrentInputLocks;  // 0x90(0x50)
	char pad_224[24];  // 0xE0(0x18)
	struct UCommonInputActionDomainTable* ActionDomainTable;  // 0xF8(0x8)
	char pad_256_1 : 7;  // 0x100(0x1)
	bool bIsGamepadSimulatedClick : 1;  // 0x100(0x1)
	char pad_257[7];  // 0x101(0x7)

	bool ShouldShowInputKeys(); // Function CommonInput.CommonInputSubsystem.ShouldShowInputKeys
	void SetGamepadInputType(struct FName InGamepadInputType); // Function CommonInput.CommonInputSubsystem.SetGamepadInputType
	void SetCurrentInputType(uint8_t  NewInputType); // Function CommonInput.CommonInputSubsystem.SetCurrentInputType
	bool IsUsingPointerInput(); // Function CommonInput.CommonInputSubsystem.IsUsingPointerInput
	bool IsInputMethodActive(uint8_t  InputMethod); // Function CommonInput.CommonInputSubsystem.IsInputMethodActive
	uint8_t  GetDefaultInputType(); // Function CommonInput.CommonInputSubsystem.GetDefaultInputType
	uint8_t  GetCurrentInputType(); // Function CommonInput.CommonInputSubsystem.GetCurrentInputType
	struct FName GetCurrentGamepadName(); // Function CommonInput.CommonInputSubsystem.GetCurrentGamepadName
}; 



// Class CommonInput.CommonInputActionDomainTable
// Size: 0x48(Inherited: 0x30) 
struct UCommonInputActionDomainTable : public UDataAsset
{
	struct TArray<struct UCommonInputActionDomain*> ActionDomains;  // 0x30(0x10)
	uint8_t  InputMode;  // 0x40(0x1)
	uint8_t  MouseCaptureMode;  // 0x41(0x1)
	char pad_66[6];  // 0x42(0x6)

}; 



// Class CommonInput.CommonUIInputData
// Size: 0x48(Inherited: 0x28) 
struct UCommonUIInputData : public UObject
{
	struct FDataTableRowHandle DefaultClickAction;  // 0x28(0x10)
	struct FDataTableRowHandle DefaultBackAction;  // 0x38(0x10)

}; 



