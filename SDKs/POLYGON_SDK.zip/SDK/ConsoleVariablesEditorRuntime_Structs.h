#pragma once 
#include "SDK.h" 
 
 
// Function ConsoleVariablesEditorRuntime.ConsoleVariablesAsset.SetVariableCollectionDescription
// Size: 0x10(Inherited: 0x0) 
struct FSetVariableCollectionDescription
{
	struct FString InVariableCollectionDescription;  // 0x0(0x10)

}; 
// ScriptStruct ConsoleVariablesEditorRuntime.ConsoleVariablesEditorAssetSaveData
// Size: 0x28(Inherited: 0x0) 
struct FConsoleVariablesEditorAssetSaveData
{
	struct FString CommandName;  // 0x0(0x10)
	struct FString CommandValueAsString;  // 0x10(0x10)
	uint8_t  CheckedState;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// Function ConsoleVariablesEditorRuntime.ConsoleVariablesAsset.AddOrSetConsoleObjectSavedData
// Size: 0x28(Inherited: 0x0) 
struct FAddOrSetConsoleObjectSavedData
{
	struct FConsoleVariablesEditorAssetSaveData InData;  // 0x0(0x28)

}; 
// Function ConsoleVariablesEditorRuntime.ConsoleVariablesAsset.FindSavedDataByCommandString
// Size: 0x40(Inherited: 0x0) 
struct FFindSavedDataByCommandString
{
	struct FString InCommandString;  // 0x0(0x10)
	struct FConsoleVariablesEditorAssetSaveData OutValue;  // 0x10(0x28)
	char ESearchCase SearchCase;  // 0x38(0x1)
	char pad_57_1 : 7;  // 0x39(0x1)
	bool ReturnValue : 1;  // 0x39(0x1)
	char pad_58[6];  // 0x3A(0x6)

}; 
// Function ConsoleVariablesEditorRuntime.ConsoleVariablesAsset.CopyFrom
// Size: 0x8(Inherited: 0x0) 
struct FCopyFrom
{
	struct UConsoleVariablesAsset* InAssetToCopy;  // 0x0(0x8)

}; 
// Function ConsoleVariablesEditorRuntime.ConsoleVariablesAsset.ExecuteSavedCommands
// Size: 0x10(Inherited: 0x0) 
struct FExecuteSavedCommands
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bOnlyIncludeChecked : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function ConsoleVariablesEditorRuntime.ConsoleVariablesAsset.GetSavedCommands
// Size: 0x10(Inherited: 0x0) 
struct FGetSavedCommands
{
	struct TArray<struct FConsoleVariablesEditorAssetSaveData> ReturnValue;  // 0x0(0x10)

}; 
// Function ConsoleVariablesEditorRuntime.ConsoleVariablesAsset.GetSavedCommandsAsCommaSeparatedString
// Size: 0x18(Inherited: 0x0) 
struct FGetSavedCommandsAsCommaSeparatedString
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bOnlyIncludeChecked : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FString ReturnValue;  // 0x8(0x10)

}; 
// Function ConsoleVariablesEditorRuntime.ConsoleVariablesAsset.GetSavedCommandsAsStringArray
// Size: 0x18(Inherited: 0x0) 
struct FGetSavedCommandsAsStringArray
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bOnlyIncludeChecked : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct TArray<struct FString> ReturnValue;  // 0x8(0x10)

}; 
// Function ConsoleVariablesEditorRuntime.ConsoleVariablesAsset.GetSavedCommandsCount
// Size: 0x4(Inherited: 0x0) 
struct FGetSavedCommandsCount
{
	int32_t ReturnValue;  // 0x0(0x4)

}; 
// Function ConsoleVariablesEditorRuntime.ConsoleVariablesAsset.GetVariableCollectionDescription
// Size: 0x10(Inherited: 0x0) 
struct FGetVariableCollectionDescription
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// Function ConsoleVariablesEditorRuntime.ConsoleVariablesAsset.RemoveConsoleVariable
// Size: 0x18(Inherited: 0x0) 
struct FRemoveConsoleVariable
{
	struct FString InCommandString;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function ConsoleVariablesEditorRuntime.ConsoleVariablesAsset.ReplaceSavedCommands
// Size: 0x10(Inherited: 0x0) 
struct FReplaceSavedCommands
{
	struct TArray<struct FConsoleVariablesEditorAssetSaveData> Replacement;  // 0x0(0x10)

}; 
