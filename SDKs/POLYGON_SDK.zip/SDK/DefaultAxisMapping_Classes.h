#pragma once 
#include <DefaultAxisMapping_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass DefaultAxisMapping.DefaultAxisMapping_C
// Size: 0x2C8(Inherited: 0x2C8) 
struct UDefaultAxisMapping_C : public UAxisMapping
{

}; 



