#pragma once 
#include "SDK.h" 
 
 
// Function AudioWidgets.AudioMeter.SetBackgroundColor
// Size: 0x10(Inherited: 0x0) 
struct FSetBackgroundColor
{
	struct FLinearColor InValue;  // 0x0(0x10)

}; 
// DelegateFunction AudioWidgets.OnAudioRadialSliderValueChangedEvent__DelegateSignature
// Size: 0x4(Inherited: 0x0) 
struct FOnAudioRadialSliderValueChangedEvent__DelegateSignature
{
	float Value;  // 0x0(0x4)

}; 
// Function AudioWidgets.AudioMeter.SetMeterValueColor
// Size: 0x10(Inherited: 0x0) 
struct FSetMeterValueColor
{
	struct FLinearColor InValue;  // 0x0(0x10)

}; 
// DelegateFunction AudioWidgets.OnFloatValueChangedEvent__DelegateSignature
// Size: 0x4(Inherited: 0x0) 
struct FOnFloatValueChangedEvent__DelegateSignature
{
	float Value;  // 0x0(0x4)

}; 
// DelegateFunction AudioWidgets.AudioMeter.GetMeterChannelInfo__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FGetMeterChannelInfo__DelegateSignature
{
	struct TArray<struct FMeterChannelInfo> ReturnValue;  // 0x0(0x10)

}; 
// Function AudioWidgets.AudioMeter.SetMeterBackgroundColor
// Size: 0x10(Inherited: 0x0) 
struct FSetMeterBackgroundColor
{
	struct FLinearColor InValue;  // 0x0(0x10)

}; 
// Function AudioWidgets.AudioSliderBase.GetLinValue
// Size: 0x8(Inherited: 0x0) 
struct FGetLinValue
{
	float OutputValue;  // 0x0(0x4)
	float ReturnValue;  // 0x4(0x4)

}; 
// Function AudioWidgets.AudioRadialSlider.SetOutputRange
// Size: 0x10(Inherited: 0x0) 
struct FSetOutputRange
{
	struct FVector2D InOutputRange;  // 0x0(0x10)

}; 
// Function AudioWidgets.AudioMeter.GetMeterChannelInfo
// Size: 0x10(Inherited: 0x0) 
struct FGetMeterChannelInfo
{
	struct TArray<struct FMeterChannelInfo> ReturnValue;  // 0x0(0x10)

}; 
// ScriptStruct AudioWidgets.MeterChannelInfo
// Size: 0xC(Inherited: 0x0) 
struct FMeterChannelInfo
{
	float MeterValue;  // 0x0(0x4)
	float PeakValue;  // 0x4(0x4)
	float ClippingValue;  // 0x8(0x4)

}; 
// Function AudioWidgets.AudioMeter.SetMeterChannelInfo
// Size: 0x10(Inherited: 0x0) 
struct FSetMeterChannelInfo
{
	struct TArray<struct FMeterChannelInfo> InMeterChannelInfo;  // 0x0(0x10)

}; 
// Function AudioWidgets.AudioMeter.SetMeterClippingColor
// Size: 0x10(Inherited: 0x0) 
struct FSetMeterClippingColor
{
	struct FLinearColor InValue;  // 0x0(0x10)

}; 
// Function AudioWidgets.AudioRadialSlider.SetHandStartEndRatio
// Size: 0x10(Inherited: 0x0) 
struct FSetHandStartEndRatio
{
	struct FVector2D InHandStartEndRatio;  // 0x0(0x10)

}; 
// Function AudioWidgets.AudioMeter.SetMeterPeakColor
// Size: 0x10(Inherited: 0x0) 
struct FSetMeterPeakColor
{
	struct FLinearColor InValue;  // 0x0(0x10)

}; 
// Function AudioWidgets.AudioSliderBase.SetValueTextReadOnly
// Size: 0x1(Inherited: 0x0) 
struct FSetValueTextReadOnly
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bIsReadOnly : 1;  // 0x0(0x1)

}; 
// Function AudioWidgets.AudioMeter.SetMeterScaleColor
// Size: 0x10(Inherited: 0x0) 
struct FSetMeterScaleColor
{
	struct FLinearColor InValue;  // 0x0(0x10)

}; 
// Function AudioWidgets.AudioSliderBase.SetShowLabelOnlyOnHover
// Size: 0x1(Inherited: 0x0) 
struct FSetShowLabelOnlyOnHover
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bShowLabelOnlyOnHover : 1;  // 0x0(0x1)

}; 
// Function AudioWidgets.AudioMeter.SetMeterScaleLabelColor
// Size: 0x10(Inherited: 0x0) 
struct FSetMeterScaleLabelColor
{
	struct FLinearColor InValue;  // 0x0(0x10)

}; 
// ScriptStruct AudioWidgets.AudioMeterStyle
// Size: 0x4D0(Inherited: 0x8) 
struct FAudioMeterStyle : public FSlateWidgetStyle
{
	char pad_8[8];  // 0x8(0x8)
	struct FSlateBrush MeterValueImage;  // 0x10(0xD0)
	struct FSlateBrush BackgroundImage;  // 0xE0(0xD0)
	struct FSlateBrush MeterBackgroundImage;  // 0x1B0(0xD0)
	struct FSlateBrush MeterValueBackgroundImage;  // 0x280(0xD0)
	struct FSlateBrush MeterPeakImage;  // 0x350(0xD0)
	struct FVector2D MeterSize;  // 0x420(0x10)
	struct FVector2D MeterPadding;  // 0x430(0x10)
	float MeterValuePadding;  // 0x440(0x4)
	float PeakValueWidth;  // 0x444(0x4)
	struct FVector2D ValueRangeDb;  // 0x448(0x10)
	char pad_1112_1 : 7;  // 0x458(0x1)
	bool bShowScale : 1;  // 0x458(0x1)
	char pad_1113_1 : 7;  // 0x459(0x1)
	bool bScaleSide : 1;  // 0x459(0x1)
	char pad_1114[2];  // 0x45A(0x2)
	float ScaleHashOffset;  // 0x45C(0x4)
	float ScaleHashWidth;  // 0x460(0x4)
	float ScaleHashHeight;  // 0x464(0x4)
	int32_t DecibelsPerHash;  // 0x468(0x4)
	char pad_1132[4];  // 0x46C(0x4)
	struct FSlateFontInfo Font;  // 0x470(0x58)
	char pad_1224[8];  // 0x4C8(0x8)

}; 
// ScriptStruct AudioWidgets.AudioTextBoxStyle
// Size: 0x100(Inherited: 0x8) 
struct FAudioTextBoxStyle : public FSlateWidgetStyle
{
	char pad_8[8];  // 0x8(0x8)
	struct FSlateBrush BackgroundImage;  // 0x10(0xD0)
	struct FSlateColor BackgroundColor;  // 0xE0(0x14)
	char pad_244[12];  // 0xF4(0xC)

}; 
// ScriptStruct AudioWidgets.AudioSliderStyle
// Size: 0x750(Inherited: 0x8) 
struct FAudioSliderStyle : public FSlateWidgetStyle
{
	char pad_8[8];  // 0x8(0x8)
	struct FSliderStyle SliderStyle;  // 0x10(0x500)
	struct FAudioTextBoxStyle TextBoxStyle;  // 0x510(0x100)
	struct FSlateBrush WidgetBackgroundImage;  // 0x610(0xD0)
	struct FSlateColor SliderBackgroundColor;  // 0x6E0(0x14)
	char pad_1780[4];  // 0x6F4(0x4)
	struct FVector2D SliderBackgroundSize;  // 0x6F8(0x10)
	float LabelPadding;  // 0x708(0x4)
	struct FSlateColor SliderBarColor;  // 0x70C(0x14)
	struct FSlateColor SliderThumbColor;  // 0x720(0x14)
	struct FSlateColor WidgetBackgroundColor;  // 0x734(0x14)
	char pad_1864[8];  // 0x748(0x8)

}; 
// ScriptStruct AudioWidgets.AudioRadialSliderStyle
// Size: 0x160(Inherited: 0x8) 
struct FAudioRadialSliderStyle : public FSlateWidgetStyle
{
	char pad_8[8];  // 0x8(0x8)
	struct FAudioTextBoxStyle TextBoxStyle;  // 0x10(0x100)
	struct FSlateColor CenterBackgroundColor;  // 0x110(0x14)
	struct FSlateColor SliderBarColor;  // 0x124(0x14)
	struct FSlateColor SliderProgressColor;  // 0x138(0x14)
	float LabelPadding;  // 0x14C(0x4)
	float DefaultSliderRadius;  // 0x150(0x4)
	char pad_340[12];  // 0x154(0xC)

}; 
// Function AudioWidgets.AudioSliderBase.GetOutputValue
// Size: 0x8(Inherited: 0x0) 
struct FGetOutputValue
{
	float InSliderValue;  // 0x0(0x4)
	float ReturnValue;  // 0x4(0x4)

}; 
// Function AudioWidgets.AudioSliderBase.GetSliderValue
// Size: 0x8(Inherited: 0x0) 
struct FGetSliderValue
{
	float OutputValue;  // 0x0(0x4)
	float ReturnValue;  // 0x4(0x4)

}; 
// Function AudioWidgets.AudioRadialSlider.SetCenterBackgroundColor
// Size: 0x10(Inherited: 0x0) 
struct FSetCenterBackgroundColor
{
	struct FLinearColor InValue;  // 0x0(0x10)

}; 
// Function AudioWidgets.AudioSliderBase.SetShowUnitsText
// Size: 0x1(Inherited: 0x0) 
struct FSetShowUnitsText
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bShowUnitsText : 1;  // 0x0(0x1)

}; 
// Function AudioWidgets.AudioSliderBase.SetSliderBarColor
// Size: 0x10(Inherited: 0x0) 
struct FSetSliderBarColor
{
	struct FLinearColor InValue;  // 0x0(0x10)

}; 
// Function AudioWidgets.AudioRadialSlider.SetSliderProgressColor
// Size: 0x10(Inherited: 0x0) 
struct FSetSliderProgressColor
{
	struct FLinearColor InValue;  // 0x0(0x10)

}; 
// Function AudioWidgets.AudioRadialSlider.SetSliderThickness
// Size: 0x4(Inherited: 0x0) 
struct FSetSliderThickness
{
	float InThickness;  // 0x0(0x4)

}; 
// Function AudioWidgets.AudioSliderBase.SetUnitsText
// Size: 0x18(Inherited: 0x0) 
struct FSetUnitsText
{
	struct FText Units;  // 0x0(0x18)

}; 
// Function AudioWidgets.AudioSliderBase.SetTextLabelBackgroundColor
// Size: 0x14(Inherited: 0x0) 
struct FSetTextLabelBackgroundColor
{
	struct FSlateColor InColor;  // 0x0(0x14)

}; 
// Function AudioWidgets.AudioSliderBase.SetUnitsTextReadOnly
// Size: 0x1(Inherited: 0x0) 
struct FSetUnitsTextReadOnly
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bIsReadOnly : 1;  // 0x0(0x1)

}; 
// Function AudioWidgets.AudioRadialSlider.SetWidgetLayout
// Size: 0x1(Inherited: 0x0) 
struct FSetWidgetLayout
{
	char EAudioRadialSliderLayout InLayout;  // 0x0(0x1)

}; 
// Function AudioWidgets.AudioSliderBase.SetSliderBackgroundColor
// Size: 0x10(Inherited: 0x0) 
struct FSetSliderBackgroundColor
{
	struct FLinearColor InValue;  // 0x0(0x10)

}; 
// Function AudioWidgets.AudioSliderBase.SetSliderThumbColor
// Size: 0x10(Inherited: 0x0) 
struct FSetSliderThumbColor
{
	struct FLinearColor InValue;  // 0x0(0x10)

}; 
// Function AudioWidgets.AudioSliderBase.SetWidgetBackgroundColor
// Size: 0x10(Inherited: 0x0) 
struct FSetWidgetBackgroundColor
{
	struct FLinearColor InValue;  // 0x0(0x10)

}; 
