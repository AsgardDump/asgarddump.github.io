#pragma once 
#include <MeshModelingTools_Structs.h>
 
 
 
// Class MeshModelingTools.EditMeshPolygonsTool
// Size: 0x810(Inherited: 0xB8) 
struct UEditMeshPolygonsTool : public USingleSelectionMeshEditingTool
{
	char pad_184[40];  // 0xB8(0x28)
	struct UMeshOpPreviewWithBackgroundCompute* Preview;  // 0xE0(0x8)
	struct UPolyEditCommonProperties* CommonProps;  // 0xE8(0x8)
	struct UEditMeshPolygonsToolActions* EditActions;  // 0xF0(0x8)
	struct UEditMeshPolygonsToolActions_Triangles* EditActions_Triangles;  // 0xF8(0x8)
	struct UEditMeshPolygonsToolEdgeActions* EditEdgeActions;  // 0x100(0x8)
	struct UEditMeshPolygonsToolEdgeActions_Triangles* EditEdgeActions_Triangles;  // 0x108(0x8)
	struct UEditMeshPolygonsToolUVActions* EditUVActions;  // 0x110(0x8)
	struct UEditMeshPolygonsToolCancelAction* CancelAction;  // 0x118(0x8)
	struct UEditMeshPolygonsToolAcceptCancelAction* AcceptCancelAction;  // 0x120(0x8)
	struct UPolyEditTopologyProperties* TopologyProperties;  // 0x128(0x8)
	struct UPolyEditExtrudeActivity* ExtrudeActivity;  // 0x130(0x8)
	struct UPolyEditInsetOutsetActivity* InsetOutsetActivity;  // 0x138(0x8)
	struct UPolyEditCutFacesActivity* CutFacesActivity;  // 0x140(0x8)
	struct UPolyEditPlanarProjectionUVActivity* PlanarProjectionUVActivity;  // 0x148(0x8)
	struct UPolyEditInsertEdgeActivity* InsertEdgeActivity;  // 0x150(0x8)
	struct UPolyEditInsertEdgeLoopActivity* InsertEdgeLoopActivity;  // 0x158(0x8)
	struct UPolyEditBevelEdgeActivity* BevelEdgeActivity;  // 0x160(0x8)
	char pad_360[56];  // 0x168(0x38)
	struct UPolyEditActivityContext* ActivityContext;  // 0x1A0(0x8)
	struct UPolygonSelectionMechanic* SelectionMechanic;  // 0x1A8(0x8)
	struct UDragAlignmentMechanic* DragAlignmentMechanic;  // 0x1B0(0x8)
	struct UCombinedTransformGizmo* TransformGizmo;  // 0x1B8(0x8)
	struct UTransformProxy* TransformProxy;  // 0x1C0(0x8)
	char pad_456[1608];  // 0x1C8(0x648)

}; 



// Class MeshModelingTools.PolyEditTopologyProperties
// Size: 0xC0(Inherited: 0xB0) 
struct UPolyEditTopologyProperties : public UEditMeshPolygonsToolActionPropertySet
{
	char pad_176_1 : 7;  // 0xB0(0x1)
	bool bAddExtraCorners : 1;  // 0xB0(0x1)
	char pad_177[7];  // 0xB1(0x7)
	double ExtraCornerAngleThresholdDegrees;  // 0xB8(0x8)

	void RegenerateExtraCorners(); // Function MeshModelingTools.PolyEditTopologyProperties.RegenerateExtraCorners
}; 



// Class MeshModelingTools.AddConePrimitiveTool
// Size: 0x138(Inherited: 0x138) 
struct UAddConePrimitiveTool : public UAddPrimitiveTool
{

}; 



// Class MeshModelingTools.DeleteGeometrySelectionCommand
// Size: 0x28(Inherited: 0x28) 
struct UDeleteGeometrySelectionCommand : public UGeometrySelectionEditCommand
{

}; 



// Class MeshModelingTools.AddBoxPrimitiveTool
// Size: 0x138(Inherited: 0x138) 
struct UAddBoxPrimitiveTool : public UAddPrimitiveTool
{

}; 



// Class MeshModelingTools.RevolveProperties
// Size: 0x118(Inherited: 0xA8) 
struct URevolveProperties : public UInteractiveToolPropertySet
{
	double RevolveDegreesClamped;  // 0xA8(0x8)
	double RevolveDegrees;  // 0xB0(0x8)
	double RevolveDegreesOffset;  // 0xB8(0x8)
	double StepsMaxDegrees;  // 0xC0(0x8)
	char pad_200_1 : 7;  // 0xC8(0x1)
	bool bExplicitSteps : 1;  // 0xC8(0x1)
	char pad_201[3];  // 0xC9(0x3)
	int32_t NumExplicitSteps;  // 0xCC(0x4)
	double HeightOffsetPerDegree;  // 0xD0(0x8)
	char pad_216_1 : 7;  // 0xD8(0x1)
	bool bReverseRevolutionDirection : 1;  // 0xD8(0x1)
	char pad_217_1 : 7;  // 0xD9(0x1)
	bool bFlipMesh : 1;  // 0xD9(0x1)
	char pad_218_1 : 7;  // 0xDA(0x1)
	bool bSharpNormals : 1;  // 0xDA(0x1)
	char pad_219[5];  // 0xDB(0x5)
	double SharpNormalsDegreeThreshold;  // 0xE0(0x8)
	char pad_232_1 : 7;  // 0xE8(0x1)
	bool bPathAtMidpointOfStep : 1;  // 0xE8(0x1)
	uint8_t  PolygroupMode;  // 0xE9(0x1)
	uint8_t  QuadSplitMode;  // 0xEA(0x1)
	char pad_235[45];  // 0xEB(0x2D)

}; 



// Class MeshModelingTools.PolyEditOffsetProperties
// Size: 0xD8(Inherited: 0xA8) 
struct UPolyEditOffsetProperties : public UInteractiveToolPropertySet
{
	uint8_t  DistanceMode;  // 0xA8(0x4)
	char pad_172[4];  // 0xAC(0x4)
	double Distance;  // 0xB0(0x8)
	uint8_t  DirectionMode;  // 0xB8(0x4)
	char pad_188[4];  // 0xBC(0x4)
	double MaxDistanceScaleFactor;  // 0xC0(0x8)
	char pad_200_1 : 7;  // 0xC8(0x1)
	bool bShellsToSolids : 1;  // 0xC8(0x1)
	char pad_201[3];  // 0xC9(0x3)
	uint8_t  MeasureDirection;  // 0xCC(0x4)
	char pad_208_1 : 7;  // 0xD0(0x1)
	bool bUseColinearityForSettingBorderGroups : 1;  // 0xD0(0x1)
	char pad_209[7];  // 0xD1(0x7)

}; 



// Class MeshModelingTools.RecomputeUVsToolBuilder
// Size: 0x28(Inherited: 0x28) 
struct URecomputeUVsToolBuilder : public USingleSelectionMeshEditingToolBuilder
{

}; 



// Class MeshModelingTools.PolyEditActivityContext
// Size: 0x120(Inherited: 0x28) 
struct UPolyEditActivityContext : public UObject
{
	struct UPolyEditCommonProperties* CommonProperties;  // 0x28(0x8)
	char pad_48[16];  // 0x30(0x10)
	struct UMeshOpPreviewWithBackgroundCompute* Preview;  // 0x40(0x8)
	char pad_72[40];  // 0x48(0x28)
	struct UPolygonSelectionMechanic* SelectionMechanic;  // 0x70(0x8)
	char pad_120[168];  // 0x78(0xA8)

}; 



// Class MeshModelingTools.CSGMeshesTool
// Size: 0x158(Inherited: 0x100) 
struct UCSGMeshesTool : public UBaseCreateFromSelectedTool
{
	struct UCSGMeshesToolProperties* CSGProperties;  // 0x100(0x8)
	struct UTrimMeshesToolProperties* TrimProperties;  // 0x108(0x8)
	char pad_272[16];  // 0x110(0x10)
	struct TArray<struct UPreviewMesh*> OriginalMeshPreviews;  // 0x120(0x10)
	struct UMaterialInstanceDynamic* PreviewsGhostMaterial;  // 0x130(0x8)
	struct ULineSetComponent* DrawnLineSet;  // 0x138(0x8)
	char pad_320[24];  // 0x140(0x18)

}; 



// Class MeshModelingTools.ProceduralDiscToolProperties
// Size: 0xD0(Inherited: 0xB8) 
struct UProceduralDiscToolProperties : public UProceduralShapeToolProperties
{
	uint8_t  DiscType;  // 0xB8(0x4)
	float Radius;  // 0xBC(0x4)
	int32_t RadialSlices;  // 0xC0(0x4)
	int32_t RadialSubdivisions;  // 0xC4(0x4)
	float HoleRadius;  // 0xC8(0x4)
	char pad_204[4];  // 0xCC(0x4)

}; 



// Class MeshModelingTools.AddPrimitiveToolBuilder
// Size: 0x30(Inherited: 0x28) 
struct UAddPrimitiveToolBuilder : public UInteractiveToolBuilder
{
	char pad_40[8];  // 0x28(0x8)

}; 



// Class MeshModelingTools.PolyEditCutProperties
// Size: 0xB0(Inherited: 0xA8) 
struct UPolyEditCutProperties : public UInteractiveToolPropertySet
{
	uint8_t  Orientation;  // 0xA8(0x4)
	char pad_172_1 : 7;  // 0xAC(0x1)
	bool bSnapToVertices : 1;  // 0xAC(0x1)
	char pad_173[3];  // 0xAD(0x3)

}; 



// Class MeshModelingTools.ProceduralBoxToolProperties
// Size: 0xD0(Inherited: 0xB8) 
struct UProceduralBoxToolProperties : public UProceduralShapeToolProperties
{
	float Width;  // 0xB8(0x4)
	float Depth;  // 0xBC(0x4)
	float Height;  // 0xC0(0x4)
	int32_t WidthSubdivisions;  // 0xC4(0x4)
	int32_t DepthSubdivisions;  // 0xC8(0x4)
	int32_t HeightSubdivisions;  // 0xCC(0x4)

}; 



// Class MeshModelingTools.EditMeshPolygonsToolActions_Triangles
// Size: 0xB0(Inherited: 0xB0) 
struct UEditMeshPolygonsToolActions_Triangles : public UEditMeshPolygonsToolActionPropertySet
{

	void RecalcNormals(); // Function MeshModelingTools.EditMeshPolygonsToolActions_Triangles.RecalcNormals
	void PushPull(); // Function MeshModelingTools.EditMeshPolygonsToolActions_Triangles.PushPull
	void Poke(); // Function MeshModelingTools.EditMeshPolygonsToolActions_Triangles.Poke
	void Outset(); // Function MeshModelingTools.EditMeshPolygonsToolActions_Triangles.Outset
	void Offset(); // Function MeshModelingTools.EditMeshPolygonsToolActions_Triangles.Offset
	void Inset(); // Function MeshModelingTools.EditMeshPolygonsToolActions_Triangles.Inset
	void Flip(); // Function MeshModelingTools.EditMeshPolygonsToolActions_Triangles.Flip
	void Extrude(); // Function MeshModelingTools.EditMeshPolygonsToolActions_Triangles.Extrude
	void Duplicate(); // Function MeshModelingTools.EditMeshPolygonsToolActions_Triangles.Duplicate
	void Disconnect(); // Function MeshModelingTools.EditMeshPolygonsToolActions_Triangles.Disconnect
	void Delete(); // Function MeshModelingTools.EditMeshPolygonsToolActions_Triangles.Delete
	void CutFaces(); // Function MeshModelingTools.EditMeshPolygonsToolActions_Triangles.CutFaces
}; 



// Class MeshModelingTools.ProceduralShapeToolProperties
// Size: 0xB8(Inherited: 0xA8) 
struct UProceduralShapeToolProperties : public UInteractiveToolPropertySet
{
	uint8_t  PolygroupMode;  // 0xA8(0x1)
	uint8_t  TargetSurface;  // 0xA9(0x1)
	uint8_t  PivotLocation;  // 0xAA(0x1)
	char pad_171[1];  // 0xAB(0x1)
	float Rotation;  // 0xAC(0x4)
	char pad_176_1 : 7;  // 0xB0(0x1)
	bool bAlignToNormal : 1;  // 0xB0(0x1)
	char pad_177_1 : 7;  // 0xB1(0x1)
	bool bShowGizmo : 1;  // 0xB1(0x1)
	char pad_178_1 : 7;  // 0xB2(0x1)
	bool bShowGizmoOptions : 1;  // 0xB2(0x1)
	char pad_179[5];  // 0xB3(0x5)

}; 



// Class MeshModelingTools.NewMeshMaterialProperties
// Size: 0xB8(Inherited: 0xA8) 
struct UNewMeshMaterialProperties : public UInteractiveToolPropertySet
{
	struct TWeakObjectPtr<UMaterialInterface> Material;  // 0xA8(0x8)
	float UVScale;  // 0xB0(0x4)
	char pad_180_1 : 7;  // 0xB4(0x1)
	bool bWorldSpaceUVScale : 1;  // 0xB4(0x1)
	char pad_181_1 : 7;  // 0xB5(0x1)
	bool bShowWireframe : 1;  // 0xB5(0x1)
	char pad_182_1 : 7;  // 0xB6(0x1)
	bool bShowExtendedOptions : 1;  // 0xB6(0x1)
	char pad_183[1];  // 0xB7(0x1)

}; 



// Class MeshModelingTools.DrawAndRevolveToolBuilder
// Size: 0x28(Inherited: 0x28) 
struct UDrawAndRevolveToolBuilder : public UInteractiveToolBuilder
{

}; 



// Class MeshModelingTools.ProceduralRectangleToolProperties
// Size: 0xD8(Inherited: 0xB8) 
struct UProceduralRectangleToolProperties : public UProceduralShapeToolProperties
{
	uint8_t  RectangleType;  // 0xB8(0x4)
	float Width;  // 0xBC(0x4)
	float Depth;  // 0xC0(0x4)
	int32_t WidthSubdivisions;  // 0xC4(0x4)
	int32_t DepthSubdivisions;  // 0xC8(0x4)
	float CornerRadius;  // 0xCC(0x4)
	int32_t CornerSlices;  // 0xD0(0x4)
	char pad_212[4];  // 0xD4(0x4)

}; 



// Class MeshModelingTools.AddPrimitiveTool
// Size: 0x138(Inherited: 0xA0) 
struct UAddPrimitiveTool : public USingleClickTool
{
	char pad_160[24];  // 0xA0(0x18)
	struct UCreateMeshObjectTypeProperties* OutputTypeProperties;  // 0xB8(0x8)
	struct UProceduralShapeToolProperties* ShapeSettings;  // 0xC0(0x8)
	struct UNewMeshMaterialProperties* MaterialProperties;  // 0xC8(0x8)
	struct UPreviewMesh* PreviewMesh;  // 0xD0(0x8)
	struct UCombinedTransformGizmo* Gizmo;  // 0xD8(0x8)
	struct UDragAlignmentMechanic* DragAlignmentMechanic;  // 0xE0(0x8)
	struct FString AssetName;  // 0xE8(0x10)
	char pad_248[64];  // 0xF8(0x40)

}; 



// Class MeshModelingTools.ProceduralTorusToolProperties
// Size: 0xC8(Inherited: 0xB8) 
struct UProceduralTorusToolProperties : public UProceduralShapeToolProperties
{
	float MajorRadius;  // 0xB8(0x4)
	float MinorRadius;  // 0xBC(0x4)
	int32_t MajorSlices;  // 0xC0(0x4)
	int32_t MinorSlices;  // 0xC4(0x4)

}; 



// Class MeshModelingTools.EditMeshPolygonsToolBuilder
// Size: 0x30(Inherited: 0x28) 
struct UEditMeshPolygonsToolBuilder : public USingleSelectionMeshEditingToolBuilder
{
	char pad_40[8];  // 0x28(0x8)

}; 



// Class MeshModelingTools.ProceduralCylinderToolProperties
// Size: 0xC8(Inherited: 0xB8) 
struct UProceduralCylinderToolProperties : public UProceduralShapeToolProperties
{
	float Radius;  // 0xB8(0x4)
	float Height;  // 0xBC(0x4)
	int32_t RadialSlices;  // 0xC0(0x4)
	int32_t HeightSubdivisions;  // 0xC4(0x4)

}; 



// Class MeshModelingTools.CutMeshWithMeshToolProperties
// Size: 0xB8(Inherited: 0xA8) 
struct UCutMeshWithMeshToolProperties : public UInteractiveToolPropertySet
{
	char pad_168_1 : 7;  // 0xA8(0x1)
	bool bTryFixHoles : 1;  // 0xA8(0x1)
	char pad_169_1 : 7;  // 0xA9(0x1)
	bool bTryCollapseEdges : 1;  // 0xA9(0x1)
	char pad_170[2];  // 0xAA(0x2)
	float WindingThreshold;  // 0xAC(0x4)
	char pad_176_1 : 7;  // 0xB0(0x1)
	bool bShowNewBoundaries : 1;  // 0xB0(0x1)
	char pad_177_1 : 7;  // 0xB1(0x1)
	bool bUseFirstMeshMaterials : 1;  // 0xB1(0x1)
	char pad_178[6];  // 0xB2(0x6)

}; 



// Class MeshModelingTools.ProceduralConeToolProperties
// Size: 0xC8(Inherited: 0xB8) 
struct UProceduralConeToolProperties : public UProceduralShapeToolProperties
{
	float Radius;  // 0xB8(0x4)
	float Height;  // 0xBC(0x4)
	int32_t RadialSlices;  // 0xC0(0x4)
	int32_t HeightSubdivisions;  // 0xC4(0x4)

}; 



// Class MeshModelingTools.ProceduralArrowToolProperties
// Size: 0xD0(Inherited: 0xB8) 
struct UProceduralArrowToolProperties : public UProceduralShapeToolProperties
{
	float ShaftRadius;  // 0xB8(0x4)
	float ShaftHeight;  // 0xBC(0x4)
	float HeadRadius;  // 0xC0(0x4)
	float HeadHeight;  // 0xC4(0x4)
	int32_t RadialSlices;  // 0xC8(0x4)
	int32_t HeightSubdivisions;  // 0xCC(0x4)

}; 



// Class MeshModelingTools.ProceduralSphereToolProperties
// Size: 0xD0(Inherited: 0xB8) 
struct UProceduralSphereToolProperties : public UProceduralShapeToolProperties
{
	float Radius;  // 0xB8(0x4)
	uint8_t  SubdivisionType;  // 0xBC(0x4)
	int32_t Subdivisions;  // 0xC0(0x4)
	int32_t HorizontalSlices;  // 0xC4(0x4)
	int32_t VerticalSlices;  // 0xC8(0x4)
	char pad_204[4];  // 0xCC(0x4)

}; 



// Class MeshModelingTools.EditMeshPolygonsToolActionPropertySet
// Size: 0xB0(Inherited: 0xA8) 
struct UEditMeshPolygonsToolActionPropertySet : public UInteractiveToolPropertySet
{
	char pad_168[8];  // 0xA8(0x8)

}; 



// Class MeshModelingTools.EditMeshPolygonsToolAcceptCancelAction
// Size: 0xB0(Inherited: 0xB0) 
struct UEditMeshPolygonsToolAcceptCancelAction : public UEditMeshPolygonsToolActionPropertySet
{

	void Cancel(); // Function MeshModelingTools.EditMeshPolygonsToolAcceptCancelAction.Cancel
	void Apply(); // Function MeshModelingTools.EditMeshPolygonsToolAcceptCancelAction.Apply
}; 



// Class MeshModelingTools.ProceduralStairsToolProperties
// Size: 0xD8(Inherited: 0xB8) 
struct UProceduralStairsToolProperties : public UProceduralShapeToolProperties
{
	uint8_t  StairsType;  // 0xB8(0x4)
	int32_t NumSteps;  // 0xBC(0x4)
	float StepWidth;  // 0xC0(0x4)
	float StepHeight;  // 0xC4(0x4)
	float StepDepth;  // 0xC8(0x4)
	float CurveAngle;  // 0xCC(0x4)
	float SpiralAngle;  // 0xD0(0x4)
	float InnerRadius;  // 0xD4(0x4)

}; 



// Class MeshModelingTools.AddCylinderPrimitiveTool
// Size: 0x138(Inherited: 0x138) 
struct UAddCylinderPrimitiveTool : public UAddPrimitiveTool
{

}; 



// Class MeshModelingTools.CSGMeshesToolBuilder
// Size: 0x30(Inherited: 0x28) 
struct UCSGMeshesToolBuilder : public UBaseCreateFromSelectedToolBuilder
{
	char pad_40[8];  // 0x28(0x8)

}; 



// Class MeshModelingTools.EditMeshPolygonsToolUVActions
// Size: 0xB0(Inherited: 0xB0) 
struct UEditMeshPolygonsToolUVActions : public UEditMeshPolygonsToolActionPropertySet
{

	void PlanarProjection(); // Function MeshModelingTools.EditMeshPolygonsToolUVActions.PlanarProjection
}; 



// Class MeshModelingTools.AddRectanglePrimitiveTool
// Size: 0x138(Inherited: 0x138) 
struct UAddRectanglePrimitiveTool : public UAddPrimitiveTool
{

}; 



// Class MeshModelingTools.AddDiscPrimitiveTool
// Size: 0x138(Inherited: 0x138) 
struct UAddDiscPrimitiveTool : public UAddPrimitiveTool
{

}; 



// Class MeshModelingTools.EditMeshPolygonsActionModeToolBuilder
// Size: 0x38(Inherited: 0x30) 
struct UEditMeshPolygonsActionModeToolBuilder : public UEditMeshPolygonsToolBuilder
{
	char pad_48[8];  // 0x30(0x8)

}; 



// Class MeshModelingTools.AddTorusPrimitiveTool
// Size: 0x138(Inherited: 0x138) 
struct UAddTorusPrimitiveTool : public UAddPrimitiveTool
{

}; 



// Class MeshModelingTools.AddArrowPrimitiveTool
// Size: 0x138(Inherited: 0x138) 
struct UAddArrowPrimitiveTool : public UAddPrimitiveTool
{

}; 



// Class MeshModelingTools.ExistingMeshMaterialProperties
// Size: 0xE0(Inherited: 0xA8) 
struct UExistingMeshMaterialProperties : public UInteractiveToolPropertySet
{
	uint8_t  MaterialMode;  // 0xA8(0x1)
	char pad_169[3];  // 0xA9(0x3)
	float CheckerDensity;  // 0xAC(0x4)
	struct UMaterialInterface* OverrideMaterial;  // 0xB0(0x8)
	struct FString UVChannel;  // 0xB8(0x10)
	struct TArray<struct FString> UVChannelNamesList;  // 0xC8(0x10)
	struct UMaterialInstanceDynamic* CheckerMaterial;  // 0xD8(0x8)

	struct TArray<struct FString> GetUVChannelNamesFunc(); // Function MeshModelingTools.ExistingMeshMaterialProperties.GetUVChannelNamesFunc
}; 



// Class MeshModelingTools.AddSpherePrimitiveTool
// Size: 0x138(Inherited: 0x138) 
struct UAddSpherePrimitiveTool : public UAddPrimitiveTool
{

}; 



// Class MeshModelingTools.RevolveToolProperties
// Size: 0x158(Inherited: 0x118) 
struct URevolveToolProperties : public URevolveProperties
{
	uint8_t  CapFillMode;  // 0x118(0x1)
	char pad_281_1 : 7;  // 0x119(0x1)
	bool bClosePathToAxis : 1;  // 0x119(0x1)
	char pad_282[6];  // 0x11A(0x6)
	struct FVector DrawPlaneOrigin;  // 0x120(0x18)
	struct FRotator DrawPlaneOrientation;  // 0x138(0x18)
	char pad_336_1 : 7;  // 0x150(0x1)
	bool bEnableSnapping : 1;  // 0x150(0x1)
	char pad_337_1 : 7;  // 0x151(0x1)
	bool bAllowedToEditDrawPlane : 1;  // 0x151(0x1)
	char pad_338[6];  // 0x152(0x6)

}; 



// Class MeshModelingTools.AddStairsPrimitiveTool
// Size: 0x138(Inherited: 0x138) 
struct UAddStairsPrimitiveTool : public UAddPrimitiveTool
{

}; 



// Class MeshModelingTools.CombineMeshesToolBuilder
// Size: 0x30(Inherited: 0x28) 
struct UCombineMeshesToolBuilder : public UMultiSelectionMeshEditingToolBuilder
{
	char pad_40[8];  // 0x28(0x8)

}; 



// Class MeshModelingTools.CombineMeshesToolProperties
// Size: 0xD0(Inherited: 0xA8) 
struct UCombineMeshesToolProperties : public UInteractiveToolPropertySet
{
	char pad_168_1 : 7;  // 0xA8(0x1)
	bool bIsDuplicateMode : 1;  // 0xA8(0x1)
	char pad_169[3];  // 0xA9(0x3)
	uint8_t  OutputWriteTo;  // 0xAC(0x4)
	struct FString OutputNewName;  // 0xB0(0x10)
	struct FString OutputExistingName;  // 0xC0(0x10)

}; 



// Class MeshModelingTools.CombineMeshesTool
// Size: 0xE0(Inherited: 0xB8) 
struct UCombineMeshesTool : public UMultiSelectionMeshEditingTool
{
	char pad_184[8];  // 0xB8(0x8)
	struct UCombineMeshesToolProperties* BasicProperties;  // 0xC0(0x8)
	struct UCreateMeshObjectTypeProperties* OutputTypeProperties;  // 0xC8(0x8)
	struct UOnAcceptHandleSourcesPropertiesBase* HandleSourceProperties;  // 0xD0(0x8)
	char pad_216[8];  // 0xD8(0x8)

}; 



// Class MeshModelingTools.RevolveOperatorFactory
// Size: 0x38(Inherited: 0x28) 
struct URevolveOperatorFactory : public UObject
{
	char pad_40[8];  // 0x28(0x8)
	struct UDrawAndRevolveTool* RevolveTool;  // 0x30(0x8)

}; 



// Class MeshModelingTools.CSGMeshesToolProperties
// Size: 0xD0(Inherited: 0xA8) 
struct UCSGMeshesToolProperties : public UInteractiveToolPropertySet
{
	uint8_t  Operation;  // 0xA8(0x1)
	char pad_169_1 : 7;  // 0xA9(0x1)
	bool bTryFixHoles : 1;  // 0xA9(0x1)
	char pad_170_1 : 7;  // 0xAA(0x1)
	bool bTryCollapseEdges : 1;  // 0xAA(0x1)
	char pad_171[1];  // 0xAB(0x1)
	float WindingThreshold;  // 0xAC(0x4)
	char pad_176_1 : 7;  // 0xB0(0x1)
	bool bShowNewBoundaries : 1;  // 0xB0(0x1)
	char pad_177_1 : 7;  // 0xB1(0x1)
	bool bShowSubtractedMesh : 1;  // 0xB1(0x1)
	char pad_178[2];  // 0xB2(0x2)
	float SubtractedMeshOpacity;  // 0xB4(0x4)
	struct FLinearColor SubtractedMeshColor;  // 0xB8(0x10)
	char pad_200_1 : 7;  // 0xC8(0x1)
	bool bUseFirstMeshMaterials : 1;  // 0xC8(0x1)
	char pad_201[7];  // 0xC9(0x7)

}; 



// Class MeshModelingTools.TrimMeshesToolProperties
// Size: 0xC8(Inherited: 0xA8) 
struct UTrimMeshesToolProperties : public UInteractiveToolPropertySet
{
	uint8_t  WhichMesh;  // 0xA8(0x1)
	uint8_t  TrimSide;  // 0xA9(0x1)
	char pad_170[2];  // 0xAA(0x2)
	float WindingThreshold;  // 0xAC(0x4)
	char pad_176_1 : 7;  // 0xB0(0x1)
	bool bShowTrimmingMesh : 1;  // 0xB0(0x1)
	char pad_177[3];  // 0xB1(0x3)
	float OpacityOfTrimmingMesh;  // 0xB4(0x4)
	struct FLinearColor ColorOfTrimmingMesh;  // 0xB8(0x10)

}; 



// Class MeshModelingTools.CutMeshWithMeshTool
// Size: 0x378(Inherited: 0x100) 
struct UCutMeshWithMeshTool : public UBaseCreateFromSelectedTool
{
	struct UCutMeshWithMeshToolProperties* CutProperties;  // 0x100(0x8)
	struct UPreviewMesh* IntersectPreviewMesh;  // 0x108(0x8)
	char pad_272[32];  // 0x110(0x20)
	struct ULineSetComponent* DrawnLineSet;  // 0x130(0x8)
	char pad_312[576];  // 0x138(0x240)

}; 



// Class MeshModelingTools.CutMeshWithMeshToolBuilder
// Size: 0x28(Inherited: 0x28) 
struct UCutMeshWithMeshToolBuilder : public UBaseCreateFromSelectedToolBuilder
{

}; 



// Class MeshModelingTools.EditMeshPolygonsToolActions
// Size: 0xB0(Inherited: 0xB0) 
struct UEditMeshPolygonsToolActions : public UEditMeshPolygonsToolActionPropertySet
{

	void SimplifyByGroups(); // Function MeshModelingTools.EditMeshPolygonsToolActions.SimplifyByGroups
	void Retriangulate(); // Function MeshModelingTools.EditMeshPolygonsToolActions.Retriangulate
	void RecalcNormals(); // Function MeshModelingTools.EditMeshPolygonsToolActions.RecalcNormals
	void PushPull(); // Function MeshModelingTools.EditMeshPolygonsToolActions.PushPull
	void Outset(); // Function MeshModelingTools.EditMeshPolygonsToolActions.Outset
	void Offset(); // Function MeshModelingTools.EditMeshPolygonsToolActions.Offset
	void Merge(); // Function MeshModelingTools.EditMeshPolygonsToolActions.Merge
	void Inset(); // Function MeshModelingTools.EditMeshPolygonsToolActions.Inset
	void InsertEdgeLoop(); // Function MeshModelingTools.EditMeshPolygonsToolActions.InsertEdgeLoop
	void InsertEdge(); // Function MeshModelingTools.EditMeshPolygonsToolActions.InsertEdge
	void Flip(); // Function MeshModelingTools.EditMeshPolygonsToolActions.Flip
	void Extrude(); // Function MeshModelingTools.EditMeshPolygonsToolActions.Extrude
	void Duplicate(); // Function MeshModelingTools.EditMeshPolygonsToolActions.Duplicate
	void Disconnect(); // Function MeshModelingTools.EditMeshPolygonsToolActions.Disconnect
	void Delete(); // Function MeshModelingTools.EditMeshPolygonsToolActions.Delete
	void Decompose(); // Function MeshModelingTools.EditMeshPolygonsToolActions.Decompose
	void CutFaces(); // Function MeshModelingTools.EditMeshPolygonsToolActions.CutFaces
	void Bevel(); // Function MeshModelingTools.EditMeshPolygonsToolActions.Bevel
}; 



// Class MeshModelingTools.DrawPolygonToolBuilder
// Size: 0x28(Inherited: 0x28) 
struct UDrawPolygonToolBuilder : public UInteractiveToolBuilder
{

}; 



// Class MeshModelingTools.DrawAndRevolveTool
// Size: 0x160(Inherited: 0x98) 
struct UDrawAndRevolveTool : public UInteractiveTool
{
	char pad_152[144];  // 0x98(0x90)
	struct UCurveControlPointsMechanic* ControlPointsMechanic;  // 0x128(0x8)
	struct UConstructionPlaneMechanic* PlaneMechanic;  // 0x130(0x8)
	struct UCreateMeshObjectTypeProperties* OutputTypeProperties;  // 0x138(0x8)
	struct URevolveToolProperties* Settings;  // 0x140(0x8)
	struct UNewMeshMaterialProperties* MaterialProperties;  // 0x148(0x8)
	struct UMeshOpPreviewWithBackgroundCompute* Preview;  // 0x150(0x8)
	char pad_344[8];  // 0x158(0x8)

}; 



// Class MeshModelingTools.RecomputeUVsTool
// Size: 0x118(Inherited: 0xB8) 
struct URecomputeUVsTool : public USingleSelectionMeshEditingTool
{
	struct UMeshUVChannelProperties* UVChannelProperties;  // 0xB8(0x8)
	struct URecomputeUVsToolProperties* Settings;  // 0xC0(0x8)
	struct UPolygroupLayersProperties* PolygroupLayerProperties;  // 0xC8(0x8)
	struct UExistingMeshMaterialProperties* MaterialSettings;  // 0xD0(0x8)
	char pad_216_1 : 7;  // 0xD8(0x1)
	bool bCreateUVLayoutViewOnSetup : 1;  // 0xD8(0x1)
	char pad_217[7];  // 0xD9(0x7)
	struct UUVLayoutPreview* UVLayoutView;  // 0xE0(0x8)
	struct URecomputeUVsOpFactory* RecomputeUVsOpFactory;  // 0xE8(0x8)
	struct UMeshOpPreviewWithBackgroundCompute* Preview;  // 0xF0(0x8)
	char pad_248[32];  // 0xF8(0x20)

}; 



// Class MeshModelingTools.EditMeshPolygonsSelectionModeToolBuilder
// Size: 0x38(Inherited: 0x30) 
struct UEditMeshPolygonsSelectionModeToolBuilder : public UEditMeshPolygonsToolBuilder
{
	char pad_48[8];  // 0x30(0x8)

}; 



// Class MeshModelingTools.DrawPolygonToolStandardProperties
// Size: 0xC0(Inherited: 0xA8) 
struct UDrawPolygonToolStandardProperties : public UInteractiveToolPropertySet
{
	uint8_t  PolygonDrawMode;  // 0xA8(0x1)
	char pad_169_1 : 7;  // 0xA9(0x1)
	bool bAllowSelfIntersections : 1;  // 0xA9(0x1)
	char pad_170[2];  // 0xAA(0x2)
	float FeatureSizeRatio;  // 0xAC(0x4)
	int32_t RadialSlices;  // 0xB0(0x4)
	float Distance;  // 0xB4(0x4)
	char pad_184_1 : 7;  // 0xB8(0x1)
	bool bShowGridGizmo : 1;  // 0xB8(0x1)
	uint8_t  ExtrudeMode;  // 0xB9(0x1)
	char pad_186[2];  // 0xBA(0x2)
	float ExtrudeHeight;  // 0xBC(0x4)

}; 



// Class MeshModelingTools.DrawPolygonToolSnapProperties
// Size: 0xB8(Inherited: 0xA8) 
struct UDrawPolygonToolSnapProperties : public UInteractiveToolPropertySet
{
	char pad_168_1 : 7;  // 0xA8(0x1)
	bool bEnableSnapping : 1;  // 0xA8(0x1)
	char pad_169_1 : 7;  // 0xA9(0x1)
	bool bSnapToWorldGrid : 1;  // 0xA9(0x1)
	char pad_170_1 : 7;  // 0xAA(0x1)
	bool bSnapToVertices : 1;  // 0xAA(0x1)
	char pad_171_1 : 7;  // 0xAB(0x1)
	bool bSnapToEdges : 1;  // 0xAB(0x1)
	char pad_172_1 : 7;  // 0xAC(0x1)
	bool bSnapToAxes : 1;  // 0xAC(0x1)
	char pad_173_1 : 7;  // 0xAD(0x1)
	bool bSnapToLengths : 1;  // 0xAD(0x1)
	char pad_174_1 : 7;  // 0xAE(0x1)
	bool bSnapToSurfaces : 1;  // 0xAE(0x1)
	char pad_175[1];  // 0xAF(0x1)
	float SnapToSurfacesOffset;  // 0xB0(0x4)
	char pad_180[4];  // 0xB4(0x4)

}; 



// Class MeshModelingTools.DrawPolygonTool
// Size: 0x5A0(Inherited: 0x98) 
struct UDrawPolygonTool : public UInteractiveTool
{
	char pad_152[8];  // 0x98(0x8)
	struct UCreateMeshObjectTypeProperties* OutputTypeProperties;  // 0xA0(0x8)
	struct UDrawPolygonToolStandardProperties* PolygonProperties;  // 0xA8(0x8)
	struct UDrawPolygonToolSnapProperties* SnapProperties;  // 0xB0(0x8)
	struct UNewMeshMaterialProperties* MaterialProperties;  // 0xB8(0x8)
	char pad_192[208];  // 0xC0(0xD0)
	struct UPreviewMesh* PreviewMesh;  // 0x190(0x8)
	struct UCombinedTransformGizmo* PlaneTransformGizmo;  // 0x198(0x8)
	struct UTransformProxy* PlaneTransformProxy;  // 0x1A0(0x8)
	char pad_424[992];  // 0x1A8(0x3E0)
	struct UPlaneDistanceFromHitMechanic* HeightMechanic;  // 0x588(0x8)
	struct UDragAlignmentMechanic* DragAlignmentMechanic;  // 0x590(0x8)
	char pad_1432[8];  // 0x598(0x8)

}; 



// Class MeshModelingTools.EditMeshPolygonsToolEdgeActions_Triangles
// Size: 0xB0(Inherited: 0xB0) 
struct UEditMeshPolygonsToolEdgeActions_Triangles : public UEditMeshPolygonsToolActionPropertySet
{

	void Weld(); // Function MeshModelingTools.EditMeshPolygonsToolEdgeActions_Triangles.Weld
	void Split(); // Function MeshModelingTools.EditMeshPolygonsToolEdgeActions_Triangles.Split
	void Flip(); // Function MeshModelingTools.EditMeshPolygonsToolEdgeActions_Triangles.Flip
	void FillHole(); // Function MeshModelingTools.EditMeshPolygonsToolEdgeActions_Triangles.FillHole
	void Collapse(); // Function MeshModelingTools.EditMeshPolygonsToolEdgeActions_Triangles.Collapse
}; 



// Class MeshModelingTools.PolyEditCommonProperties
// Size: 0xB8(Inherited: 0xA8) 
struct UPolyEditCommonProperties : public UInteractiveToolPropertySet
{
	char pad_168_1 : 7;  // 0xA8(0x1)
	bool bShowWireframe : 1;  // 0xA8(0x1)
	char pad_169_1 : 7;  // 0xA9(0x1)
	bool bShowSelectableCorners : 1;  // 0xA9(0x1)
	char pad_170_1 : 7;  // 0xAA(0x1)
	bool bGizmoVisible : 1;  // 0xAA(0x1)
	char pad_171[1];  // 0xAB(0x1)
	uint8_t  LocalFrameMode;  // 0xAC(0x4)
	char pad_176_1 : 7;  // 0xB0(0x1)
	bool bLockRotation : 1;  // 0xB0(0x1)
	char pad_177_1 : 7;  // 0xB1(0x1)
	bool bLocalCoordSystem : 1;  // 0xB1(0x1)
	char pad_178[6];  // 0xB2(0x6)

}; 



// Class MeshModelingTools.EditMeshPolygonsToolEdgeActions
// Size: 0xB0(Inherited: 0xB0) 
struct UEditMeshPolygonsToolEdgeActions : public UEditMeshPolygonsToolActionPropertySet
{

	void Weld(); // Function MeshModelingTools.EditMeshPolygonsToolEdgeActions.Weld
	void Straighten(); // Function MeshModelingTools.EditMeshPolygonsToolEdgeActions.Straighten
	void FillHole(); // Function MeshModelingTools.EditMeshPolygonsToolEdgeActions.FillHole
	void Bridge(); // Function MeshModelingTools.EditMeshPolygonsToolEdgeActions.Bridge
	void Bevel(); // Function MeshModelingTools.EditMeshPolygonsToolEdgeActions.Bevel
}; 



// Class MeshModelingTools.EditMeshPolygonsToolCancelAction
// Size: 0xB0(Inherited: 0xB0) 
struct UEditMeshPolygonsToolCancelAction : public UEditMeshPolygonsToolActionPropertySet
{

	void Done(); // Function MeshModelingTools.EditMeshPolygonsToolCancelAction.Done
}; 



// Class MeshModelingTools.MeshEditingViewProperties
// Size: 0xF8(Inherited: 0xA8) 
struct UMeshEditingViewProperties : public UInteractiveToolPropertySet
{
	char pad_168_1 : 7;  // 0xA8(0x1)
	bool bShowWireframe : 1;  // 0xA8(0x1)
	char pad_169[3];  // 0xA9(0x3)
	uint8_t  MaterialMode;  // 0xAC(0x4)
	char pad_176_1 : 7;  // 0xB0(0x1)
	bool bFlatShading : 1;  // 0xB0(0x1)
	char pad_177[3];  // 0xB1(0x3)
	struct FLinearColor Color;  // 0xB4(0x10)
	char pad_196[4];  // 0xC4(0x4)
	struct UTexture2D* Image;  // 0xC8(0x8)
	double Opacity;  // 0xD0(0x8)
	struct FLinearColor TransparentMaterialColor;  // 0xD8(0x10)
	char pad_232_1 : 7;  // 0xE8(0x1)
	bool bTwoSided : 1;  // 0xE8(0x1)
	char pad_233[3];  // 0xE9(0x3)
	struct TWeakObjectPtr<UMaterialInterface> CustomMaterial;  // 0xEC(0x8)
	char pad_244[4];  // 0xF4(0x4)

}; 



// Class MeshModelingTools.MeshUVChannelProperties
// Size: 0xC8(Inherited: 0xA8) 
struct UMeshUVChannelProperties : public UInteractiveToolPropertySet
{
	struct FString UVChannel;  // 0xA8(0x10)
	struct TArray<struct FString> UVChannelNamesList;  // 0xB8(0x10)

	struct TArray<struct FString> GetUVChannelNamesFunc(); // Function MeshModelingTools.MeshUVChannelProperties.GetUVChannelNamesFunc
}; 



// Class MeshModelingTools.PolyEditBevelEdgeProperties
// Size: 0xB0(Inherited: 0xA8) 
struct UPolyEditBevelEdgeProperties : public UInteractiveToolPropertySet
{
	double BevelDistance;  // 0xA8(0x8)

}; 



// Class MeshModelingTools.PolyEditBevelEdgeActivity
// Size: 0x140(Inherited: 0x30) 
struct UPolyEditBevelEdgeActivity : public UInteractiveToolActivity
{
	char pad_48[8];  // 0x30(0x8)
	struct UPolyEditBevelEdgeProperties* BevelProperties;  // 0x38(0x8)
	struct UPolyEditActivityContext* ActivityContext;  // 0x40(0x8)
	char pad_72[248];  // 0x48(0xF8)

}; 



// Class MeshModelingTools.PolyEditCutFacesActivity
// Size: 0xC0(Inherited: 0x30) 
struct UPolyEditCutFacesActivity : public UInteractiveToolActivity
{
	char pad_48[16];  // 0x30(0x10)
	struct UPolyEditCutProperties* CutProperties;  // 0x40(0x8)
	struct UPolyEditPreviewMesh* EditPreview;  // 0x48(0x8)
	struct UCollectSurfacePathMechanic* SurfacePathMechanic;  // 0x50(0x8)
	struct UPolyEditActivityContext* ActivityContext;  // 0x58(0x8)
	char pad_96[96];  // 0x60(0x60)

}; 



// Class MeshModelingTools.PolyEditExtrudeProperties
// Size: 0xD8(Inherited: 0xA8) 
struct UPolyEditExtrudeProperties : public UInteractiveToolPropertySet
{
	uint8_t  DistanceMode;  // 0xA8(0x4)
	char pad_172[4];  // 0xAC(0x4)
	double Distance;  // 0xB0(0x8)
	uint8_t  Direction;  // 0xB8(0x4)
	uint8_t  MeasureDirection;  // 0xBC(0x4)
	char pad_192_1 : 7;  // 0xC0(0x1)
	bool bShellsToSolids : 1;  // 0xC0(0x1)
	char pad_193[3];  // 0xC1(0x3)
	uint8_t  DirectionMode;  // 0xC4(0x4)
	double MaxDistanceScaleFactor;  // 0xC8(0x8)
	char pad_208_1 : 7;  // 0xD0(0x1)
	bool bUseColinearityForSettingBorderGroups : 1;  // 0xD0(0x1)
	char pad_209[7];  // 0xD1(0x7)

}; 



// Class MeshModelingTools.PolyEditPushPullProperties
// Size: 0xD8(Inherited: 0xA8) 
struct UPolyEditPushPullProperties : public UInteractiveToolPropertySet
{
	uint8_t  DistanceMode;  // 0xA8(0x4)
	char pad_172[4];  // 0xAC(0x4)
	double Distance;  // 0xB0(0x8)
	uint8_t  DirectionMode;  // 0xB8(0x4)
	char pad_188[4];  // 0xBC(0x4)
	double MaxDistanceScaleFactor;  // 0xC0(0x8)
	char pad_200_1 : 7;  // 0xC8(0x1)
	bool bShellsToSolids : 1;  // 0xC8(0x1)
	char pad_201[3];  // 0xC9(0x3)
	uint8_t  MeasureDirection;  // 0xCC(0x4)
	char pad_208_1 : 7;  // 0xD0(0x1)
	bool bUseColinearityForSettingBorderGroups : 1;  // 0xD0(0x1)
	char pad_209[7];  // 0xD1(0x7)

}; 



// Class MeshModelingTools.PolyEditExtrudeActivity
// Size: 0x1D0(Inherited: 0x30) 
struct UPolyEditExtrudeActivity : public UInteractiveToolActivity
{
	char pad_48[32];  // 0x30(0x20)
	struct UPolyEditExtrudeProperties* ExtrudeProperties;  // 0x50(0x8)
	struct UPolyEditOffsetProperties* OffsetProperties;  // 0x58(0x8)
	struct UPolyEditPushPullProperties* PushPullProperties;  // 0x60(0x8)
	struct UPlaneDistanceFromHitMechanic* ExtrudeHeightMechanic;  // 0x68(0x8)
	struct UPolyEditActivityContext* ActivityContext;  // 0x70(0x8)
	char pad_120[344];  // 0x78(0x158)

}; 



// Class MeshModelingTools.GroupEdgeInsertionProperties
// Size: 0xB8(Inherited: 0xA8) 
struct UGroupEdgeInsertionProperties : public UInteractiveToolPropertySet
{
	uint8_t  InsertionMode;  // 0xA8(0x4)
	char pad_172[4];  // 0xAC(0x4)
	double VertexTolerance;  // 0xB0(0x8)

}; 



// Class MeshModelingTools.PolyEditInsertEdgeActivity
// Size: 0x440(Inherited: 0x30) 
struct UPolyEditInsertEdgeActivity : public UInteractiveToolActivity
{
	char pad_48[24];  // 0x30(0x18)
	struct UGroupEdgeInsertionProperties* Settings;  // 0x48(0x8)
	struct UPolyEditActivityContext* ActivityContext;  // 0x50(0x8)
	char pad_88[1000];  // 0x58(0x3E8)

}; 



// Class MeshModelingTools.EdgeLoopInsertionProperties
// Size: 0xD8(Inherited: 0xA8) 
struct UEdgeLoopInsertionProperties : public UInteractiveToolPropertySet
{
	uint8_t  PositionMode;  // 0xA8(0x4)
	uint8_t  InsertionMode;  // 0xAC(0x4)
	int32_t NumLoops;  // 0xB0(0x4)
	char pad_180[4];  // 0xB4(0x4)
	double ProportionOffset;  // 0xB8(0x8)
	double DistanceOffset;  // 0xC0(0x8)
	char pad_200_1 : 7;  // 0xC8(0x1)
	bool bInteractive : 1;  // 0xC8(0x1)
	char pad_201_1 : 7;  // 0xC9(0x1)
	bool bFlipOffsetDirection : 1;  // 0xC9(0x1)
	char pad_202_1 : 7;  // 0xCA(0x1)
	bool bHighlightProblemGroups : 1;  // 0xCA(0x1)
	char pad_203[5];  // 0xCB(0x5)
	double VertexTolerance;  // 0xD0(0x8)

}; 



// Class MeshModelingTools.PolyEditInsertEdgeLoopActivity
// Size: 0x400(Inherited: 0x30) 
struct UPolyEditInsertEdgeLoopActivity : public UInteractiveToolActivity
{
	char pad_48[24];  // 0x30(0x18)
	struct UEdgeLoopInsertionProperties* Settings;  // 0x48(0x8)
	struct UPolyEditActivityContext* ActivityContext;  // 0x50(0x8)
	char pad_88[936];  // 0x58(0x3A8)

}; 



// Class MeshModelingTools.PolyEditInsetOutsetProperties
// Size: 0xB8(Inherited: 0xA8) 
struct UPolyEditInsetOutsetProperties : public UInteractiveToolPropertySet
{
	float Softness;  // 0xA8(0x4)
	char pad_172_1 : 7;  // 0xAC(0x1)
	bool bBoundaryOnly : 1;  // 0xAC(0x1)
	char pad_173[3];  // 0xAD(0x3)
	float AreaScale;  // 0xB0(0x4)
	char pad_180_1 : 7;  // 0xB4(0x1)
	bool bReproject : 1;  // 0xB4(0x1)
	char pad_181_1 : 7;  // 0xB5(0x1)
	bool bOutset : 1;  // 0xB5(0x1)
	char pad_182[2];  // 0xB6(0x2)

}; 



// Class MeshModelingTools.PolyEditInsetOutsetActivity
// Size: 0x70(Inherited: 0x30) 
struct UPolyEditInsetOutsetActivity : public UInteractiveToolActivity
{
	char pad_48[16];  // 0x30(0x10)
	struct UPolyEditInsetOutsetProperties* Settings;  // 0x40(0x8)
	char pad_72[8];  // 0x48(0x8)
	struct UPolyEditPreviewMesh* EditPreview;  // 0x50(0x8)
	struct USpatialCurveDistanceMechanic* CurveDistMechanic;  // 0x58(0x8)
	struct UPolyEditActivityContext* ActivityContext;  // 0x60(0x8)
	char pad_104[8];  // 0x68(0x8)

}; 



// Class MeshModelingTools.PolyEditSetUVProperties
// Size: 0xB0(Inherited: 0xA8) 
struct UPolyEditSetUVProperties : public UInteractiveToolPropertySet
{
	char pad_168_1 : 7;  // 0xA8(0x1)
	bool bShowMaterial : 1;  // 0xA8(0x1)
	char pad_169[7];  // 0xA9(0x7)

}; 



// Class MeshModelingTools.PolyEditPlanarProjectionUVActivity
// Size: 0xF0(Inherited: 0x30) 
struct UPolyEditPlanarProjectionUVActivity : public UInteractiveToolActivity
{
	char pad_48[16];  // 0x30(0x10)
	struct UPolyEditSetUVProperties* SetUVProperties;  // 0x40(0x8)
	struct UPolyEditPreviewMesh* EditPreview;  // 0x48(0x8)
	struct UCollectSurfacePathMechanic* SurfacePathMechanic;  // 0x50(0x8)
	struct UPolyEditActivityContext* ActivityContext;  // 0x58(0x8)
	char pad_96[144];  // 0x60(0x90)

}; 



// Class MeshModelingTools.UVLayoutToolBuilder
// Size: 0x28(Inherited: 0x28) 
struct UUVLayoutToolBuilder : public UMultiSelectionMeshEditingToolBuilder
{

}; 



// Class MeshModelingTools.UVLayoutTool
// Size: 0x160(Inherited: 0xB8) 
struct UUVLayoutTool : public UMultiSelectionMeshEditingTool
{
	struct UMeshUVChannelProperties* UVChannelProperties;  // 0xB8(0x8)
	struct UUVLayoutProperties* BasicProperties;  // 0xC0(0x8)
	struct UExistingMeshMaterialProperties* MaterialSettings;  // 0xC8(0x8)
	struct TArray<struct UMeshOpPreviewWithBackgroundCompute*> Previews;  // 0xD0(0x10)
	struct TArray<struct UUVLayoutOperatorFactory*> Factories;  // 0xE0(0x10)
	char pad_240[96];  // 0xF0(0x60)
	struct UUVLayoutPreview* UVLayoutView;  // 0x150(0x8)
	char pad_344[8];  // 0x158(0x8)

}; 



// Class MeshModelingTools.UVProjectionToolBuilder
// Size: 0x28(Inherited: 0x28) 
struct UUVProjectionToolBuilder : public USingleSelectionMeshEditingToolBuilder
{

}; 



// Class MeshModelingTools.UVProjectionToolEditActions
// Size: 0xB0(Inherited: 0xA8) 
struct UUVProjectionToolEditActions : public UInteractiveToolPropertySet
{
	char pad_168[8];  // 0xA8(0x8)

	void Reset(); // Function MeshModelingTools.UVProjectionToolEditActions.Reset
	void AutoFitAlign(); // Function MeshModelingTools.UVProjectionToolEditActions.AutoFitAlign
	void AutoFit(); // Function MeshModelingTools.UVProjectionToolEditActions.AutoFit
}; 



// Class MeshModelingTools.UVProjectionToolProperties
// Size: 0x190(Inherited: 0xA8) 
struct UUVProjectionToolProperties : public UInteractiveToolPropertySet
{
	uint8_t  ProjectionType;  // 0xA8(0x1)
	char pad_169[7];  // 0xA9(0x7)
	struct FVector Dimensions;  // 0xB0(0x18)
	char pad_200_1 : 7;  // 0xC8(0x1)
	bool bUniformDimensions : 1;  // 0xC8(0x1)
	char pad_201[3];  // 0xC9(0x3)
	uint8_t  Initialization;  // 0xCC(0x4)
	float CylinderSplitAngle;  // 0xD0(0x4)
	float ExpMapNormalBlending;  // 0xD4(0x4)
	int32_t ExpMapSmoothingSteps;  // 0xD8(0x4)
	float ExpMapSmoothingAlpha;  // 0xDC(0x4)
	float Rotation;  // 0xE0(0x4)
	char pad_228[4];  // 0xE4(0x4)
	struct FVector2D Scale;  // 0xE8(0x10)
	struct FVector2D Translation;  // 0xF8(0x10)
	struct FVector SavedDimensions;  // 0x108(0x18)
	char pad_288_1 : 7;  // 0x120(0x1)
	bool bSavedUniformDimensions : 1;  // 0x120(0x1)
	char pad_289[15];  // 0x121(0xF)
	struct FTransform SavedTransform;  // 0x130(0x60)

}; 



// Class MeshModelingTools.UVProjectionOperatorFactory
// Size: 0x38(Inherited: 0x28) 
struct UUVProjectionOperatorFactory : public UObject
{
	char pad_40[8];  // 0x28(0x8)
	struct UUVProjectionTool* Tool;  // 0x30(0x8)

}; 



// Class MeshModelingTools.UVProjectionTool
// Size: 0x450(Inherited: 0xB8) 
struct UUVProjectionTool : public USingleSelectionMeshEditingTool
{
	struct UMeshUVChannelProperties* UVChannelProperties;  // 0xB8(0x8)
	struct UUVProjectionToolProperties* BasicProperties;  // 0xC0(0x8)
	struct UUVProjectionToolEditActions* EditActions;  // 0xC8(0x8)
	struct UExistingMeshMaterialProperties* MaterialSettings;  // 0xD0(0x8)
	struct UMeshOpPreviewWithBackgroundCompute* Preview;  // 0xD8(0x8)
	struct UMaterialInstanceDynamic* CheckerMaterial;  // 0xE0(0x8)
	struct UCombinedTransformGizmo* TransformGizmo;  // 0xE8(0x8)
	struct UTransformProxy* TransformProxy;  // 0xF0(0x8)
	struct UUVProjectionOperatorFactory* OperatorFactory;  // 0xF8(0x8)
	struct UPreviewGeometry* EdgeRenderer;  // 0x100(0x8)
	char pad_264[816];  // 0x108(0x330)
	struct USingleClickInputBehavior* ClickToSetPlaneBehavior;  // 0x438(0x8)
	char pad_1088[16];  // 0x440(0x10)

}; 



