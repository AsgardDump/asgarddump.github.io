#pragma once 
#include <IrisStub_Structs.h>
 
 
 
// Class IrisStub.SphereWithOwnerBoostNetObjectPrioritizerConfig
// Size: 0x28(Inherited: 0x28) 
struct USphereWithOwnerBoostNetObjectPrioritizerConfig : public UNetObjectPrioritizerConfig
{

}; 



// Class IrisStub.DataStream
// Size: 0x28(Inherited: 0x28) 
struct UDataStream : public UObject
{

}; 



// Class IrisStub.NetBlobHandler
// Size: 0x28(Inherited: 0x28) 
struct UNetBlobHandler : public UObject
{

}; 



// Class IrisStub.NetObjectCountLimiterConfig
// Size: 0x28(Inherited: 0x28) 
struct UNetObjectCountLimiterConfig : public UNetObjectPrioritizerConfig
{

}; 



// Class IrisStub.IrisObjectReferencePackageMap
// Size: 0x28(Inherited: 0x28) 
struct UIrisObjectReferencePackageMap : public UObject
{

}; 



// Class IrisStub.NetObjectPrioritizerConfig
// Size: 0x28(Inherited: 0x28) 
struct UNetObjectPrioritizerConfig : public UObject
{

}; 



// Class IrisStub.NetObjectFilterConfig
// Size: 0x28(Inherited: 0x28) 
struct UNetObjectFilterConfig : public UObject
{

}; 



// Class IrisStub.NetObjectFilter
// Size: 0x28(Inherited: 0x28) 
struct UNetObjectFilter : public UObject
{

}; 



// Class IrisStub.NetObjectPrioritizer
// Size: 0x28(Inherited: 0x28) 
struct UNetObjectPrioritizer : public UObject
{

}; 



// Class IrisStub.ReplicationBridge
// Size: 0x28(Inherited: 0x28) 
struct UReplicationBridge : public UObject
{

}; 



// Class IrisStub.ObjectReplicationBridge
// Size: 0x28(Inherited: 0x28) 
struct UObjectReplicationBridge : public UReplicationBridge
{

}; 



// Class IrisStub.SequentialPartialNetBlobHandlerConfig
// Size: 0x28(Inherited: 0x28) 
struct USequentialPartialNetBlobHandlerConfig : public UObject
{

}; 



// Class IrisStub.SequentialPartialNetBlobHandler
// Size: 0x28(Inherited: 0x28) 
struct USequentialPartialNetBlobHandler : public UNetBlobHandler
{

}; 



