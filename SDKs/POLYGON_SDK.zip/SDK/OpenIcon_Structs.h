#pragma once 
#include "SDK.h" 
 
 
// ScriptStruct OpenIcon.OpenIconData
// Size: 0x40(Inherited: 0x8) 
struct FOpenIconData : public FTableRowBase
{
	uint8_t  Source;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct FString IconName;  // 0x10(0x10)
	struct FString IconCategory;  // 0x20(0x10)
	struct FString IconUcode;  // 0x30(0x10)

}; 
// Function OpenIcon.OpenIconUtil.CustomIconToTexture
// Size: 0x50(Inherited: 0x0) 
struct FCustomIconToTexture
{
	struct UDataTable* IconData;  // 0x0(0x8)
	struct UFont* IconFont;  // 0x8(0x8)
	struct FName IconID;  // 0x10(0x8)
	int32_t IconSize;  // 0x18(0x4)
	uint8_t  OutputSize;  // 0x1C(0x1)
	char pad_29[3];  // 0x1D(0x3)
	struct FString Path;  // 0x20(0x10)
	struct FString Filename;  // 0x30(0x10)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool UseDefaultName : 1;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)
	struct UTexture2D* ReturnValue;  // 0x48(0x8)

}; 
// Function OpenIcon.OpenIconUtil.CopyToClipboard
// Size: 0x10(Inherited: 0x0) 
struct FCopyToClipboard
{
	struct FString S;  // 0x0(0x10)

}; 
// Function OpenIcon.CustomIcon.InitCustomIcon
// Size: 0x10(Inherited: 0x0) 
struct FInitCustomIcon
{
	struct UDataTable* InIconData;  // 0x0(0x8)
	struct UObject* InIconFont;  // 0x8(0x8)

}; 
// ScriptStruct OpenIcon.CustomIconData
// Size: 0x48(Inherited: 0x8) 
struct FCustomIconData : public FTableRowBase
{
	struct FString IconPack;  // 0x8(0x10)
	struct FString IconName;  // 0x18(0x10)
	struct FString IconCategory;  // 0x28(0x10)
	struct FString IconUcode;  // 0x38(0x10)

}; 
// Function OpenIcon.OpenIcon.SetIconByID
// Size: 0xC(Inherited: 0x0) 
struct FSetIconByID
{
	struct FName IconID;  // 0x0(0x8)
	int32_t Size;  // 0x8(0x4)

}; 
// Function OpenIcon.OpenIcon.SetIcon
// Size: 0x30(Inherited: 0x0) 
struct FSetIcon
{
	uint8_t  Source;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FString Category;  // 0x8(0x10)
	struct FString IconUcode;  // 0x18(0x10)
	int32_t Size;  // 0x28(0x4)
	char pad_44[4];  // 0x2C(0x4)

}; 
// Function OpenIcon.OpenIconUtil.CustomIconToTexture_Advanced
// Size: 0x190(Inherited: 0x0) 
struct FCustomIconToTexture_Advanced
{
	struct FVector2D Translation;  // 0x0(0x10)
	struct FSlateColor ColorAndOpacity;  // 0x10(0x14)
	struct FLinearColor ShadowColorAndOpacity;  // 0x24(0x10)
	char pad_52[4];  // 0x34(0x4)
	struct FVector2D ShadowOffset;  // 0x38(0x10)
	struct FFontOutlineSettings OutlineSettings;  // 0x48(0x20)
	char pad_104[8];  // 0x68(0x8)
	struct FSlateBrush StrikeBrush;  // 0x70(0xD0)
	struct UDataTable* IconData;  // 0x140(0x8)
	struct UFont* IconFont;  // 0x148(0x8)
	struct FName IconID;  // 0x150(0x8)
	int32_t IconSize;  // 0x158(0x4)
	uint8_t  OutputSize;  // 0x15C(0x1)
	char pad_349[3];  // 0x15D(0x3)
	struct FString Path;  // 0x160(0x10)
	struct FString Filename;  // 0x170(0x10)
	char pad_384_1 : 7;  // 0x180(0x1)
	bool UseDefaultName : 1;  // 0x180(0x1)
	char pad_385[7];  // 0x181(0x7)
	struct UTexture2D* ReturnValue;  // 0x188(0x8)

}; 
// Function OpenIcon.OpenIconUtil.GetCustomIconDataFromTable
// Size: 0x20(Inherited: 0x0) 
struct FGetCustomIconDataFromTable
{
	struct UDataTable* DataTable;  // 0x0(0x8)
	struct TArray<struct FCustomIconData> OutData;  // 0x8(0x10)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool ReturnValue : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)

}; 
// Function OpenIcon.OpenIconUtil.OpenIconToTexture
// Size: 0x40(Inherited: 0x0) 
struct FOpenIconToTexture
{
	struct FName IconID;  // 0x0(0x8)
	int32_t IconSize;  // 0x8(0x4)
	uint8_t  OutputSize;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)
	struct FString Path;  // 0x10(0x10)
	struct FString Filename;  // 0x20(0x10)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool UseDefaultName : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)
	struct UTexture2D* ReturnValue;  // 0x38(0x8)

}; 
// Function OpenIcon.OpenIconUtil.OpenIconToTexture_Advanced
// Size: 0x180(Inherited: 0x0) 
struct FOpenIconToTexture_Advanced
{
	struct FVector2D Translation;  // 0x0(0x10)
	struct FSlateColor ColorAndOpacity;  // 0x10(0x14)
	struct FLinearColor ShadowColorAndOpacity;  // 0x24(0x10)
	char pad_52[4];  // 0x34(0x4)
	struct FVector2D ShadowOffset;  // 0x38(0x10)
	struct FFontOutlineSettings OutlineSettings;  // 0x48(0x20)
	char pad_104[8];  // 0x68(0x8)
	struct FSlateBrush StrikeBrush;  // 0x70(0xD0)
	struct FName IconID;  // 0x140(0x8)
	int32_t IconSize;  // 0x148(0x4)
	uint8_t  OutputSize;  // 0x14C(0x1)
	char pad_333[3];  // 0x14D(0x3)
	struct FString Path;  // 0x150(0x10)
	struct FString Filename;  // 0x160(0x10)
	char pad_368_1 : 7;  // 0x170(0x1)
	bool UseDefaultName : 1;  // 0x170(0x1)
	char pad_369[7];  // 0x171(0x7)
	struct UTexture2D* ReturnValue;  // 0x178(0x8)

}; 
