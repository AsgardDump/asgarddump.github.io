#pragma once 
#include <BP_Item_Underbarrel_Grip_01_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Item_Underbarrel_Grip_01.BP_Item_Underbarrel_Grip_01_C
// Size: 0x3C0(Inherited: 0x3C0) 
struct ABP_Item_Underbarrel_Grip_01_C : public AItem_Module_Underbarrel_Grip
{

}; 



