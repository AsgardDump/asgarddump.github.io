#pragma once 
#include <CameraShake_Animation_Structs.h>
 
 
 
// BlueprintGeneratedClass CameraShake_Animation.CameraShake_Animation_C
// Size: 0x210(Inherited: 0x210) 
struct UCameraShake_Animation_C : public ULegacyCameraShake
{

}; 



