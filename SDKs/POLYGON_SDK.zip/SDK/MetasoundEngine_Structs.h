#pragma once 
#include "SDK.h" 
 
 
// ScriptStruct MetasoundEngine.DefaultMetaSoundAssetAutoUpdateSettings
// Size: 0x20(Inherited: 0x0) 
struct FDefaultMetaSoundAssetAutoUpdateSettings
{
	struct FSoftObjectPath Metasound;  // 0x0(0x20)

}; 
// ScriptStruct MetasoundEngine.MetaSoundAssetDirectory
// Size: 0x10(Inherited: 0x0) 
struct FMetaSoundAssetDirectory
{
	struct FDirectoryPath Directory;  // 0x0(0x10)

}; 
// Function MetasoundEngine.MetaSoundAssetSubsystem.RegisterAssetClassesInDirectories
// Size: 0x10(Inherited: 0x0) 
struct FRegisterAssetClassesInDirectories
{
	struct TArray<struct FMetaSoundAssetDirectory> Directories;  // 0x0(0x10)

}; 
// ScriptStruct MetasoundEngine.MetaSoundAsyncAssetDependencies
// Size: 0x30(Inherited: 0x0) 
struct FMetaSoundAsyncAssetDependencies
{
	char pad_0[8];  // 0x0(0x8)
	struct UObject* Metasound;  // 0x8(0x8)
	char pad_16[32];  // 0x10(0x20)

}; 
// Function MetasoundEngine.MetaSoundAssetSubsystem.UnregisterAssetClassesInDirectories
// Size: 0x10(Inherited: 0x0) 
struct FUnregisterAssetClassesInDirectories
{
	struct TArray<struct FMetaSoundAssetDirectory> Directories;  // 0x0(0x10)

}; 
