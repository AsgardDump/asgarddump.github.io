#pragma once 
#include <ConsoleVariablesEditorRuntime_Structs.h>
 
 
 
// Class ConsoleVariablesEditorRuntime.ConsoleVariablesAsset
// Size: 0x48(Inherited: 0x28) 
struct UConsoleVariablesAsset : public UObject
{
	struct FString VariableCollectionDescription;  // 0x28(0x10)
	struct TArray<struct FConsoleVariablesEditorAssetSaveData> SavedCommands;  // 0x38(0x10)

	void SetVariableCollectionDescription(struct FString InVariableCollectionDescription); // Function ConsoleVariablesEditorRuntime.ConsoleVariablesAsset.SetVariableCollectionDescription
	void ReplaceSavedCommands(struct TArray<struct FConsoleVariablesEditorAssetSaveData>& Replacement); // Function ConsoleVariablesEditorRuntime.ConsoleVariablesAsset.ReplaceSavedCommands
	bool RemoveConsoleVariable(struct FString InCommandString); // Function ConsoleVariablesEditorRuntime.ConsoleVariablesAsset.RemoveConsoleVariable
	struct FString GetVariableCollectionDescription(); // Function ConsoleVariablesEditorRuntime.ConsoleVariablesAsset.GetVariableCollectionDescription
	int32_t GetSavedCommandsCount(); // Function ConsoleVariablesEditorRuntime.ConsoleVariablesAsset.GetSavedCommandsCount
	struct TArray<struct FString> GetSavedCommandsAsStringArray(bool bOnlyIncludeChecked); // Function ConsoleVariablesEditorRuntime.ConsoleVariablesAsset.GetSavedCommandsAsStringArray
	struct FString GetSavedCommandsAsCommaSeparatedString(bool bOnlyIncludeChecked); // Function ConsoleVariablesEditorRuntime.ConsoleVariablesAsset.GetSavedCommandsAsCommaSeparatedString
	struct TArray<struct FConsoleVariablesEditorAssetSaveData> GetSavedCommands(); // Function ConsoleVariablesEditorRuntime.ConsoleVariablesAsset.GetSavedCommands
	bool FindSavedDataByCommandString(struct FString InCommandString, struct FConsoleVariablesEditorAssetSaveData& OutValue, char ESearchCase SearchCase); // Function ConsoleVariablesEditorRuntime.ConsoleVariablesAsset.FindSavedDataByCommandString
	void ExecuteSavedCommands(struct UObject* WorldContextObject, bool bOnlyIncludeChecked); // Function ConsoleVariablesEditorRuntime.ConsoleVariablesAsset.ExecuteSavedCommands
	void CopyFrom(struct UConsoleVariablesAsset* InAssetToCopy); // Function ConsoleVariablesEditorRuntime.ConsoleVariablesAsset.CopyFrom
	void AddOrSetConsoleObjectSavedData(struct FConsoleVariablesEditorAssetSaveData& InData); // Function ConsoleVariablesEditorRuntime.ConsoleVariablesAsset.AddOrSetConsoleObjectSavedData
}; 



