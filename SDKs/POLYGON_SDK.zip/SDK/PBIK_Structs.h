#pragma once 
#include "SDK.h" 
 
 
// ScriptStruct PBIK.PBIKBoneSetting
// Size: 0x50(Inherited: 0x0) 
struct FPBIKBoneSetting
{
	struct FName bone;  // 0x0(0x8)
	float RotationStiffness;  // 0x8(0x4)
	float PositionStiffness;  // 0xC(0x4)
	uint8_t  X;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)
	float MinX;  // 0x14(0x4)
	float MaxX;  // 0x18(0x4)
	uint8_t  Y;  // 0x1C(0x1)
	char pad_29[3];  // 0x1D(0x3)
	float MinY;  // 0x20(0x4)
	float MaxY;  // 0x24(0x4)
	uint8_t  Z;  // 0x28(0x1)
	char pad_41[3];  // 0x29(0x3)
	float MinZ;  // 0x2C(0x4)
	float MaxZ;  // 0x30(0x4)
	char pad_52_1 : 7;  // 0x34(0x1)
	bool bUsePreferredAngles : 1;  // 0x34(0x1)
	char pad_53[3];  // 0x35(0x3)
	struct FVector PreferredAngles;  // 0x38(0x18)

}; 
// ScriptStruct PBIK.PBIKSolverSettings
// Size: 0x10(Inherited: 0x0) 
struct FPBIKSolverSettings
{
	int32_t Iterations;  // 0x0(0x4)
	float MassMultiplier;  // 0x4(0x4)
	float MinMassMultiplier;  // 0x8(0x4)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool bAllowStretch : 1;  // 0xC(0x1)
	uint8_t  RootBehavior;  // 0xD(0x1)
	char pad_14_1 : 7;  // 0xE(0x1)
	bool bStartSolveFromInputPose : 1;  // 0xE(0x1)
	char pad_15[1];  // 0xF(0x1)

}; 
// ScriptStruct PBIK.PBIKSolver
// Size: 0x68(Inherited: 0x0) 
struct FPBIKSolver
{
	char pad_0[104];  // 0x0(0x68)

}; 
// ScriptStruct PBIK.PBIKDebug
// Size: 0x8(Inherited: 0x0) 
struct FPBIKDebug
{
	float DrawScale;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool bDrawDebug : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)

}; 
// ScriptStruct PBIK.PBIKEffector
// Size: 0x90(Inherited: 0x0) 
struct FPBIKEffector
{
	struct FName bone;  // 0x0(0x8)
	char pad_8[8];  // 0x8(0x8)
	struct FTransform Transform;  // 0x10(0x60)
	float PositionAlpha;  // 0x70(0x4)
	float RotationAlpha;  // 0x74(0x4)
	float StrengthAlpha;  // 0x78(0x4)
	float PullChainAlpha;  // 0x7C(0x4)
	float PinRotation;  // 0x80(0x4)
	char pad_132[12];  // 0x84(0xC)

}; 
// ScriptStruct PBIK.RigUnit_PBIK
// Size: 0x130(Inherited: 0x40) 
struct FRigUnit_PBIK : public FRigUnit_HighlevelBaseMutable
{
	struct FName Root;  // 0x40(0x8)
	struct TArray<struct FPBIKEffector> Effectors;  // 0x48(0x10)
	struct TArray<int32_t> EffectorSolverIndices;  // 0x58(0x10)
	struct TArray<struct FPBIKBoneSetting> BoneSettings;  // 0x68(0x10)
	struct TArray<struct FName> ExcludedBones;  // 0x78(0x10)
	struct FPBIKSolverSettings Settings;  // 0x88(0x10)
	struct FPBIKDebug Debug;  // 0x98(0x8)
	struct TArray<int32_t> BoneSettingToSolverBoneIndex;  // 0xA0(0x10)
	struct TArray<int32_t> SolverBoneToElementIndex;  // 0xB0(0x10)
	struct FPBIKSolver Solver;  // 0xC0(0x68)
	char pad_296_1 : 7;  // 0x128(0x1)
	bool bNeedsInit : 1;  // 0x128(0x1)
	char pad_297[7];  // 0x129(0x7)

}; 
