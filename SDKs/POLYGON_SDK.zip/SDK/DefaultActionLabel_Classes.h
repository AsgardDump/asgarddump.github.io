#pragma once 
#include <DefaultActionLabel_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass DefaultActionLabel.DefaultActionLabel_C
// Size: 0x310(Inherited: 0x310) 
struct UDefaultActionLabel_C : public UActionLabel
{

}; 



