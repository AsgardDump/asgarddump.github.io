#pragma once 
#include <OpenCVHelper_Structs.h>
 
 
 
// Class OpenCVHelper.OpenCVBlueprintFunctionLibrary
// Size: 0x28(Inherited: 0x28) 
struct UOpenCVBlueprintFunctionLibrary : public UBlueprintFunctionLibrary
{

	int32_t OpenCVChessboardDetectCorners(struct UTextureRenderTarget2D* InRenderTarget, struct FIntPoint InPatternSize, bool bDebugDrawCorners, struct UTexture2D*& OutDebugTexture, struct TArray<struct FVector2D>& OutDetectedCorners); // Function OpenCVHelper.OpenCVBlueprintFunctionLibrary.OpenCVChessboardDetectCorners
	int32_t OpenCVArucoDetectMarkers(struct UTextureRenderTarget2D* InRenderTarget, uint8_t  InDictionary, uint8_t  InDictionarySize, bool bDebugDrawMarkers, bool bEstimatePose, float InMarkerLengthInMeters, struct FOpenCVLensDistortionParametersBase& InLensDistortionParameters, struct UTexture2D*& OutDebugTexture, struct TArray<struct FOpenCVArucoDetectedMarker>& OutDetectedMarkers); // Function OpenCVHelper.OpenCVBlueprintFunctionLibrary.OpenCVArucoDetectMarkers
}; 



