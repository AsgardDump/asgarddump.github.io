#pragma once 
#include <PlayFab_Structs.h>
 
 
 
// Class PlayFab.PlayFabUtilities
// Size: 0x28(Inherited: 0x28) 
struct UPlayFabUtilities : public UBlueprintFunctionLibrary
{

	void setPlayFabSettings(struct FString GameTitleId, struct FString PlayFabSecretApiKey, struct FString ProductionUrl, struct FString PhotonRealtimeAppId, struct FString PhotonTurnbasedAppId, struct FString PhotonChatAppId); // Function PlayFab.PlayFabUtilities.setPlayFabSettings
	struct FString getPhotonAppId(bool Realtime, bool Chat, bool Turnbased); // Function PlayFab.PlayFabUtilities.getPhotonAppId
	struct FString getErrorText(int32_t Code); // Function PlayFab.PlayFabUtilities.getErrorText
}; 



// Class PlayFab.PlayFabJsonObject
// Size: 0x38(Inherited: 0x28) 
struct UPlayFabJsonObject : public UObject
{
	char pad_40[16];  // 0x28(0x10)

	void SetStringField(struct FString FieldName, struct FString StringValue); // Function PlayFab.PlayFabJsonObject.SetStringField
	void SetStringArrayField(struct FString FieldName, struct TArray<struct FString>& StringArray); // Function PlayFab.PlayFabJsonObject.SetStringArrayField
	void SetObjectField(struct FString FieldName, struct UPlayFabJsonObject* JsonObject); // Function PlayFab.PlayFabJsonObject.SetObjectField
	void SetObjectArrayField(struct FString FieldName, struct TArray<struct UPlayFabJsonObject*>& ObjectArray); // Function PlayFab.PlayFabJsonObject.SetObjectArrayField
	void SetNumberField(struct FString FieldName, float Number); // Function PlayFab.PlayFabJsonObject.SetNumberField
	void SetNumberArrayField(struct FString FieldName, struct TArray<float>& NumberArray); // Function PlayFab.PlayFabJsonObject.SetNumberArrayField
	void SetFieldNull(struct FString FieldName); // Function PlayFab.PlayFabJsonObject.SetFieldNull
	void SetField(struct FString FieldName, struct UPlayFabJsonValue* JsonValue); // Function PlayFab.PlayFabJsonObject.SetField
	void SetBoolField(struct FString FieldName, bool InValue); // Function PlayFab.PlayFabJsonObject.SetBoolField
	void SetBoolArrayField(struct FString FieldName, struct TArray<bool>& BoolArray); // Function PlayFab.PlayFabJsonObject.SetBoolArrayField
	void SetArrayField(struct FString FieldName, struct TArray<struct UPlayFabJsonValue*>& inArray); // Function PlayFab.PlayFabJsonObject.SetArrayField
	void Reset(); // Function PlayFab.PlayFabJsonObject.Reset
	void RemoveField(struct FString FieldName); // Function PlayFab.PlayFabJsonObject.RemoveField
	void MergeJsonObject(struct UPlayFabJsonObject* InJsonObject, bool Overwrite); // Function PlayFab.PlayFabJsonObject.MergeJsonObject
	bool HasField(struct FString FieldName); // Function PlayFab.PlayFabJsonObject.HasField
	struct FString GetStringField(struct FString FieldName); // Function PlayFab.PlayFabJsonObject.GetStringField
	struct TArray<struct FString> GetStringArrayField(struct FString FieldName); // Function PlayFab.PlayFabJsonObject.GetStringArrayField
	struct UPlayFabJsonObject* GetObjectField(struct FString FieldName); // Function PlayFab.PlayFabJsonObject.GetObjectField
	struct TArray<struct UPlayFabJsonObject*> GetObjectArrayField(struct FString FieldName); // Function PlayFab.PlayFabJsonObject.GetObjectArrayField
	float GetNumberField(struct FString FieldName); // Function PlayFab.PlayFabJsonObject.GetNumberField
	struct TArray<float> GetNumberArrayField(struct FString FieldName); // Function PlayFab.PlayFabJsonObject.GetNumberArrayField
	struct TArray<struct FString> GetFieldNames(); // Function PlayFab.PlayFabJsonObject.GetFieldNames
	struct UPlayFabJsonValue* GetField(struct FString FieldName); // Function PlayFab.PlayFabJsonObject.GetField
	bool GetBoolField(struct FString FieldName); // Function PlayFab.PlayFabJsonObject.GetBoolField
	struct TArray<bool> GetBoolArrayField(struct FString FieldName); // Function PlayFab.PlayFabJsonObject.GetBoolArrayField
	struct TArray<struct UPlayFabJsonValue*> GetArrayField(struct FString FieldName); // Function PlayFab.PlayFabJsonObject.GetArrayField
	struct FString EncodeJson(); // Function PlayFab.PlayFabJsonObject.EncodeJson
	bool DecodeJson(struct FString JsonString); // Function PlayFab.PlayFabJsonObject.DecodeJson
	struct UPlayFabJsonObject* ConstructJsonObject(struct UObject* WorldContextObject); // Function PlayFab.PlayFabJsonObject.ConstructJsonObject
}; 



// Class PlayFab.PlayFabAdminAPI
// Size: 0x820(Inherited: 0x30) 
struct UPlayFabAdminAPI : public UOnlineBlueprintCallProxyBase
{
	struct FMulticastInlineDelegate OnPlayFabResponse;  // 0x30(0x10)
	char pad_64[1912];  // 0x40(0x778)
	struct UPlayFabAuthenticationContext* CallAuthenticationContext;  // 0x7B8(0x8)
	struct UPlayFabJsonObject* RequestJsonObj;  // 0x7C0(0x8)
	struct UPlayFabJsonObject* ResponseJsonObj;  // 0x7C8(0x8)
	char pad_2000[80];  // 0x7D0(0x50)

	struct UPlayFabAdminAPI* UpdateUserTitleDisplayName(struct FAdminUpdateUserTitleDisplayNameRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.UpdateUserTitleDisplayName
	struct UPlayFabAdminAPI* UpdateUserReadOnlyData(struct FAdminUpdateUserDataRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.UpdateUserReadOnlyData
	struct UPlayFabAdminAPI* UpdateUserPublisherReadOnlyData(struct FAdminUpdateUserDataRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.UpdateUserPublisherReadOnlyData
	struct UPlayFabAdminAPI* UpdateUserPublisherInternalData(struct FAdminUpdateUserInternalDataRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.UpdateUserPublisherInternalData
	struct UPlayFabAdminAPI* UpdateUserPublisherData(struct FAdminUpdateUserDataRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.UpdateUserPublisherData
	struct UPlayFabAdminAPI* UpdateUserInternalData(struct FAdminUpdateUserInternalDataRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.UpdateUserInternalData
	struct UPlayFabAdminAPI* UpdateUserData(struct FAdminUpdateUserDataRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.UpdateUserData
	struct UPlayFabAdminAPI* UpdateTask(struct FAdminUpdateTaskRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.UpdateTask
	struct UPlayFabAdminAPI* UpdateStoreItems(struct FAdminUpdateStoreItemsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.UpdateStoreItems
	struct UPlayFabAdminAPI* UpdateSegment(struct FAdminUpdateSegmentRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.UpdateSegment
	struct UPlayFabAdminAPI* UpdateRandomResultTables(struct FAdminUpdateRandomResultTablesRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.UpdateRandomResultTables
	struct UPlayFabAdminAPI* UpdatePolicy(struct FAdminUpdatePolicyRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.UpdatePolicy
	struct UPlayFabAdminAPI* UpdatePlayerStatisticDefinition(struct FAdminUpdatePlayerStatisticDefinitionRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.UpdatePlayerStatisticDefinition
	struct UPlayFabAdminAPI* UpdatePlayerSharedSecret(struct FAdminUpdatePlayerSharedSecretRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.UpdatePlayerSharedSecret
	struct UPlayFabAdminAPI* UpdateOpenIdConnection(struct FAdminUpdateOpenIdConnectionRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.UpdateOpenIdConnection
	struct UPlayFabAdminAPI* UpdateCloudScript(struct FAdminUpdateCloudScriptRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.UpdateCloudScript
	struct UPlayFabAdminAPI* UpdateCatalogItems(struct FAdminUpdateCatalogItemsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.UpdateCatalogItems
	struct UPlayFabAdminAPI* UpdateBans(struct FAdminUpdateBansRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.UpdateBans
	struct UPlayFabAdminAPI* SubtractUserVirtualCurrency(struct FAdminSubtractUserVirtualCurrencyRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.SubtractUserVirtualCurrency
	struct UPlayFabAdminAPI* SetupPushNotification(struct FAdminSetupPushNotificationRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.SetupPushNotification
	struct UPlayFabAdminAPI* SetTitleInternalData(struct FAdminSetTitleDataRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.SetTitleInternalData
	struct UPlayFabAdminAPI* SetTitleDataAndOverrides(struct FAdminSetTitleDataAndOverridesRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.SetTitleDataAndOverrides
	struct UPlayFabAdminAPI* SetTitleData(struct FAdminSetTitleDataRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.SetTitleData
	struct UPlayFabAdminAPI* SetStoreItems(struct FAdminUpdateStoreItemsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.SetStoreItems
	struct UPlayFabAdminAPI* SetPublisherData(struct FAdminSetPublisherDataRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.SetPublisherData
	struct UPlayFabAdminAPI* SetPublishedRevision(struct FAdminSetPublishedRevisionRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.SetPublishedRevision
	struct UPlayFabAdminAPI* SetPlayerSecret(struct FAdminSetPlayerSecretRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.SetPlayerSecret
	struct UPlayFabAdminAPI* SetMembershipOverride(struct FAdminSetMembershipOverrideRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.SetMembershipOverride
	struct UPlayFabAdminAPI* SetCatalogItems(struct FAdminUpdateCatalogItemsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.SetCatalogItems
	struct UPlayFabAdminAPI* SendAccountRecoveryEmail(struct FAdminSendAccountRecoveryEmailRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.SendAccountRecoveryEmail
	struct UPlayFabAdminAPI* RunTask(struct FAdminRunTaskRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.RunTask
	struct UPlayFabAdminAPI* RevokeInventoryItems(struct FAdminRevokeInventoryItemsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.RevokeInventoryItems
	struct UPlayFabAdminAPI* RevokeInventoryItem(struct FAdminRevokeInventoryItemRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.RevokeInventoryItem
	struct UPlayFabAdminAPI* RevokeBans(struct FAdminRevokeBansRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.RevokeBans
	struct UPlayFabAdminAPI* RevokeAllBansForUser(struct FAdminRevokeAllBansForUserRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.RevokeAllBansForUser
	struct UPlayFabAdminAPI* ResolvePurchaseDispute(struct FAdminResolvePurchaseDisputeRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.ResolvePurchaseDispute
	struct UPlayFabAdminAPI* ResetUserStatistics(struct FAdminResetUserStatisticsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.ResetUserStatistics
	struct UPlayFabAdminAPI* ResetPassword(struct FAdminResetPasswordRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.ResetPassword
	struct UPlayFabAdminAPI* ResetCharacterStatistics(struct FAdminResetCharacterStatisticsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.ResetCharacterStatistics
	struct UPlayFabAdminAPI* RemoveVirtualCurrencyTypes(struct FAdminRemoveVirtualCurrencyTypesRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.RemoveVirtualCurrencyTypes
	struct UPlayFabAdminAPI* RemovePlayerTag(struct FAdminRemovePlayerTagRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.RemovePlayerTag
	struct UPlayFabAdminAPI* RefundPurchase(struct FAdminRefundPurchaseRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.RefundPurchase
	struct UPlayFabAdminAPI* ModifyServerBuild(struct FAdminModifyServerBuildRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.ModifyServerBuild
	struct UPlayFabAdminAPI* ListVirtualCurrencyTypes(struct FAdminListVirtualCurrencyTypesRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.ListVirtualCurrencyTypes
	struct UPlayFabAdminAPI* ListOpenIdConnection(struct FAdminListOpenIdConnectionRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.ListOpenIdConnection
	struct UPlayFabAdminAPI* IncrementPlayerStatisticVersion(struct FAdminIncrementPlayerStatisticVersionRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.IncrementPlayerStatisticVersion
	struct UPlayFabAdminAPI* IncrementLimitedEditionItemAvailability(struct FAdminIncrementLimitedEditionItemAvailabilityRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.IncrementLimitedEditionItemAvailability
	void HelperUpdateUserTitleDisplayName(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperUpdateUserTitleDisplayName
	void HelperUpdateUserReadOnlyData(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperUpdateUserReadOnlyData
	void HelperUpdateUserPublisherReadOnlyData(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperUpdateUserPublisherReadOnlyData
	void HelperUpdateUserPublisherInternalData(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperUpdateUserPublisherInternalData
	void HelperUpdateUserPublisherData(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperUpdateUserPublisherData
	void HelperUpdateUserInternalData(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperUpdateUserInternalData
	void HelperUpdateUserData(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperUpdateUserData
	void HelperUpdateTask(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperUpdateTask
	void HelperUpdateStoreItems(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperUpdateStoreItems
	void HelperUpdateSegment(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperUpdateSegment
	void HelperUpdateRandomResultTables(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperUpdateRandomResultTables
	void HelperUpdatePolicy(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperUpdatePolicy
	void HelperUpdatePlayerStatisticDefinition(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperUpdatePlayerStatisticDefinition
	void HelperUpdatePlayerSharedSecret(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperUpdatePlayerSharedSecret
	void HelperUpdateOpenIdConnection(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperUpdateOpenIdConnection
	void HelperUpdateCloudScript(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperUpdateCloudScript
	void HelperUpdateCatalogItems(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperUpdateCatalogItems
	void HelperUpdateBans(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperUpdateBans
	void HelperSubtractUserVirtualCurrency(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperSubtractUserVirtualCurrency
	void HelperSetupPushNotification(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperSetupPushNotification
	void HelperSetTitleInternalData(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperSetTitleInternalData
	void HelperSetTitleDataAndOverrides(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperSetTitleDataAndOverrides
	void HelperSetTitleData(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperSetTitleData
	void HelperSetStoreItems(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperSetStoreItems
	void HelperSetPublisherData(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperSetPublisherData
	void HelperSetPublishedRevision(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperSetPublishedRevision
	void HelperSetPlayerSecret(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperSetPlayerSecret
	void HelperSetMembershipOverride(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperSetMembershipOverride
	void HelperSetCatalogItems(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperSetCatalogItems
	void HelperSendAccountRecoveryEmail(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperSendAccountRecoveryEmail
	void HelperRunTask(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperRunTask
	void HelperRevokeInventoryItems(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperRevokeInventoryItems
	void HelperRevokeInventoryItem(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperRevokeInventoryItem
	void HelperRevokeBans(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperRevokeBans
	void HelperRevokeAllBansForUser(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperRevokeAllBansForUser
	void HelperResolvePurchaseDispute(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperResolvePurchaseDispute
	void HelperResetUserStatistics(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperResetUserStatistics
	void HelperResetPassword(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperResetPassword
	void HelperResetCharacterStatistics(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperResetCharacterStatistics
	void HelperRemoveVirtualCurrencyTypes(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperRemoveVirtualCurrencyTypes
	void HelperRemovePlayerTag(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperRemovePlayerTag
	void HelperRefundPurchase(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperRefundPurchase
	void HelperModifyServerBuild(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperModifyServerBuild
	void HelperListVirtualCurrencyTypes(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperListVirtualCurrencyTypes
	void HelperListOpenIdConnection(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperListOpenIdConnection
	void HelperIncrementPlayerStatisticVersion(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperIncrementPlayerStatisticVersion
	void HelperIncrementLimitedEditionItemAvailability(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperIncrementLimitedEditionItemAvailability
	void HelperGrantItemsToUsers(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperGrantItemsToUsers
	void HelperGetUserReadOnlyData(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperGetUserReadOnlyData
	void HelperGetUserPublisherReadOnlyData(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperGetUserPublisherReadOnlyData
	void HelperGetUserPublisherInternalData(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperGetUserPublisherInternalData
	void HelperGetUserPublisherData(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperGetUserPublisherData
	void HelperGetUserInventory(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperGetUserInventory
	void HelperGetUserInternalData(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperGetUserInternalData
	void HelperGetUserData(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperGetUserData
	void HelperGetUserBans(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperGetUserBans
	void HelperGetUserAccountInfo(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperGetUserAccountInfo
	void HelperGetTitleInternalData(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperGetTitleInternalData
	void HelperGetTitleData(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperGetTitleData
	void HelperGetTasks(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperGetTasks
	void HelperGetTaskInstances(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperGetTaskInstances
	void HelperGetStoreItems(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperGetStoreItems
	void HelperGetSegments(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperGetSegments
	void HelperGetSegmentExport(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperGetSegmentExport
	void HelperGetRandomResultTables(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperGetRandomResultTables
	void HelperGetPublisherData(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperGetPublisherData
	void HelperGetPolicy(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperGetPolicy
	void HelperGetPlayerTags(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperGetPlayerTags
	void HelperGetPlayerStatisticVersions(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperGetPlayerStatisticVersions
	void HelperGetPlayerStatisticDefinitions(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperGetPlayerStatisticDefinitions
	void HelperGetPlayersInSegment(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperGetPlayersInSegment
	void HelperGetPlayerSharedSecrets(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperGetPlayerSharedSecrets
	void HelperGetPlayerSegments(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperGetPlayerSegments
	void HelperGetPlayerProfile(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperGetPlayerProfile
	void HelperGetPlayerIdFromAuthToken(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperGetPlayerIdFromAuthToken
	void HelperGetPlayedTitleList(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperGetPlayedTitleList
	void HelperGetMatchmakerGameModes(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperGetMatchmakerGameModes
	void HelperGetMatchmakerGameInfo(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperGetMatchmakerGameInfo
	void HelperGetDataReport(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperGetDataReport
	void HelperGetContentUploadUrl(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperGetContentUploadUrl
	void HelperGetContentList(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperGetContentList
	void HelperGetCloudScriptVersions(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperGetCloudScriptVersions
	void HelperGetCloudScriptTaskInstance(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperGetCloudScriptTaskInstance
	void HelperGetCloudScriptRevision(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperGetCloudScriptRevision
	void HelperGetCatalogItems(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperGetCatalogItems
	void HelperGetAllSegments(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperGetAllSegments
	void HelperGetActionsOnPlayersInSegmentTaskInstance(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperGetActionsOnPlayersInSegmentTaskInstance
	void HelperExportPlayersInSegment(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperExportPlayersInSegment
	void HelperExportMasterPlayerData(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperExportMasterPlayerData
	void HelperDeleteTitleDataOverride(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperDeleteTitleDataOverride
	void HelperDeleteTitle(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperDeleteTitle
	void HelperDeleteTask(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperDeleteTask
	void HelperDeleteStore(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperDeleteStore
	void HelperDeleteSegment(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperDeleteSegment
	void HelperDeletePlayerSharedSecret(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperDeletePlayerSharedSecret
	void HelperDeletePlayer(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperDeletePlayer
	void HelperDeleteOpenIdConnection(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperDeleteOpenIdConnection
	void HelperDeleteMembershipSubscription(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperDeleteMembershipSubscription
	void HelperDeleteMasterPlayerAccount(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperDeleteMasterPlayerAccount
	void HelperDeleteContent(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperDeleteContent
	void HelperCreateSegment(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperCreateSegment
	void HelperCreatePlayerStatisticDefinition(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperCreatePlayerStatisticDefinition
	void HelperCreatePlayerSharedSecret(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperCreatePlayerSharedSecret
	void HelperCreateOpenIdConnection(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperCreateOpenIdConnection
	void HelperCreateInsightsScheduledScalingTask(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperCreateInsightsScheduledScalingTask
	void HelperCreateCloudScriptTask(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperCreateCloudScriptTask
	void HelperCreateActionsOnPlayersInSegmentTask(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperCreateActionsOnPlayersInSegmentTask
	void HelperCheckLimitedEditionItemAvailability(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperCheckLimitedEditionItemAvailability
	void HelperBanUsers(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperBanUsers
	void HelperAddVirtualCurrencyTypes(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperAddVirtualCurrencyTypes
	void HelperAddUserVirtualCurrency(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperAddUserVirtualCurrency
	void HelperAddPlayerTag(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperAddPlayerTag
	void HelperAddNews(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperAddNews
	void HelperAddLocalizedNews(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperAddLocalizedNews
	void HelperAbortTaskInstance(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAdminAPI.HelperAbortTaskInstance
	struct UPlayFabAdminAPI* GrantItemsToUsers(struct FAdminGrantItemsToUsersRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.GrantItemsToUsers
	struct UPlayFabAdminAPI* GetUserReadOnlyData(struct FAdminGetUserDataRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.GetUserReadOnlyData
	struct UPlayFabAdminAPI* GetUserPublisherReadOnlyData(struct FAdminGetUserDataRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.GetUserPublisherReadOnlyData
	struct UPlayFabAdminAPI* GetUserPublisherInternalData(struct FAdminGetUserDataRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.GetUserPublisherInternalData
	struct UPlayFabAdminAPI* GetUserPublisherData(struct FAdminGetUserDataRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.GetUserPublisherData
	struct UPlayFabAdminAPI* GetUserInventory(struct FAdminGetUserInventoryRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.GetUserInventory
	struct UPlayFabAdminAPI* GetUserInternalData(struct FAdminGetUserDataRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.GetUserInternalData
	struct UPlayFabAdminAPI* GetUserData(struct FAdminGetUserDataRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.GetUserData
	struct UPlayFabAdminAPI* GetUserBans(struct FAdminGetUserBansRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.GetUserBans
	struct UPlayFabAdminAPI* GetUserAccountInfo(struct FAdminLookupUserAccountInfoRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.GetUserAccountInfo
	struct UPlayFabAdminAPI* GetTitleInternalData(struct FAdminGetTitleDataRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.GetTitleInternalData
	struct UPlayFabAdminAPI* GetTitleData(struct FAdminGetTitleDataRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.GetTitleData
	struct UPlayFabAdminAPI* GetTasks(struct FAdminGetTasksRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.GetTasks
	struct UPlayFabAdminAPI* GetTaskInstances(struct FAdminGetTaskInstancesRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.GetTaskInstances
	struct UPlayFabAdminAPI* GetStoreItems(struct FAdminGetStoreItemsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.GetStoreItems
	struct UPlayFabAdminAPI* GetSegments(struct FAdminGetSegmentsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.GetSegments
	struct UPlayFabAdminAPI* GetSegmentExport(struct FAdminGetPlayersInSegmentExportRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.GetSegmentExport
	struct UPlayFabAdminAPI* GetRandomResultTables(struct FAdminGetRandomResultTablesRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.GetRandomResultTables
	struct UPlayFabAdminAPI* GetPublisherData(struct FAdminGetPublisherDataRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.GetPublisherData
	struct UPlayFabAdminAPI* GetPolicy(struct FAdminGetPolicyRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.GetPolicy
	struct UPlayFabAdminAPI* GetPlayerTags(struct FAdminGetPlayerTagsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.GetPlayerTags
	struct UPlayFabAdminAPI* GetPlayerStatisticVersions(struct FAdminGetPlayerStatisticVersionsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.GetPlayerStatisticVersions
	struct UPlayFabAdminAPI* GetPlayerStatisticDefinitions(struct FAdminGetPlayerStatisticDefinitionsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.GetPlayerStatisticDefinitions
	struct UPlayFabAdminAPI* GetPlayersInSegment(struct FAdminGetPlayersInSegmentRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.GetPlayersInSegment
	struct UPlayFabAdminAPI* GetPlayerSharedSecrets(struct FAdminGetPlayerSharedSecretsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.GetPlayerSharedSecrets
	struct UPlayFabAdminAPI* GetPlayerSegments(struct FAdminGetPlayersSegmentsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.GetPlayerSegments
	struct UPlayFabAdminAPI* GetPlayerProfile(struct FAdminGetPlayerProfileRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.GetPlayerProfile
	struct UPlayFabAdminAPI* GetPlayerIdFromAuthToken(struct FAdminGetPlayerIdFromAuthTokenRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.GetPlayerIdFromAuthToken
	struct UPlayFabAdminAPI* GetPlayedTitleList(struct FAdminGetPlayedTitleListRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.GetPlayedTitleList
	struct UPlayFabAdminAPI* GetMatchmakerGameModes(struct FAdminGetMatchmakerGameModesRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.GetMatchmakerGameModes
	struct UPlayFabAdminAPI* GetMatchmakerGameInfo(struct FAdminGetMatchmakerGameInfoRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.GetMatchmakerGameInfo
	struct UPlayFabAdminAPI* GetDataReport(struct FAdminGetDataReportRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.GetDataReport
	struct UPlayFabAdminAPI* GetContentUploadUrl(struct FAdminGetContentUploadUrlRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.GetContentUploadUrl
	struct UPlayFabAdminAPI* GetContentList(struct FAdminGetContentListRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.GetContentList
	struct UPlayFabAdminAPI* GetCloudScriptVersions(struct FAdminGetCloudScriptVersionsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.GetCloudScriptVersions
	struct UPlayFabAdminAPI* GetCloudScriptTaskInstance(struct FAdminGetTaskInstanceRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.GetCloudScriptTaskInstance
	struct UPlayFabAdminAPI* GetCloudScriptRevision(struct FAdminGetCloudScriptRevisionRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.GetCloudScriptRevision
	struct UPlayFabAdminAPI* GetCatalogItems(struct FAdminGetCatalogItemsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.GetCatalogItems
	struct UPlayFabAdminAPI* GetAllSegments(struct FAdminGetAllSegmentsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.GetAllSegments
	struct UPlayFabAdminAPI* GetActionsOnPlayersInSegmentTaskInstance(struct FAdminGetTaskInstanceRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.GetActionsOnPlayersInSegmentTaskInstance
	struct UPlayFabAdminAPI* ExportPlayersInSegment(struct FAdminExportPlayersInSegmentRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.ExportPlayersInSegment
	struct UPlayFabAdminAPI* ExportMasterPlayerData(struct FAdminExportMasterPlayerDataRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.ExportMasterPlayerData
	struct UPlayFabAdminAPI* DeleteTitleDataOverride(struct FAdminDeleteTitleDataOverrideRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.DeleteTitleDataOverride
	struct UPlayFabAdminAPI* DeleteTitle(struct FAdminDeleteTitleRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.DeleteTitle
	struct UPlayFabAdminAPI* DeleteTask(struct FAdminDeleteTaskRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.DeleteTask
	struct UPlayFabAdminAPI* DeleteStore(struct FAdminDeleteStoreRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.DeleteStore
	struct UPlayFabAdminAPI* DeleteSegment(struct FAdminDeleteSegmentRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.DeleteSegment
	struct UPlayFabAdminAPI* DeletePlayerSharedSecret(struct FAdminDeletePlayerSharedSecretRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.DeletePlayerSharedSecret
	struct UPlayFabAdminAPI* DeletePlayer(struct FAdminDeletePlayerRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.DeletePlayer
	struct UPlayFabAdminAPI* DeleteOpenIdConnection(struct FAdminDeleteOpenIdConnectionRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.DeleteOpenIdConnection
	struct UPlayFabAdminAPI* DeleteMembershipSubscription(struct FAdminDeleteMembershipSubscriptionRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.DeleteMembershipSubscription
	struct UPlayFabAdminAPI* DeleteMasterPlayerAccount(struct FAdminDeleteMasterPlayerAccountRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.DeleteMasterPlayerAccount
	struct UPlayFabAdminAPI* DeleteContent(struct FAdminDeleteContentRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.DeleteContent
	void DelegateOnSuccessUpdateUserTitleDisplayName__DelegateSignature(struct FAdminUpdateUserTitleDisplayNameResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessUpdateUserTitleDisplayName__DelegateSignature
	void DelegateOnSuccessUpdateUserReadOnlyData__DelegateSignature(struct FAdminUpdateUserDataResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessUpdateUserReadOnlyData__DelegateSignature
	void DelegateOnSuccessUpdateUserPublisherReadOnlyData__DelegateSignature(struct FAdminUpdateUserDataResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessUpdateUserPublisherReadOnlyData__DelegateSignature
	void DelegateOnSuccessUpdateUserPublisherInternalData__DelegateSignature(struct FAdminUpdateUserDataResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessUpdateUserPublisherInternalData__DelegateSignature
	void DelegateOnSuccessUpdateUserPublisherData__DelegateSignature(struct FAdminUpdateUserDataResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessUpdateUserPublisherData__DelegateSignature
	void DelegateOnSuccessUpdateUserInternalData__DelegateSignature(struct FAdminUpdateUserDataResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessUpdateUserInternalData__DelegateSignature
	void DelegateOnSuccessUpdateUserData__DelegateSignature(struct FAdminUpdateUserDataResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessUpdateUserData__DelegateSignature
	void DelegateOnSuccessUpdateTask__DelegateSignature(struct FAdminEmptyResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessUpdateTask__DelegateSignature
	void DelegateOnSuccessUpdateStoreItems__DelegateSignature(struct FAdminUpdateStoreItemsResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessUpdateStoreItems__DelegateSignature
	void DelegateOnSuccessUpdateSegment__DelegateSignature(struct FAdminUpdateSegmentResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessUpdateSegment__DelegateSignature
	void DelegateOnSuccessUpdateRandomResultTables__DelegateSignature(struct FAdminUpdateRandomResultTablesResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessUpdateRandomResultTables__DelegateSignature
	void DelegateOnSuccessUpdatePolicy__DelegateSignature(struct FAdminUpdatePolicyResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessUpdatePolicy__DelegateSignature
	void DelegateOnSuccessUpdatePlayerStatisticDefinition__DelegateSignature(struct FAdminUpdatePlayerStatisticDefinitionResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessUpdatePlayerStatisticDefinition__DelegateSignature
	void DelegateOnSuccessUpdatePlayerSharedSecret__DelegateSignature(struct FAdminUpdatePlayerSharedSecretResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessUpdatePlayerSharedSecret__DelegateSignature
	void DelegateOnSuccessUpdateOpenIdConnection__DelegateSignature(struct FAdminEmptyResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessUpdateOpenIdConnection__DelegateSignature
	void DelegateOnSuccessUpdateCloudScript__DelegateSignature(struct FAdminUpdateCloudScriptResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessUpdateCloudScript__DelegateSignature
	void DelegateOnSuccessUpdateCatalogItems__DelegateSignature(struct FAdminUpdateCatalogItemsResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessUpdateCatalogItems__DelegateSignature
	void DelegateOnSuccessUpdateBans__DelegateSignature(struct FAdminUpdateBansResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessUpdateBans__DelegateSignature
	void DelegateOnSuccessSubtractUserVirtualCurrency__DelegateSignature(struct FAdminModifyUserVirtualCurrencyResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessSubtractUserVirtualCurrency__DelegateSignature
	void DelegateOnSuccessSetupPushNotification__DelegateSignature(struct FAdminSetupPushNotificationResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessSetupPushNotification__DelegateSignature
	void DelegateOnSuccessSetTitleInternalData__DelegateSignature(struct FAdminSetTitleDataResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessSetTitleInternalData__DelegateSignature
	void DelegateOnSuccessSetTitleDataAndOverrides__DelegateSignature(struct FAdminSetTitleDataAndOverridesResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessSetTitleDataAndOverrides__DelegateSignature
	void DelegateOnSuccessSetTitleData__DelegateSignature(struct FAdminSetTitleDataResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessSetTitleData__DelegateSignature
	void DelegateOnSuccessSetStoreItems__DelegateSignature(struct FAdminUpdateStoreItemsResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessSetStoreItems__DelegateSignature
	void DelegateOnSuccessSetPublisherData__DelegateSignature(struct FAdminSetPublisherDataResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessSetPublisherData__DelegateSignature
	void DelegateOnSuccessSetPublishedRevision__DelegateSignature(struct FAdminSetPublishedRevisionResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessSetPublishedRevision__DelegateSignature
	void DelegateOnSuccessSetPlayerSecret__DelegateSignature(struct FAdminSetPlayerSecretResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessSetPlayerSecret__DelegateSignature
	void DelegateOnSuccessSetMembershipOverride__DelegateSignature(struct FAdminSetMembershipOverrideResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessSetMembershipOverride__DelegateSignature
	void DelegateOnSuccessSetCatalogItems__DelegateSignature(struct FAdminUpdateCatalogItemsResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessSetCatalogItems__DelegateSignature
	void DelegateOnSuccessSendAccountRecoveryEmail__DelegateSignature(struct FAdminSendAccountRecoveryEmailResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessSendAccountRecoveryEmail__DelegateSignature
	void DelegateOnSuccessRunTask__DelegateSignature(struct FAdminRunTaskResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessRunTask__DelegateSignature
	void DelegateOnSuccessRevokeInventoryItems__DelegateSignature(struct FAdminRevokeInventoryItemsResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessRevokeInventoryItems__DelegateSignature
	void DelegateOnSuccessRevokeInventoryItem__DelegateSignature(struct FAdminRevokeInventoryResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessRevokeInventoryItem__DelegateSignature
	void DelegateOnSuccessRevokeBans__DelegateSignature(struct FAdminRevokeBansResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessRevokeBans__DelegateSignature
	void DelegateOnSuccessRevokeAllBansForUser__DelegateSignature(struct FAdminRevokeAllBansForUserResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessRevokeAllBansForUser__DelegateSignature
	void DelegateOnSuccessResolvePurchaseDispute__DelegateSignature(struct FAdminResolvePurchaseDisputeResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessResolvePurchaseDispute__DelegateSignature
	void DelegateOnSuccessResetUserStatistics__DelegateSignature(struct FAdminResetUserStatisticsResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessResetUserStatistics__DelegateSignature
	void DelegateOnSuccessResetPassword__DelegateSignature(struct FAdminResetPasswordResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessResetPassword__DelegateSignature
	void DelegateOnSuccessResetCharacterStatistics__DelegateSignature(struct FAdminResetCharacterStatisticsResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessResetCharacterStatistics__DelegateSignature
	void DelegateOnSuccessRemoveVirtualCurrencyTypes__DelegateSignature(struct FAdminBlankResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessRemoveVirtualCurrencyTypes__DelegateSignature
	void DelegateOnSuccessRemovePlayerTag__DelegateSignature(struct FAdminRemovePlayerTagResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessRemovePlayerTag__DelegateSignature
	void DelegateOnSuccessRefundPurchase__DelegateSignature(struct FAdminRefundPurchaseResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessRefundPurchase__DelegateSignature
	void DelegateOnSuccessModifyServerBuild__DelegateSignature(struct FAdminModifyServerBuildResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessModifyServerBuild__DelegateSignature
	void DelegateOnSuccessListVirtualCurrencyTypes__DelegateSignature(struct FAdminListVirtualCurrencyTypesResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessListVirtualCurrencyTypes__DelegateSignature
	void DelegateOnSuccessListOpenIdConnection__DelegateSignature(struct FAdminListOpenIdConnectionResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessListOpenIdConnection__DelegateSignature
	void DelegateOnSuccessIncrementPlayerStatisticVersion__DelegateSignature(struct FAdminIncrementPlayerStatisticVersionResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessIncrementPlayerStatisticVersion__DelegateSignature
	void DelegateOnSuccessIncrementLimitedEditionItemAvailability__DelegateSignature(struct FAdminIncrementLimitedEditionItemAvailabilityResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessIncrementLimitedEditionItemAvailability__DelegateSignature
	void DelegateOnSuccessGrantItemsToUsers__DelegateSignature(struct FAdminGrantItemsToUsersResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessGrantItemsToUsers__DelegateSignature
	void DelegateOnSuccessGetUserReadOnlyData__DelegateSignature(struct FAdminGetUserDataResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessGetUserReadOnlyData__DelegateSignature
	void DelegateOnSuccessGetUserPublisherReadOnlyData__DelegateSignature(struct FAdminGetUserDataResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessGetUserPublisherReadOnlyData__DelegateSignature
	void DelegateOnSuccessGetUserPublisherInternalData__DelegateSignature(struct FAdminGetUserDataResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessGetUserPublisherInternalData__DelegateSignature
	void DelegateOnSuccessGetUserPublisherData__DelegateSignature(struct FAdminGetUserDataResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessGetUserPublisherData__DelegateSignature
	void DelegateOnSuccessGetUserInventory__DelegateSignature(struct FAdminGetUserInventoryResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessGetUserInventory__DelegateSignature
	void DelegateOnSuccessGetUserInternalData__DelegateSignature(struct FAdminGetUserDataResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessGetUserInternalData__DelegateSignature
	void DelegateOnSuccessGetUserData__DelegateSignature(struct FAdminGetUserDataResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessGetUserData__DelegateSignature
	void DelegateOnSuccessGetUserBans__DelegateSignature(struct FAdminGetUserBansResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessGetUserBans__DelegateSignature
	void DelegateOnSuccessGetUserAccountInfo__DelegateSignature(struct FAdminLookupUserAccountInfoResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessGetUserAccountInfo__DelegateSignature
	void DelegateOnSuccessGetTitleInternalData__DelegateSignature(struct FAdminGetTitleDataResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessGetTitleInternalData__DelegateSignature
	void DelegateOnSuccessGetTitleData__DelegateSignature(struct FAdminGetTitleDataResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessGetTitleData__DelegateSignature
	void DelegateOnSuccessGetTasks__DelegateSignature(struct FAdminGetTasksResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessGetTasks__DelegateSignature
	void DelegateOnSuccessGetTaskInstances__DelegateSignature(struct FAdminGetTaskInstancesResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessGetTaskInstances__DelegateSignature
	void DelegateOnSuccessGetStoreItems__DelegateSignature(struct FAdminGetStoreItemsResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessGetStoreItems__DelegateSignature
	void DelegateOnSuccessGetSegments__DelegateSignature(struct FAdminGetSegmentsResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessGetSegments__DelegateSignature
	void DelegateOnSuccessGetSegmentExport__DelegateSignature(struct FAdminGetPlayersInSegmentExportResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessGetSegmentExport__DelegateSignature
	void DelegateOnSuccessGetRandomResultTables__DelegateSignature(struct FAdminGetRandomResultTablesResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessGetRandomResultTables__DelegateSignature
	void DelegateOnSuccessGetPublisherData__DelegateSignature(struct FAdminGetPublisherDataResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessGetPublisherData__DelegateSignature
	void DelegateOnSuccessGetPolicy__DelegateSignature(struct FAdminGetPolicyResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessGetPolicy__DelegateSignature
	void DelegateOnSuccessGetPlayerTags__DelegateSignature(struct FAdminGetPlayerTagsResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessGetPlayerTags__DelegateSignature
	void DelegateOnSuccessGetPlayerStatisticVersions__DelegateSignature(struct FAdminGetPlayerStatisticVersionsResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessGetPlayerStatisticVersions__DelegateSignature
	void DelegateOnSuccessGetPlayerStatisticDefinitions__DelegateSignature(struct FAdminGetPlayerStatisticDefinitionsResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessGetPlayerStatisticDefinitions__DelegateSignature
	void DelegateOnSuccessGetPlayersInSegment__DelegateSignature(struct FAdminGetPlayersInSegmentResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessGetPlayersInSegment__DelegateSignature
	void DelegateOnSuccessGetPlayerSharedSecrets__DelegateSignature(struct FAdminGetPlayerSharedSecretsResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessGetPlayerSharedSecrets__DelegateSignature
	void DelegateOnSuccessGetPlayerSegments__DelegateSignature(struct FAdminGetPlayerSegmentsResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessGetPlayerSegments__DelegateSignature
	void DelegateOnSuccessGetPlayerProfile__DelegateSignature(struct FAdminGetPlayerProfileResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessGetPlayerProfile__DelegateSignature
	void DelegateOnSuccessGetPlayerIdFromAuthToken__DelegateSignature(struct FAdminGetPlayerIdFromAuthTokenResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessGetPlayerIdFromAuthToken__DelegateSignature
	void DelegateOnSuccessGetPlayedTitleList__DelegateSignature(struct FAdminGetPlayedTitleListResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessGetPlayedTitleList__DelegateSignature
	void DelegateOnSuccessGetMatchmakerGameModes__DelegateSignature(struct FAdminGetMatchmakerGameModesResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessGetMatchmakerGameModes__DelegateSignature
	void DelegateOnSuccessGetMatchmakerGameInfo__DelegateSignature(struct FAdminGetMatchmakerGameInfoResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessGetMatchmakerGameInfo__DelegateSignature
	void DelegateOnSuccessGetDataReport__DelegateSignature(struct FAdminGetDataReportResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessGetDataReport__DelegateSignature
	void DelegateOnSuccessGetContentUploadUrl__DelegateSignature(struct FAdminGetContentUploadUrlResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessGetContentUploadUrl__DelegateSignature
	void DelegateOnSuccessGetContentList__DelegateSignature(struct FAdminGetContentListResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessGetContentList__DelegateSignature
	void DelegateOnSuccessGetCloudScriptVersions__DelegateSignature(struct FAdminGetCloudScriptVersionsResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessGetCloudScriptVersions__DelegateSignature
	void DelegateOnSuccessGetCloudScriptTaskInstance__DelegateSignature(struct FAdminGetCloudScriptTaskInstanceResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessGetCloudScriptTaskInstance__DelegateSignature
	void DelegateOnSuccessGetCloudScriptRevision__DelegateSignature(struct FAdminGetCloudScriptRevisionResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessGetCloudScriptRevision__DelegateSignature
	void DelegateOnSuccessGetCatalogItems__DelegateSignature(struct FAdminGetCatalogItemsResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessGetCatalogItems__DelegateSignature
	void DelegateOnSuccessGetAllSegments__DelegateSignature(struct FAdminGetAllSegmentsResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessGetAllSegments__DelegateSignature
	void DelegateOnSuccessGetActionsOnPlayersInSegmentTaskInstance__DelegateSignature(struct FAdminGetActionsOnPlayersInSegmentTaskInstanceResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessGetActionsOnPlayersInSegmentTaskInstance__DelegateSignature
	void DelegateOnSuccessExportPlayersInSegment__DelegateSignature(struct FAdminExportPlayersInSegmentResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessExportPlayersInSegment__DelegateSignature
	void DelegateOnSuccessExportMasterPlayerData__DelegateSignature(struct FAdminExportMasterPlayerDataResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessExportMasterPlayerData__DelegateSignature
	void DelegateOnSuccessDeleteTitleDataOverride__DelegateSignature(struct FAdminDeleteTitleDataOverrideResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessDeleteTitleDataOverride__DelegateSignature
	void DelegateOnSuccessDeleteTitle__DelegateSignature(struct FAdminDeleteTitleResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessDeleteTitle__DelegateSignature
	void DelegateOnSuccessDeleteTask__DelegateSignature(struct FAdminEmptyResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessDeleteTask__DelegateSignature
	void DelegateOnSuccessDeleteStore__DelegateSignature(struct FAdminDeleteStoreResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessDeleteStore__DelegateSignature
	void DelegateOnSuccessDeleteSegment__DelegateSignature(struct FAdminDeleteSegmentsResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessDeleteSegment__DelegateSignature
	void DelegateOnSuccessDeletePlayerSharedSecret__DelegateSignature(struct FAdminDeletePlayerSharedSecretResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessDeletePlayerSharedSecret__DelegateSignature
	void DelegateOnSuccessDeletePlayer__DelegateSignature(struct FAdminDeletePlayerResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessDeletePlayer__DelegateSignature
	void DelegateOnSuccessDeleteOpenIdConnection__DelegateSignature(struct FAdminEmptyResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessDeleteOpenIdConnection__DelegateSignature
	void DelegateOnSuccessDeleteMembershipSubscription__DelegateSignature(struct FAdminDeleteMembershipSubscriptionResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessDeleteMembershipSubscription__DelegateSignature
	void DelegateOnSuccessDeleteMasterPlayerAccount__DelegateSignature(struct FAdminDeleteMasterPlayerAccountResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessDeleteMasterPlayerAccount__DelegateSignature
	void DelegateOnSuccessDeleteContent__DelegateSignature(struct FAdminBlankResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessDeleteContent__DelegateSignature
	void DelegateOnSuccessCreateSegment__DelegateSignature(struct FAdminCreateSegmentResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessCreateSegment__DelegateSignature
	void DelegateOnSuccessCreatePlayerStatisticDefinition__DelegateSignature(struct FAdminCreatePlayerStatisticDefinitionResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessCreatePlayerStatisticDefinition__DelegateSignature
	void DelegateOnSuccessCreatePlayerSharedSecret__DelegateSignature(struct FAdminCreatePlayerSharedSecretResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessCreatePlayerSharedSecret__DelegateSignature
	void DelegateOnSuccessCreateOpenIdConnection__DelegateSignature(struct FAdminEmptyResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessCreateOpenIdConnection__DelegateSignature
	void DelegateOnSuccessCreateInsightsScheduledScalingTask__DelegateSignature(struct FAdminCreateTaskResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessCreateInsightsScheduledScalingTask__DelegateSignature
	void DelegateOnSuccessCreateCloudScriptTask__DelegateSignature(struct FAdminCreateTaskResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessCreateCloudScriptTask__DelegateSignature
	void DelegateOnSuccessCreateActionsOnPlayersInSegmentTask__DelegateSignature(struct FAdminCreateTaskResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessCreateActionsOnPlayersInSegmentTask__DelegateSignature
	void DelegateOnSuccessCheckLimitedEditionItemAvailability__DelegateSignature(struct FAdminCheckLimitedEditionItemAvailabilityResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessCheckLimitedEditionItemAvailability__DelegateSignature
	void DelegateOnSuccessBanUsers__DelegateSignature(struct FAdminBanUsersResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessBanUsers__DelegateSignature
	void DelegateOnSuccessAddVirtualCurrencyTypes__DelegateSignature(struct FAdminBlankResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessAddVirtualCurrencyTypes__DelegateSignature
	void DelegateOnSuccessAddUserVirtualCurrency__DelegateSignature(struct FAdminModifyUserVirtualCurrencyResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessAddUserVirtualCurrency__DelegateSignature
	void DelegateOnSuccessAddPlayerTag__DelegateSignature(struct FAdminAddPlayerTagResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessAddPlayerTag__DelegateSignature
	void DelegateOnSuccessAddNews__DelegateSignature(struct FAdminAddNewsResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessAddNews__DelegateSignature
	void DelegateOnSuccessAddLocalizedNews__DelegateSignature(struct FAdminAddLocalizedNewsResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessAddLocalizedNews__DelegateSignature
	void DelegateOnSuccessAbortTaskInstance__DelegateSignature(struct FAdminEmptyResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnSuccessAbortTaskInstance__DelegateSignature
	void DelegateOnFailurePlayFabError__DelegateSignature(struct FPlayFabError Error, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAdminAPI.DelegateOnFailurePlayFabError__DelegateSignature
	struct UPlayFabAdminAPI* CreateSegment(struct FAdminCreateSegmentRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.CreateSegment
	struct UPlayFabAdminAPI* CreatePlayerStatisticDefinition(struct FAdminCreatePlayerStatisticDefinitionRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.CreatePlayerStatisticDefinition
	struct UPlayFabAdminAPI* CreatePlayerSharedSecret(struct FAdminCreatePlayerSharedSecretRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.CreatePlayerSharedSecret
	struct UPlayFabAdminAPI* CreateOpenIdConnection(struct FAdminCreateOpenIdConnectionRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.CreateOpenIdConnection
	struct UPlayFabAdminAPI* CreateInsightsScheduledScalingTask(struct FAdminCreateInsightsScheduledScalingTaskRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.CreateInsightsScheduledScalingTask
	struct UPlayFabAdminAPI* CreateCloudScriptTask(struct FAdminCreateCloudScriptTaskRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.CreateCloudScriptTask
	struct UPlayFabAdminAPI* CreateActionsOnPlayersInSegmentTask(struct FAdminCreateActionsOnPlayerSegmentTaskRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.CreateActionsOnPlayersInSegmentTask
	struct UPlayFabAdminAPI* CheckLimitedEditionItemAvailability(struct FAdminCheckLimitedEditionItemAvailabilityRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.CheckLimitedEditionItemAvailability
	struct UPlayFabAdminAPI* BanUsers(struct FAdminBanUsersRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.BanUsers
	struct UPlayFabAdminAPI* AddVirtualCurrencyTypes(struct FAdminAddVirtualCurrencyTypesRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.AddVirtualCurrencyTypes
	struct UPlayFabAdminAPI* AddUserVirtualCurrency(struct FAdminAddUserVirtualCurrencyRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.AddUserVirtualCurrency
	struct UPlayFabAdminAPI* AddPlayerTag(struct FAdminAddPlayerTagRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.AddPlayerTag
	struct UPlayFabAdminAPI* AddNews(struct FAdminAddNewsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.AddNews
	struct UPlayFabAdminAPI* AddLocalizedNews(struct FAdminAddLocalizedNewsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.AddLocalizedNews
	struct UPlayFabAdminAPI* AbortTaskInstance(struct FAdminAbortTaskInstanceRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAdminAPI.AbortTaskInstance
}; 



// Class PlayFab.PlayFabAdminModelDecoder
// Size: 0x28(Inherited: 0x28) 
struct UPlayFabAdminModelDecoder : public UBlueprintFunctionLibrary
{

	struct FAdminUpdateUserTitleDisplayNameResult decodeUpdateUserTitleDisplayNameResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabAdminModelDecoder.decodeUpdateUserTitleDisplayNameResultResponse
	struct FAdminUpdateUserDataResult decodeUpdateUserDataResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabAdminModelDecoder.decodeUpdateUserDataResultResponse
	struct FAdminUpdateStoreItemsResult decodeUpdateStoreItemsResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabAdminModelDecoder.decodeUpdateStoreItemsResultResponse
	struct FAdminUpdateSegmentResponse decodeUpdateSegmentResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabAdminModelDecoder.decodeUpdateSegmentResponseResponse
	struct FAdminUpdateRandomResultTablesResult decodeUpdateRandomResultTablesResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabAdminModelDecoder.decodeUpdateRandomResultTablesResultResponse
	struct FAdminUpdatePolicyResponse decodeUpdatePolicyResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabAdminModelDecoder.decodeUpdatePolicyResponseResponse
	struct FAdminUpdatePlayerStatisticDefinitionResult decodeUpdatePlayerStatisticDefinitionResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabAdminModelDecoder.decodeUpdatePlayerStatisticDefinitionResultResponse
	struct FAdminUpdatePlayerSharedSecretResult decodeUpdatePlayerSharedSecretResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabAdminModelDecoder.decodeUpdatePlayerSharedSecretResultResponse
	struct FAdminUpdateCloudScriptResult decodeUpdateCloudScriptResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabAdminModelDecoder.decodeUpdateCloudScriptResultResponse
	struct FAdminUpdateCatalogItemsResult decodeUpdateCatalogItemsResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabAdminModelDecoder.decodeUpdateCatalogItemsResultResponse
	struct FAdminUpdateBansResult decodeUpdateBansResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabAdminModelDecoder.decodeUpdateBansResultResponse
	struct FAdminSetupPushNotificationResult decodeSetupPushNotificationResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabAdminModelDecoder.decodeSetupPushNotificationResultResponse
	struct FAdminSetTitleDataResult decodeSetTitleDataResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabAdminModelDecoder.decodeSetTitleDataResultResponse
	struct FAdminSetTitleDataAndOverridesResult decodeSetTitleDataAndOverridesResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabAdminModelDecoder.decodeSetTitleDataAndOverridesResultResponse
	struct FAdminSetPublisherDataResult decodeSetPublisherDataResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabAdminModelDecoder.decodeSetPublisherDataResultResponse
	struct FAdminSetPublishedRevisionResult decodeSetPublishedRevisionResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabAdminModelDecoder.decodeSetPublishedRevisionResultResponse
	struct FAdminSetPlayerSecretResult decodeSetPlayerSecretResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabAdminModelDecoder.decodeSetPlayerSecretResultResponse
	struct FAdminSetMembershipOverrideResult decodeSetMembershipOverrideResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabAdminModelDecoder.decodeSetMembershipOverrideResultResponse
	struct FAdminSendAccountRecoveryEmailResult decodeSendAccountRecoveryEmailResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabAdminModelDecoder.decodeSendAccountRecoveryEmailResultResponse
	struct FAdminRunTaskResult decodeRunTaskResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabAdminModelDecoder.decodeRunTaskResultResponse
	struct FAdminRevokeInventoryResult decodeRevokeInventoryResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabAdminModelDecoder.decodeRevokeInventoryResultResponse
	struct FAdminRevokeInventoryItemsResult decodeRevokeInventoryItemsResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabAdminModelDecoder.decodeRevokeInventoryItemsResultResponse
	struct FAdminRevokeBansResult decodeRevokeBansResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabAdminModelDecoder.decodeRevokeBansResultResponse
	struct FAdminRevokeAllBansForUserResult decodeRevokeAllBansForUserResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabAdminModelDecoder.decodeRevokeAllBansForUserResultResponse
	struct FAdminResolvePurchaseDisputeResponse decodeResolvePurchaseDisputeResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabAdminModelDecoder.decodeResolvePurchaseDisputeResponseResponse
	struct FAdminResetUserStatisticsResult decodeResetUserStatisticsResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabAdminModelDecoder.decodeResetUserStatisticsResultResponse
	struct FAdminResetPasswordResult decodeResetPasswordResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabAdminModelDecoder.decodeResetPasswordResultResponse
	struct FAdminResetCharacterStatisticsResult decodeResetCharacterStatisticsResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabAdminModelDecoder.decodeResetCharacterStatisticsResultResponse
	struct FAdminRemovePlayerTagResult decodeRemovePlayerTagResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabAdminModelDecoder.decodeRemovePlayerTagResultResponse
	struct FAdminRefundPurchaseResponse decodeRefundPurchaseResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabAdminModelDecoder.decodeRefundPurchaseResponseResponse
	struct FAdminModifyUserVirtualCurrencyResult decodeModifyUserVirtualCurrencyResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabAdminModelDecoder.decodeModifyUserVirtualCurrencyResultResponse
	struct FAdminModifyServerBuildResult decodeModifyServerBuildResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabAdminModelDecoder.decodeModifyServerBuildResultResponse
	struct FAdminLookupUserAccountInfoResult decodeLookupUserAccountInfoResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabAdminModelDecoder.decodeLookupUserAccountInfoResultResponse
	struct FAdminListVirtualCurrencyTypesResult decodeListVirtualCurrencyTypesResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabAdminModelDecoder.decodeListVirtualCurrencyTypesResultResponse
	struct FAdminListOpenIdConnectionResponse decodeListOpenIdConnectionResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabAdminModelDecoder.decodeListOpenIdConnectionResponseResponse
	struct FAdminIncrementPlayerStatisticVersionResult decodeIncrementPlayerStatisticVersionResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabAdminModelDecoder.decodeIncrementPlayerStatisticVersionResultResponse
	struct FAdminIncrementLimitedEditionItemAvailabilityResult decodeIncrementLimitedEditionItemAvailabilityResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabAdminModelDecoder.decodeIncrementLimitedEditionItemAvailabilityResultResponse
	struct FAdminGrantItemsToUsersResult decodeGrantItemsToUsersResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabAdminModelDecoder.decodeGrantItemsToUsersResultResponse
	struct FAdminGetUserInventoryResult decodeGetUserInventoryResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabAdminModelDecoder.decodeGetUserInventoryResultResponse
	struct FAdminGetUserDataResult decodeGetUserDataResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabAdminModelDecoder.decodeGetUserDataResultResponse
	struct FAdminGetUserBansResult decodeGetUserBansResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabAdminModelDecoder.decodeGetUserBansResultResponse
	struct FAdminGetTitleDataResult decodeGetTitleDataResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabAdminModelDecoder.decodeGetTitleDataResultResponse
	struct FAdminGetTasksResult decodeGetTasksResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabAdminModelDecoder.decodeGetTasksResultResponse
	struct FAdminGetTaskInstancesResult decodeGetTaskInstancesResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabAdminModelDecoder.decodeGetTaskInstancesResultResponse
	struct FAdminGetStoreItemsResult decodeGetStoreItemsResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabAdminModelDecoder.decodeGetStoreItemsResultResponse
	struct FAdminGetSegmentsResponse decodeGetSegmentsResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabAdminModelDecoder.decodeGetSegmentsResponseResponse
	struct FAdminGetRandomResultTablesResult decodeGetRandomResultTablesResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabAdminModelDecoder.decodeGetRandomResultTablesResultResponse
	struct FAdminGetPublisherDataResult decodeGetPublisherDataResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabAdminModelDecoder.decodeGetPublisherDataResultResponse
	struct FAdminGetPolicyResponse decodeGetPolicyResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabAdminModelDecoder.decodeGetPolicyResponseResponse
	struct FAdminGetPlayerTagsResult decodeGetPlayerTagsResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabAdminModelDecoder.decodeGetPlayerTagsResultResponse
	struct FAdminGetPlayerStatisticVersionsResult decodeGetPlayerStatisticVersionsResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabAdminModelDecoder.decodeGetPlayerStatisticVersionsResultResponse
	struct FAdminGetPlayerStatisticDefinitionsResult decodeGetPlayerStatisticDefinitionsResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabAdminModelDecoder.decodeGetPlayerStatisticDefinitionsResultResponse
	struct FAdminGetPlayersInSegmentResult decodeGetPlayersInSegmentResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabAdminModelDecoder.decodeGetPlayersInSegmentResultResponse
	struct FAdminGetPlayersInSegmentExportResponse decodeGetPlayersInSegmentExportResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabAdminModelDecoder.decodeGetPlayersInSegmentExportResponseResponse
	struct FAdminGetPlayerSharedSecretsResult decodeGetPlayerSharedSecretsResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabAdminModelDecoder.decodeGetPlayerSharedSecretsResultResponse
	struct FAdminGetPlayerSegmentsResult decodeGetPlayerSegmentsResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabAdminModelDecoder.decodeGetPlayerSegmentsResultResponse
	struct FAdminGetPlayerProfileResult decodeGetPlayerProfileResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabAdminModelDecoder.decodeGetPlayerProfileResultResponse
	struct FAdminGetPlayerIdFromAuthTokenResult decodeGetPlayerIdFromAuthTokenResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabAdminModelDecoder.decodeGetPlayerIdFromAuthTokenResultResponse
	struct FAdminGetPlayedTitleListResult decodeGetPlayedTitleListResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabAdminModelDecoder.decodeGetPlayedTitleListResultResponse
	struct FAdminGetMatchmakerGameModesResult decodeGetMatchmakerGameModesResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabAdminModelDecoder.decodeGetMatchmakerGameModesResultResponse
	struct FAdminGetMatchmakerGameInfoResult decodeGetMatchmakerGameInfoResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabAdminModelDecoder.decodeGetMatchmakerGameInfoResultResponse
	struct FAdminGetDataReportResult decodeGetDataReportResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabAdminModelDecoder.decodeGetDataReportResultResponse
	struct FAdminGetContentUploadUrlResult decodeGetContentUploadUrlResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabAdminModelDecoder.decodeGetContentUploadUrlResultResponse
	struct FAdminGetContentListResult decodeGetContentListResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabAdminModelDecoder.decodeGetContentListResultResponse
	struct FAdminGetCloudScriptVersionsResult decodeGetCloudScriptVersionsResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabAdminModelDecoder.decodeGetCloudScriptVersionsResultResponse
	struct FAdminGetCloudScriptTaskInstanceResult decodeGetCloudScriptTaskInstanceResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabAdminModelDecoder.decodeGetCloudScriptTaskInstanceResultResponse
	struct FAdminGetCloudScriptRevisionResult decodeGetCloudScriptRevisionResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabAdminModelDecoder.decodeGetCloudScriptRevisionResultResponse
	struct FAdminGetCatalogItemsResult decodeGetCatalogItemsResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabAdminModelDecoder.decodeGetCatalogItemsResultResponse
	struct FAdminGetAllSegmentsResult decodeGetAllSegmentsResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabAdminModelDecoder.decodeGetAllSegmentsResultResponse
	struct FAdminGetActionsOnPlayersInSegmentTaskInstanceResult decodeGetActionsOnPlayersInSegmentTaskInstanceResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabAdminModelDecoder.decodeGetActionsOnPlayersInSegmentTaskInstanceResultResponse
	struct FAdminExportPlayersInSegmentResult decodeExportPlayersInSegmentResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabAdminModelDecoder.decodeExportPlayersInSegmentResultResponse
	struct FAdminExportMasterPlayerDataResult decodeExportMasterPlayerDataResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabAdminModelDecoder.decodeExportMasterPlayerDataResultResponse
	struct FAdminEmptyResponse decodeEmptyResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabAdminModelDecoder.decodeEmptyResponseResponse
	struct FAdminDeleteTitleResult decodeDeleteTitleResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabAdminModelDecoder.decodeDeleteTitleResultResponse
	struct FAdminDeleteTitleDataOverrideResult decodeDeleteTitleDataOverrideResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabAdminModelDecoder.decodeDeleteTitleDataOverrideResultResponse
	struct FAdminDeleteStoreResult decodeDeleteStoreResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabAdminModelDecoder.decodeDeleteStoreResultResponse
	struct FAdminDeleteSegmentsResponse decodeDeleteSegmentsResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabAdminModelDecoder.decodeDeleteSegmentsResponseResponse
	struct FAdminDeletePlayerSharedSecretResult decodeDeletePlayerSharedSecretResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabAdminModelDecoder.decodeDeletePlayerSharedSecretResultResponse
	struct FAdminDeletePlayerResult decodeDeletePlayerResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabAdminModelDecoder.decodeDeletePlayerResultResponse
	struct FAdminDeleteMembershipSubscriptionResult decodeDeleteMembershipSubscriptionResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabAdminModelDecoder.decodeDeleteMembershipSubscriptionResultResponse
	struct FAdminDeleteMasterPlayerAccountResult decodeDeleteMasterPlayerAccountResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabAdminModelDecoder.decodeDeleteMasterPlayerAccountResultResponse
	struct FAdminCreateTaskResult decodeCreateTaskResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabAdminModelDecoder.decodeCreateTaskResultResponse
	struct FAdminCreateSegmentResponse decodeCreateSegmentResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabAdminModelDecoder.decodeCreateSegmentResponseResponse
	struct FAdminCreatePlayerStatisticDefinitionResult decodeCreatePlayerStatisticDefinitionResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabAdminModelDecoder.decodeCreatePlayerStatisticDefinitionResultResponse
	struct FAdminCreatePlayerSharedSecretResult decodeCreatePlayerSharedSecretResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabAdminModelDecoder.decodeCreatePlayerSharedSecretResultResponse
	struct FAdminCheckLimitedEditionItemAvailabilityResult decodeCheckLimitedEditionItemAvailabilityResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabAdminModelDecoder.decodeCheckLimitedEditionItemAvailabilityResultResponse
	struct FAdminBlankResult decodeBlankResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabAdminModelDecoder.decodeBlankResultResponse
	struct FAdminBanUsersResult decodeBanUsersResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabAdminModelDecoder.decodeBanUsersResultResponse
	struct FAdminAddPlayerTagResult decodeAddPlayerTagResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabAdminModelDecoder.decodeAddPlayerTagResultResponse
	struct FAdminAddNewsResult decodeAddNewsResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabAdminModelDecoder.decodeAddNewsResultResponse
	struct FAdminAddLocalizedNewsResult decodeAddLocalizedNewsResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabAdminModelDecoder.decodeAddLocalizedNewsResultResponse
}; 



// Class PlayFab.PlayFabAuthenticationAPI
// Size: 0x130(Inherited: 0x30) 
struct UPlayFabAuthenticationAPI : public UOnlineBlueprintCallProxyBase
{
	struct FMulticastInlineDelegate OnPlayFabResponse;  // 0x30(0x10)
	char pad_64[136];  // 0x40(0x88)
	struct UPlayFabAuthenticationContext* CallAuthenticationContext;  // 0xC8(0x8)
	struct UPlayFabJsonObject* RequestJsonObj;  // 0xD0(0x8)
	struct UPlayFabJsonObject* ResponseJsonObj;  // 0xD8(0x8)
	char pad_224[80];  // 0xE0(0x50)

	struct UPlayFabAuthenticationAPI* ValidateEntityToken(struct FAuthenticationValidateEntityTokenRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAuthenticationAPI.ValidateEntityToken
	void HelperValidateEntityToken(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAuthenticationAPI.HelperValidateEntityToken
	void HelperGetEntityToken(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAuthenticationAPI.HelperGetEntityToken
	void HelperDelete(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAuthenticationAPI.HelperDelete
	void HelperAuthenticateGameServerWithCustomId(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabAuthenticationAPI.HelperAuthenticateGameServerWithCustomId
	struct UPlayFabAuthenticationAPI* GetEntityToken(struct FAuthenticationGetEntityTokenRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAuthenticationAPI.GetEntityToken
	struct UPlayFabAuthenticationAPI* Delete(struct FAuthenticationDeleteRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAuthenticationAPI.Delete
	void DelegateOnSuccessValidateEntityToken__DelegateSignature(struct FAuthenticationValidateEntityTokenResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAuthenticationAPI.DelegateOnSuccessValidateEntityToken__DelegateSignature
	void DelegateOnSuccessGetEntityToken__DelegateSignature(struct FAuthenticationGetEntityTokenResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAuthenticationAPI.DelegateOnSuccessGetEntityToken__DelegateSignature
	void DelegateOnSuccessDelete__DelegateSignature(struct FAuthenticationEmptyResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAuthenticationAPI.DelegateOnSuccessDelete__DelegateSignature
	void DelegateOnSuccessAuthenticateGameServerWithCustomId__DelegateSignature(struct FAuthenticationAuthenticateCustomIdResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAuthenticationAPI.DelegateOnSuccessAuthenticateGameServerWithCustomId__DelegateSignature
	void DelegateOnFailurePlayFabError__DelegateSignature(struct FPlayFabError Error, struct UObject* customData); // DelegateFunction PlayFab.PlayFabAuthenticationAPI.DelegateOnFailurePlayFabError__DelegateSignature
	struct UPlayFabAuthenticationAPI* AuthenticateGameServerWithCustomId(struct FAuthenticationAuthenticateCustomIdRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabAuthenticationAPI.AuthenticateGameServerWithCustomId
}; 



// Class PlayFab.PlayFabAuthenticationModelDecoder
// Size: 0x28(Inherited: 0x28) 
struct UPlayFabAuthenticationModelDecoder : public UBlueprintFunctionLibrary
{

	struct FAuthenticationValidateEntityTokenResponse decodeValidateEntityTokenResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabAuthenticationModelDecoder.decodeValidateEntityTokenResponseResponse
	struct FAuthenticationGetEntityTokenResponse decodeGetEntityTokenResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabAuthenticationModelDecoder.decodeGetEntityTokenResponseResponse
	struct FAuthenticationEmptyResponse decodeEmptyResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabAuthenticationModelDecoder.decodeEmptyResponseResponse
	struct FAuthenticationAuthenticateCustomIdResult decodeAuthenticateCustomIdResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabAuthenticationModelDecoder.decodeAuthenticateCustomIdResultResponse
}; 



// Class PlayFab.PlayFabClientModelDecoder
// Size: 0x28(Inherited: 0x28) 
struct UPlayFabClientModelDecoder : public UBlueprintFunctionLibrary
{

	struct FClientWriteEventResponse decodeWriteEventResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeWriteEventResponseResponse
	struct FClientValidateWindowsReceiptResult decodeValidateWindowsReceiptResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeValidateWindowsReceiptResultResponse
	struct FClientValidateIOSReceiptResult decodeValidateIOSReceiptResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeValidateIOSReceiptResultResponse
	struct FClientValidateGooglePlayPurchaseResult decodeValidateGooglePlayPurchaseResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeValidateGooglePlayPurchaseResultResponse
	struct FClientValidateAmazonReceiptResult decodeValidateAmazonReceiptResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeValidateAmazonReceiptResultResponse
	struct FClientUpdateUserTitleDisplayNameResult decodeUpdateUserTitleDisplayNameResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeUpdateUserTitleDisplayNameResultResponse
	struct FClientUpdateUserDataResult decodeUpdateUserDataResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeUpdateUserDataResultResponse
	struct FClientUpdateSharedGroupDataResult decodeUpdateSharedGroupDataResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeUpdateSharedGroupDataResultResponse
	struct FClientUpdatePlayerStatisticsResult decodeUpdatePlayerStatisticsResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeUpdatePlayerStatisticsResultResponse
	struct FClientUpdateCharacterStatisticsResult decodeUpdateCharacterStatisticsResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeUpdateCharacterStatisticsResultResponse
	struct FClientUpdateCharacterDataResult decodeUpdateCharacterDataResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeUpdateCharacterDataResultResponse
	struct FClientUnlockContainerItemResult decodeUnlockContainerItemResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeUnlockContainerItemResultResponse
	struct FClientUnlinkXboxAccountResult decodeUnlinkXboxAccountResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeUnlinkXboxAccountResultResponse
	struct FClientUnlinkTwitchAccountResult decodeUnlinkTwitchAccountResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeUnlinkTwitchAccountResultResponse
	struct FClientUnlinkSteamAccountResult decodeUnlinkSteamAccountResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeUnlinkSteamAccountResultResponse
	struct FClientUnlinkPSNAccountResult decodeUnlinkPSNAccountResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeUnlinkPSNAccountResultResponse
	struct FClientUnlinkNintendoSwitchDeviceIdResult decodeUnlinkNintendoSwitchDeviceIdResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeUnlinkNintendoSwitchDeviceIdResultResponse
	struct FClientUnlinkKongregateAccountResult decodeUnlinkKongregateAccountResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeUnlinkKongregateAccountResultResponse
	struct FClientUnlinkIOSDeviceIDResult decodeUnlinkIOSDeviceIDResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeUnlinkIOSDeviceIDResultResponse
	struct FClientUnlinkGooglePlayGamesServicesAccountResult decodeUnlinkGooglePlayGamesServicesAccountResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeUnlinkGooglePlayGamesServicesAccountResultResponse
	struct FClientUnlinkGoogleAccountResult decodeUnlinkGoogleAccountResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeUnlinkGoogleAccountResultResponse
	struct FClientUnlinkGameCenterAccountResult decodeUnlinkGameCenterAccountResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeUnlinkGameCenterAccountResultResponse
	struct FClientUnlinkFacebookInstantGamesIdResult decodeUnlinkFacebookInstantGamesIdResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeUnlinkFacebookInstantGamesIdResultResponse
	struct FClientUnlinkFacebookAccountResult decodeUnlinkFacebookAccountResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeUnlinkFacebookAccountResultResponse
	struct FClientUnlinkCustomIDResult decodeUnlinkCustomIDResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeUnlinkCustomIDResultResponse
	struct FClientUnlinkAndroidDeviceIDResult decodeUnlinkAndroidDeviceIDResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeUnlinkAndroidDeviceIDResultResponse
	struct FClientStartPurchaseResult decodeStartPurchaseResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeStartPurchaseResultResponse
	struct FClientSetPlayerSecretResult decodeSetPlayerSecretResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeSetPlayerSecretResultResponse
	struct FClientSetFriendTagsResult decodeSetFriendTagsResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeSetFriendTagsResultResponse
	struct FClientSendAccountRecoveryEmailResult decodeSendAccountRecoveryEmailResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeSendAccountRecoveryEmailResultResponse
	struct FClientRewardAdActivityResult decodeRewardAdActivityResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeRewardAdActivityResultResponse
	struct FClientRestoreIOSPurchasesResult decodeRestoreIOSPurchasesResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeRestoreIOSPurchasesResultResponse
	struct FClientReportPlayerClientResult decodeReportPlayerClientResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeReportPlayerClientResultResponse
	struct FClientReportAdActivityResult decodeReportAdActivityResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeReportAdActivityResultResponse
	struct FClientRemoveSharedGroupMembersResult decodeRemoveSharedGroupMembersResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeRemoveSharedGroupMembersResultResponse
	struct FClientRemoveGenericIDResult decodeRemoveGenericIDResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeRemoveGenericIDResultResponse
	struct FClientRemoveFriendResult decodeRemoveFriendResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeRemoveFriendResultResponse
	struct FClientRemoveContactEmailResult decodeRemoveContactEmailResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeRemoveContactEmailResultResponse
	struct FClientRegisterPlayFabUserResult decodeRegisterPlayFabUserResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeRegisterPlayFabUserResultResponse
	struct FClientRegisterForIOSPushNotificationResult decodeRegisterForIOSPushNotificationResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeRegisterForIOSPushNotificationResultResponse
	struct FClientRedeemCouponResult decodeRedeemCouponResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeRedeemCouponResultResponse
	struct FClientPurchaseItemResult decodePurchaseItemResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodePurchaseItemResultResponse
	struct FClientPayForPurchaseResult decodePayForPurchaseResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodePayForPurchaseResultResponse
	struct FClientOpenTradeResponse decodeOpenTradeResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeOpenTradeResponseResponse
	struct FClientModifyUserVirtualCurrencyResult decodeModifyUserVirtualCurrencyResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeModifyUserVirtualCurrencyResultResponse
	struct FClientMatchmakeResult decodeMatchmakeResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeMatchmakeResultResponse
	struct FClientLoginResult decodeLoginResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeLoginResultResponse
	struct FClientListUsersCharactersResult decodeListUsersCharactersResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeListUsersCharactersResultResponse
	struct FClientLinkXboxAccountResult decodeLinkXboxAccountResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeLinkXboxAccountResultResponse
	struct FClientLinkTwitchAccountResult decodeLinkTwitchAccountResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeLinkTwitchAccountResultResponse
	struct FClientLinkSteamAccountResult decodeLinkSteamAccountResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeLinkSteamAccountResultResponse
	struct FClientLinkPSNAccountResult decodeLinkPSNAccountResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeLinkPSNAccountResultResponse
	struct FClientLinkNintendoSwitchDeviceIdResult decodeLinkNintendoSwitchDeviceIdResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeLinkNintendoSwitchDeviceIdResultResponse
	struct FClientLinkKongregateAccountResult decodeLinkKongregateAccountResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeLinkKongregateAccountResultResponse
	struct FClientLinkIOSDeviceIDResult decodeLinkIOSDeviceIDResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeLinkIOSDeviceIDResultResponse
	struct FClientLinkGooglePlayGamesServicesAccountResult decodeLinkGooglePlayGamesServicesAccountResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeLinkGooglePlayGamesServicesAccountResultResponse
	struct FClientLinkGoogleAccountResult decodeLinkGoogleAccountResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeLinkGoogleAccountResultResponse
	struct FClientLinkGameCenterAccountResult decodeLinkGameCenterAccountResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeLinkGameCenterAccountResultResponse
	struct FClientLinkFacebookInstantGamesIdResult decodeLinkFacebookInstantGamesIdResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeLinkFacebookInstantGamesIdResultResponse
	struct FClientLinkFacebookAccountResult decodeLinkFacebookAccountResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeLinkFacebookAccountResultResponse
	struct FClientLinkCustomIDResult decodeLinkCustomIDResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeLinkCustomIDResultResponse
	struct FClientLinkAndroidDeviceIDResult decodeLinkAndroidDeviceIDResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeLinkAndroidDeviceIDResultResponse
	struct FClientGrantCharacterToUserResult decodeGrantCharacterToUserResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeGrantCharacterToUserResultResponse
	struct FClientGetUserInventoryResult decodeGetUserInventoryResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeGetUserInventoryResultResponse
	struct FClientGetUserDataResult decodeGetUserDataResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeGetUserDataResultResponse
	struct FClientGetTradeStatusResponse decodeGetTradeStatusResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeGetTradeStatusResponseResponse
	struct FClientGetTitlePublicKeyResult decodeGetTitlePublicKeyResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeGetTitlePublicKeyResultResponse
	struct FClientGetTitleNewsResult decodeGetTitleNewsResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeGetTitleNewsResultResponse
	struct FClientGetTitleDataResult decodeGetTitleDataResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeGetTitleDataResultResponse
	struct FClientGetTimeResult decodeGetTimeResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeGetTimeResultResponse
	struct FClientGetStoreItemsResult decodeGetStoreItemsResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeGetStoreItemsResultResponse
	struct FClientGetSharedGroupDataResult decodeGetSharedGroupDataResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeGetSharedGroupDataResultResponse
	struct FClientGetPurchaseResult decodeGetPurchaseResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeGetPurchaseResultResponse
	struct FClientGetPublisherDataResult decodeGetPublisherDataResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeGetPublisherDataResultResponse
	struct FClientGetPlayFabIDsFromXboxLiveIDsResult decodeGetPlayFabIDsFromXboxLiveIDsResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeGetPlayFabIDsFromXboxLiveIDsResultResponse
	struct FClientGetPlayFabIDsFromTwitchIDsResult decodeGetPlayFabIDsFromTwitchIDsResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeGetPlayFabIDsFromTwitchIDsResultResponse
	struct FClientGetPlayFabIDsFromSteamIDsResult decodeGetPlayFabIDsFromSteamIDsResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeGetPlayFabIDsFromSteamIDsResultResponse
	struct FClientGetPlayFabIDsFromPSNAccountIDsResult decodeGetPlayFabIDsFromPSNAccountIDsResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeGetPlayFabIDsFromPSNAccountIDsResultResponse
	struct FClientGetPlayFabIDsFromNintendoSwitchDeviceIdsResult decodeGetPlayFabIDsFromNintendoSwitchDeviceIdsResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeGetPlayFabIDsFromNintendoSwitchDeviceIdsResultResponse
	struct FClientGetPlayFabIDsFromNintendoServiceAccountIdsResult decodeGetPlayFabIDsFromNintendoServiceAccountIdsResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeGetPlayFabIDsFromNintendoServiceAccountIdsResultResponse
	struct FClientGetPlayFabIDsFromKongregateIDsResult decodeGetPlayFabIDsFromKongregateIDsResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeGetPlayFabIDsFromKongregateIDsResultResponse
	struct FClientGetPlayFabIDsFromGooglePlayGamesPlayerIDsResult decodeGetPlayFabIDsFromGooglePlayGamesPlayerIDsResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeGetPlayFabIDsFromGooglePlayGamesPlayerIDsResultResponse
	struct FClientGetPlayFabIDsFromGoogleIDsResult decodeGetPlayFabIDsFromGoogleIDsResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeGetPlayFabIDsFromGoogleIDsResultResponse
	struct FClientGetPlayFabIDsFromGenericIDsResult decodeGetPlayFabIDsFromGenericIDsResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeGetPlayFabIDsFromGenericIDsResultResponse
	struct FClientGetPlayFabIDsFromGameCenterIDsResult decodeGetPlayFabIDsFromGameCenterIDsResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeGetPlayFabIDsFromGameCenterIDsResultResponse
	struct FClientGetPlayFabIDsFromFacebookInstantGamesIdsResult decodeGetPlayFabIDsFromFacebookInstantGamesIdsResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeGetPlayFabIDsFromFacebookInstantGamesIdsResultResponse
	struct FClientGetPlayFabIDsFromFacebookIDsResult decodeGetPlayFabIDsFromFacebookIDsResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeGetPlayFabIDsFromFacebookIDsResultResponse
	struct FClientGetPlayerTradesResponse decodeGetPlayerTradesResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeGetPlayerTradesResponseResponse
	struct FClientGetPlayerTagsResult decodeGetPlayerTagsResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeGetPlayerTagsResultResponse
	struct FClientGetPlayerStatisticVersionsResult decodeGetPlayerStatisticVersionsResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeGetPlayerStatisticVersionsResultResponse
	struct FClientGetPlayerStatisticsResult decodeGetPlayerStatisticsResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeGetPlayerStatisticsResultResponse
	struct FClientGetPlayerSegmentsResult decodeGetPlayerSegmentsResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeGetPlayerSegmentsResultResponse
	struct FClientGetPlayerProfileResult decodeGetPlayerProfileResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeGetPlayerProfileResultResponse
	struct FClientGetPlayerCombinedInfoResult decodeGetPlayerCombinedInfoResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeGetPlayerCombinedInfoResultResponse
	struct FClientGetPhotonAuthenticationTokenResult decodeGetPhotonAuthenticationTokenResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeGetPhotonAuthenticationTokenResultResponse
	struct FClientGetPaymentTokenResult decodeGetPaymentTokenResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeGetPaymentTokenResultResponse
	struct FClientGetLeaderboardResult decodeGetLeaderboardResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeGetLeaderboardResultResponse
	struct FClientGetLeaderboardForUsersCharactersResult decodeGetLeaderboardForUsersCharactersResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeGetLeaderboardForUsersCharactersResultResponse
	struct FClientGetLeaderboardAroundPlayerResult decodeGetLeaderboardAroundPlayerResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeGetLeaderboardAroundPlayerResultResponse
	struct FClientGetLeaderboardAroundCharacterResult decodeGetLeaderboardAroundCharacterResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeGetLeaderboardAroundCharacterResultResponse
	struct FClientGetFriendsListResult decodeGetFriendsListResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeGetFriendsListResultResponse
	struct FClientGetFriendLeaderboardAroundPlayerResult decodeGetFriendLeaderboardAroundPlayerResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeGetFriendLeaderboardAroundPlayerResultResponse
	struct FClientGetContentDownloadUrlResult decodeGetContentDownloadUrlResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeGetContentDownloadUrlResultResponse
	struct FClientGetCharacterStatisticsResult decodeGetCharacterStatisticsResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeGetCharacterStatisticsResultResponse
	struct FClientGetCharacterLeaderboardResult decodeGetCharacterLeaderboardResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeGetCharacterLeaderboardResultResponse
	struct FClientGetCharacterInventoryResult decodeGetCharacterInventoryResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeGetCharacterInventoryResultResponse
	struct FClientGetCharacterDataResult decodeGetCharacterDataResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeGetCharacterDataResultResponse
	struct FClientGetCatalogItemsResult decodeGetCatalogItemsResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeGetCatalogItemsResultResponse
	struct FClientGetAdPlacementsResult decodeGetAdPlacementsResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeGetAdPlacementsResultResponse
	struct FClientGetAccountInfoResult decodeGetAccountInfoResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeGetAccountInfoResultResponse
	struct FClientGameServerRegionsResult decodeGameServerRegionsResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeGameServerRegionsResultResponse
	struct FClientExecuteCloudScriptResult decodeExecuteCloudScriptResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeExecuteCloudScriptResultResponse
	struct FClientEmptyResult decodeEmptyResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeEmptyResultResponse
	struct FClientEmptyResponse decodeEmptyResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeEmptyResponseResponse
	struct FClientCurrentGamesResult decodeCurrentGamesResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeCurrentGamesResultResponse
	struct FClientCreateSharedGroupResult decodeCreateSharedGroupResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeCreateSharedGroupResultResponse
	struct FClientConsumeXboxEntitlementsResult decodeConsumeXboxEntitlementsResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeConsumeXboxEntitlementsResultResponse
	struct FClientConsumePSNEntitlementsResult decodeConsumePSNEntitlementsResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeConsumePSNEntitlementsResultResponse
	struct FClientConsumePS5EntitlementsResult decodeConsumePS5EntitlementsResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeConsumePS5EntitlementsResultResponse
	struct FClientConsumeMicrosoftStoreEntitlementsResponse decodeConsumeMicrosoftStoreEntitlementsResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeConsumeMicrosoftStoreEntitlementsResponseResponse
	struct FClientConsumeItemResult decodeConsumeItemResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeConsumeItemResultResponse
	struct FClientConfirmPurchaseResult decodeConfirmPurchaseResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeConfirmPurchaseResultResponse
	struct FClientCancelTradeResponse decodeCancelTradeResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeCancelTradeResponseResponse
	struct FClientAttributeInstallResult decodeAttributeInstallResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeAttributeInstallResultResponse
	struct FClientAndroidDevicePushNotificationRegistrationResult decodeAndroidDevicePushNotificationRegistrationResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeAndroidDevicePushNotificationRegistrationResultResponse
	struct FClientAddUsernamePasswordResult decodeAddUsernamePasswordResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeAddUsernamePasswordResultResponse
	struct FClientAddSharedGroupMembersResult decodeAddSharedGroupMembersResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeAddSharedGroupMembersResultResponse
	struct FClientAddOrUpdateContactEmailResult decodeAddOrUpdateContactEmailResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeAddOrUpdateContactEmailResultResponse
	struct FClientAddGenericIDResult decodeAddGenericIDResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeAddGenericIDResultResponse
	struct FClientAddFriendResult decodeAddFriendResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeAddFriendResultResponse
	struct FClientAcceptTradeResponse decodeAcceptTradeResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabClientModelDecoder.decodeAcceptTradeResponseResponse
}; 



// Class PlayFab.PlayFabClientAPI
// Size: 0xB50(Inherited: 0x30) 
struct UPlayFabClientAPI : public UOnlineBlueprintCallProxyBase
{
	struct FMulticastInlineDelegate OnPlayFabResponse;  // 0x30(0x10)
	char pad_64[2728];  // 0x40(0xAA8)
	struct UPlayFabAuthenticationContext* CallAuthenticationContext;  // 0xAE8(0x8)
	struct UPlayFabJsonObject* RequestJsonObj;  // 0xAF0(0x8)
	struct UPlayFabJsonObject* ResponseJsonObj;  // 0xAF8(0x8)
	char pad_2816[80];  // 0xB00(0x50)

	struct UPlayFabClientAPI* WriteTitleEvent(struct FClientWriteTitleEventRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.WriteTitleEvent
	struct UPlayFabClientAPI* WritePlayerEvent(struct FClientWriteClientPlayerEventRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.WritePlayerEvent
	struct UPlayFabClientAPI* WriteCharacterEvent(struct FClientWriteClientCharacterEventRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.WriteCharacterEvent
	struct UPlayFabClientAPI* ValidateWindowsStoreReceipt(struct FClientValidateWindowsReceiptRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.ValidateWindowsStoreReceipt
	struct UPlayFabClientAPI* ValidateIOSReceipt(struct FClientValidateIOSReceiptRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.ValidateIOSReceipt
	struct UPlayFabClientAPI* ValidateGooglePlayPurchase(struct FClientValidateGooglePlayPurchaseRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.ValidateGooglePlayPurchase
	struct UPlayFabClientAPI* ValidateAmazonIAPReceipt(struct FClientValidateAmazonReceiptRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.ValidateAmazonIAPReceipt
	struct UPlayFabClientAPI* UpdateUserTitleDisplayName(struct FClientUpdateUserTitleDisplayNameRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.UpdateUserTitleDisplayName
	struct UPlayFabClientAPI* UpdateUserPublisherData(struct FClientUpdateUserDataRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.UpdateUserPublisherData
	struct UPlayFabClientAPI* UpdateUserData(struct FClientUpdateUserDataRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.UpdateUserData
	struct UPlayFabClientAPI* UpdateSharedGroupData(struct FClientUpdateSharedGroupDataRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.UpdateSharedGroupData
	struct UPlayFabClientAPI* UpdatePlayerStatistics(struct FClientUpdatePlayerStatisticsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.UpdatePlayerStatistics
	struct UPlayFabClientAPI* UpdateCharacterStatistics(struct FClientUpdateCharacterStatisticsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.UpdateCharacterStatistics
	struct UPlayFabClientAPI* UpdateCharacterData(struct FClientUpdateCharacterDataRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.UpdateCharacterData
	struct UPlayFabClientAPI* UpdateAvatarUrl(struct FClientUpdateAvatarUrlRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.UpdateAvatarUrl
	struct UPlayFabClientAPI* UnlockContainerItem(struct FClientUnlockContainerItemRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.UnlockContainerItem
	struct UPlayFabClientAPI* UnlockContainerInstance(struct FClientUnlockContainerInstanceRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.UnlockContainerInstance
	struct UPlayFabClientAPI* UnlinkXboxAccount(struct FClientUnlinkXboxAccountRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.UnlinkXboxAccount
	struct UPlayFabClientAPI* UnlinkTwitch(struct FClientUnlinkTwitchAccountRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.UnlinkTwitch
	struct UPlayFabClientAPI* UnlinkSteamAccount(struct FClientUnlinkSteamAccountRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.UnlinkSteamAccount
	struct UPlayFabClientAPI* UnlinkPSNAccount(struct FClientUnlinkPSNAccountRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.UnlinkPSNAccount
	struct UPlayFabClientAPI* UnlinkOpenIdConnect(struct FClientUnlinkOpenIdConnectRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.UnlinkOpenIdConnect
	struct UPlayFabClientAPI* UnlinkNintendoSwitchDeviceId(struct FClientUnlinkNintendoSwitchDeviceIdRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.UnlinkNintendoSwitchDeviceId
	struct UPlayFabClientAPI* UnlinkNintendoServiceAccount(struct FClientUnlinkNintendoServiceAccountRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.UnlinkNintendoServiceAccount
	struct UPlayFabClientAPI* UnlinkKongregate(struct FClientUnlinkKongregateAccountRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.UnlinkKongregate
	struct UPlayFabClientAPI* UnlinkIOSDeviceID(struct FClientUnlinkIOSDeviceIDRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.UnlinkIOSDeviceID
	struct UPlayFabClientAPI* UnlinkGooglePlayGamesServicesAccount(struct FClientUnlinkGooglePlayGamesServicesAccountRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.UnlinkGooglePlayGamesServicesAccount
	struct UPlayFabClientAPI* UnlinkGoogleAccount(struct FClientUnlinkGoogleAccountRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.UnlinkGoogleAccount
	struct UPlayFabClientAPI* UnlinkGameCenterAccount(struct FClientUnlinkGameCenterAccountRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.UnlinkGameCenterAccount
	struct UPlayFabClientAPI* UnlinkFacebookInstantGamesId(struct FClientUnlinkFacebookInstantGamesIdRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.UnlinkFacebookInstantGamesId
	struct UPlayFabClientAPI* UnlinkFacebookAccount(struct FClientUnlinkFacebookAccountRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.UnlinkFacebookAccount
	struct UPlayFabClientAPI* UnlinkCustomID(struct FClientUnlinkCustomIDRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.UnlinkCustomID
	struct UPlayFabClientAPI* UnlinkApple(struct FClientUnlinkAppleRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.UnlinkApple
	struct UPlayFabClientAPI* UnlinkAndroidDeviceID(struct FClientUnlinkAndroidDeviceIDRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.UnlinkAndroidDeviceID
	struct UPlayFabClientAPI* SubtractUserVirtualCurrency(struct FClientSubtractUserVirtualCurrencyRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.SubtractUserVirtualCurrency
	struct UPlayFabClientAPI* StartPurchase(struct FClientStartPurchaseRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.StartPurchase
	struct UPlayFabClientAPI* SetPlayerSecret(struct FClientSetPlayerSecretRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.SetPlayerSecret
	struct UPlayFabClientAPI* SetFriendTags(struct FClientSetFriendTagsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.SetFriendTags
	struct UPlayFabClientAPI* SendAccountRecoveryEmail(struct FClientSendAccountRecoveryEmailRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.SendAccountRecoveryEmail
	struct UPlayFabClientAPI* RewardAdActivity(struct FClientRewardAdActivityRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.RewardAdActivity
	struct UPlayFabClientAPI* RestoreIOSPurchases(struct FClientRestoreIOSPurchasesRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.RestoreIOSPurchases
	struct UPlayFabClientAPI* ReportPlayer(struct FClientReportPlayerClientRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.ReportPlayer
	struct UPlayFabClientAPI* ReportDeviceInfo(struct FClientDeviceInfoRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.ReportDeviceInfo
	struct UPlayFabClientAPI* ReportAdActivity(struct FClientReportAdActivityRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.ReportAdActivity
	struct UPlayFabClientAPI* RemoveSharedGroupMembers(struct FClientRemoveSharedGroupMembersRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.RemoveSharedGroupMembers
	struct UPlayFabClientAPI* RemoveGenericID(struct FClientRemoveGenericIDRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.RemoveGenericID
	struct UPlayFabClientAPI* RemoveFriend(struct FClientRemoveFriendRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.RemoveFriend
	struct UPlayFabClientAPI* RemoveContactEmail(struct FClientRemoveContactEmailRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.RemoveContactEmail
	struct UPlayFabClientAPI* RegisterPlayFabUser(struct FClientRegisterPlayFabUserRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.RegisterPlayFabUser
	struct UPlayFabClientAPI* RegisterForIOSPushNotification(struct FClientRegisterForIOSPushNotificationRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.RegisterForIOSPushNotification
	struct UPlayFabClientAPI* RefreshPSNAuthToken(struct FClientRefreshPSNAuthTokenRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.RefreshPSNAuthToken
	struct UPlayFabClientAPI* RedeemCoupon(struct FClientRedeemCouponRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.RedeemCoupon
	struct UPlayFabClientAPI* PurchaseItem(struct FClientPurchaseItemRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.PurchaseItem
	struct UPlayFabClientAPI* PayForPurchase(struct FClientPayForPurchaseRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.PayForPurchase
	struct UPlayFabClientAPI* OpenTrade(struct FClientOpenTradeRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.OpenTrade
	struct UPlayFabClientAPI* Matchmake(struct FClientMatchmakeRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.Matchmake
	struct UPlayFabClientAPI* LoginWithXbox(struct FClientLoginWithXboxRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.LoginWithXbox
	struct UPlayFabClientAPI* LoginWithTwitch(struct FClientLoginWithTwitchRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.LoginWithTwitch
	struct UPlayFabClientAPI* LoginWithSteam(struct FClientLoginWithSteamRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.LoginWithSteam
	struct UPlayFabClientAPI* LoginWithPSN(struct FClientLoginWithPSNRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.LoginWithPSN
	struct UPlayFabClientAPI* LoginWithPlayFab(struct FClientLoginWithPlayFabRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.LoginWithPlayFab
	struct UPlayFabClientAPI* LoginWithOpenIdConnect(struct FClientLoginWithOpenIdConnectRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.LoginWithOpenIdConnect
	struct UPlayFabClientAPI* LoginWithNintendoSwitchDeviceId(struct FClientLoginWithNintendoSwitchDeviceIdRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.LoginWithNintendoSwitchDeviceId
	struct UPlayFabClientAPI* LoginWithNintendoServiceAccount(struct FClientLoginWithNintendoServiceAccountRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.LoginWithNintendoServiceAccount
	struct UPlayFabClientAPI* LoginWithKongregate(struct FClientLoginWithKongregateRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.LoginWithKongregate
	struct UPlayFabClientAPI* LoginWithIOSDeviceID(struct FClientLoginWithIOSDeviceIDRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.LoginWithIOSDeviceID
	struct UPlayFabClientAPI* LoginWithGooglePlayGamesServices(struct FClientLoginWithGooglePlayGamesServicesRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.LoginWithGooglePlayGamesServices
	struct UPlayFabClientAPI* LoginWithGoogleAccount(struct FClientLoginWithGoogleAccountRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.LoginWithGoogleAccount
	struct UPlayFabClientAPI* LoginWithGameCenter(struct FClientLoginWithGameCenterRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.LoginWithGameCenter
	struct UPlayFabClientAPI* LoginWithFacebookInstantGamesId(struct FClientLoginWithFacebookInstantGamesIdRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.LoginWithFacebookInstantGamesId
	struct UPlayFabClientAPI* LoginWithFacebook(struct FClientLoginWithFacebookRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.LoginWithFacebook
	struct UPlayFabClientAPI* LoginWithEmailAddress(struct FClientLoginWithEmailAddressRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.LoginWithEmailAddress
	struct UPlayFabClientAPI* LoginWithCustomID(struct FClientLoginWithCustomIDRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.LoginWithCustomID
	struct UPlayFabClientAPI* LoginWithApple(struct FClientLoginWithAppleRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.LoginWithApple
	struct UPlayFabClientAPI* LoginWithAndroidDeviceID(struct FClientLoginWithAndroidDeviceIDRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.LoginWithAndroidDeviceID
	struct UPlayFabClientAPI* LinkXboxAccount(struct FClientLinkXboxAccountRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.LinkXboxAccount
	struct UPlayFabClientAPI* LinkTwitch(struct FClientLinkTwitchAccountRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.LinkTwitch
	struct UPlayFabClientAPI* LinkSteamAccount(struct FClientLinkSteamAccountRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.LinkSteamAccount
	struct UPlayFabClientAPI* LinkPSNAccount(struct FClientLinkPSNAccountRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.LinkPSNAccount
	struct UPlayFabClientAPI* LinkOpenIdConnect(struct FClientLinkOpenIdConnectRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.LinkOpenIdConnect
	struct UPlayFabClientAPI* LinkNintendoSwitchDeviceId(struct FClientLinkNintendoSwitchDeviceIdRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.LinkNintendoSwitchDeviceId
	struct UPlayFabClientAPI* LinkNintendoServiceAccount(struct FClientLinkNintendoServiceAccountRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.LinkNintendoServiceAccount
	struct UPlayFabClientAPI* LinkKongregate(struct FClientLinkKongregateAccountRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.LinkKongregate
	struct UPlayFabClientAPI* LinkIOSDeviceID(struct FClientLinkIOSDeviceIDRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.LinkIOSDeviceID
	struct UPlayFabClientAPI* LinkGooglePlayGamesServicesAccount(struct FClientLinkGooglePlayGamesServicesAccountRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.LinkGooglePlayGamesServicesAccount
	struct UPlayFabClientAPI* LinkGoogleAccount(struct FClientLinkGoogleAccountRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.LinkGoogleAccount
	struct UPlayFabClientAPI* LinkGameCenterAccount(struct FClientLinkGameCenterAccountRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.LinkGameCenterAccount
	struct UPlayFabClientAPI* LinkFacebookInstantGamesId(struct FClientLinkFacebookInstantGamesIdRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.LinkFacebookInstantGamesId
	struct UPlayFabClientAPI* LinkFacebookAccount(struct FClientLinkFacebookAccountRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.LinkFacebookAccount
	struct UPlayFabClientAPI* LinkCustomID(struct FClientLinkCustomIDRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.LinkCustomID
	struct UPlayFabClientAPI* LinkApple(struct FClientLinkAppleRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.LinkApple
	struct UPlayFabClientAPI* LinkAndroidDeviceID(struct FClientLinkAndroidDeviceIDRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.LinkAndroidDeviceID
	void HelperWriteTitleEvent(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperWriteTitleEvent
	void HelperWritePlayerEvent(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperWritePlayerEvent
	void HelperWriteCharacterEvent(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperWriteCharacterEvent
	void HelperValidateWindowsStoreReceipt(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperValidateWindowsStoreReceipt
	void HelperValidateIOSReceipt(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperValidateIOSReceipt
	void HelperValidateGooglePlayPurchase(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperValidateGooglePlayPurchase
	void HelperValidateAmazonIAPReceipt(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperValidateAmazonIAPReceipt
	void HelperUpdateUserTitleDisplayName(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperUpdateUserTitleDisplayName
	void HelperUpdateUserPublisherData(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperUpdateUserPublisherData
	void HelperUpdateUserData(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperUpdateUserData
	void HelperUpdateSharedGroupData(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperUpdateSharedGroupData
	void HelperUpdatePlayerStatistics(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperUpdatePlayerStatistics
	void HelperUpdateCharacterStatistics(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperUpdateCharacterStatistics
	void HelperUpdateCharacterData(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperUpdateCharacterData
	void HelperUpdateAvatarUrl(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperUpdateAvatarUrl
	void HelperUnlockContainerItem(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperUnlockContainerItem
	void HelperUnlockContainerInstance(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperUnlockContainerInstance
	void HelperUnlinkXboxAccount(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperUnlinkXboxAccount
	void HelperUnlinkTwitch(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperUnlinkTwitch
	void HelperUnlinkSteamAccount(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperUnlinkSteamAccount
	void HelperUnlinkPSNAccount(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperUnlinkPSNAccount
	void HelperUnlinkOpenIdConnect(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperUnlinkOpenIdConnect
	void HelperUnlinkNintendoSwitchDeviceId(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperUnlinkNintendoSwitchDeviceId
	void HelperUnlinkNintendoServiceAccount(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperUnlinkNintendoServiceAccount
	void HelperUnlinkKongregate(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperUnlinkKongregate
	void HelperUnlinkIOSDeviceID(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperUnlinkIOSDeviceID
	void HelperUnlinkGooglePlayGamesServicesAccount(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperUnlinkGooglePlayGamesServicesAccount
	void HelperUnlinkGoogleAccount(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperUnlinkGoogleAccount
	void HelperUnlinkGameCenterAccount(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperUnlinkGameCenterAccount
	void HelperUnlinkFacebookInstantGamesId(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperUnlinkFacebookInstantGamesId
	void HelperUnlinkFacebookAccount(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperUnlinkFacebookAccount
	void HelperUnlinkCustomID(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperUnlinkCustomID
	void HelperUnlinkApple(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperUnlinkApple
	void HelperUnlinkAndroidDeviceID(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperUnlinkAndroidDeviceID
	void HelperSubtractUserVirtualCurrency(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperSubtractUserVirtualCurrency
	void HelperStartPurchase(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperStartPurchase
	void HelperSetPlayerSecret(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperSetPlayerSecret
	void HelperSetFriendTags(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperSetFriendTags
	void HelperSendAccountRecoveryEmail(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperSendAccountRecoveryEmail
	void HelperRewardAdActivity(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperRewardAdActivity
	void HelperRestoreIOSPurchases(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperRestoreIOSPurchases
	void HelperReportPlayer(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperReportPlayer
	void HelperReportDeviceInfo(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperReportDeviceInfo
	void HelperReportAdActivity(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperReportAdActivity
	void HelperRemoveSharedGroupMembers(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperRemoveSharedGroupMembers
	void HelperRemoveGenericID(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperRemoveGenericID
	void HelperRemoveFriend(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperRemoveFriend
	void HelperRemoveContactEmail(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperRemoveContactEmail
	void HelperRegisterPlayFabUser(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperRegisterPlayFabUser
	void HelperRegisterForIOSPushNotification(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperRegisterForIOSPushNotification
	void HelperRefreshPSNAuthToken(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperRefreshPSNAuthToken
	void HelperRedeemCoupon(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperRedeemCoupon
	void HelperPurchaseItem(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperPurchaseItem
	void HelperPayForPurchase(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperPayForPurchase
	void HelperOpenTrade(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperOpenTrade
	void HelperMatchmake(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperMatchmake
	void HelperLoginWithXbox(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperLoginWithXbox
	void HelperLoginWithTwitch(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperLoginWithTwitch
	void HelperLoginWithSteam(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperLoginWithSteam
	void HelperLoginWithPSN(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperLoginWithPSN
	void HelperLoginWithPlayFab(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperLoginWithPlayFab
	void HelperLoginWithOpenIdConnect(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperLoginWithOpenIdConnect
	void HelperLoginWithNintendoSwitchDeviceId(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperLoginWithNintendoSwitchDeviceId
	void HelperLoginWithNintendoServiceAccount(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperLoginWithNintendoServiceAccount
	void HelperLoginWithKongregate(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperLoginWithKongregate
	void HelperLoginWithIOSDeviceID(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperLoginWithIOSDeviceID
	void HelperLoginWithGooglePlayGamesServices(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperLoginWithGooglePlayGamesServices
	void HelperLoginWithGoogleAccount(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperLoginWithGoogleAccount
	void HelperLoginWithGameCenter(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperLoginWithGameCenter
	void HelperLoginWithFacebookInstantGamesId(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperLoginWithFacebookInstantGamesId
	void HelperLoginWithFacebook(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperLoginWithFacebook
	void HelperLoginWithEmailAddress(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperLoginWithEmailAddress
	void HelperLoginWithCustomID(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperLoginWithCustomID
	void HelperLoginWithApple(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperLoginWithApple
	void HelperLoginWithAndroidDeviceID(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperLoginWithAndroidDeviceID
	void HelperLinkXboxAccount(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperLinkXboxAccount
	void HelperLinkTwitch(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperLinkTwitch
	void HelperLinkSteamAccount(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperLinkSteamAccount
	void HelperLinkPSNAccount(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperLinkPSNAccount
	void HelperLinkOpenIdConnect(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperLinkOpenIdConnect
	void HelperLinkNintendoSwitchDeviceId(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperLinkNintendoSwitchDeviceId
	void HelperLinkNintendoServiceAccount(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperLinkNintendoServiceAccount
	void HelperLinkKongregate(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperLinkKongregate
	void HelperLinkIOSDeviceID(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperLinkIOSDeviceID
	void HelperLinkGooglePlayGamesServicesAccount(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperLinkGooglePlayGamesServicesAccount
	void HelperLinkGoogleAccount(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperLinkGoogleAccount
	void HelperLinkGameCenterAccount(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperLinkGameCenterAccount
	void HelperLinkFacebookInstantGamesId(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperLinkFacebookInstantGamesId
	void HelperLinkFacebookAccount(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperLinkFacebookAccount
	void HelperLinkCustomID(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperLinkCustomID
	void HelperLinkApple(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperLinkApple
	void HelperLinkAndroidDeviceID(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperLinkAndroidDeviceID
	void HelperGrantCharacterToUser(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperGrantCharacterToUser
	void HelperGetUserReadOnlyData(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperGetUserReadOnlyData
	void HelperGetUserPublisherReadOnlyData(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperGetUserPublisherReadOnlyData
	void HelperGetUserPublisherData(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperGetUserPublisherData
	void HelperGetUserInventory(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperGetUserInventory
	void HelperGetUserData(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperGetUserData
	void HelperGetTradeStatus(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperGetTradeStatus
	void HelperGetTitlePublicKey(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperGetTitlePublicKey
	void HelperGetTitleNews(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperGetTitleNews
	void HelperGetTitleData(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperGetTitleData
	void HelperGetTime(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperGetTime
	void HelperGetStoreItems(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperGetStoreItems
	void HelperGetSharedGroupData(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperGetSharedGroupData
	void HelperGetPurchase(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperGetPurchase
	void HelperGetPublisherData(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperGetPublisherData
	void HelperGetPlayFabIDsFromXboxLiveIDs(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperGetPlayFabIDsFromXboxLiveIDs
	void HelperGetPlayFabIDsFromTwitchIDs(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperGetPlayFabIDsFromTwitchIDs
	void HelperGetPlayFabIDsFromSteamIDs(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperGetPlayFabIDsFromSteamIDs
	void HelperGetPlayFabIDsFromPSNAccountIDs(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperGetPlayFabIDsFromPSNAccountIDs
	void HelperGetPlayFabIDsFromNintendoSwitchDeviceIds(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperGetPlayFabIDsFromNintendoSwitchDeviceIds
	void HelperGetPlayFabIDsFromNintendoServiceAccountIds(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperGetPlayFabIDsFromNintendoServiceAccountIds
	void HelperGetPlayFabIDsFromKongregateIDs(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperGetPlayFabIDsFromKongregateIDs
	void HelperGetPlayFabIDsFromGooglePlayGamesPlayerIDs(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperGetPlayFabIDsFromGooglePlayGamesPlayerIDs
	void HelperGetPlayFabIDsFromGoogleIDs(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperGetPlayFabIDsFromGoogleIDs
	void HelperGetPlayFabIDsFromGenericIDs(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperGetPlayFabIDsFromGenericIDs
	void HelperGetPlayFabIDsFromGameCenterIDs(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperGetPlayFabIDsFromGameCenterIDs
	void HelperGetPlayFabIDsFromFacebookInstantGamesIds(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperGetPlayFabIDsFromFacebookInstantGamesIds
	void HelperGetPlayFabIDsFromFacebookIDs(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperGetPlayFabIDsFromFacebookIDs
	void HelperGetPlayerTrades(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperGetPlayerTrades
	void HelperGetPlayerTags(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperGetPlayerTags
	void HelperGetPlayerStatisticVersions(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperGetPlayerStatisticVersions
	void HelperGetPlayerStatistics(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperGetPlayerStatistics
	void HelperGetPlayerSegments(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperGetPlayerSegments
	void HelperGetPlayerProfile(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperGetPlayerProfile
	void HelperGetPlayerCombinedInfo(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperGetPlayerCombinedInfo
	void HelperGetPhotonAuthenticationToken(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperGetPhotonAuthenticationToken
	void HelperGetPaymentToken(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperGetPaymentToken
	void HelperGetLeaderboardForUserCharacters(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperGetLeaderboardForUserCharacters
	void HelperGetLeaderboardAroundPlayer(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperGetLeaderboardAroundPlayer
	void HelperGetLeaderboardAroundCharacter(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperGetLeaderboardAroundCharacter
	void HelperGetLeaderboard(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperGetLeaderboard
	void HelperGetGameServerRegions(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperGetGameServerRegions
	void HelperGetFriendsList(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperGetFriendsList
	void HelperGetFriendLeaderboardAroundPlayer(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperGetFriendLeaderboardAroundPlayer
	void HelperGetFriendLeaderboard(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperGetFriendLeaderboard
	void HelperGetCurrentGames(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperGetCurrentGames
	void HelperGetContentDownloadUrl(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperGetContentDownloadUrl
	void HelperGetCharacterStatistics(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperGetCharacterStatistics
	void HelperGetCharacterReadOnlyData(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperGetCharacterReadOnlyData
	void HelperGetCharacterLeaderboard(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperGetCharacterLeaderboard
	void HelperGetCharacterInventory(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperGetCharacterInventory
	void HelperGetCharacterData(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperGetCharacterData
	void HelperGetCatalogItems(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperGetCatalogItems
	void HelperGetAllUsersCharacters(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperGetAllUsersCharacters
	void HelperGetAdPlacements(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperGetAdPlacements
	void HelperGetAccountInfo(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperGetAccountInfo
	void HelperExecuteCloudScript(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperExecuteCloudScript
	void HelperCreateSharedGroup(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperCreateSharedGroup
	void HelperConsumeXboxEntitlements(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperConsumeXboxEntitlements
	void HelperConsumePSNEntitlements(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperConsumePSNEntitlements
	void HelperConsumePS5Entitlements(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperConsumePS5Entitlements
	void HelperConsumeMicrosoftStoreEntitlements(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperConsumeMicrosoftStoreEntitlements
	void HelperConsumeItem(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperConsumeItem
	void HelperConfirmPurchase(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperConfirmPurchase
	void HelperCancelTrade(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperCancelTrade
	void HelperAttributeInstall(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperAttributeInstall
	void HelperAndroidDevicePushNotificationRegistration(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperAndroidDevicePushNotificationRegistration
	void HelperAddUserVirtualCurrency(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperAddUserVirtualCurrency
	void HelperAddUsernamePassword(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperAddUsernamePassword
	void HelperAddSharedGroupMembers(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperAddSharedGroupMembers
	void HelperAddOrUpdateContactEmail(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperAddOrUpdateContactEmail
	void HelperAddGenericID(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperAddGenericID
	void HelperAddFriend(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperAddFriend
	void HelperAcceptTrade(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabClientAPI.HelperAcceptTrade
	struct UPlayFabClientAPI* GrantCharacterToUser(struct FClientGrantCharacterToUserRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.GrantCharacterToUser
	struct UPlayFabClientAPI* GetUserReadOnlyData(struct FClientGetUserDataRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.GetUserReadOnlyData
	struct UPlayFabClientAPI* GetUserPublisherReadOnlyData(struct FClientGetUserDataRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.GetUserPublisherReadOnlyData
	struct UPlayFabClientAPI* GetUserPublisherData(struct FClientGetUserDataRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.GetUserPublisherData
	struct UPlayFabClientAPI* GetUserInventory(struct FClientGetUserInventoryRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.GetUserInventory
	struct UPlayFabClientAPI* GetUserData(struct FClientGetUserDataRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.GetUserData
	struct UPlayFabClientAPI* GetTradeStatus(struct FClientGetTradeStatusRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.GetTradeStatus
	struct UPlayFabClientAPI* GetTitlePublicKey(struct FClientGetTitlePublicKeyRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.GetTitlePublicKey
	struct UPlayFabClientAPI* GetTitleNews(struct FClientGetTitleNewsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.GetTitleNews
	struct UPlayFabClientAPI* GetTitleData(struct FClientGetTitleDataRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.GetTitleData
	struct UPlayFabClientAPI* GetTime(struct FClientGetTimeRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.GetTime
	struct UPlayFabClientAPI* GetStoreItems(struct FClientGetStoreItemsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.GetStoreItems
	struct UPlayFabClientAPI* GetSharedGroupData(struct FClientGetSharedGroupDataRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.GetSharedGroupData
	struct UPlayFabClientAPI* GetPurchase(struct FClientGetPurchaseRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.GetPurchase
	struct UPlayFabClientAPI* GetPublisherData(struct FClientGetPublisherDataRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.GetPublisherData
	struct UPlayFabClientAPI* GetPlayFabIDsFromXboxLiveIDs(struct FClientGetPlayFabIDsFromXboxLiveIDsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.GetPlayFabIDsFromXboxLiveIDs
	struct UPlayFabClientAPI* GetPlayFabIDsFromTwitchIDs(struct FClientGetPlayFabIDsFromTwitchIDsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.GetPlayFabIDsFromTwitchIDs
	struct UPlayFabClientAPI* GetPlayFabIDsFromSteamIDs(struct FClientGetPlayFabIDsFromSteamIDsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.GetPlayFabIDsFromSteamIDs
	struct UPlayFabClientAPI* GetPlayFabIDsFromPSNAccountIDs(struct FClientGetPlayFabIDsFromPSNAccountIDsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.GetPlayFabIDsFromPSNAccountIDs
	struct UPlayFabClientAPI* GetPlayFabIDsFromNintendoSwitchDeviceIds(struct FClientGetPlayFabIDsFromNintendoSwitchDeviceIdsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.GetPlayFabIDsFromNintendoSwitchDeviceIds
	struct UPlayFabClientAPI* GetPlayFabIDsFromNintendoServiceAccountIds(struct FClientGetPlayFabIDsFromNintendoServiceAccountIdsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.GetPlayFabIDsFromNintendoServiceAccountIds
	struct UPlayFabClientAPI* GetPlayFabIDsFromKongregateIDs(struct FClientGetPlayFabIDsFromKongregateIDsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.GetPlayFabIDsFromKongregateIDs
	struct UPlayFabClientAPI* GetPlayFabIDsFromGooglePlayGamesPlayerIDs(struct FClientGetPlayFabIDsFromGooglePlayGamesPlayerIDsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.GetPlayFabIDsFromGooglePlayGamesPlayerIDs
	struct UPlayFabClientAPI* GetPlayFabIDsFromGoogleIDs(struct FClientGetPlayFabIDsFromGoogleIDsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.GetPlayFabIDsFromGoogleIDs
	struct UPlayFabClientAPI* GetPlayFabIDsFromGenericIDs(struct FClientGetPlayFabIDsFromGenericIDsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.GetPlayFabIDsFromGenericIDs
	struct UPlayFabClientAPI* GetPlayFabIDsFromGameCenterIDs(struct FClientGetPlayFabIDsFromGameCenterIDsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.GetPlayFabIDsFromGameCenterIDs
	struct UPlayFabClientAPI* GetPlayFabIDsFromFacebookInstantGamesIds(struct FClientGetPlayFabIDsFromFacebookInstantGamesIdsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.GetPlayFabIDsFromFacebookInstantGamesIds
	struct UPlayFabClientAPI* GetPlayFabIDsFromFacebookIDs(struct FClientGetPlayFabIDsFromFacebookIDsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.GetPlayFabIDsFromFacebookIDs
	struct UPlayFabClientAPI* GetPlayerTrades(struct FClientGetPlayerTradesRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.GetPlayerTrades
	struct UPlayFabClientAPI* GetPlayerTags(struct FClientGetPlayerTagsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.GetPlayerTags
	struct UPlayFabClientAPI* GetPlayerStatisticVersions(struct FClientGetPlayerStatisticVersionsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.GetPlayerStatisticVersions
	struct UPlayFabClientAPI* GetPlayerStatistics(struct FClientGetPlayerStatisticsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.GetPlayerStatistics
	struct UPlayFabClientAPI* GetPlayerSegments(struct FClientGetPlayerSegmentsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.GetPlayerSegments
	struct UPlayFabClientAPI* GetPlayerProfile(struct FClientGetPlayerProfileRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.GetPlayerProfile
	struct UPlayFabClientAPI* GetPlayerCombinedInfo(struct FClientGetPlayerCombinedInfoRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.GetPlayerCombinedInfo
	struct UPlayFabClientAPI* GetPhotonAuthenticationToken(struct FClientGetPhotonAuthenticationTokenRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.GetPhotonAuthenticationToken
	struct UPlayFabClientAPI* GetPaymentToken(struct FClientGetPaymentTokenRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.GetPaymentToken
	struct UPlayFabClientAPI* GetLeaderboardForUserCharacters(struct FClientGetLeaderboardForUsersCharactersRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.GetLeaderboardForUserCharacters
	struct UPlayFabClientAPI* GetLeaderboardAroundPlayer(struct FClientGetLeaderboardAroundPlayerRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.GetLeaderboardAroundPlayer
	struct UPlayFabClientAPI* GetLeaderboardAroundCharacter(struct FClientGetLeaderboardAroundCharacterRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.GetLeaderboardAroundCharacter
	struct UPlayFabClientAPI* GetLeaderboard(struct FClientGetLeaderboardRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.GetLeaderboard
	struct UPlayFabClientAPI* GetGameServerRegions(struct FClientGameServerRegionsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.GetGameServerRegions
	struct UPlayFabClientAPI* GetFriendsList(struct FClientGetFriendsListRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.GetFriendsList
	struct UPlayFabClientAPI* GetFriendLeaderboardAroundPlayer(struct FClientGetFriendLeaderboardAroundPlayerRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.GetFriendLeaderboardAroundPlayer
	struct UPlayFabClientAPI* GetFriendLeaderboard(struct FClientGetFriendLeaderboardRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.GetFriendLeaderboard
	struct UPlayFabClientAPI* GetCurrentGames(struct FClientCurrentGamesRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.GetCurrentGames
	struct UPlayFabClientAPI* GetContentDownloadUrl(struct FClientGetContentDownloadUrlRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.GetContentDownloadUrl
	struct UPlayFabClientAPI* GetCharacterStatistics(struct FClientGetCharacterStatisticsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.GetCharacterStatistics
	struct UPlayFabClientAPI* GetCharacterReadOnlyData(struct FClientGetCharacterDataRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.GetCharacterReadOnlyData
	struct UPlayFabClientAPI* GetCharacterLeaderboard(struct FClientGetCharacterLeaderboardRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.GetCharacterLeaderboard
	struct UPlayFabClientAPI* GetCharacterInventory(struct FClientGetCharacterInventoryRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.GetCharacterInventory
	struct UPlayFabClientAPI* GetCharacterData(struct FClientGetCharacterDataRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.GetCharacterData
	struct UPlayFabClientAPI* GetCatalogItems(struct FClientGetCatalogItemsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.GetCatalogItems
	struct UPlayFabClientAPI* GetAllUsersCharacters(struct FClientListUsersCharactersRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.GetAllUsersCharacters
	struct UPlayFabClientAPI* GetAdPlacements(struct FClientGetAdPlacementsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.GetAdPlacements
	struct UPlayFabClientAPI* GetAccountInfo(struct FClientGetAccountInfoRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.GetAccountInfo
	struct UPlayFabClientAPI* ExecuteCloudScript(struct FClientExecuteCloudScriptRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.ExecuteCloudScript
	void DelegateOnSuccessWriteTitleEvent__DelegateSignature(struct FClientWriteEventResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessWriteTitleEvent__DelegateSignature
	void DelegateOnSuccessWritePlayerEvent__DelegateSignature(struct FClientWriteEventResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessWritePlayerEvent__DelegateSignature
	void DelegateOnSuccessWriteCharacterEvent__DelegateSignature(struct FClientWriteEventResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessWriteCharacterEvent__DelegateSignature
	void DelegateOnSuccessValidateWindowsStoreReceipt__DelegateSignature(struct FClientValidateWindowsReceiptResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessValidateWindowsStoreReceipt__DelegateSignature
	void DelegateOnSuccessValidateIOSReceipt__DelegateSignature(struct FClientValidateIOSReceiptResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessValidateIOSReceipt__DelegateSignature
	void DelegateOnSuccessValidateGooglePlayPurchase__DelegateSignature(struct FClientValidateGooglePlayPurchaseResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessValidateGooglePlayPurchase__DelegateSignature
	void DelegateOnSuccessValidateAmazonIAPReceipt__DelegateSignature(struct FClientValidateAmazonReceiptResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessValidateAmazonIAPReceipt__DelegateSignature
	void DelegateOnSuccessUpdateUserTitleDisplayName__DelegateSignature(struct FClientUpdateUserTitleDisplayNameResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessUpdateUserTitleDisplayName__DelegateSignature
	void DelegateOnSuccessUpdateUserPublisherData__DelegateSignature(struct FClientUpdateUserDataResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessUpdateUserPublisherData__DelegateSignature
	void DelegateOnSuccessUpdateUserData__DelegateSignature(struct FClientUpdateUserDataResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessUpdateUserData__DelegateSignature
	void DelegateOnSuccessUpdateSharedGroupData__DelegateSignature(struct FClientUpdateSharedGroupDataResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessUpdateSharedGroupData__DelegateSignature
	void DelegateOnSuccessUpdatePlayerStatistics__DelegateSignature(struct FClientUpdatePlayerStatisticsResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessUpdatePlayerStatistics__DelegateSignature
	void DelegateOnSuccessUpdateCharacterStatistics__DelegateSignature(struct FClientUpdateCharacterStatisticsResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessUpdateCharacterStatistics__DelegateSignature
	void DelegateOnSuccessUpdateCharacterData__DelegateSignature(struct FClientUpdateCharacterDataResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessUpdateCharacterData__DelegateSignature
	void DelegateOnSuccessUpdateAvatarUrl__DelegateSignature(struct FClientEmptyResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessUpdateAvatarUrl__DelegateSignature
	void DelegateOnSuccessUnlockContainerItem__DelegateSignature(struct FClientUnlockContainerItemResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessUnlockContainerItem__DelegateSignature
	void DelegateOnSuccessUnlockContainerInstance__DelegateSignature(struct FClientUnlockContainerItemResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessUnlockContainerInstance__DelegateSignature
	void DelegateOnSuccessUnlinkXboxAccount__DelegateSignature(struct FClientUnlinkXboxAccountResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessUnlinkXboxAccount__DelegateSignature
	void DelegateOnSuccessUnlinkTwitch__DelegateSignature(struct FClientUnlinkTwitchAccountResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessUnlinkTwitch__DelegateSignature
	void DelegateOnSuccessUnlinkSteamAccount__DelegateSignature(struct FClientUnlinkSteamAccountResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessUnlinkSteamAccount__DelegateSignature
	void DelegateOnSuccessUnlinkPSNAccount__DelegateSignature(struct FClientUnlinkPSNAccountResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessUnlinkPSNAccount__DelegateSignature
	void DelegateOnSuccessUnlinkOpenIdConnect__DelegateSignature(struct FClientEmptyResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessUnlinkOpenIdConnect__DelegateSignature
	void DelegateOnSuccessUnlinkNintendoSwitchDeviceId__DelegateSignature(struct FClientUnlinkNintendoSwitchDeviceIdResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessUnlinkNintendoSwitchDeviceId__DelegateSignature
	void DelegateOnSuccessUnlinkNintendoServiceAccount__DelegateSignature(struct FClientEmptyResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessUnlinkNintendoServiceAccount__DelegateSignature
	void DelegateOnSuccessUnlinkKongregate__DelegateSignature(struct FClientUnlinkKongregateAccountResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessUnlinkKongregate__DelegateSignature
	void DelegateOnSuccessUnlinkIOSDeviceID__DelegateSignature(struct FClientUnlinkIOSDeviceIDResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessUnlinkIOSDeviceID__DelegateSignature
	void DelegateOnSuccessUnlinkGooglePlayGamesServicesAccount__DelegateSignature(struct FClientUnlinkGooglePlayGamesServicesAccountResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessUnlinkGooglePlayGamesServicesAccount__DelegateSignature
	void DelegateOnSuccessUnlinkGoogleAccount__DelegateSignature(struct FClientUnlinkGoogleAccountResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessUnlinkGoogleAccount__DelegateSignature
	void DelegateOnSuccessUnlinkGameCenterAccount__DelegateSignature(struct FClientUnlinkGameCenterAccountResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessUnlinkGameCenterAccount__DelegateSignature
	void DelegateOnSuccessUnlinkFacebookInstantGamesId__DelegateSignature(struct FClientUnlinkFacebookInstantGamesIdResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessUnlinkFacebookInstantGamesId__DelegateSignature
	void DelegateOnSuccessUnlinkFacebookAccount__DelegateSignature(struct FClientUnlinkFacebookAccountResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessUnlinkFacebookAccount__DelegateSignature
	void DelegateOnSuccessUnlinkCustomID__DelegateSignature(struct FClientUnlinkCustomIDResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessUnlinkCustomID__DelegateSignature
	void DelegateOnSuccessUnlinkApple__DelegateSignature(struct FClientEmptyResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessUnlinkApple__DelegateSignature
	void DelegateOnSuccessUnlinkAndroidDeviceID__DelegateSignature(struct FClientUnlinkAndroidDeviceIDResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessUnlinkAndroidDeviceID__DelegateSignature
	void DelegateOnSuccessSubtractUserVirtualCurrency__DelegateSignature(struct FClientModifyUserVirtualCurrencyResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessSubtractUserVirtualCurrency__DelegateSignature
	void DelegateOnSuccessStartPurchase__DelegateSignature(struct FClientStartPurchaseResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessStartPurchase__DelegateSignature
	void DelegateOnSuccessSetPlayerSecret__DelegateSignature(struct FClientSetPlayerSecretResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessSetPlayerSecret__DelegateSignature
	void DelegateOnSuccessSetFriendTags__DelegateSignature(struct FClientSetFriendTagsResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessSetFriendTags__DelegateSignature
	void DelegateOnSuccessSendAccountRecoveryEmail__DelegateSignature(struct FClientSendAccountRecoveryEmailResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessSendAccountRecoveryEmail__DelegateSignature
	void DelegateOnSuccessRewardAdActivity__DelegateSignature(struct FClientRewardAdActivityResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessRewardAdActivity__DelegateSignature
	void DelegateOnSuccessRestoreIOSPurchases__DelegateSignature(struct FClientRestoreIOSPurchasesResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessRestoreIOSPurchases__DelegateSignature
	void DelegateOnSuccessReportPlayer__DelegateSignature(struct FClientReportPlayerClientResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessReportPlayer__DelegateSignature
	void DelegateOnSuccessReportDeviceInfo__DelegateSignature(struct FClientEmptyResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessReportDeviceInfo__DelegateSignature
	void DelegateOnSuccessReportAdActivity__DelegateSignature(struct FClientReportAdActivityResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessReportAdActivity__DelegateSignature
	void DelegateOnSuccessRemoveSharedGroupMembers__DelegateSignature(struct FClientRemoveSharedGroupMembersResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessRemoveSharedGroupMembers__DelegateSignature
	void DelegateOnSuccessRemoveGenericID__DelegateSignature(struct FClientRemoveGenericIDResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessRemoveGenericID__DelegateSignature
	void DelegateOnSuccessRemoveFriend__DelegateSignature(struct FClientRemoveFriendResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessRemoveFriend__DelegateSignature
	void DelegateOnSuccessRemoveContactEmail__DelegateSignature(struct FClientRemoveContactEmailResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessRemoveContactEmail__DelegateSignature
	void DelegateOnSuccessRegisterPlayFabUser__DelegateSignature(struct FClientRegisterPlayFabUserResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessRegisterPlayFabUser__DelegateSignature
	void DelegateOnSuccessRegisterForIOSPushNotification__DelegateSignature(struct FClientRegisterForIOSPushNotificationResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessRegisterForIOSPushNotification__DelegateSignature
	void DelegateOnSuccessRefreshPSNAuthToken__DelegateSignature(struct FClientEmptyResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessRefreshPSNAuthToken__DelegateSignature
	void DelegateOnSuccessRedeemCoupon__DelegateSignature(struct FClientRedeemCouponResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessRedeemCoupon__DelegateSignature
	void DelegateOnSuccessPurchaseItem__DelegateSignature(struct FClientPurchaseItemResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessPurchaseItem__DelegateSignature
	void DelegateOnSuccessPayForPurchase__DelegateSignature(struct FClientPayForPurchaseResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessPayForPurchase__DelegateSignature
	void DelegateOnSuccessOpenTrade__DelegateSignature(struct FClientOpenTradeResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessOpenTrade__DelegateSignature
	void DelegateOnSuccessMatchmake__DelegateSignature(struct FClientMatchmakeResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessMatchmake__DelegateSignature
	void DelegateOnSuccessLoginWithXbox__DelegateSignature(struct FClientLoginResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessLoginWithXbox__DelegateSignature
	void DelegateOnSuccessLoginWithTwitch__DelegateSignature(struct FClientLoginResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessLoginWithTwitch__DelegateSignature
	void DelegateOnSuccessLoginWithSteam__DelegateSignature(struct FClientLoginResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessLoginWithSteam__DelegateSignature
	void DelegateOnSuccessLoginWithPSN__DelegateSignature(struct FClientLoginResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessLoginWithPSN__DelegateSignature
	void DelegateOnSuccessLoginWithPlayFab__DelegateSignature(struct FClientLoginResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessLoginWithPlayFab__DelegateSignature
	void DelegateOnSuccessLoginWithOpenIdConnect__DelegateSignature(struct FClientLoginResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessLoginWithOpenIdConnect__DelegateSignature
	void DelegateOnSuccessLoginWithNintendoSwitchDeviceId__DelegateSignature(struct FClientLoginResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessLoginWithNintendoSwitchDeviceId__DelegateSignature
	void DelegateOnSuccessLoginWithNintendoServiceAccount__DelegateSignature(struct FClientLoginResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessLoginWithNintendoServiceAccount__DelegateSignature
	void DelegateOnSuccessLoginWithKongregate__DelegateSignature(struct FClientLoginResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessLoginWithKongregate__DelegateSignature
	void DelegateOnSuccessLoginWithIOSDeviceID__DelegateSignature(struct FClientLoginResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessLoginWithIOSDeviceID__DelegateSignature
	void DelegateOnSuccessLoginWithGooglePlayGamesServices__DelegateSignature(struct FClientLoginResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessLoginWithGooglePlayGamesServices__DelegateSignature
	void DelegateOnSuccessLoginWithGoogleAccount__DelegateSignature(struct FClientLoginResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessLoginWithGoogleAccount__DelegateSignature
	void DelegateOnSuccessLoginWithGameCenter__DelegateSignature(struct FClientLoginResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessLoginWithGameCenter__DelegateSignature
	void DelegateOnSuccessLoginWithFacebookInstantGamesId__DelegateSignature(struct FClientLoginResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessLoginWithFacebookInstantGamesId__DelegateSignature
	void DelegateOnSuccessLoginWithFacebook__DelegateSignature(struct FClientLoginResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessLoginWithFacebook__DelegateSignature
	void DelegateOnSuccessLoginWithEmailAddress__DelegateSignature(struct FClientLoginResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessLoginWithEmailAddress__DelegateSignature
	void DelegateOnSuccessLoginWithCustomID__DelegateSignature(struct FClientLoginResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessLoginWithCustomID__DelegateSignature
	void DelegateOnSuccessLoginWithApple__DelegateSignature(struct FClientLoginResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessLoginWithApple__DelegateSignature
	void DelegateOnSuccessLoginWithAndroidDeviceID__DelegateSignature(struct FClientLoginResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessLoginWithAndroidDeviceID__DelegateSignature
	void DelegateOnSuccessLinkXboxAccount__DelegateSignature(struct FClientLinkXboxAccountResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessLinkXboxAccount__DelegateSignature
	void DelegateOnSuccessLinkTwitch__DelegateSignature(struct FClientLinkTwitchAccountResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessLinkTwitch__DelegateSignature
	void DelegateOnSuccessLinkSteamAccount__DelegateSignature(struct FClientLinkSteamAccountResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessLinkSteamAccount__DelegateSignature
	void DelegateOnSuccessLinkPSNAccount__DelegateSignature(struct FClientLinkPSNAccountResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessLinkPSNAccount__DelegateSignature
	void DelegateOnSuccessLinkOpenIdConnect__DelegateSignature(struct FClientEmptyResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessLinkOpenIdConnect__DelegateSignature
	void DelegateOnSuccessLinkNintendoSwitchDeviceId__DelegateSignature(struct FClientLinkNintendoSwitchDeviceIdResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessLinkNintendoSwitchDeviceId__DelegateSignature
	void DelegateOnSuccessLinkNintendoServiceAccount__DelegateSignature(struct FClientEmptyResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessLinkNintendoServiceAccount__DelegateSignature
	void DelegateOnSuccessLinkKongregate__DelegateSignature(struct FClientLinkKongregateAccountResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessLinkKongregate__DelegateSignature
	void DelegateOnSuccessLinkIOSDeviceID__DelegateSignature(struct FClientLinkIOSDeviceIDResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessLinkIOSDeviceID__DelegateSignature
	void DelegateOnSuccessLinkGooglePlayGamesServicesAccount__DelegateSignature(struct FClientLinkGooglePlayGamesServicesAccountResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessLinkGooglePlayGamesServicesAccount__DelegateSignature
	void DelegateOnSuccessLinkGoogleAccount__DelegateSignature(struct FClientLinkGoogleAccountResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessLinkGoogleAccount__DelegateSignature
	void DelegateOnSuccessLinkGameCenterAccount__DelegateSignature(struct FClientLinkGameCenterAccountResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessLinkGameCenterAccount__DelegateSignature
	void DelegateOnSuccessLinkFacebookInstantGamesId__DelegateSignature(struct FClientLinkFacebookInstantGamesIdResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessLinkFacebookInstantGamesId__DelegateSignature
	void DelegateOnSuccessLinkFacebookAccount__DelegateSignature(struct FClientLinkFacebookAccountResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessLinkFacebookAccount__DelegateSignature
	void DelegateOnSuccessLinkCustomID__DelegateSignature(struct FClientLinkCustomIDResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessLinkCustomID__DelegateSignature
	void DelegateOnSuccessLinkApple__DelegateSignature(struct FClientEmptyResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessLinkApple__DelegateSignature
	void DelegateOnSuccessLinkAndroidDeviceID__DelegateSignature(struct FClientLinkAndroidDeviceIDResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessLinkAndroidDeviceID__DelegateSignature
	void DelegateOnSuccessGrantCharacterToUser__DelegateSignature(struct FClientGrantCharacterToUserResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessGrantCharacterToUser__DelegateSignature
	void DelegateOnSuccessGetUserReadOnlyData__DelegateSignature(struct FClientGetUserDataResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessGetUserReadOnlyData__DelegateSignature
	void DelegateOnSuccessGetUserPublisherReadOnlyData__DelegateSignature(struct FClientGetUserDataResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessGetUserPublisherReadOnlyData__DelegateSignature
	void DelegateOnSuccessGetUserPublisherData__DelegateSignature(struct FClientGetUserDataResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessGetUserPublisherData__DelegateSignature
	void DelegateOnSuccessGetUserInventory__DelegateSignature(struct FClientGetUserInventoryResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessGetUserInventory__DelegateSignature
	void DelegateOnSuccessGetUserData__DelegateSignature(struct FClientGetUserDataResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessGetUserData__DelegateSignature
	void DelegateOnSuccessGetTradeStatus__DelegateSignature(struct FClientGetTradeStatusResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessGetTradeStatus__DelegateSignature
	void DelegateOnSuccessGetTitlePublicKey__DelegateSignature(struct FClientGetTitlePublicKeyResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessGetTitlePublicKey__DelegateSignature
	void DelegateOnSuccessGetTitleNews__DelegateSignature(struct FClientGetTitleNewsResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessGetTitleNews__DelegateSignature
	void DelegateOnSuccessGetTitleData__DelegateSignature(struct FClientGetTitleDataResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessGetTitleData__DelegateSignature
	void DelegateOnSuccessGetTime__DelegateSignature(struct FClientGetTimeResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessGetTime__DelegateSignature
	void DelegateOnSuccessGetStoreItems__DelegateSignature(struct FClientGetStoreItemsResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessGetStoreItems__DelegateSignature
	void DelegateOnSuccessGetSharedGroupData__DelegateSignature(struct FClientGetSharedGroupDataResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessGetSharedGroupData__DelegateSignature
	void DelegateOnSuccessGetPurchase__DelegateSignature(struct FClientGetPurchaseResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessGetPurchase__DelegateSignature
	void DelegateOnSuccessGetPublisherData__DelegateSignature(struct FClientGetPublisherDataResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessGetPublisherData__DelegateSignature
	void DelegateOnSuccessGetPlayFabIDsFromXboxLiveIDs__DelegateSignature(struct FClientGetPlayFabIDsFromXboxLiveIDsResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessGetPlayFabIDsFromXboxLiveIDs__DelegateSignature
	void DelegateOnSuccessGetPlayFabIDsFromTwitchIDs__DelegateSignature(struct FClientGetPlayFabIDsFromTwitchIDsResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessGetPlayFabIDsFromTwitchIDs__DelegateSignature
	void DelegateOnSuccessGetPlayFabIDsFromSteamIDs__DelegateSignature(struct FClientGetPlayFabIDsFromSteamIDsResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessGetPlayFabIDsFromSteamIDs__DelegateSignature
	void DelegateOnSuccessGetPlayFabIDsFromPSNAccountIDs__DelegateSignature(struct FClientGetPlayFabIDsFromPSNAccountIDsResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessGetPlayFabIDsFromPSNAccountIDs__DelegateSignature
	void DelegateOnSuccessGetPlayFabIDsFromNintendoSwitchDeviceIds__DelegateSignature(struct FClientGetPlayFabIDsFromNintendoSwitchDeviceIdsResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessGetPlayFabIDsFromNintendoSwitchDeviceIds__DelegateSignature
	void DelegateOnSuccessGetPlayFabIDsFromNintendoServiceAccountIds__DelegateSignature(struct FClientGetPlayFabIDsFromNintendoServiceAccountIdsResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessGetPlayFabIDsFromNintendoServiceAccountIds__DelegateSignature
	void DelegateOnSuccessGetPlayFabIDsFromKongregateIDs__DelegateSignature(struct FClientGetPlayFabIDsFromKongregateIDsResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessGetPlayFabIDsFromKongregateIDs__DelegateSignature
	void DelegateOnSuccessGetPlayFabIDsFromGooglePlayGamesPlayerIDs__DelegateSignature(struct FClientGetPlayFabIDsFromGooglePlayGamesPlayerIDsResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessGetPlayFabIDsFromGooglePlayGamesPlayerIDs__DelegateSignature
	void DelegateOnSuccessGetPlayFabIDsFromGoogleIDs__DelegateSignature(struct FClientGetPlayFabIDsFromGoogleIDsResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessGetPlayFabIDsFromGoogleIDs__DelegateSignature
	void DelegateOnSuccessGetPlayFabIDsFromGenericIDs__DelegateSignature(struct FClientGetPlayFabIDsFromGenericIDsResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessGetPlayFabIDsFromGenericIDs__DelegateSignature
	void DelegateOnSuccessGetPlayFabIDsFromGameCenterIDs__DelegateSignature(struct FClientGetPlayFabIDsFromGameCenterIDsResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessGetPlayFabIDsFromGameCenterIDs__DelegateSignature
	void DelegateOnSuccessGetPlayFabIDsFromFacebookInstantGamesIds__DelegateSignature(struct FClientGetPlayFabIDsFromFacebookInstantGamesIdsResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessGetPlayFabIDsFromFacebookInstantGamesIds__DelegateSignature
	void DelegateOnSuccessGetPlayFabIDsFromFacebookIDs__DelegateSignature(struct FClientGetPlayFabIDsFromFacebookIDsResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessGetPlayFabIDsFromFacebookIDs__DelegateSignature
	void DelegateOnSuccessGetPlayerTrades__DelegateSignature(struct FClientGetPlayerTradesResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessGetPlayerTrades__DelegateSignature
	void DelegateOnSuccessGetPlayerTags__DelegateSignature(struct FClientGetPlayerTagsResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessGetPlayerTags__DelegateSignature
	void DelegateOnSuccessGetPlayerStatisticVersions__DelegateSignature(struct FClientGetPlayerStatisticVersionsResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessGetPlayerStatisticVersions__DelegateSignature
	void DelegateOnSuccessGetPlayerStatistics__DelegateSignature(struct FClientGetPlayerStatisticsResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessGetPlayerStatistics__DelegateSignature
	void DelegateOnSuccessGetPlayerSegments__DelegateSignature(struct FClientGetPlayerSegmentsResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessGetPlayerSegments__DelegateSignature
	void DelegateOnSuccessGetPlayerProfile__DelegateSignature(struct FClientGetPlayerProfileResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessGetPlayerProfile__DelegateSignature
	void DelegateOnSuccessGetPlayerCombinedInfo__DelegateSignature(struct FClientGetPlayerCombinedInfoResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessGetPlayerCombinedInfo__DelegateSignature
	void DelegateOnSuccessGetPhotonAuthenticationToken__DelegateSignature(struct FClientGetPhotonAuthenticationTokenResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessGetPhotonAuthenticationToken__DelegateSignature
	void DelegateOnSuccessGetPaymentToken__DelegateSignature(struct FClientGetPaymentTokenResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessGetPaymentToken__DelegateSignature
	void DelegateOnSuccessGetLeaderboardForUserCharacters__DelegateSignature(struct FClientGetLeaderboardForUsersCharactersResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessGetLeaderboardForUserCharacters__DelegateSignature
	void DelegateOnSuccessGetLeaderboardAroundPlayer__DelegateSignature(struct FClientGetLeaderboardAroundPlayerResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessGetLeaderboardAroundPlayer__DelegateSignature
	void DelegateOnSuccessGetLeaderboardAroundCharacter__DelegateSignature(struct FClientGetLeaderboardAroundCharacterResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessGetLeaderboardAroundCharacter__DelegateSignature
	void DelegateOnSuccessGetLeaderboard__DelegateSignature(struct FClientGetLeaderboardResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessGetLeaderboard__DelegateSignature
	void DelegateOnSuccessGetGameServerRegions__DelegateSignature(struct FClientGameServerRegionsResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessGetGameServerRegions__DelegateSignature
	void DelegateOnSuccessGetFriendsList__DelegateSignature(struct FClientGetFriendsListResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessGetFriendsList__DelegateSignature
	void DelegateOnSuccessGetFriendLeaderboardAroundPlayer__DelegateSignature(struct FClientGetFriendLeaderboardAroundPlayerResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessGetFriendLeaderboardAroundPlayer__DelegateSignature
	void DelegateOnSuccessGetFriendLeaderboard__DelegateSignature(struct FClientGetLeaderboardResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessGetFriendLeaderboard__DelegateSignature
	void DelegateOnSuccessGetCurrentGames__DelegateSignature(struct FClientCurrentGamesResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessGetCurrentGames__DelegateSignature
	void DelegateOnSuccessGetContentDownloadUrl__DelegateSignature(struct FClientGetContentDownloadUrlResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessGetContentDownloadUrl__DelegateSignature
	void DelegateOnSuccessGetCharacterStatistics__DelegateSignature(struct FClientGetCharacterStatisticsResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessGetCharacterStatistics__DelegateSignature
	void DelegateOnSuccessGetCharacterReadOnlyData__DelegateSignature(struct FClientGetCharacterDataResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessGetCharacterReadOnlyData__DelegateSignature
	void DelegateOnSuccessGetCharacterLeaderboard__DelegateSignature(struct FClientGetCharacterLeaderboardResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessGetCharacterLeaderboard__DelegateSignature
	void DelegateOnSuccessGetCharacterInventory__DelegateSignature(struct FClientGetCharacterInventoryResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessGetCharacterInventory__DelegateSignature
	void DelegateOnSuccessGetCharacterData__DelegateSignature(struct FClientGetCharacterDataResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessGetCharacterData__DelegateSignature
	void DelegateOnSuccessGetCatalogItems__DelegateSignature(struct FClientGetCatalogItemsResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessGetCatalogItems__DelegateSignature
	void DelegateOnSuccessGetAllUsersCharacters__DelegateSignature(struct FClientListUsersCharactersResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessGetAllUsersCharacters__DelegateSignature
	void DelegateOnSuccessGetAdPlacements__DelegateSignature(struct FClientGetAdPlacementsResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessGetAdPlacements__DelegateSignature
	void DelegateOnSuccessGetAccountInfo__DelegateSignature(struct FClientGetAccountInfoResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessGetAccountInfo__DelegateSignature
	void DelegateOnSuccessExecuteCloudScript__DelegateSignature(struct FClientExecuteCloudScriptResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessExecuteCloudScript__DelegateSignature
	void DelegateOnSuccessCreateSharedGroup__DelegateSignature(struct FClientCreateSharedGroupResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessCreateSharedGroup__DelegateSignature
	void DelegateOnSuccessConsumeXboxEntitlements__DelegateSignature(struct FClientConsumeXboxEntitlementsResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessConsumeXboxEntitlements__DelegateSignature
	void DelegateOnSuccessConsumePSNEntitlements__DelegateSignature(struct FClientConsumePSNEntitlementsResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessConsumePSNEntitlements__DelegateSignature
	void DelegateOnSuccessConsumePS5Entitlements__DelegateSignature(struct FClientConsumePS5EntitlementsResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessConsumePS5Entitlements__DelegateSignature
	void DelegateOnSuccessConsumeMicrosoftStoreEntitlements__DelegateSignature(struct FClientConsumeMicrosoftStoreEntitlementsResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessConsumeMicrosoftStoreEntitlements__DelegateSignature
	void DelegateOnSuccessConsumeItem__DelegateSignature(struct FClientConsumeItemResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessConsumeItem__DelegateSignature
	void DelegateOnSuccessConfirmPurchase__DelegateSignature(struct FClientConfirmPurchaseResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessConfirmPurchase__DelegateSignature
	void DelegateOnSuccessCancelTrade__DelegateSignature(struct FClientCancelTradeResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessCancelTrade__DelegateSignature
	void DelegateOnSuccessAttributeInstall__DelegateSignature(struct FClientAttributeInstallResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessAttributeInstall__DelegateSignature
	void DelegateOnSuccessAndroidDevicePushNotificationRegistration__DelegateSignature(struct FClientAndroidDevicePushNotificationRegistrationResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessAndroidDevicePushNotificationRegistration__DelegateSignature
	void DelegateOnSuccessAddUserVirtualCurrency__DelegateSignature(struct FClientModifyUserVirtualCurrencyResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessAddUserVirtualCurrency__DelegateSignature
	void DelegateOnSuccessAddUsernamePassword__DelegateSignature(struct FClientAddUsernamePasswordResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessAddUsernamePassword__DelegateSignature
	void DelegateOnSuccessAddSharedGroupMembers__DelegateSignature(struct FClientAddSharedGroupMembersResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessAddSharedGroupMembers__DelegateSignature
	void DelegateOnSuccessAddOrUpdateContactEmail__DelegateSignature(struct FClientAddOrUpdateContactEmailResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessAddOrUpdateContactEmail__DelegateSignature
	void DelegateOnSuccessAddGenericID__DelegateSignature(struct FClientAddGenericIDResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessAddGenericID__DelegateSignature
	void DelegateOnSuccessAddFriend__DelegateSignature(struct FClientAddFriendResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessAddFriend__DelegateSignature
	void DelegateOnSuccessAcceptTrade__DelegateSignature(struct FClientAcceptTradeResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnSuccessAcceptTrade__DelegateSignature
	void DelegateOnFailurePlayFabError__DelegateSignature(struct FPlayFabError Error, struct UObject* customData); // DelegateFunction PlayFab.PlayFabClientAPI.DelegateOnFailurePlayFabError__DelegateSignature
	struct UPlayFabClientAPI* CreateSharedGroup(struct FClientCreateSharedGroupRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.CreateSharedGroup
	struct UPlayFabClientAPI* ConsumeXboxEntitlements(struct FClientConsumeXboxEntitlementsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.ConsumeXboxEntitlements
	struct UPlayFabClientAPI* ConsumePSNEntitlements(struct FClientConsumePSNEntitlementsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.ConsumePSNEntitlements
	struct UPlayFabClientAPI* ConsumePS5Entitlements(struct FClientConsumePS5EntitlementsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.ConsumePS5Entitlements
	struct UPlayFabClientAPI* ConsumeMicrosoftStoreEntitlements(struct FClientConsumeMicrosoftStoreEntitlementsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.ConsumeMicrosoftStoreEntitlements
	struct UPlayFabClientAPI* ConsumeItem(struct FClientConsumeItemRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.ConsumeItem
	struct UPlayFabClientAPI* ConfirmPurchase(struct FClientConfirmPurchaseRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.ConfirmPurchase
	struct UPlayFabClientAPI* CancelTrade(struct FClientCancelTradeRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.CancelTrade
	struct UPlayFabClientAPI* AttributeInstall(struct FClientAttributeInstallRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.AttributeInstall
	struct UPlayFabClientAPI* AndroidDevicePushNotificationRegistration(struct FClientAndroidDevicePushNotificationRegistrationRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.AndroidDevicePushNotificationRegistration
	struct UPlayFabClientAPI* AddUserVirtualCurrency(struct FClientAddUserVirtualCurrencyRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.AddUserVirtualCurrency
	struct UPlayFabClientAPI* AddUsernamePassword(struct FClientAddUsernamePasswordRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.AddUsernamePassword
	struct UPlayFabClientAPI* AddSharedGroupMembers(struct FClientAddSharedGroupMembersRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.AddSharedGroupMembers
	struct UPlayFabClientAPI* AddOrUpdateContactEmail(struct FClientAddOrUpdateContactEmailRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.AddOrUpdateContactEmail
	struct UPlayFabClientAPI* AddGenericID(struct FClientAddGenericIDRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.AddGenericID
	struct UPlayFabClientAPI* AddFriend(struct FClientAddFriendRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.AddFriend
	struct UPlayFabClientAPI* AcceptTrade(struct FClientAcceptTradeRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabClientAPI.AcceptTrade
}; 



// Class PlayFab.PlayFabEconomyModelDecoder
// Size: 0x28(Inherited: 0x28) 
struct UPlayFabEconomyModelDecoder : public UBlueprintFunctionLibrary
{

	struct FEconomyUpdateInventoryItemsResponse decodeUpdateInventoryItemsResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabEconomyModelDecoder.decodeUpdateInventoryItemsResponseResponse
	struct FEconomyUpdateDraftItemResponse decodeUpdateDraftItemResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabEconomyModelDecoder.decodeUpdateDraftItemResponseResponse
	struct FEconomyUpdateCatalogConfigResponse decodeUpdateCatalogConfigResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabEconomyModelDecoder.decodeUpdateCatalogConfigResponseResponse
	struct FEconomyTransferInventoryItemsResponse decodeTransferInventoryItemsResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabEconomyModelDecoder.decodeTransferInventoryItemsResponseResponse
	struct FEconomyTakedownItemReviewsResponse decodeTakedownItemReviewsResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabEconomyModelDecoder.decodeTakedownItemReviewsResponseResponse
	struct FEconomySubtractInventoryItemsResponse decodeSubtractInventoryItemsResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabEconomyModelDecoder.decodeSubtractInventoryItemsResponseResponse
	struct FEconomySubmitItemReviewVoteResponse decodeSubmitItemReviewVoteResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabEconomyModelDecoder.decodeSubmitItemReviewVoteResponseResponse
	struct FEconomySetItemModerationStateResponse decodeSetItemModerationStateResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabEconomyModelDecoder.decodeSetItemModerationStateResponseResponse
	struct FEconomySearchItemsResponse decodeSearchItemsResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabEconomyModelDecoder.decodeSearchItemsResponseResponse
	struct FEconomyReviewItemResponse decodeReviewItemResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabEconomyModelDecoder.decodeReviewItemResponseResponse
	struct FEconomyReportItemReviewResponse decodeReportItemReviewResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabEconomyModelDecoder.decodeReportItemReviewResponseResponse
	struct FEconomyReportItemResponse decodeReportItemResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabEconomyModelDecoder.decodeReportItemResponseResponse
	struct FEconomyRedeemSteamInventoryItemsResponse decodeRedeemSteamInventoryItemsResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabEconomyModelDecoder.decodeRedeemSteamInventoryItemsResponseResponse
	struct FEconomyRedeemPlayStationStoreInventoryItemsResponse decodeRedeemPlayStationStoreInventoryItemsResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabEconomyModelDecoder.decodeRedeemPlayStationStoreInventoryItemsResponseResponse
	struct FEconomyRedeemNintendoEShopInventoryItemsResponse decodeRedeemNintendoEShopInventoryItemsResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabEconomyModelDecoder.decodeRedeemNintendoEShopInventoryItemsResponseResponse
	struct FEconomyRedeemMicrosoftStoreInventoryItemsResponse decodeRedeemMicrosoftStoreInventoryItemsResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabEconomyModelDecoder.decodeRedeemMicrosoftStoreInventoryItemsResponseResponse
	struct FEconomyRedeemGooglePlayInventoryItemsResponse decodeRedeemGooglePlayInventoryItemsResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabEconomyModelDecoder.decodeRedeemGooglePlayInventoryItemsResponseResponse
	struct FEconomyRedeemAppleAppStoreInventoryItemsResponse decodeRedeemAppleAppStoreInventoryItemsResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabEconomyModelDecoder.decodeRedeemAppleAppStoreInventoryItemsResponseResponse
	struct FEconomyPurchaseInventoryItemsResponse decodePurchaseInventoryItemsResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabEconomyModelDecoder.decodePurchaseInventoryItemsResponseResponse
	struct FEconomyPublishDraftItemResponse decodePublishDraftItemResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabEconomyModelDecoder.decodePublishDraftItemResponseResponse
	struct FEconomyGetTransactionHistoryResponse decodeGetTransactionHistoryResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabEconomyModelDecoder.decodeGetTransactionHistoryResponseResponse
	struct FEconomyGetMicrosoftStoreAccessTokensResponse decodeGetMicrosoftStoreAccessTokensResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabEconomyModelDecoder.decodeGetMicrosoftStoreAccessTokensResponseResponse
	struct FEconomyGetItemsResponse decodeGetItemsResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabEconomyModelDecoder.decodeGetItemsResponseResponse
	struct FEconomyGetItemReviewSummaryResponse decodeGetItemReviewSummaryResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabEconomyModelDecoder.decodeGetItemReviewSummaryResponseResponse
	struct FEconomyGetItemReviewsResponse decodeGetItemReviewsResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabEconomyModelDecoder.decodeGetItemReviewsResponseResponse
	struct FEconomyGetItemResponse decodeGetItemResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabEconomyModelDecoder.decodeGetItemResponseResponse
	struct FEconomyGetItemPublishStatusResponse decodeGetItemPublishStatusResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabEconomyModelDecoder.decodeGetItemPublishStatusResponseResponse
	struct FEconomyGetItemModerationStateResponse decodeGetItemModerationStateResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabEconomyModelDecoder.decodeGetItemModerationStateResponseResponse
	struct FEconomyGetItemContainersResponse decodeGetItemContainersResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabEconomyModelDecoder.decodeGetItemContainersResponseResponse
	struct FEconomyGetInventoryItemsResponse decodeGetInventoryItemsResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabEconomyModelDecoder.decodeGetInventoryItemsResponseResponse
	struct FEconomyGetInventoryCollectionIdsResponse decodeGetInventoryCollectionIdsResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabEconomyModelDecoder.decodeGetInventoryCollectionIdsResponseResponse
	struct FEconomyGetEntityItemReviewResponse decodeGetEntityItemReviewResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabEconomyModelDecoder.decodeGetEntityItemReviewResponseResponse
	struct FEconomyGetEntityDraftItemsResponse decodeGetEntityDraftItemsResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabEconomyModelDecoder.decodeGetEntityDraftItemsResponseResponse
	struct FEconomyGetDraftItemsResponse decodeGetDraftItemsResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabEconomyModelDecoder.decodeGetDraftItemsResponseResponse
	struct FEconomyGetDraftItemResponse decodeGetDraftItemResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabEconomyModelDecoder.decodeGetDraftItemResponseResponse
	struct FEconomyGetCatalogConfigResponse decodeGetCatalogConfigResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabEconomyModelDecoder.decodeGetCatalogConfigResponseResponse
	struct FEconomyExecuteInventoryOperationsResponse decodeExecuteInventoryOperationsResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabEconomyModelDecoder.decodeExecuteInventoryOperationsResponseResponse
	struct FEconomyDeleteItemResponse decodeDeleteItemResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabEconomyModelDecoder.decodeDeleteItemResponseResponse
	struct FEconomyDeleteInventoryItemsResponse decodeDeleteInventoryItemsResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabEconomyModelDecoder.decodeDeleteInventoryItemsResponseResponse
	struct FEconomyDeleteInventoryCollectionResponse decodeDeleteInventoryCollectionResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabEconomyModelDecoder.decodeDeleteInventoryCollectionResponseResponse
	struct FEconomyDeleteEntityItemReviewsResponse decodeDeleteEntityItemReviewsResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabEconomyModelDecoder.decodeDeleteEntityItemReviewsResponseResponse
	struct FEconomyCreateUploadUrlsResponse decodeCreateUploadUrlsResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabEconomyModelDecoder.decodeCreateUploadUrlsResponseResponse
	struct FEconomyCreateDraftItemResponse decodeCreateDraftItemResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabEconomyModelDecoder.decodeCreateDraftItemResponseResponse
	struct FEconomyAddInventoryItemsResponse decodeAddInventoryItemsResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabEconomyModelDecoder.decodeAddInventoryItemsResponseResponse
}; 



// Class PlayFab.PlayFabDataAPI
// Size: 0x160(Inherited: 0x30) 
struct UPlayFabDataAPI : public UOnlineBlueprintCallProxyBase
{
	struct FMulticastInlineDelegate OnPlayFabResponse;  // 0x30(0x10)
	char pad_64[184];  // 0x40(0xB8)
	struct UPlayFabAuthenticationContext* CallAuthenticationContext;  // 0xF8(0x8)
	struct UPlayFabJsonObject* RequestJsonObj;  // 0x100(0x8)
	struct UPlayFabJsonObject* ResponseJsonObj;  // 0x108(0x8)
	char pad_272[80];  // 0x110(0x50)

	struct UPlayFabDataAPI* SetObjects(struct FDataSetObjectsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabDataAPI.SetObjects
	struct UPlayFabDataAPI* InitiateFileUploads(struct FDataInitiateFileUploadsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabDataAPI.InitiateFileUploads
	void HelperSetObjects(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabDataAPI.HelperSetObjects
	void HelperInitiateFileUploads(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabDataAPI.HelperInitiateFileUploads
	void HelperGetObjects(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabDataAPI.HelperGetObjects
	void HelperGetFiles(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabDataAPI.HelperGetFiles
	void HelperFinalizeFileUploads(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabDataAPI.HelperFinalizeFileUploads
	void HelperDeleteFiles(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabDataAPI.HelperDeleteFiles
	void HelperAbortFileUploads(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabDataAPI.HelperAbortFileUploads
	struct UPlayFabDataAPI* GetObjects(struct FDataGetObjectsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabDataAPI.GetObjects
	struct UPlayFabDataAPI* GetFiles(struct FDataGetFilesRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabDataAPI.GetFiles
	struct UPlayFabDataAPI* FinalizeFileUploads(struct FDataFinalizeFileUploadsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabDataAPI.FinalizeFileUploads
	struct UPlayFabDataAPI* DeleteFiles(struct FDataDeleteFilesRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabDataAPI.DeleteFiles
	void DelegateOnSuccessSetObjects__DelegateSignature(struct FDataSetObjectsResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabDataAPI.DelegateOnSuccessSetObjects__DelegateSignature
	void DelegateOnSuccessInitiateFileUploads__DelegateSignature(struct FDataInitiateFileUploadsResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabDataAPI.DelegateOnSuccessInitiateFileUploads__DelegateSignature
	void DelegateOnSuccessGetObjects__DelegateSignature(struct FDataGetObjectsResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabDataAPI.DelegateOnSuccessGetObjects__DelegateSignature
	void DelegateOnSuccessGetFiles__DelegateSignature(struct FDataGetFilesResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabDataAPI.DelegateOnSuccessGetFiles__DelegateSignature
	void DelegateOnSuccessFinalizeFileUploads__DelegateSignature(struct FDataFinalizeFileUploadsResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabDataAPI.DelegateOnSuccessFinalizeFileUploads__DelegateSignature
	void DelegateOnSuccessDeleteFiles__DelegateSignature(struct FDataDeleteFilesResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabDataAPI.DelegateOnSuccessDeleteFiles__DelegateSignature
	void DelegateOnSuccessAbortFileUploads__DelegateSignature(struct FDataAbortFileUploadsResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabDataAPI.DelegateOnSuccessAbortFileUploads__DelegateSignature
	void DelegateOnFailurePlayFabError__DelegateSignature(struct FPlayFabError Error, struct UObject* customData); // DelegateFunction PlayFab.PlayFabDataAPI.DelegateOnFailurePlayFabError__DelegateSignature
	struct UPlayFabDataAPI* AbortFileUploads(struct FDataAbortFileUploadsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabDataAPI.AbortFileUploads
}; 



// Class PlayFab.PlayFabCloudScriptAPI
// Size: 0x1D0(Inherited: 0x30) 
struct UPlayFabCloudScriptAPI : public UOnlineBlueprintCallProxyBase
{
	struct FMulticastInlineDelegate OnPlayFabResponse;  // 0x30(0x10)
	char pad_64[296];  // 0x40(0x128)
	struct UPlayFabAuthenticationContext* CallAuthenticationContext;  // 0x168(0x8)
	struct UPlayFabJsonObject* RequestJsonObj;  // 0x170(0x8)
	struct UPlayFabJsonObject* ResponseJsonObj;  // 0x178(0x8)
	char pad_384[80];  // 0x180(0x50)

	struct UPlayFabCloudScriptAPI* UnregisterFunction(struct FCloudScriptUnregisterFunctionRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabCloudScriptAPI.UnregisterFunction
	struct UPlayFabCloudScriptAPI* RegisterQueuedFunction(struct FCloudScriptRegisterQueuedFunctionRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabCloudScriptAPI.RegisterQueuedFunction
	struct UPlayFabCloudScriptAPI* RegisterHttpFunction(struct FCloudScriptRegisterHttpFunctionRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabCloudScriptAPI.RegisterHttpFunction
	struct UPlayFabCloudScriptAPI* PostFunctionResultForScheduledTask(struct FCloudScriptPostFunctionResultForScheduledTaskRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabCloudScriptAPI.PostFunctionResultForScheduledTask
	struct UPlayFabCloudScriptAPI* PostFunctionResultForPlayerTriggeredAction(struct FCloudScriptPostFunctionResultForPlayerTriggeredActionRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabCloudScriptAPI.PostFunctionResultForPlayerTriggeredAction
	struct UPlayFabCloudScriptAPI* PostFunctionResultForFunctionExecution(struct FCloudScriptPostFunctionResultForFunctionExecutionRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabCloudScriptAPI.PostFunctionResultForFunctionExecution
	struct UPlayFabCloudScriptAPI* PostFunctionResultForEntityTriggeredAction(struct FCloudScriptPostFunctionResultForEntityTriggeredActionRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabCloudScriptAPI.PostFunctionResultForEntityTriggeredAction
	struct UPlayFabCloudScriptAPI* ListQueuedFunctions(struct FCloudScriptListFunctionsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabCloudScriptAPI.ListQueuedFunctions
	struct UPlayFabCloudScriptAPI* ListHttpFunctions(struct FCloudScriptListFunctionsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabCloudScriptAPI.ListHttpFunctions
	struct UPlayFabCloudScriptAPI* ListFunctions(struct FCloudScriptListFunctionsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabCloudScriptAPI.ListFunctions
	void HelperUnregisterFunction(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabCloudScriptAPI.HelperUnregisterFunction
	void HelperRegisterQueuedFunction(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabCloudScriptAPI.HelperRegisterQueuedFunction
	void HelperRegisterHttpFunction(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabCloudScriptAPI.HelperRegisterHttpFunction
	void HelperPostFunctionResultForScheduledTask(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabCloudScriptAPI.HelperPostFunctionResultForScheduledTask
	void HelperPostFunctionResultForPlayerTriggeredAction(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabCloudScriptAPI.HelperPostFunctionResultForPlayerTriggeredAction
	void HelperPostFunctionResultForFunctionExecution(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabCloudScriptAPI.HelperPostFunctionResultForFunctionExecution
	void HelperPostFunctionResultForEntityTriggeredAction(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabCloudScriptAPI.HelperPostFunctionResultForEntityTriggeredAction
	void HelperListQueuedFunctions(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabCloudScriptAPI.HelperListQueuedFunctions
	void HelperListHttpFunctions(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabCloudScriptAPI.HelperListHttpFunctions
	void HelperListFunctions(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabCloudScriptAPI.HelperListFunctions
	void HelperGetFunction(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabCloudScriptAPI.HelperGetFunction
	void HelperExecuteFunction(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabCloudScriptAPI.HelperExecuteFunction
	void HelperExecuteEntityCloudScript(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabCloudScriptAPI.HelperExecuteEntityCloudScript
	struct UPlayFabCloudScriptAPI* GetFunction(struct FCloudScriptGetFunctionRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabCloudScriptAPI.GetFunction
	struct UPlayFabCloudScriptAPI* ExecuteFunction(struct FCloudScriptExecuteFunctionRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabCloudScriptAPI.ExecuteFunction
	struct UPlayFabCloudScriptAPI* ExecuteEntityCloudScript(struct FCloudScriptExecuteEntityCloudScriptRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabCloudScriptAPI.ExecuteEntityCloudScript
	void DelegateOnSuccessUnregisterFunction__DelegateSignature(struct FCloudScriptEmptyResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabCloudScriptAPI.DelegateOnSuccessUnregisterFunction__DelegateSignature
	void DelegateOnSuccessRegisterQueuedFunction__DelegateSignature(struct FCloudScriptEmptyResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabCloudScriptAPI.DelegateOnSuccessRegisterQueuedFunction__DelegateSignature
	void DelegateOnSuccessRegisterHttpFunction__DelegateSignature(struct FCloudScriptEmptyResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabCloudScriptAPI.DelegateOnSuccessRegisterHttpFunction__DelegateSignature
	void DelegateOnSuccessPostFunctionResultForScheduledTask__DelegateSignature(struct FCloudScriptEmptyResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabCloudScriptAPI.DelegateOnSuccessPostFunctionResultForScheduledTask__DelegateSignature
	void DelegateOnSuccessPostFunctionResultForPlayerTriggeredAction__DelegateSignature(struct FCloudScriptEmptyResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabCloudScriptAPI.DelegateOnSuccessPostFunctionResultForPlayerTriggeredAction__DelegateSignature
	void DelegateOnSuccessPostFunctionResultForFunctionExecution__DelegateSignature(struct FCloudScriptEmptyResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabCloudScriptAPI.DelegateOnSuccessPostFunctionResultForFunctionExecution__DelegateSignature
	void DelegateOnSuccessPostFunctionResultForEntityTriggeredAction__DelegateSignature(struct FCloudScriptEmptyResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabCloudScriptAPI.DelegateOnSuccessPostFunctionResultForEntityTriggeredAction__DelegateSignature
	void DelegateOnSuccessListQueuedFunctions__DelegateSignature(struct FCloudScriptListQueuedFunctionsResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabCloudScriptAPI.DelegateOnSuccessListQueuedFunctions__DelegateSignature
	void DelegateOnSuccessListHttpFunctions__DelegateSignature(struct FCloudScriptListHttpFunctionsResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabCloudScriptAPI.DelegateOnSuccessListHttpFunctions__DelegateSignature
	void DelegateOnSuccessListFunctions__DelegateSignature(struct FCloudScriptListFunctionsResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabCloudScriptAPI.DelegateOnSuccessListFunctions__DelegateSignature
	void DelegateOnSuccessGetFunction__DelegateSignature(struct FCloudScriptGetFunctionResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabCloudScriptAPI.DelegateOnSuccessGetFunction__DelegateSignature
	void DelegateOnSuccessExecuteFunction__DelegateSignature(struct FCloudScriptExecuteFunctionResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabCloudScriptAPI.DelegateOnSuccessExecuteFunction__DelegateSignature
	void DelegateOnSuccessExecuteEntityCloudScript__DelegateSignature(struct FCloudScriptExecuteCloudScriptResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabCloudScriptAPI.DelegateOnSuccessExecuteEntityCloudScript__DelegateSignature
	void DelegateOnFailurePlayFabError__DelegateSignature(struct FPlayFabError Error, struct UObject* customData); // DelegateFunction PlayFab.PlayFabCloudScriptAPI.DelegateOnFailurePlayFabError__DelegateSignature
}; 



// Class PlayFab.PlayFabDataModelDecoder
// Size: 0x28(Inherited: 0x28) 
struct UPlayFabDataModelDecoder : public UBlueprintFunctionLibrary
{

	struct FDataSetObjectsResponse decodeSetObjectsResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabDataModelDecoder.decodeSetObjectsResponseResponse
	struct FDataInitiateFileUploadsResponse decodeInitiateFileUploadsResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabDataModelDecoder.decodeInitiateFileUploadsResponseResponse
	struct FDataGetObjectsResponse decodeGetObjectsResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabDataModelDecoder.decodeGetObjectsResponseResponse
	struct FDataGetFilesResponse decodeGetFilesResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabDataModelDecoder.decodeGetFilesResponseResponse
	struct FDataFinalizeFileUploadsResponse decodeFinalizeFileUploadsResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabDataModelDecoder.decodeFinalizeFileUploadsResponseResponse
	struct FDataDeleteFilesResponse decodeDeleteFilesResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabDataModelDecoder.decodeDeleteFilesResponseResponse
	struct FDataAbortFileUploadsResponse decodeAbortFileUploadsResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabDataModelDecoder.decodeAbortFileUploadsResponseResponse
}; 



// Class PlayFab.PlayFabCloudScriptModelDecoder
// Size: 0x28(Inherited: 0x28) 
struct UPlayFabCloudScriptModelDecoder : public UBlueprintFunctionLibrary
{

	struct FCloudScriptListQueuedFunctionsResult decodeListQueuedFunctionsResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabCloudScriptModelDecoder.decodeListQueuedFunctionsResultResponse
	struct FCloudScriptListHttpFunctionsResult decodeListHttpFunctionsResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabCloudScriptModelDecoder.decodeListHttpFunctionsResultResponse
	struct FCloudScriptListFunctionsResult decodeListFunctionsResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabCloudScriptModelDecoder.decodeListFunctionsResultResponse
	struct FCloudScriptGetFunctionResult decodeGetFunctionResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabCloudScriptModelDecoder.decodeGetFunctionResultResponse
	struct FCloudScriptExecuteFunctionResult decodeExecuteFunctionResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabCloudScriptModelDecoder.decodeExecuteFunctionResultResponse
	struct FCloudScriptExecuteCloudScriptResult decodeExecuteCloudScriptResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabCloudScriptModelDecoder.decodeExecuteCloudScriptResultResponse
	struct FCloudScriptEmptyResult decodeEmptyResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabCloudScriptModelDecoder.decodeEmptyResultResponse
}; 



// Class PlayFab.PlayFabEconomyAPI
// Size: 0x3B0(Inherited: 0x30) 
struct UPlayFabEconomyAPI : public UOnlineBlueprintCallProxyBase
{
	struct FMulticastInlineDelegate OnPlayFabResponse;  // 0x30(0x10)
	char pad_64[776];  // 0x40(0x308)
	struct UPlayFabAuthenticationContext* CallAuthenticationContext;  // 0x348(0x8)
	struct UPlayFabJsonObject* RequestJsonObj;  // 0x350(0x8)
	struct UPlayFabJsonObject* ResponseJsonObj;  // 0x358(0x8)
	char pad_864[80];  // 0x360(0x50)

	struct UPlayFabEconomyAPI* UpdateInventoryItems(struct FEconomyUpdateInventoryItemsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabEconomyAPI.UpdateInventoryItems
	struct UPlayFabEconomyAPI* UpdateDraftItem(struct FEconomyUpdateDraftItemRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabEconomyAPI.UpdateDraftItem
	struct UPlayFabEconomyAPI* UpdateCatalogConfig(struct FEconomyUpdateCatalogConfigRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabEconomyAPI.UpdateCatalogConfig
	struct UPlayFabEconomyAPI* TransferInventoryItems(struct FEconomyTransferInventoryItemsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabEconomyAPI.TransferInventoryItems
	struct UPlayFabEconomyAPI* TakedownItemReviews(struct FEconomyTakedownItemReviewsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabEconomyAPI.TakedownItemReviews
	struct UPlayFabEconomyAPI* SubtractInventoryItems(struct FEconomySubtractInventoryItemsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabEconomyAPI.SubtractInventoryItems
	struct UPlayFabEconomyAPI* SubmitItemReviewVote(struct FEconomySubmitItemReviewVoteRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabEconomyAPI.SubmitItemReviewVote
	struct UPlayFabEconomyAPI* SetItemModerationState(struct FEconomySetItemModerationStateRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabEconomyAPI.SetItemModerationState
	struct UPlayFabEconomyAPI* SearchItems(struct FEconomySearchItemsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabEconomyAPI.SearchItems
	struct UPlayFabEconomyAPI* ReviewItem(struct FEconomyReviewItemRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabEconomyAPI.ReviewItem
	struct UPlayFabEconomyAPI* ReportItemReview(struct FEconomyReportItemReviewRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabEconomyAPI.ReportItemReview
	struct UPlayFabEconomyAPI* ReportItem(struct FEconomyReportItemRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabEconomyAPI.ReportItem
	struct UPlayFabEconomyAPI* RedeemSteamInventoryItems(struct FEconomyRedeemSteamInventoryItemsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabEconomyAPI.RedeemSteamInventoryItems
	struct UPlayFabEconomyAPI* RedeemPlayStationStoreInventoryItems(struct FEconomyRedeemPlayStationStoreInventoryItemsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabEconomyAPI.RedeemPlayStationStoreInventoryItems
	struct UPlayFabEconomyAPI* RedeemNintendoEShopInventoryItems(struct FEconomyRedeemNintendoEShopInventoryItemsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabEconomyAPI.RedeemNintendoEShopInventoryItems
	struct UPlayFabEconomyAPI* RedeemMicrosoftStoreInventoryItems(struct FEconomyRedeemMicrosoftStoreInventoryItemsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabEconomyAPI.RedeemMicrosoftStoreInventoryItems
	struct UPlayFabEconomyAPI* RedeemGooglePlayInventoryItems(struct FEconomyRedeemGooglePlayInventoryItemsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabEconomyAPI.RedeemGooglePlayInventoryItems
	struct UPlayFabEconomyAPI* RedeemAppleAppStoreInventoryItems(struct FEconomyRedeemAppleAppStoreInventoryItemsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabEconomyAPI.RedeemAppleAppStoreInventoryItems
	struct UPlayFabEconomyAPI* PurchaseInventoryItems(struct FEconomyPurchaseInventoryItemsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabEconomyAPI.PurchaseInventoryItems
	struct UPlayFabEconomyAPI* PublishDraftItem(struct FEconomyPublishDraftItemRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabEconomyAPI.PublishDraftItem
	void HelperUpdateInventoryItems(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabEconomyAPI.HelperUpdateInventoryItems
	void HelperUpdateDraftItem(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabEconomyAPI.HelperUpdateDraftItem
	void HelperUpdateCatalogConfig(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabEconomyAPI.HelperUpdateCatalogConfig
	void HelperTransferInventoryItems(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabEconomyAPI.HelperTransferInventoryItems
	void HelperTakedownItemReviews(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabEconomyAPI.HelperTakedownItemReviews
	void HelperSubtractInventoryItems(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabEconomyAPI.HelperSubtractInventoryItems
	void HelperSubmitItemReviewVote(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabEconomyAPI.HelperSubmitItemReviewVote
	void HelperSetItemModerationState(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabEconomyAPI.HelperSetItemModerationState
	void HelperSearchItems(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabEconomyAPI.HelperSearchItems
	void HelperReviewItem(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabEconomyAPI.HelperReviewItem
	void HelperReportItemReview(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabEconomyAPI.HelperReportItemReview
	void HelperReportItem(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabEconomyAPI.HelperReportItem
	void HelperRedeemSteamInventoryItems(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabEconomyAPI.HelperRedeemSteamInventoryItems
	void HelperRedeemPlayStationStoreInventoryItems(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabEconomyAPI.HelperRedeemPlayStationStoreInventoryItems
	void HelperRedeemNintendoEShopInventoryItems(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabEconomyAPI.HelperRedeemNintendoEShopInventoryItems
	void HelperRedeemMicrosoftStoreInventoryItems(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabEconomyAPI.HelperRedeemMicrosoftStoreInventoryItems
	void HelperRedeemGooglePlayInventoryItems(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabEconomyAPI.HelperRedeemGooglePlayInventoryItems
	void HelperRedeemAppleAppStoreInventoryItems(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabEconomyAPI.HelperRedeemAppleAppStoreInventoryItems
	void HelperPurchaseInventoryItems(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabEconomyAPI.HelperPurchaseInventoryItems
	void HelperPublishDraftItem(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabEconomyAPI.HelperPublishDraftItem
	void HelperGetTransactionHistory(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabEconomyAPI.HelperGetTransactionHistory
	void HelperGetMicrosoftStoreAccessTokens(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabEconomyAPI.HelperGetMicrosoftStoreAccessTokens
	void HelperGetItems(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabEconomyAPI.HelperGetItems
	void HelperGetItemReviewSummary(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabEconomyAPI.HelperGetItemReviewSummary
	void HelperGetItemReviews(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabEconomyAPI.HelperGetItemReviews
	void HelperGetItemPublishStatus(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabEconomyAPI.HelperGetItemPublishStatus
	void HelperGetItemModerationState(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabEconomyAPI.HelperGetItemModerationState
	void HelperGetItemContainers(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabEconomyAPI.HelperGetItemContainers
	void HelperGetItem(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabEconomyAPI.HelperGetItem
	void HelperGetInventoryItems(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabEconomyAPI.HelperGetInventoryItems
	void HelperGetInventoryCollectionIds(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabEconomyAPI.HelperGetInventoryCollectionIds
	void HelperGetEntityItemReview(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabEconomyAPI.HelperGetEntityItemReview
	void HelperGetEntityDraftItems(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabEconomyAPI.HelperGetEntityDraftItems
	void HelperGetDraftItems(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabEconomyAPI.HelperGetDraftItems
	void HelperGetDraftItem(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabEconomyAPI.HelperGetDraftItem
	void HelperGetCatalogConfig(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabEconomyAPI.HelperGetCatalogConfig
	void HelperExecuteInventoryOperations(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabEconomyAPI.HelperExecuteInventoryOperations
	void HelperDeleteItem(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabEconomyAPI.HelperDeleteItem
	void HelperDeleteInventoryItems(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabEconomyAPI.HelperDeleteInventoryItems
	void HelperDeleteInventoryCollection(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabEconomyAPI.HelperDeleteInventoryCollection
	void HelperDeleteEntityItemReviews(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabEconomyAPI.HelperDeleteEntityItemReviews
	void HelperCreateUploadUrls(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabEconomyAPI.HelperCreateUploadUrls
	void HelperCreateDraftItem(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabEconomyAPI.HelperCreateDraftItem
	void HelperAddInventoryItems(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabEconomyAPI.HelperAddInventoryItems
	struct UPlayFabEconomyAPI* GetTransactionHistory(struct FEconomyGetTransactionHistoryRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabEconomyAPI.GetTransactionHistory
	struct UPlayFabEconomyAPI* GetMicrosoftStoreAccessTokens(struct FEconomyGetMicrosoftStoreAccessTokensRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabEconomyAPI.GetMicrosoftStoreAccessTokens
	struct UPlayFabEconomyAPI* GetItems(struct FEconomyGetItemsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabEconomyAPI.GetItems
	struct UPlayFabEconomyAPI* GetItemReviewSummary(struct FEconomyGetItemReviewSummaryRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabEconomyAPI.GetItemReviewSummary
	struct UPlayFabEconomyAPI* GetItemReviews(struct FEconomyGetItemReviewsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabEconomyAPI.GetItemReviews
	struct UPlayFabEconomyAPI* GetItemPublishStatus(struct FEconomyGetItemPublishStatusRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabEconomyAPI.GetItemPublishStatus
	struct UPlayFabEconomyAPI* GetItemModerationState(struct FEconomyGetItemModerationStateRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabEconomyAPI.GetItemModerationState
	struct UPlayFabEconomyAPI* GetItemContainers(struct FEconomyGetItemContainersRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabEconomyAPI.GetItemContainers
	struct UPlayFabEconomyAPI* GetItem(struct FEconomyGetItemRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabEconomyAPI.GetItem
	struct UPlayFabEconomyAPI* GetInventoryItems(struct FEconomyGetInventoryItemsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabEconomyAPI.GetInventoryItems
	struct UPlayFabEconomyAPI* GetInventoryCollectionIds(struct FEconomyGetInventoryCollectionIdsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabEconomyAPI.GetInventoryCollectionIds
	struct UPlayFabEconomyAPI* GetEntityItemReview(struct FEconomyGetEntityItemReviewRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabEconomyAPI.GetEntityItemReview
	struct UPlayFabEconomyAPI* GetEntityDraftItems(struct FEconomyGetEntityDraftItemsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabEconomyAPI.GetEntityDraftItems
	struct UPlayFabEconomyAPI* GetDraftItems(struct FEconomyGetDraftItemsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabEconomyAPI.GetDraftItems
	struct UPlayFabEconomyAPI* GetDraftItem(struct FEconomyGetDraftItemRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabEconomyAPI.GetDraftItem
	struct UPlayFabEconomyAPI* GetCatalogConfig(struct FEconomyGetCatalogConfigRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabEconomyAPI.GetCatalogConfig
	struct UPlayFabEconomyAPI* ExecuteInventoryOperations(struct FEconomyExecuteInventoryOperationsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabEconomyAPI.ExecuteInventoryOperations
	struct UPlayFabEconomyAPI* DeleteItem(struct FEconomyDeleteItemRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabEconomyAPI.DeleteItem
	struct UPlayFabEconomyAPI* DeleteInventoryItems(struct FEconomyDeleteInventoryItemsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabEconomyAPI.DeleteInventoryItems
	struct UPlayFabEconomyAPI* DeleteInventoryCollection(struct FEconomyDeleteInventoryCollectionRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabEconomyAPI.DeleteInventoryCollection
	struct UPlayFabEconomyAPI* DeleteEntityItemReviews(struct FEconomyDeleteEntityItemReviewsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabEconomyAPI.DeleteEntityItemReviews
	void DelegateOnSuccessUpdateInventoryItems__DelegateSignature(struct FEconomyUpdateInventoryItemsResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabEconomyAPI.DelegateOnSuccessUpdateInventoryItems__DelegateSignature
	void DelegateOnSuccessUpdateDraftItem__DelegateSignature(struct FEconomyUpdateDraftItemResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabEconomyAPI.DelegateOnSuccessUpdateDraftItem__DelegateSignature
	void DelegateOnSuccessUpdateCatalogConfig__DelegateSignature(struct FEconomyUpdateCatalogConfigResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabEconomyAPI.DelegateOnSuccessUpdateCatalogConfig__DelegateSignature
	void DelegateOnSuccessTransferInventoryItems__DelegateSignature(struct FEconomyTransferInventoryItemsResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabEconomyAPI.DelegateOnSuccessTransferInventoryItems__DelegateSignature
	void DelegateOnSuccessTakedownItemReviews__DelegateSignature(struct FEconomyTakedownItemReviewsResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabEconomyAPI.DelegateOnSuccessTakedownItemReviews__DelegateSignature
	void DelegateOnSuccessSubtractInventoryItems__DelegateSignature(struct FEconomySubtractInventoryItemsResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabEconomyAPI.DelegateOnSuccessSubtractInventoryItems__DelegateSignature
	void DelegateOnSuccessSubmitItemReviewVote__DelegateSignature(struct FEconomySubmitItemReviewVoteResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabEconomyAPI.DelegateOnSuccessSubmitItemReviewVote__DelegateSignature
	void DelegateOnSuccessSetItemModerationState__DelegateSignature(struct FEconomySetItemModerationStateResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabEconomyAPI.DelegateOnSuccessSetItemModerationState__DelegateSignature
	void DelegateOnSuccessSearchItems__DelegateSignature(struct FEconomySearchItemsResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabEconomyAPI.DelegateOnSuccessSearchItems__DelegateSignature
	void DelegateOnSuccessReviewItem__DelegateSignature(struct FEconomyReviewItemResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabEconomyAPI.DelegateOnSuccessReviewItem__DelegateSignature
	void DelegateOnSuccessReportItemReview__DelegateSignature(struct FEconomyReportItemReviewResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabEconomyAPI.DelegateOnSuccessReportItemReview__DelegateSignature
	void DelegateOnSuccessReportItem__DelegateSignature(struct FEconomyReportItemResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabEconomyAPI.DelegateOnSuccessReportItem__DelegateSignature
	void DelegateOnSuccessRedeemSteamInventoryItems__DelegateSignature(struct FEconomyRedeemSteamInventoryItemsResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabEconomyAPI.DelegateOnSuccessRedeemSteamInventoryItems__DelegateSignature
	void DelegateOnSuccessRedeemPlayStationStoreInventoryItems__DelegateSignature(struct FEconomyRedeemPlayStationStoreInventoryItemsResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabEconomyAPI.DelegateOnSuccessRedeemPlayStationStoreInventoryItems__DelegateSignature
	void DelegateOnSuccessRedeemNintendoEShopInventoryItems__DelegateSignature(struct FEconomyRedeemNintendoEShopInventoryItemsResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabEconomyAPI.DelegateOnSuccessRedeemNintendoEShopInventoryItems__DelegateSignature
	void DelegateOnSuccessRedeemMicrosoftStoreInventoryItems__DelegateSignature(struct FEconomyRedeemMicrosoftStoreInventoryItemsResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabEconomyAPI.DelegateOnSuccessRedeemMicrosoftStoreInventoryItems__DelegateSignature
	void DelegateOnSuccessRedeemGooglePlayInventoryItems__DelegateSignature(struct FEconomyRedeemGooglePlayInventoryItemsResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabEconomyAPI.DelegateOnSuccessRedeemGooglePlayInventoryItems__DelegateSignature
	void DelegateOnSuccessRedeemAppleAppStoreInventoryItems__DelegateSignature(struct FEconomyRedeemAppleAppStoreInventoryItemsResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabEconomyAPI.DelegateOnSuccessRedeemAppleAppStoreInventoryItems__DelegateSignature
	void DelegateOnSuccessPurchaseInventoryItems__DelegateSignature(struct FEconomyPurchaseInventoryItemsResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabEconomyAPI.DelegateOnSuccessPurchaseInventoryItems__DelegateSignature
	void DelegateOnSuccessPublishDraftItem__DelegateSignature(struct FEconomyPublishDraftItemResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabEconomyAPI.DelegateOnSuccessPublishDraftItem__DelegateSignature
	void DelegateOnSuccessGetTransactionHistory__DelegateSignature(struct FEconomyGetTransactionHistoryResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabEconomyAPI.DelegateOnSuccessGetTransactionHistory__DelegateSignature
	void DelegateOnSuccessGetMicrosoftStoreAccessTokens__DelegateSignature(struct FEconomyGetMicrosoftStoreAccessTokensResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabEconomyAPI.DelegateOnSuccessGetMicrosoftStoreAccessTokens__DelegateSignature
	void DelegateOnSuccessGetItems__DelegateSignature(struct FEconomyGetItemsResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabEconomyAPI.DelegateOnSuccessGetItems__DelegateSignature
	void DelegateOnSuccessGetItemReviewSummary__DelegateSignature(struct FEconomyGetItemReviewSummaryResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabEconomyAPI.DelegateOnSuccessGetItemReviewSummary__DelegateSignature
	void DelegateOnSuccessGetItemReviews__DelegateSignature(struct FEconomyGetItemReviewsResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabEconomyAPI.DelegateOnSuccessGetItemReviews__DelegateSignature
	void DelegateOnSuccessGetItemPublishStatus__DelegateSignature(struct FEconomyGetItemPublishStatusResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabEconomyAPI.DelegateOnSuccessGetItemPublishStatus__DelegateSignature
	void DelegateOnSuccessGetItemModerationState__DelegateSignature(struct FEconomyGetItemModerationStateResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabEconomyAPI.DelegateOnSuccessGetItemModerationState__DelegateSignature
	void DelegateOnSuccessGetItemContainers__DelegateSignature(struct FEconomyGetItemContainersResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabEconomyAPI.DelegateOnSuccessGetItemContainers__DelegateSignature
	void DelegateOnSuccessGetItem__DelegateSignature(struct FEconomyGetItemResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabEconomyAPI.DelegateOnSuccessGetItem__DelegateSignature
	void DelegateOnSuccessGetInventoryItems__DelegateSignature(struct FEconomyGetInventoryItemsResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabEconomyAPI.DelegateOnSuccessGetInventoryItems__DelegateSignature
	void DelegateOnSuccessGetInventoryCollectionIds__DelegateSignature(struct FEconomyGetInventoryCollectionIdsResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabEconomyAPI.DelegateOnSuccessGetInventoryCollectionIds__DelegateSignature
	void DelegateOnSuccessGetEntityItemReview__DelegateSignature(struct FEconomyGetEntityItemReviewResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabEconomyAPI.DelegateOnSuccessGetEntityItemReview__DelegateSignature
	void DelegateOnSuccessGetEntityDraftItems__DelegateSignature(struct FEconomyGetEntityDraftItemsResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabEconomyAPI.DelegateOnSuccessGetEntityDraftItems__DelegateSignature
	void DelegateOnSuccessGetDraftItems__DelegateSignature(struct FEconomyGetDraftItemsResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabEconomyAPI.DelegateOnSuccessGetDraftItems__DelegateSignature
	void DelegateOnSuccessGetDraftItem__DelegateSignature(struct FEconomyGetDraftItemResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabEconomyAPI.DelegateOnSuccessGetDraftItem__DelegateSignature
	void DelegateOnSuccessGetCatalogConfig__DelegateSignature(struct FEconomyGetCatalogConfigResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabEconomyAPI.DelegateOnSuccessGetCatalogConfig__DelegateSignature
	void DelegateOnSuccessExecuteInventoryOperations__DelegateSignature(struct FEconomyExecuteInventoryOperationsResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabEconomyAPI.DelegateOnSuccessExecuteInventoryOperations__DelegateSignature
	void DelegateOnSuccessDeleteItem__DelegateSignature(struct FEconomyDeleteItemResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabEconomyAPI.DelegateOnSuccessDeleteItem__DelegateSignature
	void DelegateOnSuccessDeleteInventoryItems__DelegateSignature(struct FEconomyDeleteInventoryItemsResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabEconomyAPI.DelegateOnSuccessDeleteInventoryItems__DelegateSignature
	void DelegateOnSuccessDeleteInventoryCollection__DelegateSignature(struct FEconomyDeleteInventoryCollectionResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabEconomyAPI.DelegateOnSuccessDeleteInventoryCollection__DelegateSignature
	void DelegateOnSuccessDeleteEntityItemReviews__DelegateSignature(struct FEconomyDeleteEntityItemReviewsResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabEconomyAPI.DelegateOnSuccessDeleteEntityItemReviews__DelegateSignature
	void DelegateOnSuccessCreateUploadUrls__DelegateSignature(struct FEconomyCreateUploadUrlsResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabEconomyAPI.DelegateOnSuccessCreateUploadUrls__DelegateSignature
	void DelegateOnSuccessCreateDraftItem__DelegateSignature(struct FEconomyCreateDraftItemResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabEconomyAPI.DelegateOnSuccessCreateDraftItem__DelegateSignature
	void DelegateOnSuccessAddInventoryItems__DelegateSignature(struct FEconomyAddInventoryItemsResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabEconomyAPI.DelegateOnSuccessAddInventoryItems__DelegateSignature
	void DelegateOnFailurePlayFabError__DelegateSignature(struct FPlayFabError Error, struct UObject* customData); // DelegateFunction PlayFab.PlayFabEconomyAPI.DelegateOnFailurePlayFabError__DelegateSignature
	struct UPlayFabEconomyAPI* CreateUploadUrls(struct FEconomyCreateUploadUrlsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabEconomyAPI.CreateUploadUrls
	struct UPlayFabEconomyAPI* CreateDraftItem(struct FEconomyCreateDraftItemRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabEconomyAPI.CreateDraftItem
	struct UPlayFabEconomyAPI* AddInventoryItems(struct FEconomyAddInventoryItemsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabEconomyAPI.AddInventoryItems
}; 



// Class PlayFab.PlayFabEventsAPI
// Size: 0x110(Inherited: 0x30) 
struct UPlayFabEventsAPI : public UOnlineBlueprintCallProxyBase
{
	struct FMulticastInlineDelegate OnPlayFabResponse;  // 0x30(0x10)
	char pad_64[104];  // 0x40(0x68)
	struct UPlayFabAuthenticationContext* CallAuthenticationContext;  // 0xA8(0x8)
	struct UPlayFabJsonObject* RequestJsonObj;  // 0xB0(0x8)
	struct UPlayFabJsonObject* ResponseJsonObj;  // 0xB8(0x8)
	char pad_192[80];  // 0xC0(0x50)

	struct UPlayFabEventsAPI* WriteTelemetryEvents(struct FEventsWriteEventsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabEventsAPI.WriteTelemetryEvents
	struct UPlayFabEventsAPI* WriteEvents(struct FEventsWriteEventsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabEventsAPI.WriteEvents
	void HelperWriteTelemetryEvents(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabEventsAPI.HelperWriteTelemetryEvents
	void HelperWriteEvents(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabEventsAPI.HelperWriteEvents
	void DelegateOnSuccessWriteTelemetryEvents__DelegateSignature(struct FEventsWriteEventsResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabEventsAPI.DelegateOnSuccessWriteTelemetryEvents__DelegateSignature
	void DelegateOnSuccessWriteEvents__DelegateSignature(struct FEventsWriteEventsResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabEventsAPI.DelegateOnSuccessWriteEvents__DelegateSignature
	void DelegateOnFailurePlayFabError__DelegateSignature(struct FPlayFabError Error, struct UObject* customData); // DelegateFunction PlayFab.PlayFabEventsAPI.DelegateOnFailurePlayFabError__DelegateSignature
}; 



// Class PlayFab.PlayFabLocalizationAPI
// Size: 0x100(Inherited: 0x30) 
struct UPlayFabLocalizationAPI : public UOnlineBlueprintCallProxyBase
{
	struct FMulticastInlineDelegate OnPlayFabResponse;  // 0x30(0x10)
	char pad_64[88];  // 0x40(0x58)
	struct UPlayFabAuthenticationContext* CallAuthenticationContext;  // 0x98(0x8)
	struct UPlayFabJsonObject* RequestJsonObj;  // 0xA0(0x8)
	struct UPlayFabJsonObject* ResponseJsonObj;  // 0xA8(0x8)
	char pad_176[80];  // 0xB0(0x50)

	void HelperGetLanguageList(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabLocalizationAPI.HelperGetLanguageList
	struct UPlayFabLocalizationAPI* GetLanguageList(struct FLocalizationGetLanguageListRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabLocalizationAPI.GetLanguageList
	void DelegateOnSuccessGetLanguageList__DelegateSignature(struct FLocalizationGetLanguageListResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabLocalizationAPI.DelegateOnSuccessGetLanguageList__DelegateSignature
	void DelegateOnFailurePlayFabError__DelegateSignature(struct FPlayFabError Error, struct UObject* customData); // DelegateFunction PlayFab.PlayFabLocalizationAPI.DelegateOnFailurePlayFabError__DelegateSignature
}; 



// Class PlayFab.PlayFabEventsModelDecoder
// Size: 0x28(Inherited: 0x28) 
struct UPlayFabEventsModelDecoder : public UBlueprintFunctionLibrary
{

	struct FEventsWriteEventsResponse decodeWriteEventsResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabEventsModelDecoder.decodeWriteEventsResponseResponse
}; 



// Class PlayFab.PlayFabProfilesAPI
// Size: 0x170(Inherited: 0x30) 
struct UPlayFabProfilesAPI : public UOnlineBlueprintCallProxyBase
{
	struct FMulticastInlineDelegate OnPlayFabResponse;  // 0x30(0x10)
	char pad_64[200];  // 0x40(0xC8)
	struct UPlayFabAuthenticationContext* CallAuthenticationContext;  // 0x108(0x8)
	struct UPlayFabJsonObject* RequestJsonObj;  // 0x110(0x8)
	struct UPlayFabJsonObject* ResponseJsonObj;  // 0x118(0x8)
	char pad_288[80];  // 0x120(0x50)

	struct UPlayFabProfilesAPI* SetProfilePolicy(struct FProfilesSetEntityProfilePolicyRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabProfilesAPI.SetProfilePolicy
	struct UPlayFabProfilesAPI* SetProfileLanguage(struct FProfilesSetProfileLanguageRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabProfilesAPI.SetProfileLanguage
	struct UPlayFabProfilesAPI* SetGlobalPolicy(struct FProfilesSetGlobalPolicyRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabProfilesAPI.SetGlobalPolicy
	void HelperSetProfilePolicy(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabProfilesAPI.HelperSetProfilePolicy
	void HelperSetProfileLanguage(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabProfilesAPI.HelperSetProfileLanguage
	void HelperSetGlobalPolicy(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabProfilesAPI.HelperSetGlobalPolicy
	void HelperGetTitlePlayersFromXboxLiveIDs(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabProfilesAPI.HelperGetTitlePlayersFromXboxLiveIDs
	void HelperGetTitlePlayersFromMasterPlayerAccountIds(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabProfilesAPI.HelperGetTitlePlayersFromMasterPlayerAccountIds
	void HelperGetProfiles(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabProfilesAPI.HelperGetProfiles
	void HelperGetProfile(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabProfilesAPI.HelperGetProfile
	void HelperGetGlobalPolicy(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabProfilesAPI.HelperGetGlobalPolicy
	struct UPlayFabProfilesAPI* GetTitlePlayersFromXboxLiveIDs(struct FProfilesGetTitlePlayersFromXboxLiveIDsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabProfilesAPI.GetTitlePlayersFromXboxLiveIDs
	struct UPlayFabProfilesAPI* GetTitlePlayersFromMasterPlayerAccountIds(struct FProfilesGetTitlePlayersFromMasterPlayerAccountIdsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabProfilesAPI.GetTitlePlayersFromMasterPlayerAccountIds
	struct UPlayFabProfilesAPI* GetProfiles(struct FProfilesGetEntityProfilesRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabProfilesAPI.GetProfiles
	struct UPlayFabProfilesAPI* GetProfile(struct FProfilesGetEntityProfileRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabProfilesAPI.GetProfile
	struct UPlayFabProfilesAPI* GetGlobalPolicy(struct FProfilesGetGlobalPolicyRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabProfilesAPI.GetGlobalPolicy
	void DelegateOnSuccessSetProfilePolicy__DelegateSignature(struct FProfilesSetEntityProfilePolicyResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabProfilesAPI.DelegateOnSuccessSetProfilePolicy__DelegateSignature
	void DelegateOnSuccessSetProfileLanguage__DelegateSignature(struct FProfilesSetProfileLanguageResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabProfilesAPI.DelegateOnSuccessSetProfileLanguage__DelegateSignature
	void DelegateOnSuccessSetGlobalPolicy__DelegateSignature(struct FProfilesSetGlobalPolicyResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabProfilesAPI.DelegateOnSuccessSetGlobalPolicy__DelegateSignature
	void DelegateOnSuccessGetTitlePlayersFromXboxLiveIDs__DelegateSignature(struct FProfilesGetTitlePlayersFromProviderIDsResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabProfilesAPI.DelegateOnSuccessGetTitlePlayersFromXboxLiveIDs__DelegateSignature
	void DelegateOnSuccessGetTitlePlayersFromMasterPlayerAccountIds__DelegateSignature(struct FProfilesGetTitlePlayersFromMasterPlayerAccountIdsResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabProfilesAPI.DelegateOnSuccessGetTitlePlayersFromMasterPlayerAccountIds__DelegateSignature
	void DelegateOnSuccessGetProfiles__DelegateSignature(struct FProfilesGetEntityProfilesResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabProfilesAPI.DelegateOnSuccessGetProfiles__DelegateSignature
	void DelegateOnSuccessGetProfile__DelegateSignature(struct FProfilesGetEntityProfileResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabProfilesAPI.DelegateOnSuccessGetProfile__DelegateSignature
	void DelegateOnSuccessGetGlobalPolicy__DelegateSignature(struct FProfilesGetGlobalPolicyResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabProfilesAPI.DelegateOnSuccessGetGlobalPolicy__DelegateSignature
	void DelegateOnFailurePlayFabError__DelegateSignature(struct FPlayFabError Error, struct UObject* customData); // DelegateFunction PlayFab.PlayFabProfilesAPI.DelegateOnFailurePlayFabError__DelegateSignature
}; 



// Class PlayFab.PlayFabExperimentationAPI
// Size: 0x1C0(Inherited: 0x30) 
struct UPlayFabExperimentationAPI : public UOnlineBlueprintCallProxyBase
{
	struct FMulticastInlineDelegate OnPlayFabResponse;  // 0x30(0x10)
	char pad_64[280];  // 0x40(0x118)
	struct UPlayFabAuthenticationContext* CallAuthenticationContext;  // 0x158(0x8)
	struct UPlayFabJsonObject* RequestJsonObj;  // 0x160(0x8)
	struct UPlayFabJsonObject* ResponseJsonObj;  // 0x168(0x8)
	char pad_368[80];  // 0x170(0x50)

	struct UPlayFabExperimentationAPI* UpdateExperiment(struct FExperimentationUpdateExperimentRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabExperimentationAPI.UpdateExperiment
	struct UPlayFabExperimentationAPI* UpdateExclusionGroup(struct FExperimentationUpdateExclusionGroupRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabExperimentationAPI.UpdateExclusionGroup
	struct UPlayFabExperimentationAPI* StopExperiment(struct FExperimentationStopExperimentRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabExperimentationAPI.StopExperiment
	struct UPlayFabExperimentationAPI* StartExperiment(struct FExperimentationStartExperimentRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabExperimentationAPI.StartExperiment
	void HelperUpdateExperiment(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabExperimentationAPI.HelperUpdateExperiment
	void HelperUpdateExclusionGroup(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabExperimentationAPI.HelperUpdateExclusionGroup
	void HelperStopExperiment(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabExperimentationAPI.HelperStopExperiment
	void HelperStartExperiment(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabExperimentationAPI.HelperStartExperiment
	void HelperGetTreatmentAssignment(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabExperimentationAPI.HelperGetTreatmentAssignment
	void HelperGetLatestScorecard(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabExperimentationAPI.HelperGetLatestScorecard
	void HelperGetExperiments(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabExperimentationAPI.HelperGetExperiments
	void HelperGetExclusionGroupTraffic(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabExperimentationAPI.HelperGetExclusionGroupTraffic
	void HelperGetExclusionGroups(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabExperimentationAPI.HelperGetExclusionGroups
	void HelperDeleteExperiment(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabExperimentationAPI.HelperDeleteExperiment
	void HelperDeleteExclusionGroup(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabExperimentationAPI.HelperDeleteExclusionGroup
	void HelperCreateExperiment(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabExperimentationAPI.HelperCreateExperiment
	void HelperCreateExclusionGroup(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabExperimentationAPI.HelperCreateExclusionGroup
	struct UPlayFabExperimentationAPI* GetTreatmentAssignment(struct FExperimentationGetTreatmentAssignmentRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabExperimentationAPI.GetTreatmentAssignment
	struct UPlayFabExperimentationAPI* GetLatestScorecard(struct FExperimentationGetLatestScorecardRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabExperimentationAPI.GetLatestScorecard
	struct UPlayFabExperimentationAPI* GetExperiments(struct FExperimentationGetExperimentsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabExperimentationAPI.GetExperiments
	struct UPlayFabExperimentationAPI* GetExclusionGroupTraffic(struct FExperimentationGetExclusionGroupTrafficRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabExperimentationAPI.GetExclusionGroupTraffic
	struct UPlayFabExperimentationAPI* GetExclusionGroups(struct FExperimentationGetExclusionGroupsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabExperimentationAPI.GetExclusionGroups
	struct UPlayFabExperimentationAPI* DeleteExperiment(struct FExperimentationDeleteExperimentRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabExperimentationAPI.DeleteExperiment
	struct UPlayFabExperimentationAPI* DeleteExclusionGroup(struct FExperimentationDeleteExclusionGroupRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabExperimentationAPI.DeleteExclusionGroup
	void DelegateOnSuccessUpdateExperiment__DelegateSignature(struct FExperimentationEmptyResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabExperimentationAPI.DelegateOnSuccessUpdateExperiment__DelegateSignature
	void DelegateOnSuccessUpdateExclusionGroup__DelegateSignature(struct FExperimentationEmptyResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabExperimentationAPI.DelegateOnSuccessUpdateExclusionGroup__DelegateSignature
	void DelegateOnSuccessStopExperiment__DelegateSignature(struct FExperimentationEmptyResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabExperimentationAPI.DelegateOnSuccessStopExperiment__DelegateSignature
	void DelegateOnSuccessStartExperiment__DelegateSignature(struct FExperimentationEmptyResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabExperimentationAPI.DelegateOnSuccessStartExperiment__DelegateSignature
	void DelegateOnSuccessGetTreatmentAssignment__DelegateSignature(struct FExperimentationGetTreatmentAssignmentResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabExperimentationAPI.DelegateOnSuccessGetTreatmentAssignment__DelegateSignature
	void DelegateOnSuccessGetLatestScorecard__DelegateSignature(struct FExperimentationGetLatestScorecardResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabExperimentationAPI.DelegateOnSuccessGetLatestScorecard__DelegateSignature
	void DelegateOnSuccessGetExperiments__DelegateSignature(struct FExperimentationGetExperimentsResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabExperimentationAPI.DelegateOnSuccessGetExperiments__DelegateSignature
	void DelegateOnSuccessGetExclusionGroupTraffic__DelegateSignature(struct FExperimentationGetExclusionGroupTrafficResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabExperimentationAPI.DelegateOnSuccessGetExclusionGroupTraffic__DelegateSignature
	void DelegateOnSuccessGetExclusionGroups__DelegateSignature(struct FExperimentationGetExclusionGroupsResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabExperimentationAPI.DelegateOnSuccessGetExclusionGroups__DelegateSignature
	void DelegateOnSuccessDeleteExperiment__DelegateSignature(struct FExperimentationEmptyResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabExperimentationAPI.DelegateOnSuccessDeleteExperiment__DelegateSignature
	void DelegateOnSuccessDeleteExclusionGroup__DelegateSignature(struct FExperimentationEmptyResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabExperimentationAPI.DelegateOnSuccessDeleteExclusionGroup__DelegateSignature
	void DelegateOnSuccessCreateExperiment__DelegateSignature(struct FExperimentationCreateExperimentResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabExperimentationAPI.DelegateOnSuccessCreateExperiment__DelegateSignature
	void DelegateOnSuccessCreateExclusionGroup__DelegateSignature(struct FExperimentationCreateExclusionGroupResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabExperimentationAPI.DelegateOnSuccessCreateExclusionGroup__DelegateSignature
	void DelegateOnFailurePlayFabError__DelegateSignature(struct FPlayFabError Error, struct UObject* customData); // DelegateFunction PlayFab.PlayFabExperimentationAPI.DelegateOnFailurePlayFabError__DelegateSignature
	struct UPlayFabExperimentationAPI* CreateExperiment(struct FExperimentationCreateExperimentRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabExperimentationAPI.CreateExperiment
	struct UPlayFabExperimentationAPI* CreateExclusionGroup(struct FExperimentationCreateExclusionGroupRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabExperimentationAPI.CreateExclusionGroup
}; 



// Class PlayFab.PlayFabProfilesModelDecoder
// Size: 0x28(Inherited: 0x28) 
struct UPlayFabProfilesModelDecoder : public UBlueprintFunctionLibrary
{

	struct FProfilesSetProfileLanguageResponse decodeSetProfileLanguageResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabProfilesModelDecoder.decodeSetProfileLanguageResponseResponse
	struct FProfilesSetGlobalPolicyResponse decodeSetGlobalPolicyResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabProfilesModelDecoder.decodeSetGlobalPolicyResponseResponse
	struct FProfilesSetEntityProfilePolicyResponse decodeSetEntityProfilePolicyResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabProfilesModelDecoder.decodeSetEntityProfilePolicyResponseResponse
	struct FProfilesGetTitlePlayersFromProviderIDsResponse decodeGetTitlePlayersFromProviderIDsResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabProfilesModelDecoder.decodeGetTitlePlayersFromProviderIDsResponseResponse
	struct FProfilesGetTitlePlayersFromMasterPlayerAccountIdsResponse decodeGetTitlePlayersFromMasterPlayerAccountIdsResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabProfilesModelDecoder.decodeGetTitlePlayersFromMasterPlayerAccountIdsResponseResponse
	struct FProfilesGetGlobalPolicyResponse decodeGetGlobalPolicyResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabProfilesModelDecoder.decodeGetGlobalPolicyResponseResponse
	struct FProfilesGetEntityProfilesResponse decodeGetEntityProfilesResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabProfilesModelDecoder.decodeGetEntityProfilesResponseResponse
	struct FProfilesGetEntityProfileResponse decodeGetEntityProfileResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabProfilesModelDecoder.decodeGetEntityProfileResponseResponse
}; 



// Class PlayFab.PlayFabExperimentationModelDecoder
// Size: 0x28(Inherited: 0x28) 
struct UPlayFabExperimentationModelDecoder : public UBlueprintFunctionLibrary
{

	struct FExperimentationGetTreatmentAssignmentResult decodeGetTreatmentAssignmentResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabExperimentationModelDecoder.decodeGetTreatmentAssignmentResultResponse
	struct FExperimentationGetLatestScorecardResult decodeGetLatestScorecardResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabExperimentationModelDecoder.decodeGetLatestScorecardResultResponse
	struct FExperimentationGetExperimentsResult decodeGetExperimentsResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabExperimentationModelDecoder.decodeGetExperimentsResultResponse
	struct FExperimentationGetExclusionGroupTrafficResult decodeGetExclusionGroupTrafficResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabExperimentationModelDecoder.decodeGetExclusionGroupTrafficResultResponse
	struct FExperimentationGetExclusionGroupsResult decodeGetExclusionGroupsResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabExperimentationModelDecoder.decodeGetExclusionGroupsResultResponse
	struct FExperimentationEmptyResponse decodeEmptyResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabExperimentationModelDecoder.decodeEmptyResponseResponse
	struct FExperimentationCreateExperimentResult decodeCreateExperimentResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabExperimentationModelDecoder.decodeCreateExperimentResultResponse
	struct FExperimentationCreateExclusionGroupResult decodeCreateExclusionGroupResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabExperimentationModelDecoder.decodeCreateExclusionGroupResultResponse
}; 



// Class PlayFab.PlayFabGroupsAPI
// Size: 0x280(Inherited: 0x30) 
struct UPlayFabGroupsAPI : public UOnlineBlueprintCallProxyBase
{
	struct FMulticastInlineDelegate OnPlayFabResponse;  // 0x30(0x10)
	char pad_64[472];  // 0x40(0x1D8)
	struct UPlayFabAuthenticationContext* CallAuthenticationContext;  // 0x218(0x8)
	struct UPlayFabJsonObject* RequestJsonObj;  // 0x220(0x8)
	struct UPlayFabJsonObject* ResponseJsonObj;  // 0x228(0x8)
	char pad_560[80];  // 0x230(0x50)

	struct UPlayFabGroupsAPI* UpdateRole(struct FGroupsUpdateGroupRoleRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabGroupsAPI.UpdateRole
	struct UPlayFabGroupsAPI* UpdateGroup(struct FGroupsUpdateGroupRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabGroupsAPI.UpdateGroup
	struct UPlayFabGroupsAPI* UnblockEntity(struct FGroupsUnblockEntityRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabGroupsAPI.UnblockEntity
	struct UPlayFabGroupsAPI* RemoveMembers(struct FGroupsRemoveMembersRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabGroupsAPI.RemoveMembers
	struct UPlayFabGroupsAPI* RemoveGroupInvitation(struct FGroupsRemoveGroupInvitationRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabGroupsAPI.RemoveGroupInvitation
	struct UPlayFabGroupsAPI* RemoveGroupApplication(struct FGroupsRemoveGroupApplicationRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabGroupsAPI.RemoveGroupApplication
	struct UPlayFabGroupsAPI* ListMembershipOpportunities(struct FGroupsListMembershipOpportunitiesRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabGroupsAPI.ListMembershipOpportunities
	struct UPlayFabGroupsAPI* ListMembership(struct FGroupsListMembershipRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabGroupsAPI.ListMembership
	struct UPlayFabGroupsAPI* ListGroupMembers(struct FGroupsListGroupMembersRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabGroupsAPI.ListGroupMembers
	struct UPlayFabGroupsAPI* ListGroupInvitations(struct FGroupsListGroupInvitationsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabGroupsAPI.ListGroupInvitations
	struct UPlayFabGroupsAPI* ListGroupBlocks(struct FGroupsListGroupBlocksRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabGroupsAPI.ListGroupBlocks
	struct UPlayFabGroupsAPI* ListGroupApplications(struct FGroupsListGroupApplicationsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabGroupsAPI.ListGroupApplications
	struct UPlayFabGroupsAPI* IsMember(struct FGroupsIsMemberRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabGroupsAPI.IsMember
	struct UPlayFabGroupsAPI* InviteToGroup(struct FGroupsInviteToGroupRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabGroupsAPI.InviteToGroup
	void HelperUpdateRole(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabGroupsAPI.HelperUpdateRole
	void HelperUpdateGroup(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabGroupsAPI.HelperUpdateGroup
	void HelperUnblockEntity(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabGroupsAPI.HelperUnblockEntity
	void HelperRemoveMembers(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabGroupsAPI.HelperRemoveMembers
	void HelperRemoveGroupInvitation(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabGroupsAPI.HelperRemoveGroupInvitation
	void HelperRemoveGroupApplication(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabGroupsAPI.HelperRemoveGroupApplication
	void HelperListMembershipOpportunities(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabGroupsAPI.HelperListMembershipOpportunities
	void HelperListMembership(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabGroupsAPI.HelperListMembership
	void HelperListGroupMembers(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabGroupsAPI.HelperListGroupMembers
	void HelperListGroupInvitations(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabGroupsAPI.HelperListGroupInvitations
	void HelperListGroupBlocks(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabGroupsAPI.HelperListGroupBlocks
	void HelperListGroupApplications(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabGroupsAPI.HelperListGroupApplications
	void HelperIsMember(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabGroupsAPI.HelperIsMember
	void HelperInviteToGroup(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabGroupsAPI.HelperInviteToGroup
	void HelperGetGroup(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabGroupsAPI.HelperGetGroup
	void HelperDeleteRole(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabGroupsAPI.HelperDeleteRole
	void HelperDeleteGroup(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabGroupsAPI.HelperDeleteGroup
	void HelperCreateRole(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabGroupsAPI.HelperCreateRole
	void HelperCreateGroup(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabGroupsAPI.HelperCreateGroup
	void HelperChangeMemberRole(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabGroupsAPI.HelperChangeMemberRole
	void HelperBlockEntity(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabGroupsAPI.HelperBlockEntity
	void HelperApplyToGroup(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabGroupsAPI.HelperApplyToGroup
	void HelperAddMembers(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabGroupsAPI.HelperAddMembers
	void HelperAcceptGroupInvitation(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabGroupsAPI.HelperAcceptGroupInvitation
	void HelperAcceptGroupApplication(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabGroupsAPI.HelperAcceptGroupApplication
	struct UPlayFabGroupsAPI* GetGroup(struct FGroupsGetGroupRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabGroupsAPI.GetGroup
	struct UPlayFabGroupsAPI* DeleteRole(struct FGroupsDeleteRoleRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabGroupsAPI.DeleteRole
	struct UPlayFabGroupsAPI* DeleteGroup(struct FGroupsDeleteGroupRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabGroupsAPI.DeleteGroup
	void DelegateOnSuccessUpdateRole__DelegateSignature(struct FGroupsUpdateGroupRoleResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabGroupsAPI.DelegateOnSuccessUpdateRole__DelegateSignature
	void DelegateOnSuccessUpdateGroup__DelegateSignature(struct FGroupsUpdateGroupResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabGroupsAPI.DelegateOnSuccessUpdateGroup__DelegateSignature
	void DelegateOnSuccessUnblockEntity__DelegateSignature(struct FGroupsEmptyResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabGroupsAPI.DelegateOnSuccessUnblockEntity__DelegateSignature
	void DelegateOnSuccessRemoveMembers__DelegateSignature(struct FGroupsEmptyResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabGroupsAPI.DelegateOnSuccessRemoveMembers__DelegateSignature
	void DelegateOnSuccessRemoveGroupInvitation__DelegateSignature(struct FGroupsEmptyResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabGroupsAPI.DelegateOnSuccessRemoveGroupInvitation__DelegateSignature
	void DelegateOnSuccessRemoveGroupApplication__DelegateSignature(struct FGroupsEmptyResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabGroupsAPI.DelegateOnSuccessRemoveGroupApplication__DelegateSignature
	void DelegateOnSuccessListMembershipOpportunities__DelegateSignature(struct FGroupsListMembershipOpportunitiesResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabGroupsAPI.DelegateOnSuccessListMembershipOpportunities__DelegateSignature
	void DelegateOnSuccessListMembership__DelegateSignature(struct FGroupsListMembershipResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabGroupsAPI.DelegateOnSuccessListMembership__DelegateSignature
	void DelegateOnSuccessListGroupMembers__DelegateSignature(struct FGroupsListGroupMembersResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabGroupsAPI.DelegateOnSuccessListGroupMembers__DelegateSignature
	void DelegateOnSuccessListGroupInvitations__DelegateSignature(struct FGroupsListGroupInvitationsResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabGroupsAPI.DelegateOnSuccessListGroupInvitations__DelegateSignature
	void DelegateOnSuccessListGroupBlocks__DelegateSignature(struct FGroupsListGroupBlocksResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabGroupsAPI.DelegateOnSuccessListGroupBlocks__DelegateSignature
	void DelegateOnSuccessListGroupApplications__DelegateSignature(struct FGroupsListGroupApplicationsResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabGroupsAPI.DelegateOnSuccessListGroupApplications__DelegateSignature
	void DelegateOnSuccessIsMember__DelegateSignature(struct FGroupsIsMemberResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabGroupsAPI.DelegateOnSuccessIsMember__DelegateSignature
	void DelegateOnSuccessInviteToGroup__DelegateSignature(struct FGroupsInviteToGroupResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabGroupsAPI.DelegateOnSuccessInviteToGroup__DelegateSignature
	void DelegateOnSuccessGetGroup__DelegateSignature(struct FGroupsGetGroupResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabGroupsAPI.DelegateOnSuccessGetGroup__DelegateSignature
	void DelegateOnSuccessDeleteRole__DelegateSignature(struct FGroupsEmptyResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabGroupsAPI.DelegateOnSuccessDeleteRole__DelegateSignature
	void DelegateOnSuccessDeleteGroup__DelegateSignature(struct FGroupsEmptyResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabGroupsAPI.DelegateOnSuccessDeleteGroup__DelegateSignature
	void DelegateOnSuccessCreateRole__DelegateSignature(struct FGroupsCreateGroupRoleResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabGroupsAPI.DelegateOnSuccessCreateRole__DelegateSignature
	void DelegateOnSuccessCreateGroup__DelegateSignature(struct FGroupsCreateGroupResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabGroupsAPI.DelegateOnSuccessCreateGroup__DelegateSignature
	void DelegateOnSuccessChangeMemberRole__DelegateSignature(struct FGroupsEmptyResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabGroupsAPI.DelegateOnSuccessChangeMemberRole__DelegateSignature
	void DelegateOnSuccessBlockEntity__DelegateSignature(struct FGroupsEmptyResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabGroupsAPI.DelegateOnSuccessBlockEntity__DelegateSignature
	void DelegateOnSuccessApplyToGroup__DelegateSignature(struct FGroupsApplyToGroupResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabGroupsAPI.DelegateOnSuccessApplyToGroup__DelegateSignature
	void DelegateOnSuccessAddMembers__DelegateSignature(struct FGroupsEmptyResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabGroupsAPI.DelegateOnSuccessAddMembers__DelegateSignature
	void DelegateOnSuccessAcceptGroupInvitation__DelegateSignature(struct FGroupsEmptyResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabGroupsAPI.DelegateOnSuccessAcceptGroupInvitation__DelegateSignature
	void DelegateOnSuccessAcceptGroupApplication__DelegateSignature(struct FGroupsEmptyResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabGroupsAPI.DelegateOnSuccessAcceptGroupApplication__DelegateSignature
	void DelegateOnFailurePlayFabError__DelegateSignature(struct FPlayFabError Error, struct UObject* customData); // DelegateFunction PlayFab.PlayFabGroupsAPI.DelegateOnFailurePlayFabError__DelegateSignature
	struct UPlayFabGroupsAPI* CreateRole(struct FGroupsCreateGroupRoleRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabGroupsAPI.CreateRole
	struct UPlayFabGroupsAPI* CreateGroup(struct FGroupsCreateGroupRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabGroupsAPI.CreateGroup
	struct UPlayFabGroupsAPI* ChangeMemberRole(struct FGroupsChangeMemberRoleRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabGroupsAPI.ChangeMemberRole
	struct UPlayFabGroupsAPI* BlockEntity(struct FGroupsBlockEntityRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabGroupsAPI.BlockEntity
	struct UPlayFabGroupsAPI* ApplyToGroup(struct FGroupsApplyToGroupRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabGroupsAPI.ApplyToGroup
	struct UPlayFabGroupsAPI* AddMembers(struct FGroupsAddMembersRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabGroupsAPI.AddMembers
	struct UPlayFabGroupsAPI* AcceptGroupInvitation(struct FGroupsAcceptGroupInvitationRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabGroupsAPI.AcceptGroupInvitation
	struct UPlayFabGroupsAPI* AcceptGroupApplication(struct FGroupsAcceptGroupApplicationRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabGroupsAPI.AcceptGroupApplication
}; 



// Class PlayFab.PlayFabGroupsModelDecoder
// Size: 0x28(Inherited: 0x28) 
struct UPlayFabGroupsModelDecoder : public UBlueprintFunctionLibrary
{

	struct FGroupsUpdateGroupRoleResponse decodeUpdateGroupRoleResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabGroupsModelDecoder.decodeUpdateGroupRoleResponseResponse
	struct FGroupsUpdateGroupResponse decodeUpdateGroupResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabGroupsModelDecoder.decodeUpdateGroupResponseResponse
	struct FGroupsListMembershipResponse decodeListMembershipResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabGroupsModelDecoder.decodeListMembershipResponseResponse
	struct FGroupsListMembershipOpportunitiesResponse decodeListMembershipOpportunitiesResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabGroupsModelDecoder.decodeListMembershipOpportunitiesResponseResponse
	struct FGroupsListGroupMembersResponse decodeListGroupMembersResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabGroupsModelDecoder.decodeListGroupMembersResponseResponse
	struct FGroupsListGroupInvitationsResponse decodeListGroupInvitationsResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabGroupsModelDecoder.decodeListGroupInvitationsResponseResponse
	struct FGroupsListGroupBlocksResponse decodeListGroupBlocksResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabGroupsModelDecoder.decodeListGroupBlocksResponseResponse
	struct FGroupsListGroupApplicationsResponse decodeListGroupApplicationsResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabGroupsModelDecoder.decodeListGroupApplicationsResponseResponse
	struct FGroupsIsMemberResponse decodeIsMemberResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabGroupsModelDecoder.decodeIsMemberResponseResponse
	struct FGroupsInviteToGroupResponse decodeInviteToGroupResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabGroupsModelDecoder.decodeInviteToGroupResponseResponse
	struct FGroupsGetGroupResponse decodeGetGroupResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabGroupsModelDecoder.decodeGetGroupResponseResponse
	struct FGroupsEmptyResponse decodeEmptyResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabGroupsModelDecoder.decodeEmptyResponseResponse
	struct FGroupsCreateGroupRoleResponse decodeCreateGroupRoleResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabGroupsModelDecoder.decodeCreateGroupRoleResponseResponse
	struct FGroupsCreateGroupResponse decodeCreateGroupResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabGroupsModelDecoder.decodeCreateGroupResponseResponse
	struct FGroupsApplyToGroupResponse decodeApplyToGroupResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabGroupsModelDecoder.decodeApplyToGroupResponseResponse
}; 



// Class PlayFab.PlayFabInsightsAPI
// Size: 0x150(Inherited: 0x30) 
struct UPlayFabInsightsAPI : public UOnlineBlueprintCallProxyBase
{
	struct FMulticastInlineDelegate OnPlayFabResponse;  // 0x30(0x10)
	char pad_64[168];  // 0x40(0xA8)
	struct UPlayFabAuthenticationContext* CallAuthenticationContext;  // 0xE8(0x8)
	struct UPlayFabJsonObject* RequestJsonObj;  // 0xF0(0x8)
	struct UPlayFabJsonObject* ResponseJsonObj;  // 0xF8(0x8)
	char pad_256[80];  // 0x100(0x50)

	struct UPlayFabInsightsAPI* SetStorageRetention(struct FInsightsInsightsSetStorageRetentionRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabInsightsAPI.SetStorageRetention
	struct UPlayFabInsightsAPI* SetPerformance(struct FInsightsInsightsSetPerformanceRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabInsightsAPI.SetPerformance
	void HelperSetStorageRetention(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabInsightsAPI.HelperSetStorageRetention
	void HelperSetPerformance(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabInsightsAPI.HelperSetPerformance
	void HelperGetPendingOperations(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabInsightsAPI.HelperGetPendingOperations
	void HelperGetOperationStatus(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabInsightsAPI.HelperGetOperationStatus
	void HelperGetLimits(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabInsightsAPI.HelperGetLimits
	void HelperGetDetails(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabInsightsAPI.HelperGetDetails
	struct UPlayFabInsightsAPI* GetPendingOperations(struct FInsightsInsightsGetPendingOperationsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabInsightsAPI.GetPendingOperations
	struct UPlayFabInsightsAPI* GetOperationStatus(struct FInsightsInsightsGetOperationStatusRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabInsightsAPI.GetOperationStatus
	struct UPlayFabInsightsAPI* GetLimits(struct FInsightsInsightsEmptyRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabInsightsAPI.GetLimits
	struct UPlayFabInsightsAPI* GetDetails(struct FInsightsInsightsEmptyRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabInsightsAPI.GetDetails
	void DelegateOnSuccessSetStorageRetention__DelegateSignature(struct FInsightsInsightsOperationResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabInsightsAPI.DelegateOnSuccessSetStorageRetention__DelegateSignature
	void DelegateOnSuccessSetPerformance__DelegateSignature(struct FInsightsInsightsOperationResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabInsightsAPI.DelegateOnSuccessSetPerformance__DelegateSignature
	void DelegateOnSuccessGetPendingOperations__DelegateSignature(struct FInsightsInsightsGetPendingOperationsResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabInsightsAPI.DelegateOnSuccessGetPendingOperations__DelegateSignature
	void DelegateOnSuccessGetOperationStatus__DelegateSignature(struct FInsightsInsightsGetOperationStatusResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabInsightsAPI.DelegateOnSuccessGetOperationStatus__DelegateSignature
	void DelegateOnSuccessGetLimits__DelegateSignature(struct FInsightsInsightsGetLimitsResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabInsightsAPI.DelegateOnSuccessGetLimits__DelegateSignature
	void DelegateOnSuccessGetDetails__DelegateSignature(struct FInsightsInsightsGetDetailsResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabInsightsAPI.DelegateOnSuccessGetDetails__DelegateSignature
	void DelegateOnFailurePlayFabError__DelegateSignature(struct FPlayFabError Error, struct UObject* customData); // DelegateFunction PlayFab.PlayFabInsightsAPI.DelegateOnFailurePlayFabError__DelegateSignature
}; 



// Class PlayFab.PlayFabInsightsModelDecoder
// Size: 0x28(Inherited: 0x28) 
struct UPlayFabInsightsModelDecoder : public UBlueprintFunctionLibrary
{

	struct FInsightsInsightsOperationResponse decodeInsightsOperationResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabInsightsModelDecoder.decodeInsightsOperationResponseResponse
	struct FInsightsInsightsGetPendingOperationsResponse decodeInsightsGetPendingOperationsResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabInsightsModelDecoder.decodeInsightsGetPendingOperationsResponseResponse
	struct FInsightsInsightsGetOperationStatusResponse decodeInsightsGetOperationStatusResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabInsightsModelDecoder.decodeInsightsGetOperationStatusResponseResponse
	struct FInsightsInsightsGetLimitsResponse decodeInsightsGetLimitsResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabInsightsModelDecoder.decodeInsightsGetLimitsResponseResponse
	struct FInsightsInsightsGetDetailsResponse decodeInsightsGetDetailsResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabInsightsModelDecoder.decodeInsightsGetDetailsResponseResponse
}; 



// Class PlayFab.PlayFabJsonValue
// Size: 0x38(Inherited: 0x28) 
struct UPlayFabJsonValue : public UObject
{
	char pad_40[16];  // 0x28(0x10)

	bool IsNull(); // Function PlayFab.PlayFabJsonValue.IsNull
	struct FString GetTypeString(); // Function PlayFab.PlayFabJsonValue.GetTypeString
	char EPFJson GetType(); // Function PlayFab.PlayFabJsonValue.GetType
	struct UPlayFabJsonValue* ConstructJsonValueString(struct UObject* WorldContextObject, struct FString StringValue); // Function PlayFab.PlayFabJsonValue.ConstructJsonValueString
	struct UPlayFabJsonValue* ConstructJsonValueObject(struct UObject* WorldContextObject, struct UPlayFabJsonObject* JsonObject); // Function PlayFab.PlayFabJsonValue.ConstructJsonValueObject
	struct UPlayFabJsonValue* ConstructJsonValueNumber(struct UObject* WorldContextObject, float Number); // Function PlayFab.PlayFabJsonValue.ConstructJsonValueNumber
	struct UPlayFabJsonValue* ConstructJsonValueBool(struct UObject* WorldContextObject, bool InValue); // Function PlayFab.PlayFabJsonValue.ConstructJsonValueBool
	struct UPlayFabJsonValue* ConstructJsonValueArray(struct UObject* WorldContextObject, struct TArray<struct UPlayFabJsonValue*>& inArray); // Function PlayFab.PlayFabJsonValue.ConstructJsonValueArray
	struct FString AsString(); // Function PlayFab.PlayFabJsonValue.AsString
	struct UPlayFabJsonObject* AsObject(); // Function PlayFab.PlayFabJsonValue.AsObject
	float AsNumber(); // Function PlayFab.PlayFabJsonValue.AsNumber
	bool AsBool(); // Function PlayFab.PlayFabJsonValue.AsBool
	struct TArray<struct UPlayFabJsonValue*> AsArray(); // Function PlayFab.PlayFabJsonValue.AsArray
}; 



// Class PlayFab.PlayFabLocalizationModelDecoder
// Size: 0x28(Inherited: 0x28) 
struct UPlayFabLocalizationModelDecoder : public UBlueprintFunctionLibrary
{

	struct FLocalizationGetLanguageListResponse decodeGetLanguageListResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabLocalizationModelDecoder.decodeGetLanguageListResponseResponse
}; 



// Class PlayFab.PlayFabMatchmakerAPI
// Size: 0x130(Inherited: 0x30) 
struct UPlayFabMatchmakerAPI : public UOnlineBlueprintCallProxyBase
{
	struct FMulticastInlineDelegate OnPlayFabResponse;  // 0x30(0x10)
	char pad_64[136];  // 0x40(0x88)
	struct UPlayFabAuthenticationContext* CallAuthenticationContext;  // 0xC8(0x8)
	struct UPlayFabJsonObject* RequestJsonObj;  // 0xD0(0x8)
	struct UPlayFabJsonObject* ResponseJsonObj;  // 0xD8(0x8)
	char pad_224[80];  // 0xE0(0x50)

	struct UPlayFabMatchmakerAPI* UserInfo(struct FMatchmakerUserInfoRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabMatchmakerAPI.UserInfo
	struct UPlayFabMatchmakerAPI* PlayerLeft(struct FMatchmakerPlayerLeftRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabMatchmakerAPI.PlayerLeft
	struct UPlayFabMatchmakerAPI* PlayerJoined(struct FMatchmakerPlayerJoinedRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabMatchmakerAPI.PlayerJoined
	void HelperUserInfo(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabMatchmakerAPI.HelperUserInfo
	void HelperPlayerLeft(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabMatchmakerAPI.HelperPlayerLeft
	void HelperPlayerJoined(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabMatchmakerAPI.HelperPlayerJoined
	void HelperAuthUser(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabMatchmakerAPI.HelperAuthUser
	void DelegateOnSuccessUserInfo__DelegateSignature(struct FMatchmakerUserInfoResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabMatchmakerAPI.DelegateOnSuccessUserInfo__DelegateSignature
	void DelegateOnSuccessPlayerLeft__DelegateSignature(struct FMatchmakerPlayerLeftResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabMatchmakerAPI.DelegateOnSuccessPlayerLeft__DelegateSignature
	void DelegateOnSuccessPlayerJoined__DelegateSignature(struct FMatchmakerPlayerJoinedResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabMatchmakerAPI.DelegateOnSuccessPlayerJoined__DelegateSignature
	void DelegateOnSuccessAuthUser__DelegateSignature(struct FMatchmakerAuthUserResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabMatchmakerAPI.DelegateOnSuccessAuthUser__DelegateSignature
	void DelegateOnFailurePlayFabError__DelegateSignature(struct FPlayFabError Error, struct UObject* customData); // DelegateFunction PlayFab.PlayFabMatchmakerAPI.DelegateOnFailurePlayFabError__DelegateSignature
	struct UPlayFabMatchmakerAPI* AuthUser(struct FMatchmakerAuthUserRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabMatchmakerAPI.AuthUser
}; 



// Class PlayFab.PlayFabMatchmakerModelDecoder
// Size: 0x28(Inherited: 0x28) 
struct UPlayFabMatchmakerModelDecoder : public UBlueprintFunctionLibrary
{

	struct FMatchmakerUserInfoResponse decodeUserInfoResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabMatchmakerModelDecoder.decodeUserInfoResponseResponse
	struct FMatchmakerPlayerLeftResponse decodePlayerLeftResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabMatchmakerModelDecoder.decodePlayerLeftResponseResponse
	struct FMatchmakerPlayerJoinedResponse decodePlayerJoinedResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabMatchmakerModelDecoder.decodePlayerJoinedResponseResponse
	struct FMatchmakerAuthUserResponse decodeAuthUserResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabMatchmakerModelDecoder.decodeAuthUserResponseResponse
}; 



// Class PlayFab.PlayFabMultiplayerAPI
// Size: 0x590(Inherited: 0x30) 
struct UPlayFabMultiplayerAPI : public UOnlineBlueprintCallProxyBase
{
	struct FMulticastInlineDelegate OnPlayFabResponse;  // 0x30(0x10)
	char pad_64[1256];  // 0x40(0x4E8)
	struct UPlayFabAuthenticationContext* CallAuthenticationContext;  // 0x528(0x8)
	struct UPlayFabJsonObject* RequestJsonObj;  // 0x530(0x8)
	struct UPlayFabJsonObject* ResponseJsonObj;  // 0x538(0x8)
	char pad_1344[80];  // 0x540(0x50)

	struct UPlayFabMultiplayerAPI* UploadCertificate(struct FMultiplayerUploadCertificateRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabMultiplayerAPI.UploadCertificate
	struct UPlayFabMultiplayerAPI* UpdateLobby(struct FMultiplayerUpdateLobbyRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabMultiplayerAPI.UpdateLobby
	struct UPlayFabMultiplayerAPI* UpdateBuildRegions(struct FMultiplayerUpdateBuildRegionsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabMultiplayerAPI.UpdateBuildRegions
	struct UPlayFabMultiplayerAPI* UpdateBuildRegion(struct FMultiplayerUpdateBuildRegionRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabMultiplayerAPI.UpdateBuildRegion
	struct UPlayFabMultiplayerAPI* UpdateBuildName(struct FMultiplayerUpdateBuildNameRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabMultiplayerAPI.UpdateBuildName
	struct UPlayFabMultiplayerAPI* UpdateBuildAlias(struct FMultiplayerUpdateBuildAliasRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabMultiplayerAPI.UpdateBuildAlias
	struct UPlayFabMultiplayerAPI* UntagContainerImage(struct FMultiplayerUntagContainerImageRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabMultiplayerAPI.UntagContainerImage
	struct UPlayFabMultiplayerAPI* UnsubscribeFromLobbyResource(struct FMultiplayerUnsubscribeFromLobbyResourceRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabMultiplayerAPI.UnsubscribeFromLobbyResource
	struct UPlayFabMultiplayerAPI* SubscribeToLobbyResource(struct FMultiplayerSubscribeToLobbyResourceRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabMultiplayerAPI.SubscribeToLobbyResource
	struct UPlayFabMultiplayerAPI* ShutdownMultiplayerServer(struct FMultiplayerShutdownMultiplayerServerRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabMultiplayerAPI.ShutdownMultiplayerServer
	struct UPlayFabMultiplayerAPI* RolloverContainerRegistryCredentials(struct FMultiplayerRolloverContainerRegistryCredentialsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabMultiplayerAPI.RolloverContainerRegistryCredentials
	struct UPlayFabMultiplayerAPI* RequestMultiplayerServer(struct FMultiplayerRequestMultiplayerServerRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabMultiplayerAPI.RequestMultiplayerServer
	struct UPlayFabMultiplayerAPI* RemoveMember(struct FMultiplayerRemoveMemberFromLobbyRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabMultiplayerAPI.RemoveMember
	struct UPlayFabMultiplayerAPI* ListVirtualMachineSummaries(struct FMultiplayerListVirtualMachineSummariesRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabMultiplayerAPI.ListVirtualMachineSummaries
	struct UPlayFabMultiplayerAPI* ListTitleMultiplayerServersQuotaChanges(struct FMultiplayerListTitleMultiplayerServersQuotaChangesRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabMultiplayerAPI.ListTitleMultiplayerServersQuotaChanges
	struct UPlayFabMultiplayerAPI* ListServerBackfillTicketsForPlayer(struct FMultiplayerListServerBackfillTicketsForPlayerRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabMultiplayerAPI.ListServerBackfillTicketsForPlayer
	struct UPlayFabMultiplayerAPI* ListQosServersForTitle(struct FMultiplayerListQosServersForTitleRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabMultiplayerAPI.ListQosServersForTitle
	struct UPlayFabMultiplayerAPI* ListPartyQosServers(struct FMultiplayerListPartyQosServersRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabMultiplayerAPI.ListPartyQosServers
	struct UPlayFabMultiplayerAPI* ListMultiplayerServers(struct FMultiplayerListMultiplayerServersRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabMultiplayerAPI.ListMultiplayerServers
	struct UPlayFabMultiplayerAPI* ListMatchmakingTicketsForPlayer(struct FMultiplayerListMatchmakingTicketsForPlayerRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabMultiplayerAPI.ListMatchmakingTicketsForPlayer
	struct UPlayFabMultiplayerAPI* ListContainerImageTags(struct FMultiplayerListContainerImageTagsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabMultiplayerAPI.ListContainerImageTags
	struct UPlayFabMultiplayerAPI* ListContainerImages(struct FMultiplayerListContainerImagesRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabMultiplayerAPI.ListContainerImages
	struct UPlayFabMultiplayerAPI* ListCertificateSummaries(struct FMultiplayerListCertificateSummariesRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabMultiplayerAPI.ListCertificateSummaries
	struct UPlayFabMultiplayerAPI* ListBuildSummariesV2(struct FMultiplayerListBuildSummariesRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabMultiplayerAPI.ListBuildSummariesV2
	struct UPlayFabMultiplayerAPI* ListBuildAliases(struct FMultiplayerListBuildAliasesRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabMultiplayerAPI.ListBuildAliases
	struct UPlayFabMultiplayerAPI* ListAssetSummaries(struct FMultiplayerListAssetSummariesRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabMultiplayerAPI.ListAssetSummaries
	struct UPlayFabMultiplayerAPI* ListArchivedMultiplayerServers(struct FMultiplayerListMultiplayerServersRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabMultiplayerAPI.ListArchivedMultiplayerServers
	struct UPlayFabMultiplayerAPI* LeaveLobby(struct FMultiplayerLeaveLobbyRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabMultiplayerAPI.LeaveLobby
	struct UPlayFabMultiplayerAPI* JoinMatchmakingTicket(struct FMultiplayerJoinMatchmakingTicketRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabMultiplayerAPI.JoinMatchmakingTicket
	struct UPlayFabMultiplayerAPI* JoinLobby(struct FMultiplayerJoinLobbyRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabMultiplayerAPI.JoinLobby
	struct UPlayFabMultiplayerAPI* JoinArrangedLobby(struct FMultiplayerJoinArrangedLobbyRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabMultiplayerAPI.JoinArrangedLobby
	struct UPlayFabMultiplayerAPI* InviteToLobby(struct FMultiplayerInviteToLobbyRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabMultiplayerAPI.InviteToLobby
	void HelperUploadCertificate(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabMultiplayerAPI.HelperUploadCertificate
	void HelperUpdateLobby(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabMultiplayerAPI.HelperUpdateLobby
	void HelperUpdateBuildRegions(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabMultiplayerAPI.HelperUpdateBuildRegions
	void HelperUpdateBuildRegion(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabMultiplayerAPI.HelperUpdateBuildRegion
	void HelperUpdateBuildName(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabMultiplayerAPI.HelperUpdateBuildName
	void HelperUpdateBuildAlias(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabMultiplayerAPI.HelperUpdateBuildAlias
	void HelperUntagContainerImage(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabMultiplayerAPI.HelperUntagContainerImage
	void HelperUnsubscribeFromLobbyResource(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabMultiplayerAPI.HelperUnsubscribeFromLobbyResource
	void HelperSubscribeToLobbyResource(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabMultiplayerAPI.HelperSubscribeToLobbyResource
	void HelperShutdownMultiplayerServer(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabMultiplayerAPI.HelperShutdownMultiplayerServer
	void HelperRolloverContainerRegistryCredentials(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabMultiplayerAPI.HelperRolloverContainerRegistryCredentials
	void HelperRequestMultiplayerServer(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabMultiplayerAPI.HelperRequestMultiplayerServer
	void HelperRemoveMember(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabMultiplayerAPI.HelperRemoveMember
	void HelperListVirtualMachineSummaries(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabMultiplayerAPI.HelperListVirtualMachineSummaries
	void HelperListTitleMultiplayerServersQuotaChanges(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabMultiplayerAPI.HelperListTitleMultiplayerServersQuotaChanges
	void HelperListServerBackfillTicketsForPlayer(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabMultiplayerAPI.HelperListServerBackfillTicketsForPlayer
	void HelperListQosServersForTitle(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabMultiplayerAPI.HelperListQosServersForTitle
	void HelperListPartyQosServers(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabMultiplayerAPI.HelperListPartyQosServers
	void HelperListMultiplayerServers(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabMultiplayerAPI.HelperListMultiplayerServers
	void HelperListMatchmakingTicketsForPlayer(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabMultiplayerAPI.HelperListMatchmakingTicketsForPlayer
	void HelperListContainerImageTags(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabMultiplayerAPI.HelperListContainerImageTags
	void HelperListContainerImages(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabMultiplayerAPI.HelperListContainerImages
	void HelperListCertificateSummaries(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabMultiplayerAPI.HelperListCertificateSummaries
	void HelperListBuildSummariesV2(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabMultiplayerAPI.HelperListBuildSummariesV2
	void HelperListBuildAliases(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabMultiplayerAPI.HelperListBuildAliases
	void HelperListAssetSummaries(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabMultiplayerAPI.HelperListAssetSummaries
	void HelperListArchivedMultiplayerServers(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabMultiplayerAPI.HelperListArchivedMultiplayerServers
	void HelperLeaveLobby(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabMultiplayerAPI.HelperLeaveLobby
	void HelperJoinMatchmakingTicket(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabMultiplayerAPI.HelperJoinMatchmakingTicket
	void HelperJoinLobby(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabMultiplayerAPI.HelperJoinLobby
	void HelperJoinArrangedLobby(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabMultiplayerAPI.HelperJoinArrangedLobby
	void HelperInviteToLobby(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabMultiplayerAPI.HelperInviteToLobby
	void HelperGetTitleMultiplayerServersQuotas(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabMultiplayerAPI.HelperGetTitleMultiplayerServersQuotas
	void HelperGetTitleMultiplayerServersQuotaChange(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabMultiplayerAPI.HelperGetTitleMultiplayerServersQuotaChange
	void HelperGetTitleEnabledForMultiplayerServersStatus(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabMultiplayerAPI.HelperGetTitleEnabledForMultiplayerServersStatus
	void HelperGetServerBackfillTicket(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabMultiplayerAPI.HelperGetServerBackfillTicket
	void HelperGetRemoteLoginEndpoint(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabMultiplayerAPI.HelperGetRemoteLoginEndpoint
	void HelperGetQueueStatistics(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabMultiplayerAPI.HelperGetQueueStatistics
	void HelperGetMultiplayerSessionLogsBySessionId(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabMultiplayerAPI.HelperGetMultiplayerSessionLogsBySessionId
	void HelperGetMultiplayerServerLogs(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabMultiplayerAPI.HelperGetMultiplayerServerLogs
	void HelperGetMultiplayerServerDetails(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabMultiplayerAPI.HelperGetMultiplayerServerDetails
	void HelperGetMatchmakingTicket(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabMultiplayerAPI.HelperGetMatchmakingTicket
	void HelperGetMatch(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabMultiplayerAPI.HelperGetMatch
	void HelperGetLobby(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabMultiplayerAPI.HelperGetLobby
	void HelperGetContainerRegistryCredentials(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabMultiplayerAPI.HelperGetContainerRegistryCredentials
	void HelperGetBuildAlias(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabMultiplayerAPI.HelperGetBuildAlias
	void HelperGetBuild(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabMultiplayerAPI.HelperGetBuild
	void HelperGetAssetUploadUrl(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabMultiplayerAPI.HelperGetAssetUploadUrl
	void HelperGetAssetDownloadUrl(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabMultiplayerAPI.HelperGetAssetDownloadUrl
	void HelperFindLobbies(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabMultiplayerAPI.HelperFindLobbies
	void HelperFindFriendLobbies(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabMultiplayerAPI.HelperFindFriendLobbies
	void HelperEnableMultiplayerServersForTitle(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabMultiplayerAPI.HelperEnableMultiplayerServersForTitle
	void HelperDeleteRemoteUser(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabMultiplayerAPI.HelperDeleteRemoteUser
	void HelperDeleteLobby(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabMultiplayerAPI.HelperDeleteLobby
	void HelperDeleteContainerImageRepository(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabMultiplayerAPI.HelperDeleteContainerImageRepository
	void HelperDeleteCertificate(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabMultiplayerAPI.HelperDeleteCertificate
	void HelperDeleteBuildRegion(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabMultiplayerAPI.HelperDeleteBuildRegion
	void HelperDeleteBuildAlias(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabMultiplayerAPI.HelperDeleteBuildAlias
	void HelperDeleteBuild(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabMultiplayerAPI.HelperDeleteBuild
	void HelperDeleteAsset(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabMultiplayerAPI.HelperDeleteAsset
	void HelperCreateTitleMultiplayerServersQuotaChange(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabMultiplayerAPI.HelperCreateTitleMultiplayerServersQuotaChange
	void HelperCreateServerMatchmakingTicket(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabMultiplayerAPI.HelperCreateServerMatchmakingTicket
	void HelperCreateServerBackfillTicket(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabMultiplayerAPI.HelperCreateServerBackfillTicket
	void HelperCreateRemoteUser(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabMultiplayerAPI.HelperCreateRemoteUser
	void HelperCreateMatchmakingTicket(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabMultiplayerAPI.HelperCreateMatchmakingTicket
	void HelperCreateLobby(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabMultiplayerAPI.HelperCreateLobby
	void HelperCreateBuildWithProcessBasedServer(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabMultiplayerAPI.HelperCreateBuildWithProcessBasedServer
	void HelperCreateBuildWithManagedContainer(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabMultiplayerAPI.HelperCreateBuildWithManagedContainer
	void HelperCreateBuildWithCustomContainer(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabMultiplayerAPI.HelperCreateBuildWithCustomContainer
	void HelperCreateBuildAlias(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabMultiplayerAPI.HelperCreateBuildAlias
	void HelperCancelServerBackfillTicket(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabMultiplayerAPI.HelperCancelServerBackfillTicket
	void HelperCancelMatchmakingTicket(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabMultiplayerAPI.HelperCancelMatchmakingTicket
	void HelperCancelAllServerBackfillTicketsForPlayer(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabMultiplayerAPI.HelperCancelAllServerBackfillTicketsForPlayer
	void HelperCancelAllMatchmakingTicketsForPlayer(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabMultiplayerAPI.HelperCancelAllMatchmakingTicketsForPlayer
	struct UPlayFabMultiplayerAPI* GetTitleMultiplayerServersQuotas(struct FMultiplayerGetTitleMultiplayerServersQuotasRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabMultiplayerAPI.GetTitleMultiplayerServersQuotas
	struct UPlayFabMultiplayerAPI* GetTitleMultiplayerServersQuotaChange(struct FMultiplayerGetTitleMultiplayerServersQuotaChangeRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabMultiplayerAPI.GetTitleMultiplayerServersQuotaChange
	struct UPlayFabMultiplayerAPI* GetTitleEnabledForMultiplayerServersStatus(struct FMultiplayerGetTitleEnabledForMultiplayerServersStatusRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabMultiplayerAPI.GetTitleEnabledForMultiplayerServersStatus
	struct UPlayFabMultiplayerAPI* GetServerBackfillTicket(struct FMultiplayerGetServerBackfillTicketRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabMultiplayerAPI.GetServerBackfillTicket
	struct UPlayFabMultiplayerAPI* GetRemoteLoginEndpoint(struct FMultiplayerGetRemoteLoginEndpointRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabMultiplayerAPI.GetRemoteLoginEndpoint
	struct UPlayFabMultiplayerAPI* GetQueueStatistics(struct FMultiplayerGetQueueStatisticsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabMultiplayerAPI.GetQueueStatistics
	struct UPlayFabMultiplayerAPI* GetMultiplayerSessionLogsBySessionId(struct FMultiplayerGetMultiplayerSessionLogsBySessionIdRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabMultiplayerAPI.GetMultiplayerSessionLogsBySessionId
	struct UPlayFabMultiplayerAPI* GetMultiplayerServerLogs(struct FMultiplayerGetMultiplayerServerLogsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabMultiplayerAPI.GetMultiplayerServerLogs
	struct UPlayFabMultiplayerAPI* GetMultiplayerServerDetails(struct FMultiplayerGetMultiplayerServerDetailsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabMultiplayerAPI.GetMultiplayerServerDetails
	struct UPlayFabMultiplayerAPI* GetMatchmakingTicket(struct FMultiplayerGetMatchmakingTicketRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabMultiplayerAPI.GetMatchmakingTicket
	struct UPlayFabMultiplayerAPI* GetMatch(struct FMultiplayerGetMatchRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabMultiplayerAPI.GetMatch
	struct UPlayFabMultiplayerAPI* GetLobby(struct FMultiplayerGetLobbyRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabMultiplayerAPI.GetLobby
	struct UPlayFabMultiplayerAPI* GetContainerRegistryCredentials(struct FMultiplayerGetContainerRegistryCredentialsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabMultiplayerAPI.GetContainerRegistryCredentials
	struct UPlayFabMultiplayerAPI* GetBuildAlias(struct FMultiplayerGetBuildAliasRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabMultiplayerAPI.GetBuildAlias
	struct UPlayFabMultiplayerAPI* GetBuild(struct FMultiplayerGetBuildRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabMultiplayerAPI.GetBuild
	struct UPlayFabMultiplayerAPI* GetAssetUploadUrl(struct FMultiplayerGetAssetUploadUrlRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabMultiplayerAPI.GetAssetUploadUrl
	struct UPlayFabMultiplayerAPI* GetAssetDownloadUrl(struct FMultiplayerGetAssetDownloadUrlRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabMultiplayerAPI.GetAssetDownloadUrl
	struct UPlayFabMultiplayerAPI* FindLobbies(struct FMultiplayerFindLobbiesRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabMultiplayerAPI.FindLobbies
	struct UPlayFabMultiplayerAPI* FindFriendLobbies(struct FMultiplayerFindFriendLobbiesRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabMultiplayerAPI.FindFriendLobbies
	struct UPlayFabMultiplayerAPI* EnableMultiplayerServersForTitle(struct FMultiplayerEnableMultiplayerServersForTitleRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabMultiplayerAPI.EnableMultiplayerServersForTitle
	struct UPlayFabMultiplayerAPI* DeleteRemoteUser(struct FMultiplayerDeleteRemoteUserRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabMultiplayerAPI.DeleteRemoteUser
	struct UPlayFabMultiplayerAPI* DeleteLobby(struct FMultiplayerDeleteLobbyRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabMultiplayerAPI.DeleteLobby
	struct UPlayFabMultiplayerAPI* DeleteContainerImageRepository(struct FMultiplayerDeleteContainerImageRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabMultiplayerAPI.DeleteContainerImageRepository
	struct UPlayFabMultiplayerAPI* DeleteCertificate(struct FMultiplayerDeleteCertificateRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabMultiplayerAPI.DeleteCertificate
	struct UPlayFabMultiplayerAPI* DeleteBuildRegion(struct FMultiplayerDeleteBuildRegionRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabMultiplayerAPI.DeleteBuildRegion
	struct UPlayFabMultiplayerAPI* DeleteBuildAlias(struct FMultiplayerDeleteBuildAliasRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabMultiplayerAPI.DeleteBuildAlias
	struct UPlayFabMultiplayerAPI* DeleteBuild(struct FMultiplayerDeleteBuildRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabMultiplayerAPI.DeleteBuild
	struct UPlayFabMultiplayerAPI* DeleteAsset(struct FMultiplayerDeleteAssetRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabMultiplayerAPI.DeleteAsset
	void DelegateOnSuccessUploadCertificate__DelegateSignature(struct FMultiplayerEmptyResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessUploadCertificate__DelegateSignature
	void DelegateOnSuccessUpdateLobby__DelegateSignature(struct FMultiplayerLobbyEmptyResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessUpdateLobby__DelegateSignature
	void DelegateOnSuccessUpdateBuildRegions__DelegateSignature(struct FMultiplayerEmptyResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessUpdateBuildRegions__DelegateSignature
	void DelegateOnSuccessUpdateBuildRegion__DelegateSignature(struct FMultiplayerEmptyResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessUpdateBuildRegion__DelegateSignature
	void DelegateOnSuccessUpdateBuildName__DelegateSignature(struct FMultiplayerEmptyResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessUpdateBuildName__DelegateSignature
	void DelegateOnSuccessUpdateBuildAlias__DelegateSignature(struct FMultiplayerBuildAliasDetailsResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessUpdateBuildAlias__DelegateSignature
	void DelegateOnSuccessUntagContainerImage__DelegateSignature(struct FMultiplayerEmptyResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessUntagContainerImage__DelegateSignature
	void DelegateOnSuccessUnsubscribeFromLobbyResource__DelegateSignature(struct FMultiplayerLobbyEmptyResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessUnsubscribeFromLobbyResource__DelegateSignature
	void DelegateOnSuccessSubscribeToLobbyResource__DelegateSignature(struct FMultiplayerSubscribeToLobbyResourceResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessSubscribeToLobbyResource__DelegateSignature
	void DelegateOnSuccessShutdownMultiplayerServer__DelegateSignature(struct FMultiplayerEmptyResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessShutdownMultiplayerServer__DelegateSignature
	void DelegateOnSuccessRolloverContainerRegistryCredentials__DelegateSignature(struct FMultiplayerRolloverContainerRegistryCredentialsResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessRolloverContainerRegistryCredentials__DelegateSignature
	void DelegateOnSuccessRequestMultiplayerServer__DelegateSignature(struct FMultiplayerRequestMultiplayerServerResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessRequestMultiplayerServer__DelegateSignature
	void DelegateOnSuccessRemoveMember__DelegateSignature(struct FMultiplayerLobbyEmptyResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessRemoveMember__DelegateSignature
	void DelegateOnSuccessListVirtualMachineSummaries__DelegateSignature(struct FMultiplayerListVirtualMachineSummariesResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessListVirtualMachineSummaries__DelegateSignature
	void DelegateOnSuccessListTitleMultiplayerServersQuotaChanges__DelegateSignature(struct FMultiplayerListTitleMultiplayerServersQuotaChangesResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessListTitleMultiplayerServersQuotaChanges__DelegateSignature
	void DelegateOnSuccessListServerBackfillTicketsForPlayer__DelegateSignature(struct FMultiplayerListServerBackfillTicketsForPlayerResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessListServerBackfillTicketsForPlayer__DelegateSignature
	void DelegateOnSuccessListQosServersForTitle__DelegateSignature(struct FMultiplayerListQosServersForTitleResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessListQosServersForTitle__DelegateSignature
	void DelegateOnSuccessListPartyQosServers__DelegateSignature(struct FMultiplayerListPartyQosServersResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessListPartyQosServers__DelegateSignature
	void DelegateOnSuccessListMultiplayerServers__DelegateSignature(struct FMultiplayerListMultiplayerServersResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessListMultiplayerServers__DelegateSignature
	void DelegateOnSuccessListMatchmakingTicketsForPlayer__DelegateSignature(struct FMultiplayerListMatchmakingTicketsForPlayerResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessListMatchmakingTicketsForPlayer__DelegateSignature
	void DelegateOnSuccessListContainerImageTags__DelegateSignature(struct FMultiplayerListContainerImageTagsResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessListContainerImageTags__DelegateSignature
	void DelegateOnSuccessListContainerImages__DelegateSignature(struct FMultiplayerListContainerImagesResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessListContainerImages__DelegateSignature
	void DelegateOnSuccessListCertificateSummaries__DelegateSignature(struct FMultiplayerListCertificateSummariesResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessListCertificateSummaries__DelegateSignature
	void DelegateOnSuccessListBuildSummariesV2__DelegateSignature(struct FMultiplayerListBuildSummariesResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessListBuildSummariesV2__DelegateSignature
	void DelegateOnSuccessListBuildAliases__DelegateSignature(struct FMultiplayerListBuildAliasesResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessListBuildAliases__DelegateSignature
	void DelegateOnSuccessListAssetSummaries__DelegateSignature(struct FMultiplayerListAssetSummariesResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessListAssetSummaries__DelegateSignature
	void DelegateOnSuccessListArchivedMultiplayerServers__DelegateSignature(struct FMultiplayerListMultiplayerServersResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessListArchivedMultiplayerServers__DelegateSignature
	void DelegateOnSuccessLeaveLobby__DelegateSignature(struct FMultiplayerLobbyEmptyResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessLeaveLobby__DelegateSignature
	void DelegateOnSuccessJoinMatchmakingTicket__DelegateSignature(struct FMultiplayerJoinMatchmakingTicketResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessJoinMatchmakingTicket__DelegateSignature
	void DelegateOnSuccessJoinLobby__DelegateSignature(struct FMultiplayerJoinLobbyResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessJoinLobby__DelegateSignature
	void DelegateOnSuccessJoinArrangedLobby__DelegateSignature(struct FMultiplayerJoinLobbyResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessJoinArrangedLobby__DelegateSignature
	void DelegateOnSuccessInviteToLobby__DelegateSignature(struct FMultiplayerLobbyEmptyResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessInviteToLobby__DelegateSignature
	void DelegateOnSuccessGetTitleMultiplayerServersQuotas__DelegateSignature(struct FMultiplayerGetTitleMultiplayerServersQuotasResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessGetTitleMultiplayerServersQuotas__DelegateSignature
	void DelegateOnSuccessGetTitleMultiplayerServersQuotaChange__DelegateSignature(struct FMultiplayerGetTitleMultiplayerServersQuotaChangeResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessGetTitleMultiplayerServersQuotaChange__DelegateSignature
	void DelegateOnSuccessGetTitleEnabledForMultiplayerServersStatus__DelegateSignature(struct FMultiplayerGetTitleEnabledForMultiplayerServersStatusResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessGetTitleEnabledForMultiplayerServersStatus__DelegateSignature
	void DelegateOnSuccessGetServerBackfillTicket__DelegateSignature(struct FMultiplayerGetServerBackfillTicketResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessGetServerBackfillTicket__DelegateSignature
	void DelegateOnSuccessGetRemoteLoginEndpoint__DelegateSignature(struct FMultiplayerGetRemoteLoginEndpointResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessGetRemoteLoginEndpoint__DelegateSignature
	void DelegateOnSuccessGetQueueStatistics__DelegateSignature(struct FMultiplayerGetQueueStatisticsResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessGetQueueStatistics__DelegateSignature
	void DelegateOnSuccessGetMultiplayerSessionLogsBySessionId__DelegateSignature(struct FMultiplayerGetMultiplayerServerLogsResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessGetMultiplayerSessionLogsBySessionId__DelegateSignature
	void DelegateOnSuccessGetMultiplayerServerLogs__DelegateSignature(struct FMultiplayerGetMultiplayerServerLogsResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessGetMultiplayerServerLogs__DelegateSignature
	void DelegateOnSuccessGetMultiplayerServerDetails__DelegateSignature(struct FMultiplayerGetMultiplayerServerDetailsResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessGetMultiplayerServerDetails__DelegateSignature
	void DelegateOnSuccessGetMatchmakingTicket__DelegateSignature(struct FMultiplayerGetMatchmakingTicketResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessGetMatchmakingTicket__DelegateSignature
	void DelegateOnSuccessGetMatch__DelegateSignature(struct FMultiplayerGetMatchResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessGetMatch__DelegateSignature
	void DelegateOnSuccessGetLobby__DelegateSignature(struct FMultiplayerGetLobbyResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessGetLobby__DelegateSignature
	void DelegateOnSuccessGetContainerRegistryCredentials__DelegateSignature(struct FMultiplayerGetContainerRegistryCredentialsResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessGetContainerRegistryCredentials__DelegateSignature
	void DelegateOnSuccessGetBuildAlias__DelegateSignature(struct FMultiplayerBuildAliasDetailsResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessGetBuildAlias__DelegateSignature
	void DelegateOnSuccessGetBuild__DelegateSignature(struct FMultiplayerGetBuildResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessGetBuild__DelegateSignature
	void DelegateOnSuccessGetAssetUploadUrl__DelegateSignature(struct FMultiplayerGetAssetUploadUrlResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessGetAssetUploadUrl__DelegateSignature
	void DelegateOnSuccessGetAssetDownloadUrl__DelegateSignature(struct FMultiplayerGetAssetDownloadUrlResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessGetAssetDownloadUrl__DelegateSignature
	void DelegateOnSuccessFindLobbies__DelegateSignature(struct FMultiplayerFindLobbiesResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessFindLobbies__DelegateSignature
	void DelegateOnSuccessFindFriendLobbies__DelegateSignature(struct FMultiplayerFindFriendLobbiesResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessFindFriendLobbies__DelegateSignature
	void DelegateOnSuccessEnableMultiplayerServersForTitle__DelegateSignature(struct FMultiplayerEnableMultiplayerServersForTitleResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessEnableMultiplayerServersForTitle__DelegateSignature
	void DelegateOnSuccessDeleteRemoteUser__DelegateSignature(struct FMultiplayerEmptyResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessDeleteRemoteUser__DelegateSignature
	void DelegateOnSuccessDeleteLobby__DelegateSignature(struct FMultiplayerLobbyEmptyResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessDeleteLobby__DelegateSignature
	void DelegateOnSuccessDeleteContainerImageRepository__DelegateSignature(struct FMultiplayerEmptyResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessDeleteContainerImageRepository__DelegateSignature
	void DelegateOnSuccessDeleteCertificate__DelegateSignature(struct FMultiplayerEmptyResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessDeleteCertificate__DelegateSignature
	void DelegateOnSuccessDeleteBuildRegion__DelegateSignature(struct FMultiplayerEmptyResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessDeleteBuildRegion__DelegateSignature
	void DelegateOnSuccessDeleteBuildAlias__DelegateSignature(struct FMultiplayerEmptyResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessDeleteBuildAlias__DelegateSignature
	void DelegateOnSuccessDeleteBuild__DelegateSignature(struct FMultiplayerEmptyResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessDeleteBuild__DelegateSignature
	void DelegateOnSuccessDeleteAsset__DelegateSignature(struct FMultiplayerEmptyResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessDeleteAsset__DelegateSignature
	void DelegateOnSuccessCreateTitleMultiplayerServersQuotaChange__DelegateSignature(struct FMultiplayerCreateTitleMultiplayerServersQuotaChangeResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessCreateTitleMultiplayerServersQuotaChange__DelegateSignature
	void DelegateOnSuccessCreateServerMatchmakingTicket__DelegateSignature(struct FMultiplayerCreateMatchmakingTicketResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessCreateServerMatchmakingTicket__DelegateSignature
	void DelegateOnSuccessCreateServerBackfillTicket__DelegateSignature(struct FMultiplayerCreateServerBackfillTicketResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessCreateServerBackfillTicket__DelegateSignature
	void DelegateOnSuccessCreateRemoteUser__DelegateSignature(struct FMultiplayerCreateRemoteUserResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessCreateRemoteUser__DelegateSignature
	void DelegateOnSuccessCreateMatchmakingTicket__DelegateSignature(struct FMultiplayerCreateMatchmakingTicketResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessCreateMatchmakingTicket__DelegateSignature
	void DelegateOnSuccessCreateLobby__DelegateSignature(struct FMultiplayerCreateLobbyResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessCreateLobby__DelegateSignature
	void DelegateOnSuccessCreateBuildWithProcessBasedServer__DelegateSignature(struct FMultiplayerCreateBuildWithProcessBasedServerResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessCreateBuildWithProcessBasedServer__DelegateSignature
	void DelegateOnSuccessCreateBuildWithManagedContainer__DelegateSignature(struct FMultiplayerCreateBuildWithManagedContainerResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessCreateBuildWithManagedContainer__DelegateSignature
	void DelegateOnSuccessCreateBuildWithCustomContainer__DelegateSignature(struct FMultiplayerCreateBuildWithCustomContainerResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessCreateBuildWithCustomContainer__DelegateSignature
	void DelegateOnSuccessCreateBuildAlias__DelegateSignature(struct FMultiplayerBuildAliasDetailsResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessCreateBuildAlias__DelegateSignature
	void DelegateOnSuccessCancelServerBackfillTicket__DelegateSignature(struct FMultiplayerCancelServerBackfillTicketResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessCancelServerBackfillTicket__DelegateSignature
	void DelegateOnSuccessCancelMatchmakingTicket__DelegateSignature(struct FMultiplayerCancelMatchmakingTicketResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessCancelMatchmakingTicket__DelegateSignature
	void DelegateOnSuccessCancelAllServerBackfillTicketsForPlayer__DelegateSignature(struct FMultiplayerCancelAllServerBackfillTicketsForPlayerResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessCancelAllServerBackfillTicketsForPlayer__DelegateSignature
	void DelegateOnSuccessCancelAllMatchmakingTicketsForPlayer__DelegateSignature(struct FMultiplayerCancelAllMatchmakingTicketsForPlayerResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnSuccessCancelAllMatchmakingTicketsForPlayer__DelegateSignature
	void DelegateOnFailurePlayFabError__DelegateSignature(struct FPlayFabError Error, struct UObject* customData); // DelegateFunction PlayFab.PlayFabMultiplayerAPI.DelegateOnFailurePlayFabError__DelegateSignature
	struct UPlayFabMultiplayerAPI* CreateTitleMultiplayerServersQuotaChange(struct FMultiplayerCreateTitleMultiplayerServersQuotaChangeRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabMultiplayerAPI.CreateTitleMultiplayerServersQuotaChange
	struct UPlayFabMultiplayerAPI* CreateServerMatchmakingTicket(struct FMultiplayerCreateServerMatchmakingTicketRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabMultiplayerAPI.CreateServerMatchmakingTicket
	struct UPlayFabMultiplayerAPI* CreateServerBackfillTicket(struct FMultiplayerCreateServerBackfillTicketRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabMultiplayerAPI.CreateServerBackfillTicket
	struct UPlayFabMultiplayerAPI* CreateRemoteUser(struct FMultiplayerCreateRemoteUserRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabMultiplayerAPI.CreateRemoteUser
	struct UPlayFabMultiplayerAPI* CreateMatchmakingTicket(struct FMultiplayerCreateMatchmakingTicketRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabMultiplayerAPI.CreateMatchmakingTicket
	struct UPlayFabMultiplayerAPI* CreateLobby(struct FMultiplayerCreateLobbyRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabMultiplayerAPI.CreateLobby
	struct UPlayFabMultiplayerAPI* CreateBuildWithProcessBasedServer(struct FMultiplayerCreateBuildWithProcessBasedServerRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabMultiplayerAPI.CreateBuildWithProcessBasedServer
	struct UPlayFabMultiplayerAPI* CreateBuildWithManagedContainer(struct FMultiplayerCreateBuildWithManagedContainerRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabMultiplayerAPI.CreateBuildWithManagedContainer
	struct UPlayFabMultiplayerAPI* CreateBuildWithCustomContainer(struct FMultiplayerCreateBuildWithCustomContainerRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabMultiplayerAPI.CreateBuildWithCustomContainer
	struct UPlayFabMultiplayerAPI* CreateBuildAlias(struct FMultiplayerCreateBuildAliasRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabMultiplayerAPI.CreateBuildAlias
	struct UPlayFabMultiplayerAPI* CancelServerBackfillTicket(struct FMultiplayerCancelServerBackfillTicketRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabMultiplayerAPI.CancelServerBackfillTicket
	struct UPlayFabMultiplayerAPI* CancelMatchmakingTicket(struct FMultiplayerCancelMatchmakingTicketRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabMultiplayerAPI.CancelMatchmakingTicket
	struct UPlayFabMultiplayerAPI* CancelAllServerBackfillTicketsForPlayer(struct FMultiplayerCancelAllServerBackfillTicketsForPlayerRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabMultiplayerAPI.CancelAllServerBackfillTicketsForPlayer
	struct UPlayFabMultiplayerAPI* CancelAllMatchmakingTicketsForPlayer(struct FMultiplayerCancelAllMatchmakingTicketsForPlayerRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabMultiplayerAPI.CancelAllMatchmakingTicketsForPlayer
}; 



// Class PlayFab.PlayFabMultiplayerModelDecoder
// Size: 0x28(Inherited: 0x28) 
struct UPlayFabMultiplayerModelDecoder : public UBlueprintFunctionLibrary
{

	struct FMultiplayerSubscribeToLobbyResourceResult decodeSubscribeToLobbyResourceResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabMultiplayerModelDecoder.decodeSubscribeToLobbyResourceResultResponse
	struct FMultiplayerRolloverContainerRegistryCredentialsResponse decodeRolloverContainerRegistryCredentialsResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabMultiplayerModelDecoder.decodeRolloverContainerRegistryCredentialsResponseResponse
	struct FMultiplayerRequestMultiplayerServerResponse decodeRequestMultiplayerServerResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabMultiplayerModelDecoder.decodeRequestMultiplayerServerResponseResponse
	struct FMultiplayerLobbyEmptyResult decodeLobbyEmptyResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabMultiplayerModelDecoder.decodeLobbyEmptyResultResponse
	struct FMultiplayerListVirtualMachineSummariesResponse decodeListVirtualMachineSummariesResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabMultiplayerModelDecoder.decodeListVirtualMachineSummariesResponseResponse
	struct FMultiplayerListTitleMultiplayerServersQuotaChangesResponse decodeListTitleMultiplayerServersQuotaChangesResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabMultiplayerModelDecoder.decodeListTitleMultiplayerServersQuotaChangesResponseResponse
	struct FMultiplayerListServerBackfillTicketsForPlayerResult decodeListServerBackfillTicketsForPlayerResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabMultiplayerModelDecoder.decodeListServerBackfillTicketsForPlayerResultResponse
	struct FMultiplayerListQosServersForTitleResponse decodeListQosServersForTitleResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabMultiplayerModelDecoder.decodeListQosServersForTitleResponseResponse
	struct FMultiplayerListPartyQosServersResponse decodeListPartyQosServersResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabMultiplayerModelDecoder.decodeListPartyQosServersResponseResponse
	struct FMultiplayerListMultiplayerServersResponse decodeListMultiplayerServersResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabMultiplayerModelDecoder.decodeListMultiplayerServersResponseResponse
	struct FMultiplayerListMatchmakingTicketsForPlayerResult decodeListMatchmakingTicketsForPlayerResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabMultiplayerModelDecoder.decodeListMatchmakingTicketsForPlayerResultResponse
	struct FMultiplayerListContainerImageTagsResponse decodeListContainerImageTagsResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabMultiplayerModelDecoder.decodeListContainerImageTagsResponseResponse
	struct FMultiplayerListContainerImagesResponse decodeListContainerImagesResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabMultiplayerModelDecoder.decodeListContainerImagesResponseResponse
	struct FMultiplayerListCertificateSummariesResponse decodeListCertificateSummariesResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabMultiplayerModelDecoder.decodeListCertificateSummariesResponseResponse
	struct FMultiplayerListBuildSummariesResponse decodeListBuildSummariesResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabMultiplayerModelDecoder.decodeListBuildSummariesResponseResponse
	struct FMultiplayerListBuildAliasesResponse decodeListBuildAliasesResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabMultiplayerModelDecoder.decodeListBuildAliasesResponseResponse
	struct FMultiplayerListAssetSummariesResponse decodeListAssetSummariesResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabMultiplayerModelDecoder.decodeListAssetSummariesResponseResponse
	struct FMultiplayerJoinMatchmakingTicketResult decodeJoinMatchmakingTicketResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabMultiplayerModelDecoder.decodeJoinMatchmakingTicketResultResponse
	struct FMultiplayerJoinLobbyResult decodeJoinLobbyResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabMultiplayerModelDecoder.decodeJoinLobbyResultResponse
	struct FMultiplayerGetTitleMultiplayerServersQuotasResponse decodeGetTitleMultiplayerServersQuotasResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabMultiplayerModelDecoder.decodeGetTitleMultiplayerServersQuotasResponseResponse
	struct FMultiplayerGetTitleMultiplayerServersQuotaChangeResponse decodeGetTitleMultiplayerServersQuotaChangeResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabMultiplayerModelDecoder.decodeGetTitleMultiplayerServersQuotaChangeResponseResponse
	struct FMultiplayerGetTitleEnabledForMultiplayerServersStatusResponse decodeGetTitleEnabledForMultiplayerServersStatusResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabMultiplayerModelDecoder.decodeGetTitleEnabledForMultiplayerServersStatusResponseResponse
	struct FMultiplayerGetServerBackfillTicketResult decodeGetServerBackfillTicketResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabMultiplayerModelDecoder.decodeGetServerBackfillTicketResultResponse
	struct FMultiplayerGetRemoteLoginEndpointResponse decodeGetRemoteLoginEndpointResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabMultiplayerModelDecoder.decodeGetRemoteLoginEndpointResponseResponse
	struct FMultiplayerGetQueueStatisticsResult decodeGetQueueStatisticsResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabMultiplayerModelDecoder.decodeGetQueueStatisticsResultResponse
	struct FMultiplayerGetMultiplayerServerLogsResponse decodeGetMultiplayerServerLogsResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabMultiplayerModelDecoder.decodeGetMultiplayerServerLogsResponseResponse
	struct FMultiplayerGetMultiplayerServerDetailsResponse decodeGetMultiplayerServerDetailsResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabMultiplayerModelDecoder.decodeGetMultiplayerServerDetailsResponseResponse
	struct FMultiplayerGetMatchResult decodeGetMatchResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabMultiplayerModelDecoder.decodeGetMatchResultResponse
	struct FMultiplayerGetMatchmakingTicketResult decodeGetMatchmakingTicketResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabMultiplayerModelDecoder.decodeGetMatchmakingTicketResultResponse
	struct FMultiplayerGetLobbyResult decodeGetLobbyResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabMultiplayerModelDecoder.decodeGetLobbyResultResponse
	struct FMultiplayerGetContainerRegistryCredentialsResponse decodeGetContainerRegistryCredentialsResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabMultiplayerModelDecoder.decodeGetContainerRegistryCredentialsResponseResponse
	struct FMultiplayerGetBuildResponse decodeGetBuildResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabMultiplayerModelDecoder.decodeGetBuildResponseResponse
	struct FMultiplayerGetAssetUploadUrlResponse decodeGetAssetUploadUrlResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabMultiplayerModelDecoder.decodeGetAssetUploadUrlResponseResponse
	struct FMultiplayerGetAssetDownloadUrlResponse decodeGetAssetDownloadUrlResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabMultiplayerModelDecoder.decodeGetAssetDownloadUrlResponseResponse
	struct FMultiplayerFindLobbiesResult decodeFindLobbiesResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabMultiplayerModelDecoder.decodeFindLobbiesResultResponse
	struct FMultiplayerFindFriendLobbiesResult decodeFindFriendLobbiesResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabMultiplayerModelDecoder.decodeFindFriendLobbiesResultResponse
	struct FMultiplayerEnableMultiplayerServersForTitleResponse decodeEnableMultiplayerServersForTitleResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabMultiplayerModelDecoder.decodeEnableMultiplayerServersForTitleResponseResponse
	struct FMultiplayerEmptyResponse decodeEmptyResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabMultiplayerModelDecoder.decodeEmptyResponseResponse
	struct FMultiplayerCreateTitleMultiplayerServersQuotaChangeResponse decodeCreateTitleMultiplayerServersQuotaChangeResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabMultiplayerModelDecoder.decodeCreateTitleMultiplayerServersQuotaChangeResponseResponse
	struct FMultiplayerCreateServerBackfillTicketResult decodeCreateServerBackfillTicketResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabMultiplayerModelDecoder.decodeCreateServerBackfillTicketResultResponse
	struct FMultiplayerCreateRemoteUserResponse decodeCreateRemoteUserResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabMultiplayerModelDecoder.decodeCreateRemoteUserResponseResponse
	struct FMultiplayerCreateMatchmakingTicketResult decodeCreateMatchmakingTicketResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabMultiplayerModelDecoder.decodeCreateMatchmakingTicketResultResponse
	struct FMultiplayerCreateLobbyResult decodeCreateLobbyResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabMultiplayerModelDecoder.decodeCreateLobbyResultResponse
	struct FMultiplayerCreateBuildWithProcessBasedServerResponse decodeCreateBuildWithProcessBasedServerResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabMultiplayerModelDecoder.decodeCreateBuildWithProcessBasedServerResponseResponse
	struct FMultiplayerCreateBuildWithManagedContainerResponse decodeCreateBuildWithManagedContainerResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabMultiplayerModelDecoder.decodeCreateBuildWithManagedContainerResponseResponse
	struct FMultiplayerCreateBuildWithCustomContainerResponse decodeCreateBuildWithCustomContainerResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabMultiplayerModelDecoder.decodeCreateBuildWithCustomContainerResponseResponse
	struct FMultiplayerCancelServerBackfillTicketResult decodeCancelServerBackfillTicketResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabMultiplayerModelDecoder.decodeCancelServerBackfillTicketResultResponse
	struct FMultiplayerCancelMatchmakingTicketResult decodeCancelMatchmakingTicketResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabMultiplayerModelDecoder.decodeCancelMatchmakingTicketResultResponse
	struct FMultiplayerCancelAllServerBackfillTicketsForPlayerResult decodeCancelAllServerBackfillTicketsForPlayerResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabMultiplayerModelDecoder.decodeCancelAllServerBackfillTicketsForPlayerResultResponse
	struct FMultiplayerCancelAllMatchmakingTicketsForPlayerResult decodeCancelAllMatchmakingTicketsForPlayerResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabMultiplayerModelDecoder.decodeCancelAllMatchmakingTicketsForPlayerResultResponse
	struct FMultiplayerBuildAliasDetailsResponse decodeBuildAliasDetailsResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabMultiplayerModelDecoder.decodeBuildAliasDetailsResponseResponse
}; 



// Class PlayFab.PlayFabServerAPI
// Size: 0x9C0(Inherited: 0x30) 
struct UPlayFabServerAPI : public UOnlineBlueprintCallProxyBase
{
	struct FMulticastInlineDelegate OnPlayFabResponse;  // 0x30(0x10)
	char pad_64[2328];  // 0x40(0x918)
	struct UPlayFabAuthenticationContext* CallAuthenticationContext;  // 0x958(0x8)
	struct UPlayFabJsonObject* RequestJsonObj;  // 0x960(0x8)
	struct UPlayFabJsonObject* ResponseJsonObj;  // 0x968(0x8)
	char pad_2416[80];  // 0x970(0x50)

	struct UPlayFabServerAPI* WriteTitleEvent(struct FServerWriteTitleEventRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.WriteTitleEvent
	struct UPlayFabServerAPI* WritePlayerEvent(struct FServerWriteServerPlayerEventRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.WritePlayerEvent
	struct UPlayFabServerAPI* WriteCharacterEvent(struct FServerWriteServerCharacterEventRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.WriteCharacterEvent
	struct UPlayFabServerAPI* UpdateUserReadOnlyData(struct FServerUpdateUserDataRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.UpdateUserReadOnlyData
	struct UPlayFabServerAPI* UpdateUserPublisherReadOnlyData(struct FServerUpdateUserDataRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.UpdateUserPublisherReadOnlyData
	struct UPlayFabServerAPI* UpdateUserPublisherInternalData(struct FServerUpdateUserInternalDataRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.UpdateUserPublisherInternalData
	struct UPlayFabServerAPI* UpdateUserPublisherData(struct FServerUpdateUserDataRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.UpdateUserPublisherData
	struct UPlayFabServerAPI* UpdateUserInventoryItemCustomData(struct FServerUpdateUserInventoryItemDataRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.UpdateUserInventoryItemCustomData
	struct UPlayFabServerAPI* UpdateUserInternalData(struct FServerUpdateUserInternalDataRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.UpdateUserInternalData
	struct UPlayFabServerAPI* UpdateUserData(struct FServerUpdateUserDataRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.UpdateUserData
	struct UPlayFabServerAPI* UpdateSharedGroupData(struct FServerUpdateSharedGroupDataRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.UpdateSharedGroupData
	struct UPlayFabServerAPI* UpdatePlayerStatistics(struct FServerUpdatePlayerStatisticsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.UpdatePlayerStatistics
	struct UPlayFabServerAPI* UpdateCharacterStatistics(struct FServerUpdateCharacterStatisticsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.UpdateCharacterStatistics
	struct UPlayFabServerAPI* UpdateCharacterReadOnlyData(struct FServerUpdateCharacterDataRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.UpdateCharacterReadOnlyData
	struct UPlayFabServerAPI* UpdateCharacterInternalData(struct FServerUpdateCharacterDataRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.UpdateCharacterInternalData
	struct UPlayFabServerAPI* UpdateCharacterData(struct FServerUpdateCharacterDataRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.UpdateCharacterData
	struct UPlayFabServerAPI* UpdateBans(struct FServerUpdateBansRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.UpdateBans
	struct UPlayFabServerAPI* UpdateAvatarUrl(struct FServerUpdateAvatarUrlRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.UpdateAvatarUrl
	struct UPlayFabServerAPI* UnlockContainerItem(struct FServerUnlockContainerItemRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.UnlockContainerItem
	struct UPlayFabServerAPI* UnlockContainerInstance(struct FServerUnlockContainerInstanceRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.UnlockContainerInstance
	struct UPlayFabServerAPI* UnlinkXboxAccount(struct FServerUnlinkXboxAccountRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.UnlinkXboxAccount
	struct UPlayFabServerAPI* UnlinkSteamId(struct FServerUnlinkSteamIdRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.UnlinkSteamId
	struct UPlayFabServerAPI* UnlinkServerCustomId(struct FServerUnlinkServerCustomIdRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.UnlinkServerCustomId
	struct UPlayFabServerAPI* UnlinkPSNAccount(struct FServerUnlinkPSNAccountRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.UnlinkPSNAccount
	struct UPlayFabServerAPI* UnlinkNintendoSwitchDeviceId(struct FServerUnlinkNintendoSwitchDeviceIdRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.UnlinkNintendoSwitchDeviceId
	struct UPlayFabServerAPI* UnlinkNintendoServiceAccount(struct FServerUnlinkNintendoServiceAccountRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.UnlinkNintendoServiceAccount
	struct UPlayFabServerAPI* SubtractUserVirtualCurrency(struct FServerSubtractUserVirtualCurrencyRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.SubtractUserVirtualCurrency
	struct UPlayFabServerAPI* SubtractCharacterVirtualCurrency(struct FServerSubtractCharacterVirtualCurrencyRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.SubtractCharacterVirtualCurrency
	struct UPlayFabServerAPI* SetTitleInternalData(struct FServerSetTitleDataRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.SetTitleInternalData
	struct UPlayFabServerAPI* SetTitleData(struct FServerSetTitleDataRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.SetTitleData
	struct UPlayFabServerAPI* SetPublisherData(struct FServerSetPublisherDataRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.SetPublisherData
	struct UPlayFabServerAPI* SetPlayerSecret(struct FServerSetPlayerSecretRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.SetPlayerSecret
	struct UPlayFabServerAPI* SetGameServerInstanceTags(struct FServerSetGameServerInstanceTagsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.SetGameServerInstanceTags
	struct UPlayFabServerAPI* SetGameServerInstanceState(struct FServerSetGameServerInstanceStateRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.SetGameServerInstanceState
	struct UPlayFabServerAPI* SetGameServerInstanceData(struct FServerSetGameServerInstanceDataRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.SetGameServerInstanceData
	struct UPlayFabServerAPI* SetFriendTags(struct FServerSetFriendTagsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.SetFriendTags
	struct UPlayFabServerAPI* SendPushNotificationFromTemplate(struct FServerSendPushNotificationFromTemplateRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.SendPushNotificationFromTemplate
	struct UPlayFabServerAPI* SendPushNotification(struct FServerSendPushNotificationRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.SendPushNotification
	struct UPlayFabServerAPI* SendEmailFromTemplate(struct FServerSendEmailFromTemplateRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.SendEmailFromTemplate
	struct UPlayFabServerAPI* SendCustomAccountRecoveryEmail(struct FServerSendCustomAccountRecoveryEmailRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.SendCustomAccountRecoveryEmail
	struct UPlayFabServerAPI* SavePushNotificationTemplate(struct FServerSavePushNotificationTemplateRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.SavePushNotificationTemplate
	struct UPlayFabServerAPI* RevokeInventoryItems(struct FServerRevokeInventoryItemsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.RevokeInventoryItems
	struct UPlayFabServerAPI* RevokeInventoryItem(struct FServerRevokeInventoryItemRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.RevokeInventoryItem
	struct UPlayFabServerAPI* RevokeBans(struct FServerRevokeBansRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.RevokeBans
	struct UPlayFabServerAPI* RevokeAllBansForUser(struct FServerRevokeAllBansForUserRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.RevokeAllBansForUser
	struct UPlayFabServerAPI* ReportPlayer(struct FServerReportPlayerServerRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.ReportPlayer
	struct UPlayFabServerAPI* RemoveSharedGroupMembers(struct FServerRemoveSharedGroupMembersRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.RemoveSharedGroupMembers
	struct UPlayFabServerAPI* RemovePlayerTag(struct FServerRemovePlayerTagRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.RemovePlayerTag
	struct UPlayFabServerAPI* RemoveGenericID(struct FServerRemoveGenericIDRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.RemoveGenericID
	struct UPlayFabServerAPI* RemoveFriend(struct FServerRemoveFriendRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.RemoveFriend
	struct UPlayFabServerAPI* RegisterGame(struct FServerRegisterGameRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.RegisterGame
	struct UPlayFabServerAPI* RefreshGameServerInstanceHeartbeat(struct FServerRefreshGameServerInstanceHeartbeatRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.RefreshGameServerInstanceHeartbeat
	struct UPlayFabServerAPI* RedeemMatchmakerTicket(struct FServerRedeemMatchmakerTicketRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.RedeemMatchmakerTicket
	struct UPlayFabServerAPI* RedeemCoupon(struct FServerRedeemCouponRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.RedeemCoupon
	struct UPlayFabServerAPI* NotifyMatchmakerPlayerLeft(struct FServerNotifyMatchmakerPlayerLeftRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.NotifyMatchmakerPlayerLeft
	struct UPlayFabServerAPI* MoveItemToUserFromCharacter(struct FServerMoveItemToUserFromCharacterRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.MoveItemToUserFromCharacter
	struct UPlayFabServerAPI* MoveItemToCharacterFromUser(struct FServerMoveItemToCharacterFromUserRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.MoveItemToCharacterFromUser
	struct UPlayFabServerAPI* MoveItemToCharacterFromCharacter(struct FServerMoveItemToCharacterFromCharacterRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.MoveItemToCharacterFromCharacter
	struct UPlayFabServerAPI* ModifyItemUses(struct FServerModifyItemUsesRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.ModifyItemUses
	struct UPlayFabServerAPI* LoginWithXboxId(struct FServerLoginWithXboxIdRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.LoginWithXboxId
	struct UPlayFabServerAPI* LoginWithXbox(struct FServerLoginWithXboxRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.LoginWithXbox
	struct UPlayFabServerAPI* LoginWithSteamId(struct FServerLoginWithSteamIdRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.LoginWithSteamId
	struct UPlayFabServerAPI* LoginWithServerCustomId(struct FServerLoginWithServerCustomIdRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.LoginWithServerCustomId
	struct UPlayFabServerAPI* LinkXboxAccount(struct FServerLinkXboxAccountRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.LinkXboxAccount
	struct UPlayFabServerAPI* LinkSteamId(struct FServerLinkSteamIdRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.LinkSteamId
	struct UPlayFabServerAPI* LinkServerCustomId(struct FServerLinkServerCustomIdRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.LinkServerCustomId
	struct UPlayFabServerAPI* LinkPSNAccount(struct FServerLinkPSNAccountRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.LinkPSNAccount
	struct UPlayFabServerAPI* LinkNintendoSwitchDeviceId(struct FServerLinkNintendoSwitchDeviceIdRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.LinkNintendoSwitchDeviceId
	struct UPlayFabServerAPI* LinkNintendoServiceAccount(struct FServerLinkNintendoServiceAccountRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.LinkNintendoServiceAccount
	void HelperWriteTitleEvent(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperWriteTitleEvent
	void HelperWritePlayerEvent(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperWritePlayerEvent
	void HelperWriteCharacterEvent(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperWriteCharacterEvent
	void HelperUpdateUserReadOnlyData(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperUpdateUserReadOnlyData
	void HelperUpdateUserPublisherReadOnlyData(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperUpdateUserPublisherReadOnlyData
	void HelperUpdateUserPublisherInternalData(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperUpdateUserPublisherInternalData
	void HelperUpdateUserPublisherData(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperUpdateUserPublisherData
	void HelperUpdateUserInventoryItemCustomData(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperUpdateUserInventoryItemCustomData
	void HelperUpdateUserInternalData(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperUpdateUserInternalData
	void HelperUpdateUserData(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperUpdateUserData
	void HelperUpdateSharedGroupData(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperUpdateSharedGroupData
	void HelperUpdatePlayerStatistics(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperUpdatePlayerStatistics
	void HelperUpdateCharacterStatistics(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperUpdateCharacterStatistics
	void HelperUpdateCharacterReadOnlyData(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperUpdateCharacterReadOnlyData
	void HelperUpdateCharacterInternalData(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperUpdateCharacterInternalData
	void HelperUpdateCharacterData(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperUpdateCharacterData
	void HelperUpdateBans(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperUpdateBans
	void HelperUpdateAvatarUrl(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperUpdateAvatarUrl
	void HelperUnlockContainerItem(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperUnlockContainerItem
	void HelperUnlockContainerInstance(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperUnlockContainerInstance
	void HelperUnlinkXboxAccount(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperUnlinkXboxAccount
	void HelperUnlinkSteamId(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperUnlinkSteamId
	void HelperUnlinkServerCustomId(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperUnlinkServerCustomId
	void HelperUnlinkPSNAccount(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperUnlinkPSNAccount
	void HelperUnlinkNintendoSwitchDeviceId(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperUnlinkNintendoSwitchDeviceId
	void HelperUnlinkNintendoServiceAccount(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperUnlinkNintendoServiceAccount
	void HelperSubtractUserVirtualCurrency(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperSubtractUserVirtualCurrency
	void HelperSubtractCharacterVirtualCurrency(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperSubtractCharacterVirtualCurrency
	void HelperSetTitleInternalData(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperSetTitleInternalData
	void HelperSetTitleData(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperSetTitleData
	void HelperSetPublisherData(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperSetPublisherData
	void HelperSetPlayerSecret(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperSetPlayerSecret
	void HelperSetGameServerInstanceTags(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperSetGameServerInstanceTags
	void HelperSetGameServerInstanceState(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperSetGameServerInstanceState
	void HelperSetGameServerInstanceData(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperSetGameServerInstanceData
	void HelperSetFriendTags(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperSetFriendTags
	void HelperSendPushNotificationFromTemplate(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperSendPushNotificationFromTemplate
	void HelperSendPushNotification(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperSendPushNotification
	void HelperSendEmailFromTemplate(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperSendEmailFromTemplate
	void HelperSendCustomAccountRecoveryEmail(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperSendCustomAccountRecoveryEmail
	void HelperSavePushNotificationTemplate(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperSavePushNotificationTemplate
	void HelperRevokeInventoryItems(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperRevokeInventoryItems
	void HelperRevokeInventoryItem(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperRevokeInventoryItem
	void HelperRevokeBans(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperRevokeBans
	void HelperRevokeAllBansForUser(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperRevokeAllBansForUser
	void HelperReportPlayer(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperReportPlayer
	void HelperRemoveSharedGroupMembers(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperRemoveSharedGroupMembers
	void HelperRemovePlayerTag(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperRemovePlayerTag
	void HelperRemoveGenericID(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperRemoveGenericID
	void HelperRemoveFriend(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperRemoveFriend
	void HelperRegisterGame(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperRegisterGame
	void HelperRefreshGameServerInstanceHeartbeat(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperRefreshGameServerInstanceHeartbeat
	void HelperRedeemMatchmakerTicket(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperRedeemMatchmakerTicket
	void HelperRedeemCoupon(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperRedeemCoupon
	void HelperNotifyMatchmakerPlayerLeft(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperNotifyMatchmakerPlayerLeft
	void HelperMoveItemToUserFromCharacter(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperMoveItemToUserFromCharacter
	void HelperMoveItemToCharacterFromUser(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperMoveItemToCharacterFromUser
	void HelperMoveItemToCharacterFromCharacter(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperMoveItemToCharacterFromCharacter
	void HelperModifyItemUses(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperModifyItemUses
	void HelperLoginWithXboxId(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperLoginWithXboxId
	void HelperLoginWithXbox(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperLoginWithXbox
	void HelperLoginWithSteamId(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperLoginWithSteamId
	void HelperLoginWithServerCustomId(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperLoginWithServerCustomId
	void HelperLinkXboxAccount(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperLinkXboxAccount
	void HelperLinkSteamId(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperLinkSteamId
	void HelperLinkServerCustomId(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperLinkServerCustomId
	void HelperLinkPSNAccount(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperLinkPSNAccount
	void HelperLinkNintendoSwitchDeviceId(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperLinkNintendoSwitchDeviceId
	void HelperLinkNintendoServiceAccount(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperLinkNintendoServiceAccount
	void HelperGrantItemsToUsers(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperGrantItemsToUsers
	void HelperGrantItemsToUser(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperGrantItemsToUser
	void HelperGrantItemsToCharacter(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperGrantItemsToCharacter
	void HelperGrantCharacterToUser(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperGrantCharacterToUser
	void HelperGetUserReadOnlyData(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperGetUserReadOnlyData
	void HelperGetUserPublisherReadOnlyData(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperGetUserPublisherReadOnlyData
	void HelperGetUserPublisherInternalData(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperGetUserPublisherInternalData
	void HelperGetUserPublisherData(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperGetUserPublisherData
	void HelperGetUserInventory(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperGetUserInventory
	void HelperGetUserInternalData(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperGetUserInternalData
	void HelperGetUserData(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperGetUserData
	void HelperGetUserBans(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperGetUserBans
	void HelperGetUserAccountInfo(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperGetUserAccountInfo
	void HelperGetTitleNews(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperGetTitleNews
	void HelperGetTitleInternalData(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperGetTitleInternalData
	void HelperGetTitleData(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperGetTitleData
	void HelperGetTime(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperGetTime
	void HelperGetStoreItems(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperGetStoreItems
	void HelperGetSharedGroupData(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperGetSharedGroupData
	void HelperGetServerCustomIDsFromPlayFabIDs(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperGetServerCustomIDsFromPlayFabIDs
	void HelperGetRandomResultTables(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperGetRandomResultTables
	void HelperGetPublisherData(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperGetPublisherData
	void HelperGetPlayFabIDsFromXboxLiveIDs(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperGetPlayFabIDsFromXboxLiveIDs
	void HelperGetPlayFabIDsFromTwitchIDs(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperGetPlayFabIDsFromTwitchIDs
	void HelperGetPlayFabIDsFromSteamIDs(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperGetPlayFabIDsFromSteamIDs
	void HelperGetPlayFabIDsFromPSNAccountIDs(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperGetPlayFabIDsFromPSNAccountIDs
	void HelperGetPlayFabIDsFromNintendoSwitchDeviceIds(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperGetPlayFabIDsFromNintendoSwitchDeviceIds
	void HelperGetPlayFabIDsFromNintendoServiceAccountIds(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperGetPlayFabIDsFromNintendoServiceAccountIds
	void HelperGetPlayFabIDsFromGenericIDs(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperGetPlayFabIDsFromGenericIDs
	void HelperGetPlayFabIDsFromFacebookInstantGamesIds(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperGetPlayFabIDsFromFacebookInstantGamesIds
	void HelperGetPlayFabIDsFromFacebookIDs(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperGetPlayFabIDsFromFacebookIDs
	void HelperGetPlayerTags(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperGetPlayerTags
	void HelperGetPlayerStatisticVersions(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperGetPlayerStatisticVersions
	void HelperGetPlayerStatistics(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperGetPlayerStatistics
	void HelperGetPlayersInSegment(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperGetPlayersInSegment
	void HelperGetPlayerSegments(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperGetPlayerSegments
	void HelperGetPlayerProfile(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperGetPlayerProfile
	void HelperGetPlayerCombinedInfo(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperGetPlayerCombinedInfo
	void HelperGetLeaderboardForUserCharacters(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperGetLeaderboardForUserCharacters
	void HelperGetLeaderboardAroundUser(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperGetLeaderboardAroundUser
	void HelperGetLeaderboardAroundCharacter(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperGetLeaderboardAroundCharacter
	void HelperGetLeaderboard(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperGetLeaderboard
	void HelperGetFriendsList(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperGetFriendsList
	void HelperGetFriendLeaderboard(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperGetFriendLeaderboard
	void HelperGetContentDownloadUrl(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperGetContentDownloadUrl
	void HelperGetCharacterStatistics(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperGetCharacterStatistics
	void HelperGetCharacterReadOnlyData(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperGetCharacterReadOnlyData
	void HelperGetCharacterLeaderboard(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperGetCharacterLeaderboard
	void HelperGetCharacterInventory(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperGetCharacterInventory
	void HelperGetCharacterInternalData(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperGetCharacterInternalData
	void HelperGetCharacterData(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperGetCharacterData
	void HelperGetCatalogItems(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperGetCatalogItems
	void HelperGetAllUsersCharacters(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperGetAllUsersCharacters
	void HelperGetAllSegments(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperGetAllSegments
	void HelperExecuteCloudScript(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperExecuteCloudScript
	void HelperEvaluateRandomResultTable(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperEvaluateRandomResultTable
	void HelperDeregisterGame(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperDeregisterGame
	void HelperDeleteSharedGroup(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperDeleteSharedGroup
	void HelperDeletePushNotificationTemplate(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperDeletePushNotificationTemplate
	void HelperDeletePlayer(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperDeletePlayer
	void HelperDeleteCharacterFromUser(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperDeleteCharacterFromUser
	void HelperCreateSharedGroup(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperCreateSharedGroup
	void HelperConsumeItem(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperConsumeItem
	void HelperBanUsers(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperBanUsers
	void HelperAwardSteamAchievement(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperAwardSteamAchievement
	void HelperAuthenticateSessionTicket(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperAuthenticateSessionTicket
	void HelperAddUserVirtualCurrency(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperAddUserVirtualCurrency
	void HelperAddSharedGroupMembers(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperAddSharedGroupMembers
	void HelperAddPlayerTag(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperAddPlayerTag
	void HelperAddGenericID(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperAddGenericID
	void HelperAddFriend(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperAddFriend
	void HelperAddCharacterVirtualCurrency(struct FPlayFabBaseModel Response, struct UObject* customData, bool Successful); // Function PlayFab.PlayFabServerAPI.HelperAddCharacterVirtualCurrency
	struct UPlayFabServerAPI* GrantItemsToUsers(struct FServerGrantItemsToUsersRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.GrantItemsToUsers
	struct UPlayFabServerAPI* GrantItemsToUser(struct FServerGrantItemsToUserRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.GrantItemsToUser
	struct UPlayFabServerAPI* GrantItemsToCharacter(struct FServerGrantItemsToCharacterRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.GrantItemsToCharacter
	struct UPlayFabServerAPI* GrantCharacterToUser(struct FServerGrantCharacterToUserRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.GrantCharacterToUser
	struct UPlayFabServerAPI* GetUserReadOnlyData(struct FServerGetUserDataRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.GetUserReadOnlyData
	struct UPlayFabServerAPI* GetUserPublisherReadOnlyData(struct FServerGetUserDataRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.GetUserPublisherReadOnlyData
	struct UPlayFabServerAPI* GetUserPublisherInternalData(struct FServerGetUserDataRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.GetUserPublisherInternalData
	struct UPlayFabServerAPI* GetUserPublisherData(struct FServerGetUserDataRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.GetUserPublisherData
	struct UPlayFabServerAPI* GetUserInventory(struct FServerGetUserInventoryRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.GetUserInventory
	struct UPlayFabServerAPI* GetUserInternalData(struct FServerGetUserDataRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.GetUserInternalData
	struct UPlayFabServerAPI* GetUserData(struct FServerGetUserDataRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.GetUserData
	struct UPlayFabServerAPI* GetUserBans(struct FServerGetUserBansRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.GetUserBans
	struct UPlayFabServerAPI* GetUserAccountInfo(struct FServerGetUserAccountInfoRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.GetUserAccountInfo
	struct UPlayFabServerAPI* GetTitleNews(struct FServerGetTitleNewsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.GetTitleNews
	struct UPlayFabServerAPI* GetTitleInternalData(struct FServerGetTitleDataRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.GetTitleInternalData
	struct UPlayFabServerAPI* GetTitleData(struct FServerGetTitleDataRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.GetTitleData
	struct UPlayFabServerAPI* GetTime(struct FServerGetTimeRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.GetTime
	struct UPlayFabServerAPI* GetStoreItems(struct FServerGetStoreItemsServerRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.GetStoreItems
	struct UPlayFabServerAPI* GetSharedGroupData(struct FServerGetSharedGroupDataRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.GetSharedGroupData
	struct UPlayFabServerAPI* GetServerCustomIDsFromPlayFabIDs(struct FServerGetServerCustomIDsFromPlayFabIDsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.GetServerCustomIDsFromPlayFabIDs
	struct UPlayFabServerAPI* GetRandomResultTables(struct FServerGetRandomResultTablesRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.GetRandomResultTables
	struct UPlayFabServerAPI* GetPublisherData(struct FServerGetPublisherDataRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.GetPublisherData
	struct UPlayFabServerAPI* GetPlayFabIDsFromXboxLiveIDs(struct FServerGetPlayFabIDsFromXboxLiveIDsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.GetPlayFabIDsFromXboxLiveIDs
	struct UPlayFabServerAPI* GetPlayFabIDsFromTwitchIDs(struct FServerGetPlayFabIDsFromTwitchIDsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.GetPlayFabIDsFromTwitchIDs
	struct UPlayFabServerAPI* GetPlayFabIDsFromSteamIDs(struct FServerGetPlayFabIDsFromSteamIDsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.GetPlayFabIDsFromSteamIDs
	struct UPlayFabServerAPI* GetPlayFabIDsFromPSNAccountIDs(struct FServerGetPlayFabIDsFromPSNAccountIDsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.GetPlayFabIDsFromPSNAccountIDs
	struct UPlayFabServerAPI* GetPlayFabIDsFromNintendoSwitchDeviceIds(struct FServerGetPlayFabIDsFromNintendoSwitchDeviceIdsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.GetPlayFabIDsFromNintendoSwitchDeviceIds
	struct UPlayFabServerAPI* GetPlayFabIDsFromNintendoServiceAccountIds(struct FServerGetPlayFabIDsFromNintendoServiceAccountIdsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.GetPlayFabIDsFromNintendoServiceAccountIds
	struct UPlayFabServerAPI* GetPlayFabIDsFromGenericIDs(struct FServerGetPlayFabIDsFromGenericIDsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.GetPlayFabIDsFromGenericIDs
	struct UPlayFabServerAPI* GetPlayFabIDsFromFacebookInstantGamesIds(struct FServerGetPlayFabIDsFromFacebookInstantGamesIdsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.GetPlayFabIDsFromFacebookInstantGamesIds
	struct UPlayFabServerAPI* GetPlayFabIDsFromFacebookIDs(struct FServerGetPlayFabIDsFromFacebookIDsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.GetPlayFabIDsFromFacebookIDs
	struct UPlayFabServerAPI* GetPlayerTags(struct FServerGetPlayerTagsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.GetPlayerTags
	struct UPlayFabServerAPI* GetPlayerStatisticVersions(struct FServerGetPlayerStatisticVersionsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.GetPlayerStatisticVersions
	struct UPlayFabServerAPI* GetPlayerStatistics(struct FServerGetPlayerStatisticsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.GetPlayerStatistics
	struct UPlayFabServerAPI* GetPlayersInSegment(struct FServerGetPlayersInSegmentRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.GetPlayersInSegment
	struct UPlayFabServerAPI* GetPlayerSegments(struct FServerGetPlayersSegmentsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.GetPlayerSegments
	struct UPlayFabServerAPI* GetPlayerProfile(struct FServerGetPlayerProfileRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.GetPlayerProfile
	struct UPlayFabServerAPI* GetPlayerCombinedInfo(struct FServerGetPlayerCombinedInfoRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.GetPlayerCombinedInfo
	struct UPlayFabServerAPI* GetLeaderboardForUserCharacters(struct FServerGetLeaderboardForUsersCharactersRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.GetLeaderboardForUserCharacters
	struct UPlayFabServerAPI* GetLeaderboardAroundUser(struct FServerGetLeaderboardAroundUserRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.GetLeaderboardAroundUser
	struct UPlayFabServerAPI* GetLeaderboardAroundCharacter(struct FServerGetLeaderboardAroundCharacterRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.GetLeaderboardAroundCharacter
	struct UPlayFabServerAPI* GetLeaderboard(struct FServerGetLeaderboardRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.GetLeaderboard
	struct UPlayFabServerAPI* GetFriendsList(struct FServerGetFriendsListRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.GetFriendsList
	struct UPlayFabServerAPI* GetFriendLeaderboard(struct FServerGetFriendLeaderboardRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.GetFriendLeaderboard
	struct UPlayFabServerAPI* GetContentDownloadUrl(struct FServerGetContentDownloadUrlRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.GetContentDownloadUrl
	struct UPlayFabServerAPI* GetCharacterStatistics(struct FServerGetCharacterStatisticsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.GetCharacterStatistics
	struct UPlayFabServerAPI* GetCharacterReadOnlyData(struct FServerGetCharacterDataRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.GetCharacterReadOnlyData
	struct UPlayFabServerAPI* GetCharacterLeaderboard(struct FServerGetCharacterLeaderboardRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.GetCharacterLeaderboard
	struct UPlayFabServerAPI* GetCharacterInventory(struct FServerGetCharacterInventoryRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.GetCharacterInventory
	struct UPlayFabServerAPI* GetCharacterInternalData(struct FServerGetCharacterDataRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.GetCharacterInternalData
	struct UPlayFabServerAPI* GetCharacterData(struct FServerGetCharacterDataRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.GetCharacterData
	struct UPlayFabServerAPI* GetCatalogItems(struct FServerGetCatalogItemsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.GetCatalogItems
	struct UPlayFabServerAPI* GetAllUsersCharacters(struct FServerListUsersCharactersRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.GetAllUsersCharacters
	struct UPlayFabServerAPI* GetAllSegments(struct FServerGetAllSegmentsRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.GetAllSegments
	struct UPlayFabServerAPI* ExecuteCloudScript(struct FServerExecuteCloudScriptServerRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.ExecuteCloudScript
	struct UPlayFabServerAPI* EvaluateRandomResultTable(struct FServerEvaluateRandomResultTableRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.EvaluateRandomResultTable
	struct UPlayFabServerAPI* DeregisterGame(struct FServerDeregisterGameRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.DeregisterGame
	struct UPlayFabServerAPI* DeleteSharedGroup(struct FServerDeleteSharedGroupRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.DeleteSharedGroup
	struct UPlayFabServerAPI* DeletePushNotificationTemplate(struct FServerDeletePushNotificationTemplateRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.DeletePushNotificationTemplate
	struct UPlayFabServerAPI* DeletePlayer(struct FServerDeletePlayerRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.DeletePlayer
	struct UPlayFabServerAPI* DeleteCharacterFromUser(struct FServerDeleteCharacterFromUserRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.DeleteCharacterFromUser
	void DelegateOnSuccessWriteTitleEvent__DelegateSignature(struct FServerWriteEventResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessWriteTitleEvent__DelegateSignature
	void DelegateOnSuccessWritePlayerEvent__DelegateSignature(struct FServerWriteEventResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessWritePlayerEvent__DelegateSignature
	void DelegateOnSuccessWriteCharacterEvent__DelegateSignature(struct FServerWriteEventResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessWriteCharacterEvent__DelegateSignature
	void DelegateOnSuccessUpdateUserReadOnlyData__DelegateSignature(struct FServerUpdateUserDataResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessUpdateUserReadOnlyData__DelegateSignature
	void DelegateOnSuccessUpdateUserPublisherReadOnlyData__DelegateSignature(struct FServerUpdateUserDataResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessUpdateUserPublisherReadOnlyData__DelegateSignature
	void DelegateOnSuccessUpdateUserPublisherInternalData__DelegateSignature(struct FServerUpdateUserDataResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessUpdateUserPublisherInternalData__DelegateSignature
	void DelegateOnSuccessUpdateUserPublisherData__DelegateSignature(struct FServerUpdateUserDataResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessUpdateUserPublisherData__DelegateSignature
	void DelegateOnSuccessUpdateUserInventoryItemCustomData__DelegateSignature(struct FServerEmptyResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessUpdateUserInventoryItemCustomData__DelegateSignature
	void DelegateOnSuccessUpdateUserInternalData__DelegateSignature(struct FServerUpdateUserDataResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessUpdateUserInternalData__DelegateSignature
	void DelegateOnSuccessUpdateUserData__DelegateSignature(struct FServerUpdateUserDataResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessUpdateUserData__DelegateSignature
	void DelegateOnSuccessUpdateSharedGroupData__DelegateSignature(struct FServerUpdateSharedGroupDataResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessUpdateSharedGroupData__DelegateSignature
	void DelegateOnSuccessUpdatePlayerStatistics__DelegateSignature(struct FServerUpdatePlayerStatisticsResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessUpdatePlayerStatistics__DelegateSignature
	void DelegateOnSuccessUpdateCharacterStatistics__DelegateSignature(struct FServerUpdateCharacterStatisticsResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessUpdateCharacterStatistics__DelegateSignature
	void DelegateOnSuccessUpdateCharacterReadOnlyData__DelegateSignature(struct FServerUpdateCharacterDataResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessUpdateCharacterReadOnlyData__DelegateSignature
	void DelegateOnSuccessUpdateCharacterInternalData__DelegateSignature(struct FServerUpdateCharacterDataResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessUpdateCharacterInternalData__DelegateSignature
	void DelegateOnSuccessUpdateCharacterData__DelegateSignature(struct FServerUpdateCharacterDataResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessUpdateCharacterData__DelegateSignature
	void DelegateOnSuccessUpdateBans__DelegateSignature(struct FServerUpdateBansResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessUpdateBans__DelegateSignature
	void DelegateOnSuccessUpdateAvatarUrl__DelegateSignature(struct FServerEmptyResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessUpdateAvatarUrl__DelegateSignature
	void DelegateOnSuccessUnlockContainerItem__DelegateSignature(struct FServerUnlockContainerItemResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessUnlockContainerItem__DelegateSignature
	void DelegateOnSuccessUnlockContainerInstance__DelegateSignature(struct FServerUnlockContainerItemResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessUnlockContainerInstance__DelegateSignature
	void DelegateOnSuccessUnlinkXboxAccount__DelegateSignature(struct FServerUnlinkXboxAccountResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessUnlinkXboxAccount__DelegateSignature
	void DelegateOnSuccessUnlinkSteamId__DelegateSignature(struct FServerUnlinkSteamIdResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessUnlinkSteamId__DelegateSignature
	void DelegateOnSuccessUnlinkServerCustomId__DelegateSignature(struct FServerUnlinkServerCustomIdResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessUnlinkServerCustomId__DelegateSignature
	void DelegateOnSuccessUnlinkPSNAccount__DelegateSignature(struct FServerUnlinkPSNAccountResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessUnlinkPSNAccount__DelegateSignature
	void DelegateOnSuccessUnlinkNintendoSwitchDeviceId__DelegateSignature(struct FServerUnlinkNintendoSwitchDeviceIdResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessUnlinkNintendoSwitchDeviceId__DelegateSignature
	void DelegateOnSuccessUnlinkNintendoServiceAccount__DelegateSignature(struct FServerEmptyResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessUnlinkNintendoServiceAccount__DelegateSignature
	void DelegateOnSuccessSubtractUserVirtualCurrency__DelegateSignature(struct FServerModifyUserVirtualCurrencyResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessSubtractUserVirtualCurrency__DelegateSignature
	void DelegateOnSuccessSubtractCharacterVirtualCurrency__DelegateSignature(struct FServerModifyCharacterVirtualCurrencyResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessSubtractCharacterVirtualCurrency__DelegateSignature
	void DelegateOnSuccessSetTitleInternalData__DelegateSignature(struct FServerSetTitleDataResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessSetTitleInternalData__DelegateSignature
	void DelegateOnSuccessSetTitleData__DelegateSignature(struct FServerSetTitleDataResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessSetTitleData__DelegateSignature
	void DelegateOnSuccessSetPublisherData__DelegateSignature(struct FServerSetPublisherDataResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessSetPublisherData__DelegateSignature
	void DelegateOnSuccessSetPlayerSecret__DelegateSignature(struct FServerSetPlayerSecretResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessSetPlayerSecret__DelegateSignature
	void DelegateOnSuccessSetGameServerInstanceTags__DelegateSignature(struct FServerSetGameServerInstanceTagsResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessSetGameServerInstanceTags__DelegateSignature
	void DelegateOnSuccessSetGameServerInstanceState__DelegateSignature(struct FServerSetGameServerInstanceStateResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessSetGameServerInstanceState__DelegateSignature
	void DelegateOnSuccessSetGameServerInstanceData__DelegateSignature(struct FServerSetGameServerInstanceDataResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessSetGameServerInstanceData__DelegateSignature
	void DelegateOnSuccessSetFriendTags__DelegateSignature(struct FServerEmptyResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessSetFriendTags__DelegateSignature
	void DelegateOnSuccessSendPushNotificationFromTemplate__DelegateSignature(struct FServerSendPushNotificationResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessSendPushNotificationFromTemplate__DelegateSignature
	void DelegateOnSuccessSendPushNotification__DelegateSignature(struct FServerSendPushNotificationResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessSendPushNotification__DelegateSignature
	void DelegateOnSuccessSendEmailFromTemplate__DelegateSignature(struct FServerSendEmailFromTemplateResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessSendEmailFromTemplate__DelegateSignature
	void DelegateOnSuccessSendCustomAccountRecoveryEmail__DelegateSignature(struct FServerSendCustomAccountRecoveryEmailResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessSendCustomAccountRecoveryEmail__DelegateSignature
	void DelegateOnSuccessSavePushNotificationTemplate__DelegateSignature(struct FServerSavePushNotificationTemplateResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessSavePushNotificationTemplate__DelegateSignature
	void DelegateOnSuccessRevokeInventoryItems__DelegateSignature(struct FServerRevokeInventoryItemsResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessRevokeInventoryItems__DelegateSignature
	void DelegateOnSuccessRevokeInventoryItem__DelegateSignature(struct FServerRevokeInventoryResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessRevokeInventoryItem__DelegateSignature
	void DelegateOnSuccessRevokeBans__DelegateSignature(struct FServerRevokeBansResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessRevokeBans__DelegateSignature
	void DelegateOnSuccessRevokeAllBansForUser__DelegateSignature(struct FServerRevokeAllBansForUserResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessRevokeAllBansForUser__DelegateSignature
	void DelegateOnSuccessReportPlayer__DelegateSignature(struct FServerReportPlayerServerResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessReportPlayer__DelegateSignature
	void DelegateOnSuccessRemoveSharedGroupMembers__DelegateSignature(struct FServerRemoveSharedGroupMembersResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessRemoveSharedGroupMembers__DelegateSignature
	void DelegateOnSuccessRemovePlayerTag__DelegateSignature(struct FServerRemovePlayerTagResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessRemovePlayerTag__DelegateSignature
	void DelegateOnSuccessRemoveGenericID__DelegateSignature(struct FServerEmptyResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessRemoveGenericID__DelegateSignature
	void DelegateOnSuccessRemoveFriend__DelegateSignature(struct FServerEmptyResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessRemoveFriend__DelegateSignature
	void DelegateOnSuccessRegisterGame__DelegateSignature(struct FServerRegisterGameResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessRegisterGame__DelegateSignature
	void DelegateOnSuccessRefreshGameServerInstanceHeartbeat__DelegateSignature(struct FServerRefreshGameServerInstanceHeartbeatResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessRefreshGameServerInstanceHeartbeat__DelegateSignature
	void DelegateOnSuccessRedeemMatchmakerTicket__DelegateSignature(struct FServerRedeemMatchmakerTicketResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessRedeemMatchmakerTicket__DelegateSignature
	void DelegateOnSuccessRedeemCoupon__DelegateSignature(struct FServerRedeemCouponResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessRedeemCoupon__DelegateSignature
	void DelegateOnSuccessNotifyMatchmakerPlayerLeft__DelegateSignature(struct FServerNotifyMatchmakerPlayerLeftResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessNotifyMatchmakerPlayerLeft__DelegateSignature
	void DelegateOnSuccessMoveItemToUserFromCharacter__DelegateSignature(struct FServerMoveItemToUserFromCharacterResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessMoveItemToUserFromCharacter__DelegateSignature
	void DelegateOnSuccessMoveItemToCharacterFromUser__DelegateSignature(struct FServerMoveItemToCharacterFromUserResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessMoveItemToCharacterFromUser__DelegateSignature
	void DelegateOnSuccessMoveItemToCharacterFromCharacter__DelegateSignature(struct FServerMoveItemToCharacterFromCharacterResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessMoveItemToCharacterFromCharacter__DelegateSignature
	void DelegateOnSuccessModifyItemUses__DelegateSignature(struct FServerModifyItemUsesResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessModifyItemUses__DelegateSignature
	void DelegateOnSuccessLoginWithXboxId__DelegateSignature(struct FServerServerLoginResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessLoginWithXboxId__DelegateSignature
	void DelegateOnSuccessLoginWithXbox__DelegateSignature(struct FServerServerLoginResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessLoginWithXbox__DelegateSignature
	void DelegateOnSuccessLoginWithSteamId__DelegateSignature(struct FServerServerLoginResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessLoginWithSteamId__DelegateSignature
	void DelegateOnSuccessLoginWithServerCustomId__DelegateSignature(struct FServerServerLoginResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessLoginWithServerCustomId__DelegateSignature
	void DelegateOnSuccessLinkXboxAccount__DelegateSignature(struct FServerLinkXboxAccountResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessLinkXboxAccount__DelegateSignature
	void DelegateOnSuccessLinkSteamId__DelegateSignature(struct FServerLinkSteamIdResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessLinkSteamId__DelegateSignature
	void DelegateOnSuccessLinkServerCustomId__DelegateSignature(struct FServerLinkServerCustomIdResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessLinkServerCustomId__DelegateSignature
	void DelegateOnSuccessLinkPSNAccount__DelegateSignature(struct FServerLinkPSNAccountResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessLinkPSNAccount__DelegateSignature
	void DelegateOnSuccessLinkNintendoSwitchDeviceId__DelegateSignature(struct FServerLinkNintendoSwitchDeviceIdResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessLinkNintendoSwitchDeviceId__DelegateSignature
	void DelegateOnSuccessLinkNintendoServiceAccount__DelegateSignature(struct FServerEmptyResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessLinkNintendoServiceAccount__DelegateSignature
	void DelegateOnSuccessGrantItemsToUsers__DelegateSignature(struct FServerGrantItemsToUsersResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGrantItemsToUsers__DelegateSignature
	void DelegateOnSuccessGrantItemsToUser__DelegateSignature(struct FServerGrantItemsToUserResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGrantItemsToUser__DelegateSignature
	void DelegateOnSuccessGrantItemsToCharacter__DelegateSignature(struct FServerGrantItemsToCharacterResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGrantItemsToCharacter__DelegateSignature
	void DelegateOnSuccessGrantCharacterToUser__DelegateSignature(struct FServerGrantCharacterToUserResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGrantCharacterToUser__DelegateSignature
	void DelegateOnSuccessGetUserReadOnlyData__DelegateSignature(struct FServerGetUserDataResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGetUserReadOnlyData__DelegateSignature
	void DelegateOnSuccessGetUserPublisherReadOnlyData__DelegateSignature(struct FServerGetUserDataResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGetUserPublisherReadOnlyData__DelegateSignature
	void DelegateOnSuccessGetUserPublisherInternalData__DelegateSignature(struct FServerGetUserDataResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGetUserPublisherInternalData__DelegateSignature
	void DelegateOnSuccessGetUserPublisherData__DelegateSignature(struct FServerGetUserDataResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGetUserPublisherData__DelegateSignature
	void DelegateOnSuccessGetUserInventory__DelegateSignature(struct FServerGetUserInventoryResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGetUserInventory__DelegateSignature
	void DelegateOnSuccessGetUserInternalData__DelegateSignature(struct FServerGetUserDataResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGetUserInternalData__DelegateSignature
	void DelegateOnSuccessGetUserData__DelegateSignature(struct FServerGetUserDataResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGetUserData__DelegateSignature
	void DelegateOnSuccessGetUserBans__DelegateSignature(struct FServerGetUserBansResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGetUserBans__DelegateSignature
	void DelegateOnSuccessGetUserAccountInfo__DelegateSignature(struct FServerGetUserAccountInfoResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGetUserAccountInfo__DelegateSignature
	void DelegateOnSuccessGetTitleNews__DelegateSignature(struct FServerGetTitleNewsResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGetTitleNews__DelegateSignature
	void DelegateOnSuccessGetTitleInternalData__DelegateSignature(struct FServerGetTitleDataResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGetTitleInternalData__DelegateSignature
	void DelegateOnSuccessGetTitleData__DelegateSignature(struct FServerGetTitleDataResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGetTitleData__DelegateSignature
	void DelegateOnSuccessGetTime__DelegateSignature(struct FServerGetTimeResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGetTime__DelegateSignature
	void DelegateOnSuccessGetStoreItems__DelegateSignature(struct FServerGetStoreItemsResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGetStoreItems__DelegateSignature
	void DelegateOnSuccessGetSharedGroupData__DelegateSignature(struct FServerGetSharedGroupDataResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGetSharedGroupData__DelegateSignature
	void DelegateOnSuccessGetServerCustomIDsFromPlayFabIDs__DelegateSignature(struct FServerGetServerCustomIDsFromPlayFabIDsResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGetServerCustomIDsFromPlayFabIDs__DelegateSignature
	void DelegateOnSuccessGetRandomResultTables__DelegateSignature(struct FServerGetRandomResultTablesResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGetRandomResultTables__DelegateSignature
	void DelegateOnSuccessGetPublisherData__DelegateSignature(struct FServerGetPublisherDataResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGetPublisherData__DelegateSignature
	void DelegateOnSuccessGetPlayFabIDsFromXboxLiveIDs__DelegateSignature(struct FServerGetPlayFabIDsFromXboxLiveIDsResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGetPlayFabIDsFromXboxLiveIDs__DelegateSignature
	void DelegateOnSuccessGetPlayFabIDsFromTwitchIDs__DelegateSignature(struct FServerGetPlayFabIDsFromTwitchIDsResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGetPlayFabIDsFromTwitchIDs__DelegateSignature
	void DelegateOnSuccessGetPlayFabIDsFromSteamIDs__DelegateSignature(struct FServerGetPlayFabIDsFromSteamIDsResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGetPlayFabIDsFromSteamIDs__DelegateSignature
	void DelegateOnSuccessGetPlayFabIDsFromPSNAccountIDs__DelegateSignature(struct FServerGetPlayFabIDsFromPSNAccountIDsResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGetPlayFabIDsFromPSNAccountIDs__DelegateSignature
	void DelegateOnSuccessGetPlayFabIDsFromNintendoSwitchDeviceIds__DelegateSignature(struct FServerGetPlayFabIDsFromNintendoSwitchDeviceIdsResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGetPlayFabIDsFromNintendoSwitchDeviceIds__DelegateSignature
	void DelegateOnSuccessGetPlayFabIDsFromNintendoServiceAccountIds__DelegateSignature(struct FServerGetPlayFabIDsFromNintendoServiceAccountIdsResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGetPlayFabIDsFromNintendoServiceAccountIds__DelegateSignature
	void DelegateOnSuccessGetPlayFabIDsFromGenericIDs__DelegateSignature(struct FServerGetPlayFabIDsFromGenericIDsResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGetPlayFabIDsFromGenericIDs__DelegateSignature
	void DelegateOnSuccessGetPlayFabIDsFromFacebookInstantGamesIds__DelegateSignature(struct FServerGetPlayFabIDsFromFacebookInstantGamesIdsResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGetPlayFabIDsFromFacebookInstantGamesIds__DelegateSignature
	void DelegateOnSuccessGetPlayFabIDsFromFacebookIDs__DelegateSignature(struct FServerGetPlayFabIDsFromFacebookIDsResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGetPlayFabIDsFromFacebookIDs__DelegateSignature
	void DelegateOnSuccessGetPlayerTags__DelegateSignature(struct FServerGetPlayerTagsResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGetPlayerTags__DelegateSignature
	void DelegateOnSuccessGetPlayerStatisticVersions__DelegateSignature(struct FServerGetPlayerStatisticVersionsResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGetPlayerStatisticVersions__DelegateSignature
	void DelegateOnSuccessGetPlayerStatistics__DelegateSignature(struct FServerGetPlayerStatisticsResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGetPlayerStatistics__DelegateSignature
	void DelegateOnSuccessGetPlayersInSegment__DelegateSignature(struct FServerGetPlayersInSegmentResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGetPlayersInSegment__DelegateSignature
	void DelegateOnSuccessGetPlayerSegments__DelegateSignature(struct FServerGetPlayerSegmentsResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGetPlayerSegments__DelegateSignature
	void DelegateOnSuccessGetPlayerProfile__DelegateSignature(struct FServerGetPlayerProfileResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGetPlayerProfile__DelegateSignature
	void DelegateOnSuccessGetPlayerCombinedInfo__DelegateSignature(struct FServerGetPlayerCombinedInfoResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGetPlayerCombinedInfo__DelegateSignature
	void DelegateOnSuccessGetLeaderboardForUserCharacters__DelegateSignature(struct FServerGetLeaderboardForUsersCharactersResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGetLeaderboardForUserCharacters__DelegateSignature
	void DelegateOnSuccessGetLeaderboardAroundUser__DelegateSignature(struct FServerGetLeaderboardAroundUserResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGetLeaderboardAroundUser__DelegateSignature
	void DelegateOnSuccessGetLeaderboardAroundCharacter__DelegateSignature(struct FServerGetLeaderboardAroundCharacterResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGetLeaderboardAroundCharacter__DelegateSignature
	void DelegateOnSuccessGetLeaderboard__DelegateSignature(struct FServerGetLeaderboardResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGetLeaderboard__DelegateSignature
	void DelegateOnSuccessGetFriendsList__DelegateSignature(struct FServerGetFriendsListResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGetFriendsList__DelegateSignature
	void DelegateOnSuccessGetFriendLeaderboard__DelegateSignature(struct FServerGetLeaderboardResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGetFriendLeaderboard__DelegateSignature
	void DelegateOnSuccessGetContentDownloadUrl__DelegateSignature(struct FServerGetContentDownloadUrlResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGetContentDownloadUrl__DelegateSignature
	void DelegateOnSuccessGetCharacterStatistics__DelegateSignature(struct FServerGetCharacterStatisticsResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGetCharacterStatistics__DelegateSignature
	void DelegateOnSuccessGetCharacterReadOnlyData__DelegateSignature(struct FServerGetCharacterDataResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGetCharacterReadOnlyData__DelegateSignature
	void DelegateOnSuccessGetCharacterLeaderboard__DelegateSignature(struct FServerGetCharacterLeaderboardResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGetCharacterLeaderboard__DelegateSignature
	void DelegateOnSuccessGetCharacterInventory__DelegateSignature(struct FServerGetCharacterInventoryResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGetCharacterInventory__DelegateSignature
	void DelegateOnSuccessGetCharacterInternalData__DelegateSignature(struct FServerGetCharacterDataResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGetCharacterInternalData__DelegateSignature
	void DelegateOnSuccessGetCharacterData__DelegateSignature(struct FServerGetCharacterDataResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGetCharacterData__DelegateSignature
	void DelegateOnSuccessGetCatalogItems__DelegateSignature(struct FServerGetCatalogItemsResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGetCatalogItems__DelegateSignature
	void DelegateOnSuccessGetAllUsersCharacters__DelegateSignature(struct FServerListUsersCharactersResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGetAllUsersCharacters__DelegateSignature
	void DelegateOnSuccessGetAllSegments__DelegateSignature(struct FServerGetAllSegmentsResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessGetAllSegments__DelegateSignature
	void DelegateOnSuccessExecuteCloudScript__DelegateSignature(struct FServerExecuteCloudScriptResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessExecuteCloudScript__DelegateSignature
	void DelegateOnSuccessEvaluateRandomResultTable__DelegateSignature(struct FServerEvaluateRandomResultTableResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessEvaluateRandomResultTable__DelegateSignature
	void DelegateOnSuccessDeregisterGame__DelegateSignature(struct FServerDeregisterGameResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessDeregisterGame__DelegateSignature
	void DelegateOnSuccessDeleteSharedGroup__DelegateSignature(struct FServerEmptyResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessDeleteSharedGroup__DelegateSignature
	void DelegateOnSuccessDeletePushNotificationTemplate__DelegateSignature(struct FServerDeletePushNotificationTemplateResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessDeletePushNotificationTemplate__DelegateSignature
	void DelegateOnSuccessDeletePlayer__DelegateSignature(struct FServerDeletePlayerResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessDeletePlayer__DelegateSignature
	void DelegateOnSuccessDeleteCharacterFromUser__DelegateSignature(struct FServerDeleteCharacterFromUserResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessDeleteCharacterFromUser__DelegateSignature
	void DelegateOnSuccessCreateSharedGroup__DelegateSignature(struct FServerCreateSharedGroupResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessCreateSharedGroup__DelegateSignature
	void DelegateOnSuccessConsumeItem__DelegateSignature(struct FServerConsumeItemResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessConsumeItem__DelegateSignature
	void DelegateOnSuccessBanUsers__DelegateSignature(struct FServerBanUsersResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessBanUsers__DelegateSignature
	void DelegateOnSuccessAwardSteamAchievement__DelegateSignature(struct FServerAwardSteamAchievementResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessAwardSteamAchievement__DelegateSignature
	void DelegateOnSuccessAuthenticateSessionTicket__DelegateSignature(struct FServerAuthenticateSessionTicketResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessAuthenticateSessionTicket__DelegateSignature
	void DelegateOnSuccessAddUserVirtualCurrency__DelegateSignature(struct FServerModifyUserVirtualCurrencyResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessAddUserVirtualCurrency__DelegateSignature
	void DelegateOnSuccessAddSharedGroupMembers__DelegateSignature(struct FServerAddSharedGroupMembersResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessAddSharedGroupMembers__DelegateSignature
	void DelegateOnSuccessAddPlayerTag__DelegateSignature(struct FServerAddPlayerTagResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessAddPlayerTag__DelegateSignature
	void DelegateOnSuccessAddGenericID__DelegateSignature(struct FServerEmptyResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessAddGenericID__DelegateSignature
	void DelegateOnSuccessAddFriend__DelegateSignature(struct FServerEmptyResponse Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessAddFriend__DelegateSignature
	void DelegateOnSuccessAddCharacterVirtualCurrency__DelegateSignature(struct FServerModifyCharacterVirtualCurrencyResult Result, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnSuccessAddCharacterVirtualCurrency__DelegateSignature
	void DelegateOnFailurePlayFabError__DelegateSignature(struct FPlayFabError Error, struct UObject* customData); // DelegateFunction PlayFab.PlayFabServerAPI.DelegateOnFailurePlayFabError__DelegateSignature
	struct UPlayFabServerAPI* CreateSharedGroup(struct FServerCreateSharedGroupRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.CreateSharedGroup
	struct UPlayFabServerAPI* ConsumeItem(struct FServerConsumeItemRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.ConsumeItem
	struct UPlayFabServerAPI* BanUsers(struct FServerBanUsersRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.BanUsers
	struct UPlayFabServerAPI* AwardSteamAchievement(struct FServerAwardSteamAchievementRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.AwardSteamAchievement
	struct UPlayFabServerAPI* AuthenticateSessionTicket(struct FServerAuthenticateSessionTicketRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.AuthenticateSessionTicket
	struct UPlayFabServerAPI* AddUserVirtualCurrency(struct FServerAddUserVirtualCurrencyRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.AddUserVirtualCurrency
	struct UPlayFabServerAPI* AddSharedGroupMembers(struct FServerAddSharedGroupMembersRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.AddSharedGroupMembers
	struct UPlayFabServerAPI* AddPlayerTag(struct FServerAddPlayerTagRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.AddPlayerTag
	struct UPlayFabServerAPI* AddGenericID(struct FServerAddGenericIDRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.AddGenericID
	struct UPlayFabServerAPI* AddFriend(struct FServerAddFriendRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.AddFriend
	struct UPlayFabServerAPI* AddCharacterVirtualCurrency(struct FServerAddCharacterVirtualCurrencyRequest Request, struct FDelegate onSuccess, struct FDelegate onFailure, struct UObject* customData); // Function PlayFab.PlayFabServerAPI.AddCharacterVirtualCurrency
}; 



// Class PlayFab.PlayFabServerModelDecoder
// Size: 0x28(Inherited: 0x28) 
struct UPlayFabServerModelDecoder : public UBlueprintFunctionLibrary
{

	struct FServerWriteEventResponse decodeWriteEventResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeWriteEventResponseResponse
	struct FServerUpdateUserDataResult decodeUpdateUserDataResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeUpdateUserDataResultResponse
	struct FServerUpdateSharedGroupDataResult decodeUpdateSharedGroupDataResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeUpdateSharedGroupDataResultResponse
	struct FServerUpdatePlayerStatisticsResult decodeUpdatePlayerStatisticsResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeUpdatePlayerStatisticsResultResponse
	struct FServerUpdateCharacterStatisticsResult decodeUpdateCharacterStatisticsResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeUpdateCharacterStatisticsResultResponse
	struct FServerUpdateCharacterDataResult decodeUpdateCharacterDataResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeUpdateCharacterDataResultResponse
	struct FServerUpdateBansResult decodeUpdateBansResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeUpdateBansResultResponse
	struct FServerUnlockContainerItemResult decodeUnlockContainerItemResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeUnlockContainerItemResultResponse
	struct FServerUnlinkXboxAccountResult decodeUnlinkXboxAccountResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeUnlinkXboxAccountResultResponse
	struct FServerUnlinkSteamIdResult decodeUnlinkSteamIdResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeUnlinkSteamIdResultResponse
	struct FServerUnlinkServerCustomIdResult decodeUnlinkServerCustomIdResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeUnlinkServerCustomIdResultResponse
	struct FServerUnlinkPSNAccountResult decodeUnlinkPSNAccountResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeUnlinkPSNAccountResultResponse
	struct FServerUnlinkNintendoSwitchDeviceIdResult decodeUnlinkNintendoSwitchDeviceIdResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeUnlinkNintendoSwitchDeviceIdResultResponse
	struct FServerSetTitleDataResult decodeSetTitleDataResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeSetTitleDataResultResponse
	struct FServerSetPublisherDataResult decodeSetPublisherDataResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeSetPublisherDataResultResponse
	struct FServerSetPlayerSecretResult decodeSetPlayerSecretResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeSetPlayerSecretResultResponse
	struct FServerSetGameServerInstanceTagsResult decodeSetGameServerInstanceTagsResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeSetGameServerInstanceTagsResultResponse
	struct FServerSetGameServerInstanceStateResult decodeSetGameServerInstanceStateResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeSetGameServerInstanceStateResultResponse
	struct FServerSetGameServerInstanceDataResult decodeSetGameServerInstanceDataResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeSetGameServerInstanceDataResultResponse
	struct FServerServerLoginResult decodeServerLoginResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeServerLoginResultResponse
	struct FServerSendPushNotificationResult decodeSendPushNotificationResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeSendPushNotificationResultResponse
	struct FServerSendEmailFromTemplateResult decodeSendEmailFromTemplateResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeSendEmailFromTemplateResultResponse
	struct FServerSendCustomAccountRecoveryEmailResult decodeSendCustomAccountRecoveryEmailResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeSendCustomAccountRecoveryEmailResultResponse
	struct FServerSavePushNotificationTemplateResult decodeSavePushNotificationTemplateResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeSavePushNotificationTemplateResultResponse
	struct FServerRevokeInventoryResult decodeRevokeInventoryResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeRevokeInventoryResultResponse
	struct FServerRevokeInventoryItemsResult decodeRevokeInventoryItemsResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeRevokeInventoryItemsResultResponse
	struct FServerRevokeBansResult decodeRevokeBansResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeRevokeBansResultResponse
	struct FServerRevokeAllBansForUserResult decodeRevokeAllBansForUserResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeRevokeAllBansForUserResultResponse
	struct FServerReportPlayerServerResult decodeReportPlayerServerResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeReportPlayerServerResultResponse
	struct FServerRemoveSharedGroupMembersResult decodeRemoveSharedGroupMembersResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeRemoveSharedGroupMembersResultResponse
	struct FServerRemovePlayerTagResult decodeRemovePlayerTagResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeRemovePlayerTagResultResponse
	struct FServerRegisterGameResponse decodeRegisterGameResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeRegisterGameResponseResponse
	struct FServerRefreshGameServerInstanceHeartbeatResult decodeRefreshGameServerInstanceHeartbeatResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeRefreshGameServerInstanceHeartbeatResultResponse
	struct FServerRedeemMatchmakerTicketResult decodeRedeemMatchmakerTicketResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeRedeemMatchmakerTicketResultResponse
	struct FServerRedeemCouponResult decodeRedeemCouponResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeRedeemCouponResultResponse
	struct FServerNotifyMatchmakerPlayerLeftResult decodeNotifyMatchmakerPlayerLeftResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeNotifyMatchmakerPlayerLeftResultResponse
	struct FServerMoveItemToUserFromCharacterResult decodeMoveItemToUserFromCharacterResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeMoveItemToUserFromCharacterResultResponse
	struct FServerMoveItemToCharacterFromUserResult decodeMoveItemToCharacterFromUserResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeMoveItemToCharacterFromUserResultResponse
	struct FServerMoveItemToCharacterFromCharacterResult decodeMoveItemToCharacterFromCharacterResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeMoveItemToCharacterFromCharacterResultResponse
	struct FServerModifyUserVirtualCurrencyResult decodeModifyUserVirtualCurrencyResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeModifyUserVirtualCurrencyResultResponse
	struct FServerModifyItemUsesResult decodeModifyItemUsesResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeModifyItemUsesResultResponse
	struct FServerModifyCharacterVirtualCurrencyResult decodeModifyCharacterVirtualCurrencyResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeModifyCharacterVirtualCurrencyResultResponse
	struct FServerListUsersCharactersResult decodeListUsersCharactersResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeListUsersCharactersResultResponse
	struct FServerLinkXboxAccountResult decodeLinkXboxAccountResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeLinkXboxAccountResultResponse
	struct FServerLinkSteamIdResult decodeLinkSteamIdResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeLinkSteamIdResultResponse
	struct FServerLinkServerCustomIdResult decodeLinkServerCustomIdResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeLinkServerCustomIdResultResponse
	struct FServerLinkPSNAccountResult decodeLinkPSNAccountResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeLinkPSNAccountResultResponse
	struct FServerLinkNintendoSwitchDeviceIdResult decodeLinkNintendoSwitchDeviceIdResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeLinkNintendoSwitchDeviceIdResultResponse
	struct FServerGrantItemsToUsersResult decodeGrantItemsToUsersResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeGrantItemsToUsersResultResponse
	struct FServerGrantItemsToUserResult decodeGrantItemsToUserResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeGrantItemsToUserResultResponse
	struct FServerGrantItemsToCharacterResult decodeGrantItemsToCharacterResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeGrantItemsToCharacterResultResponse
	struct FServerGrantCharacterToUserResult decodeGrantCharacterToUserResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeGrantCharacterToUserResultResponse
	struct FServerGetUserInventoryResult decodeGetUserInventoryResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeGetUserInventoryResultResponse
	struct FServerGetUserDataResult decodeGetUserDataResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeGetUserDataResultResponse
	struct FServerGetUserBansResult decodeGetUserBansResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeGetUserBansResultResponse
	struct FServerGetUserAccountInfoResult decodeGetUserAccountInfoResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeGetUserAccountInfoResultResponse
	struct FServerGetTitleNewsResult decodeGetTitleNewsResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeGetTitleNewsResultResponse
	struct FServerGetTitleDataResult decodeGetTitleDataResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeGetTitleDataResultResponse
	struct FServerGetTimeResult decodeGetTimeResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeGetTimeResultResponse
	struct FServerGetStoreItemsResult decodeGetStoreItemsResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeGetStoreItemsResultResponse
	struct FServerGetSharedGroupDataResult decodeGetSharedGroupDataResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeGetSharedGroupDataResultResponse
	struct FServerGetServerCustomIDsFromPlayFabIDsResult decodeGetServerCustomIDsFromPlayFabIDsResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeGetServerCustomIDsFromPlayFabIDsResultResponse
	struct FServerGetRandomResultTablesResult decodeGetRandomResultTablesResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeGetRandomResultTablesResultResponse
	struct FServerGetPublisherDataResult decodeGetPublisherDataResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeGetPublisherDataResultResponse
	struct FServerGetPlayFabIDsFromXboxLiveIDsResult decodeGetPlayFabIDsFromXboxLiveIDsResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeGetPlayFabIDsFromXboxLiveIDsResultResponse
	struct FServerGetPlayFabIDsFromTwitchIDsResult decodeGetPlayFabIDsFromTwitchIDsResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeGetPlayFabIDsFromTwitchIDsResultResponse
	struct FServerGetPlayFabIDsFromSteamIDsResult decodeGetPlayFabIDsFromSteamIDsResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeGetPlayFabIDsFromSteamIDsResultResponse
	struct FServerGetPlayFabIDsFromPSNAccountIDsResult decodeGetPlayFabIDsFromPSNAccountIDsResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeGetPlayFabIDsFromPSNAccountIDsResultResponse
	struct FServerGetPlayFabIDsFromNintendoSwitchDeviceIdsResult decodeGetPlayFabIDsFromNintendoSwitchDeviceIdsResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeGetPlayFabIDsFromNintendoSwitchDeviceIdsResultResponse
	struct FServerGetPlayFabIDsFromNintendoServiceAccountIdsResult decodeGetPlayFabIDsFromNintendoServiceAccountIdsResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeGetPlayFabIDsFromNintendoServiceAccountIdsResultResponse
	struct FServerGetPlayFabIDsFromGenericIDsResult decodeGetPlayFabIDsFromGenericIDsResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeGetPlayFabIDsFromGenericIDsResultResponse
	struct FServerGetPlayFabIDsFromFacebookInstantGamesIdsResult decodeGetPlayFabIDsFromFacebookInstantGamesIdsResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeGetPlayFabIDsFromFacebookInstantGamesIdsResultResponse
	struct FServerGetPlayFabIDsFromFacebookIDsResult decodeGetPlayFabIDsFromFacebookIDsResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeGetPlayFabIDsFromFacebookIDsResultResponse
	struct FServerGetPlayerTagsResult decodeGetPlayerTagsResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeGetPlayerTagsResultResponse
	struct FServerGetPlayerStatisticVersionsResult decodeGetPlayerStatisticVersionsResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeGetPlayerStatisticVersionsResultResponse
	struct FServerGetPlayerStatisticsResult decodeGetPlayerStatisticsResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeGetPlayerStatisticsResultResponse
	struct FServerGetPlayersInSegmentResult decodeGetPlayersInSegmentResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeGetPlayersInSegmentResultResponse
	struct FServerGetPlayerSegmentsResult decodeGetPlayerSegmentsResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeGetPlayerSegmentsResultResponse
	struct FServerGetPlayerProfileResult decodeGetPlayerProfileResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeGetPlayerProfileResultResponse
	struct FServerGetPlayerCombinedInfoResult decodeGetPlayerCombinedInfoResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeGetPlayerCombinedInfoResultResponse
	struct FServerGetLeaderboardResult decodeGetLeaderboardResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeGetLeaderboardResultResponse
	struct FServerGetLeaderboardForUsersCharactersResult decodeGetLeaderboardForUsersCharactersResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeGetLeaderboardForUsersCharactersResultResponse
	struct FServerGetLeaderboardAroundUserResult decodeGetLeaderboardAroundUserResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeGetLeaderboardAroundUserResultResponse
	struct FServerGetLeaderboardAroundCharacterResult decodeGetLeaderboardAroundCharacterResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeGetLeaderboardAroundCharacterResultResponse
	struct FServerGetFriendsListResult decodeGetFriendsListResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeGetFriendsListResultResponse
	struct FServerGetContentDownloadUrlResult decodeGetContentDownloadUrlResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeGetContentDownloadUrlResultResponse
	struct FServerGetCharacterStatisticsResult decodeGetCharacterStatisticsResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeGetCharacterStatisticsResultResponse
	struct FServerGetCharacterLeaderboardResult decodeGetCharacterLeaderboardResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeGetCharacterLeaderboardResultResponse
	struct FServerGetCharacterInventoryResult decodeGetCharacterInventoryResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeGetCharacterInventoryResultResponse
	struct FServerGetCharacterDataResult decodeGetCharacterDataResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeGetCharacterDataResultResponse
	struct FServerGetCatalogItemsResult decodeGetCatalogItemsResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeGetCatalogItemsResultResponse
	struct FServerGetAllSegmentsResult decodeGetAllSegmentsResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeGetAllSegmentsResultResponse
	struct FServerExecuteCloudScriptResult decodeExecuteCloudScriptResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeExecuteCloudScriptResultResponse
	struct FServerEvaluateRandomResultTableResult decodeEvaluateRandomResultTableResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeEvaluateRandomResultTableResultResponse
	struct FServerEmptyResult decodeEmptyResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeEmptyResultResponse
	struct FServerEmptyResponse decodeEmptyResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeEmptyResponseResponse
	struct FServerDeregisterGameResponse decodeDeregisterGameResponseResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeDeregisterGameResponseResponse
	struct FServerDeletePushNotificationTemplateResult decodeDeletePushNotificationTemplateResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeDeletePushNotificationTemplateResultResponse
	struct FServerDeletePlayerResult decodeDeletePlayerResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeDeletePlayerResultResponse
	struct FServerDeleteCharacterFromUserResult decodeDeleteCharacterFromUserResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeDeleteCharacterFromUserResultResponse
	struct FServerCreateSharedGroupResult decodeCreateSharedGroupResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeCreateSharedGroupResultResponse
	struct FServerConsumeItemResult decodeConsumeItemResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeConsumeItemResultResponse
	struct FServerBanUsersResult decodeBanUsersResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeBanUsersResultResponse
	struct FServerAwardSteamAchievementResult decodeAwardSteamAchievementResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeAwardSteamAchievementResultResponse
	struct FServerAuthenticateSessionTicketResult decodeAuthenticateSessionTicketResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeAuthenticateSessionTicketResultResponse
	struct FServerAddSharedGroupMembersResult decodeAddSharedGroupMembersResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeAddSharedGroupMembersResultResponse
	struct FServerAddPlayerTagResult decodeAddPlayerTagResultResponse(struct UPlayFabJsonObject* Response); // Function PlayFab.PlayFabServerModelDecoder.decodeAddPlayerTagResultResponse
}; 



