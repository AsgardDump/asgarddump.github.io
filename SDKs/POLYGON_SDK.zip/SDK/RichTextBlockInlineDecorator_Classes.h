#pragma once 
#include <RichTextBlockInlineDecorator_Structs.h>
 
 
 
// Class RichTextBlockInlineDecorator.RichTextBlockInlineDecorator
// Size: 0x28(Inherited: 0x28) 
struct URichTextBlockInlineDecorator : public URichTextBlockDecorator
{

}; 



