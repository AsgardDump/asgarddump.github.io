#pragma once 
#include <BP_UserEntry_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_UserEntry.BP_UserEntry_C
// Size: 0x90(Inherited: 0x28) 
struct UBP_UserEntry_C : public UUserEntry
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x28(0x8)
	struct FUniqueNetIdRepl UserId;  // 0x30(0x30)
	struct FMulticastInlineDelegate OnGetAvatar;  // 0x60(0x10)
	struct UTexture* UserAvatar;  // 0x70(0x8)
	uint8_t  OnlineStatus;  // 0x78(0x1)
	char pad_121[7];  // 0x79(0x7)
	struct FMulticastInlineDelegate OnPresenceUpdated;  // 0x80(0x10)

	void OnGetAvatarComplete_824A0C6B4C2DBA1D157208B3CDEF0AE0(bool bWasSuccessful, struct UTexture* ResultTexture); // Function BP_UserEntry.BP_UserEntry_C.OnGetAvatarComplete_824A0C6B4C2DBA1D157208B3CDEF0AE0
	void OnCallFailed_824A0C6B4C2DBA1D157208B3CDEF0AE0(bool bWasSuccessful, struct UTexture* ResultTexture); // Function BP_UserEntry.BP_UserEntry_C.OnCallFailed_824A0C6B4C2DBA1D157208B3CDEF0AE0
	void ParseUserInfo(struct FUniqueNetIdRepl UserId); // Function BP_UserEntry.BP_UserEntry_C.ParseUserInfo
	void OnPresenceReceived_Event(struct FUniqueNetIdRepl UserId, struct FOnlineUserPresenceData Presence); // Function BP_UserEntry.BP_UserEntry_C.OnPresenceReceived_Event
	void ExecuteUbergraph_BP_UserEntry(int32_t EntryPoint); // Function BP_UserEntry.BP_UserEntry_C.ExecuteUbergraph_BP_UserEntry
	void OnPresenceUpdated__DelegateSignature(); // Function BP_UserEntry.BP_UserEntry_C.OnPresenceUpdated__DelegateSignature
	void OnGetAvatar__DelegateSignature(); // Function BP_UserEntry.BP_UserEntry_C.OnGetAvatar__DelegateSignature
}; 



