#pragma once 
#include <DeveloperSettings_Structs.h>
 
 
 
// Class DeveloperSettings.DeveloperSettings
// Size: 0x38(Inherited: 0x28) 
struct UDeveloperSettings : public UObject
{
	char pad_40[16];  // 0x28(0x10)

}; 



// Class DeveloperSettings.DeveloperSettingsBackedByCVars
// Size: 0x38(Inherited: 0x38) 
struct UDeveloperSettingsBackedByCVars : public UDeveloperSettings
{

}; 



// Class DeveloperSettings.PlatformSettings
// Size: 0x40(Inherited: 0x28) 
struct UPlatformSettings : public UObject
{
	char pad_40[24];  // 0x28(0x18)

}; 



// Class DeveloperSettings.PlatformSettingsManager
// Size: 0x80(Inherited: 0x28) 
struct UPlatformSettingsManager : public UObject
{
	struct TMap<UPlatformSettings*, struct FPlatformSettingsInstances> SettingsMap;  // 0x28(0x50)
	char pad_120[8];  // 0x78(0x8)

}; 



