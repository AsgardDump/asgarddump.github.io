#pragma once 
#include <DefaultBindCaptureButton_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass DefaultBindCaptureButton.DefaultBindCaptureButton_C
// Size: 0x2C0(Inherited: 0x2A8) 
struct UDefaultBindCaptureButton_C : public UBindCaptureButton
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x2A8(0x8)
	struct UButton* Button_1;  // 0x2B0(0x8)
	struct UNamedSlot* Content;  // 0x2B8(0x8)

	void BndEvt__Button_0_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature(); // Function DefaultBindCaptureButton.DefaultBindCaptureButton_C.BndEvt__Button_0_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature
	void ExecuteUbergraph_DefaultBindCaptureButton(int32_t EntryPoint); // Function DefaultBindCaptureButton.DefaultBindCaptureButton_C.ExecuteUbergraph_DefaultBindCaptureButton
}; 



