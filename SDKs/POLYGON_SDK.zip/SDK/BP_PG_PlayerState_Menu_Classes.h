#pragma once 
#include <BP_PG_PlayerState_Menu_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_PG_PlayerState_Menu.BP_PG_PlayerState_Menu_C
// Size: 0x3D0(Inherited: 0x3C8) 
struct ABP_PG_PlayerState_Menu_C : public APG_PlayerState_Menu
{
	struct USceneComponent* DefaultSceneRoot;  // 0x3C8(0x8)

}; 



