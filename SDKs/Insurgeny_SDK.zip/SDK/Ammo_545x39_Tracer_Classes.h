#pragma once 
#include <Ammo_545x39_Tracer_Structs.h>
 
 
 
// DynamicClass Ammo_545x39_Tracer.Ammo_545x39_Tracer_C
// Size: 0x2C8(Inherited: 0x2C8) 
struct UAmmo_545x39_Tracer_C : public UAmmo_545x39_C
{

}; 



