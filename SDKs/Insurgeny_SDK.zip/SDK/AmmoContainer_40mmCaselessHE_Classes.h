#pragma once 
#include <AmmoContainer_40mmCaselessHE_Structs.h>
 
 
 
// BlueprintGeneratedClass AmmoContainer_40mmCaselessHE.AmmoContainer_40mmCaselessHE_C
// Size: 0x170(Inherited: 0x170) 
struct UAmmoContainer_40mmCaselessHE_C : public UAmmoContainer
{

}; 



