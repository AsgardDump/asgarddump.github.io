#pragma once 
#include <ABP_CP_Equipment_Insurgent_Structs.h>
 
 
 
// DynamicClass ABP_CP_Equipment_Insurgent.ABP_CP_Equipment_Insurgent_C
// Size: 0xA920(Inherited: 0x2C0) 
struct UABP_CP_Equipment_Insurgent_C : public UAnimInstance
{
	struct FAnimNode_Root AnimGraphNode_Root;  // 0x2C0(0x30)
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool_3;  // 0x2F0(0xA0)
	struct FAnimNode_RefPose AnimGraphNode_LocalRefPose;  // 0x390(0x18)
	struct FAnimNode_CopyPoseFromMesh AnimGraphNode_CopyPoseFromMesh;  // 0x3A8(0x1D8)
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose_2;  // 0x580(0x158)
	char pad_1752[8];  // 0x6D8(0x8)
	struct FAnimNode_RigidBody AnimGraphNode_RigidBody_18;  // 0x6E0(0x830)
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose;  // 0xF10(0x158)
	struct FAnimNode_BlendListByEnum AnimGraphNode_BlendListByEnum_2;  // 0x1068(0xB0)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace_19;  // 0x1118(0x20)
	char pad_4408[8];  // 0x1138(0x8)
	struct FAnimNode_RigidBody AnimGraphNode_RigidBody_17;  // 0x1140(0x830)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace_18;  // 0x1970(0x20)
	struct FAnimNode_RigidBody AnimGraphNode_RigidBody_16;  // 0x1990(0x830)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace_17;  // 0x21C0(0x20)
	struct FAnimNode_RigidBody AnimGraphNode_RigidBody_15;  // 0x21E0(0x830)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace_16;  // 0x2A10(0x20)
	struct FAnimNode_RigidBody AnimGraphNode_RigidBody_14;  // 0x2A30(0x830)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace_15;  // 0x3260(0x20)
	struct FAnimNode_RigidBody AnimGraphNode_RigidBody_13;  // 0x3280(0x830)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace_14;  // 0x3AB0(0x20)
	struct FAnimNode_RigidBody AnimGraphNode_RigidBody_12;  // 0x3AD0(0x830)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace_13;  // 0x4300(0x20)
	struct FAnimNode_RigidBody AnimGraphNode_RigidBody_11;  // 0x4320(0x830)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace_12;  // 0x4B50(0x20)
	struct FAnimNode_RigidBody AnimGraphNode_RigidBody_10;  // 0x4B70(0x830)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace_11;  // 0x53A0(0x20)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace_19;  // 0x53C0(0x20)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace_18;  // 0x53E0(0x20)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace_17;  // 0x5400(0x20)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace_16;  // 0x5420(0x20)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace_15;  // 0x5440(0x20)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace_14;  // 0x5460(0x20)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace_13;  // 0x5480(0x20)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace_12;  // 0x54A0(0x20)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace_11;  // 0x54C0(0x20)
	struct FAnimNode_CopyBone AnimGraphNode_CopyBone;  // 0x54E0(0xF0)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace_10;  // 0x55D0(0x20)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace_10;  // 0x55F0(0x20)
	struct FAnimNode_TwoWayBlend AnimGraphNode_TwoWayBlend;  // 0x5610(0xC8)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_23;  // 0x56D8(0x28)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_22;  // 0x5700(0x28)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_21;  // 0x5728(0x28)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_20;  // 0x5750(0x28)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_19;  // 0x5778(0x28)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_18;  // 0x57A0(0x28)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_17;  // 0x57C8(0x28)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_16;  // 0x57F0(0x28)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_15;  // 0x5818(0x28)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_14;  // 0x5840(0x28)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_13;  // 0x5868(0x28)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_12;  // 0x5890(0x28)
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool_2;  // 0x58B8(0xA0)
	char pad_22872[8];  // 0x5958(0x8)
	struct FAnimNode_RigidBody AnimGraphNode_RigidBody_9;  // 0x5960(0x830)
	struct FAnimNode_BlendListByEnum AnimGraphNode_BlendListByEnum;  // 0x6190(0xB0)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace_9;  // 0x6240(0x20)
	struct FAnimNode_RigidBody AnimGraphNode_RigidBody_8;  // 0x6260(0x830)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace_8;  // 0x6A90(0x20)
	struct FAnimNode_RigidBody AnimGraphNode_RigidBody_7;  // 0x6AB0(0x830)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace_7;  // 0x72E0(0x20)
	struct FAnimNode_RigidBody AnimGraphNode_RigidBody_6;  // 0x7300(0x830)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace_6;  // 0x7B30(0x20)
	struct FAnimNode_RigidBody AnimGraphNode_RigidBody_5;  // 0x7B50(0x830)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace_5;  // 0x8380(0x20)
	struct FAnimNode_RigidBody AnimGraphNode_RigidBody_4;  // 0x83A0(0x830)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace_4;  // 0x8BD0(0x20)
	struct FAnimNode_RigidBody AnimGraphNode_RigidBody_3;  // 0x8BF0(0x830)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace_3;  // 0x9420(0x20)
	struct FAnimNode_RigidBody AnimGraphNode_RigidBody_2;  // 0x9440(0x830)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace_2;  // 0x9C70(0x20)
	struct FAnimNode_RigidBody AnimGraphNode_RigidBody;  // 0x9C90(0x830)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace;  // 0xA4C0(0x20)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace_9;  // 0xA4E0(0x20)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace_8;  // 0xA500(0x20)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace_7;  // 0xA520(0x20)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace_6;  // 0xA540(0x20)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace_5;  // 0xA560(0x20)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace_4;  // 0xA580(0x20)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace_3;  // 0xA5A0(0x20)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace_2;  // 0xA5C0(0x20)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace;  // 0xA5E0(0x20)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_11;  // 0xA600(0x28)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_10;  // 0xA628(0x28)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_9;  // 0xA650(0x28)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_8;  // 0xA678(0x28)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_7;  // 0xA6A0(0x28)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_6;  // 0xA6C8(0x28)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_5;  // 0xA6F0(0x28)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_4;  // 0xA718(0x28)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_3;  // 0xA740(0x28)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_2;  // 0xA768(0x28)
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool;  // 0xA790(0xA0)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose;  // 0xA830(0x28)
	struct USkeletalMeshComponent* CharacterMesh;  // 0xA858(0x8)
	char pad_43104_1 : 7;  // 0xA860(0x1)
	bool bInitComplete : 1;  // 0xA860(0x1)
	uint8_t  CarrierArmourCombination;  // 0xA861(0x1)
	char pad_43106[6];  // 0xA862(0x6)
	struct UABP_Character_C* CharacterABPReference;  // 0xA868(0x8)
	char pad_43120_1 : 7;  // 0xA870(0x1)
	bool PreviousVehicleUserBoneHide : 1;  // 0xA870(0x1)
	char pad_43121_1 : 7;  // 0xA871(0x1)
	bool bIsFemale : 1;  // 0xA871(0x1)
	char pad_43122_1 : 7;  // 0xA872(0x1)
	bool bProfile : 1;  // 0xA872(0x1)
	char pad_43123_1 : 7;  // 0xA873(0x1)
	bool bEnabled : 1;  // 0xA873(0x1)
	float SimulateTimer;  // 0xA874(0x4)
	char pad_43128_1 : 7;  // 0xA878(0x1)
	bool bSimulateTimerExpired : 1;  // 0xA878(0x1)
	char pad_43129[7];  // 0xA879(0x7)
	struct AINSSoldier* Soldier;  // 0xA880(0x8)
	float Time;  // 0xA888(0x4)
	char pad_43148[4];  // 0xA88C(0x4)
	struct UAnimInstance* K2Node_Event_GearAnimInstance;  // 0xA890(0x8)
	uint8_t  K2Node_Event_Combination_2;  // 0xA898(0x1)
	char pad_43161[3];  // 0xA899(0x3)
	struct FName K2Node_Event_Faction_2;  // 0xA89C(0x8)
	char pad_43172[4];  // 0xA8A4(0x4)
	struct AINSSoldier* K2Node_DynamicCast_AsINSSoldier;  // 0xA8A8(0x8)
	char pad_43184_1 : 7;  // 0xA8B0(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0xA8B0(0x1)
	char pad_43185[7];  // 0xA8B1(0x7)
	struct UINSSkeletalMeshComponent* K2Node_Event_Carrier_2;  // 0xA8B8(0x8)
	struct AINSSoldier* K2Node_Event_Soldier;  // 0xA8C0(0x8)
	struct UAnimSequenceBase* K2Node_Event_Montage;  // 0xA8C8(0x8)
	char pad_43216_1 : 7;  // 0xA8D0(0x1)
	bool K2Node_Event_Enable : 1;  // 0xA8D0(0x1)
	char pad_43217_1 : 7;  // 0xA8D1(0x1)
	bool K2Node_Event_bProfile : 1;  // 0xA8D1(0x1)
	char pad_43218_1 : 7;  // 0xA8D2(0x1)
	bool K2Node_Event_bFemale : 1;  // 0xA8D2(0x1)
	char pad_43219[5];  // 0xA8D3(0x5)
	struct USkeletalMeshComponent* K2Node_Event_Character;  // 0xA8D8(0x8)
	struct ABP_Gear_BASE_Carrier_C* K2Node_Event_Carrier;  // 0xA8E0(0x8)
	uint8_t  K2Node_Event_Combination;  // 0xA8E8(0x1)
	char pad_43241[3];  // 0xA8E9(0x3)
	struct FName K2Node_Event_Faction;  // 0xA8EC(0x8)
	uint8_t  K2Node_Event_State;  // 0xA8F4(0x1)
	uint8_t  CallFunc_UpdateGearCopyPoseSettings_CarrierArmour;  // 0xA8F5(0x1)
	uint8_t  K2Node_Event_State_2;  // 0xA8F6(0x1)
	char pad_43255_1 : 7;  // 0xA8F7(0x1)
	bool K2Node_Event_bEnabled : 1;  // 0xA8F7(0x1)
	char pad_43256_1 : 7;  // 0xA8F8(0x1)
	bool K2Node_Event_Visibility : 1;  // 0xA8F8(0x1)
	char pad_43257[7];  // 0xA8F9(0x7)
	struct UABP_Character_C* K2Node_Event_AnimInstance;  // 0xA900(0x8)
	char pad_43272_1 : 7;  // 0xA908(0x1)
	bool K2Node_Event_Gunner : 1;  // 0xA908(0x1)
	char pad_43273_1 : 7;  // 0xA909(0x1)
	bool K2Node_Event_Passenger : 1;  // 0xA909(0x1)
	char pad_43274[2];  // 0xA90A(0x2)
	float K2Node_Event_DeltaTimeX;  // 0xA90C(0x4)
	struct ABP_Gear_GasMask_C* K2Node_Event_Gasmask;  // 0xA910(0x8)
	char pad_43288[8];  // 0xA918(0x8)

	void UpdatEquipmentOnBack(struct UINSSkeletalMeshComponent* bpp__Carrier__pf, struct AINSSoldier* bpp__Soldier__pf); // Function ABP_CP_Equipment_Insurgent.ABP_CP_Equipment_Insurgent_C.UpdatEquipmentOnBack
	void UpdateNightVisionState(uint8_t  bpp__State__pf); // Function ABP_CP_Equipment_Insurgent.ABP_CP_Equipment_Insurgent_C.UpdateNightVisionState
	void UpdateInsurgentNVGState(); // Function ABP_CP_Equipment_Insurgent.ABP_CP_Equipment_Insurgent_C.UpdateInsurgentNVGState
	void UpdateGearCopyPoseAnim(bool bpp__Enable__pf, bool bpp__bProfile__pf, bool bpp__bFemale__pf, struct USkeletalMeshComponent* bpp__Character__pf, struct ABP_Gear_BASE_Carrier_C* bpp__Carrier__pf, uint8_t  bpp__Combination__pf, struct FName bpp__Faction__pf); // Function ABP_CP_Equipment_Insurgent.ABP_CP_Equipment_Insurgent_C.UpdateGearCopyPoseAnim
	void UpdateGearBoneVisibility(bool bpp__Visibility__pf); // Function ABP_CP_Equipment_Insurgent.ABP_CP_Equipment_Insurgent_C.UpdateGearBoneVisibility
	void UpdateGasMaskState(uint8_t  bpp__State__pf); // Function ABP_CP_Equipment_Insurgent.ABP_CP_Equipment_Insurgent_C.UpdateGasMaskState
	void UpdateGasmaskReference(struct ABP_Gear_GasMask_C* bpp__Gasmask__pf); // Function ABP_CP_Equipment_Insurgent.ABP_CP_Equipment_Insurgent_C.UpdateGasmaskReference
	void UpdateCharacterBoneHide(struct UABP_Character_C* bpp__AnimInstance__pf, bool bpp__Gunner__pf, bool bpp__Passenger__pf); // Function ABP_CP_Equipment_Insurgent.ABP_CP_Equipment_Insurgent_C.UpdateCharacterBoneHide
	void UpdateCharacterAnimInstance(struct UAnimInstance* bpp__GearAnimInstance__pf, uint8_t  bpp__Combination__pf, struct FName bpp__Faction__pf); // Function ABP_CP_Equipment_Insurgent.ABP_CP_Equipment_Insurgent_C.UpdateCharacterAnimInstance
	void ResetEquipmentPhysics(); // Function ABP_CP_Equipment_Insurgent.ABP_CP_Equipment_Insurgent_C.ResetEquipmentPhysics
	void PrintHelper(struct FString bpp__Title__pf__const, struct FString bpp__Input__pf__const, float bpp__Duration__pf, struct FLinearColor bpp__TextColor__pf); // Function ABP_CP_Equipment_Insurgent.ABP_CP_Equipment_Insurgent_C.PrintHelper
	void NewFunction_1(); // Function ABP_CP_Equipment_Insurgent.ABP_CP_Equipment_Insurgent_C.NewFunction_1
	void MolotovRagState(bool bpp__bEnabled__pf); // Function ABP_CP_Equipment_Insurgent.ABP_CP_Equipment_Insurgent_C.MolotovRagState
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_CP_Equipment_Insurgent_AnimGraphNode_CopyPoseFromMesh_B7C8949746137AE43611F98883FB18FC(); // Function ABP_CP_Equipment_Insurgent.ABP_CP_Equipment_Insurgent_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_CP_Equipment_Insurgent_AnimGraphNode_CopyPoseFromMesh_B7C8949746137AE43611F98883FB18FC
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_CP_Equipment_Insurgent_AnimGraphNode_BlendListByEnum_F19D922F4E2D6A41192BA794BF4E1C47(); // Function ABP_CP_Equipment_Insurgent.ABP_CP_Equipment_Insurgent_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_CP_Equipment_Insurgent_AnimGraphNode_BlendListByEnum_F19D922F4E2D6A41192BA794BF4E1C47
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_CP_Equipment_Insurgent_AnimGraphNode_BlendListByEnum_7E0DF9874ECF15736FBF5981245A6323(); // Function ABP_CP_Equipment_Insurgent.ABP_CP_Equipment_Insurgent_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_CP_Equipment_Insurgent_AnimGraphNode_BlendListByEnum_7E0DF9874ECF15736FBF5981245A6323
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_CP_Equipment_Insurgent_AnimGraphNode_BlendListByBool_F0025F9F4C62D4AFD72307A1BADD27BD(); // Function ABP_CP_Equipment_Insurgent.ABP_CP_Equipment_Insurgent_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_CP_Equipment_Insurgent_AnimGraphNode_BlendListByBool_F0025F9F4C62D4AFD72307A1BADD27BD
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_CP_Equipment_Insurgent_AnimGraphNode_BlendListByBool_70B3452A48854F03794CD2A7B34E02FA(); // Function ABP_CP_Equipment_Insurgent.ABP_CP_Equipment_Insurgent_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_CP_Equipment_Insurgent_AnimGraphNode_BlendListByBool_70B3452A48854F03794CD2A7B34E02FA
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_CP_Equipment_Insurgent_AnimGraphNode_BlendListByBool_52A85B9A48C4258C58A9668705B0EE42(); // Function ABP_CP_Equipment_Insurgent.ABP_CP_Equipment_Insurgent_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_CP_Equipment_Insurgent_AnimGraphNode_BlendListByBool_52A85B9A48C4258C58A9668705B0EE42
	void DeltaRotatorAxis(float bpp__Axisx1__pfT, float bpp__Axisx2__pfT, float& bpp__Return__pf); // Function ABP_CP_Equipment_Insurgent.ABP_CP_Equipment_Insurgent_C.DeltaRotatorAxis
	void CombineRotatorAxis(float bpp__Axisx1__pfT, float bpp__Axisx2__pfT, float& bpp__Return__pf); // Function ABP_CP_Equipment_Insurgent.ABP_CP_Equipment_Insurgent_C.CombineRotatorAxis
	void CalcRelativeTransform(struct FTransform& bpp__Child__pf__const, struct FTransform& bpp__Parent__pf__const, struct FTransform& bpp__Return__pf); // Function ABP_CP_Equipment_Insurgent.ABP_CP_Equipment_Insurgent_C.CalcRelativeTransform
	void BlueprintUpdateAnimation(float bpp__DeltaTimeX__pf); // Function ABP_CP_Equipment_Insurgent.ABP_CP_Equipment_Insurgent_C.BlueprintUpdateAnimation
	void BlueprintInitializeAnimation(); // Function ABP_CP_Equipment_Insurgent.ABP_CP_Equipment_Insurgent_C.BlueprintInitializeAnimation
	void BlendOutMontage(struct UAnimSequenceBase* bpp__Montage__pf); // Function ABP_CP_Equipment_Insurgent.ABP_CP_Equipment_Insurgent_C.BlendOutMontage
	void AnimGraph(struct FPoseLink& bpp__AnimGraph__pf); // Function ABP_CP_Equipment_Insurgent.ABP_CP_Equipment_Insurgent_C.AnimGraph
}; 



