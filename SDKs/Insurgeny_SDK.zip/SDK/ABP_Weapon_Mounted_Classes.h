#pragma once 
#include <ABP_Weapon_Mounted_Structs.h>
 
 
 
// DynamicClass ABP_Weapon_Mounted.ABP_Weapon_Mounted_C
// Size: 0x2790(Inherited: 0x20A0) 
struct UABP_Weapon_Mounted_C : public UFirstPersonAnimInstance
{
	struct FAnimNode_Root AnimGraphNode_Root;  // 0x20A0(0x30)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer;  // 0x20D0(0x80)
	struct FAnimNode_Slot AnimGraphNode_Slot_7;  // 0x2150(0x48)
	struct FAnimNode_Slot AnimGraphNode_Slot_6;  // 0x2198(0x48)
	struct FAnimNode_Slot AnimGraphNode_Slot_5;  // 0x21E0(0x48)
	struct FAnimNode_Slot AnimGraphNode_Slot_4;  // 0x2228(0x48)
	struct FAnimNode_Slot AnimGraphNode_Slot_3;  // 0x2270(0x48)
	struct FAnimNode_Slot AnimGraphNode_Slot_2;  // 0x22B8(0x48)
	struct FAnimNode_Slot AnimGraphNode_Slot;  // 0x2300(0x48)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone;  // 0x2348(0x108)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace;  // 0x2450(0x20)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace;  // 0x2470(0x20)
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool;  // 0x2490(0xA0)
	struct FAnimNode_RefPose AnimGraphNode_LocalRefPose;  // 0x2530(0x18)
	struct FAnimNode_RotationOffsetBlendSpace AnimGraphNode_RotationOffsetBlendSpace;  // 0x2548(0x190)
	struct UAnimMontage* ActiveMountedFire;  // 0x26D8(0x8)
	int32_t RecoilSlotCycle;  // 0x26E0(0x4)
	struct FRotator BarrelRotator;  // 0x26E4(0xC)
	char pad_9968_1 : 7;  // 0x26F0(0x1)
	bool bIsFiring : 1;  // 0x26F0(0x1)
	char pad_9969[7];  // 0x26F1(0x7)
	struct UCurveFloat* SpinUpCurve;  // 0x26F8(0x8)
	char pad_9984_1 : 7;  // 0x2700(0x1)
	bool bHasReload : 1;  // 0x2700(0x1)
	char pad_9985_1 : 7;  // 0x2701(0x1)
	bool bIsValid : 1;  // 0x2701(0x1)
	char pad_9986[2];  // 0x2702(0x2)
	float MinigunAlpha;  // 0x2704(0x4)
	float SightFraction;  // 0x2708(0x4)
	char pad_9996_1 : 7;  // 0x270C(0x1)
	bool bIsIron : 1;  // 0x270C(0x1)
	char pad_9997_1 : 7;  // 0x270D(0x1)
	bool bUsesFireLoop : 1;  // 0x270D(0x1)
	char pad_9998[2];  // 0x270E(0x2)
	float MinigunYaw;  // 0x2710(0x4)
	float MinigunPitch;  // 0x2714(0x4)
	float MinigunInitialOffsetPitch;  // 0x2718(0x4)
	float MinigunInitialOffsetYaw;  // 0x271C(0x4)
	char pad_10016_1 : 7;  // 0x2720(0x1)
	bool K2Node_Event_bDryReload : 1;  // 0x2720(0x1)
	char pad_10017_1 : 7;  // 0x2721(0x1)
	bool K2Node_Event_bSingleReload : 1;  // 0x2721(0x1)
	char pad_10018[2];  // 0x2722(0x2)
	float K2Node_Event_RateMultiplier;  // 0x2724(0x4)
	float CallFunc_BreakRotator_Roll;  // 0x2728(0x4)
	float CallFunc_BreakRotator_Pitch;  // 0x272C(0x4)
	float CallFunc_BreakRotator_Yaw;  // 0x2730(0x4)
	struct FVector K2Node_Event_FireOrigin;  // 0x2734(0xC)
	struct FVector K2Node_Event_FireDirection;  // 0x2740(0xC)
	char pad_10060[4];  // 0x274C(0x4)
	struct AItemEquipable* K2Node_Event_Item;  // 0x2750(0x8)
	float K2Node_Event_DeltaTimeX;  // 0x2758(0x4)
	float CallFunc_BreakRotator_Roll_2;  // 0x275C(0x4)
	float CallFunc_BreakRotator_Pitch_2;  // 0x2760(0x4)
	float CallFunc_BreakRotator_Yaw_2;  // 0x2764(0x4)
	struct AItemMinigun* K2Node_DynamicCast_AsItem_Minigun;  // 0x2768(0x8)
	char pad_10096_1 : 7;  // 0x2770(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x2770(0x1)
	char pad_10097[3];  // 0x2771(0x3)
	float CallFunc_BreakRotator_Roll_3;  // 0x2774(0x4)
	float CallFunc_BreakRotator_Pitch_3;  // 0x2778(0x4)
	float CallFunc_BreakRotator_Yaw_3;  // 0x277C(0x4)
	float K2Node_MathExpression_ReturnValue;  // 0x2780(0x4)
	char pad_10116[12];  // 0x2784(0xC)

	void SetEquipable(struct AItemEquipable* bpp__Item__pf); // Function ABP_Weapon_Mounted.ABP_Weapon_Mounted_C.SetEquipable
	void OnPlayReload(bool bpp__Empty__pf, bool bpp__HasReload__pf); // Function ABP_Weapon_Mounted.ABP_Weapon_Mounted_C.OnPlayReload
	void OnPlayFireLoop(); // Function ABP_Weapon_Mounted.ABP_Weapon_Mounted_C.OnPlayFireLoop
	void OnPlayFire(); // Function ABP_Weapon_Mounted.ABP_Weapon_Mounted_C.OnPlayFire
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Weapon_Mounted_AnimGraphNode_SequencePlayer_9B6584244A3D39BC1B1CA3B0ED4A52C3(); // Function ABP_Weapon_Mounted.ABP_Weapon_Mounted_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Weapon_Mounted_AnimGraphNode_SequencePlayer_9B6584244A3D39BC1B1CA3B0ED4A52C3
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Weapon_Mounted_AnimGraphNode_RotationOffsetBlendSpace_8B9DEC2F41B85164E41C7CBC56771AE9(); // Function ABP_Weapon_Mounted.ABP_Weapon_Mounted_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Weapon_Mounted_AnimGraphNode_RotationOffsetBlendSpace_8B9DEC2F41B85164E41C7CBC56771AE9
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Weapon_Mounted_AnimGraphNode_ModifyBone_257D3A0A4E6F0D37C342A0955B5328FD(); // Function ABP_Weapon_Mounted.ABP_Weapon_Mounted_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Weapon_Mounted_AnimGraphNode_ModifyBone_257D3A0A4E6F0D37C342A0955B5328FD
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Weapon_Mounted_AnimGraphNode_BlendListByBool_11AFA0A94BEA31BD38319592ECFAB211(); // Function ABP_Weapon_Mounted.ABP_Weapon_Mounted_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Weapon_Mounted_AnimGraphNode_BlendListByBool_11AFA0A94BEA31BD38319592ECFAB211
	void BlueprintUpdateAnimation(float bpp__DeltaTimeX__pf); // Function ABP_Weapon_Mounted.ABP_Weapon_Mounted_C.BlueprintUpdateAnimation
	void BlueprintOnReloadInterrupt(); // Function ABP_Weapon_Mounted.ABP_Weapon_Mounted_C.BlueprintOnReloadInterrupt
	void BlueprintOnReload(bool bpp__bDryReload__pf__const, bool bpp__bSingleReload__pf__const, float bpp__RateMultiplier__pf__const); // Function ABP_Weapon_Mounted.ABP_Weapon_Mounted_C.BlueprintOnReload
	void BlueprintOnFirearmStopFire(); // Function ABP_Weapon_Mounted.ABP_Weapon_Mounted_C.BlueprintOnFirearmStopFire
	void BlueprintOnFirearmFired(struct FVector& bpp__FireOrigin__pf__const, struct FVector& bpp__FireDirection__pf__const); // Function ABP_Weapon_Mounted.ABP_Weapon_Mounted_C.BlueprintOnFirearmFired
	void BlueprintBeginPlay(); // Function ABP_Weapon_Mounted.ABP_Weapon_Mounted_C.BlueprintBeginPlay
	void AnimGraph(struct FPoseLink& bpp__AnimGraph__pf); // Function ABP_Weapon_Mounted.ABP_Weapon_Mounted_C.AnimGraph
}; 



