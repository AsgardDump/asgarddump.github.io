#pragma once 
#include <AmmoContainer_20mmSmoke_Structs.h>
 
 
 
// BlueprintGeneratedClass AmmoContainer_20mmSmoke.AmmoContainer_20mmSmoke_C
// Size: 0x170(Inherited: 0x170) 
struct UAmmoContainer_20mmSmoke_C : public UAmmoContainer
{

}; 



