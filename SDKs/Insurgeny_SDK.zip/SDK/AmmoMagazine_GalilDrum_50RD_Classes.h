#pragma once 
#include <AmmoMagazine_GalilDrum_50RD_Structs.h>
 
 
 
// BlueprintGeneratedClass AmmoMagazine_GalilDrum_50RD.AmmoMagazine_GalilDrum_50RD_C
// Size: 0x178(Inherited: 0x178) 
struct UAmmoMagazine_GalilDrum_50RD_C : public UAmmoContainerMagazine
{

}; 



