#pragma once 
#include "SDK.h" 
 
 
// DelegateFunction ABP_VehiclePassenger.ABP_VehiclePassenger_C.OnVehicleSeatChangeDelegate__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FOnVehicleSeatChangeDelegate__DelegateSignature
{
	struct UVehicleSeatComponent* bpp__VehicleSeat__pf;  // 0x0(0x8)

}; 
// Function ABP_VehiclePassenger.ABP_VehiclePassenger_C.AnimGraph
// Size: 0x10(Inherited: 0x0) 
struct FAnimGraph
{
	struct FPoseLink bpp__AnimGraph__pf;  // 0x0(0x10)

}; 
// Function ABP_VehiclePassenger.ABP_VehiclePassenger_C.BlueprintUpdateAnimation
// Size: 0x4(Inherited: 0x0) 
struct FBlueprintUpdateAnimation
{
	float bpp__DeltaTimeX__pf;  // 0x0(0x4)

}; 
// Function ABP_VehiclePassenger.ABP_VehiclePassenger_C.OnEnteredVehicle
// Size: 0x8(Inherited: 0x0) 
struct FOnEnteredVehicle
{
	struct UVehicleSeatComponent* bpp__VehicleSeat__pf;  // 0x0(0x8)

}; 
