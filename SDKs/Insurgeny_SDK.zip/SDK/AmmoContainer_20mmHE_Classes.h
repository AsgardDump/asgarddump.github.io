#pragma once 
#include <AmmoContainer_20mmHE_Structs.h>
 
 
 
// BlueprintGeneratedClass AmmoContainer_20mmHE.AmmoContainer_20mmHE_C
// Size: 0x170(Inherited: 0x170) 
struct UAmmoContainer_20mmHE_C : public UAmmoContainer
{

}; 



