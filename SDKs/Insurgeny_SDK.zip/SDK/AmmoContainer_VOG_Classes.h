#pragma once 
#include <AmmoContainer_VOG_Structs.h>
 
 
 
// BlueprintGeneratedClass AmmoContainer_VOG.AmmoContainer_VOG_C
// Size: 0x170(Inherited: 0x170) 
struct UAmmoContainer_VOG_C : public UAmmoContainer
{

}; 



