#pragma once 
#include <AmmoMagazine_L105_15RD_Structs.h>
 
 
 
// BlueprintGeneratedClass AmmoMagazine_L105_15RD.AmmoMagazine_L105_15RD_C
// Size: 0x178(Inherited: 0x178) 
struct UAmmoMagazine_L105_15RD_C : public UAmmoContainerMagazine
{

}; 



