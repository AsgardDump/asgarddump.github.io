#pragma once 
#include <ABP_VehiclePassenger_Structs.h>
 
 
 
// DynamicClass ABP_VehiclePassenger.ABP_VehiclePassenger_C
// Size: 0x2AB0(Inherited: 0xAD0) 
struct UABP_VehiclePassenger_C : public UThirdPersonAnimInstance
{
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace_4;  // 0xAD0(0x20)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace_3;  // 0xAF0(0x20)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace_4;  // 0xB10(0x20)
	struct FAnimNode_BoneDrivenController AnimGraphNode_BoneDrivenController_2;  // 0xB30(0x118)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_6;  // 0xC48(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_5;  // 0xD50(0x108)
	char pad_3672[8];  // 0xE58(0x8)
	struct FAnimNode_TwoBoneIK AnimGraphNode_TwoBoneIK_4;  // 0xE60(0x1E0)
	struct FAnimNode_SequenceEvaluator AnimGraphNode_SequenceEvaluator_3;  // 0x1040(0x50)
	struct FAnimNode_PoseDriver AnimGraphNode_PoseDriver_2;  // 0x1090(0x168)
	struct FAnimNode_PoseDriver AnimGraphNode_PoseDriver;  // 0x11F8(0x168)
	struct FAnimNode_TwoBoneIK AnimGraphNode_TwoBoneIK_3;  // 0x1360(0x1E0)
	struct FAnimNode_Root AnimGraphNode_Root;  // 0x1540(0x30)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_4;  // 0x1570(0x108)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace_3;  // 0x1678(0x20)
	char pad_5784[8];  // 0x1698(0x8)
	struct FAnimNode_TwoBoneIK AnimGraphNode_TwoBoneIK_2;  // 0x16A0(0x1E0)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer;  // 0x1880(0x80)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace_2;  // 0x1900(0x20)
	struct FAnimNode_TwoBoneIK AnimGraphNode_TwoBoneIK;  // 0x1920(0x1E0)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_3;  // 0x1B00(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_2;  // 0x1C08(0x108)
	struct FAnimNode_BoneDrivenController AnimGraphNode_BoneDrivenController;  // 0x1D10(0x118)
	struct FAnimNode_RotationOffsetBlendSpace AnimGraphNode_RotationOffsetBlendSpace_3;  // 0x1E28(0x190)
	struct FAnimNode_RotationOffsetBlendSpace AnimGraphNode_RotationOffsetBlendSpace_2;  // 0x1FB8(0x190)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace_2;  // 0x2148(0x20)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone;  // 0x2168(0x108)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace;  // 0x2270(0x20)
	struct FAnimNode_BlendListByEnum AnimGraphNode_BlendListByEnum;  // 0x2290(0xB0)
	struct FAnimNode_RefPose AnimGraphNode_LocalRefPose_2;  // 0x2340(0x18)
	struct FAnimNode_TwoWayBlend AnimGraphNode_TwoWayBlend;  // 0x2358(0xC8)
	struct FAnimNode_RefPose AnimGraphNode_LocalRefPose;  // 0x2420(0x18)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace;  // 0x2438(0x20)
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool_2;  // 0x2458(0xA0)
	struct FAnimNode_SequenceEvaluator AnimGraphNode_SequenceEvaluator_2;  // 0x24F8(0x50)
	struct FAnimNode_RotationOffsetBlendSpace AnimGraphNode_RotationOffsetBlendSpace;  // 0x2548(0x190)
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool;  // 0x26D8(0xA0)
	struct FAnimNode_SequenceEvaluator AnimGraphNode_SequenceEvaluator;  // 0x2778(0x50)
	uint8_t  VehicleSeatType_1;  // 0x27C8(0x1)
	char pad_10185[7];  // 0x27C9(0x7)
	struct FSeatAnimationStruct VehicleSeatAnimations;  // 0x27D0(0x120)
	char pad_10480_1 : 7;  // 0x28F0(0x1)
	bool bSetSeatAnimations : 1;  // 0x28F0(0x1)
	char pad_10481[7];  // 0x28F1(0x7)
	struct UAnimSequence* SeatPassengerAnimation;  // 0x28F8(0x8)
	float SeatPassengerStartTime;  // 0x2900(0x4)
	struct FRotator GenericVehicleRotation;  // 0x2904(0xC)
	float VehicleOccupantPitch;  // 0x2910(0x4)
	float VehicleOccupantYawLocked;  // 0x2914(0x4)
	float VehicleOccupantYaw;  // 0x2918(0x4)
	float NormDeltaMountedYaw;  // 0x291C(0x4)
	float NormMountedPitch;  // 0x2920(0x4)
	struct FVector GunnerOffsetLocation;  // 0x2924(0xC)
	struct FVector MountedLHandVector;  // 0x2930(0xC)
	struct FRotator MountedLHandRotator;  // 0x293C(0xC)
	struct FVector MountedRHandVector;  // 0x2948(0xC)
	struct FRotator MountedRHandRotator;  // 0x2954(0xC)
	struct AActor* SeatOwnerActor;  // 0x2960(0x8)
	struct AVehicleBase* VehicleComponent;  // 0x2968(0x8)
	float VehicleSteering;  // 0x2970(0x4)
	struct FRotator LastTickMountedRotation;  // 0x2974(0xC)
	char pad_10624_1 : 7;  // 0x2980(0x1)
	bool IsValid : 1;  // 0x2980(0x1)
	char pad_10625[7];  // 0x2981(0x7)
	struct AINSCharacter* Character;  // 0x2988(0x8)
	char pad_10640_1 : 7;  // 0x2990(0x1)
	bool bIsDead : 1;  // 0x2990(0x1)
	char pad_10641_1 : 7;  // 0x2991(0x1)
	bool bHasDeath : 1;  // 0x2991(0x1)
	char pad_10642_1 : 7;  // 0x2992(0x1)
	bool bIsMinigun : 1;  // 0x2992(0x1)
	char pad_10643[1];  // 0x2993(0x1)
	float NormMountedYaw;  // 0x2994(0x4)
	char pad_10648_1 : 7;  // 0x2998(0x1)
	bool bIsHelicopter : 1;  // 0x2998(0x1)
	char pad_10649_1 : 7;  // 0x2999(0x1)
	bool bInitialEntry : 1;  // 0x2999(0x1)
	char pad_10650[6];  // 0x299A(0x6)
	struct UVehicleSeatComponent* VehicleSeat;  // 0x29A0(0x8)
	char pad_10664_1 : 7;  // 0x29A8(0x1)
	bool bCheckTurretType : 1;  // 0x29A8(0x1)
	char pad_10665[3];  // 0x29A9(0x3)
	struct FName Temp_name_Variable;  // 0x29AC(0x8)
	float K2Node_Event_DeltaTimeX;  // 0x29B4(0x4)
	struct AINSCharacter* K2Node_DynamicCast_AsINSCharacter;  // 0x29B8(0x8)
	char pad_10688_1 : 7;  // 0x29C0(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x29C0(0x1)
	char pad_10689[7];  // 0x29C1(0x7)
	struct UVehicleSeatComponent* K2Node_CustomEvent_VehicleSeat;  // 0x29C8(0x8)
	struct AVehicleHoveringBase* K2Node_DynamicCast_AsVehicle_Hovering_Base;  // 0x29D0(0x8)
	char pad_10712_1 : 7;  // 0x29D8(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x29D8(0x1)
	char pad_10713_1 : 7;  // 0x29D9(0x1)
	bool Temp_bool_Variable : 1;  // 0x29D9(0x1)
	char pad_10714_1 : 7;  // 0x29DA(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x29DA(0x1)
	char pad_10715[1];  // 0x29DB(0x1)
	float CallFunc_BreakRotator_Roll;  // 0x29DC(0x4)
	float CallFunc_BreakRotator_Pitch;  // 0x29E0(0x4)
	float CallFunc_BreakRotator_Yaw;  // 0x29E4(0x4)
	char pad_10728_1 : 7;  // 0x29E8(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0x29E8(0x1)
	char pad_10729[7];  // 0x29E9(0x7)
	struct ABP_Firearm_GAU19_C* K2Node_DynamicCast_AsBP_Firearm_GAU19;  // 0x29F0(0x8)
	char pad_10744_1 : 7;  // 0x29F8(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x29F8(0x1)
	char pad_10745[3];  // 0x29F9(0x3)
	float CallFunc_BreakRotator_Roll_2;  // 0x29FC(0x4)
	float CallFunc_BreakRotator_Pitch_2;  // 0x2A00(0x4)
	float CallFunc_BreakRotator_Yaw_2;  // 0x2A04(0x4)
	float CallFunc_BreakRotator_Roll_3;  // 0x2A08(0x4)
	float CallFunc_BreakRotator_Pitch_3;  // 0x2A0C(0x4)
	float CallFunc_BreakRotator_Yaw_3;  // 0x2A10(0x4)
	float CallFunc_BreakRotator_Roll_4;  // 0x2A14(0x4)
	float CallFunc_BreakRotator_Pitch_4;  // 0x2A18(0x4)
	float CallFunc_BreakRotator_Yaw_4;  // 0x2A1C(0x4)
	struct FName Temp_name_Variable_2;  // 0x2A20(0x8)
	struct FName Temp_name_Variable_3;  // 0x2A28(0x8)
	struct FName K2Node_Select_Default;  // 0x2A30(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x2A38(0x10)
	struct FVector CallFunc_BreakTransform_Location;  // 0x2A48(0xC)
	struct FRotator CallFunc_BreakTransform_Rotation;  // 0x2A54(0xC)
	struct FVector CallFunc_BreakTransform_Scale;  // 0x2A60(0xC)
	struct FName Temp_name_Variable_4;  // 0x2A6C(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x2A74(0x10)
	struct FName K2Node_Select_Default_2;  // 0x2A84(0x8)
	struct FVector CallFunc_BreakTransform_Location_2;  // 0x2A8C(0xC)
	struct FRotator CallFunc_BreakTransform_Rotation_2;  // 0x2A98(0xC)
	struct FVector CallFunc_BreakTransform_Scale_2;  // 0x2AA4(0xC)

	void OnKilledInVehicle(); // Function ABP_VehiclePassenger.ABP_VehiclePassenger_C.OnKilledInVehicle
	void OnEnteredVehicle(struct UVehicleSeatComponent* bpp__VehicleSeat__pf); // Function ABP_VehiclePassenger.ABP_VehiclePassenger_C.OnEnteredVehicle
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_VehiclePassenger_AnimGraphNode_TwoWayBlend_7AC4CA9D45F21158B8F892BC36B58A69(); // Function ABP_VehiclePassenger.ABP_VehiclePassenger_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_VehiclePassenger_AnimGraphNode_TwoWayBlend_7AC4CA9D45F21158B8F892BC36B58A69
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_VehiclePassenger_AnimGraphNode_SequencePlayer_ED2055DB41B7F95D70A319898236EEC9(); // Function ABP_VehiclePassenger.ABP_VehiclePassenger_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_VehiclePassenger_AnimGraphNode_SequencePlayer_ED2055DB41B7F95D70A319898236EEC9
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_VehiclePassenger_AnimGraphNode_SequenceEvaluator_F66318064EB6985A076D7D8ECA0038F9(); // Function ABP_VehiclePassenger.ABP_VehiclePassenger_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_VehiclePassenger_AnimGraphNode_SequenceEvaluator_F66318064EB6985A076D7D8ECA0038F9
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_VehiclePassenger_AnimGraphNode_SequenceEvaluator_B653A3AA4BE81FCE0CCAA89AD158DF1A(); // Function ABP_VehiclePassenger.ABP_VehiclePassenger_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_VehiclePassenger_AnimGraphNode_SequenceEvaluator_B653A3AA4BE81FCE0CCAA89AD158DF1A
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_VehiclePassenger_AnimGraphNode_SequenceEvaluator_7F64DFDB46D9C74FD89EDAAB6B1943C5(); // Function ABP_VehiclePassenger.ABP_VehiclePassenger_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_VehiclePassenger_AnimGraphNode_SequenceEvaluator_7F64DFDB46D9C74FD89EDAAB6B1943C5
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_VehiclePassenger_AnimGraphNode_RotationOffsetBlendSpace_B43B83B2466EFA35DA01CE8C9AF31A9D(); // Function ABP_VehiclePassenger.ABP_VehiclePassenger_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_VehiclePassenger_AnimGraphNode_RotationOffsetBlendSpace_B43B83B2466EFA35DA01CE8C9AF31A9D
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_VehiclePassenger_AnimGraphNode_RotationOffsetBlendSpace_552F964E423BAAABCEDF4D84818E464C(); // Function ABP_VehiclePassenger.ABP_VehiclePassenger_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_VehiclePassenger_AnimGraphNode_RotationOffsetBlendSpace_552F964E423BAAABCEDF4D84818E464C
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_VehiclePassenger_AnimGraphNode_RotationOffsetBlendSpace_37FE29964FDADDA1BE03099DFD33F826(); // Function ABP_VehiclePassenger.ABP_VehiclePassenger_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_VehiclePassenger_AnimGraphNode_RotationOffsetBlendSpace_37FE29964FDADDA1BE03099DFD33F826
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_VehiclePassenger_AnimGraphNode_ModifyBone_DE881CD34719387273396895FB11A9B6(); // Function ABP_VehiclePassenger.ABP_VehiclePassenger_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_VehiclePassenger_AnimGraphNode_ModifyBone_DE881CD34719387273396895FB11A9B6
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_VehiclePassenger_AnimGraphNode_ModifyBone_A6EAF7C544267847272D2AAA76F9E843(); // Function ABP_VehiclePassenger.ABP_VehiclePassenger_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_VehiclePassenger_AnimGraphNode_ModifyBone_A6EAF7C544267847272D2AAA76F9E843
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_VehiclePassenger_AnimGraphNode_ModifyBone_8F415A9C49C73918A0983BBFFED6F919(); // Function ABP_VehiclePassenger.ABP_VehiclePassenger_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_VehiclePassenger_AnimGraphNode_ModifyBone_8F415A9C49C73918A0983BBFFED6F919
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_VehiclePassenger_AnimGraphNode_ModifyBone_0FA0FAA7420609F7B190328DE0713572(); // Function ABP_VehiclePassenger.ABP_VehiclePassenger_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_VehiclePassenger_AnimGraphNode_ModifyBone_0FA0FAA7420609F7B190328DE0713572
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_VehiclePassenger_AnimGraphNode_BlendListByEnum_94CDB62542D8B742076AC49B6F6EA77B(); // Function ABP_VehiclePassenger.ABP_VehiclePassenger_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_VehiclePassenger_AnimGraphNode_BlendListByEnum_94CDB62542D8B742076AC49B6F6EA77B
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_VehiclePassenger_AnimGraphNode_BlendListByBool_56D7E0D14A11B9BEC99ABC8FC62BFB6B(); // Function ABP_VehiclePassenger.ABP_VehiclePassenger_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_VehiclePassenger_AnimGraphNode_BlendListByBool_56D7E0D14A11B9BEC99ABC8FC62BFB6B
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_VehiclePassenger_AnimGraphNode_BlendListByBool_37AB98324287D816E651DA84A0F4F5F1(); // Function ABP_VehiclePassenger.ABP_VehiclePassenger_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_VehiclePassenger_AnimGraphNode_BlendListByBool_37AB98324287D816E651DA84A0F4F5F1
	void BlueprintUpdateAnimation(float bpp__DeltaTimeX__pf); // Function ABP_VehiclePassenger.ABP_VehiclePassenger_C.BlueprintUpdateAnimation
	void BlueprintInitializeAnimation(); // Function ABP_VehiclePassenger.ABP_VehiclePassenger_C.BlueprintInitializeAnimation
	void BlueprintBeginPlay(); // Function ABP_VehiclePassenger.ABP_VehiclePassenger_C.BlueprintBeginPlay
	void AnimGraph(struct FPoseLink& bpp__AnimGraph__pf); // Function ABP_VehiclePassenger.ABP_VehiclePassenger_C.AnimGraph
	void OnVehicleSeatChangeDelegate__DelegateSignature(struct UVehicleSeatComponent* bpp__VehicleSeat__pf); // DelegateFunction ABP_VehiclePassenger.ABP_VehiclePassenger_C.OnVehicleSeatChangeDelegate__DelegateSignature
	void OnKilledInVehicleSeatDelegate__DelegateSignature(); // DelegateFunction ABP_VehiclePassenger.ABP_VehiclePassenger_C.OnKilledInVehicleSeatDelegate__DelegateSignature
}; 



