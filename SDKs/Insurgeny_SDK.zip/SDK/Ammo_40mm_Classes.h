#pragma once 
#include <Ammo_40mm_Structs.h>
 
 
 
// DynamicClass Ammo_40mm.Ammo_40mm_C
// Size: 0x2C8(Inherited: 0x2C8) 
struct UAmmo_40mm_C : public UAmmoTypeBallistic
{

}; 



