#pragma once 
#include <AmmoContainer_12GAKSGShellsSubContainers_Structs.h>
 
 
 
// BlueprintGeneratedClass AmmoContainer_12GAKSGShellsSubContainers.AmmoContainer_12GAKSGShellsSubContainers_C
// Size: 0x180(Inherited: 0x180) 
struct UAmmoContainer_12GAKSGShellsSubContainers_C : public UAmmoContainerWithSubContainers
{

}; 



