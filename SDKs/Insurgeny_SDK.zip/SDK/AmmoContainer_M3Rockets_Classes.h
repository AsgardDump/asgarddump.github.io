#pragma once 
#include <AmmoContainer_M3Rockets_Structs.h>
 
 
 
// BlueprintGeneratedClass AmmoContainer_M3Rockets.AmmoContainer_M3Rockets_C
// Size: 0x170(Inherited: 0x170) 
struct UAmmoContainer_M3Rockets_C : public UAmmoContainer
{

}; 



