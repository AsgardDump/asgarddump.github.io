#pragma once 
#include <AmmoContainer_35mmCaselessSmoke_Structs.h>
 
 
 
// BlueprintGeneratedClass AmmoContainer_35mmCaselessSmoke.AmmoContainer_35mmCaselessSmoke_C
// Size: 0x170(Inherited: 0x170) 
struct UAmmoContainer_35mmCaselessSmoke_C : public UAmmoContainer
{

}; 



