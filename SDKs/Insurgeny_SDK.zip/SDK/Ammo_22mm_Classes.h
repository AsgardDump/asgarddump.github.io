#pragma once 
#include <Ammo_22mm_Structs.h>
 
 
 
// DynamicClass Ammo_22mm.Ammo_22mm_C
// Size: 0x2C8(Inherited: 0x2C8) 
struct UAmmo_22mm_C : public UAmmoTypeBallistic
{

}; 



