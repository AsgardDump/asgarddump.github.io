#pragma once 
#include <Ammo_556x45_Nato_Tracer_Structs.h>
 
 
 
// DynamicClass Ammo_556x45_Nato_Tracer.Ammo_556x45_Nato_Tracer_C
// Size: 0x2C8(Inherited: 0x2C8) 
struct UAmmo_556x45_Nato_Tracer_C : public UAmmo_556x45_Nato_C
{

}; 



