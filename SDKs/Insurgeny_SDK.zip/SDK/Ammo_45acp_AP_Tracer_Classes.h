#pragma once 
#include <Ammo_45acp_AP_Tracer_Structs.h>
 
 
 
// DynamicClass Ammo_45acp_AP_Tracer.Ammo_45acp_AP_Tracer_C
// Size: 0x2C8(Inherited: 0x2C8) 
struct UAmmo_45acp_AP_Tracer_C : public UAmmo_45acp_C
{

}; 



