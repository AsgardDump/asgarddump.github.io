#pragma once 
#include <AmmoMagazine_Browning_13RD_Structs.h>
 
 
 
// BlueprintGeneratedClass AmmoMagazine_Browning_13RD.AmmoMagazine_Browning_13RD_C
// Size: 0x178(Inherited: 0x178) 
struct UAmmoMagazine_Browning_13RD_C : public UAmmoContainerMagazine
{

}; 



