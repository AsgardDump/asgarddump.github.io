#pragma once 
#include <Ammo_Rocket_RPG7_Structs.h>
 
 
 
// DynamicClass Ammo_Rocket_RPG7.Ammo_Rocket_RPG7_C
// Size: 0x2C8(Inherited: 0x2C8) 
struct UAmmo_Rocket_RPG7_C : public UAmmoTypeBallistic
{

}; 



