#pragma once 
#include <AmmoContainer_762x54_Rounds_5R_Structs.h>
 
 
 
// BlueprintGeneratedClass AmmoContainer_762x54_Rounds_5R.AmmoContainer_762x54_Rounds_5R_C
// Size: 0x170(Inherited: 0x170) 
struct UAmmoContainer_762x54_Rounds_5R_C : public UAmmoContainer
{

}; 



