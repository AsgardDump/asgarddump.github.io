#pragma once 
#include <Ammo_556x45_Nato_Structs.h>
 
 
 
// DynamicClass Ammo_556x45_Nato.Ammo_556x45_Nato_C
// Size: 0x2C8(Inherited: 0x2C8) 
struct UAmmo_556x45_Nato_C : public UAmmoTypeBallistic
{

}; 



