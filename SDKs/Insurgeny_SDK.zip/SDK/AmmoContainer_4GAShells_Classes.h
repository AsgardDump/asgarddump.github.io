#pragma once 
#include <AmmoContainer_4GAShells_Structs.h>
 
 
 
// BlueprintGeneratedClass AmmoContainer_4GAShells.AmmoContainer_4GAShells_C
// Size: 0x170(Inherited: 0x170) 
struct UAmmoContainer_4GAShells_C : public UAmmoContainer
{

}; 



