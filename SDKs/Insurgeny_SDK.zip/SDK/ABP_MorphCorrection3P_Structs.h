#pragma once 
#include "SDK.h" 
 
 
// Function ABP_MorphCorrection3P.ABP_MorphCorrection3P_C.ExecuteUbergraph_ABP_MorphCorrection3P
// Size: 0x4(Inherited: 0x0) 
struct FExecuteUbergraph_ABP_MorphCorrection3P
{
	int32_t bpp__EntryPoint__pf;  // 0x0(0x4)

}; 
// Function ABP_MorphCorrection3P.ABP_MorphCorrection3P_C.AnimGraph
// Size: 0x20(Inherited: 0x0) 
struct FAnimGraph
{
	struct FPoseLink bpp__InPose__pf;  // 0x0(0x10)
	struct FPoseLink bpp__AnimGraph__pf;  // 0x10(0x10)

}; 
