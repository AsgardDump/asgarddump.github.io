#pragma once 
#include <AmmoContainer_40mmSmoke_Structs.h>
 
 
 
// BlueprintGeneratedClass AmmoContainer_40mmSmoke.AmmoContainer_40mmSmoke_C
// Size: 0x170(Inherited: 0x170) 
struct UAmmoContainer_40mmSmoke_C : public UAmmoContainer
{

}; 



