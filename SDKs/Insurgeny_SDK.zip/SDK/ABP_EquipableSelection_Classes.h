#pragma once 
#include <ABP_EquipableSelection_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass ABP_EquipableSelection.ABP_EquipableSelection_C
// Size: 0x2CC9(Inherited: 0x20A0) 
struct UABP_EquipableSelection_C : public UFirstPersonAnimInstance
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x20A0(0x8)
	struct FAnimNode_Root AnimGraphNode_Root;  // 0x20A8(0x30)
	struct FAnimNode_RefPose AnimGraphNode_LocalRefPose;  // 0x20D8(0x18)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_5;  // 0x20F0(0x108)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace;  // 0x21F8(0x20)
	struct FAnimNode_CopyBone AnimGraphNode_CopyBone;  // 0x2218(0xF0)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace;  // 0x2308(0x20)
	struct FAnimNode_SequenceEvaluator AnimGraphNode_SequenceEvaluator_4;  // 0x2328(0x50)
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool;  // 0x2378(0xA0)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_4;  // 0x2418(0x108)
	struct FAnimNode_SequenceEvaluator AnimGraphNode_SequenceEvaluator_3;  // 0x2520(0x50)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_3;  // 0x2570(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_2;  // 0x2678(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone;  // 0x2780(0x108)
	struct FAnimNode_ApplyAdditive AnimGraphNode_ApplyAdditive;  // 0x2888(0xC8)
	struct FAnimNode_LayeredBoneBlend AnimGraphNode_LayeredBoneBlend_2;  // 0x2950(0xC0)
	struct FAnimNode_SequenceEvaluator AnimGraphNode_SequenceEvaluator_2;  // 0x2A10(0x50)
	struct FAnimNode_SequenceEvaluator AnimGraphNode_SequenceEvaluator;  // 0x2A60(0x50)
	struct FAnimNode_LayeredBoneBlend AnimGraphNode_LayeredBoneBlend;  // 0x2AB0(0xC0)
	struct UAnimSequence* UIPoseAnimation;  // 0x2B70(0x8)
	char pad_11128_1 : 7;  // 0x2B78(0x1)
	bool UIPoseValid : 1;  // 0x2B78(0x1)
	char pad_11129[3];  // 0x2B79(0x3)
	float WeaponRotation;  // 0x2B7C(0x4)
	struct FVector SocketOffsetMenu;  // 0x2B80(0xC)
	struct FRotator WeaponRotator;  // 0x2B8C(0xC)
	char pad_11160_1 : 7;  // 0x2B98(0x1)
	bool bHasLMGDelta : 1;  // 0x2B98(0x1)
	char pad_11161[7];  // 0x2B99(0x7)
	struct UAnimSequenceBase* AmmoDeltaAnim;  // 0x2BA0(0x8)
	struct AItemEquipable* EquipableItem;  // 0x2BA8(0x8)
	char pad_11184_1 : 7;  // 0x2BB0(0x1)
	bool bRanInitialChecks : 1;  // 0x2BB0(0x1)
	char pad_11185_1 : 7;  // 0x2BB1(0x1)
	bool bScaleUp : 1;  // 0x2BB1(0x1)
	char pad_11186[2];  // 0x2BB2(0x2)
	struct FVector EquipableScale;  // 0x2BB4(0xC)
	float HasMagazineDeltaTransparent;  // 0x2BC0(0x4)
	char pad_11204[4];  // 0x2BC4(0x4)
	struct UAnimSequence* UnderbarrelShotgunSequence;  // 0x2BC8(0x8)
	char pad_11216_1 : 7;  // 0x2BD0(0x1)
	bool bHasUnderbarrelShotgun : 1;  // 0x2BD0(0x1)
	char pad_11217[7];  // 0x2BD1(0x7)
	struct TMap<UWeaponUpgradeComponent*, struct UAnimSequence*> UnderbarrelMap;  // 0x2BD8(0x50)
	struct TMap<AItemWeapon*, struct UAnimSequence*> WeaponMapM26;  // 0x2C28(0x50)
	struct TMap<AItemWeapon*, struct UAnimSequence*> WeaponMapMasterkey;  // 0x2C78(0x50)
	char pad_11464_1 : 7;  // 0x2CC8(0x1)
	bool bIsMasterkey : 1;  // 0x2CC8(0x1)

	void AnimGraph(struct FPoseLink& AnimGraph); // Function ABP_EquipableSelection.ABP_EquipableSelection_C.AnimGraph
	void CheckAmmoDelta(struct AItemEquipable* Item, struct UAnimSequence*& Sequence, bool& LMG, float& MagazineTransparency); // Function ABP_EquipableSelection.ABP_EquipableSelection_C.CheckAmmoDelta
	void BlueprintUpdateAnimation(float DeltaTimeX); // Function ABP_EquipableSelection.ABP_EquipableSelection_C.BlueprintUpdateAnimation
	void ExecuteUbergraph_ABP_EquipableSelection(int32_t EntryPoint); // Function ABP_EquipableSelection.ABP_EquipableSelection_C.ExecuteUbergraph_ABP_EquipableSelection
}; 



