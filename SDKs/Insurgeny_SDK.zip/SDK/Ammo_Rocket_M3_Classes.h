#pragma once 
#include <Ammo_Rocket_M3_Structs.h>
 
 
 
// DynamicClass Ammo_Rocket_M3.Ammo_Rocket_M3_C
// Size: 0x2C8(Inherited: 0x2C8) 
struct UAmmo_Rocket_M3_C : public UAmmo_Rocket_RPG7_C
{

}; 



