#pragma once 
#include <AmmoMagazine_Browning_Carbon_13RD__Structs.h>
 
 
 
// BlueprintGeneratedClass AmmoMagazine_Browning_Carbon_13RD_.AmmoMagazine_Browning_Carbon_13RD__C
// Size: 0x178(Inherited: 0x178) 
struct UAmmoMagazine_Browning_Carbon_13RD__C : public UAmmoMagazine_Browning_13RD_C
{

}; 



