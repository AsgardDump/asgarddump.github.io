#pragma once 
#include <AmmoMagazine_ASVAL_Carbon_Box_30RD_Structs.h>
 
 
 
// BlueprintGeneratedClass AmmoMagazine_ASVAL_Carbon_Box_30RD.AmmoMagazine_ASVAL_Carbon_Box_30RD_C
// Size: 0x178(Inherited: 0x178) 
struct UAmmoMagazine_ASVAL_Carbon_Box_30RD_C : public UAmmoMagazine_ASVALBox_30RD_C
{

}; 



