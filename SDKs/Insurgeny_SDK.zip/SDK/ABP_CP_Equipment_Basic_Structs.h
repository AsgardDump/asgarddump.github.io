#pragma once 
#include "SDK.h" 
 
 
// Function ABP_CP_Equipment_Basic.ABP_CP_Equipment_Basic_C.AnimGraph
// Size: 0x10(Inherited: 0x0) 
struct FAnimGraph
{
	struct FPoseLink bpp__AnimGraph__pf;  // 0x0(0x10)

}; 
// Function ABP_CP_Equipment_Basic.ABP_CP_Equipment_Basic_C.UpdateCharacterBoneHide
// Size: 0x10(Inherited: 0x0) 
struct FUpdateCharacterBoneHide
{
	struct UABP_Character_C* bpp__AnimInstance__pf;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bpp__Gunner__pf : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool bpp__Passenger__pf : 1;  // 0x9(0x1)
	char pad_10[6];  // 0xA(0x6)

}; 
// Function ABP_CP_Equipment_Basic.ABP_CP_Equipment_Basic_C.BlendOutMontage
// Size: 0x8(Inherited: 0x0) 
struct FBlendOutMontage
{
	struct UAnimSequenceBase* bpp__Montage__pf;  // 0x0(0x8)

}; 
// Function ABP_CP_Equipment_Basic.ABP_CP_Equipment_Basic_C.PrintHelper
// Size: 0x38(Inherited: 0x0) 
struct FPrintHelper
{
	struct FString bpp__Title__pf__const;  // 0x0(0x10)
	struct FString bpp__Input__pf__const;  // 0x10(0x10)
	float bpp__Duration__pf;  // 0x20(0x4)
	struct FLinearColor bpp__TextColor__pf;  // 0x24(0x10)
	char pad_52[4];  // 0x34(0x4)

}; 
// Function ABP_CP_Equipment_Basic.ABP_CP_Equipment_Basic_C.CalcRelativeTransform
// Size: 0x90(Inherited: 0x0) 
struct FCalcRelativeTransform
{
	struct FTransform bpp__Child__pf__const;  // 0x0(0x30)
	struct FTransform bpp__Parent__pf__const;  // 0x30(0x30)
	struct FTransform bpp__Return__pf;  // 0x60(0x30)

}; 
// Function ABP_CP_Equipment_Basic.ABP_CP_Equipment_Basic_C.MolotovRagState
// Size: 0x1(Inherited: 0x0) 
struct FMolotovRagState
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bpp__bEnabled__pf : 1;  // 0x0(0x1)

}; 
// Function ABP_CP_Equipment_Basic.ABP_CP_Equipment_Basic_C.UpdateGasMaskState
// Size: 0x1(Inherited: 0x0) 
struct FUpdateGasMaskState
{
	uint8_t  bpp__State__pf;  // 0x0(0x1)

}; 
// Function ABP_CP_Equipment_Basic.ABP_CP_Equipment_Basic_C.CombineRotatorAxis
// Size: 0xC(Inherited: 0x0) 
struct FCombineRotatorAxis
{
	float bpp__Axisx1__pfT;  // 0x0(0x4)
	float bpp__Axisx2__pfT;  // 0x4(0x4)
	float bpp__Return__pf;  // 0x8(0x4)

}; 
// Function ABP_CP_Equipment_Basic.ABP_CP_Equipment_Basic_C.DeltaRotatorAxis
// Size: 0xC(Inherited: 0x0) 
struct FDeltaRotatorAxis
{
	float bpp__Axisx1__pfT;  // 0x0(0x4)
	float bpp__Axisx2__pfT;  // 0x4(0x4)
	float bpp__Return__pf;  // 0x8(0x4)

}; 
// Function ABP_CP_Equipment_Basic.ABP_CP_Equipment_Basic_C.UpdateCharacterAnimInstance
// Size: 0x18(Inherited: 0x0) 
struct FUpdateCharacterAnimInstance
{
	struct UAnimInstance* bpp__GearAnimInstance__pf;  // 0x0(0x8)
	uint8_t  bpp__Combination__pf;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	struct FName bpp__Faction__pf;  // 0xC(0x8)
	char pad_20[4];  // 0x14(0x4)

}; 
// Function ABP_CP_Equipment_Basic.ABP_CP_Equipment_Basic_C.UpdateGasmaskReference
// Size: 0x8(Inherited: 0x0) 
struct FUpdateGasmaskReference
{
	struct ABP_Gear_GasMask_C* bpp__Gasmask__pf;  // 0x0(0x8)

}; 
// Function ABP_CP_Equipment_Basic.ABP_CP_Equipment_Basic_C.UpdateGearBoneVisibility
// Size: 0x1(Inherited: 0x0) 
struct FUpdateGearBoneVisibility
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bpp__Visibility__pf : 1;  // 0x0(0x1)

}; 
// Function ABP_CP_Equipment_Basic.ABP_CP_Equipment_Basic_C.UpdateGearCopyPoseAnim
// Size: 0x28(Inherited: 0x0) 
struct FUpdateGearCopyPoseAnim
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bpp__Enable__pf : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool bpp__bProfile__pf : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool bpp__bFemale__pf : 1;  // 0x2(0x1)
	char pad_3[5];  // 0x3(0x5)
	struct USkeletalMeshComponent* bpp__Character__pf;  // 0x8(0x8)
	struct ABP_Gear_BASE_Carrier_C* bpp__Carrier__pf;  // 0x10(0x8)
	uint8_t  bpp__Combination__pf;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)
	struct FName bpp__Faction__pf;  // 0x1C(0x8)
	char pad_36[4];  // 0x24(0x4)

}; 
// Function ABP_CP_Equipment_Basic.ABP_CP_Equipment_Basic_C.UpdateNightVisionState
// Size: 0x1(Inherited: 0x0) 
struct FUpdateNightVisionState
{
	uint8_t  bpp__State__pf;  // 0x0(0x1)

}; 
// Function ABP_CP_Equipment_Basic.ABP_CP_Equipment_Basic_C.UpdatEquipmentOnBack
// Size: 0x10(Inherited: 0x0) 
struct FUpdatEquipmentOnBack
{
	struct UINSSkeletalMeshComponent* bpp__Carrier__pf;  // 0x0(0x8)
	struct AINSSoldier* bpp__Soldier__pf;  // 0x8(0x8)

}; 
