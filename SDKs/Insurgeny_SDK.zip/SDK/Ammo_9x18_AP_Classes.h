#pragma once 
#include <Ammo_9x18_AP_Structs.h>
 
 
 
// DynamicClass Ammo_9x18_AP.Ammo_9x18_AP_C
// Size: 0x2C8(Inherited: 0x2C8) 
struct UAmmo_9x18_AP_C : public UAmmo_9x18_C
{

}; 



