#pragma once 
#include <AmmoMagazine_AK74_Whiteout_Box_30RD_Structs.h>
 
 
 
// BlueprintGeneratedClass AmmoMagazine_AK74_Whiteout_Box_30RD.AmmoMagazine_AK74_Whiteout_Box_30RD_C
// Size: 0x178(Inherited: 0x178) 
struct UAmmoMagazine_AK74_Whiteout_Box_30RD_C : public UAmmoMagazine_AK74Box_30RD_C
{

}; 



