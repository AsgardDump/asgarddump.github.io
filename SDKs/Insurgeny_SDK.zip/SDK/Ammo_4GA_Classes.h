#pragma once 
#include <Ammo_4GA_Structs.h>
 
 
 
// DynamicClass Ammo_4GA.Ammo_4GA_C
// Size: 0x2C8(Inherited: 0x2C8) 
struct UAmmo_4GA_C : public UAmmoTypeBallistic
{

}; 



