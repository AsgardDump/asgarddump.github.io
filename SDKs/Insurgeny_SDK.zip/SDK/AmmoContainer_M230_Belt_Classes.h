#pragma once 
#include <AmmoContainer_M230_Belt_Structs.h>
 
 
 
// BlueprintGeneratedClass AmmoContainer_M230_Belt.AmmoContainer_M230_Belt_C
// Size: 0x178(Inherited: 0x178) 
struct UAmmoContainer_M230_Belt_C : public UAmmoContainerMagazine
{

}; 



