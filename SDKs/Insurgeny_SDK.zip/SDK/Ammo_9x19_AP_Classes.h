#pragma once 
#include <Ammo_9x19_AP_Structs.h>
 
 
 
// DynamicClass Ammo_9x19_AP.Ammo_9x19_AP_C
// Size: 0x2C8(Inherited: 0x2C8) 
struct UAmmo_9x19_AP_C : public UAmmo_9x19_C
{

}; 



