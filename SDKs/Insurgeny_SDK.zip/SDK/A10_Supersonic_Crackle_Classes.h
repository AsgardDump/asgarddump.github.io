#pragma once 
#include <A10_Supersonic_Crackle_Structs.h>
 
 
 
// DynamicClass A10_Supersonic_Crackle.A10_Supersonic_Crackle_C
// Size: 0x260(Inherited: 0x220) 
struct AA10_Supersonic_Crackle_C : public AActor
{
	struct UINSAudioComponent* CrackleAudioComponent;  // 0x220(0x8)
	struct USplineComponent* Spline;  // 0x228(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x230(0x8)
	struct FVector A10LocationOnFiring;  // 0x238(0xC)
	struct FVector StartStrafeLocation;  // 0x244(0xC)
	float CrackleSplineLength;  // 0x250(0x4)
	struct FVector EndStrafeLocation;  // 0x254(0xC)

	void OnBeginFiring(struct AAircraftStrafing* bpp__Aircraft__pf); // Function A10_Supersonic_Crackle.A10_Supersonic_Crackle_C.OnBeginFiring
}; 



