#pragma once 
#include <AmmoMagazine_AK_RedDark_Drum_50RD_Structs.h>
 
 
 
// BlueprintGeneratedClass AmmoMagazine_AK_RedDark_Drum_50RD.AmmoMagazine_AK_RedDark_Drum_50RD_C
// Size: 0x178(Inherited: 0x178) 
struct UAmmoMagazine_AK_RedDark_Drum_50RD_C : public UAmmoMagazine_AKDrum_50RD_C
{

}; 



