#pragma once 
#include <AmmoContainer_40mmHE_Structs.h>
 
 
 
// BlueprintGeneratedClass AmmoContainer_40mmHE.AmmoContainer_40mmHE_C
// Size: 0x170(Inherited: 0x170) 
struct UAmmoContainer_40mmHE_C : public UAmmoContainer
{

}; 



