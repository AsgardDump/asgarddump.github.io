#pragma once 
#include <AmmoMagazine_AKAlpha_UrbanDigital_Box_35RD_Structs.h>
 
 
 
// BlueprintGeneratedClass AmmoMagazine_AKAlpha_UrbanDigital_Box_35RD.AmmoMagazine_AKAlpha_UrbanDigital_Box_35RD_C
// Size: 0x178(Inherited: 0x178) 
struct UAmmoMagazine_AKAlpha_UrbanDigital_Box_35RD_C : public UAmmoMagazine_AKAlphaBox_35RD_C
{

}; 



