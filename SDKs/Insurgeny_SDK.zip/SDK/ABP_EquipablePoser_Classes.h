#pragma once 
#include <ABP_EquipablePoser_Structs.h>
 
 
 
// DynamicClass ABP_EquipablePoser.ABP_EquipablePoser_C
// Size: 0x470(Inherited: 0x2C0) 
struct UABP_EquipablePoser_C : public UAnimInstance
{
	struct FAnimNode_Root AnimGraphNode_Root;  // 0x2B8(0x30)
	struct FAnimNode_ApplyAdditive AnimGraphNode_ApplyAdditive;  // 0x2E8(0xC8)
	struct FAnimNode_SequenceEvaluator AnimGraphNode_SequenceEvaluator_2;  // 0x3B0(0x50)
	struct FAnimNode_SequenceEvaluator AnimGraphNode_SequenceEvaluator;  // 0x400(0x50)
	float NewVar_1;  // 0x450(0x4)
	struct UAnimSequence* NewVar_2;  // 0x458(0x8)
	struct ABP_EquipablePoser_C* K2Node_DynamicCast_AsBP_Equipable_Poser;  // 0x460(0x8)
	char pad_1132_1 : 7;  // 0x46C(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x468(0x1)
	float K2Node_Event_DeltaTimeX;  // 0x46C(0x4)

	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_EquipablePoser_AnimGraphNode_SequenceEvaluator_0CD30C19418552F98CDF16BA2C63137F(); // Function ABP_EquipablePoser.ABP_EquipablePoser_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_EquipablePoser_AnimGraphNode_SequenceEvaluator_0CD30C19418552F98CDF16BA2C63137F
	void BlueprintUpdateAnimation(float bpp__DeltaTimeX__pf); // Function ABP_EquipablePoser.ABP_EquipablePoser_C.BlueprintUpdateAnimation
	void AnimGraph(struct FPoseLink& bpp__AnimGraph__pf); // Function ABP_EquipablePoser.ABP_EquipablePoser_C.AnimGraph
}; 



