#pragma once 
#include <ABP_CP_Equipment_Basic_Structs.h>
 
 
 
// DynamicClass ABP_CP_Equipment_Basic.ABP_CP_Equipment_Basic_C
// Size: 0xCC0(Inherited: 0x2C0) 
struct UABP_CP_Equipment_Basic_C : public UAnimInstance
{
	struct FAnimNode_Root AnimGraphNode_Root;  // 0x2C0(0x30)
	struct FAnimNode_CopyPoseFromMesh AnimGraphNode_CopyPoseFromMesh;  // 0x2F0(0x1D8)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace;  // 0x4C8(0x20)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace;  // 0x4E8(0x20)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_7;  // 0x508(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_6;  // 0x610(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_5;  // 0x718(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_4;  // 0x820(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_3;  // 0x928(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_2;  // 0xA30(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone;  // 0xB38(0x108)
	char pad_3136_1 : 7;  // 0xC40(0x1)
	bool bPoncho : 1;  // 0xC40(0x1)
	char pad_3137[7];  // 0xC41(0x7)
	struct UAnimInstance* K2Node_Event_GearAnimInstance;  // 0xC48(0x8)
	uint8_t  K2Node_Event_Combination_2;  // 0xC50(0x1)
	char pad_3153[3];  // 0xC51(0x3)
	struct FName K2Node_Event_Faction_2;  // 0xC54(0x8)
	char pad_3164_1 : 7;  // 0xC5C(0x1)
	bool K2Node_Event_Enable : 1;  // 0xC5C(0x1)
	char pad_3165_1 : 7;  // 0xC5D(0x1)
	bool K2Node_Event_bProfile : 1;  // 0xC5D(0x1)
	char pad_3166_1 : 7;  // 0xC5E(0x1)
	bool K2Node_Event_bFemale : 1;  // 0xC5E(0x1)
	char pad_3167[1];  // 0xC5F(0x1)
	struct USkeletalMeshComponent* K2Node_Event_Character;  // 0xC60(0x8)
	struct ABP_Gear_BASE_Carrier_C* K2Node_Event_Carrier_2;  // 0xC68(0x8)
	uint8_t  K2Node_Event_Combination;  // 0xC70(0x1)
	char pad_3185[3];  // 0xC71(0x3)
	struct FName K2Node_Event_Faction;  // 0xC74(0x8)
	char pad_3196[4];  // 0xC7C(0x4)
	struct UINSSkeletalMeshComponent* K2Node_Event_Carrier;  // 0xC80(0x8)
	struct AINSSoldier* K2Node_Event_Soldier;  // 0xC88(0x8)
	struct UAnimSequenceBase* K2Node_Event_Montage;  // 0xC90(0x8)
	uint8_t  K2Node_Event_State_2;  // 0xC98(0x1)
	uint8_t  K2Node_Event_State;  // 0xC99(0x1)
	char pad_3226_1 : 7;  // 0xC9A(0x1)
	bool K2Node_Event_bEnabled : 1;  // 0xC9A(0x1)
	char pad_3227[5];  // 0xC9B(0x5)
	struct ABP_Gear_GasMask_C* K2Node_Event_Gasmask;  // 0xCA0(0x8)
	char pad_3240_1 : 7;  // 0xCA8(0x1)
	bool K2Node_Event_Visibility : 1;  // 0xCA8(0x1)
	char pad_3241[7];  // 0xCA9(0x7)
	struct UABP_Character_C* K2Node_Event_AnimInstance;  // 0xCB0(0x8)
	char pad_3256_1 : 7;  // 0xCB8(0x1)
	bool K2Node_Event_Gunner : 1;  // 0xCB8(0x1)
	char pad_3257_1 : 7;  // 0xCB9(0x1)
	bool K2Node_Event_Passenger : 1;  // 0xCB9(0x1)
	char pad_3258[6];  // 0xCBA(0x6)

	void UpdatEquipmentOnBack(struct UINSSkeletalMeshComponent* bpp__Carrier__pf, struct AINSSoldier* bpp__Soldier__pf); // Function ABP_CP_Equipment_Basic.ABP_CP_Equipment_Basic_C.UpdatEquipmentOnBack
	void UpdateNightVisionState(uint8_t  bpp__State__pf); // Function ABP_CP_Equipment_Basic.ABP_CP_Equipment_Basic_C.UpdateNightVisionState
	void UpdateInsurgentNVGState(); // Function ABP_CP_Equipment_Basic.ABP_CP_Equipment_Basic_C.UpdateInsurgentNVGState
	void UpdateGearCopyPoseAnim(bool bpp__Enable__pf, bool bpp__bProfile__pf, bool bpp__bFemale__pf, struct USkeletalMeshComponent* bpp__Character__pf, struct ABP_Gear_BASE_Carrier_C* bpp__Carrier__pf, uint8_t  bpp__Combination__pf, struct FName bpp__Faction__pf); // Function ABP_CP_Equipment_Basic.ABP_CP_Equipment_Basic_C.UpdateGearCopyPoseAnim
	void UpdateGearBoneVisibility(bool bpp__Visibility__pf); // Function ABP_CP_Equipment_Basic.ABP_CP_Equipment_Basic_C.UpdateGearBoneVisibility
	void UpdateGasMaskState(uint8_t  bpp__State__pf); // Function ABP_CP_Equipment_Basic.ABP_CP_Equipment_Basic_C.UpdateGasMaskState
	void UpdateGasmaskReference(struct ABP_Gear_GasMask_C* bpp__Gasmask__pf); // Function ABP_CP_Equipment_Basic.ABP_CP_Equipment_Basic_C.UpdateGasmaskReference
	void UpdateCharacterBoneHide(struct UABP_Character_C* bpp__AnimInstance__pf, bool bpp__Gunner__pf, bool bpp__Passenger__pf); // Function ABP_CP_Equipment_Basic.ABP_CP_Equipment_Basic_C.UpdateCharacterBoneHide
	void UpdateCharacterAnimInstance(struct UAnimInstance* bpp__GearAnimInstance__pf, uint8_t  bpp__Combination__pf, struct FName bpp__Faction__pf); // Function ABP_CP_Equipment_Basic.ABP_CP_Equipment_Basic_C.UpdateCharacterAnimInstance
	void ResetEquipmentPhysics(); // Function ABP_CP_Equipment_Basic.ABP_CP_Equipment_Basic_C.ResetEquipmentPhysics
	void PrintHelper(struct FString bpp__Title__pf__const, struct FString bpp__Input__pf__const, float bpp__Duration__pf, struct FLinearColor bpp__TextColor__pf); // Function ABP_CP_Equipment_Basic.ABP_CP_Equipment_Basic_C.PrintHelper
	void NewFunction_1(); // Function ABP_CP_Equipment_Basic.ABP_CP_Equipment_Basic_C.NewFunction_1
	void MolotovRagState(bool bpp__bEnabled__pf); // Function ABP_CP_Equipment_Basic.ABP_CP_Equipment_Basic_C.MolotovRagState
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_CP_Equipment_Basic_AnimGraphNode_ModifyBone_C5E444214C13F7E19D7549ABA1262025(); // Function ABP_CP_Equipment_Basic.ABP_CP_Equipment_Basic_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_CP_Equipment_Basic_AnimGraphNode_ModifyBone_C5E444214C13F7E19D7549ABA1262025
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_CP_Equipment_Basic_AnimGraphNode_ModifyBone_944FFC694E937AD467CFF6AE5EC087D8(); // Function ABP_CP_Equipment_Basic.ABP_CP_Equipment_Basic_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_CP_Equipment_Basic_AnimGraphNode_ModifyBone_944FFC694E937AD467CFF6AE5EC087D8
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_CP_Equipment_Basic_AnimGraphNode_ModifyBone_406E312442195B816F5249BA97E71202(); // Function ABP_CP_Equipment_Basic.ABP_CP_Equipment_Basic_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_CP_Equipment_Basic_AnimGraphNode_ModifyBone_406E312442195B816F5249BA97E71202
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_CP_Equipment_Basic_AnimGraphNode_ModifyBone_35FE35F54811085528D13A9E49F5CF3A(); // Function ABP_CP_Equipment_Basic.ABP_CP_Equipment_Basic_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_CP_Equipment_Basic_AnimGraphNode_ModifyBone_35FE35F54811085528D13A9E49F5CF3A
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_CP_Equipment_Basic_AnimGraphNode_ModifyBone_286CAF344E7B44798FDF339070EA5D18(); // Function ABP_CP_Equipment_Basic.ABP_CP_Equipment_Basic_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_CP_Equipment_Basic_AnimGraphNode_ModifyBone_286CAF344E7B44798FDF339070EA5D18
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_CP_Equipment_Basic_AnimGraphNode_ModifyBone_223DF0D34E572BF9E00083B998AAF2A5(); // Function ABP_CP_Equipment_Basic.ABP_CP_Equipment_Basic_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_CP_Equipment_Basic_AnimGraphNode_ModifyBone_223DF0D34E572BF9E00083B998AAF2A5
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_CP_Equipment_Basic_AnimGraphNode_ModifyBone_169062AD443F4A0693419384E9CA5067(); // Function ABP_CP_Equipment_Basic.ABP_CP_Equipment_Basic_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_CP_Equipment_Basic_AnimGraphNode_ModifyBone_169062AD443F4A0693419384E9CA5067
	void DeltaRotatorAxis(float bpp__Axisx1__pfT, float bpp__Axisx2__pfT, float& bpp__Return__pf); // Function ABP_CP_Equipment_Basic.ABP_CP_Equipment_Basic_C.DeltaRotatorAxis
	void CombineRotatorAxis(float bpp__Axisx1__pfT, float bpp__Axisx2__pfT, float& bpp__Return__pf); // Function ABP_CP_Equipment_Basic.ABP_CP_Equipment_Basic_C.CombineRotatorAxis
	void CalcRelativeTransform(struct FTransform& bpp__Child__pf__const, struct FTransform& bpp__Parent__pf__const, struct FTransform& bpp__Return__pf); // Function ABP_CP_Equipment_Basic.ABP_CP_Equipment_Basic_C.CalcRelativeTransform
	void BlendOutMontage(struct UAnimSequenceBase* bpp__Montage__pf); // Function ABP_CP_Equipment_Basic.ABP_CP_Equipment_Basic_C.BlendOutMontage
	void AnimGraph(struct FPoseLink& bpp__AnimGraph__pf); // Function ABP_CP_Equipment_Basic.ABP_CP_Equipment_Basic_C.AnimGraph
}; 



