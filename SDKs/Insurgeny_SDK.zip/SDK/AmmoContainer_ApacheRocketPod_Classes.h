#pragma once 
#include <AmmoContainer_ApacheRocketPod_Structs.h>
 
 
 
// BlueprintGeneratedClass AmmoContainer_ApacheRocketPod.AmmoContainer_ApacheRocketPod_C
// Size: 0x178(Inherited: 0x178) 
struct UAmmoContainer_ApacheRocketPod_C : public UAmmoContainerMagazine
{

}; 



