#pragma once 
#include <Ammo_58x42_Tracer_Structs.h>
 
 
 
// DynamicClass Ammo_58x42_Tracer.Ammo_58x42_Tracer_C
// Size: 0x2C8(Inherited: 0x2C8) 
struct UAmmo_58x42_Tracer_C : public UAmmo_545x39_C
{

}; 



