#pragma once 
#include "SDK.h" 
 
 
// Function ABP_PP_VIP.ABP_PP_VIP_C.AnimGraph
// Size: 0x20(Inherited: 0x0) 
struct FAnimGraph
{
	struct FPoseLink bpp__InPose__pf;  // 0x0(0x10)
	struct FPoseLink bpp__AnimGraph__pf;  // 0x10(0x10)

}; 
// Function ABP_PP_VIP.ABP_PP_VIP_C.ExecuteUbergraph_ABP_PP_VIP
// Size: 0x4(Inherited: 0x0) 
struct FExecuteUbergraph_ABP_PP_VIP
{
	int32_t bpp__EntryPoint__pf;  // 0x0(0x4)

}; 
