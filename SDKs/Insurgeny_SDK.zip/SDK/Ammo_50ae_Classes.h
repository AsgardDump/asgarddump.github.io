#pragma once 
#include <Ammo_50ae_Structs.h>
 
 
 
// DynamicClass Ammo_50ae.Ammo_50ae_C
// Size: 0x2C8(Inherited: 0x2C8) 
struct UAmmo_50ae_C : public UAmmoTypeBallistic
{

}; 



