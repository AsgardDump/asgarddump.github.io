#pragma once 
#include <ABP_CharacterKitSelection_Structs.h>
 
 
 
// DynamicClass ABP_CharacterKitSelection.ABP_CharacterKitSelection_C
// Size: 0x36A0(Inherited: 0x2C0) 
struct UABP_CharacterKitSelection_C : public UAnimInstance
{
	struct FAnimNode_Root AnimGraphNode_Root;  // 0x2C0(0x30)
	struct FAnimNode_LinkedAnimGraph AnimGraphNode_LinkedAnimGraph;  // 0x2F0(0xA0)
	struct FAnimNode_TwoBoneIK AnimGraphNode_TwoBoneIK_4;  // 0x390(0x1E0)
	struct FAnimNode_TwoBoneIK AnimGraphNode_TwoBoneIK_3;  // 0x570(0x1E0)
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose;  // 0x750(0x158)
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool_4;  // 0x8A8(0xA0)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_2;  // 0x948(0x28)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose;  // 0x970(0x28)
	struct FAnimNode_LayeredBoneBlend AnimGraphNode_LayeredBoneBlend_6;  // 0x998(0xC0)
	struct FAnimNode_LayeredBoneBlend AnimGraphNode_LayeredBoneBlend_5;  // 0xA58(0xC0)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_8;  // 0xB18(0x108)
	struct FAnimNode_LayeredBoneBlend AnimGraphNode_LayeredBoneBlend_4;  // 0xC20(0xC0)
	struct FAnimNode_SequenceEvaluator AnimGraphNode_SequenceEvaluator_6;  // 0xCE0(0x50)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace_4;  // 0xD30(0x20)
	struct FAnimNode_RotateRootBone AnimGraphNode_RotateRootBone_2;  // 0xD50(0xA0)
	struct FAnimNode_LayeredBoneBlend AnimGraphNode_LayeredBoneBlend_3;  // 0xDF0(0xC0)
	struct FAnimNode_RefPose AnimGraphNode_LocalRefPose;  // 0xEB0(0x18)
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool_3;  // 0xEC8(0xA0)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_3;  // 0xF68(0x80)
	struct FAnimNode_RotateRootBone AnimGraphNode_RotateRootBone;  // 0xFE8(0xA0)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_7;  // 0x1088(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_6;  // 0x1190(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_5;  // 0x1298(0x108)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace_3;  // 0x13A0(0x20)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace_4;  // 0x13C0(0x20)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_4;  // 0x13E0(0x108)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace_2;  // 0x14E8(0x20)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace_3;  // 0x1508(0x20)
	struct FAnimNode_SequenceEvaluator AnimGraphNode_SequenceEvaluator_5;  // 0x1528(0x50)
	struct FAnimNode_LayeredBoneBlend AnimGraphNode_LayeredBoneBlend_2;  // 0x1578(0xC0)
	struct FAnimNode_LayeredBoneBlend AnimGraphNode_LayeredBoneBlend;  // 0x1638(0xC0)
	struct FAnimNode_SequenceEvaluator AnimGraphNode_SequenceEvaluator_4;  // 0x16F8(0x50)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_2;  // 0x1748(0x80)
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool_2;  // 0x17C8(0xA0)
	struct FAnimNode_SequenceEvaluator AnimGraphNode_SequenceEvaluator_3;  // 0x1868(0x50)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_3;  // 0x18B8(0x108)
	struct FAnimNode_RotationOffsetBlendSpace AnimGraphNode_RotationOffsetBlendSpace;  // 0x19C0(0x190)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace_2;  // 0x1B50(0x20)
	struct FAnimNode_TwoBoneIK AnimGraphNode_TwoBoneIK_2;  // 0x1B70(0x1E0)
	struct FAnimNode_CopyBone AnimGraphNode_CopyBone_2;  // 0x1D50(0xF0)
	struct FAnimNode_TwoBoneIK AnimGraphNode_TwoBoneIK;  // 0x1E40(0x1E0)
	struct FAnimNode_CopyBone AnimGraphNode_CopyBone;  // 0x2020(0xF0)
	struct FAnimNode_Slot AnimGraphNode_Slot_2;  // 0x2110(0x48)
	struct FAnimNode_Slot AnimGraphNode_Slot;  // 0x2158(0x48)
	struct FAnimNode_PoseDriver AnimGraphNode_PoseDriver_2;  // 0x21A0(0x168)
	struct FAnimNode_PoseDriver AnimGraphNode_PoseDriver;  // 0x2308(0x168)
	struct FAnimNode_ApplyAdditive AnimGraphNode_ApplyAdditive;  // 0x2470(0xC8)
	struct FAnimNode_BlendListByEnum AnimGraphNode_BlendListByEnum_2;  // 0x2538(0xB0)
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool;  // 0x25E8(0xA0)
	struct FAnimNode_BlendListByEnum AnimGraphNode_BlendListByEnum;  // 0x2688(0xB0)
	struct FAnimNode_RefPose AnimGraphNode_IdentityPose_2;  // 0x2738(0x18)
	struct FAnimNode_RefPose AnimGraphNode_IdentityPose;  // 0x2750(0x18)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_2;  // 0x2768(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone;  // 0x2870(0x108)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace;  // 0x2978(0x20)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace;  // 0x2998(0x20)
	struct FAnimNode_SequenceEvaluator AnimGraphNode_SequenceEvaluator_2;  // 0x29B8(0x50)
	struct FAnimNode_TwoWayBlend AnimGraphNode_TwoWayBlend;  // 0x2A08(0xC8)
	struct FAnimNode_SequenceEvaluator AnimGraphNode_SequenceEvaluator;  // 0x2AD0(0x50)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer;  // 0x2B20(0x80)
	float RandomStartTime;  // 0x2BA0(0x4)
	float SequencePlayRate;  // 0x2BA4(0x4)
	float PlayerRotation;  // 0x2BA8(0x4)
	char pad_11180_1 : 7;  // 0x2BAC(0x1)
	bool bLegacySystem : 1;  // 0x2BAC(0x1)
	char pad_11181[3];  // 0x2BAD(0x3)
	float HandPoseLeftAlpha;  // 0x2BB0(0x4)
	float HandPoseRightAlpha;  // 0x2BB4(0x4)
	int32_t LastSpecial;  // 0x2BB8(0x4)
	char pad_11196[4];  // 0x2BBC(0x4)
	struct AItemBase* CurrentEquipable;  // 0x2BC0(0x8)
	float SpecialMontageTimer;  // 0x2BC8(0x4)
	float Time;  // 0x2BCC(0x4)
	struct UAnimMontage* SpecialMontage;  // 0x2BD0(0x8)
	char pad_11224_1 : 7;  // 0x2BD8(0x1)
	bool bNoAnimEquipable : 1;  // 0x2BD8(0x1)
	char pad_11225[3];  // 0x2BD9(0x3)
	struct FVector UnderbarrelVector;  // 0x2BDC(0xC)
	struct FRotator UnderbarrelRotator;  // 0x2BE8(0xC)
	char pad_11252_1 : 7;  // 0x2BF4(0x1)
	bool bHasUnderbarrel : 1;  // 0x2BF4(0x1)
	char pad_11253[3];  // 0x2BF5(0x3)
	struct UAnimSequenceBase* BaseSequence;  // 0x2BF8(0x8)
	struct FCharacterMorphMacro FacialMorphStandard;  // 0x2C00(0x8)
	struct FCharacterMorphMacro FacialMorphExtreme;  // 0x2C08(0x8)
	struct AProfileCharacter* ProfileCharacter;  // 0x2C10(0x8)
	struct UINSSkeletalMeshComponent* HeadComponent;  // 0x2C18(0x8)
	struct UCurveFloat* FacialModulationCurve;  // 0x2C20(0x8)
	float FacialCurveTime;  // 0x2C28(0x4)
	float FacialIntensity;  // 0x2C2C(0x4)
	struct FVector ItemOffset;  // 0x2C30(0xC)
	char pad_11324[4];  // 0x2C3C(0x4)
	struct UAnimSequence* HandPoseLeft;  // 0x2C40(0x8)
	struct FCharacterAnimEquipable EquipableCommon;  // 0x2C48(0x258)
	struct FCharacterAnimFirearm FirearmAnimStruct;  // 0x2EA0(0x598)
	char pad_13368_1 : 7;  // 0x3438(0x1)
	bool bHasForegrip : 1;  // 0x3438(0x1)
	char pad_13369[7];  // 0x3439(0x7)
	struct TMap<struct UAnimSequence*, struct FTransform> HandPoseTransformReference;  // 0x3440(0x50)
	float UnderbarrelOffsetAlpha;  // 0x3490(0x4)
	char pad_13460_1 : 7;  // 0x3494(0x1)
	bool bIsRifle : 1;  // 0x3494(0x1)
	char pad_13461[3];  // 0x3495(0x3)
	float ForearmTwistPositionLeft;  // 0x3498(0x4)
	float ForearmTwistPositionRight;  // 0x349C(0x4)
	char pad_13472_1 : 7;  // 0x34A0(0x1)
	bool bEnableWeightTesting : 1;  // 0x34A0(0x1)
	char pad_13473[3];  // 0x34A1(0x3)
	float InterpPlayerRotation;  // 0x34A4(0x4)
	float PelvisRotation;  // 0x34A8(0x4)
	float LastTickInterpPlayerRotation;  // 0x34AC(0x4)
	float TurnDirectionIntensityAlpha;  // 0x34B0(0x4)
	float TurnDirectionIntensityAO;  // 0x34B4(0x4)
	struct FVector ScaleGroin;  // 0x34B8(0xC)
	uint8_t  CarrierArmour;  // 0x34C4(0x1)
	char pad_13509_1 : 7;  // 0x34C5(0x1)
	bool bSecurity : 1;  // 0x34C5(0x1)
	char pad_13510[2];  // 0x34C6(0x2)
	struct TArray<struct FUISpecialSequence> RifleSpecialGroup;  // 0x34C8(0x10)
	struct TArray<struct FUISpecialSequence> PistolSpecialGroup;  // 0x34D8(0x10)
	struct TArray<struct FUISpecialSequence> UnarmedSpecialGroup;  // 0x34E8(0x10)
	float PlayerRotationPelvisInterpOffset;  // 0x34F8(0x4)
	char pad_13564[4];  // 0x34FC(0x4)
	struct AItemFirearm* CurrentFirearm;  // 0x3500(0x8)
	struct UAnimSequence* UnderbarrelSequence;  // 0x3508(0x8)
	char pad_13584_1 : 7;  // 0x3510(0x1)
	bool bUseCustomIdle : 1;  // 0x3510(0x1)
	char pad_13585[3];  // 0x3511(0x3)
	float Temp_float_Variable;  // 0x3514(0x4)
	float Temp_float_Variable_2;  // 0x3518(0x4)
	char pad_13596_1 : 7;  // 0x351C(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x351C(0x1)
	char pad_13597_1 : 7;  // 0x351D(0x1)
	bool K2Node_Event_Enable : 1;  // 0x351D(0x1)
	char pad_13598_1 : 7;  // 0x351E(0x1)
	bool K2Node_Event_bProfile : 1;  // 0x351E(0x1)
	char pad_13599_1 : 7;  // 0x351F(0x1)
	bool K2Node_Event_bFemale : 1;  // 0x351F(0x1)
	struct USkeletalMeshComponent* K2Node_Event_Character;  // 0x3520(0x8)
	struct ABP_Gear_BASE_Carrier_C* K2Node_Event_Carrier_2;  // 0x3528(0x8)
	uint8_t  K2Node_Event_Combination_2;  // 0x3530(0x1)
	char pad_13617[3];  // 0x3531(0x3)
	struct FName K2Node_Event_Faction_2;  // 0x3534(0x8)
	char pad_13628[4];  // 0x353C(0x4)
	struct UABP_Character_C* K2Node_Event_AnimInstance;  // 0x3540(0x8)
	char pad_13640_1 : 7;  // 0x3548(0x1)
	bool K2Node_Event_Gunner : 1;  // 0x3548(0x1)
	char pad_13641_1 : 7;  // 0x3549(0x1)
	bool K2Node_Event_Passenger : 1;  // 0x3549(0x1)
	char pad_13642[6];  // 0x354A(0x6)
	struct UINSSkeletalMeshComponent* K2Node_Event_Carrier;  // 0x3550(0x8)
	struct AINSSoldier* K2Node_Event_Soldier;  // 0x3558(0x8)
	struct UAnimSequenceBase* K2Node_Event_Montage;  // 0x3560(0x8)
	uint8_t  K2Node_Event_State_2;  // 0x3568(0x1)
	uint8_t  K2Node_Event_State;  // 0x3569(0x1)
	char pad_13674_1 : 7;  // 0x356A(0x1)
	bool K2Node_Event_bEnabled : 1;  // 0x356A(0x1)
	char pad_13675_1 : 7;  // 0x356B(0x1)
	bool K2Node_Event_Visibility : 1;  // 0x356B(0x1)
	char pad_13676[4];  // 0x356C(0x4)
	struct ABP_Gear_GasMask_C* K2Node_Event_Gasmask;  // 0x3570(0x8)
	float K2Node_Event_DeltaTimeX;  // 0x3578(0x4)
	char pad_13692_1 : 7;  // 0x357C(0x1)
	bool Temp_bool_Variable : 1;  // 0x357C(0x1)
	char pad_13693[3];  // 0x357D(0x3)
	int32_t Temp_int_Array_Index_Variable;  // 0x3580(0x4)
	char pad_13700_1 : 7;  // 0x3584(0x1)
	bool Temp_bool_True_if_break_was_hit_Variable : 1;  // 0x3584(0x1)
	char pad_13701[3];  // 0x3585(0x3)
	struct UAnimInstance* K2Node_Event_GearAnimInstance;  // 0x3588(0x8)
	uint8_t  K2Node_Event_Combination;  // 0x3590(0x1)
	char pad_13713[3];  // 0x3591(0x3)
	struct FName K2Node_Event_Faction;  // 0x3594(0x8)
	float Temp_float_Variable_3;  // 0x359C(0x4)
	float Temp_float_Variable_4;  // 0x35A0(0x4)
	uint8_t  Temp_byte_Variable;  // 0x35A4(0x1)
	char pad_13733[3];  // 0x35A5(0x3)
	struct AProfileCharacter* K2Node_DynamicCast_AsProfile_Character;  // 0x35A8(0x8)
	char pad_13744_1 : 7;  // 0x35B0(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x35B0(0x1)
	char pad_13745[7];  // 0x35B1(0x7)
	struct AItemWeapon* K2Node_DynamicCast_AsItem_Weapon;  // 0x35B8(0x8)
	char pad_13760_1 : 7;  // 0x35C0(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x35C0(0x1)
	char pad_13761[3];  // 0x35C1(0x3)
	float Temp_float_Variable_5;  // 0x35C4(0x4)
	float Temp_float_Variable_6;  // 0x35C8(0x4)
	float Temp_float_Variable_7;  // 0x35CC(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x35D0(0x4)
	char pad_13780[4];  // 0x35D4(0x4)
	struct UCosmeticItem* CallFunc_Array_Get_Item;  // 0x35D8(0x8)
	struct UINSSkeletalMeshComponent* CallFunc_Array_Get_Item_2;  // 0x35E0(0x8)
	struct UCC_BASE_HEAD_C* K2Node_DynamicCast_AsCC_BASE_HEAD;  // 0x35E8(0x8)
	char pad_13808_1 : 7;  // 0x35F0(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x35F0(0x1)
	char pad_13809[3];  // 0x35F1(0x3)
	float K2Node_MathExpression_ReturnValue;  // 0x35F4(0x4)
	float Temp_float_Variable_8;  // 0x35F8(0x4)
	float Temp_float_Variable_9;  // 0x35FC(0x4)
	float Temp_float_Variable_10;  // 0x3600(0x4)
	char pad_13828[4];  // 0x3604(0x4)
	struct ABP_Firearm_Base_C* K2Node_DynamicCast_AsBP_Firearm_Base;  // 0x3608(0x8)
	char pad_13840_1 : 7;  // 0x3610(0x1)
	bool K2Node_DynamicCast_bSuccess_4 : 1;  // 0x3610(0x1)
	char pad_13841[7];  // 0x3611(0x7)
	struct AItemFirearm* K2Node_DynamicCast_AsItem_Firearm;  // 0x3618(0x8)
	char pad_13856_1 : 7;  // 0x3620(0x1)
	bool K2Node_DynamicCast_bSuccess_5 : 1;  // 0x3620(0x1)
	char pad_13857[7];  // 0x3621(0x7)
	struct AItemDetonator* K2Node_DynamicCast_AsItem_Detonator;  // 0x3628(0x8)
	char pad_13872_1 : 7;  // 0x3630(0x1)
	bool K2Node_DynamicCast_bSuccess_6 : 1;  // 0x3630(0x1)
	char pad_13873_1 : 7;  // 0x3631(0x1)
	bool K2Node_SwitchEnum_CmpSuccess_2 : 1;  // 0x3631(0x1)
	char pad_13874[6];  // 0x3632(0x6)
	struct AItemGrenade* K2Node_DynamicCast_AsItem_Grenade;  // 0x3638(0x8)
	char pad_13888_1 : 7;  // 0x3640(0x1)
	bool K2Node_DynamicCast_bSuccess_7 : 1;  // 0x3640(0x1)
	char pad_13889[7];  // 0x3641(0x7)
	struct AItemMeleeWeapon* K2Node_DynamicCast_AsItem_Melee_Weapon;  // 0x3648(0x8)
	char pad_13904_1 : 7;  // 0x3650(0x1)
	bool K2Node_DynamicCast_bSuccess_8 : 1;  // 0x3650(0x1)
	char pad_13905[3];  // 0x3651(0x3)
	float Temp_float_Variable_11;  // 0x3654(0x4)
	struct AItemFirearm* K2Node_DynamicCast_AsItem_Firearm_2;  // 0x3658(0x8)
	char pad_13920_1 : 7;  // 0x3660(0x1)
	bool K2Node_DynamicCast_bSuccess_9 : 1;  // 0x3660(0x1)
	char pad_13921[3];  // 0x3661(0x3)
	float K2Node_Select_Default;  // 0x3664(0x4)
	float CallFunc_DeltaRotatorAxis_Return;  // 0x3668(0x4)
	float CallFunc_BreakVector_X;  // 0x366C(0x4)
	float CallFunc_BreakVector_Y;  // 0x3670(0x4)
	float CallFunc_BreakVector_Z;  // 0x3674(0x4)
	float CallFunc_CalcRotationAxisInterp_Return;  // 0x3678(0x4)
	float CallFunc_CalcRotationAxisInterp_Return_2;  // 0x367C(0x4)
	float CallFunc_BreakVector_X_2;  // 0x3680(0x4)
	float CallFunc_BreakVector_Y_2;  // 0x3684(0x4)
	float CallFunc_BreakVector_Z_2;  // 0x3688(0x4)
	float Temp_float_Variable_12;  // 0x368C(0x4)
	float Temp_float_Variable_13;  // 0x3690(0x4)
	float CallFunc_UpdateCurveAlpha_Return;  // 0x3694(0x4)
	float K2Node_Select_Default_2;  // 0x3698(0x4)
	float CallFunc_UpdateCurveAlpha_Return_2;  // 0x369C(0x4)

	void UpdatEquipmentOnBack(struct UINSSkeletalMeshComponent* bpp__Carrier__pf, struct AINSSoldier* bpp__Soldier__pf); // Function ABP_CharacterKitSelection.ABP_CharacterKitSelection_C.UpdatEquipmentOnBack
	void UpdateNightVisionState(uint8_t  bpp__State__pf); // Function ABP_CharacterKitSelection.ABP_CharacterKitSelection_C.UpdateNightVisionState
	void UpdateInsurgentNVGState(); // Function ABP_CharacterKitSelection.ABP_CharacterKitSelection_C.UpdateInsurgentNVGState
	void UpdateGearCopyPoseAnim(bool bpp__Enable__pf, bool bpp__bProfile__pf, bool bpp__bFemale__pf, struct USkeletalMeshComponent* bpp__Character__pf, struct ABP_Gear_BASE_Carrier_C* bpp__Carrier__pf, uint8_t  bpp__Combination__pf, struct FName bpp__Faction__pf); // Function ABP_CharacterKitSelection.ABP_CharacterKitSelection_C.UpdateGearCopyPoseAnim
	void UpdateGearBoneVisibility(bool bpp__Visibility__pf); // Function ABP_CharacterKitSelection.ABP_CharacterKitSelection_C.UpdateGearBoneVisibility
	void UpdateGasMaskState(uint8_t  bpp__State__pf); // Function ABP_CharacterKitSelection.ABP_CharacterKitSelection_C.UpdateGasMaskState
	void UpdateGasmaskReference(struct ABP_Gear_GasMask_C* bpp__Gasmask__pf); // Function ABP_CharacterKitSelection.ABP_CharacterKitSelection_C.UpdateGasmaskReference
	void UpdateEquipable(); // Function ABP_CharacterKitSelection.ABP_CharacterKitSelection_C.UpdateEquipable
	void UpdateCurveAlpha(bool bpp__Condition__pf, struct FName bpp__Curve__pf, float& bpp__Return__pf); // Function ABP_CharacterKitSelection.ABP_CharacterKitSelection_C.UpdateCurveAlpha
	void UpdateCharacterBoneHide(struct UABP_Character_C* bpp__AnimInstance__pf, bool bpp__Gunner__pf, bool bpp__Passenger__pf); // Function ABP_CharacterKitSelection.ABP_CharacterKitSelection_C.UpdateCharacterBoneHide
	void UpdateCharacterAnimInstance(struct UAnimInstance* bpp__GearAnimInstance__pf, uint8_t  bpp__Combination__pf, struct FName bpp__Faction__pf); // Function ABP_CharacterKitSelection.ABP_CharacterKitSelection_C.UpdateCharacterAnimInstance
	void StoreAnimations(struct FCharacterAnimEquipable bpp__Common__pf, struct FCharacterAnimFirearm bpp__FirearmStruct__pf, bool bpp__bFirearm__pf); // Function ABP_CharacterKitSelection.ABP_CharacterKitSelection_C.StoreAnimations
	void SetCharacterAnimation(); // Function ABP_CharacterKitSelection.ABP_CharacterKitSelection_C.SetCharacterAnimation
	void ResetEquipmentPhysics(); // Function ABP_CharacterKitSelection.ABP_CharacterKitSelection_C.ResetEquipmentPhysics
	void PlaySpecial(float bpp__SpecialIntervalTime__pf, float bpp__SpecialIntervalTimeMainMenu__pf, bool bpp__Enable__pf); // Function ABP_CharacterKitSelection.ABP_CharacterKitSelection_C.PlaySpecial
	void NewFunction_1(); // Function ABP_CharacterKitSelection.ABP_CharacterKitSelection_C.NewFunction_1
	void MolotovRagState(bool bpp__bEnabled__pf); // Function ABP_CharacterKitSelection.ABP_CharacterKitSelection_C.MolotovRagState
	void GetUnderbarrelSequence(struct UObject* bpp__Upgrade__pf, bool bpp__WeaponMount__pf, bool& bpp__ValidAnim__pf); // Function ABP_CharacterKitSelection.ABP_CharacterKitSelection_C.GetUnderbarrelSequence
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_CharacterKitSelection_AnimGraphNode_TwoWayBlend_B0E5E6524952A58A497A61A0851655F2(); // Function ABP_CharacterKitSelection.ABP_CharacterKitSelection_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_CharacterKitSelection_AnimGraphNode_TwoWayBlend_B0E5E6524952A58A497A61A0851655F2
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_CharacterKitSelection_AnimGraphNode_TwoBoneIK_AABA2DE546DFDB12F1F8FE833130FBCC(); // Function ABP_CharacterKitSelection.ABP_CharacterKitSelection_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_CharacterKitSelection_AnimGraphNode_TwoBoneIK_AABA2DE546DFDB12F1F8FE833130FBCC
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_CharacterKitSelection_AnimGraphNode_TwoBoneIK_389E3B5E4C44995B2B2AA6A5CCE82928(); // Function ABP_CharacterKitSelection.ABP_CharacterKitSelection_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_CharacterKitSelection_AnimGraphNode_TwoBoneIK_389E3B5E4C44995B2B2AA6A5CCE82928
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_CharacterKitSelection_AnimGraphNode_SequencePlayer_DB1C599048329E3CC13B23B0378BF7B7(); // Function ABP_CharacterKitSelection.ABP_CharacterKitSelection_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_CharacterKitSelection_AnimGraphNode_SequencePlayer_DB1C599048329E3CC13B23B0378BF7B7
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_CharacterKitSelection_AnimGraphNode_SequencePlayer_1175944E4C0DFFFADE8AB0A63C9644D4(); // Function ABP_CharacterKitSelection.ABP_CharacterKitSelection_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_CharacterKitSelection_AnimGraphNode_SequencePlayer_1175944E4C0DFFFADE8AB0A63C9644D4
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_CharacterKitSelection_AnimGraphNode_SequenceEvaluator_FB486CF8490B202C08B08187276E7687(); // Function ABP_CharacterKitSelection.ABP_CharacterKitSelection_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_CharacterKitSelection_AnimGraphNode_SequenceEvaluator_FB486CF8490B202C08B08187276E7687
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_CharacterKitSelection_AnimGraphNode_SequenceEvaluator_D84D7C104C7333D9FFC68EAA6088DE4B(); // Function ABP_CharacterKitSelection.ABP_CharacterKitSelection_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_CharacterKitSelection_AnimGraphNode_SequenceEvaluator_D84D7C104C7333D9FFC68EAA6088DE4B
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_CharacterKitSelection_AnimGraphNode_SequenceEvaluator_D6CE429A487BFFEC1ABD80B5641A784F(); // Function ABP_CharacterKitSelection.ABP_CharacterKitSelection_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_CharacterKitSelection_AnimGraphNode_SequenceEvaluator_D6CE429A487BFFEC1ABD80B5641A784F
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_CharacterKitSelection_AnimGraphNode_SequenceEvaluator_C22A8A6D4EA9792373F2AEA01876DDD0(); // Function ABP_CharacterKitSelection.ABP_CharacterKitSelection_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_CharacterKitSelection_AnimGraphNode_SequenceEvaluator_C22A8A6D4EA9792373F2AEA01876DDD0
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_CharacterKitSelection_AnimGraphNode_SequenceEvaluator_8FDA230240B449E2FFDC8B802A49F46B(); // Function ABP_CharacterKitSelection.ABP_CharacterKitSelection_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_CharacterKitSelection_AnimGraphNode_SequenceEvaluator_8FDA230240B449E2FFDC8B802A49F46B
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_CharacterKitSelection_AnimGraphNode_SequenceEvaluator_636357E64E241ADCD683C6AD5AD2913F(); // Function ABP_CharacterKitSelection.ABP_CharacterKitSelection_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_CharacterKitSelection_AnimGraphNode_SequenceEvaluator_636357E64E241ADCD683C6AD5AD2913F
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_CharacterKitSelection_AnimGraphNode_RotationOffsetBlendSpace_0324A2BE46CBFB79DDFB50BD6BE2DD9E(); // Function ABP_CharacterKitSelection.ABP_CharacterKitSelection_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_CharacterKitSelection_AnimGraphNode_RotationOffsetBlendSpace_0324A2BE46CBFB79DDFB50BD6BE2DD9E
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_CharacterKitSelection_AnimGraphNode_RotateRootBone_C8048DBE40DF25B3D46CC4B85CC3CE75(); // Function ABP_CharacterKitSelection.ABP_CharacterKitSelection_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_CharacterKitSelection_AnimGraphNode_RotateRootBone_C8048DBE40DF25B3D46CC4B85CC3CE75
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_CharacterKitSelection_AnimGraphNode_RotateRootBone_9044D3434C087E0EB39102AE2E33E515(); // Function ABP_CharacterKitSelection.ABP_CharacterKitSelection_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_CharacterKitSelection_AnimGraphNode_RotateRootBone_9044D3434C087E0EB39102AE2E33E515
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_CharacterKitSelection_AnimGraphNode_ModifyBone_F4B0472146EF97B96E8A5FA1838DEDCE(); // Function ABP_CharacterKitSelection.ABP_CharacterKitSelection_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_CharacterKitSelection_AnimGraphNode_ModifyBone_F4B0472146EF97B96E8A5FA1838DEDCE
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_CharacterKitSelection_AnimGraphNode_ModifyBone_EC487E15472FB122A3AB8EAC0CB05AB0(); // Function ABP_CharacterKitSelection.ABP_CharacterKitSelection_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_CharacterKitSelection_AnimGraphNode_ModifyBone_EC487E15472FB122A3AB8EAC0CB05AB0
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_CharacterKitSelection_AnimGraphNode_ModifyBone_87EF30D749ED80A2730E66B8157C96E8(); // Function ABP_CharacterKitSelection.ABP_CharacterKitSelection_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_CharacterKitSelection_AnimGraphNode_ModifyBone_87EF30D749ED80A2730E66B8157C96E8
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_CharacterKitSelection_AnimGraphNode_ModifyBone_7E40BAEE4E9A2D5B34C1FF898A5F577E(); // Function ABP_CharacterKitSelection.ABP_CharacterKitSelection_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_CharacterKitSelection_AnimGraphNode_ModifyBone_7E40BAEE4E9A2D5B34C1FF898A5F577E
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_CharacterKitSelection_AnimGraphNode_ModifyBone_5E03792A4435FEF21642F285F24D5E5E(); // Function ABP_CharacterKitSelection.ABP_CharacterKitSelection_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_CharacterKitSelection_AnimGraphNode_ModifyBone_5E03792A4435FEF21642F285F24D5E5E
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_CharacterKitSelection_AnimGraphNode_ModifyBone_3249B07342C1ED3C4A7A5884AEB07693(); // Function ABP_CharacterKitSelection.ABP_CharacterKitSelection_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_CharacterKitSelection_AnimGraphNode_ModifyBone_3249B07342C1ED3C4A7A5884AEB07693
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_CharacterKitSelection_AnimGraphNode_ModifyBone_0CEA69634752BE1E40EA7C9BE890E0BA(); // Function ABP_CharacterKitSelection.ABP_CharacterKitSelection_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_CharacterKitSelection_AnimGraphNode_ModifyBone_0CEA69634752BE1E40EA7C9BE890E0BA
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_CharacterKitSelection_AnimGraphNode_LayeredBoneBlend_E9FCD13849F170DEAD9454A1311BDF28(); // Function ABP_CharacterKitSelection.ABP_CharacterKitSelection_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_CharacterKitSelection_AnimGraphNode_LayeredBoneBlend_E9FCD13849F170DEAD9454A1311BDF28
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_CharacterKitSelection_AnimGraphNode_LayeredBoneBlend_560DE17B45F9B7CEE948B591D0D98A46(); // Function ABP_CharacterKitSelection.ABP_CharacterKitSelection_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_CharacterKitSelection_AnimGraphNode_LayeredBoneBlend_560DE17B45F9B7CEE948B591D0D98A46
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_CharacterKitSelection_AnimGraphNode_CopyBone_B5F8AF794642622405139CB4CE2FF904(); // Function ABP_CharacterKitSelection.ABP_CharacterKitSelection_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_CharacterKitSelection_AnimGraphNode_CopyBone_B5F8AF794642622405139CB4CE2FF904
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_CharacterKitSelection_AnimGraphNode_CopyBone_B3BBA0294B047BF413A3CD80891D3DA6(); // Function ABP_CharacterKitSelection.ABP_CharacterKitSelection_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_CharacterKitSelection_AnimGraphNode_CopyBone_B3BBA0294B047BF413A3CD80891D3DA6
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_CharacterKitSelection_AnimGraphNode_BlendListByEnum_744F923E4CAC3C41AC9B8DA075D80EE9(); // Function ABP_CharacterKitSelection.ABP_CharacterKitSelection_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_CharacterKitSelection_AnimGraphNode_BlendListByEnum_744F923E4CAC3C41AC9B8DA075D80EE9
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_CharacterKitSelection_AnimGraphNode_BlendListByEnum_17A5931047CCAE4C153F049B13F47C53(); // Function ABP_CharacterKitSelection.ABP_CharacterKitSelection_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_CharacterKitSelection_AnimGraphNode_BlendListByEnum_17A5931047CCAE4C153F049B13F47C53
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_CharacterKitSelection_AnimGraphNode_BlendListByBool_FBE3EA5F477507DA3A909E9EA766A0AB(); // Function ABP_CharacterKitSelection.ABP_CharacterKitSelection_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_CharacterKitSelection_AnimGraphNode_BlendListByBool_FBE3EA5F477507DA3A909E9EA766A0AB
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_CharacterKitSelection_AnimGraphNode_BlendListByBool_8F270DE945E510189607798E695BFF5D(); // Function ABP_CharacterKitSelection.ABP_CharacterKitSelection_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_CharacterKitSelection_AnimGraphNode_BlendListByBool_8F270DE945E510189607798E695BFF5D
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_CharacterKitSelection_AnimGraphNode_BlendListByBool_21188AE647A2091D42805DB3A8CAC412(); // Function ABP_CharacterKitSelection.ABP_CharacterKitSelection_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_CharacterKitSelection_AnimGraphNode_BlendListByBool_21188AE647A2091D42805DB3A8CAC412
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_CharacterKitSelection_AnimGraphNode_BlendListByBool_100EAD8C48A76AF6C0713B8B76D0B2E7(); // Function ABP_CharacterKitSelection.ABP_CharacterKitSelection_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_CharacterKitSelection_AnimGraphNode_BlendListByBool_100EAD8C48A76AF6C0713B8B76D0B2E7
	void DeltaRotatorAxis(float bpp__A__pf, float bpp__B__pf, float& bpp__Return__pf); // Function ABP_CharacterKitSelection.ABP_CharacterKitSelection_C.DeltaRotatorAxis
	void CalcUnderbarrelOffset(struct UWeaponUpgradeComponent* bpp__Upgrade__pf); // Function ABP_CharacterKitSelection.ABP_CharacterKitSelection_C.CalcUnderbarrelOffset
	void CalcRotationAxisInterp(float bpp__Original__pf, float bpp__Target__pf, float bpp__Speed__pf, float& bpp__Return__pf); // Function ABP_CharacterKitSelection.ABP_CharacterKitSelection_C.CalcRotationAxisInterp
	void CalcRelativeTransform(struct FTransform bpp__Child__pf, struct FTransform bpp__Parent__pf, struct FTransform& bpp__Transform__pf); // Function ABP_CharacterKitSelection.ABP_CharacterKitSelection_C.CalcRelativeTransform
	float CalcForearmTwistAlpha(struct USceneComponent* bpp__Mesh__pf, struct FName bpp__BoneName__pf, bool bpp__LeftHand__pf); // Function ABP_CharacterKitSelection.ABP_CharacterKitSelection_C.CalcForearmTwistAlpha
	void BlueprintUpdateAnimation(float bpp__DeltaTimeX__pf); // Function ABP_CharacterKitSelection.ABP_CharacterKitSelection_C.BlueprintUpdateAnimation
	void BlendOutMontage(struct UAnimSequenceBase* bpp__Montage__pf); // Function ABP_CharacterKitSelection.ABP_CharacterKitSelection_C.BlendOutMontage
	void AnimGraph(struct FPoseLink& bpp__AnimGraph__pf); // Function ABP_CharacterKitSelection.ABP_CharacterKitSelection_C.AnimGraph
}; 



