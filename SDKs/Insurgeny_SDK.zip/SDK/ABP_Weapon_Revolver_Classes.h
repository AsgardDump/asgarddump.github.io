#pragma once 
#include <ABP_Weapon_Revolver_Structs.h>
 
 
 
// DynamicClass ABP_Weapon_Revolver.ABP_Weapon_Revolver_C
// Size: 0x17A0(Inherited: 0x2C0) 
struct UABP_Weapon_Revolver_C : public UAnimInstance
{
	struct FAnimNode_Root AnimGraphNode_Root;  // 0x2C0(0x30)
	struct FAnimNode_LinkedInputPose AnimGraphNode_SubInput;  // 0x2F0(0x118)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace;  // 0x408(0x20)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_18;  // 0x428(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_17;  // 0x530(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_16;  // 0x638(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_15;  // 0x740(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_14;  // 0x848(0x108)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace;  // 0x950(0x20)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_13;  // 0x970(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_12;  // 0xA78(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_11;  // 0xB80(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_10;  // 0xC88(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_9;  // 0xD90(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_8;  // 0xE98(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_7;  // 0xFA0(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_6;  // 0x10A8(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_5;  // 0x11B0(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_4;  // 0x12B8(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_3;  // 0x13C0(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_2;  // 0x14C8(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone;  // 0x15D0(0x108)
	struct TArray<uint8_t > ChamberStatusArray;  // 0x16D8(0x10)
	struct TArray<float> EmptyAlphaArray;  // 0x16E8(0x10)
	struct TArray<float> FiredAlphaArray;  // 0x16F8(0x10)
	struct TArray<float> UnfiredAlphaArray;  // 0x1708(0x10)
	int32_t RoundsRemaining;  // 0x1718(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x171C(0x4)
	float K2Node_Event_State;  // 0x1720(0x4)
	char pad_5924_1 : 7;  // 0x1724(0x1)
	bool K2Node_Event_Enable : 1;  // 0x1724(0x1)
	char pad_5925_1 : 7;  // 0x1725(0x1)
	bool K2Node_Event_bEnable : 1;  // 0x1725(0x1)
	char pad_5926[2];  // 0x1726(0x2)
	struct TArray<uint8_t > K2Node_Event_Chambers;  // 0x1728(0x10)
	float K2Node_Event_DeltaTimeX;  // 0x1738(0x4)
	int32_t K2Node_Event_RemainingAmmo;  // 0x173C(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x1740(0x4)
	uint8_t  CallFunc_Array_Get_Item;  // 0x1744(0x1)
	char pad_5957[3];  // 0x1745(0x3)
	struct AINSSoldier* K2Node_DynamicCast_AsINSSoldier;  // 0x1748(0x8)
	char pad_5968_1 : 7;  // 0x1750(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x1750(0x1)
	char pad_5969[7];  // 0x1751(0x7)
	struct TScriptInterface<IWeaponAnimInterface_C> K2Node_DynamicCast_AsWeapon_Anim_Interface;  // 0x1758(0x10)
	char pad_5992_1 : 7;  // 0x1768(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x1768(0x1)
	char pad_5993[7];  // 0x1769(0x7)
	struct AItemRevolver* K2Node_DynamicCast_AsItem_Revolver;  // 0x1770(0x8)
	char pad_6008_1 : 7;  // 0x1778(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x1778(0x1)
	char pad_6009[7];  // 0x1779(0x7)
	struct AINSSoldier* K2Node_DynamicCast_AsINSSoldier_2;  // 0x1780(0x8)
	char pad_6024_1 : 7;  // 0x1788(0x1)
	bool K2Node_DynamicCast_bSuccess_4 : 1;  // 0x1788(0x1)
	char pad_6025[7];  // 0x1789(0x7)
	struct UABP_Weapon_C* K2Node_DynamicCast_AsABP_Weapon;  // 0x1790(0x8)
	char pad_6040_1 : 7;  // 0x1798(0x1)
	bool K2Node_DynamicCast_bSuccess_5 : 1;  // 0x1798(0x1)
	char pad_6041[7];  // 0x1799(0x7)

	void UpdateRevolverChamberState(struct TArray<uint8_t >& bpp__Chambers__pf__const); // Function ABP_Weapon_Revolver.ABP_Weapon_Revolver_C.UpdateRevolverChamberState
	void ToggleOpticState(bool bpp__Enable__pf); // Function ABP_Weapon_Revolver.ABP_Weapon_Revolver_C.ToggleOpticState
	void StopToggleOpticMontage(); // Function ABP_Weapon_Revolver.ABP_Weapon_Revolver_C.StopToggleOpticMontage
	void InterfaceUpdateSimulationBlend(float bpp__State__pf); // Function ABP_Weapon_Revolver.ABP_Weapon_Revolver_C.InterfaceUpdateSimulationBlend
	void ForceToggleOpticState(bool bpp__bEnable__pf); // Function ABP_Weapon_Revolver.ABP_Weapon_Revolver_C.ForceToggleOpticState
	void ForceRevolverChamberVisibility(int32_t bpp__RemainingAmmo__pf); // Function ABP_Weapon_Revolver.ABP_Weapon_Revolver_C.ForceRevolverChamberVisibility
	void ForceChamber(struct TArray<float>& bpp__Array__pf, float bpp__Value__pf__const, int32_t bpp__RemainingxAmmo__pfT); // Function ABP_Weapon_Revolver.ABP_Weapon_Revolver_C.ForceChamber
	void ExecuteUbergraph_ABP_Weapon_Revolver_1(int32_t bpp__EntryPoint__pf); // Function ABP_Weapon_Revolver.ABP_Weapon_Revolver_C.ExecuteUbergraph_ABP_Weapon_Revolver_1
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Weapon_Revolver_AnimGraphNode_ModifyBone_FA9829984A70202AE2D91EB13EEA8810(); // Function ABP_Weapon_Revolver.ABP_Weapon_Revolver_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Weapon_Revolver_AnimGraphNode_ModifyBone_FA9829984A70202AE2D91EB13EEA8810
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Weapon_Revolver_AnimGraphNode_ModifyBone_F49FA45F4414142C9E3B83ABCBE291DB(); // Function ABP_Weapon_Revolver.ABP_Weapon_Revolver_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Weapon_Revolver_AnimGraphNode_ModifyBone_F49FA45F4414142C9E3B83ABCBE291DB
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Weapon_Revolver_AnimGraphNode_ModifyBone_F20F63C54BAA3787668991B77D857787(); // Function ABP_Weapon_Revolver.ABP_Weapon_Revolver_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Weapon_Revolver_AnimGraphNode_ModifyBone_F20F63C54BAA3787668991B77D857787
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Weapon_Revolver_AnimGraphNode_ModifyBone_F04386D14C5A8CB4C3CC08A3C843A695(); // Function ABP_Weapon_Revolver.ABP_Weapon_Revolver_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Weapon_Revolver_AnimGraphNode_ModifyBone_F04386D14C5A8CB4C3CC08A3C843A695
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Weapon_Revolver_AnimGraphNode_ModifyBone_CC4ED6E4438E67EEB8347EA12BC35987(); // Function ABP_Weapon_Revolver.ABP_Weapon_Revolver_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Weapon_Revolver_AnimGraphNode_ModifyBone_CC4ED6E4438E67EEB8347EA12BC35987
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Weapon_Revolver_AnimGraphNode_ModifyBone_B6832E53435C036393424BAC3DAF72D2(); // Function ABP_Weapon_Revolver.ABP_Weapon_Revolver_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Weapon_Revolver_AnimGraphNode_ModifyBone_B6832E53435C036393424BAC3DAF72D2
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Weapon_Revolver_AnimGraphNode_ModifyBone_AD96A30741E44DE317E6DFBAD2141B74(); // Function ABP_Weapon_Revolver.ABP_Weapon_Revolver_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Weapon_Revolver_AnimGraphNode_ModifyBone_AD96A30741E44DE317E6DFBAD2141B74
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Weapon_Revolver_AnimGraphNode_ModifyBone_6ED3AC4E451DD50D38BCB2BA17D0F6C6(); // Function ABP_Weapon_Revolver.ABP_Weapon_Revolver_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Weapon_Revolver_AnimGraphNode_ModifyBone_6ED3AC4E451DD50D38BCB2BA17D0F6C6
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Weapon_Revolver_AnimGraphNode_ModifyBone_68625448476BA4A1A4E7B187B0113355(); // Function ABP_Weapon_Revolver.ABP_Weapon_Revolver_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Weapon_Revolver_AnimGraphNode_ModifyBone_68625448476BA4A1A4E7B187B0113355
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Weapon_Revolver_AnimGraphNode_ModifyBone_5C5D155744A79918856E4DBDDF96489C(); // Function ABP_Weapon_Revolver.ABP_Weapon_Revolver_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Weapon_Revolver_AnimGraphNode_ModifyBone_5C5D155744A79918856E4DBDDF96489C
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Weapon_Revolver_AnimGraphNode_ModifyBone_39A0B8BC4F6FE1FE6B19BDB39D801A27(); // Function ABP_Weapon_Revolver.ABP_Weapon_Revolver_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Weapon_Revolver_AnimGraphNode_ModifyBone_39A0B8BC4F6FE1FE6B19BDB39D801A27
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Weapon_Revolver_AnimGraphNode_ModifyBone_39902F1C4DF8C0002FE94A8323E8BF5F(); // Function ABP_Weapon_Revolver.ABP_Weapon_Revolver_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Weapon_Revolver_AnimGraphNode_ModifyBone_39902F1C4DF8C0002FE94A8323E8BF5F
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Weapon_Revolver_AnimGraphNode_ModifyBone_330C21D0422B4A9ED852DF81EBEAF7DA(); // Function ABP_Weapon_Revolver.ABP_Weapon_Revolver_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Weapon_Revolver_AnimGraphNode_ModifyBone_330C21D0422B4A9ED852DF81EBEAF7DA
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Weapon_Revolver_AnimGraphNode_ModifyBone_234AFCEF40815CB3D6DE60A7A30B8A35(); // Function ABP_Weapon_Revolver.ABP_Weapon_Revolver_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Weapon_Revolver_AnimGraphNode_ModifyBone_234AFCEF40815CB3D6DE60A7A30B8A35
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Weapon_Revolver_AnimGraphNode_ModifyBone_22086CA84DE2C2B368AF238BCD360B35(); // Function ABP_Weapon_Revolver.ABP_Weapon_Revolver_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Weapon_Revolver_AnimGraphNode_ModifyBone_22086CA84DE2C2B368AF238BCD360B35
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Weapon_Revolver_AnimGraphNode_ModifyBone_200B5B4046E81FDA7AE26BAD8A3EDC6A(); // Function ABP_Weapon_Revolver.ABP_Weapon_Revolver_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Weapon_Revolver_AnimGraphNode_ModifyBone_200B5B4046E81FDA7AE26BAD8A3EDC6A
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Weapon_Revolver_AnimGraphNode_ModifyBone_166C436F4598BA84C00E5094350D79E5(); // Function ABP_Weapon_Revolver.ABP_Weapon_Revolver_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Weapon_Revolver_AnimGraphNode_ModifyBone_166C436F4598BA84C00E5094350D79E5
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Weapon_Revolver_AnimGraphNode_ModifyBone_1625372D44486CA5A1727E8A661363EA(); // Function ABP_Weapon_Revolver.ABP_Weapon_Revolver_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Weapon_Revolver_AnimGraphNode_ModifyBone_1625372D44486CA5A1727E8A661363EA
	void BlueprintUpdateAnimation(float bpp__DeltaTimeX__pf); // Function ABP_Weapon_Revolver.ABP_Weapon_Revolver_C.BlueprintUpdateAnimation
	void BlueprintInitializeAnimation(); // Function ABP_Weapon_Revolver.ABP_Weapon_Revolver_C.BlueprintInitializeAnimation
	void AnimGraph(struct FPoseLink bpp__InPose__pf, struct FPoseLink& bpp__AnimGraph__pf); // Function ABP_Weapon_Revolver.ABP_Weapon_Revolver_C.AnimGraph
}; 



