#pragma once 
#include "SDK.h" 
 
 
// Function A10_Supersonic_Crackle.A10_Supersonic_Crackle_C.OnBeginFiring
// Size: 0x8(Inherited: 0x0) 
struct FOnBeginFiring
{
	struct AAircraftStrafing* bpp__Aircraft__pf;  // 0x0(0x8)

}; 
