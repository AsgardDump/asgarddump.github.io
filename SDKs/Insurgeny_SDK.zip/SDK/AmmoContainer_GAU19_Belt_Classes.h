#pragma once 
#include <AmmoContainer_GAU19_Belt_Structs.h>
 
 
 
// BlueprintGeneratedClass AmmoContainer_GAU19_Belt.AmmoContainer_GAU19_Belt_C
// Size: 0x178(Inherited: 0x178) 
struct UAmmoContainer_GAU19_Belt_C : public UAmmoContainerMagazine
{

}; 



