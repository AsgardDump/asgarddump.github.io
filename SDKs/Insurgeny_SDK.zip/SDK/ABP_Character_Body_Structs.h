#pragma once 
#include "SDK.h" 
 
 
// Function ABP_Character_Body.ABP_Character_Body_C.BlueprintUpdateAnimation
// Size: 0x4(Inherited: 0x0) 
struct FBlueprintUpdateAnimation
{
	float bpp__DeltaTimeX__pf;  // 0x0(0x4)

}; 
// DelegateFunction ABP_Character_Body.ABP_Character_Body_C.DelegateDoorKick__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FDelegateDoorKick__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bpp__bKickWillSucceed__pf : 1;  // 0x0(0x1)

}; 
// Function ABP_Character_Body.ABP_Character_Body_C.AnimGraph
// Size: 0x10(Inherited: 0x0) 
struct FAnimGraph
{
	struct FPoseLink bpp__AnimGraph__pf;  // 0x0(0x10)

}; 
// Function ABP_Character_Body.ABP_Character_Body_C.OnDoorKick
// Size: 0x1(Inherited: 0x0) 
struct FOnDoorKick
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bpp__bKickWillSucceed__pf : 1;  // 0x0(0x1)

}; 
