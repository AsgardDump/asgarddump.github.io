#pragma once 
#include <Ammo_9x19_Tracer_Structs.h>
 
 
 
// DynamicClass Ammo_9x19_Tracer.Ammo_9x19_Tracer_C
// Size: 0x2C8(Inherited: 0x2C8) 
struct UAmmo_9x19_Tracer_C : public UAmmoTypeBallistic
{

}; 



