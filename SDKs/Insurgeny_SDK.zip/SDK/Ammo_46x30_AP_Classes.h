#pragma once 
#include <Ammo_46x30_AP_Structs.h>
 
 
 
// DynamicClass Ammo_46x30_AP.Ammo_46x30_AP_C
// Size: 0x2C8(Inherited: 0x2C8) 
struct UAmmo_46x30_AP_C : public UAmmo_46x30_C
{

}; 



