#pragma once 
#include <AmmoMagazine_AUG_YellowAccent_Box_42RD_Structs.h>
 
 
 
// BlueprintGeneratedClass AmmoMagazine_AUG_YellowAccent_Box_42RD.AmmoMagazine_AUG_YellowAccent_Box_42RD_C
// Size: 0x178(Inherited: 0x178) 
struct UAmmoMagazine_AUG_YellowAccent_Box_42RD_C : public UAmmoMagazine_AUG_Box_42RD_C
{

}; 



