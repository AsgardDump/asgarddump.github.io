#pragma once 
#include "SDK.h" 
 
 
// DelegateFunction ABP_Weapon.ABP_Weapon_C.DelegateDoorKick__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FDelegateDoorKick__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bpp__bKickWillSucceed__pf : 1;  // 0x0(0x1)

}; 
// Function ABP_Weapon.ABP_Weapon_C.AdjustMontageRate
// Size: 0x10(Inherited: 0x0) 
struct FAdjustMontageRate
{
	struct UAnimMontage* bpp__MontageReference__pf;  // 0x0(0x8)
	float bpp__RateMultiplier__pf;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)

}; 
// DelegateFunction ABP_Weapon.ABP_Weapon_C.OnCharacterTakeDamageDelegate__DelegateSignature
// Size: 0x48(Inherited: 0x0) 
struct FOnCharacterTakeDamageDelegate__DelegateSignature
{
	struct UDamageType* bpp__DamageType__pf;  // 0x0(0x8)
	struct FNetHitReaction bpp__HitReaction__pf;  // 0x8(0x40)

}; 
// Function ABP_Weapon.ABP_Weapon_C.AttachmentUpdateOpticDelegate
// Size: 0x8(Inherited: 0x0) 
struct FAttachmentUpdateOpticDelegate
{
	int32_t bpp__LatchedMode__pf__const;  // 0x0(0x4)
	int32_t bpp__DesiredMode__pf__const;  // 0x4(0x4)

}; 
// DelegateFunction ABP_Weapon.ABP_Weapon_C.OnCycleOpticDelegate__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FOnCycleOpticDelegate__DelegateSignature
{
	int32_t bpp__LatchedMode__pf;  // 0x0(0x4)
	int32_t bpp__DesiredMode__pf;  // 0x4(0x4)

}; 
// Function ABP_Weapon.ABP_Weapon_C.BlueprintOnReloadAfterSwitchMagazine
// Size: 0x8(Inherited: 0x0) 
struct FBlueprintOnReloadAfterSwitchMagazine
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bpp__bDryReload__pf__const : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool bpp__bSingleReload__pf__const : 1;  // 0x1(0x1)
	char pad_2[2];  // 0x2(0x2)
	float bpp__RateMultiplier__pf__const;  // 0x4(0x4)

}; 
// Function ABP_Weapon.ABP_Weapon_C.AnimGraph
// Size: 0x10(Inherited: 0x0) 
struct FAnimGraph
{
	struct FPoseLink bpp__AnimGraph__pf;  // 0x0(0x10)

}; 
// Function ABP_Weapon.ABP_Weapon_C.ExecuteUbergraph_ABP_Weapon_417
// Size: 0x4(Inherited: 0x0) 
struct FExecuteUbergraph_ABP_Weapon_417
{
	int32_t bpp__EntryPoint__pf;  // 0x0(0x4)

}; 
// DelegateFunction ABP_Weapon.ABP_Weapon_C.OnUsableInteractionDelegate__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FOnUsableInteractionDelegate__DelegateSignature
{
	struct AINSSoldier* bpp__Interactor__pf;  // 0x0(0x8)
	struct AActor* bpp__InteractingActor__pf;  // 0x8(0x8)
	uint8_t  bpp__Item__pf;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function ABP_Weapon.ABP_Weapon_C.BlueprintOnSwitchMagazineInterrupt
// Size: 0x4(Inherited: 0x0) 
struct FBlueprintOnSwitchMagazineInterrupt
{
	float bpp__AnimationInterruptTime__pf__const;  // 0x0(0x4)

}; 
// Function ABP_Weapon.ABP_Weapon_C.BlueprintOnBipodDeployedStateChanged
// Size: 0x2(Inherited: 0x0) 
struct FBlueprintOnBipodDeployedStateChanged
{
	uint8_t  bpp__OldState__pf__const;  // 0x0(0x1)
	uint8_t  bpp__NewState__pf__const;  // 0x1(0x1)

}; 
// Function ABP_Weapon.ABP_Weapon_C.BlueprintOnBipodLegsStateChanged
// Size: 0x2(Inherited: 0x0) 
struct FBlueprintOnBipodLegsStateChanged
{
	uint8_t  bpp__OldState__pf__const;  // 0x0(0x1)
	uint8_t  bpp__NewState__pf__const;  // 0x1(0x1)

}; 
// Function ABP_Weapon.ABP_Weapon_C.ChangeRagPaticleState
// Size: 0x1(Inherited: 0x0) 
struct FChangeRagPaticleState
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bpp__ForceKill__pf : 1;  // 0x0(0x1)

}; 
// Function ABP_Weapon.ABP_Weapon_C.BlueprintOnCycleFiremode
// Size: 0x2(Inherited: 0x0) 
struct FBlueprintOnCycleFiremode
{
	uint8_t  bpp__OldFiremode__pf__const;  // 0x0(0x1)
	uint8_t  bpp__NewFiremode__pf__const;  // 0x1(0x1)

}; 
// Function ABP_Weapon.ABP_Weapon_C.BlueprintOnFastReload
// Size: 0x8(Inherited: 0x0) 
struct FBlueprintOnFastReload
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bpp__bDryReload__pf__const : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	float bpp__RateMultiplier__pf__const;  // 0x4(0x4)

}; 
// Function ABP_Weapon.ABP_Weapon_C.OnPlayMeleeDamage
// Size: 0x48(Inherited: 0x0) 
struct FOnPlayMeleeDamage
{
	struct UDamageType* bpp__DamagexType__pfT__const;  // 0x0(0x8)
	struct FNetHitReaction bpp__HitReaction__pf;  // 0x8(0x40)

}; 
// Function ABP_Weapon.ABP_Weapon_C.CalcRotatorInterp
// Size: 0x28(Inherited: 0x0) 
struct FCalcRotatorInterp
{
	struct FRotator bpp__Current__pf;  // 0x0(0xC)
	struct FRotator bpp__Target__pf;  // 0xC(0xC)
	float bpp__Speed__pf;  // 0x18(0x4)
	struct FRotator bpp__Output__pf;  // 0x1C(0xC)

}; 
// Function ABP_Weapon.ABP_Weapon_C.BlueprintOnFirearmFired
// Size: 0x18(Inherited: 0x0) 
struct FBlueprintOnFirearmFired
{
	struct FVector bpp__FireOrigin__pf__const;  // 0x0(0xC)
	struct FVector bpp__FireDirection__pf__const;  // 0xC(0xC)

}; 
// Function ABP_Weapon.ABP_Weapon_C.BlueprintOnGearInteracted
// Size: 0x10(Inherited: 0x0) 
struct FBlueprintOnGearInteracted
{
	struct AItemInteractableGear* bpp__GearItem__pf;  // 0x0(0x8)
	uint8_t  bpp__NewState__pf;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function ABP_Weapon.ABP_Weapon_C.OnTakeDamage
// Size: 0x48(Inherited: 0x0) 
struct FOnTakeDamage
{
	struct UDamageType* bpp__DamageType__pf__const;  // 0x0(0x8)
	struct FNetHitReaction bpp__HitReaction__pf;  // 0x8(0x40)

}; 
// Function ABP_Weapon.ABP_Weapon_C.BlueprintOnGenericMeleeAttack
// Size: 0x1(Inherited: 0x0) 
struct FBlueprintOnGenericMeleeAttack
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bpp__bBash__pf : 1;  // 0x0(0x1)

}; 
// Function ABP_Weapon.ABP_Weapon_C.ForceToggleOpticState
// Size: 0x1(Inherited: 0x0) 
struct FForceToggleOpticState
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bpp__bEnable__pf : 1;  // 0x0(0x1)

}; 
// Function ABP_Weapon.ABP_Weapon_C.BlueprintOnItemEquip
// Size: 0x18(Inherited: 0x0) 
struct FBlueprintOnItemEquip
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bpp__bInstant__pf__const : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct AItemEquipable* bpp__SwitchingFrom__pf;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bpp__bWantsFirstEquip__pf__const : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function ABP_Weapon.ABP_Weapon_C.OnPlayGearItemChangeState
// Size: 0x10(Inherited: 0x0) 
struct FOnPlayGearItemChangeState
{
	struct AItemInteractableGear* bpp__ItemGear__pf;  // 0x0(0x8)
	uint8_t  bpp__NewState__pf;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function ABP_Weapon.ABP_Weapon_C.BlueprintOnItemUnequip
// Size: 0x10(Inherited: 0x0) 
struct FBlueprintOnItemUnequip
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bpp__bInstant__pf : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct AItemEquipable* bpp__SwitchingTo__pf;  // 0x8(0x8)

}; 
// Function ABP_Weapon.ABP_Weapon_C.BlueprintOnMeleeWeaponAttack
// Size: 0x40(Inherited: 0x0) 
struct FBlueprintOnMeleeWeaponAttack
{
	struct FMeleeConfig bpp__SelectedAttack__pf__const;  // 0x0(0x40)

}; 
// Function ABP_Weapon.ABP_Weapon_C.BlueprintOnMeleeWeaponHit
// Size: 0x88(Inherited: 0x0) 
struct FBlueprintOnMeleeWeaponHit
{
	struct FHitResult bpp__Hit__pf__const;  // 0x0(0x88)

}; 
// Function ABP_Weapon.ABP_Weapon_C.UpdateRevolverChamberState
// Size: 0x10(Inherited: 0x0) 
struct FUpdateRevolverChamberState
{
	struct TArray<uint8_t > bpp__Chambers__pf__const;  // 0x0(0x10)

}; 
// Function ABP_Weapon.ABP_Weapon_C.IKCurve Alpha
// Size: 0x10(Inherited: 0x0) 
struct FIKCurve Alpha
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bpp__Condition__pf : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool bpp__Subtract__pf : 1;  // 0x1(0x1)
	char pad_2[2];  // 0x2(0x2)
	struct FName bpp__CurveName__pf;  // 0x4(0x8)
	float bpp__Alpha__pf;  // 0xC(0x4)

}; 
// Function ABP_Weapon.ABP_Weapon_C.BlueprintOnReload
// Size: 0x8(Inherited: 0x0) 
struct FBlueprintOnReload
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bpp__bDryReload__pf__const : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool bpp__bSingleReload__pf__const : 1;  // 0x1(0x1)
	char pad_2[2];  // 0x2(0x2)
	float bpp__RateMultiplier__pf__const;  // 0x4(0x4)

}; 
// Function ABP_Weapon.ABP_Weapon_C.ForceRevolverChamberVisibility
// Size: 0x4(Inherited: 0x0) 
struct FForceRevolverChamberVisibility
{
	int32_t bpp__RemainingAmmo__pf;  // 0x0(0x4)

}; 
// Function ABP_Weapon.ABP_Weapon_C.DeltaRotatorAxis
// Size: 0xC(Inherited: 0x0) 
struct FDeltaRotatorAxis
{
	float bpp__A__pf;  // 0x0(0x4)
	float bpp__B__pf;  // 0x4(0x4)
	float bpp__Output__pf;  // 0x8(0x4)

}; 
// Function ABP_Weapon.ABP_Weapon_C.BlueprintOnSwitchMagazine
// Size: 0x8(Inherited: 0x0) 
struct FBlueprintOnSwitchMagazine
{
	float bpp__RateMultiplier__pf__const;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool bpp__bDryReload__pf__const : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)

}; 
// Function ABP_Weapon.ABP_Weapon_C.BlueprintOnUpgradeInstalled
// Size: 0x8(Inherited: 0x0) 
struct FBlueprintOnUpgradeInstalled
{
	struct UWeaponUpgradeComponent* bpp__Upgrade__pf;  // 0x0(0x8)

}; 
// Function ABP_Weapon.ABP_Weapon_C.CheckTickUpdate
// Size: 0x10(Inherited: 0x0) 
struct FCheckTickUpdate
{
	float bpp__DelayTime__pf;  // 0x0(0x4)
	float bpp__NextTickUpdate__pf;  // 0x4(0x4)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bpp__Reutrn__pf : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	float bpp__ReturnNextTickUpdate__pf;  // 0xC(0x4)

}; 
// Function ABP_Weapon.ABP_Weapon_C.CalcFireOffsetLimits
// Size: 0xC(Inherited: 0x0) 
struct FCalcFireOffsetLimits
{
	struct FVector bpp__OpticOffset__pf;  // 0x0(0xC)

}; 
// Function ABP_Weapon.ABP_Weapon_C.BlueprintOnUpgradeMeshLoaded
// Size: 0x10(Inherited: 0x0) 
struct FBlueprintOnUpgradeMeshLoaded
{
	struct UINSSkeletalMeshComponent* bpp__Mesh__pf;  // 0x0(0x8)
	struct UWeaponVisualUpgradeComponent* bpp__Upgrade__pf;  // 0x8(0x8)

}; 
// Function ABP_Weapon.ABP_Weapon_C.BlueprintUpdateAnimation
// Size: 0x4(Inherited: 0x0) 
struct FBlueprintUpdateAnimation
{
	float bpp__DeltaTimeX__pf;  // 0x0(0x4)

}; 
// Function ABP_Weapon.ABP_Weapon_C.Update Optic Alightment
// Size: 0x8(Inherited: 0x0) 
struct FUpdate Optic Alightment
{
	struct UWeaponUpgradeComponent* bpp__UpgradeComponent__pf;  // 0x0(0x8)

}; 
// Function ABP_Weapon.ABP_Weapon_C.CalcAlphaInterp
// Size: 0x10(Inherited: 0x0) 
struct FCalcAlphaInterp
{
	float bpp__Alpha__pf;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool bpp__Switch__pf : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	float bpp__Speed__pf;  // 0x8(0x4)
	float bpp__Output__pf;  // 0xC(0x4)

}; 
// Function ABP_Weapon.ABP_Weapon_C.Calculate Magazine Offset
// Size: 0x38(Inherited: 0x0) 
struct FCalculate Magazine Offset
{
	struct USceneComponent* bpp__Magazine__pf;  // 0x0(0x8)
	struct USceneComponent* bpp__Weapon__pf;  // 0x8(0x8)
	struct FName bpp__ExtendedSocket__pf;  // 0x10(0x8)
	struct FName bpp__StandardSocket__pf;  // 0x18(0x8)
	struct FVector bpp__Position__pf;  // 0x20(0xC)
	struct FRotator bpp__Rotation__pf;  // 0x2C(0xC)

}; 
// Function ABP_Weapon.ABP_Weapon_C.CalcVariableInterp
// Size: 0x10(Inherited: 0x0) 
struct FCalcVariableInterp
{
	float bpp__Current__pf;  // 0x0(0x4)
	float bpp__Target__pf;  // 0x4(0x4)
	float bpp__Speed__pf;  // 0x8(0x4)
	float bpp__Output__pf;  // 0xC(0x4)

}; 
// Function ABP_Weapon.ABP_Weapon_C.CalcAnimPositionLength
// Size: 0x10(Inherited: 0x0) 
struct FCalcAnimPositionLength
{
	struct UAnimSequenceBase* bpp__Sequence__pf;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bpp__Reverse__pf : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	float ReturnValue;  // 0xC(0x4)

}; 
// Function ABP_Weapon.ABP_Weapon_C.CalcBobbing
// Size: 0x28(Inherited: 0x0) 
struct FCalcBobbing
{
	float bpp__BobbingxScale__pfT;  // 0x0(0x4)
	float bpp__BobbingxSpeed__pfT;  // 0x4(0x4)
	float bpp__InputAdjustedTime__pf;  // 0x8(0x4)
	struct FVector bpp__Location__pf;  // 0xC(0xC)
	struct FRotator bpp__Rotator__pf;  // 0x18(0xC)
	float bpp__AdjustedGameTime__pf;  // 0x24(0x4)

}; 
// Function ABP_Weapon.ABP_Weapon_C.OnPlayReload
// Size: 0x10(Inherited: 0x0) 
struct FOnPlayReload
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bpp__bDryReload__pf : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct UAnimMontage* bpp__MontageReference__pf;  // 0x8(0x8)

}; 
// Function ABP_Weapon.ABP_Weapon_C.CalcGenericAlpha
// Size: 0x18(Inherited: 0x0) 
struct FCalcGenericAlpha
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bpp__Target__pf : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	float bpp__AlphaInput__pf;  // 0x4(0x4)
	float bpp__Speed__pf;  // 0x8(0x4)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool bpp__Constant__pf : 1;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)
	float bpp__AlphaOutput__pf;  // 0x10(0x4)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool bpp__Finished__pf : 1;  // 0x14(0x1)
	char pad_21[3];  // 0x15(0x3)

}; 
// Function ABP_Weapon.ABP_Weapon_C.CalcSinusoid
// Size: 0x18(Inherited: 0x0) 
struct FCalcSinusoid
{
	float bpp__Frequency__pf;  // 0x0(0x4)
	float bpp__Amplitude__pf;  // 0x4(0x4)
	float bpp__GameTime__pf;  // 0x8(0x4)
	float bpp__Speed__pf;  // 0xC(0x4)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bpp__Positionx__pfzy : 1;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)
	float bpp__Output__pf;  // 0x14(0x4)

}; 
// Function ABP_Weapon.ABP_Weapon_C.CalcSprintIKAlpha
// Size: 0x10(Inherited: 0x0) 
struct FCalcSprintIKAlpha
{
	float bpp__Sprint__pf;  // 0x0(0x4)
	float bpp__Charge__pf;  // 0x4(0x4)
	float bpp__BipodLegState__pf;  // 0x8(0x4)
	float ReturnValue;  // 0xC(0x4)

}; 
// Function ABP_Weapon.ABP_Weapon_C.CalcVectorInterp
// Size: 0x28(Inherited: 0x0) 
struct FCalcVectorInterp
{
	struct FVector bpp__Current__pf;  // 0x0(0xC)
	struct FVector bpp__Target__pf;  // 0xC(0xC)
	float bpp__Speed__pf;  // 0x18(0x4)
	struct FVector bpp__Output__pf;  // 0x1C(0xC)

}; 
// Function ABP_Weapon.ABP_Weapon_C.Calc Axis Interp
// Size: 0x10(Inherited: 0x0) 
struct FCalc Axis Interp
{
	float bpp__Current__pf;  // 0x0(0x4)
	float bpp__Target__pf;  // 0x4(0x4)
	float bpp__Speed__pf;  // 0x8(0x4)
	float bpp__Output__pf;  // 0xC(0x4)

}; 
// Function ABP_Weapon.ABP_Weapon_C.Calc Generic Float Alpha
// Size: 0x14(Inherited: 0x0) 
struct FCalc Generic Float Alpha
{
	float bpp__Target__pf;  // 0x0(0x4)
	float bpp__AlphaInput__pf;  // 0x4(0x4)
	float bpp__Speed__pf;  // 0x8(0x4)
	float bpp__AlphaOutput__pf;  // 0xC(0x4)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bpp__Finished__pf : 1;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)

}; 
// Function ABP_Weapon.ABP_Weapon_C.OnScavengeMagazine
// Size: 0x10(Inherited: 0x0) 
struct FOnScavengeMagazine
{
	struct AINSSoldier* bpp__Interactor__pf;  // 0x0(0x8)
	struct AItemWeapon* bpp__Weapon__pf;  // 0x8(0x8)

}; 
// Function ABP_Weapon.ABP_Weapon_C.ClampedFLerp
// Size: 0x10(Inherited: 0x0) 
struct FClampedFLerp
{
	float bpp__A__pf;  // 0x0(0x4)
	float bpp__B__pf;  // 0x4(0x4)
	float bpp__Alpha__pf;  // 0x8(0x4)
	float bpp__Return__pf;  // 0xC(0x4)

}; 
// Function ABP_Weapon.ABP_Weapon_C.ExecuteUbergraph_ABP_Weapon_406
// Size: 0x4(Inherited: 0x0) 
struct FExecuteUbergraph_ABP_Weapon_406
{
	int32_t bpp__EntryPoint__pf;  // 0x0(0x4)

}; 
// Function ABP_Weapon.ABP_Weapon_C.ExecuteUbergraph_ABP_Weapon_2
// Size: 0x4(Inherited: 0x0) 
struct FExecuteUbergraph_ABP_Weapon_2
{
	int32_t bpp__EntryPoint__pf;  // 0x0(0x4)

}; 
// Function ABP_Weapon.ABP_Weapon_C.ExecuteUbergraph_ABP_Weapon_5
// Size: 0x4(Inherited: 0x0) 
struct FExecuteUbergraph_ABP_Weapon_5
{
	int32_t bpp__EntryPoint__pf;  // 0x0(0x4)

}; 
// Function ABP_Weapon.ABP_Weapon_C.ExecuteUbergraph_ABP_Weapon_71
// Size: 0x4(Inherited: 0x0) 
struct FExecuteUbergraph_ABP_Weapon_71
{
	int32_t bpp__EntryPoint__pf;  // 0x0(0x4)

}; 
// Function ABP_Weapon.ABP_Weapon_C.GetRevolverEmpty
// Size: 0x20(Inherited: 0x0) 
struct FGetRevolverEmpty
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bpp__Revolver__pf : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct TArray<uint8_t > bpp__RevolverChambers__pf;  // 0x8(0x10)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool bpp__Debug__pf : 1;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool bpp__Return__pf : 1;  // 0x19(0x1)
	char pad_26[6];  // 0x1A(0x6)

}; 
// Function ABP_Weapon.ABP_Weapon_C.InteractOneHandNVG
// Size: 0x10(Inherited: 0x0) 
struct FInteractOneHandNVG
{
	struct AItemInteractableGear* bpp__GearItem__pf;  // 0x0(0x8)
	uint8_t  bpp__State__pf;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function ABP_Weapon.ABP_Weapon_C.InterfaceUpdateSimulationBlend
// Size: 0x4(Inherited: 0x0) 
struct FInterfaceUpdateSimulationBlend
{
	float bpp__State__pf;  // 0x0(0x4)

}; 
// Function ABP_Weapon.ABP_Weapon_C.OnDoorKick
// Size: 0x1(Inherited: 0x0) 
struct FOnDoorKick
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bpp__bKickWillSucceed__pf : 1;  // 0x0(0x1)

}; 
// Function ABP_Weapon.ABP_Weapon_C.OnPlayBoltReload
// Size: 0x10(Inherited: 0x0) 
struct FOnPlayBoltReload
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bpp__DryReload__pf : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct UAnimMontage* bpp__MontagexReference__pfT;  // 0x8(0x8)

}; 
// Function ABP_Weapon.ABP_Weapon_C.OnPlayBoltReloadAfterSwitchMagazine
// Size: 0x10(Inherited: 0x0) 
struct FOnPlayBoltReloadAfterSwitchMagazine
{
	struct UAnimMontage* bpp__AnimReloadBoltAfterSwitchMagazine__pf;  // 0x0(0x8)
	struct UAnimMontage* bpp__MontagexReference__pfT;  // 0x8(0x8)

}; 
// Function ABP_Weapon.ABP_Weapon_C.OnPlayRechamber
// Size: 0x10(Inherited: 0x0) 
struct FOnPlayRechamber
{
	float bpp__BoltSpeed__pf;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UAnimMontage* bpp__Reference__pf;  // 0x8(0x8)

}; 
// Function ABP_Weapon.ABP_Weapon_C.OnPlayRevolverReload
// Size: 0x10(Inherited: 0x0) 
struct FOnPlayRevolverReload
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bpp__DryReload__pf : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool bpp__Debug__pf : 1;  // 0x1(0x1)
	char pad_2[6];  // 0x2(0x6)
	struct UAnimMontage* bpp__MontageReference__pf;  // 0x8(0x8)

}; 
// Function ABP_Weapon.ABP_Weapon_C.OnPlayWeaponMelee
// Size: 0x1(Inherited: 0x0) 
struct FOnPlayWeaponMelee
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bpp__Bash__pf : 1;  // 0x0(0x1)

}; 
// Function ABP_Weapon.ABP_Weapon_C.OnUseActorInteracted
// Size: 0x18(Inherited: 0x0) 
struct FOnUseActorInteracted
{
	struct AINSSoldier* bpp__Interactor__pf;  // 0x0(0x8)
	struct AActor* bpp__InteractingActor__pf;  // 0x8(0x8)
	uint8_t  bpp__Item__pf;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function ABP_Weapon.ABP_Weapon_C.PlayActorInteraction
// Size: 0x10(Inherited: 0x0) 
struct FPlayActorInteraction
{
	struct AActor* bpp__InteractingxActor__pfT;  // 0x0(0x8)
	uint8_t  bpp__UsableActorType__pf;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function ABP_Weapon.ABP_Weapon_C.PlaySwitchMagazine
// Size: 0x18(Inherited: 0x0) 
struct FPlaySwitchMagazine
{
	struct TArray<struct UAnimSequence*> bpp__Animation__pf;  // 0x0(0x10)
	int32_t bpp__Index__pf;  // 0x10(0x4)
	float bpp__Speed__pf;  // 0x14(0x4)

}; 
// Function ABP_Weapon.ABP_Weapon_C.SelectReload
// Size: 0x30(Inherited: 0x0) 
struct FSelectReload
{
	struct TArray<struct FReloadGroup> bpp__Reloads__pf;  // 0x0(0x10)
	struct UAnimMontage* bpp__Reload__pf;  // 0x10(0x8)
	struct UAnimMontage* bpp__ReloadEmpty__pf;  // 0x18(0x8)
	struct UAnimMontage* bpp__ReloadStages__pf;  // 0x20(0x8)
	int32_t bpp__SelectedReload__pf;  // 0x28(0x4)
	char pad_44[4];  // 0x2C(0x4)

}; 
// Function ABP_Weapon.ABP_Weapon_C.SetAmmoContainer
// Size: 0x1(Inherited: 0x0) 
struct FSetAmmoContainer
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bpp__AlternateMag__pf : 1;  // 0x0(0x1)

}; 
// Function ABP_Weapon.ABP_Weapon_C.SetEquipable
// Size: 0x8(Inherited: 0x0) 
struct FSetEquipable
{
	struct AItemEquipable* bpp__Item__pf;  // 0x0(0x8)

}; 
// Function ABP_Weapon.ABP_Weapon_C.SetFireModeBase
// Size: 0x1(Inherited: 0x0) 
struct FSetFireModeBase
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bpp__TwoFireModes__pf : 1;  // 0x0(0x1)

}; 
// Function ABP_Weapon.ABP_Weapon_C.SetupReloadVariables
// Size: 0x8(Inherited: 0x0) 
struct FSetupReloadVariables
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bpp__DryReload__pf : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool bpp__SingleReload__pf : 1;  // 0x1(0x1)
	char pad_2[2];  // 0x2(0x2)
	float bpp__RateMultiplier__pf;  // 0x4(0x4)

}; 
// Function ABP_Weapon.ABP_Weapon_C.SightAlignment
// Size: 0x28(Inherited: 0x0) 
struct FSightAlignment
{
	struct USkeletalMeshComponent* bpp__EquipableComponent__pf;  // 0x0(0x8)
	struct USkeletalMeshComponent* bpp__AttachmentComponent__pf;  // 0x8(0x8)
	float bpp__SightRotation__pf;  // 0x10(0x4)
	float bpp__ModelFlattenScale__pf;  // 0x14(0x4)
	struct FVector bpp__Return__pf;  // 0x18(0xC)
	char pad_36[4];  // 0x24(0x4)

}; 
// Function ABP_Weapon.ABP_Weapon_C.StopAmmoCheck
// Size: 0x4(Inherited: 0x0) 
struct FStopAmmoCheck
{
	float bpp__BlendOutTime__pf;  // 0x0(0x4)

}; 
// Function ABP_Weapon.ABP_Weapon_C.ToggleADS
// Size: 0x1(Inherited: 0x0) 
struct FToggleADS
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bpp__In__pf : 1;  // 0x0(0x1)

}; 
// Function ABP_Weapon.ABP_Weapon_C.ToggleOpticState
// Size: 0x1(Inherited: 0x0) 
struct FToggleOpticState
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bpp__Enable__pf : 1;  // 0x0(0x1)

}; 
// Function ABP_Weapon.ABP_Weapon_C.UpdateOpticOnAttachment
// Size: 0x8(Inherited: 0x0) 
struct FUpdateOpticOnAttachment
{
	int32_t bpp__LatchedMode__pf__const;  // 0x0(0x4)
	int32_t bpp__DesiredMode__pf__const;  // 0x4(0x4)

}; 
// Function ABP_Weapon.ABP_Weapon_C.UpdateOpticState
// Size: 0x10(Inherited: 0x0) 
struct FUpdateOpticState
{
	int32_t bpp__Mode__pf;  // 0x0(0x4)
	int32_t bpp__DesiredMode__pf;  // 0x4(0x4)
	struct UObject* bpp__Upgrade__pf;  // 0x8(0x8)

}; 
// Function ABP_Weapon.ABP_Weapon_C.UpdateOpticToggle
// Size: 0x18(Inherited: 0x0) 
struct FUpdateOpticToggle
{
	struct UObject* bpp__Upgrade__pf;  // 0x0(0x8)
	struct FDelegate bpp__Delegate__pf__const;  // 0x8(0x10)

}; 
// Function ABP_Weapon.ABP_Weapon_C.UpdateOpticToggleState
// Size: 0x8(Inherited: 0x0) 
struct FUpdateOpticToggleState
{
	int32_t bpp__LatchedMode__pf__const;  // 0x0(0x4)
	int32_t bpp__DesiredMode__pf__const;  // 0x4(0x4)

}; 
// Function ABP_Weapon.ABP_Weapon_C.UpdateRevolverChamberPostProcess
// Size: 0x10(Inherited: 0x0) 
struct FUpdateRevolverChamberPostProcess
{
	struct TArray<uint8_t > bpp__Chambers__pf;  // 0x0(0x10)

}; 
// Function ABP_Weapon.ABP_Weapon_C.Update Optic Toggle Attachment
// Size: 0x18(Inherited: 0x0) 
struct FUpdate Optic Toggle Attachment
{
	struct UObject* bpp__Upgrade__pf;  // 0x0(0x8)
	struct FDelegate bpp__Delegate__pf__const;  // 0x8(0x10)

}; 
// Function ABP_Weapon.ABP_Weapon_C.Update Attached Weapon Sight Offset
// Size: 0x8(Inherited: 0x0) 
struct FUpdate Attached Weapon Sight Offset
{
	struct AItemFirearm* bpp__ParentFirearm__pf;  // 0x0(0x8)

}; 
