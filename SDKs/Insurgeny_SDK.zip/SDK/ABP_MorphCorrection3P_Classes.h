#pragma once 
#include <ABP_MorphCorrection3P_Structs.h>
 
 
 
// DynamicClass ABP_MorphCorrection3P.ABP_MorphCorrection3P_C
// Size: 0x570(Inherited: 0x2C0) 
struct UABP_MorphCorrection3P_C : public UAnimInstance
{
	struct FAnimNode_Root AnimGraphNode_Root;  // 0x2B8(0x30)
	struct FAnimNode_LinkedInputPose AnimGraphNode_LinkedInputPose;  // 0x2E8(0x118)
	struct FAnimNode_PoseDriver AnimGraphNode_PoseDriver;  // 0x400(0x168)

	void ExecuteUbergraph_ABP_MorphCorrection3P(int32_t bpp__EntryPoint__pf); // Function ABP_MorphCorrection3P.ABP_MorphCorrection3P_C.ExecuteUbergraph_ABP_MorphCorrection3P
	void AnimGraph(struct FPoseLink bpp__InPose__pf, struct FPoseLink& bpp__AnimGraph__pf); // Function ABP_MorphCorrection3P.ABP_MorphCorrection3P_C.AnimGraph
}; 



