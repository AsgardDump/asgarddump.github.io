#pragma once 
#include <AmmoMagazine_ASVAL_TwitchGreen_Box_20RD_Structs.h>
 
 
 
// BlueprintGeneratedClass AmmoMagazine_ASVAL_TwitchGreen_Box_20RD.AmmoMagazine_ASVAL_TwitchGreen_Box_20RD_C
// Size: 0x178(Inherited: 0x178) 
struct UAmmoMagazine_ASVAL_TwitchGreen_Box_20RD_C : public UAmmoMagazine_ASVALBox_20RD_C
{

}; 



