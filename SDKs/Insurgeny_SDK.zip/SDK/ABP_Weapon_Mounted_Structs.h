#pragma once 
#include "SDK.h" 
 
 
// Function ABP_Weapon_Mounted.ABP_Weapon_Mounted_C.AnimGraph
// Size: 0x10(Inherited: 0x0) 
struct FAnimGraph
{
	struct FPoseLink bpp__AnimGraph__pf;  // 0x0(0x10)

}; 
// Function ABP_Weapon_Mounted.ABP_Weapon_Mounted_C.OnPlayReload
// Size: 0x2(Inherited: 0x0) 
struct FOnPlayReload
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bpp__Empty__pf : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool bpp__HasReload__pf : 1;  // 0x1(0x1)

}; 
// Function ABP_Weapon_Mounted.ABP_Weapon_Mounted_C.BlueprintOnFirearmFired
// Size: 0x18(Inherited: 0x0) 
struct FBlueprintOnFirearmFired
{
	struct FVector bpp__FireOrigin__pf__const;  // 0x0(0xC)
	struct FVector bpp__FireDirection__pf__const;  // 0xC(0xC)

}; 
// Function ABP_Weapon_Mounted.ABP_Weapon_Mounted_C.BlueprintOnReload
// Size: 0x8(Inherited: 0x0) 
struct FBlueprintOnReload
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bpp__bDryReload__pf__const : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool bpp__bSingleReload__pf__const : 1;  // 0x1(0x1)
	char pad_2[2];  // 0x2(0x2)
	float bpp__RateMultiplier__pf__const;  // 0x4(0x4)

}; 
// Function ABP_Weapon_Mounted.ABP_Weapon_Mounted_C.BlueprintUpdateAnimation
// Size: 0x4(Inherited: 0x0) 
struct FBlueprintUpdateAnimation
{
	float bpp__DeltaTimeX__pf;  // 0x0(0x4)

}; 
// Function ABP_Weapon_Mounted.ABP_Weapon_Mounted_C.SetEquipable
// Size: 0x8(Inherited: 0x0) 
struct FSetEquipable
{
	struct AItemEquipable* bpp__Item__pf;  // 0x0(0x8)

}; 
