#pragma once 
#include <AmmoMagazine_HB_BlackPowder_Box_30RD_Structs.h>
 
 
 
// BlueprintGeneratedClass AmmoMagazine_HB_BlackPowder_Box_30RD.AmmoMagazine_HB_BlackPowder_Box_30RD_C
// Size: 0x178(Inherited: 0x178) 
struct UAmmoMagazine_HB_BlackPowder_Box_30RD_C : public UAmmoMagazine_HB_Box_30RD_C
{

}; 



