#pragma once 
#include <ABP_PP_VIP_Structs.h>
 
 
 
// DynamicClass ABP_PP_VIP.ABP_PP_VIP_C
// Size: 0x570(Inherited: 0x2C0) 
struct UABP_PP_VIP_C : public UAnimInstance
{
	struct FAnimNode_Root AnimGraphNode_Root;  // 0x2B8(0x30)
	struct FAnimNode_LinkedInputPose AnimGraphNode_SubInput;  // 0x2E8(0x118)
	struct FAnimNode_PoseDriver AnimGraphNode_PoseDriver;  // 0x400(0x168)

	void ExecuteUbergraph_ABP_PP_VIP(int32_t bpp__EntryPoint__pf); // Function ABP_PP_VIP.ABP_PP_VIP_C.ExecuteUbergraph_ABP_PP_VIP
	void AnimGraph(struct FPoseLink bpp__InPose__pf, struct FPoseLink& bpp__AnimGraph__pf); // Function ABP_PP_VIP.ABP_PP_VIP_C.AnimGraph
}; 



