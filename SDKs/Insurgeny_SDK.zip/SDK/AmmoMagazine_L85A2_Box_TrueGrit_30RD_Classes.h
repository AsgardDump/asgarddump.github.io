#pragma once 
#include <AmmoMagazine_L85A2_Box_TrueGrit_30RD_Structs.h>
 
 
 
// BlueprintGeneratedClass AmmoMagazine_L85A2_Box_TrueGrit_30RD.AmmoMagazine_L85A2_Box_TrueGrit_30RD_C
// Size: 0x178(Inherited: 0x178) 
struct UAmmoMagazine_L85A2_Box_TrueGrit_30RD_C : public UAmmoMagazine_L85A2_Box_30RD_C
{

}; 



