#pragma once 
#include <AmmoContainer_22mmSmoke_Structs.h>
 
 
 
// BlueprintGeneratedClass AmmoContainer_22mmSmoke.AmmoContainer_22mmSmoke_C
// Size: 0x170(Inherited: 0x170) 
struct UAmmoContainer_22mmSmoke_C : public UAmmoContainer
{

}; 



