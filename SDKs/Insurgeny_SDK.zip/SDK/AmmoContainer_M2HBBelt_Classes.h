#pragma once 
#include <AmmoContainer_M2HBBelt_Structs.h>
 
 
 
// BlueprintGeneratedClass AmmoContainer_M2HBBelt.AmmoContainer_M2HBBelt_C
// Size: 0x178(Inherited: 0x178) 
struct UAmmoContainer_M2HBBelt_C : public UAmmoContainerMagazine
{

}; 



