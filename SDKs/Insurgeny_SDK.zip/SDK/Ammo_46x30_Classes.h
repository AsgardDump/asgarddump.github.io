#pragma once 
#include <Ammo_46x30_Structs.h>
 
 
 
// DynamicClass Ammo_46x30.Ammo_46x30_C
// Size: 0x2C8(Inherited: 0x2C8) 
struct UAmmo_46x30_C : public UAmmoTypeBallistic
{

}; 



