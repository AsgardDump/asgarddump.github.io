#pragma once 
#include <AmmoMagazine_DEagle_Damascus_7RD1_Structs.h>
 
 
 
// BlueprintGeneratedClass AmmoMagazine_DEagle_Damascus_7RD1.AmmoMagazine_DEagle_Damascus_7RD1_C
// Size: 0x178(Inherited: 0x178) 
struct UAmmoMagazine_DEagle_Damascus_7RD1_C : public UAmmoMagazine_DEagle_7RD_C
{

}; 



