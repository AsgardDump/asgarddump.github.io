#pragma once 
#include <AmmoMagazine_Garand_Whiteout_Box_9_Structs.h>
 
 
 
// BlueprintGeneratedClass AmmoMagazine_Garand_Whiteout_Box_9.AmmoMagazine_Garand_Whiteout_Box_8_C
// Size: 0x178(Inherited: 0x178) 
struct UAmmoMagazine_Garand_Whiteout_Box_8_C : public UAmmoMagazine_GarandBox_8_C
{

}; 



