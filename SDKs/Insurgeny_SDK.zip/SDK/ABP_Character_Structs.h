#pragma once 
#include "SDK.h" 
 
 
// Function ABP_Character.ABP_Character_C.CaclulateNormalAngle
// Size: 0x18(Inherited: 0x0) 
struct FCaclulateNormalAngle
{
	struct FVector bpp__Normal__pf;  // 0x0(0xC)
	struct FRotator bpp__Rotator__pf;  // 0xC(0xC)

}; 
// Function ABP_Character.ABP_Character_C.BlendOutMontage
// Size: 0x8(Inherited: 0x0) 
struct FBlendOutMontage
{
	struct UAnimSequenceBase* bpp__Montage__pf;  // 0x0(0x8)

}; 
// DelegateFunction ABP_Character.ABP_Character_C.DelegateDoorKick__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FDelegateDoorKick__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bpp__bKickWillSucceed__pf : 1;  // 0x0(0x1)

}; 
// Function ABP_Character.ABP_Character_C.BlueprintUpdateAnimation
// Size: 0x4(Inherited: 0x0) 
struct FBlueprintUpdateAnimation
{
	float bpp__DeltaTimeX__pf;  // 0x0(0x4)

}; 
// DelegateFunction ABP_Character.ABP_Character_C.CharacterResponseDelegate__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FCharacterResponseDelegate__DelegateSignature
{
	uint8_t  bpp__Response__pf;  // 0x0(0x1)

}; 
// Function ABP_Character.ABP_Character_C.PlayItemUsage
// Size: 0x2(Inherited: 0x0) 
struct FPlayItemUsage
{
	uint8_t  bpp__EquipState__pf;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool bpp__NVG__pf : 1;  // 0x1(0x1)

}; 
// DelegateFunction ABP_Character.ABP_Character_C.OnCharacterTakeDamageDelegate__DelegateSignature
// Size: 0x48(Inherited: 0x0) 
struct FOnCharacterTakeDamageDelegate__DelegateSignature
{
	struct UDamageType* bpp__DamageType__pf;  // 0x0(0x8)
	struct FNetHitReaction bpp__HitReaction__pf;  // 0x8(0x40)

}; 
// Function ABP_Character.ABP_Character_C.ExecuteUbergraph_ABP_Character_3
// Size: 0x4(Inherited: 0x0) 
struct FExecuteUbergraph_ABP_Character_3
{
	int32_t bpp__EntryPoint__pf;  // 0x0(0x4)

}; 
// Function ABP_Character.ABP_Character_C.AnimGraph
// Size: 0x10(Inherited: 0x0) 
struct FAnimGraph
{
	struct FPoseLink bpp__AnimGraph__pf;  // 0x0(0x10)

}; 
// DelegateFunction ABP_Character.ABP_Character_C.OnUsableInteractionDelegate__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FOnUsableInteractionDelegate__DelegateSignature
{
	struct AINSSoldier* bpp__Interactor__pf;  // 0x0(0x8)
	struct AActor* bpp__InteractingActor__pf;  // 0x8(0x8)
	uint8_t  bpp__Item__pf;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function ABP_Character.ABP_Character_C.BlueprintOnBipodDeployedStateChanged
// Size: 0x2(Inherited: 0x0) 
struct FBlueprintOnBipodDeployedStateChanged
{
	uint8_t  bpp__OldState__pf__const;  // 0x0(0x1)
	uint8_t  bpp__NewState__pf__const;  // 0x1(0x1)

}; 
// Function ABP_Character.ABP_Character_C.CalcUnderbarrelOffset
// Size: 0x10(Inherited: 0x0) 
struct FCalcUnderbarrelOffset
{
	struct UWeaponUpgradeComponent* bpp__Upgrade__pf;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bpp__NoCheck__pf : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool bpp__NoCalc__pf : 1;  // 0x9(0x1)
	char pad_10[6];  // 0xA(0x6)

}; 
// Function ABP_Character.ABP_Character_C.UpdateCharacterAnimInstance
// Size: 0x18(Inherited: 0x0) 
struct FUpdateCharacterAnimInstance
{
	struct UAnimInstance* bpp__GearAnimInstance__pf;  // 0x0(0x8)
	uint8_t  bpp__Combination__pf;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	struct FName bpp__Faction__pf;  // 0xC(0x8)
	char pad_20[4];  // 0x14(0x4)

}; 
// Function ABP_Character.ABP_Character_C.BlueprintOnBipodLegsStateChanged
// Size: 0x2(Inherited: 0x0) 
struct FBlueprintOnBipodLegsStateChanged
{
	uint8_t  bpp__OldState__pf__const;  // 0x0(0x1)
	uint8_t  bpp__NewState__pf__const;  // 0x1(0x1)

}; 
// Function ABP_Character.ABP_Character_C.ExecuteUbergraph_ABP_Character_54
// Size: 0x4(Inherited: 0x0) 
struct FExecuteUbergraph_ABP_Character_54
{
	int32_t bpp__EntryPoint__pf;  // 0x0(0x4)

}; 
// Function ABP_Character.ABP_Character_C.CombineRotatorAxis
// Size: 0xC(Inherited: 0x0) 
struct FCombineRotatorAxis
{
	float bpp__A__pf;  // 0x0(0x4)
	float bpp__B__pf;  // 0x4(0x4)
	float bpp__ReturnxValue__pfT;  // 0x8(0x4)

}; 
// Function ABP_Character.ABP_Character_C.BlueprintOnCycleFiremode
// Size: 0x2(Inherited: 0x0) 
struct FBlueprintOnCycleFiremode
{
	uint8_t  bpp__OldFiremode__pf__const;  // 0x0(0x1)
	uint8_t  bpp__NewFiremode__pf__const;  // 0x1(0x1)

}; 
// Function ABP_Character.ABP_Character_C.BlueprintOnFastReload
// Size: 0x8(Inherited: 0x0) 
struct FBlueprintOnFastReload
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bpp__bDryReload__pf__const : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	float bpp__RateMultiplier__pf__const;  // 0x4(0x4)

}; 
// Function ABP_Character.ABP_Character_C.OnUseActorInteracted
// Size: 0x18(Inherited: 0x0) 
struct FOnUseActorInteracted
{
	struct AINSSoldier* bpp__Interactor__pf;  // 0x0(0x8)
	struct AActor* bpp__InteractingActor__pf;  // 0x8(0x8)
	uint8_t  bpp__Item__pf;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function ABP_Character.ABP_Character_C.BlueprintOnFirearmFired
// Size: 0x18(Inherited: 0x0) 
struct FBlueprintOnFirearmFired
{
	struct FVector bpp__FireOrigin__pf__const;  // 0x0(0xC)
	struct FVector bpp__FireDirection__pf__const;  // 0xC(0xC)

}; 
// Function ABP_Character.ABP_Character_C.ExecuteUbergraph_ABP_Character_59
// Size: 0x4(Inherited: 0x0) 
struct FExecuteUbergraph_ABP_Character_59
{
	int32_t bpp__EntryPoint__pf;  // 0x0(0x4)

}; 
// Function ABP_Character.ABP_Character_C.CalcIKHip
// Size: 0x18(Inherited: 0x0) 
struct FCalcIKHip
{
	float bpp__IKFeetLeft__pf;  // 0x0(0x4)
	float bpp__IKFeetRight__pf;  // 0x4(0x4)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bpp__Debugx__pfzy : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool bpp__Activex__pfzy : 1;  // 0x9(0x1)
	char pad_10[2];  // 0xA(0x2)
	struct FVector bpp__Vertical__pf;  // 0xC(0xC)

}; 
// Function ABP_Character.ABP_Character_C.BlueprintOnGearInteracted
// Size: 0x10(Inherited: 0x0) 
struct FBlueprintOnGearInteracted
{
	struct AItemInteractableGear* bpp__GearItem__pf;  // 0x0(0x8)
	uint8_t  bpp__NewState__pf;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function ABP_Character.ABP_Character_C.OnTakeDamage
// Size: 0x48(Inherited: 0x0) 
struct FOnTakeDamage
{
	struct UDamageType* bpp__DamageType__pf__const;  // 0x0(0x8)
	struct FNetHitReaction bpp__HitReaction__pf;  // 0x8(0x40)

}; 
// Function ABP_Character.ABP_Character_C.BlueprintOnGenericMeleeAttack
// Size: 0x1(Inherited: 0x0) 
struct FBlueprintOnGenericMeleeAttack
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bpp__bBash__pf : 1;  // 0x0(0x1)

}; 
// Function ABP_Character.ABP_Character_C.BlueprintOnItemEquip
// Size: 0x18(Inherited: 0x0) 
struct FBlueprintOnItemEquip
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bpp__bInstant__pf__const : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct AItemEquipable* bpp__SwitchingFrom__pf;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bpp__bWantsFirstEquip__pf__const : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function ABP_Character.ABP_Character_C.BlueprintOnItemUnequip
// Size: 0x10(Inherited: 0x0) 
struct FBlueprintOnItemUnequip
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bpp__bInstant__pf : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct AItemEquipable* bpp__SwitchingTo__pf;  // 0x8(0x8)

}; 
// Function ABP_Character.ABP_Character_C.PlayReactionResponse
// Size: 0x1(Inherited: 0x0) 
struct FPlayReactionResponse
{
	uint8_t  bpp__Response__pf;  // 0x0(0x1)

}; 
// Function ABP_Character.ABP_Character_C.UpdateNightVisionState
// Size: 0x1(Inherited: 0x0) 
struct FUpdateNightVisionState
{
	uint8_t  bpp__State__pf;  // 0x0(0x1)

}; 
// Function ABP_Character.ABP_Character_C.BlueprintOnMeleeWeaponAttack
// Size: 0x40(Inherited: 0x0) 
struct FBlueprintOnMeleeWeaponAttack
{
	struct FMeleeConfig bpp__SelectedAttack__pf__const;  // 0x0(0x40)

}; 
// Function ABP_Character.ABP_Character_C.CalcAnimTime
// Size: 0x30(Inherited: 0x0) 
struct FCalcAnimTime
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bpp__TwoWayx__pfzy : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	float bpp__AnimStartTime__pf;  // 0x4(0x4)
	float bpp__AnimTimeInput__pf;  // 0x8(0x4)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool bpp__Condition__pf : 1;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)
	float bpp__Speed__pf;  // 0x10(0x4)
	float bpp__ReturnSpeed__pf;  // 0x14(0x4)
	float bpp__AnimLength__pf;  // 0x18(0x4)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool bpp__OverrideCondition__pf : 1;  // 0x1C(0x1)
	char pad_29[3];  // 0x1D(0x3)
	float bpp__Override__pf;  // 0x20(0x4)
	float bpp__AnimTimeOutput__pf;  // 0x24(0x4)
	float bpp__AnimTimeReturnOutput__pf;  // 0x28(0x4)
	char pad_44_1 : 7;  // 0x2C(0x1)
	bool bpp__Finished__pf : 1;  // 0x2C(0x1)
	char pad_45[3];  // 0x2D(0x3)

}; 
// Function ABP_Character.ABP_Character_C.ExecuteUbergraph_ABP_Character_7
// Size: 0x4(Inherited: 0x0) 
struct FExecuteUbergraph_ABP_Character_7
{
	int32_t bpp__EntryPoint__pf;  // 0x0(0x4)

}; 
// Function ABP_Character.ABP_Character_C.BlueprintOnReload
// Size: 0x8(Inherited: 0x0) 
struct FBlueprintOnReload
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bpp__bDryReload__pf__const : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool bpp__bSingleReload__pf__const : 1;  // 0x1(0x1)
	char pad_2[2];  // 0x2(0x2)
	float bpp__RateMultiplier__pf__const;  // 0x4(0x4)

}; 
// Function ABP_Character.ABP_Character_C.BlueprintOnUpgradeInstalled
// Size: 0x8(Inherited: 0x0) 
struct FBlueprintOnUpgradeInstalled
{
	struct UWeaponUpgradeComponent* bpp__Upgrade__pf;  // 0x0(0x8)

}; 
// Function ABP_Character.ABP_Character_C.CheckTickUpdate
// Size: 0x10(Inherited: 0x0) 
struct FCheckTickUpdate
{
	float bpp__DelayTime__pf;  // 0x0(0x4)
	float bpp__NextTickUpdate__pf;  // 0x4(0x4)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bpp__Return__pf : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	float bpp__ReturnNextTickUpdate__pf;  // 0xC(0x4)

}; 
// Function ABP_Character.ABP_Character_C.PlayHitReaction
// Size: 0x48(Inherited: 0x0) 
struct FPlayHitReaction
{
	struct UDamageType* bpp__Damage__pf__const;  // 0x0(0x8)
	struct FNetHitReaction bpp__Hit__pf;  // 0x8(0x40)

}; 
// Function ABP_Character.ABP_Character_C.BlueprintOnUpgradeMeshLoaded
// Size: 0x10(Inherited: 0x0) 
struct FBlueprintOnUpgradeMeshLoaded
{
	struct UINSSkeletalMeshComponent* bpp__Mesh__pf;  // 0x0(0x8)
	struct UWeaponVisualUpgradeComponent* bpp__Upgrade__pf;  // 0x8(0x8)

}; 
// Function ABP_Character.ABP_Character_C.MolotovRagState
// Size: 0x1(Inherited: 0x0) 
struct FMolotovRagState
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bpp__bEnabled__pf : 1;  // 0x0(0x1)

}; 
// Function ABP_Character.ABP_Character_C.CalcAlphaInterp
// Size: 0x10(Inherited: 0x0) 
struct FCalcAlphaInterp
{
	float bpp__Alpha__pf;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool bpp__Switch__pf : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	float bpp__Speed__pf;  // 0x8(0x4)
	float bpp__Output__pf;  // 0xC(0x4)

}; 
// Function ABP_Character.ABP_Character_C.CalcAlphaInterpConstant
// Size: 0x10(Inherited: 0x0) 
struct FCalcAlphaInterpConstant
{
	float bpp__Alpha__pf;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool bpp__Switch__pf : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	float bpp__Speed__pf;  // 0x8(0x4)
	float bpp__Output__pf;  // 0xC(0x4)

}; 
// Function ABP_Character.ABP_Character_C.OnVoiceCommand
// Size: 0x1(Inherited: 0x0) 
struct FOnVoiceCommand
{
	uint8_t  bpp__Response__pf;  // 0x0(0x1)

}; 
// Function ABP_Character.ABP_Character_C.OnExitedVehicle
// Size: 0x8(Inherited: 0x0) 
struct FOnExitedVehicle
{
	struct UVehicleSeatComponent* bpp__VehicleSeat__pf;  // 0x0(0x8)

}; 
// Function ABP_Character.ABP_Character_C.CalcEquipRates
// Size: 0x8(Inherited: 0x0) 
struct FCalcEquipRates
{
	struct AItemEquipable* bpp__EquipableReference__pf;  // 0x0(0x8)

}; 
// Function ABP_Character.ABP_Character_C.CalcForearmAlpha
// Size: 0x18(Inherited: 0x0) 
struct FCalcForearmAlpha
{
	struct USceneComponent* bpp__Mesh__pf;  // 0x0(0x8)
	struct FName bpp__BoneName__pf;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bpp__LeftHand__pf : 1;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)
	float ReturnValue;  // 0x14(0x4)

}; 
// Function ABP_Character.ABP_Character_C.CalcHandRelativeOffset
// Size: 0x60(Inherited: 0x0) 
struct FCalcHandRelativeOffset
{
	struct FName bpp__Socket__pf;  // 0x0(0x8)
	struct UAnimSequence* bpp__Sequence__pf;  // 0x8(0x8)
	struct FName bpp__ParentBone__pf;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool bpp__UseAlternative__pf : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct UAnimSequence* bpp__AlternateSequence__pf;  // 0x20(0x8)
	char pad_40[8];  // 0x28(0x8)
	struct FTransform ReturnValue;  // 0x30(0x30)

}; 
// Function ABP_Character.ABP_Character_C.PlayUseActorInteraction
// Size: 0x10(Inherited: 0x0) 
struct FPlayUseActorInteraction
{
	uint8_t  bpp__Selection__pf;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	float bpp__TapTime__pf;  // 0x4(0x4)
	float bpp__UseTIme__pf;  // 0x8(0x4)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool bpp__bCanTapHold__pf : 1;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)

}; 
// Function ABP_Character.ABP_Character_C.CalcIKFeetTrace
// Size: 0x28(Inherited: 0x0) 
struct FCalcIKFeetTrace
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bpp__LeftFootx__pfzy : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool bpp__Debugx__pfzy : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool bpp__Activex__pfzy : 1;  // 0x2(0x1)
	char pad_3[1];  // 0x3(0x1)
	struct FRotator bpp__OriginalRotation__pf;  // 0x4(0xC)
	float bpp__OriginalVectorZ__pf;  // 0x10(0x4)
	float bpp__Limit__pf;  // 0x14(0x4)
	float bpp__VectorZ__pf;  // 0x18(0x4)
	struct FVector_NetQuantizeNormal bpp__Normal__pf;  // 0x1C(0xC)

}; 
// Function ABP_Character.ABP_Character_C.CalcIKFeetTraceOld
// Size: 0x40(Inherited: 0x0) 
struct FCalcIKFeetTraceOld
{
	struct FName bpp__Socket__pf;  // 0x0(0x8)
	float bpp__Distance__pf;  // 0x8(0x4)
	struct FVector bpp__OriginalVector__pf;  // 0xC(0xC)
	struct FRotator bpp__OriginalRotation__pf;  // 0x18(0xC)
	char pad_36_1 : 7;  // 0x24(0x1)
	bool bpp__Debugx__pfzy : 1;  // 0x24(0x1)
	char pad_37_1 : 7;  // 0x25(0x1)
	bool bpp__Activex__pfzy : 1;  // 0x25(0x1)
	char pad_38[2];  // 0x26(0x2)
	struct FVector bpp__Vertical__pf;  // 0x28(0xC)
	struct FRotator bpp__Angle__pf;  // 0x34(0xC)

}; 
// Function ABP_Character.ABP_Character_C.CalcRotatorAxisInterp
// Size: 0x10(Inherited: 0x0) 
struct FCalcRotatorAxisInterp
{
	float bpp__Current__pf;  // 0x0(0x4)
	float bpp__Target__pf;  // 0x4(0x4)
	float bpp__Speed__pf;  // 0x8(0x4)
	float bpp__Output__pf;  // 0xC(0x4)

}; 
// Function ABP_Character.ABP_Character_C.CustomPrint
// Size: 0x28(Inherited: 0x0) 
struct FCustomPrint
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bpp__Enablex__pfzy : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FString bpp__Input__pf__const;  // 0x8(0x10)
	struct FLinearColor bpp__Colour__pf;  // 0x18(0x10)

}; 
// Function ABP_Character.ABP_Character_C.CalcVectorInterp
// Size: 0x2C(Inherited: 0x0) 
struct FCalcVectorInterp
{
	struct FVector bpp__Current__pf;  // 0x0(0xC)
	struct FVector bpp__Target__pf;  // 0xC(0xC)
	float bpp__Speed__pf;  // 0x18(0x4)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool bpp__Constant__pf : 1;  // 0x1C(0x1)
	char pad_29[3];  // 0x1D(0x3)
	struct FVector bpp__Output__pf;  // 0x20(0xC)

}; 
// Function ABP_Character.ABP_Character_C.ExecuteUbergraph_ABP_Character_1
// Size: 0x4(Inherited: 0x0) 
struct FExecuteUbergraph_ABP_Character_1
{
	int32_t bpp__EntryPoint__pf;  // 0x0(0x4)

}; 
// Function ABP_Character.ABP_Character_C.ExecuteUbergraph_ABP_Character_68
// Size: 0x4(Inherited: 0x0) 
struct FExecuteUbergraph_ABP_Character_68
{
	int32_t bpp__EntryPoint__pf;  // 0x0(0x4)

}; 
// Function ABP_Character.ABP_Character_C.PlayReaction
// Size: 0x1(Inherited: 0x0) 
struct FPlayReaction
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bpp__Start__pf : 1;  // 0x0(0x1)

}; 
// Function ABP_Character.ABP_Character_C.FindRandomSequence
// Size: 0x18(Inherited: 0x0) 
struct FFindRandomSequence
{
	struct TArray<struct UAnimSequence*> bpp__Array__pf;  // 0x0(0x10)
	struct UAnimSequence* bpp__Sequence__pf;  // 0x10(0x8)

}; 
// Function ABP_Character.ABP_Character_C.GetUnderbarrelAnim
// Size: 0x10(Inherited: 0x0) 
struct FGetUnderbarrelAnim
{
	struct UObject* bpp__UnderbarrelUpgrade__pf__const;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bpp__WeaponMount__pf : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool bpp__ValidAnim__pf : 1;  // 0x9(0x1)
	char pad_10[6];  // 0xA(0x6)

}; 
// Function ABP_Character.ABP_Character_C.SetVehicleUserBoneVisability
// Size: 0x10(Inherited: 0x0) 
struct FSetVehicleUserBoneVisability
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bpp__Gunner__pf : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool bpp__Passenger__pf : 1;  // 0x1(0x1)
	char pad_2[6];  // 0x2(0x6)
	struct USkeletalMeshComponent* bpp__Mesh__pf;  // 0x8(0x8)

}; 
// Function ABP_Character.ABP_Character_C.LerpRotatorAxis
// Size: 0x14(Inherited: 0x0) 
struct FLerpRotatorAxis
{
	float bpp__A__pf;  // 0x0(0x4)
	float bpp__B__pf;  // 0x4(0x4)
	float bpp__Alpha__pf;  // 0x8(0x4)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool bpp__ShortestPathx__pfzy : 1;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)
	float bpp__Output__pf;  // 0x10(0x4)

}; 
// Function ABP_Character.ABP_Character_C.OnDoorKick
// Size: 0x1(Inherited: 0x0) 
struct FOnDoorKick
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bpp__bKickWillSucceed__pf : 1;  // 0x0(0x1)

}; 
// Function ABP_Character.ABP_Character_C.PlayMelee
// Size: 0x1(Inherited: 0x0) 
struct FPlayMelee
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bpp__Bash__pf : 1;  // 0x0(0x1)

}; 
// Function ABP_Character.ABP_Character_C.OnEnteredVehicle
// Size: 0x8(Inherited: 0x0) 
struct FOnEnteredVehicle
{
	struct UVehicleSeatComponent* bpp__VehicleSeat__pf;  // 0x0(0x8)

}; 
// Function ABP_Character.ABP_Character_C.PlayGearShift
// Size: 0x10(Inherited: 0x0) 
struct FPlayGearShift
{
	struct UAnimMontage* bpp__MontageCheck__pf;  // 0x0(0x8)
	struct UAnimMontage* bpp__MontageReference__pf;  // 0x8(0x8)

}; 
// Function ABP_Character.ABP_Character_C.PlayReload
// Size: 0x3(Inherited: 0x0) 
struct FPlayReload
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bpp__ReloadEmpty__pf : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool bpp__SingleLoaded__pf : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool bpp__Ready__pf : 1;  // 0x2(0x1)

}; 
// Function ABP_Character.ABP_Character_C.PrintHelper
// Size: 0x38(Inherited: 0x0) 
struct FPrintHelper
{
	struct FString bpp__Name__pf__const;  // 0x0(0x10)
	struct FString bpp__InputVariable__pf__const;  // 0x10(0x10)
	float bpp__Duration__pf;  // 0x20(0x4)
	struct FLinearColor bpp__TextColor__pf;  // 0x24(0x10)
	char pad_52[4];  // 0x34(0x4)

}; 
// Function ABP_Character.ABP_Character_C.SelectReloadType
// Size: 0x98(Inherited: 0x0) 
struct FSelectReloadType
{
	struct FCharacterAnimReload bpp__Reload__pf__const;  // 0x0(0x78)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool bpp__Empty__pf : 1;  // 0x78(0x1)
	char pad_121_1 : 7;  // 0x79(0x1)
	bool bpp__Single__pf : 1;  // 0x79(0x1)
	char pad_122[6];  // 0x7A(0x6)
	struct UAnimMontage* bpp__xReload__pfT;  // 0x80(0x8)
	struct UAnimSequence* bpp__CommonxPose__pfT;  // 0x88(0x8)
	float bpp__Common__pf;  // 0x90(0x4)
	float bpp__SequenceLength__pf;  // 0x94(0x4)

}; 
// Function ABP_Character.ABP_Character_C.SetEquipable
// Size: 0x8(Inherited: 0x0) 
struct FSetEquipable
{
	struct AItemEquipable* bpp__Item__pf;  // 0x0(0x8)

}; 
// Function ABP_Character.ABP_Character_C.UpdateCharacterBoneHide
// Size: 0x10(Inherited: 0x0) 
struct FUpdateCharacterBoneHide
{
	struct UABP_Character_C* bpp__AnimInstance__pf;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bpp__Gunner__pf : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool bpp__Passenger__pf : 1;  // 0x9(0x1)
	char pad_10[6];  // 0xA(0x6)

}; 
// Function ABP_Character.ABP_Character_C.UpdateDeployed
// Size: 0x1(Inherited: 0x0) 
struct FUpdateDeployed
{
	uint8_t  bpp__State__pf__const;  // 0x0(0x1)

}; 
// Function ABP_Character.ABP_Character_C.UpdateGasmaskReference
// Size: 0x8(Inherited: 0x0) 
struct FUpdateGasmaskReference
{
	struct ABP_Gear_GasMask_C* bpp__Gasmask__pf;  // 0x0(0x8)

}; 
// Function ABP_Character.ABP_Character_C.UpdateGasMaskState
// Size: 0x1(Inherited: 0x0) 
struct FUpdateGasMaskState
{
	uint8_t  bpp__State__pf;  // 0x0(0x1)

}; 
// Function ABP_Character.ABP_Character_C.UpdateGearBoneVisibility
// Size: 0x1(Inherited: 0x0) 
struct FUpdateGearBoneVisibility
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bpp__Visibility__pf : 1;  // 0x0(0x1)

}; 
// Function ABP_Character.ABP_Character_C.UpdateGearCopyPoseAnim
// Size: 0x28(Inherited: 0x0) 
struct FUpdateGearCopyPoseAnim
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bpp__Enable__pf : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool bpp__bProfile__pf : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool bpp__bFemale__pf : 1;  // 0x2(0x1)
	char pad_3[5];  // 0x3(0x5)
	struct USkeletalMeshComponent* bpp__Character__pf;  // 0x8(0x8)
	struct ABP_Gear_BASE_Carrier_C* bpp__Carrier__pf;  // 0x10(0x8)
	uint8_t  bpp__Combination__pf;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)
	struct FName bpp__Faction__pf;  // 0x1C(0x8)
	char pad_36[4];  // 0x24(0x4)

}; 
// Function ABP_Character.ABP_Character_C.UpdateMolotovFlameState
// Size: 0x1(Inherited: 0x0) 
struct FUpdateMolotovFlameState
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bpp__bEnable__pf : 1;  // 0x0(0x1)

}; 
// Function ABP_Character.ABP_Character_C.UpdatEquipmentOnBack
// Size: 0x10(Inherited: 0x0) 
struct FUpdatEquipmentOnBack
{
	struct UINSSkeletalMeshComponent* bpp__Carrier__pf;  // 0x0(0x8)
	struct AINSSoldier* bpp__Soldier__pf;  // 0x8(0x8)

}; 
// Function ABP_Character.ABP_Character_C.ValidAnimBool
// Size: 0x10(Inherited: 0x0) 
struct FValidAnimBool
{
	struct UAnimSequence* bpp__Sequence__pf;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bpp__Valid__pf : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function ABP_Character.ABP_Character_C.VaultRecoveryTimer
// Size: 0x4(Inherited: 0x0) 
struct FVaultRecoveryTimer
{
	float bpp__RecoveryTime__pf;  // 0x0(0x4)

}; 
