#pragma once 
#include <Ammo_9x39_SP5_Tracer_Structs.h>
 
 
 
// DynamicClass Ammo_9x39_SP5_Tracer.Ammo_9x39_SP5_Tracer_C
// Size: 0x2C8(Inherited: 0x2C8) 
struct UAmmo_9x39_SP5_Tracer_C : public UAmmoTypeBallistic
{

}; 



