#pragma once 
#include <Ammo_127x108_AM_Tracer_Structs.h>
 
 
 
// DynamicClass Ammo_127x108_AM_Tracer.Ammo_127x108_AM_Tracer_C
// Size: 0x2C8(Inherited: 0x2C8) 
struct UAmmo_127x108_AM_Tracer_C : public UAmmo_127x108_Tracer_C
{

}; 



