#pragma once 
#include <Ammo_4GA_Flechette_Structs.h>
 
 
 
// DynamicClass Ammo_4GA_Flechette.Ammo_4GA_Flechette_C
// Size: 0x2C8(Inherited: 0x2C8) 
struct UAmmo_4GA_Flechette_C : public UAmmo_12GA_C
{

}; 



