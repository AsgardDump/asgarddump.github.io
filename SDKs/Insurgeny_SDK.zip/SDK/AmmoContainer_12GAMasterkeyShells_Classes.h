#pragma once 
#include <AmmoContainer_12GAMasterkeyShells_Structs.h>
 
 
 
// BlueprintGeneratedClass AmmoContainer_12GAMasterkeyShells.AmmoContainer_12GAMasterkeyShells_C
// Size: 0x170(Inherited: 0x170) 
struct UAmmoContainer_12GAMasterkeyShells_C : public UAmmoContainer
{

}; 



