#pragma once 
#include <AmmoContainer_35mmCaselessHE_Structs.h>
 
 
 
// BlueprintGeneratedClass AmmoContainer_35mmCaselessHE.AmmoContainer_35mmCaselessHE_C
// Size: 0x170(Inherited: 0x170) 
struct UAmmoContainer_35mmCaselessHE_C : public UAmmoContainer
{

}; 



