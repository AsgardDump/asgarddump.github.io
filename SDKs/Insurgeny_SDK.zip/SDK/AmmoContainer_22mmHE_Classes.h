#pragma once 
#include <AmmoContainer_22mmHE_Structs.h>
 
 
 
// BlueprintGeneratedClass AmmoContainer_22mmHE.AmmoContainer_22mmHE_C
// Size: 0x170(Inherited: 0x170) 
struct UAmmoContainer_22mmHE_C : public UAmmoContainer
{

}; 



