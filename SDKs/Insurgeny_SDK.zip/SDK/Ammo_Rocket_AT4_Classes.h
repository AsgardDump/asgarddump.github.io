#pragma once 
#include <Ammo_Rocket_AT4_Structs.h>
 
 
 
// DynamicClass Ammo_Rocket_AT4.Ammo_Rocket_AT4_C
// Size: 0x2C8(Inherited: 0x2C8) 
struct UAmmo_Rocket_AT4_C : public UAmmoTypeBallistic
{

}; 



