#pragma once 
#include "SDK.h" 
 
 
// Function ABP_Weapon_Revolver.ABP_Weapon_Revolver_C.AnimGraph
// Size: 0x20(Inherited: 0x0) 
struct FAnimGraph
{
	struct FPoseLink bpp__InPose__pf;  // 0x0(0x10)
	struct FPoseLink bpp__AnimGraph__pf;  // 0x10(0x10)

}; 
// Function ABP_Weapon_Revolver.ABP_Weapon_Revolver_C.InterfaceUpdateSimulationBlend
// Size: 0x4(Inherited: 0x0) 
struct FInterfaceUpdateSimulationBlend
{
	float bpp__State__pf;  // 0x0(0x4)

}; 
// Function ABP_Weapon_Revolver.ABP_Weapon_Revolver_C.BlueprintUpdateAnimation
// Size: 0x4(Inherited: 0x0) 
struct FBlueprintUpdateAnimation
{
	float bpp__DeltaTimeX__pf;  // 0x0(0x4)

}; 
// Function ABP_Weapon_Revolver.ABP_Weapon_Revolver_C.ExecuteUbergraph_ABP_Weapon_Revolver_1
// Size: 0x4(Inherited: 0x0) 
struct FExecuteUbergraph_ABP_Weapon_Revolver_1
{
	int32_t bpp__EntryPoint__pf;  // 0x0(0x4)

}; 
// Function ABP_Weapon_Revolver.ABP_Weapon_Revolver_C.ForceChamber
// Size: 0x18(Inherited: 0x0) 
struct FForceChamber
{
	struct TArray<float> bpp__Array__pf;  // 0x0(0x10)
	float bpp__Value__pf__const;  // 0x10(0x4)
	int32_t bpp__RemainingxAmmo__pfT;  // 0x14(0x4)

}; 
// Function ABP_Weapon_Revolver.ABP_Weapon_Revolver_C.ToggleOpticState
// Size: 0x1(Inherited: 0x0) 
struct FToggleOpticState
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bpp__Enable__pf : 1;  // 0x0(0x1)

}; 
// Function ABP_Weapon_Revolver.ABP_Weapon_Revolver_C.ForceRevolverChamberVisibility
// Size: 0x4(Inherited: 0x0) 
struct FForceRevolverChamberVisibility
{
	int32_t bpp__RemainingAmmo__pf;  // 0x0(0x4)

}; 
// Function ABP_Weapon_Revolver.ABP_Weapon_Revolver_C.ForceToggleOpticState
// Size: 0x1(Inherited: 0x0) 
struct FForceToggleOpticState
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bpp__bEnable__pf : 1;  // 0x0(0x1)

}; 
// Function ABP_Weapon_Revolver.ABP_Weapon_Revolver_C.UpdateRevolverChamberState
// Size: 0x10(Inherited: 0x0) 
struct FUpdateRevolverChamberState
{
	struct TArray<uint8_t > bpp__Chambers__pf__const;  // 0x0(0x10)

}; 
