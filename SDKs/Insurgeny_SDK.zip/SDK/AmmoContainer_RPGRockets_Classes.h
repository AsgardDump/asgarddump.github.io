#pragma once 
#include <AmmoContainer_RPGRockets_Structs.h>
 
 
 
// BlueprintGeneratedClass AmmoContainer_RPGRockets.AmmoContainer_RPGRockets_C
// Size: 0x170(Inherited: 0x170) 
struct UAmmoContainer_RPGRockets_C : public UAmmoContainer
{

}; 



