#pragma once 
#include <AmmoMagazine_FAL_Damascus_Box_20RD_Structs.h>
 
 
 
// BlueprintGeneratedClass AmmoMagazine_FAL_Damascus_Box_20RD.AmmoMagazine_FAL_Damascus_Box_20RD_C
// Size: 0x178(Inherited: 0x178) 
struct UAmmoMagazine_FAL_Damascus_Box_20RD_C : public UAmmoMagazine_FALBox_20RD_C
{

}; 



