#pragma once 
#include <ABP_PP_OKP_Structs.h>
 
 
 
// DynamicClass ABP_PP_OKP.ABP_PP_OKP_C
// Size: 0x5B0(Inherited: 0x2C0) 
struct UABP_PP_OKP_C : public UAnimInstance
{
	struct FAnimNode_Root AnimGraphNode_Root;  // 0x2B8(0x30)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone;  // 0x2E8(0x108)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace;  // 0x3F0(0x20)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace;  // 0x410(0x20)
	struct FAnimNode_LinkedInputPose AnimGraphNode_SubInput;  // 0x430(0x118)
	float SightFraction;  // 0x548(0x4)
	struct FRotator LenseRotationCorrection;  // 0x54C(0xC)
	float K2Node_Event_DeltaTimeX;  // 0x558(0x4)
	struct ABP_Character_Player_C* K2Node_DynamicCast_AsBP_Character_Player;  // 0x560(0x8)
	char pad_1388_1 : 7;  // 0x56C(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x568(0x1)
	char pad_1389[3];  // 0x56D(0x3)
	struct AItemFirearm* K2Node_DynamicCast_AsItem_Firearm;  // 0x570(0x8)
	char pad_1400_1 : 7;  // 0x578(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x578(0x1)
	char pad_1401[3];  // 0x579(0x3)
	struct FVector CallFunc_BreakTransform_Location;  // 0x57C(0xC)
	struct FRotator CallFunc_BreakTransform_Rotation;  // 0x588(0xC)
	struct FVector CallFunc_BreakTransform_Scale;  // 0x594(0xC)
	float CallFunc_BreakRotator_Roll;  // 0x5A0(0x4)
	float CallFunc_BreakRotator_Pitch;  // 0x5A4(0x4)
	float CallFunc_BreakRotator_Yaw;  // 0x5A8(0x4)
	char pad_1452[4];  // 0x5AC(0x4)

	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_PP_OKP_AnimGraphNode_ModifyBone_8F54072C4C5BB953CBB7789A50B122A8(); // Function ABP_PP_OKP.ABP_PP_OKP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_PP_OKP_AnimGraphNode_ModifyBone_8F54072C4C5BB953CBB7789A50B122A8
	void BlueprintUpdateAnimation(float bpp__DeltaTimeX__pf); // Function ABP_PP_OKP.ABP_PP_OKP_C.BlueprintUpdateAnimation
	void AnimGraph(struct FPoseLink bpp__InPose__pf, struct FPoseLink& bpp__AnimGraph__pf); // Function ABP_PP_OKP.ABP_PP_OKP_C.AnimGraph
}; 



