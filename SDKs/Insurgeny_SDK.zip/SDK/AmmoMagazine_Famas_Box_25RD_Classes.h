#pragma once 
#include <AmmoMagazine_Famas_Box_25RD_Structs.h>
 
 
 
// BlueprintGeneratedClass AmmoMagazine_Famas_Box_25RD.AmmoMagazine_Famas_Box_25RD_C
// Size: 0x178(Inherited: 0x178) 
struct UAmmoMagazine_Famas_Box_25RD_C : public UAmmoContainerMagazine
{

}; 



