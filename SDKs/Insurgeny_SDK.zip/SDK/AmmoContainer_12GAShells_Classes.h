#pragma once 
#include <AmmoContainer_12GAShells_Structs.h>
 
 
 
// BlueprintGeneratedClass AmmoContainer_12GAShells.AmmoContainer_12GAShells_C
// Size: 0x170(Inherited: 0x170) 
struct UAmmoContainer_12GAShells_C : public UAmmoContainer
{

}; 



