#pragma once 
#include <AmmoContainer_GAU8_Belt_Structs.h>
 
 
 
// BlueprintGeneratedClass AmmoContainer_GAU8_Belt.AmmoContainer_GAU8_Belt_C
// Size: 0x178(Inherited: 0x178) 
struct UAmmoContainer_GAU8_Belt_C : public UAmmoContainerMagazine
{

}; 



