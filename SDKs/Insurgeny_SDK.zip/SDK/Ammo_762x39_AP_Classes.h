#pragma once 
#include <Ammo_762x39_AP_Structs.h>
 
 
 
// DynamicClass Ammo_762x39_AP.Ammo_762x39_AP_C
// Size: 0x2C8(Inherited: 0x2C8) 
struct UAmmo_762x39_AP_C : public UAmmo_762x39_C
{

}; 



