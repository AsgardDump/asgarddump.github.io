#pragma once 
#include <Ammo_57x28_Structs.h>
 
 
 
// DynamicClass Ammo_57x28.Ammo_57x28_C
// Size: 0x2C8(Inherited: 0x2C8) 
struct UAmmo_57x28_C : public UAmmoTypeBallistic
{

}; 



