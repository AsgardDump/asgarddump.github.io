#pragma once 
#include <ABP_Character_Body_Structs.h>
 
 
 
// DynamicClass ABP_Character_Body.ABP_Character_Body_C
// Size: 0x7B0(Inherited: 0x2C0) 
struct UABP_Character_Body_C : public UAnimInstance
{
	struct FAnimNode_Root AnimGraphNode_Root;  // 0x2B8(0x30)
	struct FAnimNode_RefPose AnimGraphNode_LocalRefPose;  // 0x2E8(0x18)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_3;  // 0x300(0x108)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace;  // 0x408(0x20)
	struct FAnimNode_Slot AnimGraphNode_Slot;  // 0x428(0x48)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_2;  // 0x470(0x108)
	struct FAnimNode_RotateRootBone AnimGraphNode_RotateRootBone;  // 0x578(0xA0)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace;  // 0x618(0x20)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone;  // 0x638(0x108)
	char pad_1864_1 : 7;  // 0x748(0x1)
	bool bSoldierValid : 1;  // 0x740(0x1)
	struct USkeletalMeshComponent* CharacterMesh;  // 0x748(0x8)
	float Kick;  // 0x750(0x4)
	float DirectionYaw;  // 0x754(0x4)
	struct UAnimMontage* KickMontage;  // 0x758(0x8)
	struct AINSSoldier* SoldierReference;  // 0x760(0x8)
	float KickTimerStart;  // 0x768(0x4)
	float Time;  // 0x76C(0x4)
	float NewVar_1;  // 0x770(0x4)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x774(0x10)
	char pad_1925[3];  // 0x785(0x3)
	struct UABP_Character_C* K2Node_DynamicCast_AsABP_Character;  // 0x788(0x8)
	char pad_1936_1 : 7;  // 0x790(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x790(0x1)
	char pad_1937[3];  // 0x791(0x3)
	float K2Node_Event_DeltaTimeX;  // 0x794(0x4)
	struct AINSSoldier* K2Node_DynamicCast_AsINSSoldier;  // 0x798(0x8)
	char pad_1952_1 : 7;  // 0x7A0(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x7A0(0x1)
	char pad_1953_1 : 7;  // 0x7A1(0x1)
	bool K2Node_CustomEvent_bKickWillSucceed : 1;  // 0x7A1(0x1)
	char pad_1954_1 : 7;  // 0x7A2(0x1)
	bool Temp_bool_IsClosed_Variable : 1;  // 0x7A2(0x1)
	char pad_1955_1 : 7;  // 0x7A3(0x1)
	bool Temp_bool_Has_Been_Initd_Variable : 1;  // 0x7A3(0x1)
	char pad_1956[12];  // 0x7A4(0xC)

	void OnDoorKick(bool bpp__bKickWillSucceed__pf); // Function ABP_Character_Body.ABP_Character_Body_C.OnDoorKick
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Character_Body_AnimGraphNode_RotateRootBone_EB249B944762605806E16EA0C6EC4DB0(); // Function ABP_Character_Body.ABP_Character_Body_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Character_Body_AnimGraphNode_RotateRootBone_EB249B944762605806E16EA0C6EC4DB0
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Character_Body_AnimGraphNode_ModifyBone_6212B5D24D30DCA34CF0A0A8815B5105(); // Function ABP_Character_Body.ABP_Character_Body_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Character_Body_AnimGraphNode_ModifyBone_6212B5D24D30DCA34CF0A0A8815B5105
	void BlueprintUpdateAnimation(float bpp__DeltaTimeX__pf); // Function ABP_Character_Body.ABP_Character_Body_C.BlueprintUpdateAnimation
	void AnimGraph(struct FPoseLink& bpp__AnimGraph__pf); // Function ABP_Character_Body.ABP_Character_Body_C.AnimGraph
	void DelegateDoorKick__DelegateSignature(bool bpp__bKickWillSucceed__pf); // DelegateFunction ABP_Character_Body.ABP_Character_Body_C.DelegateDoorKick__DelegateSignature
}; 



