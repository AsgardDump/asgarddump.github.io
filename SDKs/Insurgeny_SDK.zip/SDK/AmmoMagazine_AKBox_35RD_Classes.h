#pragma once 
#include <AmmoMagazine_AKBox_35RD_Structs.h>
 
 
 
// BlueprintGeneratedClass AmmoMagazine_AKBox_35RD.AmmoMagazine_AKBox_35RD_C
// Size: 0x178(Inherited: 0x178) 
struct UAmmoMagazine_AKBox_35RD_C : public UAmmoMagazine_AKBox_30RD_C
{

}; 



