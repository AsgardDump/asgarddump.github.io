#pragma once 
#include <ABP_PP_Molotov_Rag_Structs.h>
 
 
 
// DynamicClass ABP_PP_Molotov_Rag.ABP_PP_Molotov_Rag_C
// Size: 0x2A90(Inherited: 0x20A0) 
struct UABP_PP_Molotov_Rag_C : public UFirstPersonAnimInstance
{
	char pad_8352[8];  // 0x20A0(0x8)
	struct FAnimNode_Root AnimGraphNode_Root;  // 0x20A8(0x30)
	struct FAnimNode_LinkedInputPose AnimGraphNode_SubInput;  // 0x20D8(0x118)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace;  // 0x21F0(0x20)
	struct FAnimNode_RigidBody AnimGraphNode_RigidBody;  // 0x2210(0x830)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace;  // 0x2A40(0x20)
	float SimulationBlendTimer;  // 0x2A60(0x4)
	char pad_10852_1 : 7;  // 0x2A64(0x1)
	bool bEnableBlend : 1;  // 0x2A64(0x1)
	char pad_10853_1 : 7;  // 0x2A65(0x1)
	bool K2Node_Event_bEnable : 1;  // 0x2A65(0x1)
	char pad_10854[2];  // 0x2A66(0x2)
	struct TArray<uint8_t > K2Node_Event_Chambers;  // 0x2A68(0x10)
	int32_t K2Node_Event_RemainingAmmo;  // 0x2A78(0x4)
	float K2Node_Event_State;  // 0x2A7C(0x4)
	float K2Node_Event_DeltaTimeX;  // 0x2A80(0x4)
	char pad_10884_1 : 7;  // 0x2A84(0x1)
	bool K2Node_Event_Enable : 1;  // 0x2A84(0x1)
	char pad_10885[11];  // 0x2A85(0xB)

	void UpdateRevolverChamberState(struct TArray<uint8_t >& bpp__Chambers__pf__const); // Function ABP_PP_Molotov_Rag.ABP_PP_Molotov_Rag_C.UpdateRevolverChamberState
	void ToggleOpticState(bool bpp__Enable__pf); // Function ABP_PP_Molotov_Rag.ABP_PP_Molotov_Rag_C.ToggleOpticState
	void StopToggleOpticMontage(); // Function ABP_PP_Molotov_Rag.ABP_PP_Molotov_Rag_C.StopToggleOpticMontage
	void InterfaceUpdateSimulationBlend(float bpp__State__pf); // Function ABP_PP_Molotov_Rag.ABP_PP_Molotov_Rag_C.InterfaceUpdateSimulationBlend
	void ForceToggleOpticState(bool bpp__bEnable__pf); // Function ABP_PP_Molotov_Rag.ABP_PP_Molotov_Rag_C.ForceToggleOpticState
	void ForceRevolverChamberVisibility(int32_t bpp__RemainingAmmo__pf); // Function ABP_PP_Molotov_Rag.ABP_PP_Molotov_Rag_C.ForceRevolverChamberVisibility
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_PP_Molotov_Rag_AnimGraphNode_RigidBody_46408E8E46C06493F82086BF108B4027(); // Function ABP_PP_Molotov_Rag.ABP_PP_Molotov_Rag_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_PP_Molotov_Rag_AnimGraphNode_RigidBody_46408E8E46C06493F82086BF108B4027
	void BlueprintUpdateAnimation(float bpp__DeltaTimeX__pf); // Function ABP_PP_Molotov_Rag.ABP_PP_Molotov_Rag_C.BlueprintUpdateAnimation
	void BlueprintInitializeAnimation(); // Function ABP_PP_Molotov_Rag.ABP_PP_Molotov_Rag_C.BlueprintInitializeAnimation
	void AnimGraph(struct FPoseLink bpp__InPose__pf, struct FPoseLink& bpp__AnimGraph__pf); // Function ABP_PP_Molotov_Rag.ABP_PP_Molotov_Rag_C.AnimGraph
}; 



