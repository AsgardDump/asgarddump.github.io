#pragma once 
#include <AmmoMagazine_AR15_NocturneBlue_Box_35RD_Structs.h>
 
 
 
// BlueprintGeneratedClass AmmoMagazine_AR15_NocturneBlue_Box_35RD.AmmoMagazine_AR15_NocturneBlue_Box_35RD_C
// Size: 0x178(Inherited: 0x178) 
struct UAmmoMagazine_AR15_NocturneBlue_Box_35RD_C : public UAmmoMagazine_AR15_Box_35RD_C
{

}; 



