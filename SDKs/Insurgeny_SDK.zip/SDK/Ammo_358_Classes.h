#pragma once 
#include <Ammo_358_Structs.h>
 
 
 
// DynamicClass Ammo_358.Ammo_357_C
// Size: 0x2C8(Inherited: 0x2C8) 
struct UAmmo_357_C : public UAmmoTypeBallistic
{

}; 



