#pragma once 
#include <AmmoContainer_40mmCaselessSmoke_Structs.h>
 
 
 
// BlueprintGeneratedClass AmmoContainer_40mmCaselessSmoke.AmmoContainer_40mmCaselessSmoke_C
// Size: 0x170(Inherited: 0x170) 
struct UAmmoContainer_40mmCaselessSmoke_C : public UAmmoContainer
{

}; 



