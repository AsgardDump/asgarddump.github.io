#pragma once 
#include <Ammo_50BMG_Structs.h>
 
 
 
// DynamicClass Ammo_50BMG.Ammo_50BMG_C
// Size: 0x2C8(Inherited: 0x2C8) 
struct UAmmo_50BMG_C : public UAmmoTypeBallistic
{

}; 



