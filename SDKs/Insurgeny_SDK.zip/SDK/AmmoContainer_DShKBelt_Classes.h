#pragma once 
#include <AmmoContainer_DShKBelt_Structs.h>
 
 
 
// BlueprintGeneratedClass AmmoContainer_DShKBelt.AmmoContainer_DShKBelt_C
// Size: 0x178(Inherited: 0x178) 
struct UAmmoContainer_DShKBelt_C : public UAmmoContainerMagazine
{

}; 



