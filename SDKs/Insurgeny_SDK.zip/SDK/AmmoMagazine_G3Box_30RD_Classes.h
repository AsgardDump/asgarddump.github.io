#pragma once 
#include <AmmoMagazine_G3Box_30RD_Structs.h>
 
 
 
// BlueprintGeneratedClass AmmoMagazine_G3Box_30RD.AmmoMagazine_G3Box_30RD_C
// Size: 0x178(Inherited: 0x178) 
struct UAmmoMagazine_G3Box_30RD_C : public UAmmoContainerMagazine
{

}; 



