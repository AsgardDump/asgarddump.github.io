#pragma once 
#include <Ammo_127x108_AM_Structs.h>
 
 
 
// DynamicClass Ammo_127x108_AM.Ammo_127x108_AM_C
// Size: 0x2C8(Inherited: 0x2C8) 
struct UAmmo_127x108_AM_C : public UAmmo_127x108_C
{

}; 



