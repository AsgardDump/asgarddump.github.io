#pragma once 
#include <AmmoMagazine_AR15_DesertHex_Box_30RD_Structs.h>
 
 
 
// BlueprintGeneratedClass AmmoMagazine_AR15_DesertHex_Box_30RD.AmmoMagazine_AR15_DesertHex_Box_30RD_C
// Size: 0x178(Inherited: 0x178) 
struct UAmmoMagazine_AR15_DesertHex_Box_30RD_C : public UAmmoMagazine_AR15_Box_30RD_C
{

}; 



