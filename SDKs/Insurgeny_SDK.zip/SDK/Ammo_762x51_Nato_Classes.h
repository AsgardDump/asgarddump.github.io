#pragma once 
#include <Ammo_762x51_Nato_Structs.h>
 
 
 
// DynamicClass Ammo_762x51_Nato.Ammo_762x51_Nato_C
// Size: 0x2C8(Inherited: 0x2C8) 
struct UAmmo_762x51_Nato_C : public UAmmo_762x51_C
{

}; 



