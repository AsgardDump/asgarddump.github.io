#pragma once 
#include <Ammo_12GA_Structs.h>
 
 
 
// DynamicClass Ammo_12GA.Ammo_12GA_C
// Size: 0x2C8(Inherited: 0x2C8) 
struct UAmmo_12GA_C : public UAmmoTypeBallistic
{

}; 



