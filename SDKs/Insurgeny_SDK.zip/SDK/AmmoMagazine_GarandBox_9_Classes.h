#pragma once 
#include <AmmoMagazine_GarandBox_9_Structs.h>
 
 
 
// BlueprintGeneratedClass AmmoMagazine_GarandBox_9.AmmoMagazine_GarandBox_8_C
// Size: 0x178(Inherited: 0x178) 
struct UAmmoMagazine_GarandBox_8_C : public UAmmoContainerMagazine
{

}; 



