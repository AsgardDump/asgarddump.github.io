#pragma once 
#include <Ammo_9x39_SP5_Structs.h>
 
 
 
// DynamicClass Ammo_9x39_SP5.Ammo_9x39_SP5_C
// Size: 0x2C8(Inherited: 0x2C8) 
struct UAmmo_9x39_SP5_C : public UAmmoTypeBallistic
{

}; 



