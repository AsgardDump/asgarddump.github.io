#pragma once 
#include <Ammo_50BMG_AM_Tracer_Structs.h>
 
 
 
// DynamicClass Ammo_50BMG_AM_Tracer.Ammo_50BMG_AM_Tracer_C
// Size: 0x2C8(Inherited: 0x2C8) 
struct UAmmo_50BMG_AM_Tracer_C : public UAmmo_50BMG_Tracer_C
{

}; 



