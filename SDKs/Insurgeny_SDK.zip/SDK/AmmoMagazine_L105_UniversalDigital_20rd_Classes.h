#pragma once 
#include <AmmoMagazine_L105_UniversalDigital_20rd_Structs.h>
 
 
 
// BlueprintGeneratedClass AmmoMagazine_L105_UniversalDigital_20rd.AmmoMagazine_L105_UniversalDigital_20rd_C
// Size: 0x178(Inherited: 0x178) 
struct UAmmoMagazine_L105_UniversalDigital_20rd_C : public UAmmoMagazine_L105_20RD_C
{

}; 



