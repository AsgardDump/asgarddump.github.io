#pragma once 
#include <BPI_UI_PostMatchScreen_SubScreen_Structs.h>
 
 
 
// BlueprintGeneratedClass BPI_UI_PostMatchScreen_SubScreen.BPI_UI_PostMatchScreen_SubScreen_C
// Size: 0x28(Inherited: 0x28) 
struct UBPI_UI_PostMatchScreen_SubScreen_C : public UInterface
{

	void GetFadeOutAnimation(bool bFadeOutLeft, struct UWidgetAnimation*& FadeOutAnimation); // Function BPI_UI_PostMatchScreen_SubScreen.BPI_UI_PostMatchScreen_SubScreen_C.GetFadeOutAnimation
	void GetFadeInAnimation(struct UWidgetAnimation*& FadeInAnimation); // Function BPI_UI_PostMatchScreen_SubScreen.BPI_UI_PostMatchScreen_SubScreen_C.GetFadeInAnimation
	void LeaveSubscreen(); // Function BPI_UI_PostMatchScreen_SubScreen.BPI_UI_PostMatchScreen_SubScreen_C.LeaveSubscreen
	void EnterSubscreen(); // Function BPI_UI_PostMatchScreen_SubScreen.BPI_UI_PostMatchScreen_SubScreen_C.EnterSubscreen
	void PrepareScreen(struct FTigerMatchStats& MatchStats, struct UTBP_UI_PostMatchScreen_C* PostMatchScreen); // Function BPI_UI_PostMatchScreen_SubScreen.BPI_UI_PostMatchScreen_SubScreen_C.PrepareScreen
	void ShouldBeShown(struct FTigerMatchStats& TigerMatchStats, bool& bShouldShow); // Function BPI_UI_PostMatchScreen_SubScreen.BPI_UI_PostMatchScreen_SubScreen_C.ShouldBeShown
}; 



