#pragma once 
#include "SDK.h" 
 
 
// Function BPI_UI_ChatWindow.BPI_UI_ChatWindow_C.AddMessage
// Size: 0x58(Inherited: 0x0) 
struct FAddMessage
{
	struct FTigerChatMessage InChatMessage;  // 0x0(0x58)

}; 
// Function BPI_UI_ChatWindow.BPI_UI_ChatWindow_C.OnMessageNameHovered
// Size: 0x58(Inherited: 0x0) 
struct FOnMessageNameHovered
{
	struct FTigerChatMessage InChatData;  // 0x0(0x58)

}; 
// Function BPI_UI_ChatWindow.BPI_UI_ChatWindow_C.OnBanStatusChanged
// Size: 0x18(Inherited: 0x0) 
struct FOnBanStatusChanged
{
	struct FTigerMuteInfo InMuteInfo;  // 0x0(0x18)

}; 
