#pragma once 
#include <Crossbow_Gas_Cloud_4_Structs.h>
 
 
 
// BlueprintGeneratedClass Crossbow_Gas_Cloud_4.Crossbow_Gas_Cloud_3_C
// Size: 0x500(Inherited: 0x4F8) 
struct ACrossbow_Gas_Cloud_3_C : public ATigerAreaEffect
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x4F8(0x8)

	void OnTriggerClient(); // Function Crossbow_Gas_Cloud_4.Crossbow_Gas_Cloud_3_C.OnTriggerClient
	void OnVehicleHit(struct AActor* InActor); // Function Crossbow_Gas_Cloud_4.Crossbow_Gas_Cloud_3_C.OnVehicleHit
	void ReceiveBeginPlay(); // Function Crossbow_Gas_Cloud_4.Crossbow_Gas_Cloud_3_C.ReceiveBeginPlay
	void ExecuteUbergraph_Crossbow_Gas_Cloud_4(int32_t EntryPoint); // Function Crossbow_Gas_Cloud_4.Crossbow_Gas_Cloud_3_C.ExecuteUbergraph_Crossbow_Gas_Cloud_4
}; 



