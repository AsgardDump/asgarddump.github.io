#pragma once 
#include <ChaosCloth_Structs.h>
 
 
 
// Class ChaosCloth.ChaosClothConfig
// Size: 0xB0(Inherited: 0x28) 
struct UChaosClothConfig : public UClothConfigCommon
{
	uint8_t  MassMode;  // 0x28(0x1)
	char pad_41[3];  // 0x29(0x3)
	float UniformMass;  // 0x2C(0x4)
	float TotalMass;  // 0x30(0x4)
	float Density;  // 0x34(0x4)
	float MinPerParticleMass;  // 0x38(0x4)
	float EdgeStiffness;  // 0x3C(0x4)
	float BendingStiffness;  // 0x40(0x4)
	char pad_68_1 : 7;  // 0x44(0x1)
	bool bUseBendingElements : 1;  // 0x44(0x1)
	char pad_69[3];  // 0x45(0x3)
	float AreaStiffness;  // 0x48(0x4)
	float VolumeStiffness;  // 0x4C(0x4)
	float StrainLimitingStiffness;  // 0x50(0x4)
	float LimitScale;  // 0x54(0x4)
	uint8_t  TetherMode;  // 0x58(0x1)
	char pad_89_1 : 7;  // 0x59(0x1)
	bool bUseGeodesicDistance : 1;  // 0x59(0x1)
	char pad_90[2];  // 0x5A(0x2)
	float ShapeTargetStiffness;  // 0x5C(0x4)
	float CollisionThickness;  // 0x60(0x4)
	float FrictionCoefficient;  // 0x64(0x4)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool bUseSelfCollisions : 1;  // 0x68(0x1)
	char pad_105[3];  // 0x69(0x3)
	float SelfCollisionThickness;  // 0x6C(0x4)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool bUseLegacyBackstop : 1;  // 0x70(0x1)
	char pad_113[3];  // 0x71(0x3)
	float DampingCoefficient;  // 0x74(0x4)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool bUsePointBasedWindModel : 1;  // 0x78(0x1)
	char pad_121[3];  // 0x79(0x3)
	float DragCoefficient;  // 0x7C(0x4)
	float LiftCoefficient;  // 0x80(0x4)
	char pad_132_1 : 7;  // 0x84(0x1)
	bool bUseGravityOverride : 1;  // 0x84(0x1)
	char pad_133[3];  // 0x85(0x3)
	float GravityScale;  // 0x88(0x4)
	struct FVector Gravity;  // 0x8C(0xC)
	float AnimDriveSpringStiffness;  // 0x98(0x4)
	struct FVector LinearVelocityScale;  // 0x9C(0xC)
	float AngularVelocityScale;  // 0xA8(0x4)
	char pad_172_1 : 7;  // 0xAC(0x1)
	bool bUseTetrahedralConstraints : 1;  // 0xAC(0x1)
	char pad_173_1 : 7;  // 0xAD(0x1)
	bool bUseThinShellVolumeConstraints : 1;  // 0xAD(0x1)
	char pad_174_1 : 7;  // 0xAE(0x1)
	bool bUseContinuousCollisionDetection : 1;  // 0xAE(0x1)
	char pad_175[1];  // 0xAF(0x1)

}; 



// Class ChaosCloth.ChaosClothingSimulationInteractor
// Size: 0x58(Inherited: 0x30) 
struct UChaosClothingSimulationInteractor : public UClothingSimulationInteractor
{
	char pad_48[40];  // 0x30(0x28)

}; 



// Class ChaosCloth.ChaosClothingSimulationFactory
// Size: 0x28(Inherited: 0x28) 
struct UChaosClothingSimulationFactory : public UClothingSimulationFactory
{

}; 



// Class ChaosCloth.ChaosClothSharedSimConfig
// Size: 0x58(Inherited: 0x28) 
struct UChaosClothSharedSimConfig : public UClothSharedConfigCommon
{
	int32_t IterationCount;  // 0x28(0x4)
	int32_t SubdivisionCount;  // 0x2C(0x4)
	float SelfCollisionThickness;  // 0x30(0x4)
	float CollisionThickness;  // 0x34(0x4)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool bUseDampingOverride : 1;  // 0x38(0x1)
	char pad_57[3];  // 0x39(0x3)
	float Damping;  // 0x3C(0x4)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool bUseGravityOverride : 1;  // 0x40(0x1)
	char pad_65[3];  // 0x41(0x3)
	float GravityScale;  // 0x44(0x4)
	struct FVector Gravity;  // 0x48(0xC)
	char pad_84_1 : 7;  // 0x54(0x1)
	bool bUseLocalSpaceSimulation : 1;  // 0x54(0x1)
	char pad_85_1 : 7;  // 0x55(0x1)
	bool bUseXPBDConstraints : 1;  // 0x55(0x1)
	char pad_86[2];  // 0x56(0x2)

}; 



