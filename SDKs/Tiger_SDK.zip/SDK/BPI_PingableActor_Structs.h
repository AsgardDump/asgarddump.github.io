#pragma once 
#include "SDK.h" 
 
 
// Function BPI_PingableActor.BPI_PingableActor_C.GetPingCategory
// Size: 0x8(Inherited: 0x0) 
struct FGetPingCategory
{
	struct FName OutCategory;  // 0x0(0x8)

}; 
// Function BPI_PingableActor.BPI_PingableActor_C.GetPingInfo
// Size: 0x18(Inherited: 0x0) 
struct FGetPingInfo
{
	struct FTS_PingableActorInfo OutInfo;  // 0x0(0x18)

}; 
