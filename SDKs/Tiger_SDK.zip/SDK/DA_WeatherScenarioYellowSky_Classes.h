#pragma once 
#include <DA_WeatherScenarioYellowSky_Structs.h>
 
 
 
// BlueprintGeneratedClass DA_WeatherScenarioYellowSky.DA_WeatherScenarioYellowSky_C
// Size: 0x18C(Inherited: 0x18C) 
struct UDA_WeatherScenarioYellowSky_C : public UDA_WeatherScenario_C
{

}; 



