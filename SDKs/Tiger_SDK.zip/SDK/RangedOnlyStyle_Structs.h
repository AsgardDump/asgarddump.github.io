#pragma once 
#include "SDK.h" 
 
 
// Function RangedOnlyStyle.RangedOnlyStyle_C.DetermineNextWeaponSlot
// Size: 0x13(Inherited: 0x10) 
struct FDetermineNextWeaponSlot : public FDetermineNextWeaponSlot
{
	struct ATigerPlayerController* InPlayerController;  // 0x0(0x8)
	uint8_t  InDirection;  // 0x8(0x1)
	uint8_t  ReturnValue;  // 0x9(0x1)
	uint8_t  CallFunc_GetCurrentlyEquippedSlot_ReturnValue;  // 0xA(0x1)
	char pad_27_1 : 7;  // 0x1B(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // 0xB(0x1)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool CallFunc_HasWeaponForSlot_ReturnValue : 1;  // 0xC(0x1)
	uint8_t  CallFunc_GetCurrentlyEquippedSlot_ReturnValue_2;  // 0xD(0x1)
	char pad_30_1 : 7;  // 0x1E(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_2 : 1;  // 0xE(0x1)
	char pad_31_1 : 7;  // 0x1F(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_3 : 1;  // 0xF(0x1)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_BooleanOR_ReturnValue : 1;  // 0x10(0x1)
	char pad_33_1 : 7;  // 0x21(0x1)
	bool CallFunc_HasWeaponForSlot_ReturnValue_2 : 1;  // 0x11(0x1)
	char pad_34_1 : 7;  // 0x22(0x1)
	bool CallFunc_HasWeaponForSlot_ReturnValue_3 : 1;  // 0x12(0x1)

}; 
