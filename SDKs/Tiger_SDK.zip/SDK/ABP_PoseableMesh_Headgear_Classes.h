#pragma once 
#include <ABP_PoseableMesh_Headgear_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass ABP_PoseableMesh_Headgear.ABP_PoseableMesh_Headgear_C
// Size: 0x5A8(Inherited: 0x330) 
struct UABP_PoseableMesh_Headgear_C : public UTigerCharacterPoseableMeshAnimInstance
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x330(0x8)
	struct FAnimNode_Root AnimGraphNode_Root;  // 0x338(0x30)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace;  // 0x368(0x20)
	struct FAnimNode_MeshSpaceRefPose AnimGraphNode_MeshRefPose;  // 0x388(0x10)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_2;  // 0x398(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone;  // 0x4A0(0x108)

	void AnimGraph(struct FPoseLink& AnimGraph); // Function ABP_PoseableMesh_Headgear.ABP_PoseableMesh_Headgear_C.AnimGraph
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_PoseableMesh_Headgear_AnimGraphNode_ModifyBone_1C837E29408D8B88E50D6997FE2B0949(); // Function ABP_PoseableMesh_Headgear.ABP_PoseableMesh_Headgear_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_PoseableMesh_Headgear_AnimGraphNode_ModifyBone_1C837E29408D8B88E50D6997FE2B0949
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_PoseableMesh_Headgear_AnimGraphNode_ModifyBone_C49C4A554C68B0DA1EC900AA79750374(); // Function ABP_PoseableMesh_Headgear.ABP_PoseableMesh_Headgear_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_PoseableMesh_Headgear_AnimGraphNode_ModifyBone_C49C4A554C68B0DA1EC900AA79750374
	void ExecuteUbergraph_ABP_PoseableMesh_Headgear(int32_t EntryPoint); // Function ABP_PoseableMesh_Headgear.ABP_PoseableMesh_Headgear_C.ExecuteUbergraph_ABP_PoseableMesh_Headgear
}; 



