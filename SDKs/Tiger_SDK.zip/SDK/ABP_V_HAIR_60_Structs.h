#pragma once 
#include "SDK.h" 
 
 
// Function ABP_V_HAIR_60.ABP_V_HAIR_59_C.ExecuteUbergraph_ABP_V_HAIR_60
// Size: 0x4(Inherited: 0x0) 
struct FExecuteUbergraph_ABP_V_HAIR_60
{
	int32_t EntryPoint;  // 0x0(0x4)

}; 
// Function ABP_V_HAIR_60.ABP_V_HAIR_59_C.AnimGraph
// Size: 0x10(Inherited: 0x0) 
struct FAnimGraph
{
	struct FPoseLink AnimGraph;  // 0x0(0x10)

}; 
