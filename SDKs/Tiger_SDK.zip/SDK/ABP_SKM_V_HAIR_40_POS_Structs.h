#pragma once 
#include "SDK.h" 
 
 
// Function ABP_SKM_V_HAIR_40_POS.ABP_SKM_V_HAIR_40_POS_C.ExecuteUbergraph_ABP_SKM_V_HAIR_40_POS
// Size: 0xF4(Inherited: 0x0) 
struct FExecuteUbergraph_ABP_SKM_V_HAIR_40_POS
{
	int32_t EntryPoint;  // 0x0(0x4)
	struct FVector CallFunc_GetBoneOffsetTransform_OutLocation;  // 0x4(0xC)
	struct FRotator CallFunc_GetBoneOffsetTransform_OutRotation;  // 0x10(0xC)
	struct FVector CallFunc_GetBoneOffsetTransform_OutLocation_2;  // 0x1C(0xC)
	struct FRotator CallFunc_GetBoneOffsetTransform_OutRotation_2;  // 0x28(0xC)
	struct FVector CallFunc_GetBoneOffsetTransform_OutLocation_3;  // 0x34(0xC)
	struct FRotator CallFunc_GetBoneOffsetTransform_OutRotation_3;  // 0x40(0xC)
	struct FVector CallFunc_GetBoneOffsetTransform_OutLocation_4;  // 0x4C(0xC)
	struct FRotator CallFunc_GetBoneOffsetTransform_OutRotation_4;  // 0x58(0xC)
	struct FVector CallFunc_GetBoneOffsetTransform_OutLocation_5;  // 0x64(0xC)
	struct FRotator CallFunc_GetBoneOffsetTransform_OutRotation_5;  // 0x70(0xC)
	struct FVector CallFunc_GetBoneOffsetTransform_OutLocation_6;  // 0x7C(0xC)
	struct FRotator CallFunc_GetBoneOffsetTransform_OutRotation_6;  // 0x88(0xC)
	struct FVector CallFunc_GetBoneOffsetTransform_OutLocation_7;  // 0x94(0xC)
	struct FRotator CallFunc_GetBoneOffsetTransform_OutRotation_7;  // 0xA0(0xC)
	struct FVector CallFunc_GetBoneOffsetTransform_OutLocation_8;  // 0xAC(0xC)
	struct FRotator CallFunc_GetBoneOffsetTransform_OutRotation_8;  // 0xB8(0xC)
	struct FVector CallFunc_GetBoneOffsetTransform_OutLocation_9;  // 0xC4(0xC)
	struct FRotator CallFunc_GetBoneOffsetTransform_OutRotation_9;  // 0xD0(0xC)
	struct FVector CallFunc_GetBoneOffsetTransform_OutLocation_10;  // 0xDC(0xC)
	struct FRotator CallFunc_GetBoneOffsetTransform_OutRotation_10;  // 0xE8(0xC)

}; 
// Function ABP_SKM_V_HAIR_40_POS.ABP_SKM_V_HAIR_40_POS_C.AnimGraph
// Size: 0x10(Inherited: 0x0) 
struct FAnimGraph
{
	struct FPoseLink AnimGraph;  // 0x0(0x10)

}; 
