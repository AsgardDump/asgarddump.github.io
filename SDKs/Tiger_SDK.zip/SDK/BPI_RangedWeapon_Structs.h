#pragma once 
#include "SDK.h" 
 
 
// Function BPI_RangedWeapon.BPI_RangedWeapon_C.GetRangedWeaponCategory
// Size: 0x1(Inherited: 0x0) 
struct FGetRangedWeaponCategory
{
	char ENUM_RangedWeaponCategories RangedWeaponCategory;  // 0x0(0x1)

}; 
