#pragma once 
#include <Gauntlet_Structs.h>
 
 
 
// Class Gauntlet.GauntletTestController
// Size: 0x30(Inherited: 0x28) 
struct UGauntletTestController : public UObject
{
	char pad_40[8];  // 0x28(0x8)

}; 



// Class Gauntlet.GauntletTestControllerBootTest
// Size: 0x30(Inherited: 0x30) 
struct UGauntletTestControllerBootTest : public UGauntletTestController
{

}; 



// Class Gauntlet.GauntletTestControllerErrorTest
// Size: 0x50(Inherited: 0x30) 
struct UGauntletTestControllerErrorTest : public UGauntletTestController
{
	char pad_48[32];  // 0x30(0x20)

}; 



