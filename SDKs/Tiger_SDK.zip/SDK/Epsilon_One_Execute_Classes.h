#pragma once 
#include <Epsilon_One_Execute_Structs.h>
 
 
 
// BlueprintGeneratedClass Epsilon_One_Execute.Epsilon_One_Execute_C
// Size: 0x500(Inherited: 0x4F8) 
struct AEpsilon_One_Execute_C : public ATigerAreaEffect
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x4F8(0x8)

	void OnTriggerClient(); // Function Epsilon_One_Execute.Epsilon_One_Execute_C.OnTriggerClient
	void OnVehicleHit(struct AActor* InActor); // Function Epsilon_One_Execute.Epsilon_One_Execute_C.OnVehicleHit
	void ReceiveBeginPlay(); // Function Epsilon_One_Execute.Epsilon_One_Execute_C.ReceiveBeginPlay
	void ExecuteUbergraph_Epsilon_One_Execute(int32_t EntryPoint); // Function Epsilon_One_Execute.Epsilon_One_Execute_C.ExecuteUbergraph_Epsilon_One_Execute
}; 



