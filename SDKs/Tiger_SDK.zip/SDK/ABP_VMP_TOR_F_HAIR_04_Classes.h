#pragma once 
#include <ABP_VMP_TOR_F_HAIR_04_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass ABP_VMP_TOR_F_HAIR_04.ABP_VMP_TOR_F_HAIR_04_C
// Size: 0x1440(Inherited: 0x2C0) 
struct UABP_VMP_TOR_F_HAIR_04_C : public UAnimInstance
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x2C0(0x8)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace;  // 0x2C8(0x20)
	char pad_744[8];  // 0x2E8(0x8)
	struct FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_4;  // 0x2F0(0x440)
	struct FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_3;  // 0x730(0x440)
	struct FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_2;  // 0xB70(0x440)
	struct FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics;  // 0xFB0(0x440)
	struct FAnimNode_Root AnimGraphNode_Root;  // 0x13F0(0x30)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace;  // 0x1420(0x20)

	void AnimGraph(struct FPoseLink& AnimGraph); // Function ABP_VMP_TOR_F_HAIR_04.ABP_VMP_TOR_F_HAIR_04_C.AnimGraph
	void ExecuteUbergraph_ABP_VMP_TOR_F_HAIR_04(int32_t EntryPoint); // Function ABP_VMP_TOR_F_HAIR_04.ABP_VMP_TOR_F_HAIR_04_C.ExecuteUbergraph_ABP_VMP_TOR_F_HAIR_04
}; 



