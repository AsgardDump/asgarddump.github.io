#pragma once 
#include "SDK.h" 
 
 
// ScriptStruct INTLPlugin.INTLDNSResult
// Size: 0x70(Inherited: 0x40) 
struct FINTLDNSResult : public FINTLBaseResult
{
	struct FString V4;  // 0x40(0x10)
	struct FString V6;  // 0x50(0x10)
	struct FString Host;  // 0x60(0x10)

}; 
// Function INTLPlugin.INTLPluginObserver.OnUpdateOptionalRepoInitResult
// Size: 0x48(Inherited: 0x0) 
struct FOnUpdateOptionalRepoInitResult
{
	struct FINTLUpdateOptionalRepoInitResult Ret;  // 0x0(0x48)

}; 
// ScriptStruct INTLPlugin.INTLFriendReqInfo
// Size: 0x88(Inherited: 0x0) 
struct FINTLFriendReqInfo
{
	int32_t Type;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FString User;  // 0x8(0x10)
	struct FString Title;  // 0x18(0x10)
	struct FString Description;  // 0x28(0x10)
	struct FString ImagePath;  // 0x38(0x10)
	struct FString ThumbPath;  // 0x48(0x10)
	struct FString MediaPath;  // 0x58(0x10)
	struct FString Link;  // 0x68(0x10)
	struct FString ExtraJson;  // 0x78(0x10)

}; 
// ScriptStruct INTLPlugin.INTLBaseResult
// Size: 0x40(Inherited: 0x0) 
struct FINTLBaseResult
{
	int32_t MethodId;  // 0x0(0x4)
	int32_t RetCode;  // 0x4(0x4)
	struct FString RetMsg;  // 0x8(0x10)
	int32_t ThirdCode;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct FString ThirdMsg;  // 0x20(0x10)
	struct FString ExtraJson;  // 0x30(0x10)

}; 
// ScriptStruct INTLPlugin.INTLComplianceResult
// Size: 0xB8(Inherited: 0x40) 
struct FINTLComplianceResult : public FINTLBaseResult
{
	int32_t AdultStatus;  // 0x40(0x4)
	int32_t ParentCertificateStatus;  // 0x44(0x4)
	struct FString ParentCertificateStatusExpiration;  // 0x48(0x10)
	int32_t EUUserAgreeStatus;  // 0x58(0x4)
	char pad_92[4];  // 0x5C(0x4)
	struct FString CountryCode;  // 0x60(0x10)
	int32_t AdultAge;  // 0x70(0x4)
	int32_t GameGrade;  // 0x74(0x4)
	int32_t CertificateType;  // 0x78(0x4)
	char pad_124[4];  // 0x7C(0x4)
	struct FString AdultStatusExpiration;  // 0x80(0x10)
	struct FString TS;  // 0x90(0x10)
	char pad_160_1 : 7;  // 0xA0(0x1)
	bool IsEEA : 1;  // 0xA0(0x1)
	char pad_161[7];  // 0xA1(0x7)
	struct FString Region;  // 0xA8(0x10)

}; 
// Function INTLPlugin.INTLSDKAPI.SetAccount
// Size: 0x20(Inherited: 0x0) 
struct FSetAccount
{
	struct FString Channel;  // 0x0(0x10)
	struct FString Account;  // 0x10(0x10)

}; 
// ScriptStruct INTLPlugin.INTLDirTreeResult
// Size: 0x70(Inherited: 0x40) 
struct FINTLDirTreeResult : public FINTLBaseResult
{
	int32_t TreeId;  // 0x40(0x4)
	int32_t NodeId;  // 0x44(0x4)
	struct FString TreeInfo;  // 0x48(0x10)
	struct FString RoleInfo;  // 0x58(0x10)
	int32_t ExpireTime;  // 0x68(0x4)
	char pad_108[4];  // 0x6C(0x4)

}; 
// Function INTLPlugin.INTLSDKAPI.CheckActiveUser
// Size: 0x1(Inherited: 0x0) 
struct FCheckActiveUser
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function INTLPlugin.INTLSDKAPI.Bind
// Size: 0x30(Inherited: 0x0) 
struct FBind
{
	uint8_t  Channel;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FString Permissions;  // 0x8(0x10)
	struct FString ExtraJson;  // 0x18(0x10)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool ReturnValue : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)

}; 
// Function INTLPlugin.INTLSDKAPI.CallJS
// Size: 0x10(Inherited: 0x0) 
struct FCallJS
{
	struct FString JsonJsParam;  // 0x0(0x10)

}; 
// Function INTLPlugin.INTLPluginObserver.OnDNSResult
// Size: 0x70(Inherited: 0x0) 
struct FOnDNSResult
{
	struct FINTLDNSResult Ret;  // 0x0(0x70)

}; 
// ScriptStruct INTLPlugin.CutoutInfoResult
// Size: 0x70(Inherited: 0x40) 
struct FCutoutInfoResult : public FINTLBaseResult
{
	char pad_64_1 : 7;  // 0x40(0x1)
	bool HasCutout : 1;  // 0x40(0x1)
	char pad_65_1 : 7;  // 0x41(0x1)
	bool IsCutoutHidden : 1;  // 0x41(0x1)
	char pad_66[2];  // 0x42(0x2)
	int32_t ScreenHeight;  // 0x44(0x4)
	int32_t ScreenWidth;  // 0x48(0x4)
	int32_t StatusBarHeight;  // 0x4C(0x4)
	struct TArray<struct FCutoutRect> CutoutRects;  // 0x50(0x10)
	struct FCutoutRect SafeArea;  // 0x60(0x10)

}; 
// ScriptStruct INTLPlugin.INTLExtendResult
// Size: 0x58(Inherited: 0x40) 
struct FINTLExtendResult : public FINTLBaseResult
{
	uint8_t  Channel;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)
	struct FString ExtendMethodName;  // 0x48(0x10)

}; 
// Function INTLPlugin.INTLPluginObserver.OnDismissLoginUI
// Size: 0x1(Inherited: 0x0) 
struct FOnDismissLoginUI
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Canceled : 1;  // 0x0(0x1)

}; 
// ScriptStruct INTLPlugin.CutoutRect
// Size: 0x10(Inherited: 0x0) 
struct FCutoutRect
{
	int32_t Top;  // 0x0(0x4)
	int32_t Bottom;  // 0x4(0x4)
	int32_t Left;  // 0x8(0x4)
	int32_t Right;  // 0xC(0x4)

}; 
// ScriptStruct INTLPlugin.INTLDirTreeNode
// Size: 0x60(Inherited: 0x0) 
struct FINTLDirTreeNode
{
	int32_t NodeId;  // 0x0(0x4)
	int32_t ParentId;  // 0x4(0x4)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool IsLeaf : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct FString Name;  // 0x10(0x10)
	struct FString URL;  // 0x20(0x10)
	int32_t Status;  // 0x30(0x4)
	int32_t Tag;  // 0x34(0x4)
	int32_t CustomInt1;  // 0x38(0x4)
	int32_t CustomInt2;  // 0x3C(0x4)
	struct FString CustomStr;  // 0x40(0x10)
	struct TArray<int32_t> ChildrenIdSet;  // 0x50(0x10)

}; 
// Function INTLPlugin.INTLSDKAPI.AddLocalNotificationIOS
// Size: 0x90(Inherited: 0x0) 
struct FAddLocalNotificationIOS
{
	struct FString Channel;  // 0x0(0x10)
	struct FINTLLocalNotificationIOS LocalNotification;  // 0x10(0x80)

}; 
// Function INTLPlugin.INTLPluginObserver.OnNoticeRequestData
// Size: 0x60(Inherited: 0x0) 
struct FOnNoticeRequestData
{
	struct FINTLNoticeResult Ret;  // 0x0(0x60)

}; 
// Function INTLPlugin.INTLSDKAPI.GetEncryptUrl
// Size: 0x20(Inherited: 0x0) 
struct FGetEncryptUrl
{
	struct FString URL;  // 0x0(0x10)
	struct FString ReturnValue;  // 0x10(0x10)

}; 
// Function INTLPlugin.INTLSDKAPI.DeleteAccount
// Size: 0x20(Inherited: 0x0) 
struct FDeleteAccount
{
	struct FString Channel;  // 0x0(0x10)
	struct FString Account;  // 0x10(0x10)

}; 
// ScriptStruct INTLPlugin.INTLLBSIPInfoResult
// Size: 0x68(Inherited: 0x40) 
struct FINTLLBSIPInfoResult : public FINTLBaseResult
{
	struct FString Region;  // 0x40(0x10)
	struct FString Alpha2;  // 0x50(0x10)
	int32_t Timestamp;  // 0x60(0x4)
	char pad_100[4];  // 0x64(0x4)

}; 
// ScriptStruct INTLPlugin.INTLUpdateResult
// Size: 0x50(Inherited: 0x40) 
struct FINTLUpdateResult : public FINTLBaseResult
{
	uint8_t  ActionType;  // 0x40(0x1)
	char pad_65[3];  // 0x41(0x3)
	int32_t RepoID;  // 0x44(0x4)
	int32_t TaskID;  // 0x48(0x4)
	char pad_76[4];  // 0x4C(0x4)

}; 
// ScriptStruct INTLPlugin.INTLUpdateOptionalRepoFilesStatus
// Size: 0x20(Inherited: 0x0) 
struct FINTLUpdateOptionalRepoFilesStatus
{
	struct FString FilePath;  // 0x0(0x10)
	int32_t TotalFileNum;  // 0x10(0x4)
	int32_t ValidFileNum;  // 0x14(0x4)
	int32_t NeedDownloadSize;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)

}; 
// ScriptStruct INTLPlugin.INTLUpdateInitInfo
// Size: 0x30(Inherited: 0x0) 
struct FINTLUpdateInitInfo
{
	uint8_t  ActionType;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	int32_t RepoID;  // 0x4(0x4)
	int32_t ResourceCopyType;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct FString ResourceSavePath;  // 0x10(0x10)
	struct FString FirstResourceDirPath;  // 0x20(0x10)

}; 
// Function INTLPlugin.INTLPluginObserver.OnAuthBaseResult
// Size: 0x40(Inherited: 0x0) 
struct FOnAuthBaseResult
{
	struct FINTLBaseResult Ret;  // 0x0(0x40)

}; 
// ScriptStruct INTLPlugin.INTLAccountProfile
// Size: 0xD8(Inherited: 0x0) 
struct FINTLAccountProfile
{
	struct FString UserName;  // 0x0(0x10)
	struct FString Birthday;  // 0x10(0x10)
	int32_t BirthdayYear;  // 0x20(0x4)
	int32_t BirthdayMonth;  // 0x24(0x4)
	int32_t BirthdayDay;  // 0x28(0x4)
	int32_t IsReceiveEmail;  // 0x2C(0x4)
	struct FString Region;  // 0x30(0x10)
	struct FString LangType;  // 0x40(0x10)
	struct FString ExtraJson;  // 0x50(0x10)
	struct FString Email;  // 0x60(0x10)
	struct FString Phone;  // 0x70(0x10)
	struct FString PhoneAreaCode;  // 0x80(0x10)
	int32_t AccountType;  // 0x90(0x4)
	char pad_148[4];  // 0x94(0x4)
	struct FString NickName;  // 0x98(0x10)
	struct FString PrivacyPolicy;  // 0xA8(0x10)
	struct FString TermsOfService;  // 0xB8(0x10)
	int32_t PrivacyUpdateTime;  // 0xC8(0x4)
	int32_t TermsUpdateTime;  // 0xCC(0x4)
	int32_t UsernamePassVerify;  // 0xD0(0x4)
	char pad_212[4];  // 0xD4(0x4)

}; 
// ScriptStruct INTLPlugin.INTLWebViewResult
// Size: 0x58(Inherited: 0x40) 
struct FINTLWebViewResult : public FINTLBaseResult
{
	int32_t MsgType;  // 0x40(0x4)
	char pad_68[4];  // 0x44(0x4)
	struct FString MsgJsonData;  // 0x48(0x10)

}; 
// ScriptStruct INTLPlugin.INTLUpdateOptionalRepoInitResult
// Size: 0x48(Inherited: 0x40) 
struct FINTLUpdateOptionalRepoInitResult : public FINTLBaseResult
{
	uint8_t  ActionType;  // 0x40(0x1)
	char pad_65[3];  // 0x41(0x3)
	int32_t RepoID;  // 0x44(0x4)

}; 
// ScriptStruct INTLPlugin.INTLUpdateProgress
// Size: 0x40(Inherited: 0x0) 
struct FINTLUpdateProgress
{
	int32_t MethodId;  // 0x0(0x4)
	uint8_t  ActionType;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	int32_t UpdateStep;  // 0x8(0x4)
	int32_t RepoID;  // 0xC(0x4)
	int32_t TaskID;  // 0x10(0x4)
	int32_t FinishedSize;  // 0x14(0x4)
	int32_t TotalSize;  // 0x18(0x4)
	int32_t Speed;  // 0x1C(0x4)
	int32_t RemainTime;  // 0x20(0x4)
	float StepProgress;  // 0x24(0x4)
	float TotalProgress;  // 0x28(0x4)
	char pad_44[4];  // 0x2C(0x4)
	struct FString ErrorMsg;  // 0x30(0x10)

}; 
// Function INTLPlugin.INTLOutputUtility.FormatAuthRet
// Size: 0x150(Inherited: 0x0) 
struct FFormatAuthRet
{
	struct FINTLAuthResult Ret;  // 0x0(0x130)
	char pad_304_1 : 7;  // 0x130(0x1)
	bool IsSuccess : 1;  // 0x130(0x1)
	char pad_305[7];  // 0x131(0x7)
	struct FText ErrorMsg;  // 0x138(0x18)

}; 
// Function INTLPlugin.INTLSDKAPI.ComplianceSetParentCertificateStatus
// Size: 0x1(Inherited: 0x0) 
struct FComplianceSetParentCertificateStatus
{
	uint8_t  Status;  // 0x0(0x1)

}; 
// ScriptStruct INTLPlugin.INTLLocalNotificationIOS
// Size: 0x80(Inherited: 0x0) 
struct FINTLLocalNotificationIOS
{
	int32_t RepeatType;  // 0x0(0x4)
	int32_t FireTime;  // 0x4(0x4)
	int32_t Badge;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct FString AlertBody;  // 0x10(0x10)
	struct FString AlertAction;  // 0x20(0x10)
	struct TMap<struct FString, struct FString> UserInfo;  // 0x30(0x50)

}; 
// ScriptStruct INTLPlugin.INTLPersonInfo
// Size: 0x88(Inherited: 0x0) 
struct FINTLPersonInfo
{
	struct FString OpenId;  // 0x0(0x10)
	struct FString UserName;  // 0x10(0x10)
	int32_t Gender;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)
	struct FString PictureUrl;  // 0x28(0x10)
	struct FString Country;  // 0x38(0x10)
	struct FString Province;  // 0x48(0x10)
	struct FString City;  // 0x58(0x10)
	struct FString Language;  // 0x68(0x10)
	struct FString ExtraJson;  // 0x78(0x10)

}; 
// ScriptStruct INTLPlugin.INTLUpdateStartRepoNewVersionInfo
// Size: 0x38(Inherited: 0x0) 
struct FINTLUpdateStartRepoNewVersionInfo
{
	int32_t MethodId;  // 0x0(0x4)
	uint8_t  ActionType;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	int32_t NewVersionType;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct FString Version;  // 0x10(0x10)
	int32_t NeedDownloadSize;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)
	struct FString GameDefinedStr;  // 0x28(0x10)

}; 
// Function INTLPlugin.INTLSDKAPI.Login
// Size: 0x30(Inherited: 0x0) 
struct FLogin
{
	uint8_t  Channel;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FString Permissions;  // 0x8(0x10)
	struct FString ExtraJson;  // 0x18(0x10)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool ReturnValue : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)

}; 
// ScriptStruct INTLPlugin.INTLCustomerUserProfile
// Size: 0x100(Inherited: 0x0) 
struct FINTLCustomerUserProfile
{
	struct FString LangType;  // 0x0(0x10)
	struct FString Sign;  // 0x10(0x10)
	struct FString OpenId;  // 0x20(0x10)
	struct FString GameLevel;  // 0x30(0x10)
	struct FString NickName;  // 0x40(0x10)
	struct FString RoleId;  // 0x50(0x10)
	struct FString AreaId;  // 0x60(0x10)
	struct FString ZoneId;  // 0x70(0x10)
	struct FString GameSvrId;  // 0x80(0x10)
	struct FString Region;  // 0x90(0x10)
	struct FString PictureUrl;  // 0xA0(0x10)
	struct FString CustomParam1;  // 0xB0(0x10)
	struct FString CustomParam2;  // 0xC0(0x10)
	struct FString CustomParam3;  // 0xD0(0x10)
	struct FString CustomParam4;  // 0xE0(0x10)
	struct FString CustomParam5;  // 0xF0(0x10)

}; 
// ScriptStruct INTLPlugin.INTLCustomerResult
// Size: 0x48(Inherited: 0x40) 
struct FINTLCustomerResult : public FINTLBaseResult
{
	int32_t MsgType;  // 0x40(0x4)
	char pad_68[4];  // 0x44(0x4)

}; 
// ScriptStruct INTLPlugin.INTLNoticeResult
// Size: 0x60(Inherited: 0x40) 
struct FINTLNoticeResult : public FINTLBaseResult
{
	struct FString SeqId;  // 0x40(0x10)
	struct TArray<struct FINTLNoticeInfo> NoticeInfoList;  // 0x50(0x10)

}; 
// ScriptStruct INTLPlugin.INTLPushResult
// Size: 0x58(Inherited: 0x40) 
struct FINTLPushResult : public FINTLBaseResult
{
	int32_t Type;  // 0x40(0x4)
	char pad_68[4];  // 0x44(0x4)
	struct FString Notification;  // 0x48(0x10)

}; 
// ScriptStruct INTLPlugin.INTLLocalNotification
// Size: 0x78(Inherited: 0x0) 
struct FINTLLocalNotification
{
	int32_t NotificationID;  // 0x0(0x4)
	int32_t ActionType;  // 0x4(0x4)
	int32_t SoundEnabled;  // 0x8(0x4)
	int32_t Lights;  // 0xC(0x4)
	int32_t Vibrate;  // 0x10(0x4)
	int32_t FireTime;  // 0x14(0x4)
	struct FString Title;  // 0x18(0x10)
	struct FString Content;  // 0x28(0x10)
	struct FString TickerText;  // 0x38(0x10)
	struct FString ActionParameter;  // 0x48(0x10)
	struct FString RingUri;  // 0x58(0x10)
	struct FString SmallIcon;  // 0x68(0x10)

}; 
// Function INTLPlugin.INTLSDKAPI.OnTickEvent
// Size: 0x1(Inherited: 0x0) 
struct FOnTickEvent
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// ScriptStruct INTLPlugin.INTLFriendResult
// Size: 0x50(Inherited: 0x40) 
struct FINTLFriendResult : public FINTLBaseResult
{
	struct TArray<struct FINTLPersonInfo> FriendInfoList;  // 0x40(0x10)

}; 
// Function INTLPlugin.INTLSDKAPI.SetCrashUserValue
// Size: 0x20(Inherited: 0x0) 
struct FSetCrashUserValue
{
	struct FString Key;  // 0x0(0x10)
	struct FString Value;  // 0x10(0x10)

}; 
// ScriptStruct INTLPlugin.INTLNoticeInfo
// Size: 0x78(Inherited: 0x0) 
struct FINTLNoticeInfo
{
	int32_t NoticeId;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FString AppId;  // 0x8(0x10)
	struct FString AppNoticeId;  // 0x18(0x10)
	int32_t Status;  // 0x28(0x4)
	int32_t StartTime;  // 0x2C(0x4)
	int32_t EndTime;  // 0x30(0x4)
	int32_t UpdateTime;  // 0x34(0x4)
	struct FString AreaList;  // 0x38(0x10)
	struct TArray<struct FINTLNoticePicture> PictureList;  // 0x48(0x10)
	struct FString ExtraData;  // 0x58(0x10)
	struct TArray<struct FINTLNoticeContent> ContentList;  // 0x68(0x10)

}; 
// ScriptStruct INTLPlugin.INTLNoticeContent
// Size: 0x70(Inherited: 0x0) 
struct FINTLNoticeContent
{
	int32_t ContentId;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FString AppContentId;  // 0x8(0x10)
	struct FString Title;  // 0x18(0x10)
	struct FString Content;  // 0x28(0x10)
	struct FString LangType;  // 0x38(0x10)
	int32_t UpdateTime;  // 0x48(0x4)
	char pad_76[4];  // 0x4C(0x4)
	struct FString ExtraData;  // 0x50(0x10)
	struct TArray<struct FINTLNoticePicture> PictureList;  // 0x60(0x10)

}; 
// ScriptStruct INTLPlugin.INTLNoticePicture
// Size: 0x40(Inherited: 0x0) 
struct FINTLNoticePicture
{
	struct FString URL;  // 0x0(0x10)
	struct FString Hash;  // 0x10(0x10)
	struct FString RedirectUrl;  // 0x20(0x10)
	struct FString ExtraData;  // 0x30(0x10)

}; 
// ScriptStruct INTLPlugin.INTLAccountResult
// Size: 0x1C0(Inherited: 0x40) 
struct FINTLAccountResult : public FINTLBaseResult
{
	int32_t ChannelID;  // 0x40(0x4)
	char pad_68[4];  // 0x44(0x4)
	struct FString Channel;  // 0x48(0x10)
	struct FString SeqId;  // 0x58(0x10)
	struct FString UserName;  // 0x68(0x10)
	struct FString UID;  // 0x78(0x10)
	struct FString Token;  // 0x88(0x10)
	int32_t ExpireTime;  // 0x98(0x4)
	int32_t IsRegister;  // 0x9C(0x4)
	int32_t IsSetPassword;  // 0xA0(0x4)
	int32_t IsReceiveEmail;  // 0xA4(0x4)
	int32_t VerifyCodeExpireTime;  // 0xA8(0x4)
	int32_t CanBind;  // 0xAC(0x4)
	struct FString PpAcceptanceVersion;  // 0xB0(0x10)
	struct FString TosAcceptanceVersion;  // 0xC0(0x10)
	struct FDateTime PpAcceptanceTime;  // 0xD0(0x8)
	struct FDateTime TosAcceptanceTime;  // 0xD8(0x8)
	struct FINTLAccountProfile Profile;  // 0xE0(0xD8)
	int32_t IsUserNameAvailable;  // 0x1B8(0x4)
	char pad_444[4];  // 0x1BC(0x4)

}; 
// Function INTLPlugin.INTLPluginObserver.OnUpdateProgressResult
// Size: 0x40(Inherited: 0x0) 
struct FOnUpdateProgressResult
{
	struct FINTLUpdateProgress Ret;  // 0x0(0x40)

}; 
// ScriptStruct INTLPlugin.INTLDeviceLevelResult
// Size: 0x48(Inherited: 0x40) 
struct FINTLDeviceLevelResult : public FINTLBaseResult
{
	int32_t DeviceLevel;  // 0x40(0x4)
	char pad_68[4];  // 0x44(0x4)

}; 
// ScriptStruct INTLPlugin.INTLIDTokenResult
// Size: 0x50(Inherited: 0x40) 
struct FINTLIDTokenResult : public FINTLBaseResult
{
	struct FString IdToken;  // 0x40(0x10)

}; 
// ScriptStruct INTLPlugin.INTLAuthResult
// Size: 0x130(Inherited: 0x40) 
struct FINTLAuthResult : public FINTLBaseResult
{
	struct FString OpenId;  // 0x40(0x10)
	struct FString Token;  // 0x50(0x10)
	int32_t TokenExpireTime;  // 0x60(0x4)
	int32_t FirstLogin;  // 0x64(0x4)
	struct FString RegChannelDis;  // 0x68(0x10)
	struct FString UserName;  // 0x78(0x10)
	int32_t Gender;  // 0x88(0x4)
	char pad_140[4];  // 0x8C(0x4)
	struct FString Birthday;  // 0x90(0x10)
	struct FString PicUrl;  // 0xA0(0x10)
	struct FString Pf;  // 0xB0(0x10)
	struct FString PfKey;  // 0xC0(0x10)
	char pad_208_1 : 7;  // 0xD0(0x1)
	bool NeedRealNameAuth : 1;  // 0xD0(0x1)
	char pad_209[3];  // 0xD1(0x3)
	int32_t ChannelID;  // 0xD4(0x4)
	uint8_t  ChannelName;  // 0xD8(0x1)
	char pad_217[7];  // 0xD9(0x7)
	struct FString ChannelInfo;  // 0xE0(0x10)
	struct FString ConfirmCode;  // 0xF0(0x10)
	int32_t ConfirmCodeExpireTime;  // 0x100(0x4)
	char pad_260[4];  // 0x104(0x4)
	struct FString BindList;  // 0x108(0x10)
	struct FString LegalDocumentsAcceptedVersion;  // 0x118(0x10)
	int32_t DeleteAccountStatus;  // 0x128(0x4)
	char pad_300[4];  // 0x12C(0x4)

}; 
// Function INTLPlugin.INTLUtility.GetNewToastOrder
// Size: 0x4(Inherited: 0x0) 
struct FGetNewToastOrder
{
	int32_t ReturnValue;  // 0x0(0x4)

}; 
// Function INTLPlugin.INTLOutputUtility.FormatBaseRet
// Size: 0x60(Inherited: 0x0) 
struct FFormatBaseRet
{
	struct FINTLBaseResult Ret;  // 0x0(0x40)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool IsSuccess : 1;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)
	struct FText ErrorMsg;  // 0x48(0x18)

}; 
// Function INTLPlugin.INTLSDKAPI.AddObserver
// Size: 0x10(Inherited: 0x0) 
struct FAddObserver
{
	struct TScriptInterface<IINTLPluginObserver> Observer;  // 0x0(0x10)

}; 
// Function INTLPlugin.INTLOutputUtility.FormatNoticeRet
// Size: 0x80(Inherited: 0x0) 
struct FFormatNoticeRet
{
	struct FINTLNoticeResult Ret;  // 0x0(0x60)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool IsSuccess : 1;  // 0x60(0x1)
	char pad_97[7];  // 0x61(0x7)
	struct FText ErrorMsg;  // 0x68(0x18)

}; 
// Function INTLPlugin.INTLPluginObserver.OnAccountResult
// Size: 0x1C0(Inherited: 0x0) 
struct FOnAccountResult
{
	struct FINTLAccountResult Ret;  // 0x0(0x1C0)

}; 
// Function INTLPlugin.INTLSDKAPI.RemoveObserver
// Size: 0x10(Inherited: 0x0) 
struct FRemoveObserver
{
	struct TScriptInterface<IINTLPluginObserver> Observer;  // 0x0(0x10)

}; 
// Function INTLPlugin.INTLPluginObserver.OnAuthResult
// Size: 0x130(Inherited: 0x0) 
struct FOnAuthResult
{
	struct FINTLAuthResult Ret;  // 0x0(0x130)

}; 
// Function INTLPlugin.INTLPluginObserver.OnComplianceResult
// Size: 0xB8(Inherited: 0x0) 
struct FOnComplianceResult
{
	struct FINTLComplianceResult Ret;  // 0x0(0xB8)

}; 
// Function INTLPlugin.INTLPluginObserver.OnCustomerResult
// Size: 0x48(Inherited: 0x0) 
struct FOnCustomerResult
{
	struct FINTLCustomerResult Ret;  // 0x0(0x48)

}; 
// Function INTLPlugin.INTLSDKAPI.GetConfig
// Size: 0x40(Inherited: 0x0) 
struct FGetConfig
{
	struct FString Key;  // 0x0(0x10)
	struct FString DefaultVal;  // 0x10(0x10)
	struct FString Project;  // 0x20(0x10)
	struct FString ReturnValue;  // 0x30(0x10)

}; 
// Function INTLPlugin.INTLPluginObserver.OnCutoutResult
// Size: 0x70(Inherited: 0x0) 
struct FOnCutoutResult
{
	struct FCutoutInfoResult Ret;  // 0x0(0x70)

}; 
// Function INTLPlugin.INTLSDKAPI.GetInstanceID
// Size: 0x20(Inherited: 0x0) 
struct FGetInstanceID
{
	struct FString Channel;  // 0x0(0x10)
	struct FString ReturnValue;  // 0x10(0x10)

}; 
// Function INTLPlugin.INTLPluginObserver.OnExtendResult
// Size: 0x58(Inherited: 0x0) 
struct FOnExtendResult
{
	struct FINTLExtendResult Ret;  // 0x0(0x58)

}; 
// Function INTLPlugin.INTLSDKAPI.QueryLegalDocumentsAcceptedVersion
// Size: 0x1(Inherited: 0x0) 
struct FQueryLegalDocumentsAcceptedVersion
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function INTLPlugin.INTLPluginObserver.OnDeviceLevelResult
// Size: 0x48(Inherited: 0x0) 
struct FOnDeviceLevelResult
{
	struct FINTLDeviceLevelResult Ret;  // 0x0(0x48)

}; 
// Function INTLPlugin.INTLSDKAPI.RequestVerifyCode
// Size: 0x40(Inherited: 0x0) 
struct FRequestVerifyCode
{
	struct FString Account;  // 0x0(0x10)
	uint8_t  CodeType;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct FString PhoneAreaCode;  // 0x18(0x10)
	struct FString ExtraJson;  // 0x28(0x10)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool ReturnValue : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)

}; 
// Function INTLPlugin.INTLPluginObserver.OnDirTreeResult
// Size: 0x70(Inherited: 0x0) 
struct FOnDirTreeResult
{
	struct FINTLDirTreeResult Ret;  // 0x0(0x70)

}; 
// Function INTLPlugin.INTLPluginObserver.OnFriendBaseResult
// Size: 0x40(Inherited: 0x0) 
struct FOnFriendBaseResult
{
	struct FINTLBaseResult Ret;  // 0x0(0x40)

}; 
// Function INTLPlugin.INTLPluginObserver.OnFriendResult
// Size: 0x50(Inherited: 0x0) 
struct FOnFriendResult
{
	struct FINTLFriendResult Ret;  // 0x0(0x50)

}; 
// Function INTLPlugin.INTLPluginObserver.OnIDTokenResult
// Size: 0x50(Inherited: 0x0) 
struct FOnIDTokenResult
{
	struct FINTLIDTokenResult Ret;  // 0x0(0x50)

}; 
// Function INTLPlugin.INTLSDKAPI.AutoLogin
// Size: 0x1(Inherited: 0x0) 
struct FAutoLogin
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function INTLPlugin.INTLSDKAPI.LogCrashInfo
// Size: 0x28(Inherited: 0x0) 
struct FLogCrashInfo
{
	uint8_t  Level;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FString Tag;  // 0x8(0x10)
	struct FString Log;  // 0x18(0x10)

}; 
// Function INTLPlugin.INTLPluginObserver.OnIPInfoResult
// Size: 0x68(Inherited: 0x0) 
struct FOnIPInfoResult
{
	struct FINTLLBSIPInfoResult Ret;  // 0x0(0x68)

}; 
// Function INTLPlugin.INTLPluginObserver.OnPushBaseResult
// Size: 0x40(Inherited: 0x0) 
struct FOnPushBaseResult
{
	struct FINTLBaseResult Ret;  // 0x0(0x40)

}; 
// Function INTLPlugin.INTLPluginObserver.OnUpdateResult
// Size: 0x50(Inherited: 0x0) 
struct FOnUpdateResult
{
	struct FINTLUpdateResult Ret;  // 0x0(0x50)

}; 
// Function INTLPlugin.INTLPluginObserver.OnPushResult
// Size: 0x58(Inherited: 0x0) 
struct FOnPushResult
{
	struct FINTLPushResult Ret;  // 0x0(0x58)

}; 
// Function INTLPlugin.INTLSDKAPI.QueryUserInfo
// Size: 0x1(Inherited: 0x0) 
struct FQueryUserInfo
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function INTLPlugin.INTLPluginObserver.OnUpdateStartRepoNewVersionInfoResult
// Size: 0x38(Inherited: 0x0) 
struct FOnUpdateStartRepoNewVersionInfoResult
{
	struct FINTLUpdateStartRepoNewVersionInfo Ret;  // 0x0(0x38)

}; 
// Function INTLPlugin.INTLSDKAPI.SetSessionExtraParam
// Size: 0x10(Inherited: 0x0) 
struct FSetSessionExtraParam
{
	struct FString extra_json;  // 0x0(0x10)

}; 
// Function INTLPlugin.INTLSDKAPI.QueryDirTree
// Size: 0x4(Inherited: 0x0) 
struct FQueryDirTree
{
	int32_t TreeId;  // 0x0(0x4)

}; 
// Function INTLPlugin.INTLPluginObserver.OnWebViewResult
// Size: 0x58(Inherited: 0x0) 
struct FOnWebViewResult
{
	struct FINTLWebViewResult Ret;  // 0x0(0x58)

}; 
// Function INTLPlugin.INTLSDKAPI.AddLocalNotification
// Size: 0x88(Inherited: 0x0) 
struct FAddLocalNotification
{
	struct FString Channel;  // 0x0(0x10)
	struct FINTLLocalNotification LocalNotification;  // 0x10(0x78)

}; 
// Function INTLPlugin.INTLSDKAPI.DeleteTag
// Size: 0x20(Inherited: 0x0) 
struct FDeleteTag
{
	struct FString Channel;  // 0x0(0x10)
	struct FString Tag;  // 0x10(0x10)

}; 
// Function INTLPlugin.INTLSDKAPI.BindWithLoggedinChannel
// Size: 0x1(Inherited: 0x0) 
struct FBindWithLoggedinChannel
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function INTLPlugin.INTLSDKAPI.BuildMapWithLoggedinChannel
// Size: 0x1(Inherited: 0x0) 
struct FBuildMapWithLoggedinChannel
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function INTLPlugin.INTLSDKAPI.CheckOptionalRepoFiles
// Size: 0x28(Inherited: 0x0) 
struct FCheckOptionalRepoFiles
{
	int32_t RepoID;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct TArray<struct FString> FilesPath;  // 0x8(0x10)
	struct TArray<struct FINTLUpdateOptionalRepoFilesStatus> ReturnValue;  // 0x18(0x10)

}; 
// Function INTLPlugin.INTLSDKAPI.ClearLocalNotifications
// Size: 0x10(Inherited: 0x0) 
struct FClearLocalNotifications
{
	struct FString Channel;  // 0x0(0x10)

}; 
// Function INTLPlugin.INTLSDKAPI.ComplianceCommitBirthday
// Size: 0xC(Inherited: 0x0) 
struct FComplianceCommitBirthday
{
	int32_t BirthdayYear;  // 0x0(0x4)
	int32_t BirthdayMonth;  // 0x4(0x4)
	int32_t BirthdayDay;  // 0x8(0x4)

}; 
// Function INTLPlugin.INTLSDKAPI.ComplianceSendEmail
// Size: 0x20(Inherited: 0x0) 
struct FComplianceSendEmail
{
	struct FString Email;  // 0x0(0x10)
	struct FString UserName;  // 0x10(0x10)

}; 
// Function INTLPlugin.INTLSDKAPI.ComplianceSetAdulthood
// Size: 0x1(Inherited: 0x0) 
struct FComplianceSetAdulthood
{
	uint8_t  Status;  // 0x0(0x1)

}; 
// Function INTLPlugin.INTLSDKAPI.ComplianceSetEUAgreeStatus
// Size: 0x1(Inherited: 0x0) 
struct FComplianceSetEUAgreeStatus
{
	uint8_t  Status;  // 0x0(0x1)

}; 
// Function INTLPlugin.INTLSDKAPI.ComplianceSetUserProfile
// Size: 0x50(Inherited: 0x0) 
struct FComplianceSetUserProfile
{
	struct FString GameID;  // 0x0(0x10)
	struct FString OpenId;  // 0x10(0x10)
	struct FString Token;  // 0x20(0x10)
	int32_t ChannelID;  // 0x30(0x4)
	char pad_52[4];  // 0x34(0x4)
	struct FString Region;  // 0x38(0x10)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool ReturnValue : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function INTLPlugin.INTLSDKAPI.DeleteLocalNotifications
// Size: 0x10(Inherited: 0x0) 
struct FDeleteLocalNotifications
{
	struct FString Key;  // 0x0(0x10)

}; 
// Function INTLPlugin.INTLSDKAPI.DismissLoginUI
// Size: 0x1(Inherited: 0x0) 
struct FDismissLoginUI
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Canceled : 1;  // 0x0(0x1)

}; 
// Function INTLPlugin.INTLSDKAPI.DownloadOptionalRepoFiles
// Size: 0x20(Inherited: 0x0) 
struct FDownloadOptionalRepoFiles
{
	int32_t RepoID;  // 0x0(0x4)
	int32_t DownloadPriority;  // 0x4(0x4)
	struct TArray<struct FString> FilesPath;  // 0x8(0x10)
	int32_t ReturnValue;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)

}; 
// Function INTLPlugin.INTLSDKAPI.ExtendInvoke
// Size: 0x38(Inherited: 0x0) 
struct FExtendInvoke
{
	uint8_t  Channel;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FString ExtendMethodName;  // 0x8(0x10)
	struct FString ParamsJson;  // 0x18(0x10)
	struct FString ReturnValue;  // 0x28(0x10)

}; 
// Function INTLPlugin.INTLSDKAPI.GetAuthResult
// Size: 0x138(Inherited: 0x0) 
struct FGetAuthResult
{
	struct FINTLAuthResult LoginRet;  // 0x0(0x130)
	char pad_304_1 : 7;  // 0x130(0x1)
	bool ReturnValue : 1;  // 0x130(0x1)
	char pad_305[7];  // 0x131(0x7)

}; 
// Function INTLPlugin.INTLSDKAPI.QueryIpByHost
// Size: 0x10(Inherited: 0x0) 
struct FQueryIpByHost
{
	struct FString Host;  // 0x0(0x10)

}; 
// Function INTLPlugin.INTLSDKAPI.GetCurrentAppVersion
// Size: 0x10(Inherited: 0x0) 
struct FGetCurrentAppVersion
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// Function INTLPlugin.INTLSDKAPI.GetCurrentResourceVersion
// Size: 0x10(Inherited: 0x0) 
struct FGetCurrentResourceVersion
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// Function INTLPlugin.INTLSDKAPI.GetDeviceLevel
// Size: 0x4(Inherited: 0x0) 
struct FGetDeviceLevel
{
	int32_t ReturnValue;  // 0x0(0x4)

}; 
// Function INTLPlugin.INTLSDKAPI.GetIDTokenResult
// Size: 0x58(Inherited: 0x0) 
struct FGetIDTokenResult
{
	struct FINTLIDTokenResult jwtRet;  // 0x0(0x50)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool ReturnValue : 1;  // 0x50(0x1)
	char pad_81[7];  // 0x51(0x7)

}; 
// Function INTLPlugin.INTLSDKAPI.GetInstanceIDAsync
// Size: 0x20(Inherited: 0x0) 
struct FGetInstanceIDAsync
{
	struct FString Channel;  // 0x0(0x10)
	struct FString ReturnValue;  // 0x10(0x10)

}; 
// Function INTLPlugin.INTLSDKAPI.GetIpByHost
// Size: 0x20(Inherited: 0x0) 
struct FGetIpByHost
{
	struct FString Host;  // 0x0(0x10)
	struct FString ReturnValue;  // 0x10(0x10)

}; 
// Function INTLPlugin.INTLSDKAPI.Logout
// Size: 0x2(Inherited: 0x0) 
struct FLogout
{
	uint8_t  Channel;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool ReturnValue : 1;  // 0x1(0x1)

}; 
// Function INTLPlugin.INTLSDKAPI.GetSDKVersion
// Size: 0x10(Inherited: 0x0) 
struct FGetSDKVersion
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// Function INTLPlugin.INTLSDKAPI.IsAppInstalled
// Size: 0x28(Inherited: 0x0) 
struct FIsAppInstalled
{
	struct FString Channel;  // 0x0(0x10)
	struct FString ExtraJson;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool ReturnValue : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// Function INTLPlugin.INTLSDKAPI.LaunchAccountUI
// Size: 0x20(Inherited: 0x0) 
struct FLaunchAccountUI
{
	int32_t Type;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FString ExtraJson;  // 0x8(0x10)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool ReturnValue : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)

}; 
// Function INTLPlugin.INTLSDKAPI.LaunchCustomerUI
// Size: 0x108(Inherited: 0x0) 
struct FLaunchCustomerUI
{
	struct FINTLCustomerUserProfile userProfile;  // 0x0(0x100)
	char pad_256_1 : 7;  // 0x100(0x1)
	bool ReturnValue : 1;  // 0x100(0x1)
	char pad_257[7];  // 0x101(0x7)

}; 
// Function INTLPlugin.INTLSDKAPI.LoginWithBoundChannel
// Size: 0x20(Inherited: 0x0) 
struct FLoginWithBoundChannel
{
	uint8_t  Channel;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FString LoginMode;  // 0x8(0x10)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool ReturnValue : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)

}; 
// Function INTLPlugin.INTLSDKAPI.LoginWithChannel
// Size: 0x20(Inherited: 0x0) 
struct FLoginWithChannel
{
	uint8_t  Channel;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FString LoginMode;  // 0x8(0x10)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool ReturnValue : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)

}; 
// Function INTLPlugin.INTLSDKAPI.Share
// Size: 0xA0(Inherited: 0x0) 
struct FShare
{
	struct FINTLFriendReqInfo Info;  // 0x0(0x88)
	struct FString Channel;  // 0x88(0x10)
	char pad_152_1 : 7;  // 0x98(0x1)
	bool ReturnValue : 1;  // 0x98(0x1)
	char pad_153[7];  // 0x99(0x7)

}; 
// Function INTLPlugin.INTLSDKAPI.LoginWithMappedChannel
// Size: 0x30(Inherited: 0x0) 
struct FLoginWithMappedChannel
{
	uint8_t  Channel;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FString LoginMode;  // 0x8(0x10)
	struct FString Permissions;  // 0x18(0x10)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool ReturnValue : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)

}; 
// Function INTLPlugin.INTLSDKAPI.LoginWithPassword
// Size: 0x50(Inherited: 0x0) 
struct FLoginWithPassword
{
	uint8_t  Channel;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FString Account;  // 0x8(0x10)
	struct FString Password;  // 0x18(0x10)
	struct FString PhoneAreaCode;  // 0x28(0x10)
	struct FString PermissionList;  // 0x38(0x10)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool ReturnValue : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function INTLPlugin.INTLSDKAPI.LoginWithVerifyCode
// Size: 0x60(Inherited: 0x0) 
struct FLoginWithVerifyCode
{
	uint8_t  Channel;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FString Account;  // 0x8(0x10)
	struct FString Password;  // 0x18(0x10)
	struct FString VerifyCode;  // 0x28(0x10)
	struct FString PhoneAreaCode;  // 0x38(0x10)
	struct FString PermissionList;  // 0x48(0x10)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool ReturnValue : 1;  // 0x58(0x1)
	char pad_89[7];  // 0x59(0x7)

}; 
// Function INTLPlugin.INTLSDKAPI.MarkSessionLoad
// Size: 0x20(Inherited: 0x0) 
struct FMarkSessionLoad
{
	struct FString SessionName;  // 0x0(0x10)
	struct FString extra_json;  // 0x10(0x10)

}; 
// Function INTLPlugin.INTLSDKAPI.ModifyAccountWithLoginState
// Size: 0x58(Inherited: 0x0) 
struct FModifyAccountWithLoginState
{
	struct FString OldPhoneAreaCode;  // 0x0(0x10)
	struct FString NewAccount;  // 0x10(0x10)
	struct FString NewAccountVerifyCode;  // 0x20(0x10)
	struct FString NewPhoneAreaCode;  // 0x30(0x10)
	struct FString ExtraJson;  // 0x40(0x10)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool ReturnValue : 1;  // 0x50(0x1)
	char pad_81[7];  // 0x51(0x7)

}; 
// Function INTLPlugin.INTLSDKAPI.ModifyAccountWithPassword
// Size: 0x78(Inherited: 0x0) 
struct FModifyAccountWithPassword
{
	struct FString OldAccount;  // 0x0(0x10)
	struct FString OldPhoneAreaCode;  // 0x10(0x10)
	struct FString Password;  // 0x20(0x10)
	struct FString NewAccount;  // 0x30(0x10)
	struct FString NewAccountVerifyCode;  // 0x40(0x10)
	struct FString NewPhoneAreaCode;  // 0x50(0x10)
	struct FString ExtraJson;  // 0x60(0x10)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool ReturnValue : 1;  // 0x70(0x1)
	char pad_113[7];  // 0x71(0x7)

}; 
// Function INTLPlugin.INTLSDKAPI.ModifyAccountWithVerifyCode
// Size: 0x78(Inherited: 0x0) 
struct FModifyAccountWithVerifyCode
{
	struct FString OldAccount;  // 0x0(0x10)
	struct FString OldAccountVerifyCode;  // 0x10(0x10)
	struct FString OldPhoneAreaCode;  // 0x20(0x10)
	struct FString NewAccount;  // 0x30(0x10)
	struct FString NewAccountVerifyCode;  // 0x40(0x10)
	struct FString NewPhoneAreaCode;  // 0x50(0x10)
	struct FString ExtraJson;  // 0x60(0x10)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool ReturnValue : 1;  // 0x70(0x1)
	char pad_113[7];  // 0x71(0x7)

}; 
// Function INTLPlugin.INTLUtility.Regular
// Size: 0x28(Inherited: 0x0) 
struct FRegular
{
	struct FString Str;  // 0x0(0x10)
	struct FString Reg;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool ReturnValue : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// Function INTLPlugin.INTLSDKAPI.ModifyDataProtectionAcceptance
// Size: 0x20(Inherited: 0x0) 
struct FModifyDataProtectionAcceptance
{
	struct FString PPVersion;  // 0x0(0x10)
	struct FString TOSVersion;  // 0x10(0x10)

}; 
// Function INTLPlugin.INTLSDKAPI.ModifyDownloadPriority
// Size: 0x10(Inherited: 0x0) 
struct FModifyDownloadPriority
{
	int32_t RepoID;  // 0x0(0x4)
	int32_t TaskID;  // 0x4(0x4)
	int32_t DownloadPriority;  // 0x8(0x4)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool ReturnValue : 1;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)

}; 
// Function INTLPlugin.INTLSDKAPI.ModifyLegalDocumentsAcceptedVersion
// Size: 0x18(Inherited: 0x0) 
struct FModifyLegalDocumentsAcceptedVersion
{
	struct FString acceptedVersionsJson;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function INTLPlugin.INTLSDKAPI.ModifyProfile
// Size: 0xE0(Inherited: 0x0) 
struct FModifyProfile
{
	struct FINTLAccountProfile userProfile;  // 0x0(0xD8)
	char pad_216_1 : 7;  // 0xD8(0x1)
	bool ReturnValue : 1;  // 0xD8(0x1)
	char pad_217[7];  // 0xD9(0x7)

}; 
// Function INTLPlugin.INTLSDKAPI.NoticeRequestData
// Size: 0x40(Inherited: 0x0) 
struct FNoticeRequestData
{
	struct FString Region;  // 0x0(0x10)
	struct FString LangType;  // 0x10(0x10)
	struct FString ExtraJson;  // 0x20(0x10)
	struct FString ReturnValue;  // 0x30(0x10)

}; 
// Function INTLPlugin.INTLSDKAPI.PostFrameTimeInSession
// Size: 0x4(Inherited: 0x0) 
struct FPostFrameTimeInSession
{
	float DeltaSeconds;  // 0x0(0x4)

}; 
// Function INTLPlugin.INTLSDKAPI.OpenUrl
// Size: 0x28(Inherited: 0x0) 
struct FOpenUrl
{
	struct FString URL;  // 0x0(0x10)
	uint8_t  ScreenOrientation;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool FullScreenEnable : 1;  // 0x11(0x1)
	char pad_18_1 : 7;  // 0x12(0x1)
	bool EncryptEnable : 1;  // 0x12(0x1)
	char pad_19_1 : 7;  // 0x13(0x1)
	bool SystemBrowserEnable : 1;  // 0x13(0x1)
	char pad_20[4];  // 0x14(0x4)
	struct FString ExtraJson;  // 0x18(0x10)

}; 
// Function INTLPlugin.INTLSDKAPI.PostNetworkLatencyInSession
// Size: 0x4(Inherited: 0x0) 
struct FPostNetworkLatencyInSession
{
	int32_t LatencyMs;  // 0x0(0x4)

}; 
// Function INTLPlugin.INTLSDKAPI.QueryAccountProfile
// Size: 0x1(Inherited: 0x0) 
struct FQueryAccountProfile
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function INTLPlugin.INTLSDKAPI.QueryActiveUser
// Size: 0x1(Inherited: 0x0) 
struct FQueryActiveUser
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function INTLPlugin.INTLSDKAPI.QueryCanBind
// Size: 0x40(Inherited: 0x0) 
struct FQueryCanBind
{
	int32_t ChannelID;  // 0x0(0x4)
	int32_t AccountPlatType;  // 0x4(0x4)
	struct FString Account;  // 0x8(0x10)
	struct FString PhoneAreaCode;  // 0x18(0x10)
	struct FString ExtraJson;  // 0x28(0x10)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool ReturnValue : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)

}; 
// Function INTLPlugin.INTLSDKAPI.QueryDirNode
// Size: 0x8(Inherited: 0x0) 
struct FQueryDirNode
{
	int32_t TreeId;  // 0x0(0x4)
	int32_t NodeId;  // 0x4(0x4)

}; 
// Function INTLPlugin.INTLSDKAPI.QueryFriends
// Size: 0x28(Inherited: 0x0) 
struct FQueryFriends
{
	uint8_t  Channel;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	int32_t Page;  // 0x4(0x4)
	int32_t Count;  // 0x8(0x4)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool IsInGame : 1;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)
	struct FString ExtraJson;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool ReturnValue : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// Function INTLPlugin.INTLSDKAPI.QueryIsEEA
// Size: 0x10(Inherited: 0x0) 
struct FQueryIsEEA
{
	struct FString Region;  // 0x0(0x10)

}; 
// Function INTLPlugin.INTLSDKAPI.QueryIsReceiveEmail
// Size: 0x38(Inherited: 0x0) 
struct FQueryIsReceiveEmail
{
	struct FString Account;  // 0x0(0x10)
	struct FString PhoneAreaCode;  // 0x10(0x10)
	struct FString ExtraJson;  // 0x20(0x10)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool ReturnValue : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)

}; 
// Function INTLPlugin.INTLSDKAPI.QueryRegisterStatus
// Size: 0x38(Inherited: 0x0) 
struct FQueryRegisterStatus
{
	struct FString Account;  // 0x0(0x10)
	struct FString PhoneAreaCode;  // 0x10(0x10)
	struct FString ExtraJson;  // 0x20(0x10)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool ReturnValue : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)

}; 
// Function INTLPlugin.INTLSDKAPI.QueryUserNameStatus
// Size: 0x10(Inherited: 0x0) 
struct FQueryUserNameStatus
{
	struct FString UserName;  // 0x0(0x10)

}; 
// Function INTLPlugin.INTLSDKAPI.QueryVerifyCodeStatus
// Size: 0x50(Inherited: 0x0) 
struct FQueryVerifyCodeStatus
{
	struct FString Account;  // 0x0(0x10)
	struct FString VerifyCode;  // 0x10(0x10)
	uint8_t  CodeType;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct FString PhoneAreaCode;  // 0x28(0x10)
	struct FString ExtraJson;  // 0x38(0x10)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool ReturnValue : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function INTLPlugin.INTLSDKAPI.Register
// Size: 0x120(Inherited: 0x0) 
struct FRegister
{
	struct FString Account;  // 0x0(0x10)
	struct FString Password;  // 0x10(0x10)
	struct FString VerifyCode;  // 0x20(0x10)
	struct FString PhoneAreaCode;  // 0x30(0x10)
	struct FINTLAccountProfile userProfile;  // 0x40(0xD8)
	char pad_280_1 : 7;  // 0x118(0x1)
	bool ReturnValue : 1;  // 0x118(0x1)
	char pad_281[7];  // 0x119(0x7)

}; 
// Function INTLPlugin.INTLSDKAPI.ReportException
// Size: 0x88(Inherited: 0x0) 
struct FReportException
{
	int32_t Type;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FString ExceptionName;  // 0x8(0x10)
	struct FString ExceptionMsg;  // 0x18(0x10)
	struct FString ExceptionStack;  // 0x28(0x10)
	struct TMap<struct FString, struct FString> ExtInfo;  // 0x38(0x50)

}; 
// Function INTLPlugin.INTLSDKAPI.RegisterPush
// Size: 0x20(Inherited: 0x0) 
struct FRegisterPush
{
	struct FString Channel;  // 0x0(0x10)
	struct FString Account;  // 0x10(0x10)

}; 
// Function INTLPlugin.INTLSDKAPI.ReportBinary
// Size: 0x38(Inherited: 0x0) 
struct FReportBinary
{
	struct FString EventName;  // 0x0(0x10)
	struct FString Data;  // 0x10(0x10)
	int32_t Length;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)
	struct FString SpecificChannel;  // 0x28(0x10)

}; 
// Function INTLPlugin.INTLSDKAPI.ReportCustomEventStep
// Size: 0x80(Inherited: 0x0) 
struct FReportCustomEventStep
{
	struct FString EventName;  // 0x0(0x10)
	int32_t Step;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct FString StepName;  // 0x18(0x10)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool Result : 1;  // 0x28(0x1)
	char pad_41[3];  // 0x29(0x3)
	int32_t ErrorCode;  // 0x2C(0x4)
	struct TMap<struct FString, struct FString> ParamsMap;  // 0x30(0x50)

}; 
// Function INTLPlugin.INTLSDKAPI.ReportEvent
// Size: 0x80(Inherited: 0x0) 
struct FReportEvent
{
	struct FString EventName;  // 0x0(0x10)
	struct TMap<struct FString, struct FString> ParamsMap;  // 0x10(0x50)
	struct FString SpecificChannel;  // 0x60(0x10)
	struct FString ExtraJson;  // 0x70(0x10)

}; 
// Function INTLPlugin.INTLSDKAPI.ReportLoginStep
// Size: 0x70(Inherited: 0x0) 
struct FReportLoginStep
{
	int32_t Step;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FString StepName;  // 0x8(0x10)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool Result : 1;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)
	int32_t ErrorCode;  // 0x1C(0x4)
	struct TMap<struct FString, struct FString> ParamsMap;  // 0x20(0x50)

}; 
// Function INTLPlugin.INTLSDKAPI.ReportPayStep
// Size: 0x70(Inherited: 0x0) 
struct FReportPayStep
{
	int32_t Step;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FString StepName;  // 0x8(0x10)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool Result : 1;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)
	int32_t ErrorCode;  // 0x1C(0x4)
	struct TMap<struct FString, struct FString> ParamsMap;  // 0x20(0x50)

}; 
// Function INTLPlugin.INTLSDKAPI.ResetGuest
// Size: 0x1(Inherited: 0x0) 
struct FResetGuest
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function INTLPlugin.INTLSDKAPI.ResetPasswordWithOldPassword
// Size: 0x58(Inherited: 0x0) 
struct FResetPasswordWithOldPassword
{
	struct FString Account;  // 0x0(0x10)
	struct FString OldPassword;  // 0x10(0x10)
	struct FString PhoneAreaCode;  // 0x20(0x10)
	struct FString NewPassword;  // 0x30(0x10)
	struct FString ExtraJson;  // 0x40(0x10)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool ReturnValue : 1;  // 0x50(0x1)
	char pad_81[7];  // 0x51(0x7)

}; 
// Function INTLPlugin.INTLSDKAPI.ResetPasswordWithVerifyCode
// Size: 0x58(Inherited: 0x0) 
struct FResetPasswordWithVerifyCode
{
	struct FString Account;  // 0x0(0x10)
	struct FString VerifyCode;  // 0x10(0x10)
	struct FString PhoneAreaCode;  // 0x20(0x10)
	struct FString NewPassword;  // 0x30(0x10)
	struct FString ExtraJson;  // 0x40(0x10)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool ReturnValue : 1;  // 0x50(0x1)
	char pad_81[7];  // 0x51(0x7)

}; 
// Function INTLPlugin.INTLSDKAPI.SendMessage
// Size: 0xA0(Inherited: 0x0) 
struct FSendMessage
{
	struct FINTLFriendReqInfo Info;  // 0x0(0x88)
	struct FString Channel;  // 0x88(0x10)
	char pad_152_1 : 7;  // 0x98(0x1)
	bool ReturnValue : 1;  // 0x98(0x1)
	char pad_153[7];  // 0x99(0x7)

}; 
// Function INTLPlugin.INTLSDKAPI.SetAccountInfo
// Size: 0x20(Inherited: 0x0) 
struct FSetAccountInfo
{
	uint8_t  Channel;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	int32_t ChannelID;  // 0x4(0x4)
	struct FString LangType;  // 0x8(0x10)
	int32_t AccountPlatType;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)

}; 
// Function INTLPlugin.INTLSDKAPI.SetBuglyAppVersion
// Size: 0x10(Inherited: 0x0) 
struct FSetBuglyAppVersion
{
	struct FString appVersion;  // 0x0(0x10)

}; 
// Function INTLPlugin.INTLSDKAPI.SetCrashUserId
// Size: 0x10(Inherited: 0x0) 
struct FSetCrashUserId
{
	struct FString userId;  // 0x0(0x10)

}; 
// Function INTLPlugin.INTLSDKAPI.SetDeviceLevel
// Size: 0x4(Inherited: 0x0) 
struct FSetDeviceLevel
{
	int32_t Level;  // 0x0(0x4)

}; 
// Function INTLPlugin.INTLSDKAPI.SetTag
// Size: 0x20(Inherited: 0x0) 
struct FSetTag
{
	struct FString Channel;  // 0x0(0x10)
	struct FString Tag;  // 0x10(0x10)

}; 
// Function INTLPlugin.INTLSDKAPI.ShowAccountPicker
// Size: 0x1(Inherited: 0x0) 
struct FShowAccountPicker
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function INTLPlugin.INTLSDKAPI.Unbind
// Size: 0x30(Inherited: 0x0) 
struct FUnbind
{
	uint8_t  Channel;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FString UID;  // 0x8(0x10)
	struct FString ExtraJson;  // 0x18(0x10)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool ReturnValue : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)

}; 
// Function INTLPlugin.INTLSDKAPI.UnregisterPush
// Size: 0x10(Inherited: 0x0) 
struct FUnregisterPush
{
	struct FString Channel;  // 0x0(0x10)

}; 
// Function INTLPlugin.INTLSDKAPI.UpdateConfig
// Size: 0x68(Inherited: 0x0) 
struct FUpdateConfig
{
	struct TMap<struct FString, struct FString> Cfg;  // 0x0(0x50)
	struct FString Project;  // 0x50(0x10)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool ReturnValue : 1;  // 0x60(0x1)
	char pad_97[7];  // 0x61(0x7)

}; 
// Function INTLPlugin.INTLSDKAPI.UpdateContinue
// Size: 0x8(Inherited: 0x0) 
struct FUpdateContinue
{
	int32_t RepoID;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool ReturnValue : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)

}; 
// Function INTLPlugin.INTLSDKAPI.UpdateStart
// Size: 0x38(Inherited: 0x0) 
struct FUpdateStart
{
	struct FINTLUpdateInitInfo Info;  // 0x0(0x30)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool ReturnValue : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)

}; 
// Function INTLPlugin.INTLSDKAPI.UpdateStop
// Size: 0xC(Inherited: 0x0) 
struct FUpdateStop
{
	int32_t RepoID;  // 0x0(0x4)
	int32_t TaskID;  // 0x4(0x4)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)

}; 
// Function INTLPlugin.INTLUtility.RefreshCurToastCnt
// Size: 0x8(Inherited: 0x0) 
struct FRefreshCurToastCnt
{
	int32_t ChangeCnt;  // 0x0(0x4)
	int32_t ReturnValue;  // 0x4(0x4)

}; 
