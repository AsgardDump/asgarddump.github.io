#pragma once 
#include "SDK.h" 
 
 
// Function BPI_UI_PostMatchScreen_SubScreen.BPI_UI_PostMatchScreen_SubScreen_C.ShouldBeShown
// Size: 0xB9(Inherited: 0x0) 
struct FShouldBeShown
{
	struct FTigerMatchStats TigerMatchStats;  // 0x0(0xB8)
	char pad_184_1 : 7;  // 0xB8(0x1)
	bool bShouldShow : 1;  // 0xB8(0x1)

}; 
// Function BPI_UI_PostMatchScreen_SubScreen.BPI_UI_PostMatchScreen_SubScreen_C.GetFadeInAnimation
// Size: 0x8(Inherited: 0x0) 
struct FGetFadeInAnimation
{
	struct UWidgetAnimation* FadeInAnimation;  // 0x0(0x8)

}; 
// Function BPI_UI_PostMatchScreen_SubScreen.BPI_UI_PostMatchScreen_SubScreen_C.PrepareScreen
// Size: 0xC0(Inherited: 0x0) 
struct FPrepareScreen
{
	struct FTigerMatchStats MatchStats;  // 0x0(0xB8)
	struct UTBP_UI_PostMatchScreen_C* PostMatchScreen;  // 0xB8(0x8)

}; 
// Function BPI_UI_PostMatchScreen_SubScreen.BPI_UI_PostMatchScreen_SubScreen_C.GetFadeOutAnimation
// Size: 0x10(Inherited: 0x0) 
struct FGetFadeOutAnimation
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bFadeOutLeft : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct UWidgetAnimation* FadeOutAnimation;  // 0x8(0x8)

}; 
