#pragma once 
#include <ABP_VMP_BRU_M_HAIR_13_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass ABP_VMP_BRU_M_HAIR_13.ABP_VMP_BRU_M_HAIR_12_C
// Size: 0x1000(Inherited: 0x2C0) 
struct UABP_VMP_BRU_M_HAIR_12_C : public UAnimInstance
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x2C0(0x8)
	struct FAnimNode_Root AnimGraphNode_Root;  // 0x2C8(0x30)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace;  // 0x2F8(0x20)
	char pad_792[8];  // 0x318(0x8)
	struct FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_3;  // 0x320(0x440)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace;  // 0x760(0x20)
	struct FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_2;  // 0x780(0x440)
	struct FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics;  // 0xBC0(0x440)

	void AnimGraph(struct FPoseLink& AnimGraph); // Function ABP_VMP_BRU_M_HAIR_13.ABP_VMP_BRU_M_HAIR_12_C.AnimGraph
	void ExecuteUbergraph_ABP_VMP_BRU_M_HAIR_13(int32_t EntryPoint); // Function ABP_VMP_BRU_M_HAIR_13.ABP_VMP_BRU_M_HAIR_12_C.ExecuteUbergraph_ABP_VMP_BRU_M_HAIR_13
}; 



