#pragma once 
#include "SDK.h" 
 
 
// Function BPI_ChatWIndow_Owner.BPI_ChatWIndow_Owner_C.OnMessageInput
// Size: 0x19(Inherited: 0x0) 
struct FOnMessageInput
{
	struct FText MessageText;  // 0x0(0x18)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool OnlyGroup : 1;  // 0x18(0x1)

}; 
