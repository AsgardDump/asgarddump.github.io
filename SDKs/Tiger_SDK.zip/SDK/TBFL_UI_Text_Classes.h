#pragma once 
#include <TBFL_UI_Text_Structs.h>
 
 
 
// BlueprintGeneratedClass TBFL_UI_Text.TBFL_UI_Text_C
// Size: 0x28(Inherited: 0x28) 
struct UTBFL_UI_Text_C : public UBlueprintFunctionLibrary
{

	void GetTimeDayHoursMinutes(struct FTimespan InTimespan, struct UObject* __WorldContext, struct FText& OutText); // Function TBFL_UI_Text.TBFL_UI_Text_C.GetTimeDayHoursMinutes
	void Get Excluded Game Mode From Challenge Requirement(struct FTigerChallengeRequirementExcludeGameMode Mode Requirement, struct UObject* __WorldContext, struct FText& Game Mode); // Function TBFL_UI_Text.TBFL_UI_Text_C.Get Excluded Game Mode From Challenge Requirement
	void Get Game Mode as UIText(struct FString InGameModeId, struct UObject* __WorldContext, struct FText& Text); // Function TBFL_UI_Text.TBFL_UI_Text_C.Get Game Mode as UIText
	void Get Game Mode from Challenge Requirement(struct FTigerChallengeRequirementGameMode Mode Requirement, struct UObject* __WorldContext, struct FText& Game Mode); // Function TBFL_UI_Text.TBFL_UI_Text_C.Get Game Mode from Challenge Requirement
	void Get Timespan A UI Text For Daily Challenges(struct FTimespan InTime, struct UObject* __WorldContext, struct FText& FormattedTime); // Function TBFL_UI_Text.TBFL_UI_Text_C.Get Timespan A UI Text For Daily Challenges
	void Get Archetype Name From Archetype Enum(uint8_t  InArchetypeType, struct UObject* __WorldContext, struct FText& ArchetypeName); // Function TBFL_UI_Text.TBFL_UI_Text_C.Get Archetype Name From Archetype Enum
	void SetTextCapitalized(struct URichTextBlock* InTextBlock, struct FText InText, struct UObject* __WorldContext); // Function TBFL_UI_Text.TBFL_UI_Text_C.SetTextCapitalized
	void Get Timespan As UI Text For Store Entries(struct FTimespan InTimeStamp, struct UObject* __WorldContext, struct FText& Text); // Function TBFL_UI_Text.TBFL_UI_Text_C.Get Timespan As UI Text For Store Entries
	void Get Payment Response Text(char EShPaymentResult InPaymentResult, struct UObject* __WorldContext, struct FText& Text); // Function TBFL_UI_Text.TBFL_UI_Text_C.Get Payment Response Text
	void GetBuyResponseText(uint8_t  InResponse, struct UObject* __WorldContext, struct FText& Text); // Function TBFL_UI_Text.TBFL_UI_Text_C.GetBuyResponseText
	void GetSeasonExperienceSourceUIText(uint8_t  InExperieceSource, int32_t InMatchPlacement, struct UObject* __WorldContext, struct FText& OutText); // Function TBFL_UI_Text.TBFL_UI_Text_C.GetSeasonExperienceSourceUIText
	void Int To Digital Time Text(int32_t InValue, struct UObject* __WorldContext, struct FText& AsDigitalTime); // Function TBFL_UI_Text.TBFL_UI_Text_C.Int To Digital Time Text
	void Get Timespan As UI Text(struct FTimespan InTimespan, struct UObject* __WorldContext, struct FText& Formatted Timespan); // Function TBFL_UI_Text.TBFL_UI_Text_C.Get Timespan As UI Text
	void Get Discipline Slot From Challenge Requirement(struct FTigerChallengeRequirementDisciplineSlot InChallengeRequirement, struct UObject* __WorldContext, struct FText& Highlighted Text); // Function TBFL_UI_Text.TBFL_UI_Text_C.Get Discipline Slot From Challenge Requirement
	void Get Balance Mode From Challenge Requirement(struct FTigerChallengeRequirementBalanceMode Mode Requirement, struct UObject* __WorldContext, struct FText& Balance Mode); // Function TBFL_UI_Text.TBFL_UI_Text_C.Get Balance Mode From Challenge Requirement
	void Get Clan Name from Challenge Requirement(struct FTigerChallengeRequirementClan Clan Requirement, struct UObject* __WorldContext, struct FText& Text); // Function TBFL_UI_Text.TBFL_UI_Text_C.Get Clan Name from Challenge Requirement
	void Get Weapon Name From Challenge Requirement(struct FTigerChallengeRequirementWeaponType ChallengeRequirement, struct UObject* __WorldContext, struct FText& Weapon Name); // Function TBFL_UI_Text.TBFL_UI_Text_C.Get Weapon Name From Challenge Requirement
	void GetBalanceModeAsUIText(uint8_t  InBalanceMode, struct UObject* __WorldContext, struct FText& Text); // Function TBFL_UI_Text.TBFL_UI_Text_C.GetBalanceModeAsUIText
	void GetGroupModeAsUIText(uint8_t  GameGroupMode, struct UObject* __WorldContext, struct FText& GroupModeAsText); // Function TBFL_UI_Text.TBFL_UI_Text_C.GetGroupModeAsUIText
	void GetClanNameAsUIText(uint8_t  InClanEnum, struct UObject* __WorldContext, struct FText& ClanName); // Function TBFL_UI_Text.TBFL_UI_Text_C.GetClanNameAsUIText
	void Get Challenge Target Value(struct UTigerChallenge* TigerChallenge, struct UObject* __WorldContext, struct FText& FormattedText); // Function TBFL_UI_Text.TBFL_UI_Text_C.Get Challenge Target Value
	void GetBloodPotencyInUIText(uint8_t  BloodPotency, struct UObject* __WorldContext, struct FText& BloodPotencyAsText); // Function TBFL_UI_Text.TBFL_UI_Text_C.GetBloodPotencyInUIText
	void GetNpcTypeInUIText(uint8_t  NPCType, struct UObject* __WorldContext, struct FText& NPCTypeAsText); // Function TBFL_UI_Text.TBFL_UI_Text_C.GetNpcTypeInUIText
	void Wrap Text in Color(uint8_t  UIColor, uint8_t  ColourSpace, struct FText Text, struct UObject* __WorldContext, struct FText& Result); // Function TBFL_UI_Text.TBFL_UI_Text_C.Wrap Text in Color
	void Wrap Text in Markup(struct FName StyleName, struct FText TextToFormat, struct UObject* __WorldContext, struct FText& FormattedText); // Function TBFL_UI_Text.TBFL_UI_Text_C.Wrap Text in Markup
}; 



