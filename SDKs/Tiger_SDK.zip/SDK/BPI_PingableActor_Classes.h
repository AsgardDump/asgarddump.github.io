#pragma once 
#include <BPI_PingableActor_Structs.h>
 
 
 
// BlueprintGeneratedClass BPI_PingableActor.BPI_PingableActor_C
// Size: 0x28(Inherited: 0x28) 
struct UBPI_PingableActor_C : public UInterface
{

	void GetPingInfo(struct FTS_PingableActorInfo& OutInfo); // Function BPI_PingableActor.BPI_PingableActor_C.GetPingInfo
	void GetPingCategory(struct FName& OutCategory); // Function BPI_PingableActor.BPI_PingableActor_C.GetPingCategory
}; 



