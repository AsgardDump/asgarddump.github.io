#pragma once 
#include <StunVisuals_Structs.h>
 
 
 
// BlueprintGeneratedClass StunVisuals.StunVisuals_C
// Size: 0x238(Inherited: 0x228) 
struct AStunVisuals_C : public AActor
{
	struct UStaticMeshComponent* StaticMesh;  // 0x228(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x230(0x8)

}; 



