#pragma once 
#include "SDK.h" 
 
 
// Function BPI_UI_SystemMenu_CategoryInterface.BPI_UI_SystemMenu_CategoryInterface_C.HasUnappliedChanges
// Size: 0x1(Inherited: 0x0) 
struct FHasUnappliedChanges
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool OutHasUnappliedChanges : 1;  // 0x0(0x1)

}; 
// Function BPI_UI_SystemMenu_CategoryInterface.BPI_UI_SystemMenu_CategoryInterface_C.ApplyChanges
// Size: 0x2(Inherited: 0x0) 
struct FApplyChanges
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool OutShouldShowRevertPrompt : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool OutNeedsRestart : 1;  // 0x1(0x1)

}; 
