#pragma once 
#include <ABP_Civilian_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass ABP_Civilian.ABP_Civilian_C
// Size: 0x3ED0(Inherited: 0x430) 
struct UABP_Civilian_C : public UTigerNpcAnimInstance
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x430(0x8)
	struct FAnimNode_LayeredBoneBlend AnimGraphNode_LayeredBoneBlend_4;  // 0x438(0xC0)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_14;  // 0x4F8(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_13;  // 0x520(0x28)
	struct FTigerAnimNode_PlaySequenceByName TigerAnimGraphNode_PlaySequenceByName_8;  // 0x548(0x88)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_13;  // 0x5D0(0x30)
	struct FTigerAnimNode_PlaySequenceByName TigerAnimGraphNode_PlaySequenceByName_7;  // 0x600(0x88)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_12;  // 0x688(0x30)
	struct FTigerAnimNode_PlaySequenceByName TigerAnimGraphNode_PlaySequenceByName_6;  // 0x6B8(0x88)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_11;  // 0x740(0x30)
	struct FAnimNode_StateMachine AnimGraphNode_StateMachine_3;  // 0x770(0xB0)
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool_3;  // 0x820(0xA0)
	struct FTigerFilteredLayeredBlend TigerAnimGraphNode_FilteredLayeredBlending;  // 0x8C0(0xC8)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_7;  // 0x988(0x28)
	struct FAnimNode_Slot AnimGraphNode_Slot_6;  // 0x9B0(0x48)
	struct FTigerAnimNode_RandomPlayer TigerAnimGraphNode_RandomPlayer;  // 0x9F8(0xA0)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_6;  // 0xA98(0x28)
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose_5;  // 0xAC0(0x158)
	struct FAnimNode_Root AnimGraphNode_Root;  // 0xC18(0x30)
	struct FAnimNode_LayeredBoneBlend AnimGraphNode_LayeredBoneBlend_3;  // 0xC48(0xC0)
	char pad_3336[8];  // 0xD08(0x8)
	struct FAnimNode_TwoBoneIK AnimGraphNode_TwoBoneIK_2;  // 0xD10(0x1E0)
	struct FAnimNode_TwoBoneIK AnimGraphNode_TwoBoneIK;  // 0xEF0(0x1E0)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace_6;  // 0x10D0(0x20)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace_6;  // 0x10F0(0x20)
	struct FAnimNode_Slot AnimGraphNode_Slot_5;  // 0x1110(0x48)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_5;  // 0x1158(0x28)
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose_4;  // 0x1180(0x158)
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool_2;  // 0x12D8(0xA0)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_4;  // 0x1378(0x28)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_7;  // 0x13A0(0x80)
	struct FAnimNode_Slot AnimGraphNode_Slot_4;  // 0x1420(0x48)
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose_3;  // 0x1468(0x158)
	struct FAnimNode_Slot AnimGraphNode_Slot_3;  // 0x15C0(0x48)
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose_2;  // 0x1608(0x158)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_3;  // 0x1760(0x28)
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose;  // 0x1788(0x158)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_2;  // 0x18E0(0x28)
	struct FAnimNode_Slot AnimGraphNode_Slot_2;  // 0x1908(0x48)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_12;  // 0x1950(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_11;  // 0x1978(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_10;  // 0x19A0(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_9;  // 0x19C8(0x28)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_21;  // 0x19F0(0x108)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_6;  // 0x1AF8(0x80)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace_5;  // 0x1B78(0x20)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace_5;  // 0x1B98(0x20)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_10;  // 0x1BB8(0x30)
	struct FTigerAnimNode_PlaySequenceByName TigerAnimGraphNode_PlaySequenceByName_5;  // 0x1BE8(0x88)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_5;  // 0x1C70(0x80)
	struct FAnimNode_LayeredBoneBlend AnimGraphNode_LayeredBoneBlend_2;  // 0x1CF0(0xC0)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_9;  // 0x1DB0(0x30)
	struct FTigerAnimNode_PlaySequenceByName TigerAnimGraphNode_PlaySequenceByName_4;  // 0x1DE0(0x88)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_4;  // 0x1E68(0x80)
	struct FAnimNode_LayeredBoneBlend AnimGraphNode_LayeredBoneBlend;  // 0x1EE8(0xC0)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_8;  // 0x1FA8(0x30)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_8;  // 0x1FD8(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_7;  // 0x2000(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_6;  // 0x2028(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_5;  // 0x2050(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_4;  // 0x2078(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_3;  // 0x20A0(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_2;  // 0x20C8(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult;  // 0x20F0(0x28)
	struct FTigerAnimNode_PlaySequenceByName TigerAnimGraphNode_PlaySequenceByName_3;  // 0x2118(0x88)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace_4;  // 0x21A0(0x20)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace_4;  // 0x21C0(0x20)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_20;  // 0x21E0(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_19;  // 0x22E8(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_18;  // 0x23F0(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_17;  // 0x24F8(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_16;  // 0x2600(0x108)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_7;  // 0x2708(0x30)
	struct FTigerAnimNode_PlaySequenceByName TigerAnimGraphNode_PlaySequenceByName_2;  // 0x2738(0x88)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace_3;  // 0x27C0(0x20)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace_3;  // 0x27E0(0x20)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_15;  // 0x2800(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_14;  // 0x2908(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_13;  // 0x2A10(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_12;  // 0x2B18(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_11;  // 0x2C20(0x108)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_6;  // 0x2D28(0x30)
	struct FTigerAnimNode_PlaySequenceByName TigerAnimGraphNode_PlaySequenceByName;  // 0x2D58(0x88)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace_2;  // 0x2DE0(0x20)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace_2;  // 0x2E00(0x20)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_10;  // 0x2E20(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_9;  // 0x2F28(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_8;  // 0x3030(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_7;  // 0x3138(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_6;  // 0x3240(0x108)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_5;  // 0x3348(0x30)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace;  // 0x3378(0x20)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace;  // 0x3398(0x20)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_5;  // 0x33B8(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_4;  // 0x34C0(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_3;  // 0x35C8(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_2;  // 0x36D0(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone;  // 0x37D8(0x108)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_3;  // 0x38E0(0x80)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_4;  // 0x3960(0x30)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_2;  // 0x3990(0x80)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_3;  // 0x3A10(0x30)
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool;  // 0x3A40(0xA0)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer;  // 0x3AE0(0x80)
	struct FAnimNode_PoseSnapshot AnimGraphNode_PoseSnapshot;  // 0x3B60(0x90)
	struct FAnimNode_Slot AnimGraphNode_Slot;  // 0x3BF0(0x48)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_2;  // 0x3C38(0x30)
	struct FAnimNode_StateMachine AnimGraphNode_StateMachine_2;  // 0x3C68(0xB0)
	struct FAnimNode_StateResult AnimGraphNode_StateResult;  // 0x3D18(0x30)
	struct FAnimNode_StateMachine AnimGraphNode_StateMachine;  // 0x3D48(0xB0)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose;  // 0x3DF8(0x28)
	char pad_15904_1 : 7;  // 0x3E20(0x1)
	bool bIsDedicatedServer : 1;  // 0x3E20(0x1)
	char pad_15905[3];  // 0x3E21(0x3)
	struct FVector LeftFootstepPosition;  // 0x3E24(0xC)
	float LeftFootstepTime;  // 0x3E30(0x4)
	float RightFootstepTime;  // 0x3E34(0x4)
	struct FVector RightFootstepPosition;  // 0x3E38(0xC)
	struct FRotator CharacterRotation;  // 0x3E44(0xC)
	float YawDelta;  // 0x3E50(0x4)
	float DeltaX;  // 0x3E54(0x4)
	float YawDeltaSmooth;  // 0x3E58(0x4)
	char pad_15964_1 : 7;  // 0x3E5C(0x1)
	bool IsBeingFeedOn : 1;  // 0x3E5C(0x1)
	char pad_15965_1 : 7;  // 0x3E5D(0x1)
	bool IsRecovering : 1;  // 0x3E5D(0x1)
	char pad_15966_1 : 7;  // 0x3E5E(0x1)
	bool FullyRecoverd : 1;  // 0x3E5E(0x1)
	char pad_15967_1 : 7;  // 0x3E5F(0x1)
	bool InContextIdle : 1;  // 0x3E5F(0x1)
	struct FName CachedContextBasedIdle;  // 0x3E60(0x8)
	char pad_15976_1 : 7;  // 0x3E68(0x1)
	bool IsHoldingProp : 1;  // 0x3E68(0x1)
	char pad_15977[3];  // 0x3E69(0x3)
	struct FName FaceAnimSlotName_00;  // 0x3E6C(0x8)
	struct FName FaceAnimSlotName_01;  // 0x3E74(0x8)
	struct FName FaceAnimSlotName_02;  // 0x3E7C(0x8)
	struct FName FaceAnimSlotName_03;  // 0x3E84(0x8)
	struct FRotator LookAtSpineRotator;  // 0x3E8C(0xC)
	struct FRotator LookAtHeadRotator;  // 0x3E98(0xC)
	float LookAtVertical;  // 0x3EA4(0x4)
	float LookAtHorizontal;  // 0x3EA8(0x4)
	float LookAtHorizontalSlow;  // 0x3EAC(0x4)
	float AimYawDelta;  // 0x3EB0(0x4)
	float Speed_Smooth;  // 0x3EB4(0x4)
	struct TArray<struct UAnimMontage*> React Montage;  // 0x3EB8(0x10)
	struct UAkAudioEvent* FootstepAkEvent;  // 0x3EC8(0x8)

	void AnimGraph(struct FPoseLink& AnimGraph); // Function ABP_Civilian.ABP_Civilian_C.AnimGraph
	void PostFootStepAudio(); // Function ABP_Civilian.ABP_Civilian_C.PostFootStepAudio
	void AddEmotionalAnimationSet(struct UTigerAnimationSetCollection* InSetCollection); // Function ABP_Civilian.ABP_Civilian_C.AddEmotionalAnimationSet
	void Facial Animations(); // Function ABP_Civilian.ABP_Civilian_C.Facial Animations
	void StopCapMontage(uint8_t  A); // Function ABP_Civilian.ABP_Civilian_C.StopCapMontage
	void HandleContextualIdle(); // Function ABP_Civilian.ABP_Civilian_C.HandleContextualIdle
	void HandleFootstepSound(float FootstepDuration, bool LeftFoot); // Function ABP_Civilian.ABP_Civilian_C.HandleFootstepSound
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Civilian_AnimGraphNode_TransitionResult_BBA6A9724AFCD837302A6AB8D3D55CBB(); // Function ABP_Civilian.ABP_Civilian_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Civilian_AnimGraphNode_TransitionResult_BBA6A9724AFCD837302A6AB8D3D55CBB
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Civilian_AnimGraphNode_SequencePlayer_CA1CB30F44EF00F966251AAA867490CA(); // Function ABP_Civilian.ABP_Civilian_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Civilian_AnimGraphNode_SequencePlayer_CA1CB30F44EF00F966251AAA867490CA
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Civilian_AnimGraphNode_BlendListByBool_A6AB795945D148CB4AEE71AC2F76A9A2(); // Function ABP_Civilian.ABP_Civilian_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Civilian_AnimGraphNode_BlendListByBool_A6AB795945D148CB4AEE71AC2F76A9A2
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Civilian_AnimGraphNode_LayeredBoneBlend_D132CB474C4CD8732517EFAF61A0670E(); // Function ABP_Civilian.ABP_Civilian_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Civilian_AnimGraphNode_LayeredBoneBlend_D132CB474C4CD8732517EFAF61A0670E
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Civilian_TigerAnimGraphNode_RandomPlayer_AD270F954A6AC11814CAFDA6C00BC755(); // Function ABP_Civilian.ABP_Civilian_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Civilian_TigerAnimGraphNode_RandomPlayer_AD270F954A6AC11814CAFDA6C00BC755
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Civilian_AnimGraphNode_TransitionResult_DDB556484047FAEBC14C5687AA7ED506(); // Function ABP_Civilian.ABP_Civilian_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Civilian_AnimGraphNode_TransitionResult_DDB556484047FAEBC14C5687AA7ED506
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Civilian_AnimGraphNode_TransitionResult_FF7B69DD43977067A7C8EAA305F7DE94(); // Function ABP_Civilian.ABP_Civilian_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Civilian_AnimGraphNode_TransitionResult_FF7B69DD43977067A7C8EAA305F7DE94
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Civilian_AnimGraphNode_TransitionResult_C2A09BAA45A8969D20CC9693267BE7A9(); // Function ABP_Civilian.ABP_Civilian_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Civilian_AnimGraphNode_TransitionResult_C2A09BAA45A8969D20CC9693267BE7A9
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Civilian_AnimGraphNode_TransitionResult_8A689E074CAAA0BCC42C20A2E224F2E6(); // Function ABP_Civilian.ABP_Civilian_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Civilian_AnimGraphNode_TransitionResult_8A689E074CAAA0BCC42C20A2E224F2E6
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Civilian_AnimGraphNode_TransitionResult_3B5B01C94F495AA698FAF9BA69180E2C(); // Function ABP_Civilian.ABP_Civilian_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Civilian_AnimGraphNode_TransitionResult_3B5B01C94F495AA698FAF9BA69180E2C
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Civilian_AnimGraphNode_TransitionResult_1410EC2340A6B877E3B6CFB8046D439A(); // Function ABP_Civilian.ABP_Civilian_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Civilian_AnimGraphNode_TransitionResult_1410EC2340A6B877E3B6CFB8046D439A
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Civilian_AnimGraphNode_ModifyBone_8DCA473E4F0442A438726E9DC0F181A8(); // Function ABP_Civilian.ABP_Civilian_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Civilian_AnimGraphNode_ModifyBone_8DCA473E4F0442A438726E9DC0F181A8
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Civilian_AnimGraphNode_SequencePlayer_44626FDB45DD85C93968159051D3B35B(); // Function ABP_Civilian.ABP_Civilian_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Civilian_AnimGraphNode_SequencePlayer_44626FDB45DD85C93968159051D3B35B
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Civilian_AnimGraphNode_TransitionResult_4D238E45428FCC9B6A39B0B930AC8AA4(); // Function ABP_Civilian.ABP_Civilian_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Civilian_AnimGraphNode_TransitionResult_4D238E45428FCC9B6A39B0B930AC8AA4
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Civilian_AnimGraphNode_TransitionResult_8A7EC1F94AABA14079965D87190BA410(); // Function ABP_Civilian.ABP_Civilian_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Civilian_AnimGraphNode_TransitionResult_8A7EC1F94AABA14079965D87190BA410
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Civilian_AnimGraphNode_TransitionResult_5E507CAD402D56D610FC95B131D51453(); // Function ABP_Civilian.ABP_Civilian_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Civilian_AnimGraphNode_TransitionResult_5E507CAD402D56D610FC95B131D51453
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Civilian_AnimGraphNode_TransitionResult_F680FFE542EA01E2748D7598FBD52DE5(); // Function ABP_Civilian.ABP_Civilian_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Civilian_AnimGraphNode_TransitionResult_F680FFE542EA01E2748D7598FBD52DE5
	void BlueprintUpdateAnimation(float DeltaTimeX); // Function ABP_Civilian.ABP_Civilian_C.BlueprintUpdateAnimation
	void OnInitiateAnimationBlueprint(); // Function ABP_Civilian.ABP_Civilian_C.OnInitiateAnimationBlueprint
	void AddSets(struct UTigerAnimationSetCollection* SetCollection); // Function ABP_Civilian.ABP_Civilian_C.AddSets
	void AnimNotify_FootStep_Left(); // Function ABP_Civilian.ABP_Civilian_C.AnimNotify_FootStep_Left
	void AnimNotify_Footstep_Right(); // Function ABP_Civilian.ABP_Civilian_C.AnimNotify_Footstep_Right
	void OnFootstep(bool bIsLeftFoot, float FootstepDuration); // Function ABP_Civilian.ABP_Civilian_C.OnFootstep
	void OnNpcReactionEvent(struct FTigerNpcReactionEvent& ReactionEvent); // Function ABP_Civilian.ABP_Civilian_C.OnNpcReactionEvent
	void AnimNotify_FullyRecovered(); // Function ABP_Civilian.ABP_Civilian_C.AnimNotify_FullyRecovered
	void AnimNotify_ResetFeedingState(); // Function ABP_Civilian.ABP_Civilian_C.AnimNotify_ResetFeedingState
	void OnAnimationModeChanged(uint8_t  LastAnimationMode); // Function ABP_Civilian.ABP_Civilian_C.OnAnimationModeChanged
	void OnBumpedByPlayerEvent(struct ATigerPlayer* InPlayer, struct FVector& InDirectionToPlayer); // Function ABP_Civilian.ABP_Civilian_C.OnBumpedByPlayerEvent
	void OnSettle(struct FTigerSettleEvent& SettleEvent); // Function ABP_Civilian.ABP_Civilian_C.OnSettle
	void ExecuteUbergraph_ABP_Civilian(int32_t EntryPoint); // Function ABP_Civilian.ABP_Civilian_C.ExecuteUbergraph_ABP_Civilian
}; 



