#pragma once 
#include "SDK.h" 
 
 
// Function DefaultCycleStyle.DefaultCycleStyle_C.DetermineNextWeaponSlot
// Size: 0x29(Inherited: 0x10) 
struct FDetermineNextWeaponSlot : public FDetermineNextWeaponSlot
{
	struct ATigerPlayerController* InPlayerController;  // 0x0(0x8)
	uint8_t  InDirection;  // 0x8(0x1)
	uint8_t  ReturnValue;  // 0x9(0x1)
	char pad_26_1 : 7;  // 0x1A(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // 0xA(0x1)
	uint8_t  CallFunc_GetCurrentlyEquippedSlot_ReturnValue;  // 0xB(0x1)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0xC(0x4)
	uint8_t  CallFunc_IntToSlot_ReturnValue;  // 0x10(0x1)
	int32_t CallFunc_WrapSlotValue_ReturnValue;  // 0x14(0x4)
	uint8_t  CallFunc_IntToSlot_ReturnValue_2;  // 0x18(0x1)
	char pad_38_1 : 7;  // 0x26(0x1)
	bool CallFunc_IsValidWeaponSlotToCycle_ReturnValue : 1;  // 0x19(0x1)
	char pad_39_1 : 7;  // 0x27(0x1)
	bool CallFunc_HasWeaponForSlot_ReturnValue : 1;  // 0x1A(0x1)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x1B(0x1)
	uint8_t  CallFunc_GetCurrentlyEquippedSlot_ReturnValue_2;  // 0x1C(0x1)
	int32_t CallFunc_Conv_ByteToInt_ReturnValue;  // 0x20(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0x24(0x4)
	char pad_50_1 : 7;  // 0x32(0x1)
	bool CallFunc_NotEqual_IntInt_ReturnValue : 1;  // 0x28(0x1)

}; 
