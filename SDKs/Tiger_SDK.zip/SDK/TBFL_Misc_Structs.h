#pragma once 
#include "SDK.h" 
 
 
// Function TBFL_Misc.TBFL_Misc_C.ActivateAlarmAndReportAction
// Size: 0x98(Inherited: 0x0) 
struct FActivateAlarmAndReportAction
{
	struct FVector EventLocation;  // 0x0(0xC)
	float ActionRange;  // 0xC(0x4)
	struct ATigerCharacter* Character;  // 0x10(0x8)
	uint8_t  InAction;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct UObject* __WorldContext;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct ATigerPlayer* K2Node_DynamicCast_AsTiger_Player;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x38(0x1)
	char pad_57_1 : 7;  // 0x39(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0x39(0x1)
	char pad_58[2];  // 0x3A(0x2)
	float CallFunc_Square_ReturnValue;  // 0x3C(0x4)
	struct FTigerAIPlayerAction K2Node_MakeStruct_TigerAIPlayerAction;  // 0x40(0x58)

}; 
// Function TBFL_Misc.TBFL_Misc_C.MoveWidgetsFromSideAngle
// Size: 0x4D(Inherited: 0x0) 
struct FMoveWidgetsFromSideAngle
{
	float InWidgetDistance;  // 0x0(0x4)
	float InAngleDegrees;  // 0x4(0x4)
	struct UWidget* InTranslationWidget;  // 0x8(0x8)
	struct UWidget* InRotationWidget;  // 0x10(0x8)
	struct UWidget* InInverseTranslationWidget;  // 0x18(0x8)
	struct UObject* __WorldContext;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x28(0x1)
	char pad_41[3];  // 0x29(0x3)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0x2C(0x4)
	struct FVector2D CallFunc_GetRotated2D_ReturnValue;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x38(0x1)
	char pad_57[3];  // 0x39(0x3)
	struct FVector2D CallFunc_Multiply_Vector2DFloat_ReturnValue;  // 0x3C(0x8)
	struct FVector2D CallFunc_Multiply_Vector2DFloat_ReturnValue_2;  // 0x44(0x8)
	char pad_76_1 : 7;  // 0x4C(0x1)
	bool CallFunc_IsValid_ReturnValue_3 : 1;  // 0x4C(0x1)

}; 
// Function TBFL_Misc.TBFL_Misc_C.ActivateClientAlarmAndReportAction
// Size: 0xB0(Inherited: 0x0) 
struct FActivateClientAlarmAndReportAction
{
	struct UAkAudioEvent* Event;  // 0x0(0x8)
	struct FVector EventLocation;  // 0x8(0xC)
	float ActionRange;  // 0x14(0x4)
	struct ATigerCharacter* Character;  // 0x18(0x8)
	uint8_t  InAction;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct UObject* __WorldContext;  // 0x28(0x8)
	struct ATigerPlayer* CallFunc_GetLocalPlayer_ReturnValue;  // 0x30(0x8)
	float CallFunc_Square_ReturnValue;  // 0x38(0x4)
	int32_t CallFunc_PostEventAtLocation_ReturnValue;  // 0x3C(0x4)
	struct FTigerAIPlayerAction K2Node_MakeStruct_TigerAIPlayerAction;  // 0x40(0x58)
	struct ATigerPlayer* K2Node_DynamicCast_AsTiger_Player;  // 0x98(0x8)
	char pad_160_1 : 7;  // 0xA0(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0xA0(0x1)
	char pad_161_1 : 7;  // 0xA1(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue : 1;  // 0xA1(0x1)
	char pad_162[6];  // 0xA2(0x6)
	struct ATigerPlayerController* CallFunc_GetTigerPlayerController_ReturnValue;  // 0xA8(0x8)

}; 
// Function TBFL_Misc.TBFL_Misc_C.CanOpenMainMenu
// Size: 0x3F(Inherited: 0x0) 
struct FCanOpenMainMenu
{
	struct UObject* __WorldContext;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bCanOpenMatchMenu : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct AGameStateBase* CallFunc_GetGameState_ReturnValue;  // 0x10(0x8)
	struct UGameInstance* CallFunc_GetGameInstance_ReturnValue;  // 0x18(0x8)
	struct ATigerMatchGameState* K2Node_DynamicCast_AsTiger_Match_Game_State;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct UTBP_TigerGameInstance_C* K2Node_DynamicCast_AsTBP_Tiger_Game_Instance;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x38(0x1)
	uint8_t  CallFunc_GetMatchState_ReturnValue;  // 0x39(0x1)
	char pad_58_1 : 7;  // 0x3A(0x1)
	bool CallFunc_IsJoiningMatch_ReturnValue : 1;  // 0x3A(0x1)
	char pad_59_1 : 7;  // 0x3B(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x3B(0x1)
	char pad_60_1 : 7;  // 0x3C(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x3C(0x1)
	char pad_61_1 : 7;  // 0x3D(0x1)
	bool CallFunc_IsInMatch_InMatch : 1;  // 0x3D(0x1)
	char pad_62_1 : 7;  // 0x3E(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x3E(0x1)

}; 
// Function TBFL_Misc.TBFL_Misc_C.OpenTeamMenu
// Size: 0x19(Inherited: 0x0) 
struct FOpenTeamMenu
{
	struct ATigerMatchHUD* InMatchHud;  // 0x0(0x8)
	struct UObject* __WorldContext;  // 0x8(0x8)
	struct UTBP_UI_TeamMenu_C* CallFunc_Create_ReturnValue;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x18(0x1)

}; 
