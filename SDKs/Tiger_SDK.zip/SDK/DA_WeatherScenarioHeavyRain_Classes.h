#pragma once 
#include <DA_WeatherScenarioHeavyRain_Structs.h>
 
 
 
// BlueprintGeneratedClass DA_WeatherScenarioHeavyRain.DA_WeatherScenarioHeavyRain_C
// Size: 0x18C(Inherited: 0x18C) 
struct UDA_WeatherScenarioHeavyRain_C : public UDA_WeatherScenario_C
{

}; 



