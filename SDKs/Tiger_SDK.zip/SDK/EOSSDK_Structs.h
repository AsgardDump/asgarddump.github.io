#pragma once 
#include "SDK.h" 
 
 
// ScriptStruct EOSSDK.EOSAntiCheatActionContext
// Size: 0x18(Inherited: 0x0) 
struct FEOSAntiCheatActionContext
{
	struct FString ActionDetailString;  // 0x0(0x10)
	uint8_t  Action;  // 0x10(0x1)
	uint8_t  ActionReason;  // 0x11(0x1)
	char pad_18[6];  // 0x12(0x6)

}; 
// Function EOSSDK.EOSUserComponent.Client_ReceiveAntiCheatData
// Size: 0x10(Inherited: 0x0) 
struct FClient_ReceiveAntiCheatData
{
	struct TArray<char> InByteArray;  // 0x0(0x10)

}; 
// Function EOSSDK.EOSUserComponent.Server_EACConnected
// Size: 0x1(Inherited: 0x0) 
struct FServer_EACConnected
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bInEACConnected : 1;  // 0x0(0x1)

}; 
// Function EOSSDK.EOSUserComponent.Server_ReceiveAntiCheatData
// Size: 0x10(Inherited: 0x0) 
struct FServer_ReceiveAntiCheatData
{
	struct TArray<char> InByteArray;  // 0x0(0x10)

}; 
// Function EOSSDK.EOSUserComponent.Server_ReceiveConnectInfo
// Size: 0x20(Inherited: 0x0) 
struct FServer_ReceiveConnectInfo
{
	struct FString InToken;  // 0x0(0x10)
	struct FString InID;  // 0x10(0x10)

}; 
