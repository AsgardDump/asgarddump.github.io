#pragma once 
#include <DirectionalStyle_Structs.h>
 
 
 
// BlueprintGeneratedClass DirectionalStyle.DirectionalStyle_C
// Size: 0x49(Inherited: 0x48) 
struct UDirectionalStyle_C : public UTigerWeaponCycleStyle
{
	uint8_t  OutWeaponSlot;  // 0x48(0x1)

	uint8_t  DetermineNextWeaponSlot(struct ATigerPlayerController* InPlayerController, uint8_t  InDirection); // Function DirectionalStyle.DirectionalStyle_C.DetermineNextWeaponSlot
}; 



