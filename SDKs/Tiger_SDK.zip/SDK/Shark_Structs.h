#pragma once 
#include "SDK.h" 
 
 
// Function Shark.SharkAccounts.Login
// Size: 0x30(Inherited: 0x0) 
struct FLogin
{
	struct FString InEmail;  // 0x0(0x10)
	struct FString InPassword;  // 0x10(0x10)
	struct FDelegate InCallback;  // 0x20(0x10)

}; 
// DelegateFunction Shark.SharkAccounts.SharkLoginCallback__DelegateSignature
// Size: 0x98(Inherited: 0x0) 
struct FSharkLoginCallback__DelegateSignature
{
	struct FSharkLoginResult InResult;  // 0x0(0x98)

}; 
// ScriptStruct Shark.SharkTelemetryEventBase
// Size: 0x8(Inherited: 0x0) 
struct FSharkTelemetryEventBase
{
	char pad_0[8];  // 0x0(0x8)

}; 
// ScriptStruct Shark.SharkInt8Vector
// Size: 0x3(Inherited: 0x0) 
struct FSharkInt8Vector
{
	int8_t X;  // 0x0(0x1)
	int8_t Y;  // 0x1(0x1)
	int8_t Z;  // 0x2(0x1)

}; 
// Function Shark.SharkBlueprintFunctionLibrary.SetCustomPrimitiveDataVector4
// Size: 0x30(Inherited: 0x0) 
struct FSetCustomPrimitiveDataVector4
{
	struct UPrimitiveComponent* PrimitiveComponent;  // 0x0(0x8)
	uint8_t  CustomDataName;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct FVector4 Value;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool bDoRuntimeUpdate : 1;  // 0x20(0x1)
	char pad_33[15];  // 0x21(0xF)

}; 
// Function Shark.SharkAccounts.RegisterAndLogin
// Size: 0x60(Inherited: 0x0) 
struct FRegisterAndLogin
{
	struct FSharkAccountRegistrationData InRegistrationData;  // 0x0(0x50)
	struct FDelegate InCallback;  // 0x50(0x10)

}; 
// DelegateFunction Shark.SharkAccounts.SharkUsernameRegisteredQueryCallback__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FSharkUsernameRegisteredQueryCallback__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bInSuccess : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool bIsAvailable : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool bIsProfanity : 1;  // 0x2(0x1)
	char pad_3[5];  // 0x3(0x5)
	struct FString InUsername;  // 0x8(0x10)

}; 
// DelegateFunction Shark.SharkAccounts.SharkEmailRegisteredQueryCallback__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FSharkEmailRegisteredQueryCallback__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bInSuccess : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool bInRegistered : 1;  // 0x1(0x1)
	char pad_2[6];  // 0x2(0x6)
	struct FString InEmail;  // 0x8(0x10)

}; 
// Function Shark.SharkLoginHelperLibrary.GetErrorMessage
// Size: 0xA8(Inherited: 0x0) 
struct FGetErrorMessage
{
	struct FSharkLoginResult InLoginResult;  // 0x0(0x98)
	struct FString ReturnValue;  // 0x98(0x10)

}; 
// ScriptStruct Shark.SharkAccountActionResult
// Size: 0x30(Inherited: 0x0) 
struct FSharkAccountActionResult
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Success : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FString InternalErrorMessage;  // 0x8(0x10)
	struct FString InternalThirdPartyErrorMessage;  // 0x18(0x10)
	int32_t ErrorCode;  // 0x28(0x4)
	int32_t ThirdPartyErrorCode;  // 0x2C(0x4)

}; 
// Function Shark.SharkAccounts.QueryEmailRegisterStatus
// Size: 0x20(Inherited: 0x0) 
struct FQueryEmailRegisterStatus
{
	struct FString InEmail;  // 0x0(0x10)
	struct FDelegate InCallback;  // 0x10(0x10)

}; 
// ScriptStruct Shark.SharkRuntimeTextLocalizationPair
// Size: 0x20(Inherited: 0x0) 
struct FSharkRuntimeTextLocalizationPair
{
	struct FString Culture;  // 0x0(0x10)
	struct FString DisplayString;  // 0x10(0x10)

}; 
// Function Shark.SharkAccounts.QueryUsernameRegisterStatus
// Size: 0x20(Inherited: 0x0) 
struct FQueryUsernameRegisterStatus
{
	struct FString InUsername;  // 0x0(0x10)
	struct FDelegate InCallback;  // 0x10(0x10)

}; 
// ScriptStruct Shark.SharkRuntimeTextNetSerializer
// Size: 0x30(Inherited: 0x0) 
struct FSharkRuntimeTextNetSerializer
{
	struct FName TextKey;  // 0x0(0x8)
	struct TArray<struct FSharkRuntimeTextLocalizationPair> Localizations;  // 0x8(0x10)
	char pad_24[24];  // 0x18(0x18)

}; 
// Function Shark.SharkBlueprintFunctionLibrary.UnregisterApplicationHasReactivatedForSelf
// Size: 0x8(Inherited: 0x0) 
struct FUnregisterApplicationHasReactivatedForSelf
{
	struct UObject* InSelf;  // 0x0(0x8)

}; 
// ScriptStruct Shark.SharkLoginResult
// Size: 0x98(Inherited: 0x30) 
struct FSharkLoginResult : public FSharkAccountActionResult
{
	struct FString UserName;  // 0x30(0x10)
	struct FString OpenId;  // 0x40(0x10)
	struct FString Token;  // 0x50(0x10)
	struct FString PfKey;  // 0x60(0x10)
	struct FString Pf;  // 0x70(0x10)
	struct FString SharkmobToken;  // 0x80(0x10)
	uint8_t  AuthenticationChannelId;  // 0x90(0x1)
	char pad_145_1 : 7;  // 0x91(0x1)
	bool IsNewAccount : 1;  // 0x91(0x1)
	char pad_146[6];  // 0x92(0x6)

}; 
// Function Shark.SharkAccounts.PlatformLogin
// Size: 0x14(Inherited: 0x0) 
struct FPlatformLogin
{
	struct FDelegate InCallback;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bIsSharkmobAccountLoginEnabled : 1;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)

}; 
// ScriptStruct Shark.SharkTelemetryHTTPSRequestDataChunk
// Size: 0x20(Inherited: 0x0) 
struct FSharkTelemetryHTTPSRequestDataChunk
{
	struct FString log_name;  // 0x0(0x10)
	struct FString log_fields;  // 0x10(0x10)

}; 
// ScriptStruct Shark.SharkAccountRegistrationData
// Size: 0x50(Inherited: 0x0) 
struct FSharkAccountRegistrationData
{
	struct FString Email;  // 0x0(0x10)
	struct FString Password;  // 0x10(0x10)
	int32_t RegionId;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)
	struct FString UserName;  // 0x28(0x10)
	struct FString VerificationCode;  // 0x38(0x10)
	int32_t RecieveEmail;  // 0x48(0x4)
	char pad_76[4];  // 0x4C(0x4)

}; 
// ScriptStruct Shark.SharkRandomDeviation
// Size: 0x8(Inherited: 0x0) 
struct FSharkRandomDeviation
{
	float Min;  // 0x0(0x4)
	float Max;  // 0x4(0x4)

}; 
// Function Shark.SharkAccounts.SendRegistrationVerificationCode
// Size: 0x20(Inherited: 0x0) 
struct FSendRegistrationVerificationCode
{
	struct FString InEmail;  // 0x0(0x10)
	struct FDelegate InCallback;  // 0x10(0x10)

}; 
// DelegateFunction Shark.SharkAccounts.SharkAccountActionCallback__DelegateSignature
// Size: 0x30(Inherited: 0x0) 
struct FSharkAccountActionCallback__DelegateSignature
{
	struct FSharkAccountActionResult InResult;  // 0x0(0x30)

}; 
// DelegateFunction Shark.TigerForwardJSONTelemetry__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FTigerForwardJSONTelemetry__DelegateSignature
{
	struct FString InJsonData;  // 0x0(0x10)

}; 
// Function Shark.SharkBlueprintFunctionLibrary.RegisterApplicationHasReactivated
// Size: 0x10(Inherited: 0x0) 
struct FRegisterApplicationHasReactivated
{
	struct FDelegate InDelegate;  // 0x0(0x10)

}; 
// Function Shark.SharkBlueprintFunctionLibrary.GetNumMips
// Size: 0x10(Inherited: 0x0) 
struct FGetNumMips
{
	struct UTexture2D* InTexture;  // 0x0(0x8)
	int32_t ReturnValue;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)

}; 
// Function Shark.SharkBlueprintFunctionLibrary.GetPlatformType
// Size: 0x1(Inherited: 0x0) 
struct FGetPlatformType
{
	uint8_t  ReturnValue;  // 0x0(0x1)

}; 
// Function Shark.SharkBlueprintFunctionLibrary.LoadMultipleObjectsAsync
// Size: 0x20(Inherited: 0x0) 
struct FLoadMultipleObjectsAsync
{
	struct TArray<struct TSoftObjectPtr<UObject>> SoftObjects;  // 0x0(0x10)
	struct FDelegate OnLoaded;  // 0x10(0x10)

}; 
// DelegateFunction Shark.SharkBlueprintFunctionLibrary.OnAssetsLoaded__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FOnAssetsLoaded__DelegateSignature
{
	struct TArray<struct UObject*> InLoadedObjects;  // 0x0(0x10)

}; 
// ScriptStruct Shark.SharkGameInstanceId
// Size: 0x10(Inherited: 0x0) 
struct FSharkGameInstanceId
{
	char pad_0[16];  // 0x0(0x10)

}; 
// Function Shark.SharkBlueprintFunctionLibrary.SetCastDynamicShadows
// Size: 0x10(Inherited: 0x0) 
struct FSetCastDynamicShadows
{
	struct UPrimitiveComponent* InPrimitiveComponent;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool InValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// ScriptStruct Shark.SharkTelemetryDataBundle
// Size: 0x10(Inherited: 0x0) 
struct FSharkTelemetryDataBundle
{
	struct TArray<struct FSharkTelemetryHTTPSRequestDataChunk> Data;  // 0x0(0x10)

}; 
// ScriptStruct Shark.ShChannelInfo
// Size: 0x10(Inherited: 0x0) 
struct FShChannelInfo
{
	struct FShMapInfo map_info;  // 0x0(0x10)

}; 
// Function Shark.SharkBlueprintFunctionLibrary.SetCustomPrimitiveDataFloat
// Size: 0x18(Inherited: 0x0) 
struct FSetCustomPrimitiveDataFloat
{
	struct UPrimitiveComponent* PrimitiveComponent;  // 0x0(0x8)
	uint8_t  CustomDataName;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	float Value;  // 0xC(0x4)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bDoRuntimeUpdate : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// ScriptStruct Shark.ShMapInfo
// Size: 0x10(Inherited: 0x0) 
struct FShMapInfo
{
	struct FString sacc_token;  // 0x0(0x10)

}; 
// ScriptStruct Shark.SharkTelemetryDateTime
// Size: 0x1(Inherited: 0x0) 
struct FSharkTelemetryDateTime
{
	char pad_0[1];  // 0x0(0x1)

}; 
// Function Shark.SharkBlueprintFunctionLibrary.SetCustomPrimitiveDataVector2
// Size: 0x18(Inherited: 0x0) 
struct FSetCustomPrimitiveDataVector2
{
	struct UPrimitiveComponent* PrimitiveComponent;  // 0x0(0x8)
	uint8_t  CustomDataName;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	struct FVector2D Value;  // 0xC(0x8)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool bDoRuntimeUpdate : 1;  // 0x14(0x1)
	char pad_21[3];  // 0x15(0x3)

}; 
// Function Shark.SharkBlueprintFunctionLibrary.SetCustomPrimitiveDataVector3
// Size: 0x20(Inherited: 0x0) 
struct FSetCustomPrimitiveDataVector3
{
	struct UPrimitiveComponent* PrimitiveComponent;  // 0x0(0x8)
	uint8_t  CustomDataName;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	struct FVector Value;  // 0xC(0xC)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool bDoRuntimeUpdate : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)

}; 
// ScriptStruct Shark.SharkUserId
// Size: 0x10(Inherited: 0x0) 
struct FSharkUserId
{
	struct FString ID;  // 0x0(0x10)

}; 
// ScriptStruct Shark.SharkTokenBucket
// Size: 0xC(Inherited: 0x0) 
struct FSharkTokenBucket
{
	char pad_0[4];  // 0x0(0x4)
	float Capacity;  // 0x4(0x4)
	float TokenFillRatePerSecond;  // 0x8(0x4)

}; 
// ScriptStruct Shark.SharkRandomDeviationInt
// Size: 0x8(Inherited: 0x0) 
struct FSharkRandomDeviationInt
{
	int32_t Min;  // 0x0(0x4)
	int32_t Max;  // 0x4(0x4)

}; 
// ScriptStruct Shark.SharkRoundRobinClassSettings
// Size: 0x30(Inherited: 0x0) 
struct FSharkRoundRobinClassSettings
{
	struct TSoftClassPtr<UObject> Class;  // 0x0(0x28)
	char ETickingGroup TickingGroup;  // 0x28(0x1)
	char pad_41[3];  // 0x29(0x3)
	uint32_t FramesBetweenUpdates;  // 0x2C(0x4)

}; 
// ScriptStruct Shark.SharkServerMetricsConfig
// Size: 0x28(Inherited: 0x0) 
struct FSharkServerMetricsConfig
{
	float UploadIntervalSeconds;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FString UploadURI;  // 0x8(0x10)
	struct FString Database;  // 0x18(0x10)

}; 
// Function Shark.SharkRuntimeTextSubsystem.GetRuntimeText
// Size: 0x20(Inherited: 0x0) 
struct FGetRuntimeText
{
	struct FName InKey;  // 0x0(0x8)
	struct FText ReturnValue;  // 0x8(0x18)

}; 
// ScriptStruct Shark.SharkTelemtryEventData
// Size: 0x28(Inherited: 0x0) 
struct FSharkTelemtryEventData
{
	char pad_0[24];  // 0x0(0x18)
	struct UStruct* StaticPropertyStruct;  // 0x18(0x8)
	char pad_32[8];  // 0x20(0x8)

}; 
// ScriptStruct Shark.SharkTelemetrySettings
// Size: 0x50(Inherited: 0x0) 
struct FSharkTelemetrySettings
{
	struct FString DomainURL;  // 0x0(0x10)
	struct FString SecretKey;  // 0x10(0x10)
	struct FString ApplicationName;  // 0x20(0x10)
	struct FString ApplicationID;  // 0x30(0x10)
	int32_t DefaultRequestRetryCount;  // 0x40(0x4)
	int32_t ChunkDispatchMaxBodySizeBytes;  // 0x44(0x4)
	int32_t ChunkDispatchAmountThreshold;  // 0x48(0x4)
	float ChunkDispatchTimeSecondsThreshold;  // 0x4C(0x4)

}; 
// ScriptStruct Shark.SharkTelemetryHTTPSResponse
// Size: 0x98(Inherited: 0x0) 
struct FSharkTelemetryHTTPSResponse
{
	struct FSharkTelemetryHTTPSRequestHeader Title;  // 0x0(0x80)
	struct FSharkTelemetryHTTPSResponseDataChunk Data;  // 0x80(0x18)

}; 
// ScriptStruct Shark.SharkTelemetryHTTPSResponseDataChunk
// Size: 0x18(Inherited: 0x0) 
struct FSharkTelemetryHTTPSResponseDataChunk
{
	int32_t code;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FString Msg;  // 0x8(0x10)

}; 
// ScriptStruct Shark.SharkTelemetryHTTPSRequestHeader
// Size: 0x80(Inherited: 0x0) 
struct FSharkTelemetryHTTPSRequestHeader
{
	struct FString app_id;  // 0x0(0x10)
	struct FString app_name;  // 0x10(0x10)
	struct FString Timestamp;  // 0x20(0x10)
	struct FString seq_id;  // 0x30(0x10)
	struct FString retry_times;  // 0x40(0x10)
	struct FString key_x;  // 0x50(0x10)
	struct FString key_y;  // 0x60(0x10)
	struct FString key_z;  // 0x70(0x10)

}; 
// ScriptStruct Shark.SharkTelemetryHTTPSRequest
// Size: 0x90(Inherited: 0x0) 
struct FSharkTelemetryHTTPSRequest
{
	struct FSharkTelemetryHTTPSRequestHeader Title;  // 0x0(0x80)
	struct TArray<struct FSharkTelemetryHTTPSRequestDataChunk> Data;  // 0x80(0x10)

}; 
