#pragma once 
#include <TBP_AimAssist_9_Barrel_Structs.h>
 
 
 
// BlueprintGeneratedClass TBP_AimAssist_9_Barrel.TBP_AimAssist_9_Barrel_C
// Size: 0x240(Inherited: 0x240) 
struct UTBP_AimAssist_9_Barrel_C : public UTBP_AimAssist_Default_C
{

}; 



