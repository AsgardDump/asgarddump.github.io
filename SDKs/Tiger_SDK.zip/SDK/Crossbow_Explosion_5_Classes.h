#pragma once 
#include <Crossbow_Explosion_5_Structs.h>
 
 
 
// BlueprintGeneratedClass Crossbow_Explosion_5.Crossbow_Explosion_4_C
// Size: 0x500(Inherited: 0x4F8) 
struct ACrossbow_Explosion_4_C : public ATigerAreaEffect
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x4F8(0x8)

	void OnTriggerClient(); // Function Crossbow_Explosion_5.Crossbow_Explosion_4_C.OnTriggerClient
	void ExecuteUbergraph_Crossbow_Explosion_5(int32_t EntryPoint); // Function Crossbow_Explosion_5.Crossbow_Explosion_4_C.ExecuteUbergraph_Crossbow_Explosion_5
}; 



