#pragma once 
#include "SDK.h" 
 
 
// Function S_GrimoireCardTransition.SequenceDirector_C.SequenceEvent__ENTRYPOINTSequenceDirector_2
// Size: 0x8(Inherited: 0x0) 
struct FSequenceEvent__ENTRYPOINTSequenceDirector_2
{
	struct ATBP_Grimoire_Card_C* TBP_Grimoire_Card;  // 0x0(0x8)

}; 
// Function S_GrimoireCardTransition.SequenceDirector_C.Enable Floating
// Size: 0x8(Inherited: 0x0) 
struct FEnable Floating
{
	struct ATBP_Grimoire_Card_C* TBP_Grimoire_Card;  // 0x0(0x8)

}; 
// Function S_GrimoireCardTransition.SequenceDirector_C.ExecuteUbergraph_SequenceDirector
// Size: 0x18(Inherited: 0x0) 
struct FExecuteUbergraph_SequenceDirector
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct ATBP_Grimoire_Card_C* K2Node_CustomEvent_TBP_Grimoire_Card;  // 0x8(0x8)
	struct ATBP_Grimoire_Card_C* K2Node_CustomEvent_TBP_Grimoire_Card_2;  // 0x10(0x8)

}; 
// Function S_GrimoireCardTransition.SequenceDirector_C.Disable Floating
// Size: 0x8(Inherited: 0x0) 
struct FDisable Floating
{
	struct ATBP_Grimoire_Card_C* TBP_Grimoire_Card;  // 0x0(0x8)

}; 
// Function S_GrimoireCardTransition.SequenceDirector_C.SequenceEvent__ENTRYPOINTSequenceDirector_1
// Size: 0x8(Inherited: 0x0) 
struct FSequenceEvent__ENTRYPOINTSequenceDirector_1
{
	struct ATBP_Grimoire_Card_C* TBP_Grimoire_Card;  // 0x0(0x8)

}; 
// Function S_GrimoireCardTransition.SequenceDirector_C.SequenceEvent__ENTRYPOINTSequenceDirector_3
// Size: 0x8(Inherited: 0x0) 
struct FSequenceEvent__ENTRYPOINTSequenceDirector_3
{
	struct ATBP_Grimoire_Card_C* TBP_Grimoire_Card;  // 0x0(0x8)

}; 
