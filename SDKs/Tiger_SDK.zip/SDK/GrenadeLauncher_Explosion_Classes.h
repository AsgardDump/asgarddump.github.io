#pragma once 
#include <GrenadeLauncher_Explosion_Structs.h>
 
 
 
// BlueprintGeneratedClass GrenadeLauncher_Explosion.GrenadeLauncher_Explosion_C
// Size: 0x500(Inherited: 0x4F8) 
struct AGrenadeLauncher_Explosion_C : public ATigerAreaEffect
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x4F8(0x8)

	void OnTriggerClient(); // Function GrenadeLauncher_Explosion.GrenadeLauncher_Explosion_C.OnTriggerClient
	void ExecuteUbergraph_GrenadeLauncher_Explosion(int32_t EntryPoint); // Function GrenadeLauncher_Explosion.GrenadeLauncher_Explosion_C.ExecuteUbergraph_GrenadeLauncher_Explosion
}; 



