#pragma once 
#include <Crossbow_Explosion_3_Structs.h>
 
 
 
// BlueprintGeneratedClass Crossbow_Explosion_3.Crossbow_Explosion_2_C
// Size: 0x500(Inherited: 0x4F8) 
struct ACrossbow_Explosion_2_C : public ATigerAreaEffect
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x4F8(0x8)

	void OnTriggerClient(); // Function Crossbow_Explosion_3.Crossbow_Explosion_2_C.OnTriggerClient
	void ExecuteUbergraph_Crossbow_Explosion_3(int32_t EntryPoint); // Function Crossbow_Explosion_3.Crossbow_Explosion_2_C.ExecuteUbergraph_Crossbow_Explosion_3
}; 



