#pragma once 
#include "SDK.h" 
 
 
// Function NiagaraAnimNotifies.AnimNotify_PlayNiagaraEffect.GetSpawnedEffect
// Size: 0x8(Inherited: 0x0) 
struct FGetSpawnedEffect
{
	struct UFXSystemComponent* ReturnValue;  // 0x0(0x8)

}; 
