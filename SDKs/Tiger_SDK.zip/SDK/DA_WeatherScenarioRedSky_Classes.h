#pragma once 
#include <DA_WeatherScenarioRedSky_Structs.h>
 
 
 
// BlueprintGeneratedClass DA_WeatherScenarioRedSky.DA_WeatherScenarioRedSky_C
// Size: 0x18C(Inherited: 0x18C) 
struct UDA_WeatherScenarioRedSky_C : public UDA_WeatherScenario_C
{

}; 



