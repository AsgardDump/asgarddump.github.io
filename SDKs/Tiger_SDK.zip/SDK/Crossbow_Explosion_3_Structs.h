#pragma once 
#include "SDK.h" 
 
 
// Function Crossbow_Explosion_3.Crossbow_Explosion_2_C.ExecuteUbergraph_Crossbow_Explosion_3
// Size: 0x14(Inherited: 0x0) 
struct FExecuteUbergraph_Crossbow_Explosion_3
{
	int32_t EntryPoint;  // 0x0(0x4)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x4(0xC)
	int32_t CallFunc_PostEventAtLocation_ReturnValue;  // 0x10(0x4)

}; 
