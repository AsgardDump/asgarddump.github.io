#pragma once 
#include <ABP_V_HAIR_57_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass ABP_V_HAIR_57.ABP_V_HAIR_56_C
// Size: 0x2F8(Inherited: 0x2C0) 
struct UABP_V_HAIR_56_C : public UAnimInstance
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x2C0(0x8)
	struct FAnimNode_Root AnimGraphNode_Root;  // 0x2C8(0x30)

	void AnimGraph(struct FPoseLink& AnimGraph); // Function ABP_V_HAIR_57.ABP_V_HAIR_56_C.AnimGraph
	void ExecuteUbergraph_ABP_V_HAIR_57(int32_t EntryPoint); // Function ABP_V_HAIR_57.ABP_V_HAIR_56_C.ExecuteUbergraph_ABP_V_HAIR_57
}; 



