#pragma once 
#include "SDK.h" 
 
 
// Function I_Destruction.I_Destruction_C.StaticMeshComponentHit
// Size: 0x98(Inherited: 0x0) 
struct FStaticMeshComponentHit
{
	struct FHitResult HitResult;  // 0x0(0x8C)
	struct FVector ImpactVelocity;  // 0x8C(0xC)

}; 
