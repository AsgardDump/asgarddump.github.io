#pragma once 
#include "SDK.h" 
 
 
// Function TBFL_Npc.TBFL_Npc_C.GetAttachmentInfoFromIdentifier
// Size: 0xE0(Inherited: 0x0) 
struct FGetAttachmentInfoFromIdentifier
{
	struct FName Identifier;  // 0x0(0x8)
	struct UObject* __WorldContext;  // 0x8(0x8)
	struct FTigerPropAttachmentInfo ReturnValue;  // 0x10(0x60)
	ATigerPropDummy* AttachClass;  // 0x70(0x8)
	char pad_120[8];  // 0x78(0x8)
	struct FTigerPropAttachmentInfo CallFunc_GetAttachmentInfoFromIdentifierAndClass_ReturnValue;  // 0x80(0x60)

}; 
