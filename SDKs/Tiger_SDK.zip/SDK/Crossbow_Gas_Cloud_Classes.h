#pragma once 
#include <Crossbow_Gas_Cloud_Structs.h>
 
 
 
// BlueprintGeneratedClass Crossbow_Gas_Cloud.Crossbow_Gas_Cloud_C
// Size: 0x500(Inherited: 0x4F8) 
struct ACrossbow_Gas_Cloud_C : public ATigerAreaEffect
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x4F8(0x8)

	void OnTriggerClient(); // Function Crossbow_Gas_Cloud.Crossbow_Gas_Cloud_C.OnTriggerClient
	void OnVehicleHit(struct AActor* InActor); // Function Crossbow_Gas_Cloud.Crossbow_Gas_Cloud_C.OnVehicleHit
	void ReceiveBeginPlay(); // Function Crossbow_Gas_Cloud.Crossbow_Gas_Cloud_C.ReceiveBeginPlay
	void ExecuteUbergraph_Crossbow_Gas_Cloud(int32_t EntryPoint); // Function Crossbow_Gas_Cloud.Crossbow_Gas_Cloud_C.ExecuteUbergraph_Crossbow_Gas_Cloud
}; 



