#pragma once 
#include <TBFL_MetaStore_Structs.h>
 
 
 
// BlueprintGeneratedClass TBFL_MetaStore.TBFL_MetaStore_C
// Size: 0x28(Inherited: 0x28) 
struct UTBFL_MetaStore_C : public UBlueprintFunctionLibrary
{

	void ChooseInventoryItemSubItem(struct ATigerPlayer* InPlayerPawn, struct UTigerInventoryItemBase* InItem, struct UObject* __WorldContext, struct UTigerInventoryItemBase*& OutItem); // Function TBFL_MetaStore.TBFL_MetaStore_C.ChooseInventoryItemSubItem
	void GetStoreEntryUIName(struct FTigerMetaStoreEntry InStoreEntry, struct ATigerPlayer* InPlayerPawn, struct UObject* __WorldContext, struct FText& UiName); // Function TBFL_MetaStore.TBFL_MetaStore_C.GetStoreEntryUIName
}; 



