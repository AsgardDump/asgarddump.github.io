#pragma once 
#include "SDK.h" 
 
 
// Function ImgMedia.ImgMediaSource.GetSequencePath
// Size: 0x10(Inherited: 0x0) 
struct FGetSequencePath
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// Function ImgMedia.ImgMediaSource.GetProxies
// Size: 0x10(Inherited: 0x0) 
struct FGetProxies
{
	struct TArray<struct FString> OutProxies;  // 0x0(0x10)

}; 
// Function ImgMedia.ImgMediaSource.SetSequencePath
// Size: 0x10(Inherited: 0x0) 
struct FSetSequencePath
{
	struct FString Path;  // 0x0(0x10)

}; 
