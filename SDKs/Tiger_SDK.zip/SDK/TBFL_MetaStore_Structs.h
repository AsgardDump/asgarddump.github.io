#pragma once 
#include "SDK.h" 
 
 
// Function TBFL_MetaStore.TBFL_MetaStore_C.GetStoreEntryUIName
// Size: 0xD0(Inherited: 0x0) 
struct FGetStoreEntryUIName
{
	struct FTigerMetaStoreEntry InStoreEntry;  // 0x0(0x50)
	struct ATigerPlayer* InPlayerPawn;  // 0x50(0x8)
	struct UObject* __WorldContext;  // 0x58(0x8)
	struct FText UiName;  // 0x60(0x18)
	struct UTigerInventoryItemBase* FirstInventoryItem;  // 0x78(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x80(0x4)
	char pad_132_1 : 7;  // 0x84(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue : 1;  // 0x84(0x1)
	char pad_133_1 : 7;  // 0x85(0x1)
	bool Temp_bool_Variable : 1;  // 0x85(0x1)
	char pad_134[2];  // 0x86(0x2)
	struct UTigerInventoryItemBase* CallFunc_GetItemFromItemId_ReturnValue;  // 0x88(0x8)
	struct UTigerInventoryItemBase* CallFunc_ChooseInventoryItemSubItem_OutItem;  // 0x90(0x8)
	char pad_152_1 : 7;  // 0x98(0x1)
	bool CallFunc_TextIsEmpty_ReturnValue : 1;  // 0x98(0x1)
	char pad_153[7];  // 0x99(0x7)
	struct FText K2Node_Select_Default;  // 0xA0(0x18)
	struct FText CallFunc_TextToUpper_ReturnValue;  // 0xB8(0x18)

}; 
// Function TBFL_MetaStore.TBFL_MetaStore_C.ChooseInventoryItemSubItem
// Size: 0x40(Inherited: 0x0) 
struct FChooseInventoryItemSubItem
{
	struct ATigerPlayer* InPlayerPawn;  // 0x0(0x8)
	struct UTigerInventoryItemBase* InItem;  // 0x8(0x8)
	struct UObject* __WorldContext;  // 0x10(0x8)
	struct UTigerInventoryItemBase* OutItem;  // 0x18(0x8)
	struct UTigerCharacterCombinedItemConfiguration* K2Node_DynamicCast_AsTiger_Character_Combined_Item_Configuration;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x28(0x1)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x29(0x1)
	char pad_42[6];  // 0x2A(0x6)
	UTigerInventoryItemBase* CallFunc_GetItemFromCombinedContainer_ReturnValue;  // 0x30(0x8)
	struct UTigerInventoryItemBase* CallFunc_GetClassDefaultObject_ReturnValue;  // 0x38(0x8)

}; 
