#pragma once 
#include "SDK.h" 
 
 
// Function TBFL_UIColors.TBFL_UIColors_C.GetUIColorAsText
// Size: 0x68(Inherited: 0x0) 
struct FGetUIColorAsText
{
	uint8_t  UIColor;  // 0x0(0x1)
	uint8_t  ColourSpace;  // 0x1(0x1)
	char pad_2[6];  // 0x2(0x6)
	struct UObject* __WorldContext;  // 0x8(0x8)
	struct FText ColorText;  // 0x10(0x18)
	struct UTigerUIColorSet* CallFunc_GetData_ColorSet;  // 0x28(0x8)
	struct FLinearColor CallFunc_GetColor_ReturnValue;  // 0x30(0x10)
	struct FString CallFunc_Conv_ColorToString_ReturnValue;  // 0x40(0x10)
	struct FText CallFunc_Conv_StringToText_ReturnValue;  // 0x50(0x18)

}; 
// Function TBFL_UIColors.TBFL_UIColors_C.GetData
// Size: 0x10(Inherited: 0x0) 
struct FGetData
{
	struct UObject* __WorldContext;  // 0x0(0x8)
	struct UTigerUIColorSet* ColorSet;  // 0x8(0x8)

}; 
// Function TBFL_UIColors.TBFL_UIColors_C.GetUIColor
// Size: 0x38(Inherited: 0x0) 
struct FGetUIColor
{
	uint8_t  UIColor;  // 0x0(0x1)
	uint8_t  ColourSpace;  // 0x1(0x1)
	char pad_2[6];  // 0x2(0x6)
	struct UObject* __WorldContext;  // 0x8(0x8)
	struct FLinearColor LinearColor;  // 0x10(0x10)
	struct UTigerUIColorSet* CallFunc_GetData_ColorSet;  // 0x20(0x8)
	struct FLinearColor CallFunc_GetColor_ReturnValue;  // 0x28(0x10)

}; 
// Function TBFL_UIColors.TBFL_UIColors_C.GetUIColorSlate
// Size: 0x70(Inherited: 0x0) 
struct FGetUIColorSlate
{
	uint8_t  UIColor;  // 0x0(0x1)
	uint8_t  ColorSpace;  // 0x1(0x1)
	char pad_2[6];  // 0x2(0x6)
	struct UObject* __WorldContext;  // 0x8(0x8)
	struct FSlateColor SlateColor;  // 0x10(0x28)
	struct FLinearColor CallFunc_GetUIColor_LinearColor;  // 0x38(0x10)
	struct FSlateColor K2Node_MakeStruct_SlateColor;  // 0x48(0x28)

}; 
// Function TBFL_UIColors.TBFL_UIColors_C.GetBackgroundColorByPlayerStatus
// Size: 0xE0(Inherited: 0x0) 
struct FGetBackgroundColorByPlayerStatus
{
	char TBE_StatusIcon InPlayerStatus;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct UObject* __WorldContext;  // 0x8(0x8)
	struct FSlateColor OutAccentColor;  // 0x10(0x28)
	char TBE_StatusIcon Temp_byte_Variable;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct FSlateColor K2Node_MakeStruct_SlateColor;  // 0x40(0x28)
	struct FSlateColor K2Node_MakeStruct_SlateColor_2;  // 0x68(0x28)
	struct FSlateColor K2Node_MakeStruct_SlateColor_3;  // 0x90(0x28)
	struct FSlateColor K2Node_Select_Default;  // 0xB8(0x28)

}; 
// Function TBFL_UIColors.TBFL_UIColors_C.GetPlayerColorByIndex
// Size: 0x38(Inherited: 0x0) 
struct FGetPlayerColorByIndex
{
	char InPlayerIndex;  // 0x0(0x1)
	uint8_t  InColorSpace;  // 0x1(0x1)
	char pad_2[6];  // 0x2(0x6)
	struct UObject* __WorldContext;  // 0x8(0x8)
	struct FLinearColor Color;  // 0x10(0x10)
	char Temp_byte_Variable;  // 0x20(0x1)
	char pad_33_1 : 7;  // 0x21(0x1)
	bool CallFunc_GreaterEqual_ByteByte_ReturnValue : 1;  // 0x21(0x1)
	uint8_t  Temp_byte_Variable_2;  // 0x22(0x1)
	uint8_t  Temp_byte_Variable_3;  // 0x23(0x1)
	uint8_t  Temp_byte_Variable_4;  // 0x24(0x1)
	uint8_t  Temp_byte_Variable_5;  // 0x25(0x1)
	uint8_t  K2Node_Select_Default;  // 0x26(0x1)
	char pad_39[1];  // 0x27(0x1)
	struct FLinearColor CallFunc_GetUIColor_LinearColor;  // 0x28(0x10)

}; 
// Function TBFL_UIColors.TBFL_UIColors_C.GetOutlineColor
// Size: 0x74(Inherited: 0x0) 
struct FGetOutlineColor
{
	uint8_t  InOutlineMode;  // 0x0(0x1)
	char InPlayerIndex;  // 0x1(0x1)
	char pad_2[6];  // 0x2(0x6)
	struct UObject* __WorldContext;  // 0x8(0x8)
	struct FLinearColor Color;  // 0x10(0x10)
	uint8_t  Temp_byte_Variable;  // 0x20(0x1)
	char pad_33[3];  // 0x21(0x3)
	struct FLinearColor CallFunc_GetUIColor_LinearColor;  // 0x24(0x10)
	struct FLinearColor CallFunc_GetUIColor_LinearColor_2;  // 0x34(0x10)
	struct FLinearColor CallFunc_GetUIColor_LinearColor_3;  // 0x44(0x10)
	struct FLinearColor CallFunc_GetUIColor_LinearColor_4;  // 0x54(0x10)
	struct FLinearColor K2Node_Select_Default;  // 0x64(0x10)

}; 
// Function TBFL_UIColors.TBFL_UIColors_C.GetAccentColorByPlayerStatus
// Size: 0xA4(Inherited: 0x0) 
struct FGetAccentColorByPlayerStatus
{
	char TBE_StatusIcon InPlayerStatus;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct UObject* __WorldContext;  // 0x8(0x8)
	struct FLinearColor OutAccentColor;  // 0x10(0x10)
	char TBE_StatusIcon Temp_byte_Variable;  // 0x20(0x1)
	char pad_33[3];  // 0x21(0x3)
	struct FLinearColor Temp_struct_Variable;  // 0x24(0x10)
	struct FLinearColor Temp_struct_Variable_2;  // 0x34(0x10)
	struct FLinearColor Temp_struct_Variable_3;  // 0x44(0x10)
	struct FLinearColor Temp_struct_Variable_4;  // 0x54(0x10)
	struct FLinearColor Temp_struct_Variable_5;  // 0x64(0x10)
	struct FLinearColor Temp_struct_Variable_6;  // 0x74(0x10)
	struct FLinearColor Temp_struct_Variable_7;  // 0x84(0x10)
	struct FLinearColor K2Node_Select_Default;  // 0x94(0x10)

}; 
// Function TBFL_UIColors.TBFL_UIColors_C.GetColorByItemType
// Size: 0x6C(Inherited: 0x0) 
struct FGetColorByItemType
{
	struct UTigerItemAsset* InItemAsset;  // 0x0(0x8)
	struct UObject* __WorldContext;  // 0x8(0x8)
	struct FLinearColor OutColor;  // 0x10(0x10)
	uint8_t  Temp_byte_Variable;  // 0x20(0x1)
	char pad_33[3];  // 0x21(0x3)
	struct FLinearColor CallFunc_GetUIColor_LinearColor;  // 0x24(0x10)
	struct FLinearColor CallFunc_GetUIColor_LinearColor_2;  // 0x34(0x10)
	char pad_68_1 : 7;  // 0x44(0x1)
	bool CallFunc_NotEqual_ByteByte_ReturnValue : 1;  // 0x44(0x1)
	char pad_69_1 : 7;  // 0x45(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // 0x45(0x1)
	char pad_70[2];  // 0x46(0x2)
	struct UTigerAmmoAsset* K2Node_DynamicCast_AsTiger_Ammo_Asset;  // 0x48(0x8)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x50(0x1)
	char pad_81_1 : 7;  // 0x51(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_2 : 1;  // 0x51(0x1)
	char pad_82_1 : 7;  // 0x52(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x52(0x1)
	uint8_t  Temp_byte_Variable_2;  // 0x53(0x1)
	char pad_84_1 : 7;  // 0x54(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_3 : 1;  // 0x54(0x1)
	uint8_t  Temp_byte_Variable_3;  // 0x55(0x1)
	uint8_t  Temp_byte_Variable_4;  // 0x56(0x1)
	uint8_t  Temp_byte_Variable_5;  // 0x57(0x1)
	uint8_t  Temp_byte_Variable_6;  // 0x58(0x1)
	uint8_t  Temp_byte_Variable_7;  // 0x59(0x1)
	uint8_t  K2Node_Select_Default;  // 0x5A(0x1)
	char pad_91[1];  // 0x5B(0x1)
	struct FLinearColor CallFunc_GetUIColor_LinearColor_3;  // 0x5C(0x10)

}; 
