#pragma once 
#include <TBFL_Npc_Structs.h>
 
 
 
// BlueprintGeneratedClass TBFL_Npc.TBFL_Npc_C
// Size: 0x28(Inherited: 0x28) 
struct UTBFL_Npc_C : public UBlueprintFunctionLibrary
{

	struct FTigerPropAttachmentInfo GetAttachmentInfoFromIdentifier(struct FName Identifier, struct UObject* __WorldContext); // Function TBFL_Npc.TBFL_Npc_C.GetAttachmentInfoFromIdentifier
}; 



