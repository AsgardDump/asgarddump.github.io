#pragma once 
#include <S_GrimoireCardTransition_Structs.h>
 
 
 
// BlueprintGeneratedClass S_GrimoireCardTransition.SequenceDirector_C
// Size: 0x38(Inherited: 0x30) 
struct USequenceDirector_C : public ULevelSequenceDirector
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x30(0x8)

	void SequenceEvent__ENTRYPOINTSequenceDirector_3(struct ATBP_Grimoire_Card_C* TBP_Grimoire_Card); // Function S_GrimoireCardTransition.SequenceDirector_C.SequenceEvent__ENTRYPOINTSequenceDirector_3
	void SequenceEvent__ENTRYPOINTSequenceDirector_2(struct ATBP_Grimoire_Card_C* TBP_Grimoire_Card); // Function S_GrimoireCardTransition.SequenceDirector_C.SequenceEvent__ENTRYPOINTSequenceDirector_2
	void SequenceEvent__ENTRYPOINTSequenceDirector_1(struct ATBP_Grimoire_Card_C* TBP_Grimoire_Card); // Function S_GrimoireCardTransition.SequenceDirector_C.SequenceEvent__ENTRYPOINTSequenceDirector_1
	void Enable Floating(struct ATBP_Grimoire_Card_C* TBP_Grimoire_Card); // Function S_GrimoireCardTransition.SequenceDirector_C.Enable Floating
	void Disable Floating(struct ATBP_Grimoire_Card_C* TBP_Grimoire_Card); // Function S_GrimoireCardTransition.SequenceDirector_C.Disable Floating
	void ExecuteUbergraph_SequenceDirector(int32_t EntryPoint); // Function S_GrimoireCardTransition.SequenceDirector_C.ExecuteUbergraph_SequenceDirector
}; 



