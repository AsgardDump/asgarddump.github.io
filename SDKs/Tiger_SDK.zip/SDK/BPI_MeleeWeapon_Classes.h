#pragma once 
#include <BPI_MeleeWeapon_Structs.h>
 
 
 
// BlueprintGeneratedClass BPI_MeleeWeapon.BPI_MeleeWeapon_C
// Size: 0x28(Inherited: 0x28) 
struct UBPI_MeleeWeapon_C : public UInterface
{

	void GetMeleeWeaponCategory(char ENUM_MeleeWeaponCategories& MeleeWeaponCategory); // Function BPI_MeleeWeapon.BPI_MeleeWeapon_C.GetMeleeWeaponCategory
}; 



