#pragma once 
#include <BPI_MenuChangeInterface_Structs.h>
 
 
 
// BlueprintGeneratedClass BPI_MenuChangeInterface.BPI_MenuChangeInterface_C
// Size: 0x28(Inherited: 0x28) 
struct UBPI_MenuChangeInterface_C : public UInterface
{

	void On Menu Changed(struct TSoftClassPtr<UObject>& NewMenuWidget); // Function BPI_MenuChangeInterface.BPI_MenuChangeInterface_C.On Menu Changed
}; 



