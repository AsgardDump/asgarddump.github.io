#pragma once 
#include <DA_NearCameraFadeDb_Structs.h>
 
 
 
// BlueprintGeneratedClass DA_NearCameraFadeDb.DA_NearCameraFadeDb_C
// Size: 0xD0(Inherited: 0xD0) 
struct UDA_NearCameraFadeDb_C : public UTigerNearCameraFadeMaterialDb
{

}; 



