#pragma once 
#include "SDK.h" 
 
 
// ScriptStruct SharkPaymentSDK.ShReponse_Finalize
// Size: 0x10(Inherited: 0x0) 
struct FShReponse_Finalize
{
	struct FString Status;  // 0x0(0x10)

}; 
// ScriptStruct SharkPaymentSDK.ShRequest_Finalize
// Size: 0x20(Inherited: 0x0) 
struct FShRequest_Finalize
{
	struct FString Ticket;  // 0x0(0x10)
	struct FString TransactionId;  // 0x10(0x10)

}; 
// ScriptStruct SharkPaymentSDK.ShResponse_CreateTicket
// Size: 0x10(Inherited: 0x0) 
struct FShResponse_CreateTicket
{
	struct FString Ticket;  // 0x0(0x10)

}; 
// ScriptStruct SharkPaymentSDK.ShRequest_CreateTicket
// Size: 0x38(Inherited: 0x0) 
struct FShRequest_CreateTicket
{
	struct FString AppId;  // 0x0(0x10)
	struct FString userId;  // 0x10(0x10)
	struct FString AuthCode;  // 0x20(0x10)
	char PlatformBackend;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)

}; 
