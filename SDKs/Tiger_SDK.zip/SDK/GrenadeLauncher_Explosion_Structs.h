#pragma once 
#include "SDK.h" 
 
 
// Function GrenadeLauncher_Explosion.GrenadeLauncher_Explosion_C.ExecuteUbergraph_GrenadeLauncher_Explosion
// Size: 0x14(Inherited: 0x0) 
struct FExecuteUbergraph_GrenadeLauncher_Explosion
{
	int32_t EntryPoint;  // 0x0(0x4)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x4(0xC)
	int32_t CallFunc_PostEventAtLocation_ReturnValue;  // 0x10(0x4)

}; 
