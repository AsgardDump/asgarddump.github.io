#pragma once 
#include <OnlineSubsystemTiger_Structs.h>
 
 
 
// Class OnlineSubsystemTiger.TigerOnlineSubsystemSettings
// Size: 0x60(Inherited: 0x38) 
struct UTigerOnlineSubsystemSettings : public UDeveloperSettings
{
	struct FString SessionServiceUri;  // 0x38(0x10)
	int32_t MaxRequestRetries;  // 0x48(0x4)
	int32_t MatchmakingTimeoutSeconds;  // 0x4C(0x4)
	struct FString DsVersion;  // 0x50(0x10)

}; 



