#pragma once 
#include "SDK.h" 
 
 
// Function Crossbow_Gas_Cloud.Crossbow_Gas_Cloud_C.ExecuteUbergraph_Crossbow_Gas_Cloud
// Size: 0x79(Inherited: 0x0) 
struct FExecuteUbergraph_Crossbow_Gas_Cloud
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[12];  // 0x4(0xC)
	struct FTransform CallFunc_GetTransform_ReturnValue;  // 0x10(0x30)
	struct AActor* CallFunc_BeginDeferredActorSpawnFromClass_ReturnValue;  // 0x40(0x8)
	struct ATBP_VFX_FakeVolume_C* CallFunc_FinishSpawningActor_ReturnValue;  // 0x48(0x8)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x50(0xC)
	int32_t CallFunc_PostEventAtLocation_ReturnValue;  // 0x5C(0x4)
	struct AActor* K2Node_Event_InActor;  // 0x60(0x8)
	struct TScriptInterface<II_Destruction_C> K2Node_DynamicCast_AsI_Destruction;  // 0x68(0x10)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x78(0x1)

}; 
// Function Crossbow_Gas_Cloud.Crossbow_Gas_Cloud_C.OnVehicleHit
// Size: 0x8(Inherited: 0x8) 
struct FOnVehicleHit : public FOnVehicleHit
{
	struct AActor* InActor;  // 0x0(0x8)

}; 
