#pragma once 
#include <AnimationBudgetAllocator_Structs.h>
 
 
 
// Class AnimationBudgetAllocator.AnimationBudgetBlueprintLibrary
// Size: 0x28(Inherited: 0x28) 
struct UAnimationBudgetBlueprintLibrary : public UBlueprintFunctionLibrary
{

	void SetAnimationBudgetParameters(struct UObject* WorldContextObject, struct FAnimationBudgetAllocatorParameters& InParameters); // Function AnimationBudgetAllocator.AnimationBudgetBlueprintLibrary.SetAnimationBudgetParameters
	void EnableAnimationBudget(struct UObject* WorldContextObject, bool bEnabled); // Function AnimationBudgetAllocator.AnimationBudgetBlueprintLibrary.EnableAnimationBudget
}; 



// Class AnimationBudgetAllocator.SkeletalMeshComponentBudgeted
// Size: 0xF20(Inherited: 0xEF0) 
struct USkeletalMeshComponentBudgeted : public USkeletalMeshComponent
{
	char pad_3824[32];  // 0xEF0(0x20)
	char bAutoRegisterWithBudgetAllocator : 1;  // 0xF10(0x1)
	char bAutoCalculateSignificance : 1;  // 0xF10(0x1)
	char bShouldUseActorRenderedFlag : 1;  // 0xF10(0x1)
	char pad_3856_1 : 5;  // 0xF10(0x1)
	char pad_3857[16];  // 0xF11(0x10)

	void SetAutoRegisterWithBudgetAllocator(bool bInAutoRegisterWithBudgetAllocator); // Function AnimationBudgetAllocator.SkeletalMeshComponentBudgeted.SetAutoRegisterWithBudgetAllocator
}; 



