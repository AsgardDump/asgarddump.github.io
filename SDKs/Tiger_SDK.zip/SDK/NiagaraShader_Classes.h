#pragma once 
#include <NiagaraShader_Structs.h>
 
 
 
// Class NiagaraShader.NiagaraScriptBase
// Size: 0x28(Inherited: 0x28) 
struct UNiagaraScriptBase : public UObject
{

}; 



