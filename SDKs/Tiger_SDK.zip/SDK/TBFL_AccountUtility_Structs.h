#pragma once 
#include "SDK.h" 
 
 
// Function TBFL_AccountUtility.TBFL_AccountUtility_C.Check Password Format
// Size: 0x6D(Inherited: 0x0) 
struct FCheck Password Format
{
	struct FText In Password;  // 0x0(0x18)
	struct UObject* __WorldContext;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool Error : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct FText Message;  // 0x28(0x18)
	struct FString CallFunc_Conv_TextToString_ReturnValue;  // 0x40(0x10)
	struct FString CallFunc_Conv_TextToString_ReturnValue_2;  // 0x50(0x10)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool CallFunc_PartialMatch_ReturnValue : 1;  // 0x60(0x1)
	char pad_97[3];  // 0x61(0x3)
	int32_t CallFunc_Len_ReturnValue;  // 0x64(0x4)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool CallFunc_LessEqual_IntInt_ReturnValue : 1;  // 0x68(0x1)
	char pad_105_1 : 7;  // 0x69(0x1)
	bool CallFunc_GreaterEqual_IntInt_ReturnValue : 1;  // 0x69(0x1)
	char pad_106_1 : 7;  // 0x6A(0x1)
	bool CallFunc_PartialMatch_ReturnValue_2 : 1;  // 0x6A(0x1)
	char pad_107_1 : 7;  // 0x6B(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x6B(0x1)
	char pad_108_1 : 7;  // 0x6C(0x1)
	bool CallFunc_TextIsEmpty_ReturnValue : 1;  // 0x6C(0x1)

}; 
// Function TBFL_AccountUtility.TBFL_AccountUtility_C.Check Verification Code Format
// Size: 0x55(Inherited: 0x0) 
struct FCheck Verification Code Format
{
	struct FText In Email;  // 0x0(0x18)
	struct UObject* __WorldContext;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool Error : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct FText Message;  // 0x28(0x18)
	struct FString CallFunc_Conv_TextToString_ReturnValue;  // 0x40(0x10)
	int32_t CallFunc_Len_ReturnValue;  // 0x50(0x4)
	char pad_84_1 : 7;  // 0x54(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x54(0x1)

}; 
// Function TBFL_AccountUtility.TBFL_AccountUtility_C.Check Email Format
// Size: 0x72(Inherited: 0x0) 
struct FCheck Email Format
{
	struct FText In Email;  // 0x0(0x18)
	struct UObject* __WorldContext;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool Error : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct FText Message;  // 0x28(0x18)
	struct FText CallFunc_TextTrimPrecedingAndTrailing_ReturnValue;  // 0x40(0x18)
	struct FString CallFunc_Conv_TextToString_ReturnValue;  // 0x58(0x10)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool CallFunc_TextIsEmpty_ReturnValue : 1;  // 0x68(0x1)
	char pad_105[3];  // 0x69(0x3)
	int32_t CallFunc_Len_ReturnValue;  // 0x6C(0x4)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool CallFunc_LessEqual_IntInt_ReturnValue : 1;  // 0x70(0x1)
	char pad_113_1 : 7;  // 0x71(0x1)
	bool CallFunc_PartialMatch_ReturnValue : 1;  // 0x71(0x1)

}; 
// Function TBFL_AccountUtility.TBFL_AccountUtility_C.Check UsernameNotInPassword
// Size: 0x61(Inherited: 0x0) 
struct FCheck UsernameNotInPassword
{
	struct FText InUsername;  // 0x0(0x18)
	struct FText InPassword;  // 0x18(0x18)
	struct UObject* __WorldContext;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool OutErrror : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct FString CallFunc_Conv_TextToString_ReturnValue;  // 0x40(0x10)
	struct FString CallFunc_Conv_TextToString_ReturnValue_2;  // 0x50(0x10)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool CallFunc_Contains_ReturnValue : 1;  // 0x60(0x1)

}; 
// Function TBFL_AccountUtility.TBFL_AccountUtility_C.Check Username Format
// Size: 0x70(Inherited: 0x0) 
struct FCheck Username Format
{
	struct FText In Email;  // 0x0(0x18)
	struct UObject* __WorldContext;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool Error : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct FText Message;  // 0x28(0x18)
	struct FString CallFunc_Conv_TextToString_ReturnValue;  // 0x40(0x10)
	struct FText CallFunc_TextTrimPrecedingAndTrailing_ReturnValue;  // 0x50(0x18)
	int32_t CallFunc_Len_ReturnValue;  // 0x68(0x4)
	char pad_108_1 : 7;  // 0x6C(0x1)
	bool CallFunc_TextIsEmpty_ReturnValue : 1;  // 0x6C(0x1)
	char pad_109_1 : 7;  // 0x6D(0x1)
	bool CallFunc_LessEqual_IntInt_ReturnValue : 1;  // 0x6D(0x1)
	char pad_110_1 : 7;  // 0x6E(0x1)
	bool CallFunc_PartialMatch_ReturnValue : 1;  // 0x6E(0x1)
	char pad_111_1 : 7;  // 0x6F(0x1)
	bool CallFunc_PartialMatch_ReturnValue_2 : 1;  // 0x6F(0x1)

}; 
// Function TBFL_AccountUtility.TBFL_AccountUtility_C.Check Date Of Birth
// Size: 0xF0(Inherited: 0x0) 
struct FCheck Date Of Birth
{
	struct FDateTime InDateOfBirth;  // 0x0(0x8)
	int32_t InSelectedCountryIndex;  // 0x8(0x4)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool InCountrySelected : 1;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)
	struct UObject* __WorldContext;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool bValid : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct FText Message;  // 0x20(0x18)
	int32_t ageLimit;  // 0x38(0x4)
	char pad_60[4];  // 0x3C(0x4)
	struct FDateTime CallFunc_Today_ReturnValue;  // 0x40(0x8)
	int32_t CallFunc_BreakDateTime_Year;  // 0x48(0x4)
	int32_t CallFunc_BreakDateTime_Month;  // 0x4C(0x4)
	int32_t CallFunc_BreakDateTime_Day;  // 0x50(0x4)
	int32_t CallFunc_BreakDateTime_Hour;  // 0x54(0x4)
	int32_t CallFunc_BreakDateTime_Minute;  // 0x58(0x4)
	int32_t CallFunc_BreakDateTime_Second;  // 0x5C(0x4)
	int32_t CallFunc_BreakDateTime_Millisecond;  // 0x60(0x4)
	int32_t CallFunc_Subtract_IntInt_ReturnValue;  // 0x64(0x4)
	struct FDateTime CallFunc_MakeDateTime_ReturnValue;  // 0x68(0x8)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool CallFunc_Greater_DateTimeDateTime_ReturnValue : 1;  // 0x70(0x1)
	char pad_113[7];  // 0x71(0x7)
	struct FString CallFunc_Conv_IntToString_ReturnValue;  // 0x78(0x10)
	struct FName CallFunc_Conv_StringToName_ReturnValue;  // 0x88(0x8)
	int32_t CallFunc_GetMinimumAccountCreationAge_ReturnValue;  // 0x90(0x4)
	char pad_148[4];  // 0x94(0x4)
	struct FTigerCountryCode CallFunc_GetDataTableRowFromName_OutRow;  // 0x98(0x50)
	char pad_232_1 : 7;  // 0xE8(0x1)
	bool CallFunc_GetDataTableRowFromName_ReturnValue : 1;  // 0xE8(0x1)
	char pad_233[3];  // 0xE9(0x3)
	int32_t CallFunc_Max_ReturnValue;  // 0xEC(0x4)

}; 
