#pragma once 
#include <ImgMedia_Structs.h>
 
 
 
// Class ImgMedia.ImgMediaSource
// Size: 0xB0(Inherited: 0x88) 
struct UImgMediaSource : public UBaseMediaSource
{
	struct FFrameRate FrameRateOverride;  // 0x88(0x8)
	struct FString ProxyOverride;  // 0x90(0x10)
	struct FDirectoryPath SequencePath;  // 0xA0(0x10)

	void SetSequencePath(struct FString Path); // Function ImgMedia.ImgMediaSource.SetSequencePath
	struct FString GetSequencePath(); // Function ImgMedia.ImgMediaSource.GetSequencePath
	void GetProxies(struct TArray<struct FString>& OutProxies); // Function ImgMedia.ImgMediaSource.GetProxies
}; 



