#pragma once 
#include <MagicLeapSharedWorld_Structs.h>
 
 
 
// Class MagicLeapSharedWorld.MagicLeapSharedWorldGameMode
// Size: 0x3E0(Inherited: 0x310) 
struct AMagicLeapSharedWorldGameMode : public AGameMode
{
	struct FMagicLeapSharedWorldSharedData SharedWorldData;  // 0x310(0x10)
	struct FMulticastInlineDelegate OnNewLocalDataFromClients;  // 0x320(0x10)
	float PinSelectionConfidenceThreshold;  // 0x330(0x4)
	char pad_820[164];  // 0x334(0xA4)
	struct AMagicLeapSharedWorldPlayerController* ChosenOne;  // 0x3D8(0x8)

	bool SendSharedWorldDataToClients(); // Function MagicLeapSharedWorld.MagicLeapSharedWorldGameMode.SendSharedWorldDataToClients
	void SelectChosenOne(); // Function MagicLeapSharedWorld.MagicLeapSharedWorldGameMode.SelectChosenOne
	void MagicLeapOnNewLocalDataFromClients__DelegateSignature(); // DelegateFunction MagicLeapSharedWorld.MagicLeapSharedWorldGameMode.MagicLeapOnNewLocalDataFromClients__DelegateSignature
	void DetermineSharedWorldData(struct FMagicLeapSharedWorldSharedData& NewSharedWorldData); // Function MagicLeapSharedWorld.MagicLeapSharedWorldGameMode.DetermineSharedWorldData
}; 



// Class MagicLeapSharedWorld.MagicLeapSharedWorldGameState
// Size: 0x2D8(Inherited: 0x298) 
struct AMagicLeapSharedWorldGameState : public AGameState
{
	struct FMagicLeapSharedWorldSharedData SharedWorldData;  // 0x298(0x10)
	struct FMagicLeapSharedWorldAlignmentTransforms AlignmentTransforms;  // 0x2A8(0x10)
	struct FMulticastInlineDelegate OnSharedWorldDataUpdated;  // 0x2B8(0x10)
	struct FMulticastInlineDelegate OnAlignmentTransformsUpdated;  // 0x2C8(0x10)

	void OnReplicate_SharedWorldData(); // Function MagicLeapSharedWorld.MagicLeapSharedWorldGameState.OnReplicate_SharedWorldData
	void OnReplicate_AlignmentTransforms(); // Function MagicLeapSharedWorld.MagicLeapSharedWorldGameState.OnReplicate_AlignmentTransforms
	void MagicLeapSharedWorldEvent__DelegateSignature(); // DelegateFunction MagicLeapSharedWorld.MagicLeapSharedWorldGameState.MagicLeapSharedWorldEvent__DelegateSignature
	struct FTransform CalculateXRCameraRootTransform(); // Function MagicLeapSharedWorld.MagicLeapSharedWorldGameState.CalculateXRCameraRootTransform
}; 



// Class MagicLeapSharedWorld.MagicLeapSharedWorldPlayerController
// Size: 0x590(Inherited: 0x578) 
struct AMagicLeapSharedWorldPlayerController : public APlayerController
{
	char pad_1400[24];  // 0x578(0x18)

	void ServerSetLocalWorldData(struct FMagicLeapSharedWorldLocalData LocalWorldReplicationData); // Function MagicLeapSharedWorld.MagicLeapSharedWorldPlayerController.ServerSetLocalWorldData
	void ServerSetAlignmentTransforms(struct FMagicLeapSharedWorldAlignmentTransforms InAlignmentTransforms); // Function MagicLeapSharedWorld.MagicLeapSharedWorldPlayerController.ServerSetAlignmentTransforms
	bool IsChosenOne(); // Function MagicLeapSharedWorld.MagicLeapSharedWorldPlayerController.IsChosenOne
	void ClientSetChosenOne(bool bChosenOne); // Function MagicLeapSharedWorld.MagicLeapSharedWorldPlayerController.ClientSetChosenOne
	void ClientMarkReadyForSendingLocalData(); // Function MagicLeapSharedWorld.MagicLeapSharedWorldPlayerController.ClientMarkReadyForSendingLocalData
	bool CanSendLocalDataToServer(); // Function MagicLeapSharedWorld.MagicLeapSharedWorldPlayerController.CanSendLocalDataToServer
}; 



