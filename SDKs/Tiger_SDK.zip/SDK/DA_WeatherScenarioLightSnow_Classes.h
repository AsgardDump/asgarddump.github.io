#pragma once 
#include <DA_WeatherScenarioLightSnow_Structs.h>
 
 
 
// BlueprintGeneratedClass DA_WeatherScenarioLightSnow.DA_WeatherScenarioLightSnow_C
// Size: 0x18C(Inherited: 0x18C) 
struct UDA_WeatherScenarioLightSnow_C : public UDA_WeatherScenario_C
{

}; 



