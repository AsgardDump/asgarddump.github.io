#pragma once 
#include <TBP_AimAssist_Assault_Rifle_Structs.h>
 
 
 
// BlueprintGeneratedClass TBP_AimAssist_Assault_Rifle.TBP_AimAssist_Assault_Rifle_C
// Size: 0x240(Inherited: 0x240) 
struct UTBP_AimAssist_Assault_Rifle_C : public UTBP_AimAssist_Default_C
{

}; 



