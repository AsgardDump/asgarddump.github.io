#pragma once 
#include "SDK.h" 
 
 
// Function TBFL_UI_Text.TBFL_UI_Text_C.GetBuyResponseText
// Size: 0x248(Inherited: 0x0) 
struct FGetBuyResponseText
{
	uint8_t  InResponse;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct UObject* __WorldContext;  // 0x8(0x8)
	struct FText Text;  // 0x10(0x18)
	struct FText BattlepassName_Text;  // 0x28(0x18)
	struct FText BattlepassError_Text;  // 0x40(0x18)
	uint8_t  Temp_byte_Variable;  // 0x58(0x1)
	char pad_89[7];  // 0x59(0x7)
	struct FText Temp_text_Variable;  // 0x60(0x18)
	struct FText Temp_text_Variable_2;  // 0x78(0x18)
	struct FText Temp_text_Variable_3;  // 0x90(0x18)
	struct FText Temp_text_Variable_4;  // 0xA8(0x18)
	struct FText Temp_text_Variable_5;  // 0xC0(0x18)
	struct FText Temp_text_Variable_6;  // 0xD8(0x18)
	struct FText Temp_text_Variable_7;  // 0xF0(0x18)
	struct FText Temp_text_Variable_8;  // 0x108(0x18)
	struct FText Temp_text_Variable_9;  // 0x120(0x18)
	struct FText Temp_text_Variable_10;  // 0x138(0x18)
	struct FText Temp_text_Variable_11;  // 0x150(0x18)
	struct FText Temp_text_Variable_12;  // 0x168(0x18)
	struct FText Temp_text_Variable_13;  // 0x180(0x18)
	struct FText Temp_text_Variable_14;  // 0x198(0x18)
	struct FText Temp_text_Variable_15;  // 0x1B0(0x18)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData;  // 0x1C8(0x40)
	struct TArray<struct FFormatArgumentData> K2Node_MakeArray_Array;  // 0x208(0x10)
	struct FText CallFunc_Format_ReturnValue;  // 0x218(0x18)
	struct FText K2Node_Select_Default;  // 0x230(0x18)

}; 
// Function TBFL_UI_Text.TBFL_UI_Text_C.GetClanNameAsUIText
// Size: 0x48(Inherited: 0x0) 
struct FGetClanNameAsUIText
{
	uint8_t  InClanEnum;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct UObject* __WorldContext;  // 0x8(0x8)
	struct FText ClanName;  // 0x10(0x18)
	struct UTigerPlayerClanData* ClanData;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)
	struct UTigerGameInstance* CallFunc_GetTigerGameInstance_ReturnValue;  // 0x38(0x8)
	struct UTigerPlayerClanData* CallFunc_GetClanData_ReturnValue;  // 0x40(0x8)

}; 
// Function TBFL_UI_Text.TBFL_UI_Text_C.Wrap Text in Markup
// Size: 0x100(Inherited: 0x0) 
struct FWrap Text in Markup
{
	struct FName StyleName;  // 0x0(0x8)
	struct FText TextToFormat;  // 0x8(0x18)
	struct UObject* __WorldContext;  // 0x20(0x8)
	struct FText FormattedText;  // 0x28(0x18)
	struct FText CallFunc_Conv_NameToText_ReturnValue;  // 0x40(0x18)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData;  // 0x58(0x40)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_2;  // 0x98(0x40)
	struct TArray<struct FFormatArgumentData> K2Node_MakeArray_Array;  // 0xD8(0x10)
	struct FText CallFunc_Format_ReturnValue;  // 0xE8(0x18)

}; 
// Function TBFL_UI_Text.TBFL_UI_Text_C.GetNpcTypeInUIText
// Size: 0xA8(Inherited: 0x0) 
struct FGetNpcTypeInUIText
{
	uint8_t  NPCType;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct UObject* __WorldContext;  // 0x8(0x8)
	struct FText NPCTypeAsText;  // 0x10(0x18)
	uint8_t  Temp_byte_Variable;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct FText Temp_text_Variable;  // 0x30(0x18)
	struct FText Temp_text_Variable_2;  // 0x48(0x18)
	struct FText Temp_text_Variable_3;  // 0x60(0x18)
	struct FText Temp_text_Variable_4;  // 0x78(0x18)
	struct FText K2Node_Select_Default;  // 0x90(0x18)

}; 
// Function TBFL_UI_Text.TBFL_UI_Text_C.Wrap Text in Color
// Size: 0x188(Inherited: 0x0) 
struct FWrap Text in Color
{
	uint8_t  UIColor;  // 0x0(0x1)
	uint8_t  ColourSpace;  // 0x1(0x1)
	char pad_2[6];  // 0x2(0x6)
	struct FText Text;  // 0x8(0x18)
	struct UObject* __WorldContext;  // 0x20(0x8)
	struct FText Result;  // 0x28(0x18)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData;  // 0x40(0x40)
	struct FLinearColor CallFunc_GetUIColor_LinearColor;  // 0x80(0x10)
	float CallFunc_BreakColor_R;  // 0x90(0x4)
	float CallFunc_BreakColor_G;  // 0x94(0x4)
	float CallFunc_BreakColor_B;  // 0x98(0x4)
	float CallFunc_BreakColor_A;  // 0x9C(0x4)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_2;  // 0xA0(0x40)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_3;  // 0xE0(0x40)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_4;  // 0x120(0x40)
	struct TArray<struct FFormatArgumentData> K2Node_MakeArray_Array;  // 0x160(0x10)
	struct FText CallFunc_Format_ReturnValue;  // 0x170(0x18)

}; 
// Function TBFL_UI_Text.TBFL_UI_Text_C.GetBloodPotencyInUIText
// Size: 0xA8(Inherited: 0x0) 
struct FGetBloodPotencyInUIText
{
	uint8_t  BloodPotency;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct UObject* __WorldContext;  // 0x8(0x8)
	struct FText BloodPotencyAsText;  // 0x10(0x18)
	uint8_t  Temp_byte_Variable;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct FText Temp_text_Variable;  // 0x30(0x18)
	struct FText Temp_text_Variable_2;  // 0x48(0x18)
	struct FText Temp_text_Variable_3;  // 0x60(0x18)
	struct FText Temp_text_Variable_4;  // 0x78(0x18)
	struct FText K2Node_Select_Default;  // 0x90(0x18)

}; 
// Function TBFL_UI_Text.TBFL_UI_Text_C.Get Challenge Target Value
// Size: 0x48(Inherited: 0x0) 
struct FGet Challenge Target Value
{
	struct UTigerChallenge* TigerChallenge;  // 0x0(0x8)
	struct UObject* __WorldContext;  // 0x8(0x8)
	struct FText FormattedText;  // 0x10(0x18)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x28(0x1)
	char pad_41[3];  // 0x29(0x3)
	int32_t CallFunc_GetTargetValue_ReturnValue;  // 0x2C(0x4)
	struct FText CallFunc_Conv_IntToText_ReturnValue;  // 0x30(0x18)

}; 
// Function TBFL_UI_Text.TBFL_UI_Text_C.GetGroupModeAsUIText
// Size: 0x90(Inherited: 0x0) 
struct FGetGroupModeAsUIText
{
	uint8_t  GameGroupMode;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct UObject* __WorldContext;  // 0x8(0x8)
	struct FText GroupModeAsText;  // 0x10(0x18)
	uint8_t  Temp_byte_Variable;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct FText Temp_text_Variable;  // 0x30(0x18)
	struct FText Temp_text_Variable_2;  // 0x48(0x18)
	struct FText Temp_text_Variable_3;  // 0x60(0x18)
	struct FText K2Node_Select_Default;  // 0x78(0x18)

}; 
// Function TBFL_UI_Text.TBFL_UI_Text_C.GetBalanceModeAsUIText
// Size: 0x78(Inherited: 0x0) 
struct FGetBalanceModeAsUIText
{
	uint8_t  InBalanceMode;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct UObject* __WorldContext;  // 0x8(0x8)
	struct FText Text;  // 0x10(0x18)
	uint8_t  Temp_byte_Variable;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct FText Temp_text_Variable;  // 0x30(0x18)
	struct FText Temp_text_Variable_2;  // 0x48(0x18)
	struct FText K2Node_Select_Default;  // 0x60(0x18)

}; 
// Function TBFL_UI_Text.TBFL_UI_Text_C.Get Weapon Name From Challenge Requirement
// Size: 0xC8(Inherited: 0x0) 
struct FGet Weapon Name From Challenge Requirement
{
	struct FTigerChallengeRequirementWeaponType ChallengeRequirement;  // 0x0(0x18)
	struct UObject* __WorldContext;  // 0x18(0x8)
	struct FText Weapon Name;  // 0x20(0x18)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool Temp_bool_Variable : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct FText Temp_text_Variable;  // 0x40(0x18)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x58(0x1)
	char pad_89_1 : 7;  // 0x59(0x1)
	bool CallFunc_IsValidClass_ReturnValue : 1;  // 0x59(0x1)
	char pad_90[6];  // 0x5A(0x6)
	struct FText Temp_text_Variable_2;  // 0x60(0x18)
	struct FText Temp_text_Variable_3;  // 0x78(0x18)
	char pad_144_1 : 7;  // 0x90(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0x90(0x1)
	char pad_145[7];  // 0x91(0x7)
	struct FText K2Node_Select_Default;  // 0x98(0x18)
	struct FText K2Node_Select_Default_2;  // 0xB0(0x18)

}; 
// Function TBFL_UI_Text.TBFL_UI_Text_C.Get Clan Name from Challenge Requirement
// Size: 0x48(Inherited: 0x0) 
struct FGet Clan Name from Challenge Requirement
{
	struct FTigerChallengeRequirementClan Clan Requirement;  // 0x0(0x10)
	struct UObject* __WorldContext;  // 0x10(0x8)
	struct FText Text;  // 0x18(0x18)
	struct FText CallFunc_GetClanNameAsUIText_ClanName;  // 0x30(0x18)

}; 
// Function TBFL_UI_Text.TBFL_UI_Text_C.Get Balance Mode From Challenge Requirement
// Size: 0x48(Inherited: 0x0) 
struct FGet Balance Mode From Challenge Requirement
{
	struct FTigerChallengeRequirementBalanceMode Mode Requirement;  // 0x0(0x10)
	struct UObject* __WorldContext;  // 0x10(0x8)
	struct FText Balance Mode;  // 0x18(0x18)
	struct FText CallFunc_GetBalanceModeAsUIText_Text;  // 0x30(0x18)

}; 
// Function TBFL_UI_Text.TBFL_UI_Text_C.Get Discipline Slot From Challenge Requirement
// Size: 0xE8(Inherited: 0x0) 
struct FGet Discipline Slot From Challenge Requirement
{
	struct FTigerChallengeRequirementDisciplineSlot InChallengeRequirement;  // 0x0(0x10)
	struct UObject* __WorldContext;  // 0x10(0x8)
	struct FText Highlighted Text;  // 0x18(0x18)
	uint8_t  Temp_byte_Variable;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)
	struct FText Temp_text_Variable;  // 0x38(0x18)
	struct FText Temp_text_Variable_2;  // 0x50(0x18)
	struct FText Temp_text_Variable_3;  // 0x68(0x18)
	struct FText Temp_text_Variable_4;  // 0x80(0x18)
	char pad_152_1 : 7;  // 0x98(0x1)
	bool Temp_bool_Variable : 1;  // 0x98(0x1)
	char pad_153[7];  // 0x99(0x7)
	struct FText K2Node_Select_Default;  // 0xA0(0x18)
	struct FText Temp_text_Variable_5;  // 0xB8(0x18)
	struct FText K2Node_Select_Default_2;  // 0xD0(0x18)

}; 
// Function TBFL_UI_Text.TBFL_UI_Text_C.Get Timespan As UI Text
// Size: 0x2E0(Inherited: 0x0) 
struct FGet Timespan As UI Text
{
	struct FTimespan InTimespan;  // 0x0(0x8)
	struct UObject* __WorldContext;  // 0x8(0x8)
	struct FText Formatted Timespan;  // 0x10(0x18)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool Temp_bool_Variable : 1;  // 0x28(0x1)
	char pad_41[3];  // 0x29(0x3)
	int32_t CallFunc_BreakTimespan_Days;  // 0x2C(0x4)
	int32_t CallFunc_BreakTimespan_Hours;  // 0x30(0x4)
	int32_t CallFunc_BreakTimespan_Minutes;  // 0x34(0x4)
	int32_t CallFunc_BreakTimespan_Seconds;  // 0x38(0x4)
	int32_t CallFunc_BreakTimespan_Milliseconds;  // 0x3C(0x4)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue : 1;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)
	struct FText CallFunc_Int_To_Digital_Time_Text_AsDigitalTime;  // 0x48(0x18)
	struct FText CallFunc_Int_To_Digital_Time_Text_AsDigitalTime_2;  // 0x60(0x18)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData;  // 0x78(0x40)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_2;  // 0xB8(0x40)
	struct FText CallFunc_Int_To_Digital_Time_Text_AsDigitalTime_3;  // 0xF8(0x18)
	struct FText CallFunc_Int_To_Digital_Time_Text_AsDigitalTime_4;  // 0x110(0x18)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_3;  // 0x128(0x40)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_4;  // 0x168(0x40)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_5;  // 0x1A8(0x40)
	struct TArray<struct FFormatArgumentData> K2Node_MakeArray_Array;  // 0x1E8(0x10)
	struct TArray<struct FFormatArgumentData> K2Node_MakeArray_Array_2;  // 0x1F8(0x10)
	struct FText CallFunc_Format_ReturnValue;  // 0x208(0x18)
	struct FText CallFunc_Format_ReturnValue_2;  // 0x220(0x18)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_6;  // 0x238(0x40)
	char pad_632_1 : 7;  // 0x278(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue_2 : 1;  // 0x278(0x1)
	char pad_633[7];  // 0x279(0x7)
	struct TArray<struct FFormatArgumentData> K2Node_MakeArray_Array_3;  // 0x280(0x10)
	struct FText CallFunc_Format_ReturnValue_3;  // 0x290(0x18)
	char pad_680_1 : 7;  // 0x2A8(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0x2A8(0x1)
	char pad_681[7];  // 0x2A9(0x7)
	struct FText K2Node_Select_Default;  // 0x2B0(0x18)
	struct FText K2Node_Select_Default_2;  // 0x2C8(0x18)

}; 
// Function TBFL_UI_Text.TBFL_UI_Text_C.Int To Digital Time Text
// Size: 0x40(Inherited: 0x0) 
struct FInt To Digital Time Text
{
	int32_t InValue;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UObject* __WorldContext;  // 0x8(0x8)
	struct FText AsDigitalTime;  // 0x10(0x18)
	struct FText CallFunc_Conv_IntToText_ReturnValue;  // 0x28(0x18)

}; 
// Function TBFL_UI_Text.TBFL_UI_Text_C.SetTextCapitalized
// Size: 0x40(Inherited: 0x0) 
struct FSetTextCapitalized
{
	struct URichTextBlock* InTextBlock;  // 0x0(0x8)
	struct FText InText;  // 0x8(0x18)
	struct UObject* __WorldContext;  // 0x20(0x8)
	struct FText CallFunc_TextToUpper_ReturnValue;  // 0x28(0x18)

}; 
// Function TBFL_UI_Text.TBFL_UI_Text_C.GetSeasonExperienceSourceUIText
// Size: 0x2A0(Inherited: 0x0) 
struct FGetSeasonExperienceSourceUIText
{
	uint8_t  InExperieceSource;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	int32_t InMatchPlacement;  // 0x4(0x4)
	struct UObject* __WorldContext;  // 0x8(0x8)
	struct FText OutText;  // 0x10(0x18)
	uint8_t  Temp_byte_Variable;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData;  // 0x30(0x40)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_2;  // 0x70(0x40)
	struct FText Temp_text_Variable;  // 0xB0(0x18)
	struct TArray<struct FFormatArgumentData> K2Node_MakeArray_Array;  // 0xC8(0x10)
	struct FText CallFunc_Format_ReturnValue;  // 0xD8(0x18)
	struct FText Temp_text_Variable_2;  // 0xF0(0x18)
	struct FText Temp_text_Variable_3;  // 0x108(0x18)
	struct FText Temp_text_Variable_4;  // 0x120(0x18)
	struct FText Temp_text_Variable_5;  // 0x138(0x18)
	struct FText Temp_text_Variable_6;  // 0x150(0x18)
	struct FText Temp_text_Variable_7;  // 0x168(0x18)
	struct FText Temp_text_Variable_8;  // 0x180(0x18)
	struct FText Temp_text_Variable_9;  // 0x198(0x18)
	struct FText Temp_text_Variable_10;  // 0x1B0(0x18)
	struct FText Temp_text_Variable_11;  // 0x1C8(0x18)
	struct FText Temp_text_Variable_12;  // 0x1E0(0x18)
	struct FText Temp_text_Variable_13;  // 0x1F8(0x18)
	struct FText Temp_text_Variable_14;  // 0x210(0x18)
	struct FText Temp_text_Variable_15;  // 0x228(0x18)
	struct FText Temp_text_Variable_16;  // 0x240(0x18)
	struct FText Temp_text_Variable_17;  // 0x258(0x18)
	struct FText Temp_text_Variable_18;  // 0x270(0x18)
	struct FText K2Node_Select_Default;  // 0x288(0x18)

}; 
// Function TBFL_UI_Text.TBFL_UI_Text_C.Get Payment Response Text
// Size: 0x138(Inherited: 0x0) 
struct FGet Payment Response Text
{
	char EShPaymentResult InPaymentResult;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct UObject* __WorldContext;  // 0x8(0x8)
	struct FText Text;  // 0x10(0x18)
	char EShPaymentResult Temp_byte_Variable;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct FText Temp_text_Variable;  // 0x30(0x18)
	struct FText Temp_text_Variable_2;  // 0x48(0x18)
	struct FText Temp_text_Variable_3;  // 0x60(0x18)
	struct FText Temp_text_Variable_4;  // 0x78(0x18)
	struct FText Temp_text_Variable_5;  // 0x90(0x18)
	struct FText Temp_text_Variable_6;  // 0xA8(0x18)
	struct FText Temp_text_Variable_7;  // 0xC0(0x18)
	struct FText Temp_text_Variable_8;  // 0xD8(0x18)
	struct FText Temp_text_Variable_9;  // 0xF0(0x18)
	struct FText Temp_text_Variable_10;  // 0x108(0x18)
	struct FText K2Node_Select_Default;  // 0x120(0x18)

}; 
// Function TBFL_UI_Text.TBFL_UI_Text_C.Get Archetype Name From Archetype Enum
// Size: 0x41(Inherited: 0x0) 
struct FGet Archetype Name From Archetype Enum
{
	uint8_t  InArchetypeType;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct UObject* __WorldContext;  // 0x8(0x8)
	struct FText ArchetypeName;  // 0x10(0x18)
	struct UTigerPowerKit* ArchetypeData;  // 0x28(0x8)
	struct UTigerGameInstance* CallFunc_GetTigerGameInstance_ReturnValue;  // 0x30(0x8)
	struct UTigerPowerKit* CallFunc_GetArchetypeData_ReturnValue;  // 0x38(0x8)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x40(0x1)

}; 
// Function TBFL_UI_Text.TBFL_UI_Text_C.Get Timespan As UI Text For Store Entries
// Size: 0x1C8(Inherited: 0x0) 
struct FGet Timespan As UI Text For Store Entries
{
	struct FTimespan InTimeStamp;  // 0x0(0x8)
	struct UObject* __WorldContext;  // 0x8(0x8)
	struct FText Text;  // 0x10(0x18)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool Temp_bool_Variable : 1;  // 0x28(0x1)
	char pad_41[3];  // 0x29(0x3)
	float CallFunc_GetTotalMinutes_ReturnValue;  // 0x2C(0x4)
	float CallFunc_GetTotalHours_ReturnValue;  // 0x30(0x4)
	int32_t CallFunc_FCeil_ReturnValue;  // 0x34(0x4)
	int32_t CallFunc_FCeil_ReturnValue_2;  // 0x38(0x4)
	char pad_60[4];  // 0x3C(0x4)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData;  // 0x40(0x40)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_2;  // 0x80(0x40)
	struct TArray<struct FFormatArgumentData> K2Node_MakeArray_Array;  // 0xC0(0x10)
	struct TArray<struct FFormatArgumentData> K2Node_MakeArray_Array_2;  // 0xD0(0x10)
	struct FText CallFunc_Format_ReturnValue;  // 0xE0(0x18)
	struct FText CallFunc_Format_ReturnValue_2;  // 0xF8(0x18)
	char pad_272_1 : 7;  // 0x110(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue : 1;  // 0x110(0x1)
	char pad_273[3];  // 0x111(0x3)
	float CallFunc_GetTotalDays_ReturnValue;  // 0x114(0x4)
	int32_t CallFunc_FCeil_ReturnValue_3;  // 0x118(0x4)
	char pad_284[4];  // 0x11C(0x4)
	struct FText K2Node_Select_Default;  // 0x120(0x18)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_3;  // 0x138(0x40)
	char pad_376_1 : 7;  // 0x178(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue_2 : 1;  // 0x178(0x1)
	char pad_377[7];  // 0x179(0x7)
	struct TArray<struct FFormatArgumentData> K2Node_MakeArray_Array_3;  // 0x180(0x10)
	char pad_400_1 : 7;  // 0x190(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0x190(0x1)
	char pad_401[7];  // 0x191(0x7)
	struct FText CallFunc_Format_ReturnValue_3;  // 0x198(0x18)
	struct FText K2Node_Select_Default_2;  // 0x1B0(0x18)

}; 
// Function TBFL_UI_Text.TBFL_UI_Text_C.Get Timespan A UI Text For Daily Challenges
// Size: 0x1E8(Inherited: 0x0) 
struct FGet Timespan A UI Text For Daily Challenges
{
	struct FTimespan InTime;  // 0x0(0x8)
	struct UObject* __WorldContext;  // 0x8(0x8)
	struct FText FormattedTime;  // 0x10(0x18)
	int32_t CallFunc_BreakTimespan_Days;  // 0x28(0x4)
	int32_t CallFunc_BreakTimespan_Hours;  // 0x2C(0x4)
	int32_t CallFunc_BreakTimespan_Minutes;  // 0x30(0x4)
	int32_t CallFunc_BreakTimespan_Seconds;  // 0x34(0x4)
	int32_t CallFunc_BreakTimespan_Milliseconds;  // 0x38(0x4)
	char pad_60[4];  // 0x3C(0x4)
	struct FText CallFunc_Conv_IntToText_ReturnValue;  // 0x40(0x18)
	struct FText CallFunc_Conv_IntToText_ReturnValue_2;  // 0x58(0x18)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData;  // 0x70(0x40)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_2;  // 0xB0(0x40)
	struct TArray<struct FFormatArgumentData> K2Node_MakeArray_Array;  // 0xF0(0x10)
	struct TArray<struct FFormatArgumentData> K2Node_MakeArray_Array_2;  // 0x100(0x10)
	struct FText CallFunc_Format_ReturnValue;  // 0x110(0x18)
	struct FText CallFunc_Format_ReturnValue_2;  // 0x128(0x18)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_3;  // 0x140(0x40)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_4;  // 0x180(0x40)
	struct TArray<struct FFormatArgumentData> K2Node_MakeArray_Array_3;  // 0x1C0(0x10)
	struct FText CallFunc_Format_ReturnValue_3;  // 0x1D0(0x18)

}; 
// Function TBFL_UI_Text.TBFL_UI_Text_C.Get Game Mode from Challenge Requirement
// Size: 0x58(Inherited: 0x0) 
struct FGet Game Mode from Challenge Requirement
{
	struct FTigerChallengeRequirementGameMode Mode Requirement;  // 0x0(0x20)
	struct UObject* __WorldContext;  // 0x20(0x8)
	struct FText Game Mode;  // 0x28(0x18)
	struct FText CallFunc_Get_Game_Mode_as_UIText_Text;  // 0x40(0x18)

}; 
// Function TBFL_UI_Text.TBFL_UI_Text_C.Get Game Mode as UIText
// Size: 0x31(Inherited: 0x0) 
struct FGet Game Mode as UIText
{
	struct FString InGameModeId;  // 0x0(0x10)
	struct UObject* __WorldContext;  // 0x10(0x8)
	struct FText Text;  // 0x18(0x18)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool K2Node_SwitchString_CmpSuccess : 1;  // 0x30(0x1)

}; 
// Function TBFL_UI_Text.TBFL_UI_Text_C.Get Excluded Game Mode From Challenge Requirement
// Size: 0x58(Inherited: 0x0) 
struct FGet Excluded Game Mode From Challenge Requirement
{
	struct FTigerChallengeRequirementExcludeGameMode Mode Requirement;  // 0x0(0x20)
	struct UObject* __WorldContext;  // 0x20(0x8)
	struct FText Game Mode;  // 0x28(0x18)
	struct FText CallFunc_Get_Game_Mode_as_UIText_Text;  // 0x40(0x18)

}; 
// Function TBFL_UI_Text.TBFL_UI_Text_C.GetTimeDayHoursMinutes
// Size: 0x128(Inherited: 0x0) 
struct FGetTimeDayHoursMinutes
{
	struct FTimespan InTimespan;  // 0x0(0x8)
	struct UObject* __WorldContext;  // 0x8(0x8)
	struct FText OutText;  // 0x10(0x18)
	int32_t CallFunc_BreakTimespan_Days;  // 0x28(0x4)
	int32_t CallFunc_BreakTimespan_Hours;  // 0x2C(0x4)
	int32_t CallFunc_BreakTimespan_Minutes;  // 0x30(0x4)
	int32_t CallFunc_BreakTimespan_Seconds;  // 0x34(0x4)
	int32_t CallFunc_BreakTimespan_Milliseconds;  // 0x38(0x4)
	char pad_60[4];  // 0x3C(0x4)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData;  // 0x40(0x40)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_2;  // 0x80(0x40)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_3;  // 0xC0(0x40)
	struct TArray<struct FFormatArgumentData> K2Node_MakeArray_Array;  // 0x100(0x10)
	struct FText CallFunc_Format_ReturnValue;  // 0x110(0x18)

}; 
