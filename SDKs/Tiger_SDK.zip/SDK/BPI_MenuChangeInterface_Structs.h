#pragma once 
#include "SDK.h" 
 
 
// Function BPI_MenuChangeInterface.BPI_MenuChangeInterface_C.On Menu Changed
// Size: 0x28(Inherited: 0x0) 
struct FOn Menu Changed
{
	struct TSoftClassPtr<UObject> NewMenuWidget;  // 0x0(0x28)

}; 
