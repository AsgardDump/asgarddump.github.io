#pragma once 
#include <ABP_SKM_VMP_BRU_F_HAIR_15_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass ABP_SKM_VMP_BRU_F_HAIR_15.ABP_SKM_VMP_BRU_F_HAIR_14_C
// Size: 0x3640(Inherited: 0x2C0) 
struct UABP_SKM_VMP_BRU_F_HAIR_14_C : public UAnimInstance
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x2C0(0x8)
	struct FAnimNode_Root AnimGraphNode_Root;  // 0x2C8(0x30)
	char pad_760[8];  // 0x2F8(0x8)
	struct FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_12;  // 0x300(0x440)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace;  // 0x740(0x20)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace;  // 0x760(0x20)
	struct FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_11;  // 0x780(0x440)
	struct FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_10;  // 0xBC0(0x440)
	struct FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_9;  // 0x1000(0x440)
	struct FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_8;  // 0x1440(0x440)
	struct FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_7;  // 0x1880(0x440)
	struct FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_6;  // 0x1CC0(0x440)
	struct FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_5;  // 0x2100(0x440)
	struct FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_4;  // 0x2540(0x440)
	struct FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_3;  // 0x2980(0x440)
	struct FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_2;  // 0x2DC0(0x440)
	struct FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics;  // 0x3200(0x440)

	void AnimGraph(struct FPoseLink& AnimGraph); // Function ABP_SKM_VMP_BRU_F_HAIR_15.ABP_SKM_VMP_BRU_F_HAIR_14_C.AnimGraph
	void ExecuteUbergraph_ABP_SKM_VMP_BRU_F_HAIR_15(int32_t EntryPoint); // Function ABP_SKM_VMP_BRU_F_HAIR_15.ABP_SKM_VMP_BRU_F_HAIR_14_C.ExecuteUbergraph_ABP_SKM_VMP_BRU_F_HAIR_15
}; 



