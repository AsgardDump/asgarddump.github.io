#pragma once 
#include <TBFL_UIColors_Structs.h>
 
 
 
// BlueprintGeneratedClass TBFL_UIColors.TBFL_UIColors_C
// Size: 0x28(Inherited: 0x28) 
struct UTBFL_UIColors_C : public UBlueprintFunctionLibrary
{

	void GetColorByItemType(struct UTigerItemAsset* InItemAsset, struct UObject* __WorldContext, struct FLinearColor& OutColor); // Function TBFL_UIColors.TBFL_UIColors_C.GetColorByItemType
	void GetOutlineColor(uint8_t  InOutlineMode, char InPlayerIndex, struct UObject* __WorldContext, struct FLinearColor& Color); // Function TBFL_UIColors.TBFL_UIColors_C.GetOutlineColor
	void GetBackgroundColorByPlayerStatus(char TBE_StatusIcon InPlayerStatus, struct UObject* __WorldContext, struct FSlateColor& OutAccentColor); // Function TBFL_UIColors.TBFL_UIColors_C.GetBackgroundColorByPlayerStatus
	void GetAccentColorByPlayerStatus(char TBE_StatusIcon InPlayerStatus, struct UObject* __WorldContext, struct FLinearColor& OutAccentColor); // Function TBFL_UIColors.TBFL_UIColors_C.GetAccentColorByPlayerStatus
	void GetPlayerColorByIndex(char InPlayerIndex, uint8_t  InColorSpace, struct UObject* __WorldContext, struct FLinearColor& Color); // Function TBFL_UIColors.TBFL_UIColors_C.GetPlayerColorByIndex
	void GetUIColorSlate(uint8_t  UIColor, uint8_t  ColorSpace, struct UObject* __WorldContext, struct FSlateColor& SlateColor); // Function TBFL_UIColors.TBFL_UIColors_C.GetUIColorSlate
	void GetUIColorAsText(uint8_t  UIColor, uint8_t  ColourSpace, struct UObject* __WorldContext, struct FText& ColorText); // Function TBFL_UIColors.TBFL_UIColors_C.GetUIColorAsText
	void GetUIColor(uint8_t  UIColor, uint8_t  ColourSpace, struct UObject* __WorldContext, struct FLinearColor& LinearColor); // Function TBFL_UIColors.TBFL_UIColors_C.GetUIColor
	void GetData(struct UObject* __WorldContext, struct UTigerUIColorSet*& ColorSet); // Function TBFL_UIColors.TBFL_UIColors_C.GetData
}; 



