#pragma once 
#include <DA_WeatherScenario_Structs.h>
 
 
 
// BlueprintGeneratedClass DA_WeatherScenario.DA_WeatherScenario_C
// Size: 0x18C(Inherited: 0x40) 
struct UDA_WeatherScenario_C : public UTigerWeatherScenarioData
{
	float WindStrength;  // 0x40(0x4)
	float WindSpeed;  // 0x44(0x4)
	float RainRate;  // 0x48(0x4)
	float PuddlesAmount;  // 0x4C(0x4)
	float PuddlesRingsIntensity;  // 0x50(0x4)
	float PuddlesWindTiling;  // 0x54(0x4)
	float AISightModifier;  // 0x58(0x4)
	float RainAudioMin;  // 0x5C(0x4)
	float ThunderAudioMin;  // 0x60(0x4)
	float WindAudioMin;  // 0x64(0x4)
	float RainAudioMax;  // 0x68(0x4)
	float ThunderAudioMax;  // 0x6C(0x4)
	float WindAudioMax;  // 0x70(0x4)
	uint8_t  ExponensialHeightFog;  // 0x74(0x1)
	char pad_117[3];  // 0x75(0x3)
	float SnowfallRate;  // 0x78(0x4)
	float WetnessAmount;  // 0x7C(0x4)
	float MovementStrength;  // 0x80(0x4)
	float Speed;  // 0x84(0x4)
	float NoiseMultiplier;  // 0x88(0x4)
	char pad_140_1 : 7;  // 0x8C(0x1)
	bool EnableLightning : 1;  // 0x8C(0x1)
	char pad_141[3];  // 0x8D(0x3)
	struct FPostProcessOverrides Global Post Process Settings;  // 0x90(0x58)
	struct FSkyTextures SkyCubemapTextures;  // 0xE8(0x78)
	struct TSoftObjectPtr<UTextureCube> LightningMask;  // 0x160(0x28)
	float AuroraIntensity;  // 0x188(0x4)

}; 



