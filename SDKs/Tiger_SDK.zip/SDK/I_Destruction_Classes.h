#pragma once 
#include <I_Destruction_Structs.h>
 
 
 
// BlueprintGeneratedClass I_Destruction.I_Destruction_C
// Size: 0x28(Inherited: 0x28) 
struct UI_Destruction_C : public UInterface
{

	void TriggerAlarm(); // Function I_Destruction.I_Destruction_C.TriggerAlarm
	void StaticMeshComponentHit(struct FHitResult HitResult, struct FVector ImpactVelocity); // Function I_Destruction.I_Destruction_C.StaticMeshComponentHit
}; 



