#pragma once 
#include "SDK.h" 
 
 
// Function TBFL_TypeAndRarity.TBFL_TypeAndRarity_C.GetTextFromAmmoType
// Size: 0x49(Inherited: 0x0) 
struct FGetTextFromAmmoType
{
	uint8_t  In Ammo Type;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct UObject* __WorldContext;  // 0x8(0x8)
	struct FText Text;  // 0x10(0x18)
	struct UTigerTypeAndRarityData* CallFunc_GetData_Data;  // 0x28(0x8)
	struct FText CallFunc_Map_Find_Value;  // 0x30(0x18)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool CallFunc_Map_Find_ReturnValue : 1;  // 0x48(0x1)

}; 
// Function TBFL_TypeAndRarity.TBFL_TypeAndRarity_C.GetColorTextFromItemType
// Size: 0x60(Inherited: 0x0) 
struct FGetColorTextFromItemType
{
	struct UTigerItemAsset* InItemAsset;  // 0x0(0x8)
	struct UObject* __WorldContext;  // 0x8(0x8)
	struct FText ColorText;  // 0x10(0x18)
	struct FLinearColor CallFunc_GetColorByItemType_OutColor;  // 0x28(0x10)
	struct FString CallFunc_Conv_ColorToString_ReturnValue;  // 0x38(0x10)
	struct FText CallFunc_Conv_StringToText_ReturnValue;  // 0x48(0x18)

}; 
// Function TBFL_TypeAndRarity.TBFL_TypeAndRarity_C.GetColorFromItemRarity
// Size: 0x3C(Inherited: 0x0) 
struct FGetColorFromItemRarity
{
	uint8_t  In Rarity;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct UObject* __WorldContext;  // 0x8(0x8)
	struct FLinearColor Color;  // 0x10(0x10)
	struct UTigerTypeAndRarityData* CallFunc_GetData_Data;  // 0x20(0x8)
	uint8_t  CallFunc_Map_Find_Value;  // 0x28(0x1)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool CallFunc_Map_Find_ReturnValue : 1;  // 0x29(0x1)
	char pad_42[2];  // 0x2A(0x2)
	struct FLinearColor CallFunc_GetUIColor_LinearColor;  // 0x2C(0x10)

}; 
// Function TBFL_TypeAndRarity.TBFL_TypeAndRarity_C.SetRarityMaterialFromWeaponClass
// Size: 0x21(Inherited: 0x0) 
struct FSetRarityMaterialFromWeaponClass
{
	struct UMeshComponent* InMeshComponent;  // 0x0(0x8)
	struct UTigerWeapon* InWeaponClass;  // 0x8(0x8)
	struct UObject* __WorldContext;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x19(0x1)
	char pad_26[2];  // 0x1A(0x2)
	int32_t CallFunc_GetNumMaterials_ReturnValue;  // 0x1C(0x4)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue : 1;  // 0x20(0x1)

}; 
// Function TBFL_TypeAndRarity.TBFL_TypeAndRarity_C.GetTextFromItemType
// Size: 0x69(Inherited: 0x0) 
struct FGetTextFromItemType
{
	uint8_t  In Item Type;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool InGetShortVersion : 1;  // 0x1(0x1)
	char pad_2[6];  // 0x2(0x6)
	struct UObject* __WorldContext;  // 0x8(0x8)
	struct FText Text;  // 0x10(0x18)
	struct UTigerTypeAndRarityData* CallFunc_GetData_Data;  // 0x28(0x8)
	struct FText CallFunc_Map_Find_Value;  // 0x30(0x18)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool CallFunc_Map_Find_ReturnValue : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)
	struct FText CallFunc_Map_Find_Value_2;  // 0x50(0x18)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool CallFunc_Map_Find_ReturnValue_2 : 1;  // 0x68(0x1)

}; 
// Function TBFL_TypeAndRarity.TBFL_TypeAndRarity_C.GetData
// Size: 0x10(Inherited: 0x0) 
struct FGetData
{
	struct UObject* __WorldContext;  // 0x0(0x8)
	struct UTigerTypeAndRarityData* Data;  // 0x8(0x8)

}; 
// Function TBFL_TypeAndRarity.TBFL_TypeAndRarity_C.GetTextFromItemRarity
// Size: 0x49(Inherited: 0x0) 
struct FGetTextFromItemRarity
{
	uint8_t  In Rarity;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct UObject* __WorldContext;  // 0x8(0x8)
	struct FText Text;  // 0x10(0x18)
	struct UTigerTypeAndRarityData* CallFunc_GetData_Data;  // 0x28(0x8)
	struct FText CallFunc_Map_Find_Value;  // 0x30(0x18)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool CallFunc_Map_Find_ReturnValue : 1;  // 0x48(0x1)

}; 
// Function TBFL_TypeAndRarity.TBFL_TypeAndRarity_C.GetColorTextFromItemRarity
// Size: 0x60(Inherited: 0x0) 
struct FGetColorTextFromItemRarity
{
	uint8_t  In Rarity;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct UObject* __WorldContext;  // 0x8(0x8)
	struct FText ColorText;  // 0x10(0x18)
	struct FLinearColor CallFunc_GetColorFromItemRarity_Color;  // 0x28(0x10)
	struct FString CallFunc_Conv_ColorToString_ReturnValue;  // 0x38(0x10)
	struct FText CallFunc_Conv_StringToText_ReturnValue;  // 0x48(0x18)

}; 
// Function TBFL_TypeAndRarity.TBFL_TypeAndRarity_C.GetShortTextFromWeaponType
// Size: 0x49(Inherited: 0x0) 
struct FGetShortTextFromWeaponType
{
	uint8_t  WeaponType;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct UObject* __WorldContext;  // 0x8(0x8)
	struct FText ShortType;  // 0x10(0x18)
	struct UTigerTypeAndRarityData* CallFunc_GetData_Data;  // 0x28(0x8)
	struct FText CallFunc_Map_Find_Value;  // 0x30(0x18)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool CallFunc_Map_Find_ReturnValue : 1;  // 0x48(0x1)

}; 
// Function TBFL_TypeAndRarity.TBFL_TypeAndRarity_C.GetTextFromLootCategory
// Size: 0x71(Inherited: 0x0) 
struct FGetTextFromLootCategory
{
	uint8_t  LootCategory;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct UObject* __WorldContext;  // 0x8(0x8)
	struct FText Text;  // 0x10(0x18)
	struct FString CallFunc_Conv_ByteToString_ReturnValue;  // 0x28(0x10)
	struct UTigerTypeAndRarityData* CallFunc_GetData_Data;  // 0x38(0x8)
	struct FText CallFunc_Conv_StringToText_ReturnValue;  // 0x40(0x18)
	struct FText CallFunc_Map_Find_Value;  // 0x58(0x18)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool CallFunc_Map_Find_ReturnValue : 1;  // 0x70(0x1)

}; 
