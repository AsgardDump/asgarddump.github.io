#pragma once 
#include <BPI_PlayerAnimation_Structs.h>
 
 
 
// BlueprintGeneratedClass BPI_PlayerAnimation.BPI_PlayerAnimation_C
// Size: 0x28(Inherited: 0x28) 
struct UBPI_PlayerAnimation_C : public UInterface
{

	void GetWeapon(struct USkeletalMeshComponent*& OutWeapon, struct USkeletalMeshComponent*& OutSecondWeapon); // Function BPI_PlayerAnimation.BPI_PlayerAnimation_C.GetWeapon
}; 



