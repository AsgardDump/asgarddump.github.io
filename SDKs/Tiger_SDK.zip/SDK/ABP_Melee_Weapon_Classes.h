#pragma once 
#include <ABP_Melee_Weapon_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass ABP_Melee_Weapon.ABP_Melee_Weapon_C
// Size: 0xD88(Inherited: 0x2E0) 
struct UABP_Melee_Weapon_C : public UTigerMeleeWeaponAnimInstance
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x2E0(0x8)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_5;  // 0x2E8(0x28)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_4;  // 0x310(0x28)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_3;  // 0x338(0x28)
	struct FAnimNode_Root AnimGraphNode_Root;  // 0x360(0x30)
	struct FAnimNode_BlendListByEnum AnimGraphNode_BlendListByEnum;  // 0x390(0xB0)
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose_5;  // 0x440(0x158)
	struct FAnimNode_Slot AnimGraphNode_Slot;  // 0x598(0x48)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_2;  // 0x5E0(0x28)
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose_4;  // 0x608(0x158)
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose_3;  // 0x760(0x158)
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose_2;  // 0x8B8(0x158)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose;  // 0xA10(0x28)
	struct FAnimNode_SequenceEvaluator AnimGraphNode_SequenceEvaluator_4;  // 0xA38(0x50)
	struct FAnimNode_SequenceEvaluator AnimGraphNode_SequenceEvaluator_3;  // 0xA88(0x50)
	struct FAnimNode_SequenceEvaluator AnimGraphNode_SequenceEvaluator_2;  // 0xAD8(0x50)
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose;  // 0xB28(0x158)
	struct FAnimNode_SequenceEvaluator AnimGraphNode_SequenceEvaluator;  // 0xC80(0x50)
	char pad_3280_1 : 7;  // 0xCD0(0x1)
	bool IsSecondaryWeapon : 1;  // 0xCD0(0x1)
	char pad_3281[3];  // 0xCD1(0x3)
	float IsPlayingAsFemaleFloat;  // 0xCD4(0x4)
	char ENUM_MeleeWeaponCategories CurrentMeleeWeapon;  // 0xCD8(0x1)
	char pad_3289[7];  // 0xCD9(0x7)
	struct TMap<char ENUM_MeleeWeaponCategories, struct FVector> RootJointOffsetMap;  // 0xCE0(0x50)
	struct TMap<char ENUM_MeleeWeaponCategories, struct FVector> LeftHandOffsetMap;  // 0xD30(0x50)
	struct UABP_Player_C* Anim Instance;  // 0xD80(0x8)

	void AnimGraph(struct FPoseLink& AnimGraph); // Function ABP_Melee_Weapon.ABP_Melee_Weapon_C.AnimGraph
	void BlueprintInitializeAnimation(); // Function ABP_Melee_Weapon.ABP_Melee_Weapon_C.BlueprintInitializeAnimation
	void OnMelee(int32_t AttackCount); // Function ABP_Melee_Weapon.ABP_Melee_Weapon_C.OnMelee
	void OnPossibleMeshChange(); // Function ABP_Melee_Weapon.ABP_Melee_Weapon_C.OnPossibleMeshChange
	void ExecuteUbergraph_ABP_Melee_Weapon(int32_t EntryPoint); // Function ABP_Melee_Weapon.ABP_Melee_Weapon_C.ExecuteUbergraph_ABP_Melee_Weapon
}; 



