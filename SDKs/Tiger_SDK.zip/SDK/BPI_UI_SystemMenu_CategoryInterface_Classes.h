#pragma once 
#include <BPI_UI_SystemMenu_CategoryInterface_Structs.h>
 
 
 
// BlueprintGeneratedClass BPI_UI_SystemMenu_CategoryInterface.BPI_UI_SystemMenu_CategoryInterface_C
// Size: 0x28(Inherited: 0x28) 
struct UBPI_UI_SystemMenu_CategoryInterface_C : public UInterface
{

	void GiveBackDpad(); // Function BPI_UI_SystemMenu_CategoryInterface.BPI_UI_SystemMenu_CategoryInterface_C.GiveBackDpad
	void ResetSettings(); // Function BPI_UI_SystemMenu_CategoryInterface.BPI_UI_SystemMenu_CategoryInterface_C.ResetSettings
	void RevertChanges(); // Function BPI_UI_SystemMenu_CategoryInterface.BPI_UI_SystemMenu_CategoryInterface_C.RevertChanges
	void DiscardChanges(); // Function BPI_UI_SystemMenu_CategoryInterface.BPI_UI_SystemMenu_CategoryInterface_C.DiscardChanges
	void ConfirmApply(); // Function BPI_UI_SystemMenu_CategoryInterface.BPI_UI_SystemMenu_CategoryInterface_C.ConfirmApply
	void ApplyChanges(bool& OutShouldShowRevertPrompt, bool& OutNeedsRestart); // Function BPI_UI_SystemMenu_CategoryInterface.BPI_UI_SystemMenu_CategoryInterface_C.ApplyChanges
	void HasUnappliedChanges(bool& OutHasUnappliedChanges); // Function BPI_UI_SystemMenu_CategoryInterface.BPI_UI_SystemMenu_CategoryInterface_C.HasUnappliedChanges
	void CloseCategory(); // Function BPI_UI_SystemMenu_CategoryInterface.BPI_UI_SystemMenu_CategoryInterface_C.CloseCategory
	void OpenCategory(); // Function BPI_UI_SystemMenu_CategoryInterface.BPI_UI_SystemMenu_CategoryInterface_C.OpenCategory
}; 



