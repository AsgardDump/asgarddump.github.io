#pragma once 
#include "SDK.h" 
 
 
// Function ABP_VMP_BRU_F_HAIR_07.ABP_VMP_BRU_F_HAIR_07_C.AnimGraph
// Size: 0x10(Inherited: 0x0) 
struct FAnimGraph
{
	struct FPoseLink AnimGraph;  // 0x0(0x10)

}; 
// Function ABP_VMP_BRU_F_HAIR_07.ABP_VMP_BRU_F_HAIR_07_C.ExecuteUbergraph_ABP_VMP_BRU_F_HAIR_07
// Size: 0x4(Inherited: 0x0) 
struct FExecuteUbergraph_ABP_VMP_BRU_F_HAIR_07
{
	int32_t EntryPoint;  // 0x0(0x4)

}; 
