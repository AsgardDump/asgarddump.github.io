#pragma once 
#include <INTLPlugin_Structs.h>
 
 
 
// Class INTLPlugin.INTLBaseUserWidget
// Size: 0x268(Inherited: 0x260) 
struct UINTLBaseUserWidget : public UUserWidget
{
	char pad_608[8];  // 0x260(0x8)

}; 



// Class INTLPlugin.INTLOutputUtility
// Size: 0x28(Inherited: 0x28) 
struct UINTLOutputUtility : public UBlueprintFunctionLibrary
{

	void FormatNoticeRet(struct FINTLNoticeResult Ret, bool& IsSuccess, struct FText& ErrorMsg); // Function INTLPlugin.INTLOutputUtility.FormatNoticeRet
	void FormatBaseRet(struct FINTLBaseResult Ret, bool& IsSuccess, struct FText& ErrorMsg); // Function INTLPlugin.INTLOutputUtility.FormatBaseRet
	void FormatAuthRet(struct FINTLAuthResult Ret, bool& IsSuccess, struct FText& ErrorMsg); // Function INTLPlugin.INTLOutputUtility.FormatAuthRet
}; 



// Class INTLPlugin.INTLUtility
// Size: 0x28(Inherited: 0x28) 
struct UINTLUtility : public UBlueprintFunctionLibrary
{

	bool Regular(struct FString Str, struct FString Reg); // Function INTLPlugin.INTLUtility.Regular
	int32_t RefreshCurToastCnt(int32_t ChangeCnt); // Function INTLPlugin.INTLUtility.RefreshCurToastCnt
	int32_t GetNewToastOrder(); // Function INTLPlugin.INTLUtility.GetNewToastOrder
	void ForceCrash(); // Function INTLPlugin.INTLUtility.ForceCrash
}; 



// Class INTLPlugin.INTLPluginObserver
// Size: 0x28(Inherited: 0x28) 
struct UINTLPluginObserver : public UInterface
{

	void OnWebViewResult(struct FINTLWebViewResult Ret); // Function INTLPlugin.INTLPluginObserver.OnWebViewResult
	void OnUpdateStartRepoNewVersionInfoResult(struct FINTLUpdateStartRepoNewVersionInfo Ret); // Function INTLPlugin.INTLPluginObserver.OnUpdateStartRepoNewVersionInfoResult
	void OnUpdateResult(struct FINTLUpdateResult Ret); // Function INTLPlugin.INTLPluginObserver.OnUpdateResult
	void OnUpdateProgressResult(struct FINTLUpdateProgress Ret); // Function INTLPlugin.INTLPluginObserver.OnUpdateProgressResult
	void OnUpdateOptionalRepoInitResult(struct FINTLUpdateOptionalRepoInitResult Ret); // Function INTLPlugin.INTLPluginObserver.OnUpdateOptionalRepoInitResult
	void OnPushResult(struct FINTLPushResult Ret); // Function INTLPlugin.INTLPluginObserver.OnPushResult
	void OnPushBaseResult(struct FINTLBaseResult Ret); // Function INTLPlugin.INTLPluginObserver.OnPushBaseResult
	void OnNoticeRequestData(struct FINTLNoticeResult Ret); // Function INTLPlugin.INTLPluginObserver.OnNoticeRequestData
	void OnIPInfoResult(struct FINTLLBSIPInfoResult Ret); // Function INTLPlugin.INTLPluginObserver.OnIPInfoResult
	void OnIDTokenResult(struct FINTLIDTokenResult Ret); // Function INTLPlugin.INTLPluginObserver.OnIDTokenResult
	void OnFriendResult(struct FINTLFriendResult Ret); // Function INTLPlugin.INTLPluginObserver.OnFriendResult
	void OnFriendBaseResult(struct FINTLBaseResult Ret); // Function INTLPlugin.INTLPluginObserver.OnFriendBaseResult
	void OnExtendResult(struct FINTLExtendResult Ret); // Function INTLPlugin.INTLPluginObserver.OnExtendResult
	void OnDNSResult(struct FINTLDNSResult Ret); // Function INTLPlugin.INTLPluginObserver.OnDNSResult
	void OnDismissLoginUI(bool Canceled); // Function INTLPlugin.INTLPluginObserver.OnDismissLoginUI
	void OnDirTreeResult(struct FINTLDirTreeResult Ret); // Function INTLPlugin.INTLPluginObserver.OnDirTreeResult
	void OnDeviceLevelResult(struct FINTLDeviceLevelResult Ret); // Function INTLPlugin.INTLPluginObserver.OnDeviceLevelResult
	void OnCutoutResult(struct FCutoutInfoResult Ret); // Function INTLPlugin.INTLPluginObserver.OnCutoutResult
	void OnCustomerResult(struct FINTLCustomerResult Ret); // Function INTLPlugin.INTLPluginObserver.OnCustomerResult
	void OnComplianceResult(struct FINTLComplianceResult Ret); // Function INTLPlugin.INTLPluginObserver.OnComplianceResult
	void OnAuthResult(struct FINTLAuthResult Ret); // Function INTLPlugin.INTLPluginObserver.OnAuthResult
	void OnAuthBaseResult(struct FINTLBaseResult Ret); // Function INTLPlugin.INTLPluginObserver.OnAuthBaseResult
	void OnAccountResult(struct FINTLAccountResult Ret); // Function INTLPlugin.INTLPluginObserver.OnAccountResult
}; 



// Class INTLPlugin.INTLSDKAPI
// Size: 0x28(Inherited: 0x28) 
struct UINTLSDKAPI : public UBlueprintFunctionLibrary
{

	bool UpdateStop(int32_t RepoID, int32_t TaskID); // Function INTLPlugin.INTLSDKAPI.UpdateStop
	bool UpdateStart(struct FINTLUpdateInitInfo Info); // Function INTLPlugin.INTLSDKAPI.UpdateStart
	bool UpdateContinue(int32_t RepoID); // Function INTLPlugin.INTLSDKAPI.UpdateContinue
	bool UpdateConfig(struct TMap<struct FString, struct FString> Cfg, struct FString Project); // Function INTLPlugin.INTLSDKAPI.UpdateConfig
	void UnregisterPush(struct FString Channel); // Function INTLPlugin.INTLSDKAPI.UnregisterPush
	bool Unbind(uint8_t  Channel, struct FString UID, struct FString ExtraJson); // Function INTLPlugin.INTLSDKAPI.Unbind
	void ShutDown(); // Function INTLPlugin.INTLSDKAPI.ShutDown
	bool ShowAccountPicker(); // Function INTLPlugin.INTLSDKAPI.ShowAccountPicker
	bool Share(struct FINTLFriendReqInfo Info, struct FString Channel); // Function INTLPlugin.INTLSDKAPI.Share
	void SetTag(struct FString Channel, struct FString Tag); // Function INTLPlugin.INTLSDKAPI.SetTag
	void SetSessionExtraParam(struct FString extra_json); // Function INTLPlugin.INTLSDKAPI.SetSessionExtraParam
	void SetDeviceLevel(int32_t Level); // Function INTLPlugin.INTLSDKAPI.SetDeviceLevel
	void SetCrashUserValue(struct FString Key, struct FString Value); // Function INTLPlugin.INTLSDKAPI.SetCrashUserValue
	void SetCrashUserId(struct FString userId); // Function INTLPlugin.INTLSDKAPI.SetCrashUserId
	void SetCrashCallback(); // Function INTLPlugin.INTLSDKAPI.SetCrashCallback
	void SetBuglyAppVersion(struct FString appVersion); // Function INTLPlugin.INTLSDKAPI.SetBuglyAppVersion
	void SetAccountInfo(uint8_t  Channel, int32_t ChannelID, struct FString LangType, int32_t AccountPlatType); // Function INTLPlugin.INTLSDKAPI.SetAccountInfo
	void SetAccount(struct FString Channel, struct FString Account); // Function INTLPlugin.INTLSDKAPI.SetAccount
	bool SendMessage(struct FINTLFriendReqInfo Info, struct FString Channel); // Function INTLPlugin.INTLSDKAPI.SendMessage
	bool ResetPasswordWithVerifyCode(struct FString Account, struct FString VerifyCode, struct FString PhoneAreaCode, struct FString NewPassword, struct FString ExtraJson); // Function INTLPlugin.INTLSDKAPI.ResetPasswordWithVerifyCode
	bool ResetPasswordWithOldPassword(struct FString Account, struct FString OldPassword, struct FString PhoneAreaCode, struct FString NewPassword, struct FString ExtraJson); // Function INTLPlugin.INTLSDKAPI.ResetPasswordWithOldPassword
	bool ResetGuest(); // Function INTLPlugin.INTLSDKAPI.ResetGuest
	bool RequestVerifyCode(struct FString Account, uint8_t  CodeType, struct FString PhoneAreaCode, struct FString ExtraJson); // Function INTLPlugin.INTLSDKAPI.RequestVerifyCode
	void RequestTrackingAuthorization(); // Function INTLPlugin.INTLSDKAPI.RequestTrackingAuthorization
	void RequestIPInfo(); // Function INTLPlugin.INTLSDKAPI.RequestIPInfo
	void ReportPayStep(int32_t Step, struct FString StepName, bool Result, int32_t ErrorCode, struct TMap<struct FString, struct FString> ParamsMap); // Function INTLPlugin.INTLSDKAPI.ReportPayStep
	void ReportLoginStep(int32_t Step, struct FString StepName, bool Result, int32_t ErrorCode, struct TMap<struct FString, struct FString> ParamsMap); // Function INTLPlugin.INTLSDKAPI.ReportLoginStep
	void ReportException(int32_t Type, struct FString ExceptionName, struct FString ExceptionMsg, struct FString ExceptionStack, struct TMap<struct FString, struct FString> ExtInfo); // Function INTLPlugin.INTLSDKAPI.ReportException
	void ReportEvent(struct FString EventName, struct TMap<struct FString, struct FString> ParamsMap, struct FString SpecificChannel, struct FString ExtraJson); // Function INTLPlugin.INTLSDKAPI.ReportEvent
	void ReportCustomEventStep(struct FString EventName, int32_t Step, struct FString StepName, bool Result, int32_t ErrorCode, struct TMap<struct FString, struct FString> ParamsMap); // Function INTLPlugin.INTLSDKAPI.ReportCustomEventStep
	void ReportBinary(struct FString EventName, struct FString Data, int32_t Length, struct FString SpecificChannel); // Function INTLPlugin.INTLSDKAPI.ReportBinary
	void RemoveObserver(struct TScriptInterface<IINTLPluginObserver> Observer); // Function INTLPlugin.INTLSDKAPI.RemoveObserver
	void RegisterPush(struct FString Channel, struct FString Account); // Function INTLPlugin.INTLSDKAPI.RegisterPush
	bool Register(struct FString Account, struct FString Password, struct FString VerifyCode, struct FString PhoneAreaCode, struct FINTLAccountProfile userProfile); // Function INTLPlugin.INTLSDKAPI.Register
	bool QueryVerifyCodeStatus(struct FString Account, struct FString VerifyCode, uint8_t  CodeType, struct FString PhoneAreaCode, struct FString ExtraJson); // Function INTLPlugin.INTLSDKAPI.QueryVerifyCodeStatus
	void QueryUserNameStatus(struct FString UserName); // Function INTLPlugin.INTLSDKAPI.QueryUserNameStatus
	bool QueryUserInfo(); // Function INTLPlugin.INTLSDKAPI.QueryUserInfo
	bool QueryRegisterStatus(struct FString Account, struct FString PhoneAreaCode, struct FString ExtraJson); // Function INTLPlugin.INTLSDKAPI.QueryRegisterStatus
	bool QueryLegalDocumentsAcceptedVersion(); // Function INTLPlugin.INTLSDKAPI.QueryLegalDocumentsAcceptedVersion
	bool QueryIsReceiveEmail(struct FString Account, struct FString PhoneAreaCode, struct FString ExtraJson); // Function INTLPlugin.INTLSDKAPI.QueryIsReceiveEmail
	void QueryIsEEA(struct FString Region); // Function INTLPlugin.INTLSDKAPI.QueryIsEEA
	void QueryIpByHost(struct FString Host); // Function INTLPlugin.INTLSDKAPI.QueryIpByHost
	void QueryIDToken(); // Function INTLPlugin.INTLSDKAPI.QueryIDToken
	bool QueryFriends(uint8_t  Channel, int32_t Page, int32_t Count, bool IsInGame, struct FString ExtraJson); // Function INTLPlugin.INTLSDKAPI.QueryFriends
	void QueryDirTree(int32_t TreeId); // Function INTLPlugin.INTLSDKAPI.QueryDirTree
	void QueryDirNode(int32_t TreeId, int32_t NodeId); // Function INTLPlugin.INTLSDKAPI.QueryDirNode
	void QueryDeviceLevel(); // Function INTLPlugin.INTLSDKAPI.QueryDeviceLevel
	void QueryDataProtectionAcceptance(); // Function INTLPlugin.INTLSDKAPI.QueryDataProtectionAcceptance
	bool QueryCanBind(int32_t ChannelID, int32_t AccountPlatType, struct FString Account, struct FString PhoneAreaCode, struct FString ExtraJson); // Function INTLPlugin.INTLSDKAPI.QueryCanBind
	bool QueryActiveUser(); // Function INTLPlugin.INTLSDKAPI.QueryActiveUser
	bool QueryAccountProfile(); // Function INTLPlugin.INTLSDKAPI.QueryAccountProfile
	void PostNetworkLatencyInSession(int32_t LatencyMs); // Function INTLPlugin.INTLSDKAPI.PostNetworkLatencyInSession
	void PostFrameTimeInSession(float DeltaSeconds); // Function INTLPlugin.INTLSDKAPI.PostFrameTimeInSession
	void OpenUrl(struct FString URL, uint8_t  ScreenOrientation, bool FullScreenEnable, bool EncryptEnable, bool SystemBrowserEnable, struct FString ExtraJson); // Function INTLPlugin.INTLSDKAPI.OpenUrl
	bool OnTickEvent(); // Function INTLPlugin.INTLSDKAPI.OnTickEvent
	struct FString NoticeRequestData(struct FString Region, struct FString LangType, struct FString ExtraJson); // Function INTLPlugin.INTLSDKAPI.NoticeRequestData
	bool ModifyProfile(struct FINTLAccountProfile userProfile); // Function INTLPlugin.INTLSDKAPI.ModifyProfile
	bool ModifyLegalDocumentsAcceptedVersion(struct FString acceptedVersionsJson); // Function INTLPlugin.INTLSDKAPI.ModifyLegalDocumentsAcceptedVersion
	bool ModifyDownloadPriority(int32_t RepoID, int32_t TaskID, int32_t DownloadPriority); // Function INTLPlugin.INTLSDKAPI.ModifyDownloadPriority
	void ModifyDataProtectionAcceptance(struct FString PPVersion, struct FString TOSVersion); // Function INTLPlugin.INTLSDKAPI.ModifyDataProtectionAcceptance
	bool ModifyAccountWithVerifyCode(struct FString OldAccount, struct FString OldAccountVerifyCode, struct FString OldPhoneAreaCode, struct FString NewAccount, struct FString NewAccountVerifyCode, struct FString NewPhoneAreaCode, struct FString ExtraJson); // Function INTLPlugin.INTLSDKAPI.ModifyAccountWithVerifyCode
	bool ModifyAccountWithPassword(struct FString OldAccount, struct FString OldPhoneAreaCode, struct FString Password, struct FString NewAccount, struct FString NewAccountVerifyCode, struct FString NewPhoneAreaCode, struct FString ExtraJson); // Function INTLPlugin.INTLSDKAPI.ModifyAccountWithPassword
	bool ModifyAccountWithLoginState(struct FString OldPhoneAreaCode, struct FString NewAccount, struct FString NewAccountVerifyCode, struct FString NewPhoneAreaCode, struct FString ExtraJson); // Function INTLPlugin.INTLSDKAPI.ModifyAccountWithLoginState
	void MarkSessionLoad(struct FString SessionName, struct FString extra_json); // Function INTLPlugin.INTLSDKAPI.MarkSessionLoad
	void MarkSessionClosed(); // Function INTLPlugin.INTLSDKAPI.MarkSessionClosed
	bool Logout(uint8_t  Channel); // Function INTLPlugin.INTLSDKAPI.Logout
	bool LoginWithVerifyCode(uint8_t  Channel, struct FString Account, struct FString Password, struct FString VerifyCode, struct FString PhoneAreaCode, struct FString PermissionList); // Function INTLPlugin.INTLSDKAPI.LoginWithVerifyCode
	bool LoginWithPassword(uint8_t  Channel, struct FString Account, struct FString Password, struct FString PhoneAreaCode, struct FString PermissionList); // Function INTLPlugin.INTLSDKAPI.LoginWithPassword
	bool LoginWithMappedChannel(uint8_t  Channel, struct FString LoginMode, struct FString Permissions); // Function INTLPlugin.INTLSDKAPI.LoginWithMappedChannel
	bool LoginWithChannel(uint8_t  Channel, struct FString LoginMode); // Function INTLPlugin.INTLSDKAPI.LoginWithChannel
	bool LoginWithBoundChannel(uint8_t  Channel, struct FString LoginMode); // Function INTLPlugin.INTLSDKAPI.LoginWithBoundChannel
	bool Login(uint8_t  Channel, struct FString Permissions, struct FString ExtraJson); // Function INTLPlugin.INTLSDKAPI.Login
	void LogCrashInfo(uint8_t  Level, struct FString Tag, struct FString Log); // Function INTLPlugin.INTLSDKAPI.LogCrashInfo
	void LoadCutoutData(); // Function INTLPlugin.INTLSDKAPI.LoadCutoutData
	void LaunchLoginUI(); // Function INTLPlugin.INTLSDKAPI.LaunchLoginUI
	bool LaunchCustomerUI(struct FINTLCustomerUserProfile userProfile); // Function INTLPlugin.INTLSDKAPI.LaunchCustomerUI
	bool LaunchAccountUI(int32_t Type, struct FString ExtraJson); // Function INTLPlugin.INTLSDKAPI.LaunchAccountUI
	bool IsAppInstalled(struct FString Channel, struct FString ExtraJson); // Function INTLPlugin.INTLSDKAPI.IsAppInstalled
	void InitAnalytics(); // Function INTLPlugin.INTLSDKAPI.InitAnalytics
	void Init(); // Function INTLPlugin.INTLSDKAPI.Init
	struct FString GetSDKVersion(); // Function INTLPlugin.INTLSDKAPI.GetSDKVersion
	struct FString GetIpByHost(struct FString Host); // Function INTLPlugin.INTLSDKAPI.GetIpByHost
	struct FString GetInstanceIDAsync(struct FString Channel); // Function INTLPlugin.INTLSDKAPI.GetInstanceIDAsync
	struct FString GetInstanceID(struct FString Channel); // Function INTLPlugin.INTLSDKAPI.GetInstanceID
	bool GetIDTokenResult(struct FINTLIDTokenResult& jwtRet); // Function INTLPlugin.INTLSDKAPI.GetIDTokenResult
	struct FString GetEncryptUrl(struct FString URL); // Function INTLPlugin.INTLSDKAPI.GetEncryptUrl
	int32_t GetDeviceLevel(); // Function INTLPlugin.INTLSDKAPI.GetDeviceLevel
	struct FString GetCurrentResourceVersion(); // Function INTLPlugin.INTLSDKAPI.GetCurrentResourceVersion
	struct FString GetCurrentAppVersion(); // Function INTLPlugin.INTLSDKAPI.GetCurrentAppVersion
	struct FString GetConfig(struct FString Key, struct FString DefaultVal, struct FString Project); // Function INTLPlugin.INTLSDKAPI.GetConfig
	bool GetAuthResult(struct FINTLAuthResult& LoginRet); // Function INTLPlugin.INTLSDKAPI.GetAuthResult
	struct FString ExtendInvoke(uint8_t  Channel, struct FString ExtendMethodName, struct FString ParamsJson); // Function INTLPlugin.INTLSDKAPI.ExtendInvoke
	int32_t DownloadOptionalRepoFiles(int32_t RepoID, int32_t DownloadPriority, struct TArray<struct FString>& FilesPath); // Function INTLPlugin.INTLSDKAPI.DownloadOptionalRepoFiles
	void DismissLoginUI(bool Canceled); // Function INTLPlugin.INTLSDKAPI.DismissLoginUI
	void DeleteTag(struct FString Channel, struct FString Tag); // Function INTLPlugin.INTLSDKAPI.DeleteTag
	void DeleteLocalNotifications(struct FString Key); // Function INTLPlugin.INTLSDKAPI.DeleteLocalNotifications
	void DeleteAccount(struct FString Channel, struct FString Account); // Function INTLPlugin.INTLSDKAPI.DeleteAccount
	bool ComplianceSetUserProfile(struct FString GameID, struct FString OpenId, struct FString Token, int32_t ChannelID, struct FString Region); // Function INTLPlugin.INTLSDKAPI.ComplianceSetUserProfile
	void ComplianceSetParentCertificateStatus(uint8_t  Status); // Function INTLPlugin.INTLSDKAPI.ComplianceSetParentCertificateStatus
	void ComplianceSetEUAgreeStatus(uint8_t  Status); // Function INTLPlugin.INTLSDKAPI.ComplianceSetEUAgreeStatus
	void ComplianceSetAdulthood(uint8_t  Status); // Function INTLPlugin.INTLSDKAPI.ComplianceSetAdulthood
	void ComplianceSendEmail(struct FString Email, struct FString UserName); // Function INTLPlugin.INTLSDKAPI.ComplianceSendEmail
	void ComplianceQueryUserStatus(); // Function INTLPlugin.INTLSDKAPI.ComplianceQueryUserStatus
	void ComplianceCommitBirthday(int32_t BirthdayYear, int32_t BirthdayMonth, int32_t BirthdayDay); // Function INTLPlugin.INTLSDKAPI.ComplianceCommitBirthday
	void CollectionStop(); // Function INTLPlugin.INTLSDKAPI.CollectionStop
	void CollectionResume(); // Function INTLPlugin.INTLSDKAPI.CollectionResume
	void ClearLocalNotifications(struct FString Channel); // Function INTLPlugin.INTLSDKAPI.ClearLocalNotifications
	struct TArray<struct FINTLUpdateOptionalRepoFilesStatus> CheckOptionalRepoFiles(int32_t RepoID, struct TArray<struct FString>& FilesPath); // Function INTLPlugin.INTLSDKAPI.CheckOptionalRepoFiles
	bool CheckActiveUser(); // Function INTLPlugin.INTLSDKAPI.CheckActiveUser
	void CallJS(struct FString JsonJsParam); // Function INTLPlugin.INTLSDKAPI.CallJS
	bool BuildMapWithLoggedinChannel(); // Function INTLPlugin.INTLSDKAPI.BuildMapWithLoggedinChannel
	bool BindWithLoggedinChannel(); // Function INTLPlugin.INTLSDKAPI.BindWithLoggedinChannel
	bool Bind(uint8_t  Channel, struct FString Permissions, struct FString ExtraJson); // Function INTLPlugin.INTLSDKAPI.Bind
	bool AutoLogin(); // Function INTLPlugin.INTLSDKAPI.AutoLogin
	void AddObserver(struct TScriptInterface<IINTLPluginObserver> Observer); // Function INTLPlugin.INTLSDKAPI.AddObserver
	void AddLocalNotificationIOS(struct FString Channel, struct FINTLLocalNotificationIOS LocalNotification); // Function INTLPlugin.INTLSDKAPI.AddLocalNotificationIOS
	void AddLocalNotification(struct FString Channel, struct FINTLLocalNotification LocalNotification); // Function INTLPlugin.INTLSDKAPI.AddLocalNotification
}; 



