#pragma once 
#include "SDK.h" 
 
 
// Function ABP_Paperdoll.ABP_Paperdoll_C.FacialAnimations
// Size: 0x20(Inherited: 0x0) 
struct FFacialAnimations
{
	struct FName CallFunc_GetFaceAnimSlotsWithActiveCurves_OutSlot0;  // 0x0(0x8)
	struct FName CallFunc_GetFaceAnimSlotsWithActiveCurves_OutSlot1;  // 0x8(0x8)
	struct FName CallFunc_GetFaceAnimSlotsWithActiveCurves_OutSlot2;  // 0x10(0x8)
	struct FName CallFunc_GetFaceAnimSlotsWithActiveCurves_OutSlot3;  // 0x18(0x8)

}; 
// Function ABP_Paperdoll.ABP_Paperdoll_C.ExecuteUbergraph_ABP_Paperdoll
// Size: 0x128(Inherited: 0x0) 
struct FExecuteUbergraph_ABP_Paperdoll
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct USkeletalMeshComponent* CallFunc_GetOwningComponent_ReturnValue;  // 0x8(0x8)
	int32_t CallFunc_GetBoneIndex_ReturnValue;  // 0x10(0x4)
	int32_t CallFunc_GetBoneIndex_ReturnValue_2;  // 0x14(0x4)
	struct FVector CallFunc_GetRefPosePosition_ReturnValue;  // 0x18(0xC)
	struct FVector CallFunc_GetRefPosePosition_ReturnValue_2;  // 0x24(0xC)
	struct FTransform CallFunc_MakeTransform_ReturnValue;  // 0x30(0x30)
	struct FTransform CallFunc_MakeTransform_ReturnValue_2;  // 0x60(0x30)
	struct UAnimSequence* CallFunc_GetFaceAnimationForCurve_ReturnValue;  // 0x90(0x8)
	struct UAnimSequence* CallFunc_GetFaceAnimationForCurve_ReturnValue_2;  // 0x98(0x8)
	struct UAnimSequence* CallFunc_GetFaceAnimationForCurve_ReturnValue_3;  // 0xA0(0x8)
	struct UAnimSequence* CallFunc_GetFaceAnimationForCurve_ReturnValue_4;  // 0xA8(0x8)
	struct UAnimSequence* CallFunc_GetSequence_ReturnValue;  // 0xB0(0x8)
	struct UTigerRandomSequenceList* CallFunc_GetRandomAnimationSequenceList_ReturnValue;  // 0xB8(0x8)
	struct UTigerAnimationSetCollection* K2Node_Event_SetCollection;  // 0xC0(0x8)
	float K2Node_Event_DeltaTimeX;  // 0xC8(0x4)
	char pad_204[4];  // 0xCC(0x4)
	struct UTigerRandomSequenceList* CallFunc_GetRandomAnimationSequenceList_ReturnValue_2;  // 0xD0(0x8)
	char pad_216_1 : 7;  // 0xD8(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0xD8(0x1)
	char pad_217[3];  // 0xD9(0x3)
	int32_t CallFunc_RandomIntegerInRange_ReturnValue;  // 0xDC(0x4)
	float CallFunc_Conv_IntToFloat_ReturnValue;  // 0xE0(0x4)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0xE4(0x10)
	char pad_244[4];  // 0xF4(0x4)
	struct UAnimMontage* K2Node_CustomEvent_Montage;  // 0xF8(0x8)
	char pad_256_1 : 7;  // 0x100(0x1)
	bool K2Node_CustomEvent_bInterrupted : 1;  // 0x100(0x1)
	char pad_257[7];  // 0x101(0x7)
	struct AActor* CallFunc_GetOwningActor_ReturnValue;  // 0x108(0x8)
	struct ATBP_PaperDoll_C* K2Node_DynamicCast_AsTBP_Paper_Doll;  // 0x110(0x8)
	char pad_280_1 : 7;  // 0x118(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x118(0x1)
	char pad_281[7];  // 0x119(0x7)
	struct UAnimSequence* CallFunc_GetSequence_ReturnValue_2;  // 0x120(0x8)

}; 
// Function ABP_Paperdoll.ABP_Paperdoll_C.SelectAnimationSets
// Size: 0x90(Inherited: 0x0) 
struct FSelectAnimationSets
{
	struct UTigerAnimationSetCollection* Set Collection;  // 0x0(0x8)
	uint8_t  Temp_byte_Variable;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct UTigerAnimationSetAsset* Temp_object_Variable;  // 0x10(0x8)
	struct UTigerAnimationSetAsset* Temp_object_Variable_2;  // 0x18(0x8)
	struct UTigerAnimationSetAsset* Temp_object_Variable_3;  // 0x20(0x8)
	struct UTigerAnimationSetAsset* Temp_object_Variable_4;  // 0x28(0x8)
	struct UTigerAnimationSetAsset* Temp_object_Variable_5;  // 0x30(0x8)
	uint8_t  Temp_byte_Variable_2;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct UTigerAnimationSetAsset* Temp_object_Variable_6;  // 0x40(0x8)
	struct UTigerAnimationSetAsset* Temp_object_Variable_7;  // 0x48(0x8)
	struct UTigerAnimationSetAsset* Temp_object_Variable_8;  // 0x50(0x8)
	struct UTigerAnimationSetAsset* Temp_object_Variable_9;  // 0x58(0x8)
	struct UTigerAnimationSetAsset* Temp_object_Variable_10;  // 0x60(0x8)
	struct AActor* CallFunc_GetOwningActor_ReturnValue;  // 0x68(0x8)
	struct ATigerPaperDoll* K2Node_DynamicCast_AsTiger_Paper_Doll;  // 0x70(0x8)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x78(0x1)
	uint8_t  CallFunc_GetBodyType_ReturnValue;  // 0x79(0x1)
	char pad_122_1 : 7;  // 0x7A(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x7A(0x1)
	char pad_123_1 : 7;  // 0x7B(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x7B(0x1)
	char pad_124[4];  // 0x7C(0x4)
	struct UTigerAnimationSetAsset* K2Node_Select_Default;  // 0x80(0x8)
	struct UTigerAnimationSetAsset* K2Node_Select_Default_2;  // 0x88(0x8)

}; 
// Function ABP_Paperdoll.ABP_Paperdoll_C.ClearProps
// Size: 0x9(Inherited: 0x0) 
struct FClearProps
{
	struct UAnimMontage* Montage;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bInterrupted : 1;  // 0x8(0x1)

}; 
// Function ABP_Paperdoll.ABP_Paperdoll_C.BlueprintUpdateAnimation
// Size: 0x4(Inherited: 0x4) 
struct FBlueprintUpdateAnimation : public FBlueprintUpdateAnimation
{
	float DeltaTimeX;  // 0x0(0x4)

}; 
// Function ABP_Paperdoll.ABP_Paperdoll_C.AnimGraph
// Size: 0x10(Inherited: 0x0) 
struct FAnimGraph
{
	struct FPoseLink AnimGraph;  // 0x0(0x10)

}; 
// Function ABP_Paperdoll.ABP_Paperdoll_C.AddSets
// Size: 0x8(Inherited: 0x8) 
struct FAddSets : public FAddSets
{
	struct UTigerAnimationSetCollection* SetCollection;  // 0x0(0x8)

}; 
