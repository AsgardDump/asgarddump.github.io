#pragma once 
#include <Explosion_Test_Structs.h>
 
 
 
// BlueprintGeneratedClass Explosion_Test.Explosion_Test_C
// Size: 0x508(Inherited: 0x4F8) 
struct AExplosion_Test_C : public ATigerAreaEffect
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x4F8(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x500(0x8)

	void OnTriggerClient(); // Function Explosion_Test.Explosion_Test_C.OnTriggerClient
	void ExecuteUbergraph_Explosion_Test(int32_t EntryPoint); // Function Explosion_Test.Explosion_Test_C.ExecuteUbergraph_Explosion_Test
}; 



