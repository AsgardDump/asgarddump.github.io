#pragma once 
#include "SDK.h" 
 
 
// ScriptStruct NetCore.NetAnalyticsDataConfig
// Size: 0xC(Inherited: 0x0) 
struct FNetAnalyticsDataConfig
{
	struct FName DataName;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bEnabled : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)

}; 
