#pragma once 
#include "SDK.h" 
 
 
// Function ABP_VMP_NOS_M_HAIR_05.ABP_VMP_NOS_M_HAIR_05_C.ExecuteUbergraph_ABP_VMP_NOS_M_HAIR_05
// Size: 0x4(Inherited: 0x0) 
struct FExecuteUbergraph_ABP_VMP_NOS_M_HAIR_05
{
	int32_t EntryPoint;  // 0x0(0x4)

}; 
// Function ABP_VMP_NOS_M_HAIR_05.ABP_VMP_NOS_M_HAIR_05_C.AnimGraph
// Size: 0x10(Inherited: 0x0) 
struct FAnimGraph
{
	struct FPoseLink AnimGraph;  // 0x0(0x10)

}; 
