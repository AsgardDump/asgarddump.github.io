#pragma once 
#include "SDK.h" 
 
 
// Function MagicLeapARPin.MagicLeapARPinComponent.GetPinnedPinID
// Size: 0x14(Inherited: 0x0) 
struct FGetPinnedPinID
{
	struct FGuid PinId;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)

}; 
// Function MagicLeapARPin.MagicLeapARPinFunctionLibrary.BindToOnMagicLeapARPinUpdatedDelegate
// Size: 0x10(Inherited: 0x0) 
struct FBindToOnMagicLeapARPinUpdatedDelegate
{
	struct FDelegate Delegate;  // 0x0(0x10)

}; 
// Function MagicLeapARPin.MagicLeapARPinComponent.PinActor
// Size: 0x10(Inherited: 0x0) 
struct FPinActor
{
	struct AActor* ActorToPin;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// DelegateFunction MagicLeapARPin.MagicLeapARPinUpdatedDelegate__DelegateSignature
// Size: 0x30(Inherited: 0x0) 
struct FMagicLeapARPinUpdatedDelegate__DelegateSignature
{
	struct TArray<struct FGuid> Added;  // 0x0(0x10)
	struct TArray<struct FGuid> Updated;  // 0x10(0x10)
	struct TArray<struct FGuid> Deleted;  // 0x20(0x10)

}; 
// Function MagicLeapARPin.MagicLeapARPinFunctionLibrary.GetARPinStateToString
// Size: 0x28(Inherited: 0x0) 
struct FGetARPinStateToString
{
	struct FMagicLeapARPinState State;  // 0x0(0x14)
	char pad_20[4];  // 0x14(0x4)
	struct FString ReturnValue;  // 0x18(0x10)

}; 
// DelegateFunction MagicLeapARPin.MagicLeapARPinUpdatedMultiDelegate__DelegateSignature
// Size: 0x30(Inherited: 0x0) 
struct FMagicLeapARPinUpdatedMultiDelegate__DelegateSignature
{
	struct TArray<struct FGuid> Added;  // 0x0(0x10)
	struct TArray<struct FGuid> Updated;  // 0x10(0x10)
	struct TArray<struct FGuid> Deleted;  // 0x20(0x10)

}; 
// DelegateFunction MagicLeapARPin.MagicLeapContentBindingFoundDelegate__DelegateSignature
// Size: 0x60(Inherited: 0x0) 
struct FMagicLeapContentBindingFoundDelegate__DelegateSignature
{
	struct FGuid PinId;  // 0x0(0x10)
	struct TSet<struct FString> PinnedObjectIds;  // 0x10(0x50)

}; 
// Function MagicLeapARPin.MagicLeapARPinComponent.AttemptPinDataRestoration
// Size: 0x1(Inherited: 0x0) 
struct FAttemptPinDataRestoration
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// DelegateFunction MagicLeapARPin.MagicLeapContentBindingFoundMultiDelegate__DelegateSignature
// Size: 0x60(Inherited: 0x0) 
struct FMagicLeapContentBindingFoundMultiDelegate__DelegateSignature
{
	struct FGuid PinId;  // 0x0(0x10)
	struct TSet<struct FString> PinnedObjectIds;  // 0x10(0x50)

}; 
// Function MagicLeapARPin.MagicLeapARPinFunctionLibrary.SetGlobalQueryFilter
// Size: 0x70(Inherited: 0x0) 
struct FSetGlobalQueryFilter
{
	struct FMagicLeapARPinQuery InGlobalFilter;  // 0x0(0x68)
	uint8_t  ReturnValue;  // 0x68(0x1)
	char pad_105[7];  // 0x69(0x7)

}; 
// Function MagicLeapARPin.MagicLeapARPinComponent.GetPinData
// Size: 0x10(Inherited: 0x0) 
struct FGetPinData
{
	UMagicLeapARPinSaveGame* PinDataClass;  // 0x0(0x8)
	struct UMagicLeapARPinSaveGame* ReturnValue;  // 0x8(0x8)

}; 
// Function MagicLeapARPin.MagicLeapARPinFunctionLibrary.GetNumAvailableARPins
// Size: 0x8(Inherited: 0x0) 
struct FGetNumAvailableARPins
{
	int32_t Count;  // 0x0(0x4)
	uint8_t  ReturnValue;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)

}; 
// Function MagicLeapARPin.MagicLeapARPinComponent.GetPinState
// Size: 0x18(Inherited: 0x0) 
struct FGetPinState
{
	struct FMagicLeapARPinState State;  // 0x0(0x14)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool ReturnValue : 1;  // 0x14(0x1)
	char pad_21[3];  // 0x15(0x3)

}; 
// ScriptStruct MagicLeapARPin.MagicLeapARPinState
// Size: 0x14(Inherited: 0x0) 
struct FMagicLeapARPinState
{
	float Confidence;  // 0x0(0x4)
	float ValidRadius;  // 0x4(0x4)
	float RotationError;  // 0x8(0x4)
	float TranslationError;  // 0xC(0x4)
	uint8_t  PinType;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)

}; 
// Function MagicLeapARPin.MagicLeapARPinComponent.IsPinned
// Size: 0x1(Inherited: 0x0) 
struct FIsPinned
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function MagicLeapARPin.MagicLeapARPinRenderer.SetVisibilityOverride
// Size: 0x1(Inherited: 0x0) 
struct FSetVisibilityOverride
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool InVisibilityOverride : 1;  // 0x0(0x1)

}; 
// DelegateFunction MagicLeapARPin.MagicLeapARPinComponent.MagicLeapARPinDataLoadAttemptCompleted__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FMagicLeapARPinDataLoadAttemptCompleted__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bDataRestored : 1;  // 0x0(0x1)

}; 
// DelegateFunction MagicLeapARPin.MagicLeapARPinComponent.PersistentEntityPinned__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FPersistentEntityPinned__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bRestoredOrSynced : 1;  // 0x0(0x1)

}; 
// Function MagicLeapARPin.MagicLeapARPinComponent.PinRestoredOrSynced
// Size: 0x1(Inherited: 0x0) 
struct FPinRestoredOrSynced
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function MagicLeapARPin.MagicLeapARPinComponent.PinSceneComponent
// Size: 0x10(Inherited: 0x0) 
struct FPinSceneComponent
{
	struct USceneComponent* ComponentToPin;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function MagicLeapARPin.MagicLeapARPinFunctionLibrary.ARPinIdToString
// Size: 0x20(Inherited: 0x0) 
struct FARPinIdToString
{
	struct FGuid ARPinId;  // 0x0(0x10)
	struct FString ReturnValue;  // 0x10(0x10)

}; 
// Function MagicLeapARPin.MagicLeapARPinComponent.PinToID
// Size: 0x14(Inherited: 0x0) 
struct FPinToID
{
	struct FGuid PinId;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)

}; 
// Function MagicLeapARPin.MagicLeapARPinComponent.PinToRestoredOrSyncedID
// Size: 0x1(Inherited: 0x0) 
struct FPinToRestoredOrSyncedID
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function MagicLeapARPin.MagicLeapARPinComponent.TryGetPinData
// Size: 0x18(Inherited: 0x0) 
struct FTryGetPinData
{
	UMagicLeapARPinSaveGame* InPinDataClass;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool OutPinDataValid : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct UMagicLeapARPinSaveGame* ReturnValue;  // 0x10(0x8)

}; 
// Function MagicLeapARPin.MagicLeapARPinFunctionLibrary.BindToOnMagicLeapContentBindingFoundDelegate
// Size: 0x10(Inherited: 0x0) 
struct FBindToOnMagicLeapContentBindingFoundDelegate
{
	struct FDelegate Delegate;  // 0x0(0x10)

}; 
// ScriptStruct MagicLeapARPin.MagicLeapARPinQuery
// Size: 0x68(Inherited: 0x0) 
struct FMagicLeapARPinQuery
{
	struct TSet<uint8_t > Types;  // 0x0(0x50)
	int32_t MaxResults;  // 0x50(0x4)
	struct FVector TargetPoint;  // 0x54(0xC)
	float Radius;  // 0x60(0x4)
	char pad_100_1 : 7;  // 0x64(0x1)
	bool bSorted : 1;  // 0x64(0x1)
	char pad_101[3];  // 0x65(0x3)

}; 
// ScriptStruct MagicLeapARPin.MagicLeapARPinObjectIdList
// Size: 0x50(Inherited: 0x0) 
struct FMagicLeapARPinObjectIdList
{
	struct TSet<struct FString> ObjectIdList;  // 0x0(0x50)

}; 
// Function MagicLeapARPin.MagicLeapARPinFunctionLibrary.CreateTracker
// Size: 0x1(Inherited: 0x0) 
struct FCreateTracker
{
	uint8_t  ReturnValue;  // 0x0(0x1)

}; 
// Function MagicLeapARPin.MagicLeapARPinFunctionLibrary.DestroyTracker
// Size: 0x1(Inherited: 0x0) 
struct FDestroyTracker
{
	uint8_t  ReturnValue;  // 0x0(0x1)

}; 
// Function MagicLeapARPin.MagicLeapARPinFunctionLibrary.GetARPinPositionAndOrientation
// Size: 0x2C(Inherited: 0x0) 
struct FGetARPinPositionAndOrientation
{
	struct FGuid PinId;  // 0x0(0x10)
	struct FVector Position;  // 0x10(0xC)
	struct FRotator Orientation;  // 0x1C(0xC)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool PinFoundInEnvironment : 1;  // 0x28(0x1)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool ReturnValue : 1;  // 0x29(0x1)
	char pad_42[2];  // 0x2A(0x2)

}; 
// Function MagicLeapARPin.MagicLeapARPinFunctionLibrary.SetContentBindingSaveGameUserIndex
// Size: 0x4(Inherited: 0x0) 
struct FSetContentBindingSaveGameUserIndex
{
	int32_t UserIndex;  // 0x0(0x4)

}; 
// Function MagicLeapARPin.MagicLeapARPinFunctionLibrary.ParseStringToARPinId
// Size: 0x28(Inherited: 0x0) 
struct FParseStringToARPinId
{
	struct FString PinIdString;  // 0x0(0x10)
	struct FGuid ARPinId;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool ReturnValue : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// Function MagicLeapARPin.MagicLeapARPinFunctionLibrary.GetARPinPositionAndOrientation_TrackingSpace
// Size: 0x2C(Inherited: 0x0) 
struct FGetARPinPositionAndOrientation_TrackingSpace
{
	struct FGuid PinId;  // 0x0(0x10)
	struct FVector Position;  // 0x10(0xC)
	struct FRotator Orientation;  // 0x1C(0xC)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool PinFoundInEnvironment : 1;  // 0x28(0x1)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool ReturnValue : 1;  // 0x29(0x1)
	char pad_42[2];  // 0x2A(0x2)

}; 
// Function MagicLeapARPin.MagicLeapARPinFunctionLibrary.GetARPinState
// Size: 0x28(Inherited: 0x0) 
struct FGetARPinState
{
	struct FGuid PinId;  // 0x0(0x10)
	struct FMagicLeapARPinState State;  // 0x10(0x14)
	uint8_t  ReturnValue;  // 0x24(0x1)
	char pad_37[3];  // 0x25(0x3)

}; 
// Function MagicLeapARPin.MagicLeapARPinFunctionLibrary.GetAvailableARPins
// Size: 0x20(Inherited: 0x0) 
struct FGetAvailableARPins
{
	int32_t NumRequested;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct TArray<struct FGuid> Pins;  // 0x8(0x10)
	uint8_t  ReturnValue;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)

}; 
// Function MagicLeapARPin.MagicLeapARPinFunctionLibrary.GetClosestARPin
// Size: 0x20(Inherited: 0x0) 
struct FGetClosestARPin
{
	struct FVector SearchPoint;  // 0x0(0xC)
	struct FGuid PinId;  // 0xC(0x10)
	uint8_t  ReturnValue;  // 0x1C(0x1)
	char pad_29[3];  // 0x1D(0x3)

}; 
// Function MagicLeapARPin.MagicLeapARPinFunctionLibrary.UnBindToOnMagicLeapContentBindingFoundDelegate
// Size: 0x10(Inherited: 0x0) 
struct FUnBindToOnMagicLeapContentBindingFoundDelegate
{
	struct FDelegate Delegate;  // 0x0(0x10)

}; 
// Function MagicLeapARPin.MagicLeapARPinFunctionLibrary.GetContentBindingSaveGameUserIndex
// Size: 0x4(Inherited: 0x0) 
struct FGetContentBindingSaveGameUserIndex
{
	int32_t ReturnValue;  // 0x0(0x4)

}; 
// Function MagicLeapARPin.MagicLeapARPinFunctionLibrary.GetGlobalQueryFilter
// Size: 0x70(Inherited: 0x0) 
struct FGetGlobalQueryFilter
{
	struct FMagicLeapARPinQuery CurrentGlobalFilter;  // 0x0(0x68)
	uint8_t  ReturnValue;  // 0x68(0x1)
	char pad_105[7];  // 0x69(0x7)

}; 
// Function MagicLeapARPin.MagicLeapARPinFunctionLibrary.IsTrackerValid
// Size: 0x1(Inherited: 0x0) 
struct FIsTrackerValid
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function MagicLeapARPin.MagicLeapARPinFunctionLibrary.QueryARPins
// Size: 0x80(Inherited: 0x0) 
struct FQueryARPins
{
	struct FMagicLeapARPinQuery Query;  // 0x0(0x68)
	struct TArray<struct FGuid> Pins;  // 0x68(0x10)
	uint8_t  ReturnValue;  // 0x78(0x1)
	char pad_121[7];  // 0x79(0x7)

}; 
// Function MagicLeapARPin.MagicLeapARPinFunctionLibrary.UnBindToOnMagicLeapARPinUpdatedDelegate
// Size: 0x10(Inherited: 0x0) 
struct FUnBindToOnMagicLeapARPinUpdatedDelegate
{
	struct FDelegate Delegate;  // 0x0(0x10)

}; 
