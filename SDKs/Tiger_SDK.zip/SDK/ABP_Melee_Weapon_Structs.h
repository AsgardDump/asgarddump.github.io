#pragma once 
#include "SDK.h" 
 
 
// Function ABP_Melee_Weapon.ABP_Melee_Weapon_C.ExecuteUbergraph_ABP_Melee_Weapon
// Size: 0x110(Inherited: 0x0) 
struct FExecuteUbergraph_ABP_Melee_Weapon
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UAnimSequenceBase* Temp_object_Variable;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct UAnimSequenceBase* Temp_object_Variable_2;  // 0x18(0x8)
	struct UAnimSequenceBase* Temp_object_Variable_3;  // 0x20(0x8)
	struct UAnimSequenceBase* Temp_object_Variable_4;  // 0x28(0x8)
	struct UAnimSequenceBase* Temp_object_Variable_5;  // 0x30(0x8)
	struct UAnimSequenceBase* Temp_object_Variable_6;  // 0x38(0x8)
	struct UAnimSequenceBase* Temp_object_Variable_7;  // 0x40(0x8)
	struct UAnimSequenceBase* Temp_object_Variable_8;  // 0x48(0x8)
	struct UAnimSequenceBase* Temp_object_Variable_9;  // 0x50(0x8)
	struct UAnimSequenceBase* Temp_object_Variable_10;  // 0x58(0x8)
	struct UAnimSequenceBase* Temp_object_Variable_11;  // 0x60(0x8)
	struct UAnimSequenceBase* Temp_object_Variable_12;  // 0x68(0x8)
	struct UAnimSequenceBase* Temp_object_Variable_13;  // 0x70(0x8)
	struct UAnimSequenceBase* Temp_object_Variable_14;  // 0x78(0x8)
	struct UAnimSequenceBase* Temp_object_Variable_15;  // 0x80(0x8)
	struct UAnimSequenceBase* Temp_object_Variable_16;  // 0x88(0x8)
	struct APawn* CallFunc_TryGetPawnOwner_ReturnValue;  // 0x90(0x8)
	struct ATigerPlayer* K2Node_DynamicCast_AsTiger_Player;  // 0x98(0x8)
	char pad_160_1 : 7;  // 0xA0(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0xA0(0x1)
	char pad_161[7];  // 0xA1(0x7)
	struct UAnimSequenceBase* Temp_object_Variable_17;  // 0xA8(0x8)
	struct UTigerAnimInstance* CallFunc_GetTigerAnimInstance_ReturnValue;  // 0xB0(0x8)
	struct UABP_Player_C* K2Node_DynamicCast_AsABP_Player;  // 0xB8(0x8)
	char pad_192_1 : 7;  // 0xC0(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0xC0(0x1)
	char ENUM_MeleeWeaponCategories Temp_byte_Variable;  // 0xC1(0x1)
	char pad_194[2];  // 0xC2(0x2)
	int32_t K2Node_CustomEvent_AttackCount;  // 0xC4(0x4)
	char pad_200_1 : 7;  // 0xC8(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0xC8(0x1)
	char pad_201_1 : 7;  // 0xC9(0x1)
	bool K2Node_SwitchInteger_CmpSuccess : 1;  // 0xC9(0x1)
	char pad_202[6];  // 0xCA(0x6)
	struct UAnimSequenceBase* Temp_object_Variable_18;  // 0xD0(0x8)
	struct UAnimSequenceBase* Temp_object_Variable_19;  // 0xD8(0x8)
	struct UAnimSequenceBase* K2Node_Select_Default;  // 0xE0(0x8)
	struct UAnimMontage* CallFunc_PlaySlotAnimationAsDynamicMontage_ReturnValue;  // 0xE8(0x8)
	struct UAnimSequenceBase* Temp_object_Variable_20;  // 0xF0(0x8)
	char ENUM_MeleeWeaponCategories Temp_byte_Variable_2;  // 0xF8(0x1)
	char pad_249[7];  // 0xF9(0x7)
	struct UAnimSequenceBase* K2Node_Select_Default_2;  // 0x100(0x8)
	struct UAnimMontage* CallFunc_PlaySlotAnimationAsDynamicMontage_ReturnValue_2;  // 0x108(0x8)

}; 
// Function ABP_Melee_Weapon.ABP_Melee_Weapon_C.AnimGraph
// Size: 0x10(Inherited: 0x0) 
struct FAnimGraph
{
	struct FPoseLink AnimGraph;  // 0x0(0x10)

}; 
// Function ABP_Melee_Weapon.ABP_Melee_Weapon_C.OnMelee
// Size: 0x4(Inherited: 0x0) 
struct FOnMelee
{
	int32_t AttackCount;  // 0x0(0x4)

}; 
