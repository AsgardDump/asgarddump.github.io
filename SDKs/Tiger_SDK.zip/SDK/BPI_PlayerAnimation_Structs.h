#pragma once 
#include "SDK.h" 
 
 
// Function BPI_PlayerAnimation.BPI_PlayerAnimation_C.GetWeapon
// Size: 0x10(Inherited: 0x0) 
struct FGetWeapon
{
	struct USkeletalMeshComponent* OutWeapon;  // 0x0(0x8)
	struct USkeletalMeshComponent* OutSecondWeapon;  // 0x8(0x8)

}; 
