#pragma once 
#include <TBFL_TypeAndRarity_Structs.h>
 
 
 
// BlueprintGeneratedClass TBFL_TypeAndRarity.TBFL_TypeAndRarity_C
// Size: 0x28(Inherited: 0x28) 
struct UTBFL_TypeAndRarity_C : public UBlueprintFunctionLibrary
{

	void GetTextFromLootCategory(uint8_t  LootCategory, struct UObject* __WorldContext, struct FText& Text); // Function TBFL_TypeAndRarity.TBFL_TypeAndRarity_C.GetTextFromLootCategory
	void GetShortTextFromWeaponType(uint8_t  WeaponType, struct UObject* __WorldContext, struct FText& ShortType); // Function TBFL_TypeAndRarity.TBFL_TypeAndRarity_C.GetShortTextFromWeaponType
	void GetTextFromAmmoType(uint8_t  In Ammo Type, struct UObject* __WorldContext, struct FText& Text); // Function TBFL_TypeAndRarity.TBFL_TypeAndRarity_C.GetTextFromAmmoType
	void GetColorTextFromItemType(struct UTigerItemAsset* InItemAsset, struct UObject* __WorldContext, struct FText& ColorText); // Function TBFL_TypeAndRarity.TBFL_TypeAndRarity_C.GetColorTextFromItemType
	void GetColorTextFromItemRarity(uint8_t  In Rarity, struct UObject* __WorldContext, struct FText& ColorText); // Function TBFL_TypeAndRarity.TBFL_TypeAndRarity_C.GetColorTextFromItemRarity
	void SetRarityMaterialFromWeaponClass(struct UMeshComponent* InMeshComponent, struct UTigerWeapon* InWeaponClass, struct UObject* __WorldContext); // Function TBFL_TypeAndRarity.TBFL_TypeAndRarity_C.SetRarityMaterialFromWeaponClass
	void GetTextFromItemType(uint8_t  In Item Type, bool InGetShortVersion, struct UObject* __WorldContext, struct FText& Text); // Function TBFL_TypeAndRarity.TBFL_TypeAndRarity_C.GetTextFromItemType
	void GetTextFromItemRarity(uint8_t  In Rarity, struct UObject* __WorldContext, struct FText& Text); // Function TBFL_TypeAndRarity.TBFL_TypeAndRarity_C.GetTextFromItemRarity
	void GetData(struct UObject* __WorldContext, struct UTigerTypeAndRarityData*& Data); // Function TBFL_TypeAndRarity.TBFL_TypeAndRarity_C.GetData
	void GetColorFromItemRarity(uint8_t  In Rarity, struct UObject* __WorldContext, struct FLinearColor& Color); // Function TBFL_TypeAndRarity.TBFL_TypeAndRarity_C.GetColorFromItemRarity
}; 



