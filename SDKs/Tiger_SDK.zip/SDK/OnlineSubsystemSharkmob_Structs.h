#pragma once 
#include "SDK.h" 
 
 
// ScriptStruct OnlineSubsystemSharkmob.INTLChannelInfoSharkmob
// Size: 0x40(Inherited: 0x0) 
struct FINTLChannelInfoSharkmob
{
	struct FString steamid;  // 0x0(0x10)
	struct FString userId;  // 0x10(0x10)
	struct FString issuerId;  // 0x20(0x10)
	struct FINTLMapInfoSharkmob map_info;  // 0x30(0x10)

}; 
// DelegateFunction OnlineSubsystemSharkmob.OnlineConnectionResult__DelegateSignature
// Size: 0xC0(Inherited: 0x0) 
struct FOnlineConnectionResult__DelegateSignature
{
	struct FLoginResultSharkmob Result;  // 0x0(0xB0)
	struct FString ErrorString;  // 0xB0(0x10)

}; 
// ScriptStruct OnlineSubsystemSharkmob.AccountRegistrationDataSharkmob
// Size: 0x50(Inherited: 0x0) 
struct FAccountRegistrationDataSharkmob
{
	struct FString Email;  // 0x0(0x10)
	struct FString Password;  // 0x10(0x10)
	int32_t RegionId;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)
	struct FString UserName;  // 0x28(0x10)
	struct FString VerificationCode;  // 0x38(0x10)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool RecieveNewsletterEmail : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct OnlineSubsystemSharkmob.LoginResultSharkmob
// Size: 0xB0(Inherited: 0x50) 
struct FLoginResultSharkmob : public FAccountRegistrationDataSharkmob
{
	struct FString OpenId;  // 0x50(0x10)
	struct FString Token;  // 0x60(0x10)
	struct FString PfKey;  // 0x70(0x10)
	struct FString Pf;  // 0x80(0x10)
	struct FString SharkmobToken;  // 0x90(0x10)
	struct FString OSSValue;  // 0xA0(0x10)

}; 
// ScriptStruct OnlineSubsystemSharkmob.INTLMapInfoSharkmob
// Size: 0x10(Inherited: 0x0) 
struct FINTLMapInfoSharkmob
{
	struct FString sacc_token;  // 0x0(0x10)

}; 
// DelegateFunction OnlineSubsystemSharkmob.QueryEmailResult__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FQueryEmailResult__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bEmailAvailable : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FString ErrorMessage;  // 0x8(0x10)

}; 
// DelegateFunction OnlineSubsystemSharkmob.QueryUserNameResult__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FQueryUserNameResult__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bUserNameAvailable : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool bUserNameContainsProfanity : 1;  // 0x1(0x1)
	char pad_2[6];  // 0x2(0x6)
	struct FString ErrorString;  // 0x8(0x10)

}; 
// DelegateFunction OnlineSubsystemSharkmob.SendRegistrationVerificationResult__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FSendRegistrationVerificationResult__DelegateSignature
{
	struct FString ErrorMsg;  // 0x0(0x10)

}; 
// Function OnlineSubsystemSharkmob.AccountErrorHandler.GetAccountErrorMessage
// Size: 0x18(Inherited: 0x0) 
struct FGetAccountErrorMessage
{
	int32_t InErrorCode;  // 0x0(0x4)
	uint8_t  InErrorType;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct FString ReturnValue;  // 0x8(0x10)

}; 
// Function OnlineSubsystemSharkmob.AccountErrorHandler.GetThirdPartyErrorCode
// Size: 0x8(Inherited: 0x0) 
struct FGetThirdPartyErrorCode
{
	uint8_t  InErrorEnum;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	int32_t ReturnValue;  // 0x4(0x4)

}; 
// Function OnlineSubsystemSharkmob.AccountErrorHandler.IsAccountLinkingRequired
// Size: 0x1(Inherited: 0x0) 
struct FIsAccountLinkingRequired
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function OnlineSubsystemSharkmob.INTLLoginWithEmailCallbackProxy.ConnectToINTLServiceWithEmail
// Size: 0x30(Inherited: 0x0) 
struct FConnectToINTLServiceWithEmail
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct FString InEmail;  // 0x8(0x10)
	struct FString InPassword;  // 0x18(0x10)
	struct UINTLLoginWithEmailCallbackProxy* ReturnValue;  // 0x28(0x8)

}; 
// Function OnlineSubsystemSharkmob.INTLLoginWithTokenCallbackProxy.ConnectToINTLServiceWithToken
// Size: 0x10(Inherited: 0x0) 
struct FConnectToINTLServiceWithToken
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct UINTLLoginWithTokenCallbackProxy* ReturnValue;  // 0x8(0x8)

}; 
// Function OnlineSubsystemSharkmob.INTLQueryEmailAvailabilityCallbackProxy.QueryEmailAvailabilityWithINTL
// Size: 0x20(Inherited: 0x0) 
struct FQueryEmailAvailabilityWithINTL
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct FString InEmail;  // 0x8(0x10)
	struct UINTLQueryEmailAvailabilityCallbackProxy* ReturnValue;  // 0x18(0x8)

}; 
// Function OnlineSubsystemSharkmob.INTLQueryUserNameAvailabilityCallbackProxy.QueryUserNameAvailabilityWithINTL
// Size: 0x20(Inherited: 0x0) 
struct FQueryUserNameAvailabilityWithINTL
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct FString InUsername;  // 0x8(0x10)
	struct UINTLQueryUserNameAvailabilityCallbackProxy* ReturnValue;  // 0x18(0x8)

}; 
// Function OnlineSubsystemSharkmob.INTLRegisterAndLoginCallbackProxy.RegisterAndLoginToINTL
// Size: 0x60(Inherited: 0x0) 
struct FRegisterAndLoginToINTL
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct FString InEmail;  // 0x8(0x10)
	struct FString InPassword;  // 0x18(0x10)
	struct FString InUsername;  // 0x28(0x10)
	struct FString InVerificationCode;  // 0x38(0x10)
	int32_t InRegionId;  // 0x48(0x4)
	char pad_76_1 : 7;  // 0x4C(0x1)
	bool InReceiveNewsletterEmail : 1;  // 0x4C(0x1)
	char pad_77[3];  // 0x4D(0x3)
	struct FDateTime InBirthday;  // 0x50(0x8)
	struct UINTLRegisterAndLoginCallbackProxy* ReturnValue;  // 0x58(0x8)

}; 
// Function OnlineSubsystemSharkmob.INTLSendRegisterVerificationCodeCallbackProxy.SendRegisterVerificationCode
// Size: 0x20(Inherited: 0x0) 
struct FSendRegisterVerificationCode
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct FString InUsername;  // 0x8(0x10)
	struct UINTLSendRegisterVerificationCodeCallbackProxy* ReturnValue;  // 0x18(0x8)

}; 
