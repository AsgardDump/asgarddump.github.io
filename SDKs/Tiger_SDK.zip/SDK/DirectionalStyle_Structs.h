#pragma once 
#include "SDK.h" 
 
 
// Function DirectionalStyle.DirectionalStyle_C.DetermineNextWeaponSlot
// Size: 0x10(Inherited: 0x10) 
struct FDetermineNextWeaponSlot : public FDetermineNextWeaponSlot
{
	struct ATigerPlayerController* InPlayerController;  // 0x0(0x8)
	uint8_t  InDirection;  // 0x8(0x1)
	uint8_t  ReturnValue;  // 0x9(0x1)
	char pad_26_1 : 7;  // 0x1A(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // 0xA(0x1)
	char pad_27_1 : 7;  // 0x1B(0x1)
	bool CallFunc_HasWeaponForSlot_ReturnValue : 1;  // 0xB(0x1)
	uint8_t  CallFunc_GetCurrentlyEquippedSlot_ReturnValue;  // 0xC(0x1)
	char pad_29_1 : 7;  // 0x1D(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_2 : 1;  // 0xD(0x1)
	char pad_30_1 : 7;  // 0x1E(0x1)
	bool CallFunc_HasWeaponForSlot_ReturnValue_2 : 1;  // 0xE(0x1)
	char pad_31_1 : 7;  // 0x1F(0x1)
	bool CallFunc_HasWeaponForSlot_ReturnValue_3 : 1;  // 0xF(0x1)

}; 
