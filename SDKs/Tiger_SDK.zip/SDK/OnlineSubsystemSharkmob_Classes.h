#pragma once 
#include <OnlineSubsystemSharkmob_Structs.h>
 
 
 
// Class OnlineSubsystemSharkmob.INTLRegisterAndLoginCallbackProxy
// Size: 0xC0(Inherited: 0x30) 
struct UINTLRegisterAndLoginCallbackProxy : public UOnlineBlueprintCallProxyBase
{
	struct FMulticastInlineDelegate OnSuccess;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnFailure;  // 0x40(0x10)
	char pad_80[112];  // 0x50(0x70)

	struct UINTLRegisterAndLoginCallbackProxy* RegisterAndLoginToINTL(struct UObject* WorldContextObject, struct FString InEmail, struct FString InPassword, struct FString InUsername, struct FString InVerificationCode, int32_t InRegionId, bool InReceiveNewsletterEmail, struct FDateTime InBirthday); // Function OnlineSubsystemSharkmob.INTLRegisterAndLoginCallbackProxy.RegisterAndLoginToINTL
}; 



// Class OnlineSubsystemSharkmob.INTLQueryEmailAvailabilityCallbackProxy
// Size: 0x80(Inherited: 0x30) 
struct UINTLQueryEmailAvailabilityCallbackProxy : public UOnlineBlueprintCallProxyBase
{
	struct FMulticastInlineDelegate OnSuccess;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnFailure;  // 0x40(0x10)
	char pad_80[48];  // 0x50(0x30)

	struct UINTLQueryEmailAvailabilityCallbackProxy* QueryEmailAvailabilityWithINTL(struct UObject* WorldContextObject, struct FString InEmail); // Function OnlineSubsystemSharkmob.INTLQueryEmailAvailabilityCallbackProxy.QueryEmailAvailabilityWithINTL
}; 



// Class OnlineSubsystemSharkmob.AccountErrorHandler
// Size: 0x28(Inherited: 0x28) 
struct UAccountErrorHandler : public UObject
{

	bool IsAccountLinkingRequired(); // Function OnlineSubsystemSharkmob.AccountErrorHandler.IsAccountLinkingRequired
	int32_t GetThirdPartyErrorCode(uint8_t  InErrorEnum); // Function OnlineSubsystemSharkmob.AccountErrorHandler.GetThirdPartyErrorCode
	struct FString GetAccountErrorMessage(int32_t InErrorCode, uint8_t  InErrorType); // Function OnlineSubsystemSharkmob.AccountErrorHandler.GetAccountErrorMessage
}; 



// Class OnlineSubsystemSharkmob.INTLLoginWithEmailCallbackProxy
// Size: 0x90(Inherited: 0x30) 
struct UINTLLoginWithEmailCallbackProxy : public UOnlineBlueprintCallProxyBase
{
	struct FMulticastInlineDelegate OnSuccess;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnFailure;  // 0x40(0x10)
	char pad_80[64];  // 0x50(0x40)

	struct UINTLLoginWithEmailCallbackProxy* ConnectToINTLServiceWithEmail(struct UObject* WorldContextObject, struct FString InEmail, struct FString InPassword); // Function OnlineSubsystemSharkmob.INTLLoginWithEmailCallbackProxy.ConnectToINTLServiceWithEmail
}; 



// Class OnlineSubsystemSharkmob.INTLLoginWithTokenCallbackProxy
// Size: 0x70(Inherited: 0x30) 
struct UINTLLoginWithTokenCallbackProxy : public UOnlineBlueprintCallProxyBase
{
	struct FMulticastInlineDelegate OnSuccess;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnFailure;  // 0x40(0x10)
	char pad_80[32];  // 0x50(0x20)

	struct UINTLLoginWithTokenCallbackProxy* ConnectToINTLServiceWithToken(struct UObject* WorldContextObject); // Function OnlineSubsystemSharkmob.INTLLoginWithTokenCallbackProxy.ConnectToINTLServiceWithToken
}; 



// Class OnlineSubsystemSharkmob.INTLQueryUserNameAvailabilityCallbackProxy
// Size: 0x80(Inherited: 0x30) 
struct UINTLQueryUserNameAvailabilityCallbackProxy : public UOnlineBlueprintCallProxyBase
{
	struct FMulticastInlineDelegate OnSuccess;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnFailure;  // 0x40(0x10)
	char pad_80[48];  // 0x50(0x30)

	struct UINTLQueryUserNameAvailabilityCallbackProxy* QueryUserNameAvailabilityWithINTL(struct UObject* WorldContextObject, struct FString InUsername); // Function OnlineSubsystemSharkmob.INTLQueryUserNameAvailabilityCallbackProxy.QueryUserNameAvailabilityWithINTL
}; 



// Class OnlineSubsystemSharkmob.INTLSendRegisterVerificationCodeCallbackProxy
// Size: 0x80(Inherited: 0x30) 
struct UINTLSendRegisterVerificationCodeCallbackProxy : public UOnlineBlueprintCallProxyBase
{
	struct FMulticastInlineDelegate OnSuccess;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnFailure;  // 0x40(0x10)
	char pad_80[48];  // 0x50(0x30)

	struct UINTLSendRegisterVerificationCodeCallbackProxy* SendRegisterVerificationCode(struct UObject* WorldContextObject, struct FString InUsername); // Function OnlineSubsystemSharkmob.INTLSendRegisterVerificationCodeCallbackProxy.SendRegisterVerificationCode
}; 



