#pragma once 
#include <I_ArchetypeSelectButton_Structs.h>
 
 
 
// BlueprintGeneratedClass I_ArchetypeSelectButton.I_ArchetypeSelectButton_C
// Size: 0x28(Inherited: 0x28) 
struct UI_ArchetypeSelectButton_C : public UInterface
{

	void Check New Notification(); // Function I_ArchetypeSelectButton.I_ArchetypeSelectButton_C.Check New Notification
	void SetIsDeselected(); // Function I_ArchetypeSelectButton.I_ArchetypeSelectButton_C.SetIsDeselected
	void SetIsSelected(); // Function I_ArchetypeSelectButton.I_ArchetypeSelectButton_C.SetIsSelected
}; 



