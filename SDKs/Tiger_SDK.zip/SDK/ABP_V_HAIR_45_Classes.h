#pragma once 
#include <ABP_V_HAIR_45_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass ABP_V_HAIR_45.ABP_V_HAIR_44_C
// Size: 0x4970(Inherited: 0x330) 
struct UABP_V_HAIR_44_C : public UTigerCharacterPoseableMeshAnimInstance
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x330(0x8)
	struct FAnimNode_Root AnimGraphNode_Root;  // 0x338(0x30)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_10;  // 0x368(0x108)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace;  // 0x470(0x20)
	struct FAnimNode_MeshSpaceRefPose AnimGraphNode_MeshRefPose;  // 0x490(0x10)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_9;  // 0x4A0(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_8;  // 0x5A8(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_7;  // 0x6B0(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_6;  // 0x7B8(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_5;  // 0x8C0(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_4;  // 0x9C8(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_3;  // 0xAD0(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_2;  // 0xBD8(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone;  // 0xCE0(0x108)
	char pad_3560[8];  // 0xDE8(0x8)
	struct FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_14;  // 0xDF0(0x440)
	struct FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_13;  // 0x1230(0x440)
	struct FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_12;  // 0x1670(0x440)
	struct FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_11;  // 0x1AB0(0x440)
	struct FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_10;  // 0x1EF0(0x440)
	struct FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_9;  // 0x2330(0x440)
	struct FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_8;  // 0x2770(0x440)
	struct FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_7;  // 0x2BB0(0x440)
	struct FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_6;  // 0x2FF0(0x440)
	struct FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_5;  // 0x3430(0x440)
	struct FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_4;  // 0x3870(0x440)
	struct FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_3;  // 0x3CB0(0x440)
	struct FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_2;  // 0x40F0(0x440)
	struct FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics;  // 0x4530(0x440)

	void AnimGraph(struct FPoseLink& AnimGraph); // Function ABP_V_HAIR_45.ABP_V_HAIR_44_C.AnimGraph
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_V_HAIR_44_AnimGraphNode_ModifyBone_36AE07AE4DABD153AC68CEAECF5DBC6D(); // Function ABP_V_HAIR_45.ABP_V_HAIR_44_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_V_HAIR_44_AnimGraphNode_ModifyBone_36AE07AE4DABD153AC68CEAECF5DBC6D
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_V_HAIR_44_AnimGraphNode_ModifyBone_8AD68A904025CE4947115FB1D4D41F30(); // Function ABP_V_HAIR_45.ABP_V_HAIR_44_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_V_HAIR_44_AnimGraphNode_ModifyBone_8AD68A904025CE4947115FB1D4D41F30
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_V_HAIR_44_AnimGraphNode_ModifyBone_4E46B44F4FECB30D5DE6EA8DB5399560(); // Function ABP_V_HAIR_45.ABP_V_HAIR_44_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_V_HAIR_44_AnimGraphNode_ModifyBone_4E46B44F4FECB30D5DE6EA8DB5399560
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_V_HAIR_44_AnimGraphNode_ModifyBone_315284B2469AC3B621F005B5C04A2FF8(); // Function ABP_V_HAIR_45.ABP_V_HAIR_44_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_V_HAIR_44_AnimGraphNode_ModifyBone_315284B2469AC3B621F005B5C04A2FF8
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_V_HAIR_44_AnimGraphNode_ModifyBone_8D3A59494662C04AF881C6B6FB81E134(); // Function ABP_V_HAIR_45.ABP_V_HAIR_44_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_V_HAIR_44_AnimGraphNode_ModifyBone_8D3A59494662C04AF881C6B6FB81E134
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_V_HAIR_44_AnimGraphNode_ModifyBone_3D2B6B504B652DD44BDBACB44595FBCF(); // Function ABP_V_HAIR_45.ABP_V_HAIR_44_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_V_HAIR_44_AnimGraphNode_ModifyBone_3D2B6B504B652DD44BDBACB44595FBCF
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_V_HAIR_44_AnimGraphNode_ModifyBone_66C50A3A4664C78847E5B5AFA455BCFC(); // Function ABP_V_HAIR_45.ABP_V_HAIR_44_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_V_HAIR_44_AnimGraphNode_ModifyBone_66C50A3A4664C78847E5B5AFA455BCFC
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_V_HAIR_44_AnimGraphNode_ModifyBone_AFC45BED44C16CD7D115B1B0086BD944(); // Function ABP_V_HAIR_45.ABP_V_HAIR_44_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_V_HAIR_44_AnimGraphNode_ModifyBone_AFC45BED44C16CD7D115B1B0086BD944
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_V_HAIR_44_AnimGraphNode_ModifyBone_B40AF07749070ABB3EB53BAB1DB4D436(); // Function ABP_V_HAIR_45.ABP_V_HAIR_44_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_V_HAIR_44_AnimGraphNode_ModifyBone_B40AF07749070ABB3EB53BAB1DB4D436
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_V_HAIR_44_AnimGraphNode_ModifyBone_C2CB786341CE88DA7D83D384D8391061(); // Function ABP_V_HAIR_45.ABP_V_HAIR_44_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_V_HAIR_44_AnimGraphNode_ModifyBone_C2CB786341CE88DA7D83D384D8391061
	void ExecuteUbergraph_ABP_V_HAIR_45(int32_t EntryPoint); // Function ABP_V_HAIR_45.ABP_V_HAIR_44_C.ExecuteUbergraph_ABP_V_HAIR_45
}; 



