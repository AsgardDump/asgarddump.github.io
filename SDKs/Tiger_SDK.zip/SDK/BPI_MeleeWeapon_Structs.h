#pragma once 
#include "SDK.h" 
 
 
// Function BPI_MeleeWeapon.BPI_MeleeWeapon_C.GetMeleeWeaponCategory
// Size: 0x1(Inherited: 0x0) 
struct FGetMeleeWeaponCategory
{
	char ENUM_MeleeWeaponCategories MeleeWeaponCategory;  // 0x0(0x1)

}; 
