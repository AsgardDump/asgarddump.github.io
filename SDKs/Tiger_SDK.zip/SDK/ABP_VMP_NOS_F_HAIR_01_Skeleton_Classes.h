#pragma once 
#include <ABP_VMP_NOS_F_HAIR_01_Skeleton_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass ABP_VMP_NOS_F_HAIR_01_Skeleton.ABP_VMP_NOS_F_HAIR_01_Skeleton_C
// Size: 0x4FC0(Inherited: 0x2C0) 
struct UABP_VMP_NOS_F_HAIR_01_Skeleton_C : public UAnimInstance
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x2C0(0x8)
	struct FAnimNode_Root AnimGraphNode_Root;  // 0x2C8(0x30)
	char pad_760[8];  // 0x2F8(0x8)
	struct FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_18;  // 0x300(0x440)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace;  // 0x740(0x20)
	struct FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_17;  // 0x760(0x440)
	struct FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_16;  // 0xBA0(0x440)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace;  // 0xFE0(0x20)
	struct FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_15;  // 0x1000(0x440)
	struct FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_14;  // 0x1440(0x440)
	struct FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_13;  // 0x1880(0x440)
	struct FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_12;  // 0x1CC0(0x440)
	struct FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_11;  // 0x2100(0x440)
	struct FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_10;  // 0x2540(0x440)
	struct FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_9;  // 0x2980(0x440)
	struct FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_8;  // 0x2DC0(0x440)
	struct FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_7;  // 0x3200(0x440)
	struct FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_6;  // 0x3640(0x440)
	struct FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_5;  // 0x3A80(0x440)
	struct FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_4;  // 0x3EC0(0x440)
	struct FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_3;  // 0x4300(0x440)
	struct FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_2;  // 0x4740(0x440)
	struct FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics;  // 0x4B80(0x440)

	void AnimGraph(struct FPoseLink& AnimGraph); // Function ABP_VMP_NOS_F_HAIR_01_Skeleton.ABP_VMP_NOS_F_HAIR_01_Skeleton_C.AnimGraph
	void ExecuteUbergraph_ABP_VMP_NOS_F_HAIR_01_Skeleton(int32_t EntryPoint); // Function ABP_VMP_NOS_F_HAIR_01_Skeleton.ABP_VMP_NOS_F_HAIR_01_Skeleton_C.ExecuteUbergraph_ABP_VMP_NOS_F_HAIR_01_Skeleton
}; 



