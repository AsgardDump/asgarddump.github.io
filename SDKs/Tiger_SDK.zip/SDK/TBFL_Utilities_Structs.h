#pragma once 
#include "SDK.h" 
 
 
// Function TBFL_Utilities.TBFL_Utilities_C.GetCurveValueFloat
// Size: 0x20(Inherited: 0x0) 
struct FGetCurveValueFloat
{
	struct UCurveFloat* Curve;  // 0x0(0x8)
	float Time;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct UObject* __WorldContext;  // 0x10(0x8)
	float Value;  // 0x18(0x4)
	float CallFunc_GetFloatValue_ReturnValue;  // 0x1C(0x4)

}; 
// Function TBFL_Utilities.TBFL_Utilities_C.ForceClampMax
// Size: 0x14(Inherited: 0x0) 
struct FForceClampMax
{
	int32_t Variable;  // 0x0(0x4)
	int32_t Max;  // 0x4(0x4)
	struct UObject* __WorldContext;  // 0x8(0x8)
	int32_t CallFunc_Clamp_ReturnValue;  // 0x10(0x4)

}; 
// Function TBFL_Utilities.TBFL_Utilities_C.ForceClamp
// Size: 0x24(Inherited: 0x0) 
struct FForceClamp
{
	int32_t Variable;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct TArray<struct UObject*> Array;  // 0x8(0x10)
	struct UObject* __WorldContext;  // 0x18(0x8)
	int32_t CallFunc_Array_LastIndex_ReturnValue;  // 0x20(0x4)

}; 
// Function TBFL_Utilities.TBFL_Utilities_C.GetCurveValueColor
// Size: 0x38(Inherited: 0x0) 
struct FGetCurveValueColor
{
	struct UCurveLinearColor* Curve;  // 0x0(0x8)
	float Time;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct UObject* __WorldContext;  // 0x10(0x8)
	struct FLinearColor Value;  // 0x18(0x10)
	struct FLinearColor CallFunc_GetLinearColorValue_ReturnValue;  // 0x28(0x10)

}; 
// Function TBFL_Utilities.TBFL_Utilities_C.GetCurveValueVector
// Size: 0x30(Inherited: 0x0) 
struct FGetCurveValueVector
{
	struct UCurveVector* Curve;  // 0x0(0x8)
	float Time;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct UObject* __WorldContext;  // 0x10(0x8)
	struct FVector Value;  // 0x18(0xC)
	struct FVector CallFunc_GetVectorValue_ReturnValue;  // 0x24(0xC)

}; 
// Function TBFL_Utilities.TBFL_Utilities_C.DistanceToBox
// Size: 0x58(Inherited: 0x0) 
struct FDistanceToBox
{
	struct FVector Position;  // 0x0(0xC)
	struct FVector Bounds;  // 0xC(0xC)
	struct UObject* __WorldContext;  // 0x18(0x8)
	float Distance;  // 0x20(0x4)
	struct FVector CallFunc_Vector_GetAbs_ReturnValue;  // 0x24(0xC)
	struct FVector CallFunc_Subtract_VectorVector_ReturnValue;  // 0x30(0xC)
	float CallFunc_GetMaxElement_ReturnValue;  // 0x3C(0x4)
	struct FVector CallFunc_Vector_ComponentMax_ReturnValue;  // 0x40(0xC)
	float CallFunc_FMin_ReturnValue;  // 0x4C(0x4)
	float CallFunc_VSize_ReturnValue;  // 0x50(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0x54(0x4)

}; 
// Function TBFL_Utilities.TBFL_Utilities_C.Compute2DCentroid
// Size: 0x130(Inherited: 0x0) 
struct FCompute2DCentroid
{
	struct TArray<struct FVector> Array;  // 0x0(0x10)
	struct UObject* __WorldContext;  // 0x10(0x8)
	struct FVector OutCentroid;  // 0x18(0xC)
	float F;  // 0x24(0x4)
	int32_t J;  // 0x28(0x4)
	float TwiceArea;  // 0x2C(0x4)
	struct FVector Last;  // 0x30(0xC)
	struct FVector First;  // 0x3C(0xC)
	struct FVector NextVertex;  // 0x48(0xC)
	struct FVector CurrentVertex;  // 0x54(0xC)
	float PartialSignedArea;  // 0x60(0x4)
	float SignedArea;  // 0x64(0x4)
	struct FVector Centroid;  // 0x68(0xC)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x74(0x4)
	int32_t CallFunc_Subtract_IntInt_ReturnValue;  // 0x78(0x4)
	int32_t Temp_int_Variable;  // 0x7C(0x4)
	char pad_128_1 : 7;  // 0x80(0x1)
	bool CallFunc_LessEqual_IntInt_ReturnValue : 1;  // 0x80(0x1)
	char pad_129[3];  // 0x81(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x84(0x4)
	struct FVector CallFunc_Divide_VectorFloat_ReturnValue;  // 0x88(0xC)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x94(0x4)
	struct FVector CallFunc_Add_VectorVector_ReturnValue;  // 0x98(0xC)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue;  // 0xA4(0xC)
	struct FVector CallFunc_Add_VectorVector_ReturnValue_2;  // 0xB0(0xC)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0xBC(0x4)
	struct FVector CallFunc_Subtract_VectorVector_ReturnValue;  // 0xC0(0xC)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue_2;  // 0xCC(0xC)
	struct FVector CallFunc_Add_VectorVector_ReturnValue_3;  // 0xD8(0xC)
	float CallFunc_BreakVector_X;  // 0xE4(0x4)
	float CallFunc_BreakVector_Y;  // 0xE8(0x4)
	float CallFunc_BreakVector_Z;  // 0xEC(0x4)
	float CallFunc_BreakVector_X_2;  // 0xF0(0x4)
	float CallFunc_BreakVector_Y_2;  // 0xF4(0x4)
	float CallFunc_BreakVector_Z_2;  // 0xF8(0x4)
	float CallFunc_BreakVector_X_3;  // 0xFC(0x4)
	float CallFunc_BreakVector_Y_3;  // 0x100(0x4)
	float CallFunc_BreakVector_Z_3;  // 0x104(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue;  // 0x108(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue_2;  // 0x10C(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue_3;  // 0x110(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue_4;  // 0x114(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_2;  // 0x118(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_3;  // 0x11C(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue_5;  // 0x120(0x4)
	int32_t CallFunc_Array_LastIndex_ReturnValue;  // 0x124(0x4)
	char pad_296_1 : 7;  // 0x128(0x1)
	bool CallFunc_NotEqual_VectorVector_ReturnValue : 1;  // 0x128(0x1)
	char pad_297[3];  // 0x129(0x3)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0x12C(0x4)

}; 
// Function TBFL_Utilities.TBFL_Utilities_C.SortFloatArray
// Size: 0x7C(Inherited: 0x0) 
struct FSortFloatArray
{
	struct TArray<float> InputFloatArray;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool Descending : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct UObject* __WorldContext;  // 0x18(0x8)
	struct TArray<float> OutputArray;  // 0x20(0x10)
	int32_t LastIndexOfArray;  // 0x30(0x4)
	char pad_52[4];  // 0x34(0x4)
	struct TArray<float> Sorted List;  // 0x38(0x10)
	int32_t Temp_int_Variable;  // 0x48(0x4)
	int32_t CallFunc_Array_LastIndex_ReturnValue;  // 0x4C(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x50(0x4)
	int32_t CallFunc_MinOfFloatArray_IndexOfMinValue;  // 0x54(0x4)
	float CallFunc_MinOfFloatArray_MinValue;  // 0x58(0x4)
	int32_t Temp_int_Variable_2;  // 0x5C(0x4)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0x60(0x4)
	char pad_100_1 : 7;  // 0x64(0x1)
	bool CallFunc_LessEqual_IntInt_ReturnValue : 1;  // 0x64(0x1)
	char pad_101[3];  // 0x65(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0x68(0x4)
	int32_t CallFunc_MaxOfFloatArray_IndexOfMaxValue;  // 0x6C(0x4)
	float CallFunc_MaxOfFloatArray_MaxValue;  // 0x70(0x4)
	char pad_116_1 : 7;  // 0x74(0x1)
	bool CallFunc_LessEqual_IntInt_ReturnValue_2 : 1;  // 0x74(0x1)
	char pad_117[3];  // 0x75(0x3)
	int32_t CallFunc_Array_Add_ReturnValue_2;  // 0x78(0x4)

}; 
