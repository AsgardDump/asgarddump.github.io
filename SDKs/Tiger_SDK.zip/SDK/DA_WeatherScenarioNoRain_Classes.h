#pragma once 
#include <DA_WeatherScenarioNoRain_Structs.h>
 
 
 
// BlueprintGeneratedClass DA_WeatherScenarioNoRain.DA_WeatherScenarioNoRain_C
// Size: 0x18C(Inherited: 0x18C) 
struct UDA_WeatherScenarioNoRain_C : public UDA_WeatherScenario_C
{

}; 



