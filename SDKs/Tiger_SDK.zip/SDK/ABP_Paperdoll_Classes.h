#pragma once 
#include <ABP_Paperdoll_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass ABP_Paperdoll.ABP_Paperdoll_C
// Size: 0x2CB0(Inherited: 0x3D0) 
struct UABP_Paperdoll_C : public UTigerPaperDollAnimInstance
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x3D0(0x8)
	struct FAnimNode_RotationMultiplier AnimGraphNode_RotationMultiplier_16;  // 0x3D8(0xF0)
	struct FAnimNode_RotationMultiplier AnimGraphNode_RotationMultiplier_15;  // 0x4C8(0xF0)
	struct FAnimNode_RotationMultiplier AnimGraphNode_RotationMultiplier_14;  // 0x5B8(0xF0)
	struct FAnimNode_RotationMultiplier AnimGraphNode_RotationMultiplier_13;  // 0x6A8(0xF0)
	struct FAnimNode_RotationMultiplier AnimGraphNode_RotationMultiplier_12;  // 0x798(0xF0)
	struct FAnimNode_RotationMultiplier AnimGraphNode_RotationMultiplier_11;  // 0x888(0xF0)
	struct FAnimNode_RotationMultiplier AnimGraphNode_RotationMultiplier_10;  // 0x978(0xF0)
	struct FAnimNode_RotationMultiplier AnimGraphNode_RotationMultiplier_9;  // 0xA68(0xF0)
	struct FAnimNode_RotationMultiplier AnimGraphNode_RotationMultiplier_8;  // 0xB58(0xF0)
	struct FAnimNode_RotationMultiplier AnimGraphNode_RotationMultiplier_7;  // 0xC48(0xF0)
	struct FAnimNode_RotationMultiplier AnimGraphNode_RotationMultiplier_6;  // 0xD38(0xF0)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_9;  // 0xE28(0x80)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace_2;  // 0xEA8(0x20)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace_2;  // 0xEC8(0x20)
	struct FAnimNode_RotationMultiplier AnimGraphNode_RotationMultiplier_5;  // 0xEE8(0xF0)
	struct FAnimNode_RotationMultiplier AnimGraphNode_RotationMultiplier_4;  // 0xFD8(0xF0)
	struct FAnimNode_RotationMultiplier AnimGraphNode_RotationMultiplier_3;  // 0x10C8(0xF0)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_4;  // 0x11B8(0x28)
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose_4;  // 0x11E0(0x158)
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool;  // 0x1338(0xA0)
	struct FAnimNode_Slot AnimGraphNode_Slot;  // 0x13D8(0x48)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_3;  // 0x1420(0x28)
	struct FAnimNode_RotationMultiplier AnimGraphNode_RotationMultiplier_2;  // 0x1448(0xF0)
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose_3;  // 0x1538(0x158)
	struct FAnimNode_RotationMultiplier AnimGraphNode_RotationMultiplier;  // 0x1690(0xF0)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_2;  // 0x1780(0x28)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace;  // 0x17A8(0x20)
	char pad_6088[8];  // 0x17C8(0x8)
	struct FTigerAnimNode_IgnoreParentScaling TigerAnimGraphNode_IgnoreParentScaling_2;  // 0x17D0(0x150)
	struct FTigerAnimNode_IgnoreParentScaling TigerAnimGraphNode_IgnoreParentScaling;  // 0x1920(0x150)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_3;  // 0x1A70(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_2;  // 0x1B78(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone;  // 0x1C80(0x108)
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose_2;  // 0x1D88(0x158)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace;  // 0x1EE0(0x20)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose;  // 0x1F00(0x28)
	struct FAnimNode_Root AnimGraphNode_Root;  // 0x1F28(0x30)
	struct FAnimNode_ApplyAdditive AnimGraphNode_ApplyAdditive_2;  // 0x1F58(0xC8)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_8;  // 0x2020(0x80)
	struct FAnimNode_PoseBlendNode AnimGraphNode_PoseBlendNode;  // 0x20A0(0xA0)
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose;  // 0x2140(0x158)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_7;  // 0x2298(0x80)
	struct FAnimNode_ApplyAdditive AnimGraphNode_ApplyAdditive;  // 0x2318(0xC8)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_6;  // 0x23E0(0x80)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_5;  // 0x2460(0x80)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_4;  // 0x24E0(0x80)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_3;  // 0x2560(0x80)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_2;  // 0x25E0(0x80)
	struct FAnimNode_TwoWayBlend AnimGraphNode_TwoWayBlend_4;  // 0x2660(0xC8)
	struct FAnimNode_TwoWayBlend AnimGraphNode_TwoWayBlend_3;  // 0x2728(0xC8)
	struct FAnimNode_TwoWayBlend AnimGraphNode_TwoWayBlend_2;  // 0x27F0(0xC8)
	struct FAnimNode_TwoWayBlend AnimGraphNode_TwoWayBlend;  // 0x28B8(0xC8)
	struct FAnimNode_BlendListByEnum AnimGraphNode_BlendListByEnum;  // 0x2980(0xB0)
	struct FTigerAnimNode_RandomPlayer TigerAnimGraphNode_RandomPlayer;  // 0x2A30(0xA0)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer;  // 0x2AD0(0x80)
	struct FTigerFilteredLayeredBlend TigerAnimGraphNode_FilteredLayeredBlending;  // 0x2B50(0xC8)
	char pad_11288_1 : 7;  // 0x2C18(0x1)
	bool bIsDefaultSequenceList : 1;  // 0x2C18(0x1)
	char pad_11289[3];  // 0x2C19(0x3)
	struct FName FaceAnimSlotName00;  // 0x2C1C(0x8)
	struct FName FaceAnimSlotName01;  // 0x2C24(0x8)
	struct FName FaceAnimSlotName02;  // 0x2C2C(0x8)
	struct FName FaceAnimSlotName03;  // 0x2C34(0x8)
	float Start Position;  // 0x2C3C(0x4)
	char ENUM_UIAnimationMode UIAnimationSelect;  // 0x2C40(0x1)
	char pad_11329[15];  // 0x2C41(0xF)
	struct FTransform Scale Clavicle LReference Transform;  // 0x2C50(0x30)
	struct FTransform Scale Clavicle RReference Transform;  // 0x2C80(0x30)

	void AnimGraph(struct FPoseLink& AnimGraph); // Function ABP_Paperdoll.ABP_Paperdoll_C.AnimGraph
	void FacialAnimations(); // Function ABP_Paperdoll.ABP_Paperdoll_C.FacialAnimations
	void SelectAnimationSets(struct UTigerAnimationSetCollection* Set Collection); // Function ABP_Paperdoll.ABP_Paperdoll_C.SelectAnimationSets
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Paperdoll_AnimGraphNode_SequencePlayer_0C84F26241DF23504C8DBF9B4E6ED9D6(); // Function ABP_Paperdoll.ABP_Paperdoll_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Paperdoll_AnimGraphNode_SequencePlayer_0C84F26241DF23504C8DBF9B4E6ED9D6
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Paperdoll_TigerAnimGraphNode_RandomPlayer_A8C728FF47A5802CD0C3EAB638BED191(); // Function ABP_Paperdoll.ABP_Paperdoll_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Paperdoll_TigerAnimGraphNode_RandomPlayer_A8C728FF47A5802CD0C3EAB638BED191
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Paperdoll_AnimGraphNode_SequencePlayer_F6119FB64030A2FB3C6041B9E77579B3(); // Function ABP_Paperdoll.ABP_Paperdoll_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Paperdoll_AnimGraphNode_SequencePlayer_F6119FB64030A2FB3C6041B9E77579B3
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Paperdoll_AnimGraphNode_SequencePlayer_C42E041348A26E837E668D9F9E6B722F(); // Function ABP_Paperdoll.ABP_Paperdoll_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Paperdoll_AnimGraphNode_SequencePlayer_C42E041348A26E837E668D9F9E6B722F
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Paperdoll_AnimGraphNode_SequencePlayer_BB1D1FF74A496723387A3B8DBAADF705(); // Function ABP_Paperdoll.ABP_Paperdoll_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Paperdoll_AnimGraphNode_SequencePlayer_BB1D1FF74A496723387A3B8DBAADF705
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Paperdoll_AnimGraphNode_SequencePlayer_E582EC97449B0B37ADC0ACA05429B4C2(); // Function ABP_Paperdoll.ABP_Paperdoll_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Paperdoll_AnimGraphNode_SequencePlayer_E582EC97449B0B37ADC0ACA05429B4C2
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Paperdoll_AnimGraphNode_SequencePlayer_CE1E43BE48777820551A1A88BB0B3107(); // Function ABP_Paperdoll.ABP_Paperdoll_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Paperdoll_AnimGraphNode_SequencePlayer_CE1E43BE48777820551A1A88BB0B3107
	void AddSets(struct UTigerAnimationSetCollection* SetCollection); // Function ABP_Paperdoll.ABP_Paperdoll_C.AddSets
	void BlueprintUpdateAnimation(float DeltaTimeX); // Function ABP_Paperdoll.ABP_Paperdoll_C.BlueprintUpdateAnimation
	void BlueprintInitializeAnimation(); // Function ABP_Paperdoll.ABP_Paperdoll_C.BlueprintInitializeAnimation
	void BlueprintBeginPlay(); // Function ABP_Paperdoll.ABP_Paperdoll_C.BlueprintBeginPlay
	void ClearProps(struct UAnimMontage* Montage, bool bInterrupted); // Function ABP_Paperdoll.ABP_Paperdoll_C.ClearProps
	void ExecuteUbergraph_ABP_Paperdoll(int32_t EntryPoint); // Function ABP_Paperdoll.ABP_Paperdoll_C.ExecuteUbergraph_ABP_Paperdoll
}; 



