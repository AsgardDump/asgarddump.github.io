#pragma once 
#include <Shark_Structs.h>
 
 
 
// Class Shark.SharkOnlineSettings
// Size: 0x48(Inherited: 0x38) 
struct USharkOnlineSettings : public UDeveloperSettings
{
	float MaximumRetryDelaySeconds;  // 0x38(0x4)
	int32_t MinimumAccountCreationAge;  // 0x3C(0x4)
	int32_t PartyMaintenancePollIntervalSeconds;  // 0x40(0x4)
	char pad_68[4];  // 0x44(0x4)

}; 



// Class Shark.ShUserSecrets
// Size: 0x28(Inherited: 0x28) 
struct UShUserSecrets : public UObject
{

}; 



// Class Shark.SharkAccounts
// Size: 0x90(Inherited: 0x28) 
struct USharkAccounts : public UObject
{
	char pad_40[96];  // 0x28(0x60)
	struct UShAccountSettings* Settings;  // 0x88(0x8)

	void SharkUsernameRegisteredQueryCallback__DelegateSignature(bool bInSuccess, bool bIsAvailable, bool bIsProfanity, struct FString InUsername); // DelegateFunction Shark.SharkAccounts.SharkUsernameRegisteredQueryCallback__DelegateSignature
	void SharkLoginCallback__DelegateSignature(struct FSharkLoginResult InResult); // DelegateFunction Shark.SharkAccounts.SharkLoginCallback__DelegateSignature
	void SharkEmailRegisteredQueryCallback__DelegateSignature(bool bInSuccess, bool bInRegistered, struct FString InEmail); // DelegateFunction Shark.SharkAccounts.SharkEmailRegisteredQueryCallback__DelegateSignature
	void SharkAccountActionCallback__DelegateSignature(struct FSharkAccountActionResult InResult); // DelegateFunction Shark.SharkAccounts.SharkAccountActionCallback__DelegateSignature
	void SendRegistrationVerificationCode(struct FString InEmail, struct FDelegate InCallback); // Function Shark.SharkAccounts.SendRegistrationVerificationCode
	void RegisterAndLogin(struct FSharkAccountRegistrationData InRegistrationData, struct FDelegate InCallback); // Function Shark.SharkAccounts.RegisterAndLogin
	void QueryUsernameRegisterStatus(struct FString InUsername, struct FDelegate InCallback); // Function Shark.SharkAccounts.QueryUsernameRegisterStatus
	void QueryEmailRegisterStatus(struct FString InEmail, struct FDelegate InCallback); // Function Shark.SharkAccounts.QueryEmailRegisterStatus
	void PlatformLogin(struct FDelegate InCallback, bool bIsSharkmobAccountLoginEnabled); // Function Shark.SharkAccounts.PlatformLogin
	void Login(struct FString InEmail, struct FString InPassword, struct FDelegate InCallback); // Function Shark.SharkAccounts.Login
}; 



// Class Shark.SharkLocalDeveloperSettings
// Size: 0x38(Inherited: 0x38) 
struct USharkLocalDeveloperSettings : public UDeveloperSettings
{

}; 



// Class Shark.SharkA2SProtocolHandler
// Size: 0xC8(Inherited: 0x30) 
struct USharkA2SProtocolHandler : public UGameInstanceSubsystem
{
	char pad_48[152];  // 0x30(0x98)

}; 



// Class Shark.ShOnlineServerSettings
// Size: 0x90(Inherited: 0x38) 
struct UShOnlineServerSettings : public UDeveloperSettings
{
	struct FString ServerSecretDev;  // 0x38(0x10)
	struct FString ServerSecretUat;  // 0x48(0x10)
	struct FString ServerSecretProd;  // 0x58(0x10)
	struct FString ServerSecretLocal;  // 0x68(0x10)
	struct FString ServerSecretTracker;  // 0x78(0x10)
	uint32_t SeasonConfigId;  // 0x88(0x4)
	char pad_140[4];  // 0x8C(0x4)

}; 



// Class Shark.SharkLoginHelperLibrary
// Size: 0x28(Inherited: 0x28) 
struct USharkLoginHelperLibrary : public UBlueprintFunctionLibrary
{

	struct FString GetErrorMessage(struct FSharkLoginResult& InLoginResult); // Function Shark.SharkLoginHelperLibrary.GetErrorMessage
}; 



// Class Shark.ShAccountSettings
// Size: 0x60(Inherited: 0x38) 
struct UShAccountSettings : public UDeveloperSettings
{
	char pad_56_1 : 7;  // 0x38(0x1)
	bool LogEnabled : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct FString SandboxUrl;  // 0x40(0x10)
	struct FString ProductionUrl;  // 0x50(0x10)

}; 



// Class Shark.SharkBlueprintFunctionLibrary
// Size: 0x28(Inherited: 0x28) 
struct USharkBlueprintFunctionLibrary : public UBlueprintFunctionLibrary
{

	void UnregisterApplicationHasReactivatedForSelf(struct UObject* InSelf); // Function Shark.SharkBlueprintFunctionLibrary.UnregisterApplicationHasReactivatedForSelf
	void SetCustomPrimitiveDataVector4(struct UPrimitiveComponent* PrimitiveComponent, uint8_t  CustomDataName, struct FVector4 Value, bool bDoRuntimeUpdate); // Function Shark.SharkBlueprintFunctionLibrary.SetCustomPrimitiveDataVector4
	void SetCustomPrimitiveDataVector3(struct UPrimitiveComponent* PrimitiveComponent, uint8_t  CustomDataName, struct FVector Value, bool bDoRuntimeUpdate); // Function Shark.SharkBlueprintFunctionLibrary.SetCustomPrimitiveDataVector3
	void SetCustomPrimitiveDataVector2(struct UPrimitiveComponent* PrimitiveComponent, uint8_t  CustomDataName, struct FVector2D Value, bool bDoRuntimeUpdate); // Function Shark.SharkBlueprintFunctionLibrary.SetCustomPrimitiveDataVector2
	void SetCustomPrimitiveDataFloat(struct UPrimitiveComponent* PrimitiveComponent, uint8_t  CustomDataName, float Value, bool bDoRuntimeUpdate); // Function Shark.SharkBlueprintFunctionLibrary.SetCustomPrimitiveDataFloat
	void SetCastDynamicShadows(struct UPrimitiveComponent* InPrimitiveComponent, bool InValue); // Function Shark.SharkBlueprintFunctionLibrary.SetCastDynamicShadows
	void RegisterApplicationHasReactivated(struct FDelegate InDelegate); // Function Shark.SharkBlueprintFunctionLibrary.RegisterApplicationHasReactivated
	void OnAssetsLoaded__DelegateSignature(struct TArray<struct UObject*>& InLoadedObjects); // DelegateFunction Shark.SharkBlueprintFunctionLibrary.OnAssetsLoaded__DelegateSignature
	void LoadMultipleObjectsAsync(struct TArray<struct TSoftObjectPtr<UObject>>& SoftObjects, struct FDelegate OnLoaded); // Function Shark.SharkBlueprintFunctionLibrary.LoadMultipleObjectsAsync
	uint8_t  GetPlatformType(); // Function Shark.SharkBlueprintFunctionLibrary.GetPlatformType
	int32_t GetNumMips(struct UTexture2D* InTexture); // Function Shark.SharkBlueprintFunctionLibrary.GetNumMips
	void ApplicationLifetimeDelegate__DelegateSignature(); // DelegateFunction Shark.SharkBlueprintFunctionLibrary.ApplicationLifetimeDelegate__DelegateSignature
}; 



// Class Shark.SharkPlatformSettings
// Size: 0x40(Inherited: 0x38) 
struct USharkPlatformSettings : public USharkLocalDeveloperSettings
{
	uint8_t  PlatformType;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)

}; 



// Class Shark.SharkRenderingSettings
// Size: 0x1F8(Inherited: 0x38) 
struct USharkRenderingSettings : public UDeveloperSettings
{
	int32_t CustomPrimitiveFloatDataNameMapping[3a];  // 0x38(0xE8)
	int32_t CustomPrimitiveVector2DataNameMapping[13];  // 0x120(0x4C)
	int32_t CustomPrimitiveVector3DataNameMapping[19];  // 0x16C(0x64)
	int32_t CustomPrimitiveVector4DataNameMapping[9];  // 0x1D0(0x24)
	char pad_500[4];  // 0x1F4(0x4)

}; 



// Class Shark.SharkRoundRobinSettings
// Size: 0x50(Inherited: 0x38) 
struct USharkRoundRobinSettings : public UDeveloperSettings
{
	char pad_56_1 : 7;  // 0x38(0x1)
	bool bEnabled : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct TArray<struct FSharkRoundRobinClassSettings> GroupSettings;  // 0x40(0x10)

}; 



// Class Shark.SharkRoundRobinSubsystem
// Size: 0xC0(Inherited: 0x30) 
struct USharkRoundRobinSubsystem : public UWorldSubsystem
{
	char pad_48[144];  // 0x30(0x90)

}; 



// Class Shark.SharkRuntimeTextSubsystem
// Size: 0x80(Inherited: 0x30) 
struct USharkRuntimeTextSubsystem : public UEngineSubsystem
{
	char pad_48[80];  // 0x30(0x50)

	struct FText GetRuntimeText(struct FName& InKey); // Function Shark.SharkRuntimeTextSubsystem.GetRuntimeText
}; 



// Class Shark.SharkServerMetrics
// Size: 0xE0(Inherited: 0x30) 
struct USharkServerMetrics : public UGameInstanceSubsystem
{
	char pad_48[176];  // 0x30(0xB0)

}; 



// Class Shark.SharkTelemetry
// Size: 0x110(Inherited: 0x28) 
struct USharkTelemetry : public UObject
{
	char pad_40[16];  // 0x28(0x10)
	struct FSharkTelemetrySettings TelemetryApplicationSettings;  // 0x38(0x50)
	char pad_136[24];  // 0x88(0x18)
	struct TArray<struct FSharkTelemtryEventData> BufferedEvents;  // 0xA0(0x10)
	char pad_176[80];  // 0xB0(0x50)
	struct UGameInstance* GameInstance;  // 0x100(0x8)
	char pad_264[8];  // 0x108(0x8)

}; 



