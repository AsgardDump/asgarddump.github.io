#pragma once 
#include <TBFL_SpreadPatternHelpers_Structs.h>
 
 
 
// BlueprintGeneratedClass TBFL_SpreadPatternHelpers.TBFL_SpreadPatternHelpers_C
// Size: 0x28(Inherited: 0x28) 
struct UTBFL_SpreadPatternHelpers_C : public UBlueprintFunctionLibrary
{

	void GetPositionInGrid(int32_t Index, int32_t Width, int32_t Height, struct UObject* __WorldContext, int32_t& X, int32_t& Y); // Function TBFL_SpreadPatternHelpers.TBFL_SpreadPatternHelpers_C.GetPositionInGrid
	void AddNoise(struct FVector InDirection, float MagnitudeInDegrees, struct FTigerRangedRandomState& RandomState, struct UObject* __WorldContext, struct FVector& OutDirection); // Function TBFL_SpreadPatternHelpers.TBFL_SpreadPatternHelpers_C.AddNoise
	void GetSpreadRange(bool ShouldBeInsideSpreadRadius, struct UTigerRangedWeaponComponent* RangedWeaponComponent, struct UObject* __WorldContext, float& NegativeSpreadInDegrees, float& PositiveSpreadInDegrees); // Function TBFL_SpreadPatternHelpers.TBFL_SpreadPatternHelpers_C.GetSpreadRange
	void GetBulletsPerFire(struct UTigerRangedWeaponComponent* RangedWeaponComponent, struct UObject* __WorldContext, int32_t& BulletCount); // Function TBFL_SpreadPatternHelpers.TBFL_SpreadPatternHelpers_C.GetBulletsPerFire
	void GetBulletProgressInSectionFloat(float SectionStart, float SectionEnd, float BulletProgress, struct UObject* __WorldContext, bool& IsInSection, float& ProgressInSection); // Function TBFL_SpreadPatternHelpers.TBFL_SpreadPatternHelpers_C.GetBulletProgressInSectionFloat
	void RotateDirectionLeft(struct FVector InDirection, float Degrees, struct UObject* __WorldContext, struct FVector& OutDirection); // Function TBFL_SpreadPatternHelpers.TBFL_SpreadPatternHelpers_C.RotateDirectionLeft
	void RotateDirectionRight(struct FVector InDirection, float Degrees, struct UObject* __WorldContext, struct FVector& OutDirection); // Function TBFL_SpreadPatternHelpers.TBFL_SpreadPatternHelpers_C.RotateDirectionRight
	void RotateDirectionDown(struct FVector InDirection, float Degrees, struct UObject* __WorldContext, struct FVector& OutDirection); // Function TBFL_SpreadPatternHelpers.TBFL_SpreadPatternHelpers_C.RotateDirectionDown
	void RotateDirectionUp(struct FVector InDirection, float Degrees, struct UObject* __WorldContext, struct FVector& OutDirection); // Function TBFL_SpreadPatternHelpers.TBFL_SpreadPatternHelpers_C.RotateDirectionUp
	void GetBulletProgressInSection(int32_t BulletSectionStart, int32_t BulletSectionEnd, int32_t BulletIndex, struct UObject* __WorldContext, bool& IsInSection, float& Progress); // Function TBFL_SpreadPatternHelpers.TBFL_SpreadPatternHelpers_C.GetBulletProgressInSection
	void GetBulletProgress(int32_t BulletIndex, struct UTigerRangedWeaponComponent* RangedWeaponComponent, struct UObject* __WorldContext, float& BulletProgress); // Function TBFL_SpreadPatternHelpers.TBFL_SpreadPatternHelpers_C.GetBulletProgress
	void DirectionAlongLine(float BeginYaw, float EndYaw, float BeginPitch, float EndPitch, float Progress, struct FVector AimDirection, struct UObject* __WorldContext, struct FVector& Direction); // Function TBFL_SpreadPatternHelpers.TBFL_SpreadPatternHelpers_C.DirectionAlongLine
	void DirectionInCircle(struct FVector AimDirection, float ProgressionZeroToOne, float RadiusDegrees, float RotationOffset, struct UObject* __WorldContext, struct FVector& Point); // Function TBFL_SpreadPatternHelpers.TBFL_SpreadPatternHelpers_C.DirectionInCircle
	void DirectionInArc(float MinRotationDegrees, float MaxRotationDegrees, float ProgressZeroToOne, struct FVector AimDirection, float RadiusDegrees, struct UObject* __WorldContext, struct FVector& Point); // Function TBFL_SpreadPatternHelpers.TBFL_SpreadPatternHelpers_C.DirectionInArc
}; 



