#pragma once 
#include <TBP_ActionBuffer_Structs.h>
 
 
 
// BlueprintGeneratedClass TBP_ActionBuffer.TBP_ActionBuffer_C
// Size: 0xB0(Inherited: 0xB0) 
struct UTBP_ActionBuffer_C : public UTigerActionBuffer
{

}; 



