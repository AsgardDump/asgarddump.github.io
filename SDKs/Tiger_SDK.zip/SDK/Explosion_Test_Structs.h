#pragma once 
#include "SDK.h" 
 
 
// Function Explosion_Test.Explosion_Test_C.ExecuteUbergraph_Explosion_Test
// Size: 0x14(Inherited: 0x0) 
struct FExecuteUbergraph_Explosion_Test
{
	int32_t EntryPoint;  // 0x0(0x4)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x4(0xC)
	int32_t CallFunc_PostEventAtLocation_ReturnValue;  // 0x10(0x4)

}; 
