#pragma once 
#include <RangedOnlyStyle_Structs.h>
 
 
 
// BlueprintGeneratedClass RangedOnlyStyle.RangedOnlyStyle_C
// Size: 0x48(Inherited: 0x48) 
struct URangedOnlyStyle_C : public UTigerWeaponCycleStyle
{

	uint8_t  DetermineNextWeaponSlot(struct ATigerPlayerController* InPlayerController, uint8_t  InDirection); // Function RangedOnlyStyle.RangedOnlyStyle_C.DetermineNextWeaponSlot
}; 



