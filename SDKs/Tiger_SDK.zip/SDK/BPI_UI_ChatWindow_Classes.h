#pragma once 
#include <BPI_UI_ChatWindow_Structs.h>
 
 
 
// BlueprintGeneratedClass BPI_UI_ChatWindow.BPI_UI_ChatWindow_C
// Size: 0x28(Inherited: 0x28) 
struct UBPI_UI_ChatWindow_C : public UInterface
{

	void OnBanStatusChanged(struct FTigerMuteInfo InMuteInfo); // Function BPI_UI_ChatWindow.BPI_UI_ChatWindow_C.OnBanStatusChanged
	void WelcomePlayersInElysium(); // Function BPI_UI_ChatWindow.BPI_UI_ChatWindow_C.WelcomePlayersInElysium
	void OnMessageNameUnhovered(); // Function BPI_UI_ChatWindow.BPI_UI_ChatWindow_C.OnMessageNameUnhovered
	void OnMessageNameHovered(struct FTigerChatMessage& InChatData); // Function BPI_UI_ChatWindow.BPI_UI_ChatWindow_C.OnMessageNameHovered
	void Focus on Input Box(); // Function BPI_UI_ChatWindow.BPI_UI_ChatWindow_C.Focus on Input Box
	void AddMessage(struct FTigerChatMessage& InChatMessage); // Function BPI_UI_ChatWindow.BPI_UI_ChatWindow_C.AddMessage
}; 



