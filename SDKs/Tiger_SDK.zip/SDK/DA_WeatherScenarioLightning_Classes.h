#pragma once 
#include <DA_WeatherScenarioLightning_Structs.h>
 
 
 
// BlueprintGeneratedClass DA_WeatherScenarioLightning.DA_WeatherScenarioLightning_C
// Size: 0x18C(Inherited: 0x18C) 
struct UDA_WeatherScenarioLightning_C : public UDA_WeatherScenario_C
{

}; 



