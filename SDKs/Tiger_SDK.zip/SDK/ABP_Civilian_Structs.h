#pragma once 
#include "SDK.h" 
 
 
// Function ABP_Civilian.ABP_Civilian_C.HandleContextualIdle
// Size: 0x1F(Inherited: 0x0) 
struct FHandleContextualIdle
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Temp_bool_Variable : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool Temp_bool_Variable_3 : 1;  // 0x2(0x1)
	char pad_3_1 : 7;  // 0x3(0x1)
	bool Temp_bool_Variable_4 : 1;  // 0x3(0x1)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Temp_bool_Variable_5 : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool Temp_bool_Variable_6 : 1;  // 0x5(0x1)
	char pad_6_1 : 7;  // 0x6(0x1)
	bool Temp_bool_Variable_7 : 1;  // 0x6(0x1)
	char pad_7_1 : 7;  // 0x7(0x1)
	bool CallFunc_NotEqual_NameName_ReturnValue : 1;  // 0x7(0x1)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool Temp_bool_Variable_8 : 1;  // 0x9(0x1)
	char pad_10[6];  // 0xA(0x6)
	struct ATigerNPC* CallFunc_GetOwningNpc_ReturnValue;  // 0x10(0x8)
	uint8_t  Temp_byte_Variable;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool K2Node_Select_Default : 1;  // 0x19(0x1)
	char pad_26_1 : 7;  // 0x1A(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x1A(0x1)
	char pad_27_1 : 7;  // 0x1B(0x1)
	bool CallFunc_HasAnyProp_ReturnValue : 1;  // 0x1B(0x1)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool CallFunc_NotEqual_NameName_ReturnValue_2 : 1;  // 0x1C(0x1)
	char pad_29_1 : 7;  // 0x1D(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x1D(0x1)
	char pad_30_1 : 7;  // 0x1E(0x1)
	bool CallFunc_BooleanAND_ReturnValue_2 : 1;  // 0x1E(0x1)

}; 
// Function ABP_Civilian.ABP_Civilian_C.ExecuteUbergraph_ABP_Civilian
// Size: 0x1F0(Inherited: 0x0) 
struct FExecuteUbergraph_ABP_Civilian
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_EqualEqual_FloatFloat_ReturnValue : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool CallFunc_Less_FloatFloat_ReturnValue : 1;  // 0x5(0x1)
	char pad_6_1 : 7;  // 0x6(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x6(0x1)
	char pad_7_1 : 7;  // 0x7(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x7(0x1)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CallFunc_Less_FloatFloat_ReturnValue_2 : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct UAnimMontage* Temp_object_Variable;  // 0x10(0x8)
	struct UAnimMontage* Temp_object_Variable_2;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool Temp_bool_Variable : 1;  // 0x20(0x1)
	char pad_33_1 : 7;  // 0x21(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0x21(0x1)
	char pad_34[6];  // 0x22(0x6)
	struct UAnimMontage* Temp_object_Variable_3;  // 0x28(0x8)
	float CallFunc_GetRelevantAnimTimeRemaining_ReturnValue;  // 0x30(0x4)
	char pad_52_1 : 7;  // 0x34(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue : 1;  // 0x34(0x1)
	char pad_53[3];  // 0x35(0x3)
	struct UAnimMontage* Temp_object_Variable_4;  // 0x38(0x8)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool Temp_bool_Variable_3 : 1;  // 0x40(0x1)
	char pad_65[3];  // 0x41(0x3)
	float CallFunc_GetRelevantAnimTimeRemaining_ReturnValue_2;  // 0x44(0x4)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue_2 : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)
	struct UTigerRandomSequenceList* CallFunc_GetRandomAnimationSequenceList_ReturnValue;  // 0x50(0x8)
	float CallFunc_SelectFloat_ReturnValue;  // 0x58(0x4)
	char pad_92_1 : 7;  // 0x5C(0x1)
	bool CallFunc_GreaterEqual_FloatFloat_ReturnValue : 1;  // 0x5C(0x1)
	char pad_93[3];  // 0x5D(0x3)
	struct UAnimSequence* CallFunc_GetFaceAnimationForCurve_ReturnValue;  // 0x60(0x8)
	float K2Node_Event_DeltaTimeX;  // 0x68(0x4)
	char pad_108_1 : 7;  // 0x6C(0x1)
	bool CallFunc_Less_FloatFloat_ReturnValue_3 : 1;  // 0x6C(0x1)
	char pad_109[3];  // 0x6D(0x3)
	struct APawn* CallFunc_TryGetPawnOwner_ReturnValue;  // 0x70(0x8)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool CallFunc_IsDedicatedServer_ReturnValue : 1;  // 0x78(0x1)
	char pad_121_1 : 7;  // 0x79(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x79(0x1)
	char pad_122[2];  // 0x7A(0x2)
	struct FRotator CallFunc_K2_GetActorRotation_ReturnValue;  // 0x7C(0xC)
	struct UTigerAnimationSetCollection* K2Node_Event_SetCollection;  // 0x88(0x8)
	char pad_144_1 : 7;  // 0x90(0x1)
	bool CallFunc_NotEqual_ByteByte_ReturnValue : 1;  // 0x90(0x1)
	char pad_145_1 : 7;  // 0x91(0x1)
	bool K2Node_Event_bIsLeftFoot : 1;  // 0x91(0x1)
	char pad_146[2];  // 0x92(0x2)
	float K2Node_Event_FootstepDuration;  // 0x94(0x4)
	struct FTigerNpcReactionEvent K2Node_Event_ReactionEvent;  // 0x98(0x18)
	struct ATigerNPC* CallFunc_GetOwningNpc_ReturnValue;  // 0xB0(0x8)
	char pad_184_1 : 7;  // 0xB8(0x1)
	bool CallFunc_GreaterEqual_FloatFloat_ReturnValue_2 : 1;  // 0xB8(0x1)
	char pad_185_1 : 7;  // 0xB9(0x1)
	bool Temp_bool_Has_Been_Initd_Variable : 1;  // 0xB9(0x1)
	char pad_186[2];  // 0xBA(0x2)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0xBC(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue;  // 0xC0(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue_2;  // 0xC4(0x4)
	uint8_t  K2Node_Event_LastAnimationMode;  // 0xC8(0x1)
	char pad_201[3];  // 0xC9(0x3)
	float CallFunc_Subtract_FloatFloat_ReturnValue_2;  // 0xCC(0x4)
	struct FVector CallFunc_MakeVector_ReturnValue;  // 0xD0(0xC)
	char pad_220_1 : 7;  // 0xDC(0x1)
	bool CallFunc_BooleanAND_ReturnValue_2 : 1;  // 0xDC(0x1)
	char pad_221[3];  // 0xDD(0x3)
	struct ATigerNPC* CallFunc_GetOwningNpc_ReturnValue_2;  // 0xE0(0x8)
	char pad_232_1 : 7;  // 0xE8(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0xE8(0x1)
	char pad_233[7];  // 0xE9(0x7)
	struct ATigerPlayer* K2Node_Event_InPlayer;  // 0xF0(0x8)
	struct FVector K2Node_Event_InDirectionToPlayer;  // 0xF8(0xC)
	float CallFunc_BreakVector_X;  // 0x104(0x4)
	float CallFunc_BreakVector_Y;  // 0x108(0x4)
	float CallFunc_BreakVector_Z;  // 0x10C(0x4)
	float CallFunc_BreakVector_X_2;  // 0x110(0x4)
	float CallFunc_BreakVector_Y_2;  // 0x114(0x4)
	float CallFunc_BreakVector_Z_2;  // 0x118(0x4)
	float CallFunc_Abs_ReturnValue;  // 0x11C(0x4)
	char pad_288_1 : 7;  // 0x120(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue_3 : 1;  // 0x120(0x1)
	char pad_289_1 : 7;  // 0x121(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue_4 : 1;  // 0x121(0x1)
	char pad_290[6];  // 0x122(0x6)
	struct UAnimMontage* K2Node_Select_Default;  // 0x128(0x8)
	struct UAnimMontage* K2Node_Select_Default_2;  // 0x130(0x8)
	float CallFunc_Abs_ReturnValue_2;  // 0x138(0x4)
	char pad_316_1 : 7;  // 0x13C(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue_5 : 1;  // 0x13C(0x1)
	char pad_317[3];  // 0x13D(0x3)
	struct UAnimSequence* CallFunc_GetSequence_ReturnValue;  // 0x140(0x8)
	struct UAnimMontage* K2Node_Select_Default_3;  // 0x148(0x8)
	struct ATigerNPC* CallFunc_GetOwningNpc_ReturnValue_3;  // 0x150(0x8)
	uint8_t  CallFunc_DedicatedServerBranch_NetMode;  // 0x158(0x1)
	char pad_345_1 : 7;  // 0x159(0x1)
	bool K2Node_SwitchEnum_CmpSuccess_2 : 1;  // 0x159(0x1)
	char pad_346[2];  // 0x15A(0x2)
	float CallFunc_Montage_Play_ReturnValue;  // 0x15C(0x4)
	struct FTigerSettleEvent K2Node_Event_SettleEvent;  // 0x160(0x1)
	char pad_353[3];  // 0x161(0x3)
	float CallFunc_FInterpTo_ReturnValue;  // 0x164(0x4)
	float CallFunc_GetRelevantAnimTimeRemaining_ReturnValue_3;  // 0x168(0x4)
	char pad_364_1 : 7;  // 0x16C(0x1)
	bool CallFunc_LessEqual_FloatFloat_ReturnValue : 1;  // 0x16C(0x1)
	char pad_365[3];  // 0x16D(0x3)
	int32_t CallFunc_RandomInteger_ReturnValue;  // 0x170(0x4)
	char pad_372[4];  // 0x174(0x4)
	struct UAnimMontage* CallFunc_Array_Get_Item;  // 0x178(0x8)
	float CallFunc_RandomFloatInRange_ReturnValue;  // 0x180(0x4)
	char pad_388_1 : 7;  // 0x184(0x1)
	bool CallFunc_GreaterEqual_FloatFloat_ReturnValue_3 : 1;  // 0x184(0x1)
	char pad_389_1 : 7;  // 0x185(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_2 : 1;  // 0x185(0x1)
	char pad_390_1 : 7;  // 0x186(0x1)
	bool CallFunc_BooleanOR_ReturnValue : 1;  // 0x186(0x1)
	char pad_391_1 : 7;  // 0x187(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // 0x187(0x1)
	float CallFunc_GetRelevantAnimTimeRemaining_ReturnValue_4;  // 0x188(0x4)
	char pad_396_1 : 7;  // 0x18C(0x1)
	bool CallFunc_LessEqual_FloatFloat_ReturnValue_2 : 1;  // 0x18C(0x1)
	char pad_397_1 : 7;  // 0x18D(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_2 : 1;  // 0x18D(0x1)
	char pad_398_1 : 7;  // 0x18E(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_3 : 1;  // 0x18E(0x1)
	char pad_399_1 : 7;  // 0x18F(0x1)
	bool CallFunc_BooleanAND_ReturnValue_3 : 1;  // 0x18F(0x1)
	float CallFunc_FInterpTo_ReturnValue_2;  // 0x190(0x4)
	float CallFunc_FMax_ReturnValue;  // 0x194(0x4)
	char pad_408_1 : 7;  // 0x198(0x1)
	bool Temp_bool_IsClosed_Variable : 1;  // 0x198(0x1)
	char pad_409[3];  // 0x199(0x3)
	struct FRotator CallFunc_NormalizedDeltaRotator_ReturnValue;  // 0x19C(0xC)
	float CallFunc_BreakRotator_Roll;  // 0x1A8(0x4)
	float CallFunc_BreakRotator_Pitch;  // 0x1AC(0x4)
	float CallFunc_BreakRotator_Yaw;  // 0x1B0(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue_3;  // 0x1B4(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x1B8(0x4)
	float CallFunc_FClamp_ReturnValue;  // 0x1BC(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_2;  // 0x1C0(0x4)
	struct FRotator CallFunc_MakeRotator_ReturnValue;  // 0x1C4(0xC)
	float CallFunc_Multiply_FloatFloat_ReturnValue_3;  // 0x1D0(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_4;  // 0x1D4(0x4)
	struct FRotator CallFunc_MakeRotator_ReturnValue_2;  // 0x1D8(0xC)
	float CallFunc_FInterpTo_ReturnValue_3;  // 0x1E4(0x4)
	float CallFunc_FInterpTo_ReturnValue_4;  // 0x1E8(0x4)
	float CallFunc_FInterpTo_ReturnValue_5;  // 0x1EC(0x4)

}; 
// Function ABP_Civilian.ABP_Civilian_C.BlueprintUpdateAnimation
// Size: 0x4(Inherited: 0x4) 
struct FBlueprintUpdateAnimation : public FBlueprintUpdateAnimation
{
	float DeltaTimeX;  // 0x0(0x4)

}; 
// Function ABP_Civilian.ABP_Civilian_C.OnAnimationModeChanged
// Size: 0x1(Inherited: 0x1) 
struct FOnAnimationModeChanged : public FOnAnimationModeChanged
{
	uint8_t  LastAnimationMode;  // 0x0(0x1)

}; 
// Function ABP_Civilian.ABP_Civilian_C.OnSettle
// Size: 0x1(Inherited: 0x1) 
struct FOnSettle : public FOnSettle
{
	struct FTigerSettleEvent SettleEvent;  // 0x0(0x1)

}; 
// Function ABP_Civilian.ABP_Civilian_C.StopCapMontage
// Size: 0x1D(Inherited: 0x0) 
struct FStopCapMontage
{
	uint8_t  A;  // 0x0(0x1)
	uint8_t  Temp_byte_Variable;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool Temp_bool_Variable : 1;  // 0x2(0x1)
	char pad_3_1 : 7;  // 0x3(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0x3(0x1)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Temp_bool_Variable_3 : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool Temp_bool_Variable_4 : 1;  // 0x5(0x1)
	char pad_6_1 : 7;  // 0x6(0x1)
	bool Temp_bool_Variable_5 : 1;  // 0x6(0x1)
	char pad_7_1 : 7;  // 0x7(0x1)
	bool Temp_bool_Variable_6 : 1;  // 0x7(0x1)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Temp_bool_Variable_7 : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool Temp_bool_Variable_8 : 1;  // 0x9(0x1)
	char pad_10[6];  // 0xA(0x6)
	struct ATigerNPC* CallFunc_GetOwningNpc_ReturnValue;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_Select_Default : 1;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x19(0x1)
	char pad_26_1 : 7;  // 0x1A(0x1)
	bool CallFunc_Montage_IsPlaying_ReturnValue : 1;  // 0x1A(0x1)
	char pad_27_1 : 7;  // 0x1B(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x1B(0x1)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool CallFunc_BooleanAND_ReturnValue_2 : 1;  // 0x1C(0x1)

}; 
// Function ABP_Civilian.ABP_Civilian_C.AddSets
// Size: 0x8(Inherited: 0x8) 
struct FAddSets : public FAddSets
{
	struct UTigerAnimationSetCollection* SetCollection;  // 0x0(0x8)

}; 
// Function ABP_Civilian.ABP_Civilian_C.OnBumpedByPlayerEvent
// Size: 0x14(Inherited: 0x18) 
struct FOnBumpedByPlayerEvent : public FOnBumpedByPlayerEvent
{
	struct ATigerPlayer* InPlayer;  // 0x0(0x8)
	struct FVector InDirectionToPlayer;  // 0x8(0xC)

}; 
// Function ABP_Civilian.ABP_Civilian_C.OnNpcReactionEvent
// Size: 0x18(Inherited: 0x18) 
struct FOnNpcReactionEvent : public FOnNpcReactionEvent
{
	struct FTigerNpcReactionEvent ReactionEvent;  // 0x0(0x18)

}; 
// Function ABP_Civilian.ABP_Civilian_C.OnFootstep
// Size: 0x8(Inherited: 0x8) 
struct FOnFootstep : public FOnFootstep
{
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bIsLeftFoot : 1;  // 0x0(0x1)
	float FootstepDuration;  // 0x4(0x4)

}; 
// Function ABP_Civilian.ABP_Civilian_C.HandleFootstepSound
// Size: 0x34(Inherited: 0x0) 
struct FHandleFootstepSound
{
	float FootstepDuration;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool LeftFoot : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct ATigerNPC* CallFunc_GetOwningNpc_ReturnValue;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue : 1;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)
	struct FVector CallFunc_GetSocketLocation_ReturnValue;  // 0x14(0xC)
	struct FVector CallFunc_GetSocketLocation_ReturnValue_2;  // 0x20(0xC)
	float CallFunc_GetTimeSeconds_ReturnValue;  // 0x2C(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0x30(0x4)

}; 
// Function ABP_Civilian.ABP_Civilian_C.Facial Animations
// Size: 0x20(Inherited: 0x0) 
struct FFacial Animations
{
	struct FName CallFunc_GetFaceAnimSlotsWithActiveCurves_OutSlot0;  // 0x0(0x8)
	struct FName CallFunc_GetFaceAnimSlotsWithActiveCurves_OutSlot1;  // 0x8(0x8)
	struct FName CallFunc_GetFaceAnimSlotsWithActiveCurves_OutSlot2;  // 0x10(0x8)
	struct FName CallFunc_GetFaceAnimSlotsWithActiveCurves_OutSlot3;  // 0x18(0x8)

}; 
// Function ABP_Civilian.ABP_Civilian_C.AddEmotionalAnimationSet
// Size: 0x51(Inherited: 0x0) 
struct FAddEmotionalAnimationSet
{
	struct UTigerAnimationSetCollection* InSetCollection;  // 0x0(0x8)
	struct UTigerAnimationSetAsset* Temp_object_Variable;  // 0x8(0x8)
	struct UTigerAnimationSetAsset* Temp_object_Variable_2;  // 0x10(0x8)
	struct UTigerAnimationSetAsset* Temp_object_Variable_3;  // 0x18(0x8)
	struct UTigerAnimationSetAsset* Temp_object_Variable_4;  // 0x20(0x8)
	struct UTigerAnimationSetAsset* Temp_object_Variable_5;  // 0x28(0x8)
	struct UTigerAnimationSetAsset* Temp_object_Variable_6;  // 0x30(0x8)
	uint8_t  Temp_byte_Variable;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct ATigerNPC* CallFunc_GetOwningNpc_ReturnValue;  // 0x40(0x8)
	struct UTigerAnimationSetAsset* K2Node_Select_Default;  // 0x48(0x8)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x50(0x1)

}; 
// Function ABP_Civilian.ABP_Civilian_C.PostFootStepAudio
// Size: 0x5D(Inherited: 0x0) 
struct FPostFootStepAudio
{
	struct FDelegate Temp_delegate_Variable;  // 0x0(0x10)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable;  // 0x10(0x10)
	float CallFunc_GetMaxAttenuationRadius_ReturnValue;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)
	struct ATigerPlayer* CallFunc_GetLocalPlayer_ReturnValue;  // 0x28(0x8)
	struct ATigerNPC* CallFunc_GetOwningNpc_ReturnValue;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x38(0x1)
	char pad_57[3];  // 0x39(0x3)
	int32_t CallFunc_PostEvent_ReturnValue;  // 0x3C(0x4)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue;  // 0x40(0xC)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue_2;  // 0x4C(0xC)
	float CallFunc_Vector_Distance_ReturnValue;  // 0x58(0x4)
	char pad_92_1 : 7;  // 0x5C(0x1)
	bool CallFunc_Less_FloatFloat_ReturnValue : 1;  // 0x5C(0x1)

}; 
// Function ABP_Civilian.ABP_Civilian_C.AnimGraph
// Size: 0x10(Inherited: 0x0) 
struct FAnimGraph
{
	struct FPoseLink AnimGraph;  // 0x0(0x10)

}; 
