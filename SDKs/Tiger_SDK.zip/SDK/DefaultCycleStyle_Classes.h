#pragma once 
#include <DefaultCycleStyle_Structs.h>
 
 
 
// BlueprintGeneratedClass DefaultCycleStyle.DefaultCycleStyle_C
// Size: 0x58(Inherited: 0x48) 
struct UDefaultCycleStyle_C : public UTigerWeaponCycleStyle
{
	int32_t DirectionInt;  // 0x48(0x4)
	int32_t OutSlot;  // 0x4C(0x4)
	struct ATigerPlayerController* PlayerController;  // 0x50(0x8)

	uint8_t  DetermineNextWeaponSlot(struct ATigerPlayerController* InPlayerController, uint8_t  InDirection); // Function DefaultCycleStyle.DefaultCycleStyle_C.DetermineNextWeaponSlot
}; 



