#pragma once 
#include <TBFL_Misc_Structs.h>
 
 
 
// BlueprintGeneratedClass TBFL_Misc.TBFL_Misc_C
// Size: 0x28(Inherited: 0x28) 
struct UTBFL_Misc_C : public UBlueprintFunctionLibrary
{

	void OpenTeamMenu(struct ATigerMatchHUD* InMatchHud, struct UObject* __WorldContext); // Function TBFL_Misc.TBFL_Misc_C.OpenTeamMenu
	void CanOpenMainMenu(struct UObject* __WorldContext, bool& bCanOpenMatchMenu); // Function TBFL_Misc.TBFL_Misc_C.CanOpenMainMenu
	void MoveWidgetsFromSideAngle(float InWidgetDistance, float InAngleDegrees, struct UWidget* InTranslationWidget, struct UWidget* InRotationWidget, struct UWidget* InInverseTranslationWidget, struct UObject* __WorldContext); // Function TBFL_Misc.TBFL_Misc_C.MoveWidgetsFromSideAngle
	void ActivateClientAlarmAndReportAction(struct UAkAudioEvent* Event, struct FVector EventLocation, float ActionRange, struct ATigerCharacter* Character, uint8_t  InAction, struct UObject* __WorldContext); // Function TBFL_Misc.TBFL_Misc_C.ActivateClientAlarmAndReportAction
	void ActivateAlarmAndReportAction(struct FVector EventLocation, float ActionRange, struct ATigerCharacter* Character, uint8_t  InAction, struct UObject* __WorldContext); // Function TBFL_Misc.TBFL_Misc_C.ActivateAlarmAndReportAction
}; 



