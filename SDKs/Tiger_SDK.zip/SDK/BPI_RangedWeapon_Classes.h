#pragma once 
#include <BPI_RangedWeapon_Structs.h>
 
 
 
// BlueprintGeneratedClass BPI_RangedWeapon.BPI_RangedWeapon_C
// Size: 0x28(Inherited: 0x28) 
struct UBPI_RangedWeapon_C : public UInterface
{

	void GetRangedWeaponCategory(char ENUM_RangedWeaponCategories& RangedWeaponCategory); // Function BPI_RangedWeapon.BPI_RangedWeapon_C.GetRangedWeaponCategory
}; 



