#pragma once 
#include "SDK.h" 
 
 
// Function ABP_Eyewear.ABP_Eyewear_C.ExecuteUbergraph_ABP_Eyewear
// Size: 0x70(Inherited: 0x0) 
struct FExecuteUbergraph_ABP_Eyewear
{
	int32_t EntryPoint;  // 0x0(0x4)
	struct FVector CallFunc_BreakTransform_Location;  // 0x4(0xC)
	struct FRotator CallFunc_BreakTransform_Rotation;  // 0x10(0xC)
	struct FVector CallFunc_BreakTransform_Scale;  // 0x1C(0xC)
	struct FVector CallFunc_BreakTransform_Location_2;  // 0x28(0xC)
	struct FRotator CallFunc_BreakTransform_Rotation_2;  // 0x34(0xC)
	struct FVector CallFunc_BreakTransform_Scale_2;  // 0x40(0xC)
	struct FVector CallFunc_BreakTransform_Location_3;  // 0x4C(0xC)
	struct FRotator CallFunc_BreakTransform_Rotation_3;  // 0x58(0xC)
	struct FVector CallFunc_BreakTransform_Scale_3;  // 0x64(0xC)

}; 
// Function ABP_Eyewear.ABP_Eyewear_C.AnimGraph
// Size: 0x10(Inherited: 0x0) 
struct FAnimGraph
{
	struct FPoseLink AnimGraph;  // 0x0(0x10)

}; 
