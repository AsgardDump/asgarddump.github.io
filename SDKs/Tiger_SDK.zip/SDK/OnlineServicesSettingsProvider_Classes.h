#pragma once 
#include <OnlineServicesSettingsProvider_Structs.h>
 
 
 
// Class OnlineServicesSettingsProvider.ShOnlineServicesSettings
// Size: 0x1E8(Inherited: 0x38) 
struct UShOnlineServicesSettings : public UDeveloperSettings
{
	char pad_56[24];  // 0x38(0x18)
	struct FString AccountRecoveryUrlProd;  // 0x50(0x10)
	struct FString AccountRecoveryUrlUat;  // 0x60(0x10)
	struct FString AccountRecoveryUrlDev;  // 0x70(0x10)
	struct FString CdnBaseUrlDev;  // 0x80(0x10)
	struct FString CdnBaseUrlUat;  // 0x90(0x10)
	struct FString CdnBaseUrlProd;  // 0xA0(0x10)
	struct FString BaseUrlLocal;  // 0xB0(0x10)
	struct FString BaseUrlDev;  // 0xC0(0x10)
	struct FString BaseUrlMain;  // 0xD0(0x10)
	struct FString BaseUrlStaging;  // 0xE0(0x10)
	struct FString BaseUrlRelease;  // 0xF0(0x10)
	struct FString BaseUrlPs5Submission;  // 0x100(0x10)
	struct FString BaseUrlLive;  // 0x110(0x10)
	struct FString PushBaseUrlLocal;  // 0x120(0x10)
	struct FString PushBaseUrlDev;  // 0x130(0x10)
	struct FString PushBaseUrlMain;  // 0x140(0x10)
	struct FString PushBaseUrlStaging;  // 0x150(0x10)
	struct FString PushBaseUrlRelease;  // 0x160(0x10)
	struct FString PushBaseUrlPs5Submission;  // 0x170(0x10)
	struct FString PushBaseUrlLive;  // 0x180(0x10)
	struct FString OnlineEnvironment;  // 0x190(0x10)
	char pad_416[72];  // 0x1A0(0x48)

}; 



