#pragma once 
#include <ABP_SKM_V_HAIR_57_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass ABP_SKM_V_HAIR_57.ABP_SKM_V_HAIR_56_C
// Size: 0x2770(Inherited: 0x330) 
struct UABP_SKM_V_HAIR_56_C : public UTigerCharacterPoseableMeshAnimInstance
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x330(0x8)
	struct FAnimNode_Root AnimGraphNode_Root;  // 0x338(0x30)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_10;  // 0x368(0x108)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace;  // 0x470(0x20)
	struct FAnimNode_MeshSpaceRefPose AnimGraphNode_MeshRefPose;  // 0x490(0x10)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_9;  // 0x4A0(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_8;  // 0x5A8(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_7;  // 0x6B0(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_6;  // 0x7B8(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_5;  // 0x8C0(0x108)
	char pad_2504[8];  // 0x9C8(0x8)
	struct FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_6;  // 0x9D0(0x440)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_4;  // 0xE10(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_3;  // 0xF18(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_2;  // 0x1020(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone;  // 0x1128(0x108)
	struct FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_5;  // 0x1230(0x440)
	struct FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_4;  // 0x1670(0x440)
	struct FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_3;  // 0x1AB0(0x440)
	struct FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_2;  // 0x1EF0(0x440)
	struct FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics;  // 0x2330(0x440)

	void AnimGraph(struct FPoseLink& AnimGraph); // Function ABP_SKM_V_HAIR_57.ABP_SKM_V_HAIR_56_C.AnimGraph
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_SKM_V_HAIR_56_AnimGraphNode_ModifyBone_9AA714BD481326C9167C56BEABF14EBD(); // Function ABP_SKM_V_HAIR_57.ABP_SKM_V_HAIR_56_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_SKM_V_HAIR_56_AnimGraphNode_ModifyBone_9AA714BD481326C9167C56BEABF14EBD
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_SKM_V_HAIR_56_AnimGraphNode_ModifyBone_9464901341FFF0DEA917429802625F3A(); // Function ABP_SKM_V_HAIR_57.ABP_SKM_V_HAIR_56_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_SKM_V_HAIR_56_AnimGraphNode_ModifyBone_9464901341FFF0DEA917429802625F3A
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_SKM_V_HAIR_56_AnimGraphNode_ModifyBone_2E8DF5E0465A9A8DB0FF90B0E55BE6C3(); // Function ABP_SKM_V_HAIR_57.ABP_SKM_V_HAIR_56_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_SKM_V_HAIR_56_AnimGraphNode_ModifyBone_2E8DF5E0465A9A8DB0FF90B0E55BE6C3
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_SKM_V_HAIR_56_AnimGraphNode_ModifyBone_54677EDF45384422A675CE9679353CED(); // Function ABP_SKM_V_HAIR_57.ABP_SKM_V_HAIR_56_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_SKM_V_HAIR_56_AnimGraphNode_ModifyBone_54677EDF45384422A675CE9679353CED
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_SKM_V_HAIR_56_AnimGraphNode_ModifyBone_38531FBB4427422C12529DA614448C36(); // Function ABP_SKM_V_HAIR_57.ABP_SKM_V_HAIR_56_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_SKM_V_HAIR_56_AnimGraphNode_ModifyBone_38531FBB4427422C12529DA614448C36
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_SKM_V_HAIR_56_AnimGraphNode_ModifyBone_C4B8DA4B4DF44C7487E163B3DD5477C3(); // Function ABP_SKM_V_HAIR_57.ABP_SKM_V_HAIR_56_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_SKM_V_HAIR_56_AnimGraphNode_ModifyBone_C4B8DA4B4DF44C7487E163B3DD5477C3
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_SKM_V_HAIR_56_AnimGraphNode_ModifyBone_8FC96F704C96CF054C05699ED71282B4(); // Function ABP_SKM_V_HAIR_57.ABP_SKM_V_HAIR_56_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_SKM_V_HAIR_56_AnimGraphNode_ModifyBone_8FC96F704C96CF054C05699ED71282B4
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_SKM_V_HAIR_56_AnimGraphNode_ModifyBone_A20DE23A4C24FF7ADC2A67B72EFE3209(); // Function ABP_SKM_V_HAIR_57.ABP_SKM_V_HAIR_56_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_SKM_V_HAIR_56_AnimGraphNode_ModifyBone_A20DE23A4C24FF7ADC2A67B72EFE3209
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_SKM_V_HAIR_56_AnimGraphNode_ModifyBone_B7FEF8F34101E1FDE74C50A20F49B4E5(); // Function ABP_SKM_V_HAIR_57.ABP_SKM_V_HAIR_56_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_SKM_V_HAIR_56_AnimGraphNode_ModifyBone_B7FEF8F34101E1FDE74C50A20F49B4E5
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_SKM_V_HAIR_56_AnimGraphNode_ModifyBone_15F77BEC4E67815D91089081DB930A0B(); // Function ABP_SKM_V_HAIR_57.ABP_SKM_V_HAIR_56_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_SKM_V_HAIR_56_AnimGraphNode_ModifyBone_15F77BEC4E67815D91089081DB930A0B
	void ExecuteUbergraph_ABP_SKM_V_HAIR_57(int32_t EntryPoint); // Function ABP_SKM_V_HAIR_57.ABP_SKM_V_HAIR_56_C.ExecuteUbergraph_ABP_SKM_V_HAIR_57
}; 



