#pragma once 
#include <EOSSDK_Structs.h>
 
 
 
// Class EOSSDK.EOSSdkSettings
// Size: 0x58(Inherited: 0x38) 
struct UEOSSdkSettings : public UDeveloperSettings
{
	struct FString ProductName;  // 0x38(0x10)
	struct FString ProductVersion;  // 0x48(0x10)

}; 



// Class EOSSDK.EOSUserComponent
// Size: 0x158(Inherited: 0xB0) 
struct UEOSUserComponent : public UActorComponent
{
	char pad_176[168];  // 0xB0(0xA8)

	void Server_ReceiveConnectInfo(struct FString InToken, struct FString InID); // Function EOSSDK.EOSUserComponent.Server_ReceiveConnectInfo
	void Server_ReceiveAntiCheatData(struct TArray<char> InByteArray); // Function EOSSDK.EOSUserComponent.Server_ReceiveAntiCheatData
	void Server_EACConnected(bool bInEACConnected); // Function EOSSDK.EOSUserComponent.Server_EACConnected
	void Client_RequestEOSProductUserId(); // Function EOSSDK.EOSUserComponent.Client_RequestEOSProductUserId
	void Client_RequestEACConnectedStatus(); // Function EOSSDK.EOSUserComponent.Client_RequestEACConnectedStatus
	void Client_ReceiveAntiCheatData(struct TArray<char> InByteArray); // Function EOSSDK.EOSUserComponent.Client_ReceiveAntiCheatData
}; 



// Class EOSSDK.EOSPlatformClientSettings
// Size: 0x58(Inherited: 0x38) 
struct UEOSPlatformClientSettings : public UDeveloperSettings
{
	struct FString ClientId;  // 0x38(0x10)
	struct FString ClientSecret;  // 0x48(0x10)

}; 



// Class EOSSDK.EOSPlatformSettings
// Size: 0x78(Inherited: 0x38) 
struct UEOSPlatformSettings : public UDeveloperSettings
{
	struct FString DeploymentId;  // 0x38(0x10)
	struct FString EncryptionKey;  // 0x48(0x10)
	struct FString ProductId;  // 0x58(0x10)
	struct FString SandboxId;  // 0x68(0x10)

}; 



