#pragma once 
#include <SharkPaymentSDK_Structs.h>
 
 
 
// Class SharkPaymentSDK.ShPaymentSettings
// Size: 0xC0(Inherited: 0x38) 
struct UShPaymentSettings : public UDeveloperSettings
{
	struct FString IdcInfo;  // 0x38(0x10)
	struct FString OfferId;  // 0x48(0x10)
	struct FString ZoneId;  // 0x58(0x10)
	struct FString GoodsZoneId;  // 0x68(0x10)
	struct FString ProvideType;  // 0x78(0x10)
	char pad_136_1 : 7;  // 0x88(0x1)
	bool LogEnabled : 1;  // 0x88(0x1)
	char pad_137[7];  // 0x89(0x7)
	struct FString StoreServiceUri;  // 0x90(0x10)
	struct FString ClientId;  // 0xA0(0x10)
	struct FString ClientScope;  // 0xB0(0x10)

}; 



// Class SharkPaymentSDK.ShStoreService
// Size: 0x90(Inherited: 0x28) 
struct UShStoreService : public UObject
{
	char pad_40[104];  // 0x28(0x68)

}; 



