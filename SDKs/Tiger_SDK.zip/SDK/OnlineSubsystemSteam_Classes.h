#pragma once 
#include <OnlineSubsystemSteam_Structs.h>
 
 
 
// Class OnlineSubsystemSteam.SteamAuthComponentModuleInterface
// Size: 0x28(Inherited: 0x28) 
struct USteamAuthComponentModuleInterface : public UHandlerComponentFactory
{

}; 



// Class OnlineSubsystemSteam.SteamNetConnection
// Size: 0x1B98(Inherited: 0x1B90) 
struct USteamNetConnection : public UIpConnection
{
	char pad_7056_1 : 7;  // 0x1B90(0x1)
	bool bIsPassthrough : 1;  // 0x1B90(0x1)
	char pad_7057[7];  // 0x1B91(0x7)

}; 



// Class OnlineSubsystemSteam.SteamNetDriver
// Size: 0x7C0(Inherited: 0x7B8) 
struct USteamNetDriver : public UIpNetDriver
{
	char pad_1976[8];  // 0x7B8(0x8)

}; 



