#pragma once 
#include <PropertyAccess_Structs.h>
 
 
 
// Class PropertyAccess.PropertyAccess
// Size: 0x28(Inherited: 0x28) 
struct UPropertyAccess : public UInterface
{

}; 



// Class PropertyAccess.PropertyEventSubscriber
// Size: 0x28(Inherited: 0x28) 
struct UPropertyEventSubscriber : public UInterface
{

}; 



// Class PropertyAccess.PropertyEventBroadcaster
// Size: 0x28(Inherited: 0x28) 
struct UPropertyEventBroadcaster : public UInterface
{

}; 



