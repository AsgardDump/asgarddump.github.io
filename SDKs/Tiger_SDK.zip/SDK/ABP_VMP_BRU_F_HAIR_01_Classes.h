#pragma once 
#include <ABP_VMP_BRU_F_HAIR_01_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass ABP_VMP_BRU_F_HAIR_01.ABP_VMP_BRU_F_HAIR_01_C
// Size: 0x2540(Inherited: 0x2C0) 
struct UABP_VMP_BRU_F_HAIR_01_C : public UAnimInstance
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x2C0(0x8)
	char pad_712[8];  // 0x2C8(0x8)
	struct FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_8;  // 0x2D0(0x440)
	struct FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_7;  // 0x710(0x440)
	struct FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_6;  // 0xB50(0x440)
	struct FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_5;  // 0xF90(0x440)
	struct FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_4;  // 0x13D0(0x440)
	struct FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_3;  // 0x1810(0x440)
	struct FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_2;  // 0x1C50(0x440)
	struct FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics;  // 0x2090(0x440)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace;  // 0x24D0(0x20)
	struct FAnimNode_Root AnimGraphNode_Root;  // 0x24F0(0x30)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace;  // 0x2520(0x20)

	void AnimGraph(struct FPoseLink& AnimGraph); // Function ABP_VMP_BRU_F_HAIR_01.ABP_VMP_BRU_F_HAIR_01_C.AnimGraph
	void ExecuteUbergraph_ABP_VMP_BRU_F_HAIR_01(int32_t EntryPoint); // Function ABP_VMP_BRU_F_HAIR_01.ABP_VMP_BRU_F_HAIR_01_C.ExecuteUbergraph_ABP_VMP_BRU_F_HAIR_01
}; 



