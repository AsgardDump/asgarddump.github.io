#pragma once 
#include "SDK.h" 
 
 
// ScriptStruct OnlineSubsystemTiger.TigerMatchedPush
// Size: 0x4(Inherited: 0x0) 
struct FTigerMatchedPush
{
	uint32_t MatchRequestId;  // 0x0(0x4)

}; 
// ScriptStruct OnlineSubsystemTiger.TigerHeartbeatPush
// Size: 0x1(Inherited: 0x0) 
struct FTigerHeartbeatPush
{
	char pad_0[1];  // 0x0(0x1)

}; 
// ScriptStruct OnlineSubsystemTiger.TigerMatchmakingPush
// Size: 0x48(Inherited: 0x0) 
struct FTigerMatchmakingPush
{
	uint8_t  Result;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FString Host;  // 0x8(0x10)
	int32_t Port;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct FString GameSessionId;  // 0x20(0x10)
	struct FString GameSessionToken;  // 0x30(0x10)
	uint32_t MatchRequestId;  // 0x40(0x4)
	char pad_68[4];  // 0x44(0x4)

}; 
// ScriptStruct OnlineSubsystemTiger.Request_StartMatchmaking
// Size: 0x58(Inherited: 0x0) 
struct FRequest_StartMatchmaking
{
	struct FString SESSIONTYPE;  // 0x0(0x10)
	struct FString DsVersion;  // 0x10(0x10)
	struct FString MATCHMAKINGTOKEN;  // 0x20(0x10)
	struct FString REGIONPINGS;  // 0x30(0x10)
	int32_t MATCHMAKINGPLATFORM;  // 0x40(0x4)
	uint32_t MatchRequestId;  // 0x44(0x4)
	struct FString GAMEMODEID;  // 0x48(0x10)

}; 
// ScriptStruct OnlineSubsystemTiger.Request_CancelMatchmakingV2
// Size: 0x38(Inherited: 0x0) 
struct FRequest_CancelMatchmakingV2
{
	struct FString SESSIONTYPE;  // 0x0(0x10)
	struct FString DsVersion;  // 0x10(0x10)
	struct FString GAMEMODEID;  // 0x20(0x10)
	uint32_t MatchRequestId;  // 0x30(0x4)
	char pad_52[4];  // 0x34(0x4)

}; 
// ScriptStruct OnlineSubsystemTiger.Response_StartMatchmaking
// Size: 0x18(Inherited: 0x0) 
struct FResponse_StartMatchmaking
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool OK : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FString Error;  // 0x8(0x10)

}; 
// ScriptStruct OnlineSubsystemTiger.Request_CancelMatchmaking
// Size: 0x28(Inherited: 0x0) 
struct FRequest_CancelMatchmaking
{
	struct FString SESSIONTYPE;  // 0x0(0x10)
	struct FString DsVersion;  // 0x10(0x10)
	uint32_t MatchRequestId;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)

}; 
// ScriptStruct OnlineSubsystemTiger.ResponseEnvelope
// Size: 0x18(Inherited: 0x0) 
struct FResponseEnvelope
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool OK : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FString Error;  // 0x8(0x10)

}; 
