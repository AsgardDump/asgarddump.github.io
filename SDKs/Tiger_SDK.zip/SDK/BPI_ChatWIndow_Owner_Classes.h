#pragma once 
#include <BPI_ChatWIndow_Owner_Structs.h>
 
 
 
// BlueprintGeneratedClass BPI_ChatWIndow_Owner.BPI_ChatWIndow_Owner_C
// Size: 0x28(Inherited: 0x28) 
struct UBPI_ChatWIndow_Owner_C : public UInterface
{

	void OnMessageInput(struct FText MessageText, bool OnlyGroup); // Function BPI_ChatWIndow_Owner.BPI_ChatWIndow_Owner_C.OnMessageInput
}; 



