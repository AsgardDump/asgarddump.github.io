#pragma once 
#include "SDK.h" 
 
 
// Function TBFL_SpreadPatternHelpers.TBFL_SpreadPatternHelpers_C.RotateDirectionRight
// Size: 0x48(Inherited: 0x0) 
struct FRotateDirectionRight
{
	struct FVector InDirection;  // 0x0(0xC)
	float Degrees;  // 0xC(0x4)
	struct UObject* __WorldContext;  // 0x10(0x8)
	struct FVector OutDirection;  // 0x18(0xC)
	struct FRotator CallFunc_Conv_VectorToRotator_ReturnValue;  // 0x24(0xC)
	struct FVector CallFunc_GetUpVector_ReturnValue;  // 0x30(0xC)
	struct FVector CallFunc_RotateAngleAxis_ReturnValue;  // 0x3C(0xC)

}; 
// Function TBFL_SpreadPatternHelpers.TBFL_SpreadPatternHelpers_C.DirectionInArc
// Size: 0x50(Inherited: 0x0) 
struct FDirectionInArc
{
	float MinRotationDegrees;  // 0x0(0x4)
	float MaxRotationDegrees;  // 0x4(0x4)
	float ProgressZeroToOne;  // 0x8(0x4)
	struct FVector AimDirection;  // 0xC(0xC)
	float RadiusDegrees;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct UObject* __WorldContext;  // 0x20(0x8)
	struct FVector Point;  // 0x28(0xC)
	float CallFunc_Lerp_ReturnValue;  // 0x34(0x4)
	struct FVector CallFunc_RotateDirectionUp_OutDirection;  // 0x38(0xC)
	struct FVector CallFunc_RotateAngleAxis_ReturnValue;  // 0x44(0xC)

}; 
// Function TBFL_SpreadPatternHelpers.TBFL_SpreadPatternHelpers_C.RotateDirectionDown
// Size: 0x34(Inherited: 0x0) 
struct FRotateDirectionDown
{
	struct FVector InDirection;  // 0x0(0xC)
	float Degrees;  // 0xC(0x4)
	struct UObject* __WorldContext;  // 0x10(0x8)
	struct FVector OutDirection;  // 0x18(0xC)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x24(0x4)
	struct FVector CallFunc_RotateDirectionUp_OutDirection;  // 0x28(0xC)

}; 
// Function TBFL_SpreadPatternHelpers.TBFL_SpreadPatternHelpers_C.DirectionInCircle
// Size: 0x3C(Inherited: 0x0) 
struct FDirectionInCircle
{
	struct FVector AimDirection;  // 0x0(0xC)
	float ProgressionZeroToOne;  // 0xC(0x4)
	float RadiusDegrees;  // 0x10(0x4)
	float RotationOffset;  // 0x14(0x4)
	struct UObject* __WorldContext;  // 0x18(0x8)
	struct FVector Point;  // 0x20(0xC)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0x2C(0x4)
	struct FVector CallFunc_DirectionInArc_Point;  // 0x30(0xC)

}; 
// Function TBFL_SpreadPatternHelpers.TBFL_SpreadPatternHelpers_C.DirectionAlongLine
// Size: 0x54(Inherited: 0x0) 
struct FDirectionAlongLine
{
	float BeginYaw;  // 0x0(0x4)
	float EndYaw;  // 0x4(0x4)
	float BeginPitch;  // 0x8(0x4)
	float EndPitch;  // 0xC(0x4)
	float Progress;  // 0x10(0x4)
	struct FVector AimDirection;  // 0x14(0xC)
	struct UObject* __WorldContext;  // 0x20(0x8)
	struct FVector Direction;  // 0x28(0xC)
	float CallFunc_Lerp_ReturnValue;  // 0x34(0x4)
	float CallFunc_Lerp_ReturnValue_2;  // 0x38(0x4)
	struct FVector CallFunc_RotateDirectionUp_OutDirection;  // 0x3C(0xC)
	struct FVector CallFunc_RotateDirectionRight_OutDirection;  // 0x48(0xC)

}; 
// Function TBFL_SpreadPatternHelpers.TBFL_SpreadPatternHelpers_C.GetBulletProgressInSectionFloat
// Size: 0x2F(Inherited: 0x0) 
struct FGetBulletProgressInSectionFloat
{
	float SectionStart;  // 0x0(0x4)
	float SectionEnd;  // 0x4(0x4)
	float BulletProgress;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct UObject* __WorldContext;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool IsInSection : 1;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)
	float ProgressInSection;  // 0x1C(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue;  // 0x20(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue_2;  // 0x24(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x28(0x4)
	char pad_44_1 : 7;  // 0x2C(0x1)
	bool CallFunc_Less_FloatFloat_ReturnValue : 1;  // 0x2C(0x1)
	char pad_45_1 : 7;  // 0x2D(0x1)
	bool CallFunc_GreaterEqual_FloatFloat_ReturnValue : 1;  // 0x2D(0x1)
	char pad_46_1 : 7;  // 0x2E(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x2E(0x1)

}; 
// Function TBFL_SpreadPatternHelpers.TBFL_SpreadPatternHelpers_C.GetBulletProgress
// Size: 0x2C(Inherited: 0x0) 
struct FGetBulletProgress
{
	int32_t BulletIndex;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UTigerRangedWeaponComponent* RangedWeaponComponent;  // 0x8(0x8)
	struct UObject* __WorldContext;  // 0x10(0x8)
	float BulletProgress;  // 0x18(0x4)
	float CallFunc_Conv_IntToFloat_ReturnValue;  // 0x1C(0x4)
	int32_t CallFunc_GetBulletsPerFire_BulletCount;  // 0x20(0x4)
	float CallFunc_Conv_IntToFloat_ReturnValue_2;  // 0x24(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x28(0x4)

}; 
// Function TBFL_SpreadPatternHelpers.TBFL_SpreadPatternHelpers_C.RotateDirectionUp
// Size: 0x4C(Inherited: 0x0) 
struct FRotateDirectionUp
{
	struct FVector InDirection;  // 0x0(0xC)
	float Degrees;  // 0xC(0x4)
	struct UObject* __WorldContext;  // 0x10(0x8)
	struct FVector OutDirection;  // 0x18(0xC)
	struct FRotator CallFunc_Conv_VectorToRotator_ReturnValue;  // 0x24(0xC)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x30(0x4)
	struct FVector CallFunc_GetRightVector_ReturnValue;  // 0x34(0xC)
	struct FVector CallFunc_RotateAngleAxis_ReturnValue;  // 0x40(0xC)

}; 
// Function TBFL_SpreadPatternHelpers.TBFL_SpreadPatternHelpers_C.GetBulletProgressInSection
// Size: 0x37(Inherited: 0x0) 
struct FGetBulletProgressInSection
{
	int32_t BulletSectionStart;  // 0x0(0x4)
	int32_t BulletSectionEnd;  // 0x4(0x4)
	int32_t BulletIndex;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct UObject* __WorldContext;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool IsInSection : 1;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)
	float Progress;  // 0x1C(0x4)
	int32_t CallFunc_Subtract_IntInt_ReturnValue;  // 0x20(0x4)
	int32_t CallFunc_Subtract_IntInt_ReturnValue_2;  // 0x24(0x4)
	float CallFunc_Conv_IntToFloat_ReturnValue;  // 0x28(0x4)
	float CallFunc_Conv_IntToFloat_ReturnValue_2;  // 0x2C(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x30(0x4)
	char pad_52_1 : 7;  // 0x34(0x1)
	bool CallFunc_GreaterEqual_FloatFloat_ReturnValue : 1;  // 0x34(0x1)
	char pad_53_1 : 7;  // 0x35(0x1)
	bool CallFunc_LessEqual_FloatFloat_ReturnValue : 1;  // 0x35(0x1)
	char pad_54_1 : 7;  // 0x36(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x36(0x1)

}; 
// Function TBFL_SpreadPatternHelpers.TBFL_SpreadPatternHelpers_C.RotateDirectionLeft
// Size: 0x34(Inherited: 0x0) 
struct FRotateDirectionLeft
{
	struct FVector InDirection;  // 0x0(0xC)
	float Degrees;  // 0xC(0x4)
	struct UObject* __WorldContext;  // 0x10(0x8)
	struct FVector OutDirection;  // 0x18(0xC)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x24(0x4)
	struct FVector CallFunc_RotateDirectionRight_OutDirection;  // 0x28(0xC)

}; 
// Function TBFL_SpreadPatternHelpers.TBFL_SpreadPatternHelpers_C.GetBulletsPerFire
// Size: 0xF0(Inherited: 0x0) 
struct FGetBulletsPerFire
{
	struct UTigerRangedWeaponComponent* RangedWeaponComponent;  // 0x0(0x8)
	struct UObject* __WorldContext;  // 0x8(0x8)
	int32_t BulletCount;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct FTigerFireSettings CallFunc_GetCurrentFireSettings_ReturnValue;  // 0x18(0xD8)

}; 
// Function TBFL_SpreadPatternHelpers.TBFL_SpreadPatternHelpers_C.GetSpreadRange
// Size: 0x40(Inherited: 0x0) 
struct FGetSpreadRange
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ShouldBeInsideSpreadRadius : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct UTigerRangedWeaponComponent* RangedWeaponComponent;  // 0x8(0x8)
	struct UObject* __WorldContext;  // 0x10(0x8)
	float NegativeSpreadInDegrees;  // 0x18(0x4)
	float PositiveSpreadInDegrees;  // 0x1C(0x4)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool Temp_bool_Variable : 1;  // 0x20(0x1)
	char pad_33[3];  // 0x21(0x3)
	float CallFunc_GetCurrentSpread_ReturnValue;  // 0x24(0x4)
	float CallFunc_RadiansToDegrees_ReturnValue;  // 0x28(0x4)
	float Temp_float_Variable;  // 0x2C(0x4)
	float Temp_float_Variable_2;  // 0x30(0x4)
	float K2Node_Select_Default;  // 0x34(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x38(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_2;  // 0x3C(0x4)

}; 
// Function TBFL_SpreadPatternHelpers.TBFL_SpreadPatternHelpers_C.AddNoise
// Size: 0x3C(Inherited: 0x0) 
struct FAddNoise
{
	struct FVector InDirection;  // 0x0(0xC)
	float MagnitudeInDegrees;  // 0xC(0x4)
	struct FTigerRangedRandomState RandomState;  // 0x10(0x8)
	struct UObject* __WorldContext;  // 0x18(0x8)
	struct FVector OutDirection;  // 0x20(0xC)
	float CallFunc_DegreesToRadians_ReturnValue;  // 0x2C(0x4)
	struct FVector CallFunc_VRandCone_ReturnValue;  // 0x30(0xC)

}; 
// Function TBFL_SpreadPatternHelpers.TBFL_SpreadPatternHelpers_C.GetPositionInGrid
// Size: 0x34(Inherited: 0x0) 
struct FGetPositionInGrid
{
	int32_t Index;  // 0x0(0x4)
	int32_t Width;  // 0x4(0x4)
	int32_t Height;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct UObject* __WorldContext;  // 0x10(0x8)
	int32_t X;  // 0x18(0x4)
	int32_t Y;  // 0x1C(0x4)
	int32_t CallFunc_Multiply_IntInt_ReturnValue;  // 0x20(0x4)
	int32_t CallFunc_Percent_IntInt_ReturnValue;  // 0x24(0x4)
	int32_t CallFunc_Percent_IntInt_ReturnValue_2;  // 0x28(0x4)
	int32_t CallFunc_Divide_IntInt_ReturnValue;  // 0x2C(0x4)
	int32_t CallFunc_Clamp_ReturnValue;  // 0x30(0x4)

}; 
