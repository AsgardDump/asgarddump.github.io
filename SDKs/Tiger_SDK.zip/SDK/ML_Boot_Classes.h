#pragma once 
#include <ML_Boot_Structs.h>
 
 
 
// BlueprintGeneratedClass ML_Boot.ML_Boot_C
// Size: 0x230(Inherited: 0x230) 
struct AML_Boot_C : public ALevelScriptActor
{

}; 



