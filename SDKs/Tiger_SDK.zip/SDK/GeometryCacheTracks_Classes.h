#pragma once 
#include <GeometryCacheTracks_Structs.h>
 
 
 
// Class GeometryCacheTracks.MovieSceneGeometryCacheSection
// Size: 0x128(Inherited: 0xE8) 
struct UMovieSceneGeometryCacheSection : public UMovieSceneSection
{
	struct FMovieSceneGeometryCacheParams Params;  // 0xE8(0x40)

}; 



// Class GeometryCacheTracks.MovieSceneGeometryCacheTrack
// Size: 0x90(Inherited: 0x78) 
struct UMovieSceneGeometryCacheTrack : public UMovieSceneNameableTrack
{
	char pad_120[8];  // 0x78(0x8)
	struct TArray<struct UMovieSceneSection*> AnimationSections;  // 0x80(0x10)

}; 



