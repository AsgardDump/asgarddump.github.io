#pragma once 
#include <AM_Tailwhip_Structs.h>
 
 
 
// BlueprintGeneratedClass AM_Tailwhip.AM_Tailwhip_C
// Size: 0x620(Inherited: 0x620) 
struct UAM_Tailwhip_C : public UME_GameplayAbilitySharkMontage
{

}; 



