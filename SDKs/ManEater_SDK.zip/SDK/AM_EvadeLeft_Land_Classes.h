#pragma once 
#include <AM_EvadeLeft_Land_Structs.h>
 
 
 
// BlueprintGeneratedClass AM_EvadeLeft_Land.AM_EvadeLeft_Land_C
// Size: 0x620(Inherited: 0x620) 
struct UAM_EvadeLeft_Land_C : public UME_GameplayAbility_SharkEvade
{

}; 



