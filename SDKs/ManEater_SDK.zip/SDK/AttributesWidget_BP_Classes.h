#pragma once 
#include <AttributesWidget_BP_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass AttributesWidget_BP.AttributesWidget_BP_C
// Size: 0x290(Inherited: 0x260) 
struct UAttributesWidget_BP_C : public UAttributesWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x260(0x8)
	struct UAttributeItem_BP_C* AttributeRatingWidget1;  // 0x268(0x8)
	struct UAttributeItem_BP_C* AttributeRatingWidget2;  // 0x270(0x8)
	struct UAttributeItem_BP_C* AttributeRatingWidget3;  // 0x278(0x8)
	struct UAttributeItem_BP_C* AttributeRatingWidget4;  // 0x280(0x8)
	struct UAttributeItem_BP_C* AttributeRatingWidget5;  // 0x288(0x8)

	void CalculateDamageRating(float& CurrentPercent, float& DeltaPercent); // Function AttributesWidget_BP.AttributesWidget_BP_C.CalculateDamageRating
	void CalculateMassRating(float& CurrentPercent, float& DeltaPercent); // Function AttributesWidget_BP.AttributesWidget_BP_C.CalculateMassRating
	void CalculateSpeedRating(float& CurrentPercent, float& DeltaPercent); // Function AttributesWidget_BP.AttributesWidget_BP_C.CalculateSpeedRating
	void CalculateDefenseRating(float& CurrentPercent, float& DeltaPercent); // Function AttributesWidget_BP.AttributesWidget_BP_C.CalculateDefenseRating
	void CalculateHealthRating(float& CurrentPercent, float& DeltaPercent); // Function AttributesWidget_BP.AttributesWidget_BP_C.CalculateHealthRating
	void Construct(); // Function AttributesWidget_BP.AttributesWidget_BP_C.Construct
	void UpdateAttributes(); // Function AttributesWidget_BP.AttributesWidget_BP_C.UpdateAttributes
	void ExecuteUbergraph_AttributesWidget_BP(int32_t EntryPoint); // Function AttributesWidget_BP.AttributesWidget_BP_C.ExecuteUbergraph_AttributesWidget_BP
}; 



