#include "SDK.h" 
 
 
void UAgeTierInfographicWidget::Construct(){

	static UObject* p_Construct = UObject::FindObject<UFunction>("Function AgeTierInfographic_BP.AgeTierInfographic_BP_C.Construct");

	struct {
	} parms;


	ProcessEvent(p_Construct, &parms);
}

void UAgeTierInfographicWidget::ExecuteUbergraph_AgeTierInfographic_BP(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph_AgeTierInfographic_BP = UObject::FindObject<UFunction>("Function AgeTierInfographic_BP.AgeTierInfographic_BP_C.ExecuteUbergraph_AgeTierInfographic_BP");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph_AgeTierInfographic_BP, &parms);
}

