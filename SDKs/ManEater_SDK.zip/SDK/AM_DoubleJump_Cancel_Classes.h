#pragma once 
#include <AM_DoubleJump_Cancel_Structs.h>
 
 
 
// BlueprintGeneratedClass AM_DoubleJump_Cancel.AM_DoubleJump_Cancel_C
// Size: 0x5E0(Inherited: 0x5E0) 
struct UAM_DoubleJump_Cancel_C : public UME_GameplayAbility_Montage
{

}; 



