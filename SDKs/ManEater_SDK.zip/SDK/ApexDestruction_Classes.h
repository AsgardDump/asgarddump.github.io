#pragma once 
#include <ApexDestruction_Structs.h>
 
 
 
// Class ApexDestruction.DestructibleActor
// Size: 0x238(Inherited: 0x220) 
struct ADestructibleActor : public AActor
{
	struct UDestructibleComponent* DestructibleComponent;  // 0x220(0x8)
	struct FMulticastInlineDelegate OnActorFracture;  // 0x228(0x10)

}; 



// Class ApexDestruction.DestructibleComponent
// Size: 0x730(Inherited: 0x650) 
struct UDestructibleComponent : public USkinnedMeshComponent
{
	char bFractureEffectOverride : 1;  // 0x650(0x1)
	char pad_1616_1 : 7;  // 0x650(0x1)
	char pad_1617[8];  // 0x651(0x8)
	struct TArray<struct FFractureEffect> FractureEffects;  // 0x658(0x10)
	char pad_1640_1 : 7;  // 0x668(0x1)
	bool bEnableHardSleeping : 1;  // 0x668(0x1)
	char pad_1641[3];  // 0x669(0x3)
	float LargeChunkThreshold;  // 0x66C(0x4)
	char pad_1648[16];  // 0x670(0x10)
	struct FMulticastInlineDelegate OnComponentFracture;  // 0x680(0x10)
	char pad_1680[160];  // 0x690(0xA0)

	void SetDestructibleMesh(struct UDestructibleMesh* NewMesh); // Function ApexDestruction.DestructibleComponent.SetDestructibleMesh
	struct UDestructibleMesh* GetDestructibleMesh(); // Function ApexDestruction.DestructibleComponent.GetDestructibleMesh
	void ApplyRadiusDamage(float BaseDamage, struct FVector& HurtOrigin, float DamageRadius, float ImpulseStrength, bool bFullDamage); // Function ApexDestruction.DestructibleComponent.ApplyRadiusDamage
	void ApplyDamage(float DamageAmount, struct FVector& HitLocation, struct FVector& ImpulseDir, float ImpulseStrength); // Function ApexDestruction.DestructibleComponent.ApplyDamage
}; 



// Class ApexDestruction.DestructibleFractureSettings
// Size: 0xB8(Inherited: 0x28) 
struct UDestructibleFractureSettings : public UObject
{
	int32_t CellSiteCount;  // 0x28(0x4)
	struct FFractureMaterial FractureMaterialDesc;  // 0x2C(0x24)
	int32_t RandomSeed;  // 0x50(0x4)
	char pad_84[4];  // 0x54(0x4)
	struct TArray<struct FVector> VoronoiSites;  // 0x58(0x10)
	int32_t OriginalSubmeshCount;  // 0x68(0x4)
	char pad_108[4];  // 0x6C(0x4)
	struct TArray<struct UMaterialInterface*> Materials;  // 0x70(0x10)
	struct TArray<struct FDestructibleChunkParameters> ChunkParameters;  // 0x80(0x10)
	char pad_144[40];  // 0x90(0x28)

}; 



// Class ApexDestruction.DestructibleMesh
// Size: 0x420(Inherited: 0x380) 
struct UDestructibleMesh : public USkeletalMesh
{
	struct FDestructibleParameters DefaultDestructibleParameters;  // 0x380(0x88)
	struct TArray<struct FFractureEffect> FractureEffects;  // 0x408(0x10)
	char pad_1048[8];  // 0x418(0x8)

}; 



