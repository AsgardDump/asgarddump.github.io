#pragma once 
#include <AlertEvent_Death_Structs.h>
 
 
 
// BlueprintGeneratedClass AlertEvent_Death.AlertEvent_Death_C
// Size: 0xA0(Inherited: 0xA0) 
struct UAlertEvent_Death_C : public UME_AlertEvent_Witness
{

}; 



