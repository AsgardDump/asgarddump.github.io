#pragma once 
#include <AM_ChunkSequence_OnLand_Structs.h>
 
 
 
// BlueprintGeneratedClass AM_ChunkSequence_OnLand.AM_ChunkSequence_OnLand_C
// Size: 0x628(Inherited: 0x628) 
struct UAM_ChunkSequence_OnLand_C : public UAM_ChunkSequence_C
{

}; 



