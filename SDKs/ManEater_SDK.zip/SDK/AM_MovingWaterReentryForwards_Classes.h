#pragma once 
#include <AM_MovingWaterReentryForwards_Structs.h>
 
 
 
// BlueprintGeneratedClass AM_MovingWaterReentryForwards.AM_MovingWaterReentryForwards_C
// Size: 0x620(Inherited: 0x620) 
struct UAM_MovingWaterReentryForwards_C : public UME_GameplayAbilitySharkMontage
{

}; 



