#pragma once 
#include <AIController_GreatWhite_BP_Structs.h>
 
 
 
// BlueprintGeneratedClass AIController_GreatWhite_BP.AIController_GreatWhite_BP_C
// Size: 0x7D0(Inherited: 0x7C8) 
struct AAIController_GreatWhite_BP_C : public AAIController_Hostile_Base_BP_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x7C8(0x8)

	void ReceiveBeginPlay(); // Function AIController_GreatWhite_BP.AIController_GreatWhite_BP_C.ReceiveBeginPlay
	void ThreatStateHasChanged_Event(char EAIThreatAlertState NewAlertState, struct AActor* InstigatingActor); // Function AIController_GreatWhite_BP.AIController_GreatWhite_BP_C.ThreatStateHasChanged_Event
	void ExecuteUbergraph_AIController_GreatWhite_BP(int32_t EntryPoint); // Function AIController_GreatWhite_BP.AIController_GreatWhite_BP_C.ExecuteUbergraph_AIController_GreatWhite_BP
}; 



