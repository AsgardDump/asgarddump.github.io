#pragma once 
#include <BP_AIDirector_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_AIDirector.BP_AIDirector_C
// Size: 0x758(Inherited: 0x750) 
struct ABP_AIDirector_C : public AME_AIDirector
{
	struct USceneComponent* DefaultSceneRoot;  // 0x750(0x8)

}; 



