#pragma once 
#include <AM_EvadeDown_Structs.h>
 
 
 
// BlueprintGeneratedClass AM_EvadeDown.AM_EvadeDown_C
// Size: 0x620(Inherited: 0x620) 
struct UAM_EvadeDown_C : public UME_GameplayAbility_SharkEvade
{

}; 



