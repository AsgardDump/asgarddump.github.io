#include "SDK.h" 
 
 
void UAttributesWidget::CalculateDamageRating(float& CurrentPercent, float& DeltaPercent){

	static UObject* p_CalculateDamageRating = UObject::FindObject<UFunction>("Function AttributesWidget_BP.AttributesWidget_BP_C.CalculateDamageRating");

	struct {
		float& CurrentPercent;
		float& DeltaPercent;
	} parms;

	parms.CurrentPercent = CurrentPercent;
	parms.DeltaPercent = DeltaPercent;

	ProcessEvent(p_CalculateDamageRating, &parms);
}

void UAttributesWidget::CalculateMassRating(float& CurrentPercent, float& DeltaPercent){

	static UObject* p_CalculateMassRating = UObject::FindObject<UFunction>("Function AttributesWidget_BP.AttributesWidget_BP_C.CalculateMassRating");

	struct {
		float& CurrentPercent;
		float& DeltaPercent;
	} parms;

	parms.CurrentPercent = CurrentPercent;
	parms.DeltaPercent = DeltaPercent;

	ProcessEvent(p_CalculateMassRating, &parms);
}

void UAttributesWidget::CalculateSpeedRating(float& CurrentPercent, float& DeltaPercent){

	static UObject* p_CalculateSpeedRating = UObject::FindObject<UFunction>("Function AttributesWidget_BP.AttributesWidget_BP_C.CalculateSpeedRating");

	struct {
		float& CurrentPercent;
		float& DeltaPercent;
	} parms;

	parms.CurrentPercent = CurrentPercent;
	parms.DeltaPercent = DeltaPercent;

	ProcessEvent(p_CalculateSpeedRating, &parms);
}

void UAttributesWidget::CalculateDefenseRating(float& CurrentPercent, float& DeltaPercent){

	static UObject* p_CalculateDefenseRating = UObject::FindObject<UFunction>("Function AttributesWidget_BP.AttributesWidget_BP_C.CalculateDefenseRating");

	struct {
		float& CurrentPercent;
		float& DeltaPercent;
	} parms;

	parms.CurrentPercent = CurrentPercent;
	parms.DeltaPercent = DeltaPercent;

	ProcessEvent(p_CalculateDefenseRating, &parms);
}

void UAttributesWidget::CalculateHealthRating(float& CurrentPercent, float& DeltaPercent){

	static UObject* p_CalculateHealthRating = UObject::FindObject<UFunction>("Function AttributesWidget_BP.AttributesWidget_BP_C.CalculateHealthRating");

	struct {
		float& CurrentPercent;
		float& DeltaPercent;
	} parms;

	parms.CurrentPercent = CurrentPercent;
	parms.DeltaPercent = DeltaPercent;

	ProcessEvent(p_CalculateHealthRating, &parms);
}

void UAttributesWidget::Construct(){

	static UObject* p_Construct = UObject::FindObject<UFunction>("Function AttributesWidget_BP.AttributesWidget_BP_C.Construct");

	struct {
	} parms;


	ProcessEvent(p_Construct, &parms);
}

void UAttributesWidget::UpdateAttributes(){

	static UObject* p_UpdateAttributes = UObject::FindObject<UFunction>("Function AttributesWidget_BP.AttributesWidget_BP_C.UpdateAttributes");

	struct {
	} parms;


	ProcessEvent(p_UpdateAttributes, &parms);
}

void UAttributesWidget::ExecuteUbergraph_AttributesWidget_BP(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph_AttributesWidget_BP = UObject::FindObject<UFunction>("Function AttributesWidget_BP.AttributesWidget_BP_C.ExecuteUbergraph_AttributesWidget_BP");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph_AttributesWidget_BP, &parms);
}

