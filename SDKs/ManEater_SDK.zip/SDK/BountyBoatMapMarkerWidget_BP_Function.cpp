#include "SDK.h" 
 
 
void UBountyBoatMapMarkerWidget::Construct(){

	static UObject* p_Construct = UObject::FindObject<UFunction>("Function BountyBoatMapMarkerWidget_BP.BountyBoatMapMarkerWidget_BP_C.Construct");

	struct {
	} parms;


	ProcessEvent(p_Construct, &parms);
}

void UBountyBoatMapMarkerWidget::ExecuteUbergraph_BountyBoatMapMarkerWidget_BP(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph_BountyBoatMapMarkerWidget_BP = UObject::FindObject<UFunction>("Function BountyBoatMapMarkerWidget_BP.BountyBoatMapMarkerWidget_BP_C.ExecuteUbergraph_BountyBoatMapMarkerWidget_BP");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph_BountyBoatMapMarkerWidget_BP, &parms);
}

