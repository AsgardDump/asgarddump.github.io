#pragma once 
#include <AM_StartThrashRight_Structs.h>
 
 
 
// BlueprintGeneratedClass AM_StartThrashRight.AM_StartThrashRight_C
// Size: 0x620(Inherited: 0x620) 
struct UAM_StartThrashRight_C : public UAM_StartThrashDown_C
{

}; 



