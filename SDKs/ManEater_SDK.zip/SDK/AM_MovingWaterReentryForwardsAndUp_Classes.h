#pragma once 
#include <AM_MovingWaterReentryForwardsAndUp_Structs.h>
 
 
 
// BlueprintGeneratedClass AM_MovingWaterReentryForwardsAndUp.AM_MovingWaterReentryForwardsAndUp_C
// Size: 0x620(Inherited: 0x620) 
struct UAM_MovingWaterReentryForwardsAndUp_C : public UME_GameplayAbilitySharkMontage
{

}; 



