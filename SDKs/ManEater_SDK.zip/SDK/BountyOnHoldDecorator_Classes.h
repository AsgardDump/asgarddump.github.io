#pragma once 
#include <BountyOnHoldDecorator_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass BountyOnHoldDecorator.BountyOnHoldDecorator_C
// Size: 0x2B8(Inherited: 0x288) 
struct UBountyOnHoldDecorator_C : public UBaseObjectiveDecorator
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x288(0x8)
	struct UImage* backgroundglow;  // 0x290(0x8)
	struct UTextBlock* InfamyRankText;  // 0x298(0x8)
	struct UImage* leftline;  // 0x2A0(0x8)
	struct UImage* ObjectiveIcon;  // 0x2A8(0x8)
	struct UImage* rightline;  // 0x2B0(0x8)

	void Construct(); // Function BountyOnHoldDecorator.BountyOnHoldDecorator_C.Construct
	void ExecuteUbergraph_BountyOnHoldDecorator(int32_t EntryPoint); // Function BountyOnHoldDecorator.BountyOnHoldDecorator_C.ExecuteUbergraph_BountyOnHoldDecorator
}; 



