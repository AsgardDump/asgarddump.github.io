#pragma once 
#include <AIController_Turtle_BP_Structs.h>
 
 
 
// BlueprintGeneratedClass AIController_Turtle_BP.AIController_Turtle_BP_C
// Size: 0x7C8(Inherited: 0x7C8) 
struct AAIController_Turtle_BP_C : public AAIController_NonHostile_Base_BP_C
{

}; 



