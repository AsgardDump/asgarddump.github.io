#pragma once 
#include <AM_ChunkSequence_Structs.h>
 
 
 
// BlueprintGeneratedClass AM_ChunkSequence.AM_ChunkSequence_C
// Size: 0x628(Inherited: 0x620) 
struct UAM_ChunkSequence_C : public UME_GameplayAbilitySharkMontage
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x620(0x8)

	void MontageEnded(struct UAnimMontage* Montage, bool bInterrupted); // Function AM_ChunkSequence.AM_ChunkSequence_C.MontageEnded
	void ExecuteUbergraph_AM_ChunkSequence(int32_t EntryPoint); // Function AM_ChunkSequence.AM_ChunkSequence_C.ExecuteUbergraph_AM_ChunkSequence
}; 



