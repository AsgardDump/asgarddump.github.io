#include "SDK.h" 
 
 
void UME_GameplayAbility_SharkEvade::K2_CommitExecute(){

	static UObject* p_K2_CommitExecute = UObject::FindObject<UFunction>("Function AM_Submerge.AM_Submerge_C.K2_CommitExecute");

	struct {
	} parms;


	ProcessEvent(p_K2_CommitExecute, &parms);
}

void UME_GameplayAbility_SharkEvade::ExecuteUbergraph_AM_Submerge(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph_AM_Submerge = UObject::FindObject<UFunction>("Function AM_Submerge.AM_Submerge_C.ExecuteUbergraph_AM_Submerge");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph_AM_Submerge, &parms);
}

