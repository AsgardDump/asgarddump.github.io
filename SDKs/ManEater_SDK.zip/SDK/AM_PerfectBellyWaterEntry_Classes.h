#pragma once 
#include <AM_PerfectBellyWaterEntry_Structs.h>
 
 
 
// BlueprintGeneratedClass AM_PerfectBellyWaterEntry.AM_PerfectBellyWaterEntry_C
// Size: 0x620(Inherited: 0x620) 
struct UAM_PerfectBellyWaterEntry_C : public UME_GameplayAbilitySharkMontage
{

}; 



