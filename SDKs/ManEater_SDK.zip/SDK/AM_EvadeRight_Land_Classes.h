#pragma once 
#include <AM_EvadeRight_Land_Structs.h>
 
 
 
// BlueprintGeneratedClass AM_EvadeRight_Land.AM_EvadeRight_Land_C
// Size: 0x620(Inherited: 0x620) 
struct UAM_EvadeRight_Land_C : public UME_GameplayAbility_SharkEvade
{

}; 



