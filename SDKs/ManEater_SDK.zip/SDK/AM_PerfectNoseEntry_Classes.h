#pragma once 
#include <AM_PerfectNoseEntry_Structs.h>
 
 
 
// BlueprintGeneratedClass AM_PerfectNoseEntry.AM_PerfectNoseEntry_C
// Size: 0x620(Inherited: 0x620) 
struct UAM_PerfectNoseEntry_C : public UME_GameplayAbilitySharkMontage
{

}; 



