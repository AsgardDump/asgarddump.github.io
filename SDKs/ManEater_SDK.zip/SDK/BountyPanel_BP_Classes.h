#pragma once 
#include <BountyPanel_BP_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass BountyPanel_BP.BountyPanel_BP_C
// Size: 0x464(Inherited: 0x408) 
struct UBountyPanel_BP_C : public UBountyPanel
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x408(0x8)
	struct UWidgetAnimation* Idle;  // 0x410(0x8)
	struct UImage* BG;  // 0x418(0x8)
	struct UImage* BorderLeft;  // 0x420(0x8)
	struct UImage* BorderRight;  // 0x428(0x8)
	struct UImage* InfamyBackground;  // 0x430(0x8)
	struct UImage* RankIconBG;  // 0x438(0x8)
	struct UImage* Strip;  // 0x440(0x8)
	int32_t NumLevels_1;  // 0x448(0x4)
	char pad_1100[4];  // 0x44C(0x4)
	struct TArray<struct UInfamyTierIcon_BP_C*> TierIcons_1;  // 0x450(0x10)
	int32_t CurrentLevelIdx;  // 0x460(0x4)

	void PreConstruct(bool IsDesignTime); // Function BountyPanel_BP.BountyPanel_BP_C.PreConstruct
	void Construct(); // Function BountyPanel_BP.BountyPanel_BP_C.Construct
	void ExecuteUbergraph_BountyPanel_BP(int32_t EntryPoint); // Function BountyPanel_BP.BountyPanel_BP_C.ExecuteUbergraph_BountyPanel_BP
}; 



