#pragma once 
#include <AM_EvadeRight_Reversed_Structs.h>
 
 
 
// BlueprintGeneratedClass AM_EvadeRight_Reversed.AM_EvadeRight_Reversed_C
// Size: 0x620(Inherited: 0x620) 
struct UAM_EvadeRight_Reversed_C : public UAM_EvadeRight_C
{

}; 



