#pragma once 
#include <AM_Jump_Knifing_Structs.h>
 
 
 
// BlueprintGeneratedClass AM_Jump_Knifing.AM_Jump_Knifing_C
// Size: 0x628(Inherited: 0x620) 
struct UAM_Jump_Knifing_C : public UME_GameplayAbility_SharkEvade
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x620(0x8)

	void K2_CommitExecute(); // Function AM_Jump_Knifing.AM_Jump_Knifing_C.K2_CommitExecute
	void ExecuteUbergraph_AM_Jump_Knifing(int32_t EntryPoint); // Function AM_Jump_Knifing.AM_Jump_Knifing_C.ExecuteUbergraph_AM_Jump_Knifing
}; 



