#include "SDK.h" 
 
 
void UTwBaseWidget::ProcessTagChange(){

	static UObject* p_ProcessTagChange = UObject::FindObject<UFunction>("Function BoostMeter_BP.BoostMeter_BP_C.ProcessTagChange");

	struct {
	} parms;


	ProcessEvent(p_ProcessTagChange, &parms);
}

void UTwBaseWidget::UpdateLocalTagContainer(bool bAdded, struct FGameplayTagContainer TagContainer, float TagDuration){

	static UObject* p_UpdateLocalTagContainer = UObject::FindObject<UFunction>("Function BoostMeter_BP.BoostMeter_BP_C.UpdateLocalTagContainer");

	struct {
		bool bAdded;
		struct FGameplayTagContainer TagContainer;
		float TagDuration;
	} parms;

	parms.bAdded = bAdded;
	parms.TagContainer = TagContainer;
	parms.TagDuration = TagDuration;

	ProcessEvent(p_UpdateLocalTagContainer, &parms);
}

void UTwBaseWidget::UnsubscribeFromEvents_BP(struct AHUD* HUD){

	static UObject* p_UnsubscribeFromEvents_BP = UObject::FindObject<UFunction>("Function BoostMeter_BP.BoostMeter_BP_C.UnsubscribeFromEvents_BP");

	struct {
		struct AHUD* HUD;
	} parms;

	parms.HUD = HUD;

	ProcessEvent(p_UnsubscribeFromEvents_BP, &parms);
}

void UTwBaseWidget::GameplayTagAdded(struct FGameplayTagContainer TagsAdded, float TagDuration){

	static UObject* p_GameplayTagAdded = UObject::FindObject<UFunction>("Function BoostMeter_BP.BoostMeter_BP_C.GameplayTagAdded");

	struct {
		struct FGameplayTagContainer TagsAdded;
		float TagDuration;
	} parms;

	parms.TagsAdded = TagsAdded;
	parms.TagDuration = TagDuration;

	ProcessEvent(p_GameplayTagAdded, &parms);
}

void UTwBaseWidget::SubscribeToEvents_BP(struct AHUD* HUD){

	static UObject* p_SubscribeToEvents_BP = UObject::FindObject<UFunction>("Function BoostMeter_BP.BoostMeter_BP_C.SubscribeToEvents_BP");

	struct {
		struct AHUD* HUD;
	} parms;

	parms.HUD = HUD;

	ProcessEvent(p_SubscribeToEvents_BP, &parms);
}

void UTwBaseWidget::GameplayTagRemoved(struct FGameplayTagContainer TagsAdded){

	static UObject* p_GameplayTagRemoved = UObject::FindObject<UFunction>("Function BoostMeter_BP.BoostMeter_BP_C.GameplayTagRemoved");

	struct {
		struct FGameplayTagContainer TagsAdded;
	} parms;

	parms.TagsAdded = TagsAdded;

	ProcessEvent(p_GameplayTagRemoved, &parms);
}

void UTwBaseWidget::Construct(){

	static UObject* p_Construct = UObject::FindObject<UFunction>("Function BoostMeter_BP.BoostMeter_BP_C.Construct");

	struct {
	} parms;


	ProcessEvent(p_Construct, &parms);
}

void UTwBaseWidget::ExecuteUbergraph_BoostMeter_BP(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph_BoostMeter_BP = UObject::FindObject<UFunction>("Function BoostMeter_BP.BoostMeter_BP_C.ExecuteUbergraph_BoostMeter_BP");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph_BoostMeter_BP, &parms);
}

