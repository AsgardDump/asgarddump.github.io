#pragma once 
#include "SDK.h" 
 
 
// UserDefinedStruct AudioTagBindingToEnum_ST.AudioTagBindingToEnum_ST
// Size: 0x1(Inherited: 0x0) 
struct FAudioTagBindingToEnum_ST
{
	char AudioTag_Enum AudioEnum_2_97F22B674718921B1603378A7885D4D3;  // 0x0(0x1)

}; 
