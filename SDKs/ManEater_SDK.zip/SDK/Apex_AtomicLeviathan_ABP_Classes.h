#pragma once 
#include <Apex_AtomicLeviathan_ABP_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass Apex_AtomicLeviathan_ABP.Apex_AtomicLeviathan_ABP_C
// Size: 0x5C8C(Inherited: 0x5C8C) 
struct UApex_AtomicLeviathan_ABP_C : public UWildlife_Base_ABP_C
{

}; 



