#pragma once 
#include <AM_StationaryWaterReentryUpwards_Structs.h>
 
 
 
// BlueprintGeneratedClass AM_StationaryWaterReentryUpwards.AM_StationaryWaterReentryUpwards_C
// Size: 0x620(Inherited: 0x620) 
struct UAM_StationaryWaterReentryUpwards_C : public UME_GameplayAbilitySharkMontage
{

}; 



