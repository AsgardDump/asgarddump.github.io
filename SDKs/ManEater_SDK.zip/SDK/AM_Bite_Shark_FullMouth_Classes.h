#pragma once 
#include <AM_Bite_Shark_FullMouth_Structs.h>
 
 
 
// BlueprintGeneratedClass AM_Bite_Shark_FullMouth.AM_Bite_Shark_FullMouth_C
// Size: 0x620(Inherited: 0x620) 
struct UAM_Bite_Shark_FullMouth_C : public UME_GameplayAbilitySharkMontage
{

}; 



