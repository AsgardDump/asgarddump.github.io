#include "SDK.h" 
 
 
void USkinnedMeshComponent::SetDestructibleMesh(struct UDestructibleMesh* NewMesh){

	static UObject* p_SetDestructibleMesh = UObject::FindObject<UFunction>("Function ApexDestruction.DestructibleComponent.SetDestructibleMesh");

	struct {
		struct UDestructibleMesh* NewMesh;
	} parms;

	parms.NewMesh = NewMesh;

	ProcessEvent(p_SetDestructibleMesh, &parms);
}

struct UDestructibleMesh* USkinnedMeshComponent::GetDestructibleMesh(){

	static UObject* p_GetDestructibleMesh = UObject::FindObject<UFunction>("Function ApexDestruction.DestructibleComponent.GetDestructibleMesh");

	struct {
		struct UDestructibleMesh* return_value;
	} parms;


	ProcessEvent(p_GetDestructibleMesh, &parms);
	return parms.return_value;
}

void USkinnedMeshComponent::ApplyRadiusDamage(float BaseDamage, struct FVector& HurtOrigin, float DamageRadius, float ImpulseStrength, bool bFullDamage){

	static UObject* p_ApplyRadiusDamage = UObject::FindObject<UFunction>("Function ApexDestruction.DestructibleComponent.ApplyRadiusDamage");

	struct {
		float BaseDamage;
		struct FVector& HurtOrigin;
		float DamageRadius;
		float ImpulseStrength;
		bool bFullDamage;
	} parms;

	parms.BaseDamage = BaseDamage;
	parms.HurtOrigin = HurtOrigin;
	parms.DamageRadius = DamageRadius;
	parms.ImpulseStrength = ImpulseStrength;
	parms.bFullDamage = bFullDamage;

	ProcessEvent(p_ApplyRadiusDamage, &parms);
}

void USkinnedMeshComponent::ApplyDamage(float DamageAmount, struct FVector& HitLocation, struct FVector& ImpulseDir, float ImpulseStrength){

	static UObject* p_ApplyDamage = UObject::FindObject<UFunction>("Function ApexDestruction.DestructibleComponent.ApplyDamage");

	struct {
		float DamageAmount;
		struct FVector& HitLocation;
		struct FVector& ImpulseDir;
		float ImpulseStrength;
	} parms;

	parms.DamageAmount = DamageAmount;
	parms.HitLocation = HitLocation;
	parms.ImpulseDir = ImpulseDir;
	parms.ImpulseStrength = ImpulseStrength;

	ProcessEvent(p_ApplyDamage, &parms);
}

