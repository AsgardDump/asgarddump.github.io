#pragma once 
#include <AM_EvadeUp_Structs.h>
 
 
 
// BlueprintGeneratedClass AM_EvadeUp.AM_EvadeUp_C
// Size: 0x620(Inherited: 0x620) 
struct UAM_EvadeUp_C : public UME_GameplayAbility_SharkEvade
{

}; 



