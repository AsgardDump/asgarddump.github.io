#pragma once 
#include <AM_MovingWaterReentryBackwardsAndUp_Structs.h>
 
 
 
// BlueprintGeneratedClass AM_MovingWaterReentryBackwardsAndUp.AM_MovingWaterReentryBackwardsAndUp_C
// Size: 0x620(Inherited: 0x620) 
struct UAM_MovingWaterReentryBackwardsAndUp_C : public UME_GameplayAbilitySharkMontage
{

}; 



