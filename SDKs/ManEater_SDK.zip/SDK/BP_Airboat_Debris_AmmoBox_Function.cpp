#include "SDK.h" 
 
 
int32_t ABP_VehicleDebris_C::GetSizeLevel(struct AME_AnimalCharacter* GrabbingAnimal){

	static UObject* p_GetSizeLevel = UObject::FindObject<UFunction>("Function BP_Airboat_Debris_AmmoBox.BP_Airboat_Debris_AmmoBox_C.GetSizeLevel");

	struct {
		struct AME_AnimalCharacter* GrabbingAnimal;
		int32_t return_value;
	} parms;

	parms.GrabbingAnimal = GrabbingAnimal;

	ProcessEvent(p_GetSizeLevel, &parms);
	return parms.return_value;
}

