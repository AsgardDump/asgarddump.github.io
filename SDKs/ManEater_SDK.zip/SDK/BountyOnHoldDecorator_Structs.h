#pragma once 
#include "SDK.h" 
 
 
// Function BountyOnHoldDecorator.BountyOnHoldDecorator_C.ExecuteUbergraph_BountyOnHoldDecorator
// Size: 0x30(Inherited: 0x0) 
struct FExecuteUbergraph_BountyOnHoldDecorator
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AME_BountyManager* CallFunc_GetBountyManager_ReturnValue;  // 0x8(0x8)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct FText CallFunc_Conv_IntToText_ReturnValue;  // 0x18(0x18)

}; 
