#pragma once 
#include <AM_KillSequence_Structs.h>
 
 
 
// BlueprintGeneratedClass AM_KillSequence.AM_KillSequence_C
// Size: 0x640(Inherited: 0x638) 
struct UAM_KillSequence_C : public UME_GameplayAbility_KillSequence
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x638(0x8)

	void MontageEnded(struct UAnimMontage* Montage, bool bInterrupted); // Function AM_KillSequence.AM_KillSequence_C.MontageEnded
	void ExecuteUbergraph_AM_KillSequence(int32_t EntryPoint); // Function AM_KillSequence.AM_KillSequence_C.ExecuteUbergraph_AM_KillSequence
}; 



