#pragma once 
#include <AM_MovingWaterReentryDownwards_Structs.h>
 
 
 
// BlueprintGeneratedClass AM_MovingWaterReentryDownwards.AM_MovingWaterReentryDownwards_C
// Size: 0x620(Inherited: 0x620) 
struct UAM_MovingWaterReentryDownwards_C : public UME_GameplayAbilitySharkMontage
{

}; 



