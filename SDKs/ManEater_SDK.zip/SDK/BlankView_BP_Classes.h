#pragma once 
#include <BlankView_BP_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass BlankView_BP.BlankView_BP_C
// Size: 0x2A8(Inherited: 0x298) 
struct UBlankView_BP_C : public UTwBaseView
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x298(0x8)
	struct USubtitleWidget_C* SubtitleWidget;  // 0x2A0(0x8)

	bool DoesRequireInputUIMode(); // Function BlankView_BP.BlankView_BP_C.DoesRequireInputUIMode
	void SubscribeToEvents_BP(struct AHUD* HUD); // Function BlankView_BP.BlankView_BP_C.SubscribeToEvents_BP
	void ExecuteUbergraph_BlankView_BP(int32_t EntryPoint); // Function BlankView_BP.BlankView_BP_C.ExecuteUbergraph_BlankView_BP
}; 



