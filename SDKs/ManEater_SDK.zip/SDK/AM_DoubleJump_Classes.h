#pragma once 
#include <AM_DoubleJump_Structs.h>
 
 
 
// BlueprintGeneratedClass AM_DoubleJump.AM_DoubleJump_C
// Size: 0x638(Inherited: 0x638) 
struct UAM_DoubleJump_C : public UME_GameplayAbility_SharkAirLunge
{

}; 



