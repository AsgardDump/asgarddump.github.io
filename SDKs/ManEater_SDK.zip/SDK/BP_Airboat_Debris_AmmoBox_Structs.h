#pragma once 
#include "SDK.h" 
 
 
// Function BP_Airboat_Debris_AmmoBox.BP_Airboat_Debris_AmmoBox_C.GetSizeLevel
// Size: 0xC(Inherited: 0x0) 
struct FGetSizeLevel
{
	struct AME_AnimalCharacter* GrabbingAnimal;  // 0x0(0x8)
	int32_t ReturnValue;  // 0x8(0x4)

}; 
