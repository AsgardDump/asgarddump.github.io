#pragma once 
#include <BountyManager_BP_Structs.h>
 
 
 
// BlueprintGeneratedClass BountyManager_BP.BountyManager_BP_C
// Size: 0x63C(Inherited: 0x628) 
struct ABountyManager_BP_C : public AME_BountyManager
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x628(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x630(0x8)
	int32_t Base Max Num Active Divers;  // 0x638(0x4)

	void Infamy Rank Up(int32_t Rank); // Function BountyManager_BP.BountyManager_BP_C.Infamy Rank Up
	void Bounty Beginning(); // Function BountyManager_BP.BountyManager_BP_C.Bounty Beginning
	void Bounty Ending(); // Function BountyManager_BP.BountyManager_BP_C.Bounty Ending
	void ReceiveBeginPlay(); // Function BountyManager_BP.BountyManager_BP_C.ReceiveBeginPlay
	void ExecuteUbergraph_BountyManager_BP(int32_t EntryPoint); // Function BountyManager_BP.BountyManager_BP_C.ExecuteUbergraph_BountyManager_BP
}; 



