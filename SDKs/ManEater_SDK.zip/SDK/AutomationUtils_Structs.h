#pragma once 
#include "SDK.h" 
 
 
// Function AutomationUtils.AutomationUtilsBlueprintLibrary.TakeGameplayAutomationScreenshot
// Size: 0x28(Inherited: 0x0) 
struct FTakeGameplayAutomationScreenshot
{
	struct FString ScreenshotName;  // 0x0(0x10)
	float MaxGlobalError;  // 0x10(0x4)
	float MaxLocalError;  // 0x14(0x4)
	struct FString MapNameOverride;  // 0x18(0x10)

}; 
