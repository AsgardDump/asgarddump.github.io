#pragma once 
#include <AM_Atomic_Body_Activate_T2_Structs.h>
 
 
 
// BlueprintGeneratedClass AM_Atomic_Body_Activate_T2.AM_Atomic_Body_Activate_T2_C
// Size: 0x5E0(Inherited: 0x5E0) 
struct UAM_Atomic_Body_Activate_T2_C : public UME_GameplayAbility_Montage
{

}; 



