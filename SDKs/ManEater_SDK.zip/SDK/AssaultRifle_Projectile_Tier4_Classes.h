#pragma once 
#include <AssaultRifle_Projectile_Tier4_Structs.h>
 
 
 
// BlueprintGeneratedClass AssaultRifle_Projectile_Tier4.AssaultRifle_Projectile_Tier4_C
// Size: 0x270(Inherited: 0x270) 
struct AAssaultRifle_Projectile_Tier4_C : public AAssaultRifle_Projectile_Tier3_C
{

}; 



