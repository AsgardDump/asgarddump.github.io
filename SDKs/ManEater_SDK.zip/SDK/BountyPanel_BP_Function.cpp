#include "SDK.h" 
 
 
void UBountyPanel::PreConstruct(bool IsDesignTime){

	static UObject* p_PreConstruct = UObject::FindObject<UFunction>("Function BountyPanel_BP.BountyPanel_BP_C.PreConstruct");

	struct {
		bool IsDesignTime;
	} parms;

	parms.IsDesignTime = IsDesignTime;

	ProcessEvent(p_PreConstruct, &parms);
}

void UBountyPanel::Construct(){

	static UObject* p_Construct = UObject::FindObject<UFunction>("Function BountyPanel_BP.BountyPanel_BP_C.Construct");

	struct {
	} parms;


	ProcessEvent(p_Construct, &parms);
}

void UBountyPanel::ExecuteUbergraph_BountyPanel_BP(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph_BountyPanel_BP = UObject::FindObject<UFunction>("Function BountyPanel_BP.BountyPanel_BP_C.ExecuteUbergraph_BountyPanel_BP");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph_BountyPanel_BP, &parms);
}

