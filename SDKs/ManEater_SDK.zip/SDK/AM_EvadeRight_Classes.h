#pragma once 
#include <AM_EvadeRight_Structs.h>
 
 
 
// BlueprintGeneratedClass AM_EvadeRight.AM_EvadeRight_C
// Size: 0x620(Inherited: 0x620) 
struct UAM_EvadeRight_C : public UME_GameplayAbility_SharkEvade
{

}; 



