#pragma once 
#include <AM_StationaryWaterReentryBackwards_Structs.h>
 
 
 
// BlueprintGeneratedClass AM_StationaryWaterReentryBackwards.AM_StationaryWaterReentryBackwards_C
// Size: 0x620(Inherited: 0x620) 
struct UAM_StationaryWaterReentryBackwards_C : public UME_GameplayAbilitySharkMontage
{

}; 



