#pragma once 
#include "SDK.h" 
 
 
// Function Basic_Spline.Basic_Spline_C.GenerateLights
// Size: 0xE4(Inherited: 0x0) 
struct FGenerateLights
{
	int32_t Temp_int_Array_Index_Variable;  // 0x0(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x4(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x8(0x4)
	int32_t Temp_int_Array_Index_Variable_2;  // 0xC(0x4)
	float CallFunc_RandomFloatInRange_ReturnValue;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct FString CallFunc_Conv_FloatToString_ReturnValue;  // 0x18(0x10)
	struct FName CallFunc_Conv_StringToName_ReturnValue;  // 0x28(0x8)
	struct FString CallFunc_GetObjectName_ReturnValue;  // 0x30(0x10)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool CallFunc_IsValidClass_ReturnValue : 1;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0x48(0x10)
	int32_t Temp_int_Loop_Counter_Variable_2;  // 0x58(0x4)
	char pad_92[4];  // 0x5C(0x4)
	struct FTransform CallFunc_Array_Get_Item;  // 0x60(0x30)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x90(0x4)
	char pad_148_1 : 7;  // 0x94(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x94(0x1)
	char pad_149[3];  // 0x95(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0x98(0x4)
	int32_t CallFunc_Array_Length_ReturnValue_2;  // 0x9C(0x4)
	struct USplineMeshComponent* CallFunc_Array_Get_Item_2;  // 0xA0(0x8)
	char pad_168_1 : 7;  // 0xA8(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_2 : 1;  // 0xA8(0x1)
	char pad_169_1 : 7;  // 0xA9(0x1)
	bool CallFunc_DoesSocketExist_ReturnValue : 1;  // 0xA9(0x1)
	char pad_170[6];  // 0xAA(0x6)
	struct FTransform CallFunc_GetSocketTransform_ReturnValue;  // 0xB0(0x30)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0xE0(0x4)

}; 
// Function Basic_Spline.Basic_Spline_C.ExecuteUbergraph_Basic_Spline
// Size: 0x4(Inherited: 0x0) 
struct FExecuteUbergraph_Basic_Spline
{
	int32_t EntryPoint;  // 0x0(0x4)

}; 
// Function Basic_Spline.Basic_Spline_C.TurnSpawnedLightsOn
// Size: 0x41(Inherited: 0x0) 
struct FTurnSpawnedLightsOn
{
	int32_t Temp_int_Array_Index_Variable;  // 0x0(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x4(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct TArray<struct AActor*> CallFunc_GetAllActorsWithTag_OutActors;  // 0x10(0x10)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)
	struct AActor* CallFunc_Array_Get_Item;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)
	struct ALight* K2Node_DynamicCast_AsLight;  // 0x38(0x8)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x40(0x1)

}; 
// Function Basic_Spline.Basic_Spline_C.UserConstructionScript
// Size: 0xF9(Inherited: 0x0) 
struct FUserConstructionScript : public FUserConstructionScript
{
	float CallFunc_Multiply_IntFloat_ReturnValue;  // 0x0(0x4)
	int32_t Temp_int_Variable;  // 0x4(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x8(0x4)
	float CallFunc_FClamp_ReturnValue;  // 0xC(0x4)
	struct FVector CallFunc_MakeVector_ReturnValue;  // 0x10(0xC)
	char pad_28[4];  // 0x1C(0x4)
	struct UStaticMesh* CallFunc_Array_Get_Item;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool CallFunc_SetStaticMesh_ReturnValue : 1;  // 0x28(0x1)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool CallFunc_Array_IsValidIndex_ReturnValue : 1;  // 0x29(0x1)
	char pad_42_1 : 7;  // 0x2A(0x1)
	bool CallFunc_Array_IsValidIndex_ReturnValue_2 : 1;  // 0x2A(0x1)
	char pad_43[1];  // 0x2B(0x1)
	int32_t CallFunc_Subtract_IntInt_ReturnValue;  // 0x2C(0x4)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_LessEqual_IntInt_ReturnValue : 1;  // 0x30(0x1)
	char pad_49[15];  // 0x31(0xF)
	struct FTransform CallFunc_K2_GetComponentToWorld_ReturnValue;  // 0x40(0x30)
	struct FVector CallFunc_BreakTransform_Location;  // 0x70(0xC)
	struct FRotator CallFunc_BreakTransform_Rotation;  // 0x7C(0xC)
	struct FVector CallFunc_BreakTransform_Scale;  // 0x88(0xC)
	float CallFunc_GetSplineLength_ReturnValue;  // 0x94(0x4)
	struct FVector CallFunc_Add_VectorFloat_ReturnValue;  // 0x98(0xC)
	char pad_164[12];  // 0xA4(0xC)
	struct FTransform CallFunc_MakeTransform_ReturnValue;  // 0xB0(0x30)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0xE0(0x4)
	char pad_228[4];  // 0xE4(0x4)
	struct USplineMeshComponent* CallFunc_AddComponent_ReturnValue;  // 0xE8(0x8)
	int32_t CallFunc_Round_ReturnValue;  // 0xF0(0x4)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0xF4(0x4)
	char pad_248_1 : 7;  // 0xF8(0x1)
	bool CallFunc_K2_AttachToComponent_ReturnValue : 1;  // 0xF8(0x1)

}; 
// Function Basic_Spline.Basic_Spline_C.UpdateMesh
// Size: 0x14C(Inherited: 0x0) 
struct FUpdateMesh
{
	int32_t MeshIndex;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct USplineMeshComponent* CurrentMesh;  // 0x8(0x8)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x10(0x4)
	float CallFunc_Lerp_ReturnValue;  // 0x14(0x4)
	struct FVector2D CallFunc_MakeVector2D_ReturnValue;  // 0x18(0x8)
	float CallFunc_Divide_FloatFloat_ReturnValue_2;  // 0x20(0x4)
	float CallFunc_Lerp_ReturnValue_2;  // 0x24(0x4)
	struct FVector2D CallFunc_MakeVector2D_ReturnValue_2;  // 0x28(0x8)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x30(0x4)
	float CallFunc_Conv_IntToFloat_ReturnValue;  // 0x34(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x38(0x4)
	float CallFunc_Conv_IntToFloat_ReturnValue_2;  // 0x3C(0x4)
	struct FVector CallFunc_GetTangentAtDistanceAlongSpline_ReturnValue;  // 0x40(0xC)
	float CallFunc_Multiply_FloatFloat_ReturnValue_2;  // 0x4C(0x4)
	struct FVector CallFunc_Normal_ReturnValue;  // 0x50(0xC)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue;  // 0x5C(0xC)
	char pad_104[8];  // 0x68(0x8)
	struct FTransform CallFunc_GetTransformAtDistanceAlongSpline_ReturnValue;  // 0x70(0x30)
	struct FVector CallFunc_BreakTransform_Location;  // 0xA0(0xC)
	struct FRotator CallFunc_BreakTransform_Rotation;  // 0xAC(0xC)
	struct FVector CallFunc_BreakTransform_Scale;  // 0xB8(0xC)
	struct FVector CallFunc_GetTangentAtDistanceAlongSpline_ReturnValue_2;  // 0xC4(0xC)
	struct FTransform CallFunc_GetTransformAtDistanceAlongSpline_ReturnValue_2;  // 0xD0(0x30)
	struct FVector CallFunc_Normal_ReturnValue_2;  // 0x100(0xC)
	struct FVector CallFunc_BreakTransform_Location_2;  // 0x10C(0xC)
	struct FRotator CallFunc_BreakTransform_Rotation_2;  // 0x118(0xC)
	struct FVector CallFunc_BreakTransform_Scale_2;  // 0x124(0xC)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue_2;  // 0x130(0xC)
	float CallFunc_Multiply_FloatFloat_ReturnValue_3;  // 0x13C(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_4;  // 0x140(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue_3;  // 0x144(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue_4;  // 0x148(0x4)

}; 
// Function Basic_Spline.Basic_Spline_C.DestroyLights
// Size: 0x31(Inherited: 0x0) 
struct FDestroyLights
{
	int32_t Temp_int_Array_Index_Variable;  // 0x0(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x4(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct TArray<struct AActor*> CallFunc_GetAllActorsWithTag_OutActors;  // 0x10(0x10)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)
	struct AActor* CallFunc_Array_Get_Item;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x30(0x1)

}; 
// Function Basic_Spline.Basic_Spline_C.ManualDestroyLights
// Size: 0x31(Inherited: 0x0) 
struct FManualDestroyLights
{
	int32_t Temp_int_Array_Index_Variable;  // 0x0(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x4(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct TArray<struct AActor*> CallFunc_GetAllActorsWithTag_OutActors;  // 0x10(0x10)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)
	struct AActor* CallFunc_Array_Get_Item;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x30(0x1)

}; 
// Function Basic_Spline.Basic_Spline_C.TurnSpawnedLightsOff
// Size: 0x41(Inherited: 0x0) 
struct FTurnSpawnedLightsOff
{
	int32_t Temp_int_Array_Index_Variable;  // 0x0(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x4(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct TArray<struct AActor*> CallFunc_GetAllActorsWithTag_OutActors;  // 0x10(0x10)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)
	struct AActor* CallFunc_Array_Get_Item;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)
	struct ALight* K2Node_DynamicCast_AsLight;  // 0x38(0x8)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x40(0x1)

}; 
// Function Basic_Spline.Basic_Spline_C.SpawnLightAtLocation
// Size: 0x84(Inherited: 0x0) 
struct FSpawnLightAtLocation
{
	ALight* LightInformation;  // 0x0(0x8)
	char pad_8[8];  // 0x8(0x8)
	struct FTransform Transform;  // 0x10(0x30)
	struct AActor* StaticMesh;  // 0x40(0x8)
	struct FName CustomTag;  // 0x48(0x8)
	struct FName SocketName;  // 0x50(0x8)
	struct AActor* CallFunc_BeginDeferredActorSpawnFromClass_ReturnValue;  // 0x58(0x8)
	struct ALight* CallFunc_FinishSpawningActor_ReturnValue;  // 0x60(0x8)
	struct TArray<struct FName> K2Node_MakeArray_Array;  // 0x68(0x10)
	struct ALight* Temp_object_Variable;  // 0x78(0x8)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0x80(0x4)

}; 
