#include "SDK.h" 
 
 
void UBaseObjectiveDecorator::Construct(){

	static UObject* p_Construct = UObject::FindObject<UFunction>("Function BountyOnHoldDecorator.BountyOnHoldDecorator_C.Construct");

	struct {
	} parms;


	ProcessEvent(p_Construct, &parms);
}

void UBaseObjectiveDecorator::ExecuteUbergraph_BountyOnHoldDecorator(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph_BountyOnHoldDecorator = UObject::FindObject<UFunction>("Function BountyOnHoldDecorator.BountyOnHoldDecorator_C.ExecuteUbergraph_BountyOnHoldDecorator");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph_BountyOnHoldDecorator, &parms);
}

