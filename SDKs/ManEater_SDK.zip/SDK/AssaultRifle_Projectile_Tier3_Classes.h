#pragma once 
#include <AssaultRifle_Projectile_Tier3_Structs.h>
 
 
 
// BlueprintGeneratedClass AssaultRifle_Projectile_Tier3.AssaultRifle_Projectile_Tier3_C
// Size: 0x270(Inherited: 0x270) 
struct AAssaultRifle_Projectile_Tier3_C : public ABulletprojectile_C
{

}; 



