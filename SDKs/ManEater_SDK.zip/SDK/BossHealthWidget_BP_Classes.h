#pragma once 
#include <BossHealthWidget_BP_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass BossHealthWidget_BP.BossHealthWidget_BP_C
// Size: 0x2B8(Inherited: 0x230) 
struct UBossHealthWidget_BP_C : public UUserWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x230(0x8)
	struct UWidgetAnimation* DefeatHuntersComplete;  // 0x238(0x8)
	struct UTextBlock* DefeatHunters_Title;  // 0x240(0x8)
	struct UScaleBox* HealthBarContainer;  // 0x248(0x8)
	struct UScaleBox* HuntersContainer;  // 0x250(0x8)
	struct UImage* Image_2;  // 0x258(0x8)
	struct UImage* Image_11;  // 0x260(0x8)
	struct UProgressBar* Progress_Bar_ShieldHealth;  // 0x268(0x8)
	struct UTextBlock* Progress_Title;  // 0x270(0x8)
	struct UProgressBar* ProgressBar_1;  // 0x278(0x8)
	struct UScaleBox* ShieldContainer;  // 0x280(0x8)
	struct UTextBlock* SurviveTitle_Text;  // 0x288(0x8)
	struct UTextBlock* Text_FirstName;  // 0x290(0x8)
	struct UTextBlock* Text_LastName;  // 0x298(0x8)
	struct UTextBlock* TextBlock_Cage;  // 0x2A0(0x8)
	struct UTextBlock* TextBlock_SurviveTimer;  // 0x2A8(0x8)
	struct UScaleBox* TimerContainer;  // 0x2B0(0x8)

	void UpdateShieldHealthPercent(float InPercent); // Function BossHealthWidget_BP.BossHealthWidget_BP_C.UpdateShieldHealthPercent
	void UpdateDefeatProgress(int32_t Progress, int32_t NumToDefeat); // Function BossHealthWidget_BP.BossHealthWidget_BP_C.UpdateDefeatProgress
	void HandleVisiblityState(char EBossUIType BossUIType); // Function BossHealthWidget_BP.BossHealthWidget_BP_C.HandleVisiblityState
	void UpdateTimer(float Time); // Function BossHealthWidget_BP.BossHealthWidget_BP_C.UpdateTimer
	void UpdateHealthPercent(float InPercent); // Function BossHealthWidget_BP.BossHealthWidget_BP_C.UpdateHealthPercent
	void OnHealthBarMadeVisible(struct FText FirstName, struct FText LastName, float Health, struct FText ShieldName); // Function BossHealthWidget_BP.BossHealthWidget_BP_C.OnHealthBarMadeVisible
	void OnDefeatHuntersComplete(); // Function BossHealthWidget_BP.BossHealthWidget_BP_C.OnDefeatHuntersComplete
	void ExecuteUbergraph_BossHealthWidget_BP(int32_t EntryPoint); // Function BossHealthWidget_BP.BossHealthWidget_BP_C.ExecuteUbergraph_BossHealthWidget_BP
}; 



