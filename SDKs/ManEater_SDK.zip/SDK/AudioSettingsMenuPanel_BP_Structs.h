#pragma once 
#include "SDK.h" 
 
 
// Function AudioSettingsMenuPanel_BP.AudioSettingsMenuPanel_BP_C.NarratorVolumeChanged
// Size: 0x18(Inherited: 0x0) 
struct FNarratorVolumeChanged
{
	int32_t Index;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UME_SaveProfileObject* CallFunc_GetProfileSaveInstance_ReturnValue;  // 0x8(0x8)
	float CallFunc_Conv_IntToFloat_ReturnValue;  // 0x10(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x14(0x4)

}; 
// Function AudioSettingsMenuPanel_BP.AudioSettingsMenuPanel_BP_C.ExecuteUbergraph_AudioSettingsMenuPanel_BP
// Size: 0x9C(Inherited: 0x0) 
struct FExecuteUbergraph_AudioSettingsMenuPanel_BP
{
	int32_t EntryPoint;  // 0x0(0x4)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x4(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x14(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_3;  // 0x24(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_4;  // 0x34(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_5;  // 0x44(0x10)
	char pad_84[4];  // 0x54(0x4)
	struct UME_SaveProfileObject* CallFunc_GetProfileSaveInstance_ReturnValue;  // 0x58(0x8)
	float CallFunc_GetSfxVolume_ReturnValue;  // 0x60(0x4)
	float CallFunc_GetNarratorVolume_ReturnValue;  // 0x64(0x4)
	float CallFunc_Multiply_IntFloat_ReturnValue;  // 0x68(0x4)
	float CallFunc_Multiply_IntFloat_ReturnValue_2;  // 0x6C(0x4)
	int32_t CallFunc_FTrunc_ReturnValue;  // 0x70(0x4)
	int32_t CallFunc_FTrunc_ReturnValue_2;  // 0x74(0x4)
	float CallFunc_GetMusicVolume_ReturnValue;  // 0x78(0x4)
	float CallFunc_GetMasterVolume_ReturnValue;  // 0x7C(0x4)
	float CallFunc_Multiply_IntFloat_ReturnValue_3;  // 0x80(0x4)
	float CallFunc_Multiply_IntFloat_ReturnValue_4;  // 0x84(0x4)
	int32_t CallFunc_FTrunc_ReturnValue_3;  // 0x88(0x4)
	int32_t CallFunc_FTrunc_ReturnValue_4;  // 0x8C(0x4)
	float CallFunc_GetDialogVolume_ReturnValue;  // 0x90(0x4)
	float CallFunc_Multiply_IntFloat_ReturnValue_5;  // 0x94(0x4)
	int32_t CallFunc_FTrunc_ReturnValue_5;  // 0x98(0x4)

}; 
// Function AudioSettingsMenuPanel_BP.AudioSettingsMenuPanel_BP_C.GetDefaultFocusWidget
// Size: 0x8(Inherited: 0x8) 
struct FGetDefaultFocusWidget : public FGetDefaultFocusWidget
{
	struct UWidget* ReturnValue;  // 0x0(0x8)

}; 
// Function AudioSettingsMenuPanel_BP.AudioSettingsMenuPanel_BP_C.MasterVolumeChanged
// Size: 0x18(Inherited: 0x0) 
struct FMasterVolumeChanged
{
	int32_t Index;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UME_SaveProfileObject* CallFunc_GetProfileSaveInstance_ReturnValue;  // 0x8(0x8)
	float CallFunc_Conv_IntToFloat_ReturnValue;  // 0x10(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x14(0x4)

}; 
// Function AudioSettingsMenuPanel_BP.AudioSettingsMenuPanel_BP_C.SFXVolumeChanged
// Size: 0x24(Inherited: 0x0) 
struct FSFXVolumeChanged
{
	int32_t Index;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UME_SaveProfileObject* CallFunc_GetProfileSaveInstance_ReturnValue;  // 0x8(0x8)
	float CallFunc_Conv_IntToFloat_ReturnValue;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct UME_GameUserSettings* CallFunc_GetManeaterUserSettings_ReturnValue;  // 0x18(0x8)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x20(0x4)

}; 
// Function AudioSettingsMenuPanel_BP.AudioSettingsMenuPanel_BP_C.MusicVolumeChanged
// Size: 0x18(Inherited: 0x0) 
struct FMusicVolumeChanged
{
	int32_t Index;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UME_SaveProfileObject* CallFunc_GetProfileSaveInstance_ReturnValue;  // 0x8(0x8)
	float CallFunc_Conv_IntToFloat_ReturnValue;  // 0x10(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x14(0x4)

}; 
// Function AudioSettingsMenuPanel_BP.AudioSettingsMenuPanel_BP_C.DialogVolumeChanged
// Size: 0x18(Inherited: 0x0) 
struct FDialogVolumeChanged
{
	int32_t Index;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UME_SaveProfileObject* CallFunc_GetProfileSaveInstance_ReturnValue;  // 0x8(0x8)
	float CallFunc_Conv_IntToFloat_ReturnValue;  // 0x10(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x14(0x4)

}; 
