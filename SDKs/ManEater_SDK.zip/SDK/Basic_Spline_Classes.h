#pragma once 
#include <Basic_Spline_Structs.h>
 
 
 
// BlueprintGeneratedClass Basic_Spline.Basic_Spline_C
// Size: 0x311(Inherited: 0x220) 
struct ABasic_Spline_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct USplineComponent* Spline;  // 0x228(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x230(0x8)
	struct TArray<struct UStaticMesh*> SplineMeshArray;  // 0x238(0x10)
	struct UStaticMesh* SplineMesh;  // 0x248(0x8)
	float DetailXStart;  // 0x250(0x4)
	float DetailYStart;  // 0x254(0x4)
	struct TArray<struct UStaticMesh*> SplineMeshTempArray;  // 0x258(0x10)
	char pad_616_1 : 7;  // 0x268(0x1)
	bool NormalizeTangents : 1;  // 0x268(0x1)
	char pad_617[7];  // 0x269(0x7)
	struct UInstancedStaticMeshComponent* NewVar_1;  // 0x270(0x8)
	float Length;  // 0x278(0x4)
	float MeshTileLength;  // 0x27C(0x4)
	int32_t Segments;  // 0x280(0x4)
	int32_t CurrentIndex;  // 0x284(0x4)
	struct USplineMeshComponent* CurrentMesh;  // 0x288(0x8)
	int32_t MeshIndex;  // 0x290(0x4)
	float CurrentPointDistance;  // 0x294(0x4)
	float NextPointDistance;  // 0x298(0x4)
	float Roll;  // 0x29C(0x4)
	float StartScale;  // 0x2A0(0x4)
	float EndScale;  // 0x2A4(0x4)
	float SplineMaxDrawDistance;  // 0x2A8(0x4)
	float SplineScale;  // 0x2AC(0x4)
	char pad_688_1 : 7;  // 0x2B0(0x1)
	bool UpdateSplineMesh : 1;  // 0x2B0(0x1)
	char pad_689[7];  // 0x2B1(0x7)
	struct UMaterialInterface* SplineMesh_MAT;  // 0x2B8(0x8)
	char pad_704_1 : 7;  // 0x2C0(0x1)
	bool EnableCollision? : 1;  // 0x2C0(0x1)
	char pad_705[7];  // 0x2C1(0x7)
	ALight* LightInfo;  // 0x2C8(0x8)
	struct TArray<struct FTransform> LightSocketTransform;  // 0x2D0(0x10)
	struct TArray<struct USplineMeshComponent*> BuiltSplineMesh;  // 0x2E0(0x10)
	struct FName SpawnedTag;  // 0x2F0(0x8)
	struct FName TODLightTag;  // 0x2F8(0x8)
	struct TArray<struct ALight*> SpawnedLights;  // 0x300(0x10)
	char pad_784_1 : 7;  // 0x310(0x1)
	bool IgnoreCameraCollision : 1;  // 0x310(0x1)

	void TurnSpawnedLightsOff(); // Function Basic_Spline.Basic_Spline_C.TurnSpawnedLightsOff
	void TurnSpawnedLightsOn(); // Function Basic_Spline.Basic_Spline_C.TurnSpawnedLightsOn
	void ManualDestroyLights(); // Function Basic_Spline.Basic_Spline_C.ManualDestroyLights
	void GenerateLights(); // Function Basic_Spline.Basic_Spline_C.GenerateLights
	void SpawnLightAtLocation(ALight* LightInformation, struct FTransform Transform, struct AActor* StaticMesh, struct FName CustomTag, struct FName SocketName); // Function Basic_Spline.Basic_Spline_C.SpawnLightAtLocation
	void DestroyLights(); // Function Basic_Spline.Basic_Spline_C.DestroyLights
	void UpdateMesh(int32_t MeshIndex, struct USplineMeshComponent* CurrentMesh); // Function Basic_Spline.Basic_Spline_C.UpdateMesh
	void UserConstructionScript(); // Function Basic_Spline.Basic_Spline_C.UserConstructionScript
	void CustomEvent_1(); // Function Basic_Spline.Basic_Spline_C.CustomEvent_1
	void ExecuteUbergraph_Basic_Spline(int32_t EntryPoint); // Function Basic_Spline.Basic_Spline_C.ExecuteUbergraph_Basic_Spline
}; 



