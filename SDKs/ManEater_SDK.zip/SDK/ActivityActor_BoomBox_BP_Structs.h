#pragma once 
#include "SDK.h" 
 
 
// Function ActivityActor_BoomBox_BP.ActivityActor_BoomBox_BP_C.ExecuteUbergraph_ActivityActor_BoomBox_BP
// Size: 0x6C(Inherited: 0x0) 
struct FExecuteUbergraph_ActivityActor_BoomBox_BP
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x4(0x1)
	char pad_5[11];  // 0x5(0xB)
	struct FTransform CallFunc_K2_GetComponentToWorld_ReturnValue;  // 0x10(0x30)
	struct AActor* CallFunc_BeginDeferredActorSpawnFromClass_ReturnValue;  // 0x40(0x8)
	struct ATargetPoint* CallFunc_FinishSpawningActor_ReturnValue;  // 0x48(0x8)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x50(0x1)
	char pad_81[7];  // 0x51(0x7)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable;  // 0x58(0x10)
	int32_t CallFunc_PostAndWaitForEndOfEvent_ReturnValue;  // 0x68(0x4)

}; 
