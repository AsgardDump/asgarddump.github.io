#include "SDK.h" 
 
 
void AWildlife_Base_BP_C::FacePlayer(){

	static UObject* p_FacePlayer = UObject::FindObject<UFunction>("Function Apex_AtomicLeviathan_BP.Apex_AtomicLeviathan_BP_C.FacePlayer");

	struct {
	} parms;


	ProcessEvent(p_FacePlayer, &parms);
}

void AWildlife_Base_BP_C::SetUpDynamicMaterials(){

	static UObject* p_SetUpDynamicMaterials = UObject::FindObject<UFunction>("Function Apex_AtomicLeviathan_BP.Apex_AtomicLeviathan_BP_C.SetUpDynamicMaterials");

	struct {
	} parms;


	ProcessEvent(p_SetUpDynamicMaterials, &parms);
}

void AWildlife_Base_BP_C::ScareSpawnedWildlife(){

	static UObject* p_ScareSpawnedWildlife = UObject::FindObject<UFunction>("Function Apex_AtomicLeviathan_BP.Apex_AtomicLeviathan_BP_C.ScareSpawnedWildlife");

	struct {
	} parms;


	ProcessEvent(p_ScareSpawnedWildlife, &parms);
}

void AWildlife_Base_BP_C::DestroySpawnedWildlife(){

	static UObject* p_DestroySpawnedWildlife = UObject::FindObject<UFunction>("Function Apex_AtomicLeviathan_BP.Apex_AtomicLeviathan_BP_C.DestroySpawnedWildlife");

	struct {
	} parms;


	ProcessEvent(p_DestroySpawnedWildlife, &parms);
}

void AWildlife_Base_BP_C::StartFinaleCinematic(){

	static UObject* p_StartFinaleCinematic = UObject::FindObject<UFunction>("Function Apex_AtomicLeviathan_BP.Apex_AtomicLeviathan_BP_C.StartFinaleCinematic");

	struct {
	} parms;


	ProcessEvent(p_StartFinaleCinematic, &parms);
}

void AWildlife_Base_BP_C::MoveToStartingLocation(){

	static UObject* p_MoveToStartingLocation = UObject::FindObject<UFunction>("Function Apex_AtomicLeviathan_BP.Apex_AtomicLeviathan_BP_C.MoveToStartingLocation");

	struct {
	} parms;


	ProcessEvent(p_MoveToStartingLocation, &parms);
}

void AWildlife_Base_BP_C::ShowHealthBar?(bool Show?){

	static UObject* p_ShowHealthBar? = UObject::FindObject<UFunction>("Function Apex_AtomicLeviathan_BP.Apex_AtomicLeviathan_BP_C.ShowHealthBar?");

	struct {
		bool Show?;
	} parms;

	parms.Show? = Show?;

	ProcessEvent(p_ShowHealthBar?, &parms);
}

void AWildlife_Base_BP_C::TryRemoveHealthBar(){

	static UObject* p_TryRemoveHealthBar = UObject::FindObject<UFunction>("Function Apex_AtomicLeviathan_BP.Apex_AtomicLeviathan_BP_C.TryRemoveHealthBar");

	struct {
	} parms;


	ProcessEvent(p_TryRemoveHealthBar, &parms);
}

void AWildlife_Base_BP_C::UpdateSpawnedWildlifeAIs(){

	static UObject* p_UpdateSpawnedWildlifeAIs = UObject::FindObject<UFunction>("Function Apex_AtomicLeviathan_BP.Apex_AtomicLeviathan_BP_C.UpdateSpawnedWildlifeAIs");

	struct {
	} parms;


	ProcessEvent(p_UpdateSpawnedWildlifeAIs, &parms);
}

void AWildlife_Base_BP_C::SpawnWildlifeIfNeeded(){

	static UObject* p_SpawnWildlifeIfNeeded = UObject::FindObject<UFunction>("Function Apex_AtomicLeviathan_BP.Apex_AtomicLeviathan_BP_C.SpawnWildlifeIfNeeded");

	struct {
	} parms;


	ProcessEvent(p_SpawnWildlifeIfNeeded, &parms);
}

void AWildlife_Base_BP_C::UpdateHealthBar(){

	static UObject* p_UpdateHealthBar = UObject::FindObject<UFunction>("Function Apex_AtomicLeviathan_BP.Apex_AtomicLeviathan_BP_C.UpdateHealthBar");

	struct {
	} parms;


	ProcessEvent(p_UpdateHealthBar, &parms);
}

void AWildlife_Base_BP_C::SetUpHealthBar(){

	static UObject* p_SetUpHealthBar = UObject::FindObject<UFunction>("Function Apex_AtomicLeviathan_BP.Apex_AtomicLeviathan_BP_C.SetUpHealthBar");

	struct {
	} parms;


	ProcessEvent(p_SetUpHealthBar, &parms);
}

void AWildlife_Base_BP_C::UpdateHealthPercentage(){

	static UObject* p_UpdateHealthPercentage = UObject::FindObject<UFunction>("Function Apex_AtomicLeviathan_BP.Apex_AtomicLeviathan_BP_C.UpdateHealthPercentage");

	struct {
	} parms;


	ProcessEvent(p_UpdateHealthPercentage, &parms);
}

void AWildlife_Base_BP_C::ResetArmor(){

	static UObject* p_ResetArmor = UObject::FindObject<UFunction>("Function Apex_AtomicLeviathan_BP.Apex_AtomicLeviathan_BP_C.ResetArmor");

	struct {
	} parms;


	ProcessEvent(p_ResetArmor, &parms);
}

void AWildlife_Base_BP_C::ResetArmorPulseEmissive__FinishedFunc(){

	static UObject* p_ResetArmorPulseEmissive__FinishedFunc = UObject::FindObject<UFunction>("Function Apex_AtomicLeviathan_BP.Apex_AtomicLeviathan_BP_C.ResetArmorPulseEmissive__FinishedFunc");

	struct {
	} parms;


	ProcessEvent(p_ResetArmorPulseEmissive__FinishedFunc, &parms);
}

void AWildlife_Base_BP_C::ResetArmorPulseEmissive__UpdateFunc(){

	static UObject* p_ResetArmorPulseEmissive__UpdateFunc = UObject::FindObject<UFunction>("Function Apex_AtomicLeviathan_BP.Apex_AtomicLeviathan_BP_C.ResetArmorPulseEmissive__UpdateFunc");

	struct {
	} parms;


	ProcessEvent(p_ResetArmorPulseEmissive__UpdateFunc, &parms);
}

void AWildlife_Base_BP_C::ReceiveBeginPlay(){

	static UObject* p_ReceiveBeginPlay = UObject::FindObject<UFunction>("Function Apex_AtomicLeviathan_BP.Apex_AtomicLeviathan_BP_C.ReceiveBeginPlay");

	struct {
	} parms;


	ProcessEvent(p_ReceiveBeginPlay, &parms);
}

void AWildlife_Base_BP_C::Damage Taken(struct AActor* DamagedActor, float Damage, struct UDamageType* DamageType, struct AController* InstigatedBy, struct AActor* DamageCauser){

	static UObject* p_Damage Taken = UObject::FindObject<UFunction>("Function Apex_AtomicLeviathan_BP.Apex_AtomicLeviathan_BP_C.Damage Taken");

	struct {
		struct AActor* DamagedActor;
		float Damage;
		struct UDamageType* DamageType;
		struct AController* InstigatedBy;
		struct AActor* DamageCauser;
	} parms;

	parms.DamagedActor = DamagedActor;
	parms.Damage = Damage;
	parms.DamageType = DamageType;
	parms.InstigatedBy = InstigatedBy;
	parms.DamageCauser = DamageCauser;

	ProcessEvent(p_Damage Taken, &parms);
}

void AWildlife_Base_BP_C::BindTakeDamage(){

	static UObject* p_BindTakeDamage = UObject::FindObject<UFunction>("Function Apex_AtomicLeviathan_BP.Apex_AtomicLeviathan_BP_C.BindTakeDamage");

	struct {
	} parms;


	ProcessEvent(p_BindTakeDamage, &parms);
}

void AWildlife_Base_BP_C::ReceiveTick(float DeltaSeconds){

	static UObject* p_ReceiveTick = UObject::FindObject<UFunction>("Function Apex_AtomicLeviathan_BP.Apex_AtomicLeviathan_BP_C.ReceiveTick");

	struct {
		float DeltaSeconds;
	} parms;

	parms.DeltaSeconds = DeltaSeconds;

	ProcessEvent(p_ReceiveTick, &parms);
}

void AWildlife_Base_BP_C::LoadSummonCinematic(){

	static UObject* p_LoadSummonCinematic = UObject::FindObject<UFunction>("Function Apex_AtomicLeviathan_BP.Apex_AtomicLeviathan_BP_C.LoadSummonCinematic");

	struct {
	} parms;


	ProcessEvent(p_LoadSummonCinematic, &parms);
}

void AWildlife_Base_BP_C::IsCineLoaded?(){

	static UObject* p_IsCineLoaded? = UObject::FindObject<UFunction>("Function Apex_AtomicLeviathan_BP.Apex_AtomicLeviathan_BP_C.IsCineLoaded?");

	struct {
	} parms;


	ProcessEvent(p_IsCineLoaded?, &parms);
}

void AWildlife_Base_BP_C::CharacterDied(struct AME_Character* Victim, struct AActor* Killer){

	static UObject* p_CharacterDied = UObject::FindObject<UFunction>("Function Apex_AtomicLeviathan_BP.Apex_AtomicLeviathan_BP_C.CharacterDied");

	struct {
		struct AME_Character* Victim;
		struct AActor* Killer;
	} parms;

	parms.Victim = Victim;
	parms.Killer = Killer;

	ProcessEvent(p_CharacterDied, &parms);
}

void AWildlife_Base_BP_C::TryLoadBoundry(bool ShouldLoad?){

	static UObject* p_TryLoadBoundry = UObject::FindObject<UFunction>("Function Apex_AtomicLeviathan_BP.Apex_AtomicLeviathan_BP_C.TryLoadBoundry");

	struct {
		bool ShouldLoad?;
	} parms;

	parms.ShouldLoad? = ShouldLoad?;

	ProcessEvent(p_TryLoadBoundry, &parms);
}

void AWildlife_Base_BP_C::GameplayTagAdded(struct FGameplayTagContainer TagsAdded, float TagDuration){

	static UObject* p_GameplayTagAdded = UObject::FindObject<UFunction>("Function Apex_AtomicLeviathan_BP.Apex_AtomicLeviathan_BP_C.GameplayTagAdded");

	struct {
		struct FGameplayTagContainer TagsAdded;
		float TagDuration;
	} parms;

	parms.TagsAdded = TagsAdded;
	parms.TagDuration = TagDuration;

	ProcessEvent(p_GameplayTagAdded, &parms);
}

void AWildlife_Base_BP_C::GameplayTagRemoved(struct FGameplayTagContainer TagsAdded){

	static UObject* p_GameplayTagRemoved = UObject::FindObject<UFunction>("Function Apex_AtomicLeviathan_BP.Apex_AtomicLeviathan_BP_C.GameplayTagRemoved");

	struct {
		struct FGameplayTagContainer TagsAdded;
	} parms;

	parms.TagsAdded = TagsAdded;

	ProcessEvent(p_GameplayTagRemoved, &parms);
}

void AWildlife_Base_BP_C::PulseEmissive(){

	static UObject* p_PulseEmissive = UObject::FindObject<UFunction>("Function Apex_AtomicLeviathan_BP.Apex_AtomicLeviathan_BP_C.PulseEmissive");

	struct {
	} parms;


	ProcessEvent(p_PulseEmissive, &parms);
}

void AWildlife_Base_BP_C::ReceiveDestroyed(){

	static UObject* p_ReceiveDestroyed = UObject::FindObject<UFunction>("Function Apex_AtomicLeviathan_BP.Apex_AtomicLeviathan_BP_C.ReceiveDestroyed");

	struct {
	} parms;


	ProcessEvent(p_ReceiveDestroyed, &parms);
}

void AWildlife_Base_BP_C::ExecuteUbergraph_Apex_AtomicLeviathan_BP(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph_Apex_AtomicLeviathan_BP = UObject::FindObject<UFunction>("Function Apex_AtomicLeviathan_BP.Apex_AtomicLeviathan_BP_C.ExecuteUbergraph_Apex_AtomicLeviathan_BP");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph_Apex_AtomicLeviathan_BP, &parms);
}

