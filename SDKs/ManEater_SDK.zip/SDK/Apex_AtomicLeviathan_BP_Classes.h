#pragma once 
#include <Apex_AtomicLeviathan_BP_Structs.h>
 
 
 
// BlueprintGeneratedClass Apex_AtomicLeviathan_BP.Apex_AtomicLeviathan_BP_C
// Size: 0x11A8(Inherited: 0x1050) 
struct AApex_AtomicLeviathan_BP_C : public AWildlife_Base_BP_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x1050(0x8)
	struct UCapsuleComponent* BlockingCollider2;  // 0x1058(0x8)
	struct UCapsuleComponent* BlockingCollider1;  // 0x1060(0x8)
	struct USphereComponent* Summon_Spawner_6;  // 0x1068(0x8)
	struct USphereComponent* Summon_Spawner_5;  // 0x1070(0x8)
	struct USphereComponent* Summon_Spawner_4;  // 0x1078(0x8)
	struct USphereComponent* Summon_Spawner_3;  // 0x1080(0x8)
	struct USphereComponent* Summon_Spawner_2;  // 0x1088(0x8)
	struct UVoiceGroupComponent_BP_C* VoiceGroupComponent_BP1;  // 0x1090(0x8)
	struct UVoiceGroupComponent_BP_C* VoiceGroupComponent_BP;  // 0x1098(0x8)
	float ResetArmorPulseEmissive_Regrowth_E0E4A8E740C9BB002197639074AE92DF;  // 0x10A0(0x4)
	float ResetArmorPulseEmissive_NewTrack_0_E0E4A8E740C9BB002197639074AE92DF;  // 0x10A4(0x4)
	char ETimelineDirection ResetArmorPulseEmissive__Direction_E0E4A8E740C9BB002197639074AE92DF;  // 0x10A8(0x1)
	char pad_4265[7];  // 0x10A9(0x7)
	struct UTimelineComponent* ResetArmorPulseEmissive;  // 0x10B0(0x8)
	float MaxArmor;  // 0x10B8(0x4)
	float Armor;  // 0x10BC(0x4)
	float Vulnerability Duration;  // 0x10C0(0x4)
	float SaveCurrentHealth;  // 0x10C4(0x4)
	char pad_4296_1 : 7;  // 0x10C8(0x1)
	bool Vulnerability Triggered : 1;  // 0x10C8(0x1)
	char pad_4297[7];  // 0x10C9(0x7)
	struct UBossHealthWidget_BP_C* BossHealthBar;  // 0x10D0(0x8)
	struct FText OverrideFirstName;  // 0x10D8(0x18)
	struct FText OverrideLastName;  // 0x10F0(0x18)
	struct FText OverrideShieldName;  // 0x1108(0x18)
	char EBossUIType BossUIType;  // 0x1120(0x1)
	char pad_4385_1 : 7;  // 0x1121(0x1)
	bool HasPerformedSummonAbility : 1;  // 0x1121(0x1)
	char pad_4386_1 : 7;  // 0x1122(0x1)
	bool WantsToSummonWildlife : 1;  // 0x1122(0x1)
	char pad_4387[5];  // 0x1123(0x5)
	struct TArray<struct USceneComponent*> SummonSpawners;  // 0x1128(0x10)
	int32_t NumWildlifeSpawned;  // 0x1138(0x4)
	char pad_4412[4];  // 0x113C(0x4)
	struct TArray<struct TSoftObjectPtr<AME_AIController>> SpawnedWildlifeAI;  // 0x1140(0x10)
	struct TArray<struct USceneComponent*> UsedSpawners;  // 0x1150(0x10)
	struct FTransform StartingLocation;  // 0x1160(0x30)
	struct AAIController_AtomicLeviathan_C* AtomicLeviathanAIController;  // 0x1190(0x8)
	struct UMaterialInstanceDynamic* DynamicMaterial;  // 0x1198(0x8)
	struct UMaterialInstanceDynamic* DynamicArmorMaterial;  // 0x11A0(0x8)

	void FacePlayer(); // Function Apex_AtomicLeviathan_BP.Apex_AtomicLeviathan_BP_C.FacePlayer
	void SetUpDynamicMaterials(); // Function Apex_AtomicLeviathan_BP.Apex_AtomicLeviathan_BP_C.SetUpDynamicMaterials
	void ScareSpawnedWildlife(); // Function Apex_AtomicLeviathan_BP.Apex_AtomicLeviathan_BP_C.ScareSpawnedWildlife
	void DestroySpawnedWildlife(); // Function Apex_AtomicLeviathan_BP.Apex_AtomicLeviathan_BP_C.DestroySpawnedWildlife
	void StartFinaleCinematic(); // Function Apex_AtomicLeviathan_BP.Apex_AtomicLeviathan_BP_C.StartFinaleCinematic
	void MoveToStartingLocation(); // Function Apex_AtomicLeviathan_BP.Apex_AtomicLeviathan_BP_C.MoveToStartingLocation
	void ShowHealthBar?(bool Show?); // Function Apex_AtomicLeviathan_BP.Apex_AtomicLeviathan_BP_C.ShowHealthBar?
	void TryRemoveHealthBar(); // Function Apex_AtomicLeviathan_BP.Apex_AtomicLeviathan_BP_C.TryRemoveHealthBar
	void UpdateSpawnedWildlifeAIs(); // Function Apex_AtomicLeviathan_BP.Apex_AtomicLeviathan_BP_C.UpdateSpawnedWildlifeAIs
	void SpawnWildlifeIfNeeded(); // Function Apex_AtomicLeviathan_BP.Apex_AtomicLeviathan_BP_C.SpawnWildlifeIfNeeded
	void UpdateHealthBar(); // Function Apex_AtomicLeviathan_BP.Apex_AtomicLeviathan_BP_C.UpdateHealthBar
	void SetUpHealthBar(); // Function Apex_AtomicLeviathan_BP.Apex_AtomicLeviathan_BP_C.SetUpHealthBar
	void UpdateHealthPercentage(); // Function Apex_AtomicLeviathan_BP.Apex_AtomicLeviathan_BP_C.UpdateHealthPercentage
	void ResetArmor(); // Function Apex_AtomicLeviathan_BP.Apex_AtomicLeviathan_BP_C.ResetArmor
	void ResetArmorPulseEmissive__FinishedFunc(); // Function Apex_AtomicLeviathan_BP.Apex_AtomicLeviathan_BP_C.ResetArmorPulseEmissive__FinishedFunc
	void ResetArmorPulseEmissive__UpdateFunc(); // Function Apex_AtomicLeviathan_BP.Apex_AtomicLeviathan_BP_C.ResetArmorPulseEmissive__UpdateFunc
	void ReceiveBeginPlay(); // Function Apex_AtomicLeviathan_BP.Apex_AtomicLeviathan_BP_C.ReceiveBeginPlay
	void Damage Taken(struct AActor* DamagedActor, float Damage, struct UDamageType* DamageType, struct AController* InstigatedBy, struct AActor* DamageCauser); // Function Apex_AtomicLeviathan_BP.Apex_AtomicLeviathan_BP_C.Damage Taken
	void BindTakeDamage(); // Function Apex_AtomicLeviathan_BP.Apex_AtomicLeviathan_BP_C.BindTakeDamage
	void ReceiveTick(float DeltaSeconds); // Function Apex_AtomicLeviathan_BP.Apex_AtomicLeviathan_BP_C.ReceiveTick
	void LoadSummonCinematic(); // Function Apex_AtomicLeviathan_BP.Apex_AtomicLeviathan_BP_C.LoadSummonCinematic
	void IsCineLoaded?(); // Function Apex_AtomicLeviathan_BP.Apex_AtomicLeviathan_BP_C.IsCineLoaded?
	void CharacterDied(struct AME_Character* Victim, struct AActor* Killer); // Function Apex_AtomicLeviathan_BP.Apex_AtomicLeviathan_BP_C.CharacterDied
	void TryLoadBoundry(bool ShouldLoad?); // Function Apex_AtomicLeviathan_BP.Apex_AtomicLeviathan_BP_C.TryLoadBoundry
	void GameplayTagAdded(struct FGameplayTagContainer TagsAdded, float TagDuration); // Function Apex_AtomicLeviathan_BP.Apex_AtomicLeviathan_BP_C.GameplayTagAdded
	void GameplayTagRemoved(struct FGameplayTagContainer TagsAdded); // Function Apex_AtomicLeviathan_BP.Apex_AtomicLeviathan_BP_C.GameplayTagRemoved
	void PulseEmissive(); // Function Apex_AtomicLeviathan_BP.Apex_AtomicLeviathan_BP_C.PulseEmissive
	void ReceiveDestroyed(); // Function Apex_AtomicLeviathan_BP.Apex_AtomicLeviathan_BP_C.ReceiveDestroyed
	void ExecuteUbergraph_Apex_AtomicLeviathan_BP(int32_t EntryPoint); // Function Apex_AtomicLeviathan_BP.Apex_AtomicLeviathan_BP_C.ExecuteUbergraph_Apex_AtomicLeviathan_BP
}; 



