#pragma once 
#include <AM_EVO_Bone_Body_Activate_T3_Structs.h>
 
 
 
// BlueprintGeneratedClass AM_EVO_Bone_Body_Activate_T3.AM_EVO_Bone_Body_Activate_T3_C
// Size: 0x5E0(Inherited: 0x5E0) 
struct UAM_EVO_Bone_Body_Activate_T3_C : public UME_GameplayAbility_Montage
{

}; 



