#pragma once 
#include <AM_KillSequence_Breaching_Structs.h>
 
 
 
// BlueprintGeneratedClass AM_KillSequence_Breaching.AM_KillSequence_Breaching_C
// Size: 0x640(Inherited: 0x640) 
struct UAM_KillSequence_Breaching_C : public UAM_KillSequence_C
{

}; 



