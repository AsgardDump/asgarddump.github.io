#pragma once 
#include <AM_MovingWaterReentryBackwards_Structs.h>
 
 
 
// BlueprintGeneratedClass AM_MovingWaterReentryBackwards.AM_MovingWaterReentryBackwards_C
// Size: 0x620(Inherited: 0x620) 
struct UAM_MovingWaterReentryBackwards_C : public UME_GameplayAbilitySharkMontage
{

}; 



