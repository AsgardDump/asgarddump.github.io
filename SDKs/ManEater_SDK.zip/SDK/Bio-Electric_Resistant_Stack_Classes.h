#pragma once 
#include <Bio-Electric_Resistant_Stack_Structs.h>
 
 
 
// BlueprintGeneratedClass Bio-Electric_Resistant_Stack.Bio-Electric_Resistant_Stack_C
// Size: 0x870(Inherited: 0x870) 
struct UBio-Electric_Resistant_Stack_C : public UME_GameplayEffect
{

}; 



