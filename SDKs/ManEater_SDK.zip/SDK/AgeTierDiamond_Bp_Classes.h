#pragma once 
#include <AgeTierDiamond_Bp_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass AgeTierDiamond_Bp.AgeTierDiamond_BP_C
// Size: 0x278(Inherited: 0x278) 
struct UAgeTierDiamond_BP_C : public UAgeTierDiamond
{

}; 



