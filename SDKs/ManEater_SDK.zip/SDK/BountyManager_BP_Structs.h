#pragma once 
#include "SDK.h" 
 
 
// Function BountyManager_BP.BountyManager_BP_C.ExecuteUbergraph_BountyManager_BP
// Size: 0x44(Inherited: 0x0) 
struct FExecuteUbergraph_BountyManager_BP
{
	int32_t EntryPoint;  // 0x0(0x4)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x4(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x14(0x10)
	int32_t K2Node_CustomEvent_Rank;  // 0x24(0x4)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue : 1;  // 0x28(0x1)
	char pad_41[3];  // 0x29(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_3;  // 0x2C(0x10)
	char pad_60_1 : 7;  // 0x3C(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue_2 : 1;  // 0x3C(0x1)
	char pad_61_1 : 7;  // 0x3D(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x3D(0x1)
	char pad_62_1 : 7;  // 0x3E(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_2 : 1;  // 0x3E(0x1)
	char pad_63[1];  // 0x3F(0x1)
	int32_t CallFunc_GetMaxNumActiveDivers_ReturnValue;  // 0x40(0x4)

}; 
// Function BountyManager_BP.BountyManager_BP_C.Infamy Rank Up
// Size: 0x4(Inherited: 0x0) 
struct FInfamy Rank Up
{
	int32_t Rank;  // 0x0(0x4)

}; 
