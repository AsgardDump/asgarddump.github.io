#pragma once 
#include <AM_Bite_Structs.h>
 
 
 
// BlueprintGeneratedClass AM_Bite.AM_Bite_C
// Size: 0x620(Inherited: 0x620) 
struct UAM_Bite_C : public UME_GameplayAbilitySharkMontage
{

}; 



