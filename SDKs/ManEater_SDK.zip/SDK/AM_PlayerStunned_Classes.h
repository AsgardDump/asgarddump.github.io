#pragma once 
#include <AM_PlayerStunned_Structs.h>
 
 
 
// BlueprintGeneratedClass AM_PlayerStunned.AM_PlayerStunned_C
// Size: 0x620(Inherited: 0x620) 
struct UAM_PlayerStunned_C : public UME_GameplayAbilitySharkMontage
{

}; 



