#pragma once 
#include <AM_StationaryWaterReentryBackwardsAndDown_Structs.h>
 
 
 
// BlueprintGeneratedClass AM_StationaryWaterReentryBackwardsAndDown.AM_StationaryWaterReentryBackwardsAndDown_C
// Size: 0x620(Inherited: 0x620) 
struct UAM_StationaryWaterReentryBackwardsAndDown_C : public UME_GameplayAbilitySharkMontage
{

}; 



