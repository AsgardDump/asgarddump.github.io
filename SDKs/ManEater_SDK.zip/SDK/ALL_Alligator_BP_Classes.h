#pragma once 
#include <ALL_Alligator_BP_Structs.h>
 
 
 
// BlueprintGeneratedClass ALL_Alligator_BP.ALL_Alligator_BP_C
// Size: 0x1060(Inherited: 0x1050) 
struct AALL_Alligator_BP_C : public AWildlife_Base_BP_C
{
	struct UVoiceGroupComponent_BP_C* VoiceGroupComponent_BP1;  // 0x1050(0x8)
	struct UVoiceGroupComponent_BP_C* VoiceGroupComponent_BP;  // 0x1058(0x8)

}; 



