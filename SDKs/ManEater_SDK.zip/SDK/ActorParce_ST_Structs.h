#pragma once 
#include "SDK.h" 
 
 
// UserDefinedStruct ActorParce_ST.ActorParce_ST
// Size: 0x10(Inherited: 0x0) 
struct FActorParce_ST
{
	struct TArray<struct AActor*> Actor_3_8B1A743641BA587DB2F62C82F1E55752;  // 0x0(0x10)

}; 
