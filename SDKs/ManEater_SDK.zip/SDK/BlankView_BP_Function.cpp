#include "SDK.h" 
 
 
bool UTwBaseView::DoesRequireInputUIMode(){

	static UObject* p_DoesRequireInputUIMode = UObject::FindObject<UFunction>("Function BlankView_BP.BlankView_BP_C.DoesRequireInputUIMode");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_DoesRequireInputUIMode, &parms);
	return parms.return_value;
}

void UTwBaseView::SubscribeToEvents_BP(struct AHUD* HUD){

	static UObject* p_SubscribeToEvents_BP = UObject::FindObject<UFunction>("Function BlankView_BP.BlankView_BP_C.SubscribeToEvents_BP");

	struct {
		struct AHUD* HUD;
	} parms;

	parms.HUD = HUD;

	ProcessEvent(p_SubscribeToEvents_BP, &parms);
}

void UTwBaseView::ExecuteUbergraph_BlankView_BP(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph_BlankView_BP = UObject::FindObject<UFunction>("Function BlankView_BP.BlankView_BP_C.ExecuteUbergraph_BlankView_BP");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph_BlankView_BP, &parms);
}

