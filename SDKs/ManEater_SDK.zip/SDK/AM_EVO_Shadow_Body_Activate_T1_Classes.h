#pragma once 
#include <AM_EVO_Shadow_Body_Activate_T1_Structs.h>
 
 
 
// BlueprintGeneratedClass AM_EVO_Shadow_Body_Activate_T1.AM_EVO_Shadow_Body_Activate_T1_C
// Size: 0x5E0(Inherited: 0x5E0) 
struct UAM_EVO_Shadow_Body_Activate_T1_C : public UME_GameplayAbility_Montage
{

}; 



