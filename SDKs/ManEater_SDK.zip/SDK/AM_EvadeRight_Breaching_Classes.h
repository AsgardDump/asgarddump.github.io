#pragma once 
#include <AM_EvadeRight_Breaching_Structs.h>
 
 
 
// BlueprintGeneratedClass AM_EvadeRight_Breaching.AM_EvadeRight_Breaching_C
// Size: 0x620(Inherited: 0x620) 
struct UAM_EvadeRight_Breaching_C : public UME_GameplayAbility_SharkEvade
{

}; 



