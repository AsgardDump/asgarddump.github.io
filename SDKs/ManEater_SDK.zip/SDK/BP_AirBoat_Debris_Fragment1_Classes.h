#pragma once 
#include <BP_AirBoat_Debris_Fragment1_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_AirBoat_Debris_Fragment1.BP_AirBoat_Debris_Fragment1_C
// Size: 0x230(Inherited: 0x230) 
struct ABP_AirBoat_Debris_Fragment1_C : public ABP_VehicleDebris_C
{

	int32_t GetSizeLevel(struct AME_AnimalCharacter* GrabbingAnimal); // Function BP_AirBoat_Debris_Fragment1.BP_AirBoat_Debris_Fragment1_C.GetSizeLevel
}; 



