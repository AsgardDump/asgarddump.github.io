#pragma once 
#include <AM_EvadeLeft_Knifing_Structs.h>
 
 
 
// BlueprintGeneratedClass AM_EvadeLeft_Knifing.AM_EvadeLeft_Knifing_C
// Size: 0x620(Inherited: 0x620) 
struct UAM_EvadeLeft_Knifing_C : public UME_GameplayAbility_SharkEvade
{

}; 



