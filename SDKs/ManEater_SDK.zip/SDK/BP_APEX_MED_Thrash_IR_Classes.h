#pragma once 
#include <BP_APEX_MED_Thrash_IR_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_APEX_MED_Thrash_IR.BP_APEX_MED_Thrash_IR_C
// Size: 0x40(Inherited: 0x40) 
struct UBP_APEX_MED_Thrash_IR_C : public UBP_Base_IR_C
{

	struct FImpactEffect GetImpactEffects(char EPhysicalSurface ImpactingSurface, bool bUnderwater, bool bScrape); // Function BP_APEX_MED_Thrash_IR.BP_APEX_MED_Thrash_IR_C.GetImpactEffects
}; 



