#pragma once 
#include <AM_CruisingWaterEntry_Structs.h>
 
 
 
// BlueprintGeneratedClass AM_CruisingWaterEntry.AM_CruisingWaterEntry_C
// Size: 0x620(Inherited: 0x620) 
struct UAM_CruisingWaterEntry_C : public UME_GameplayAbilitySharkMontage
{

}; 



