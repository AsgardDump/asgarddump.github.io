#pragma once 
#include <BoostMeter_BP_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass BoostMeter_BP.BoostMeter_BP_C
// Size: 0x2A4(Inherited: 0x258) 
struct UBoostMeter_BP_C : public UTwBaseWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x258(0x8)
	struct UProgressBar* LungeBar;  // 0x260(0x8)
	int32_t LungeTier;  // 0x268(0x4)
	char pad_620[4];  // 0x26C(0x4)
	struct FGameplayTagContainer LocalTagContainer;  // 0x270(0x20)
	struct TArray<struct FGameplayTag> TagsOfConcern;  // 0x290(0x10)
	int32_t SprintTier;  // 0x2A0(0x4)

	void ProcessTagChange(); // Function BoostMeter_BP.BoostMeter_BP_C.ProcessTagChange
	void UpdateLocalTagContainer(bool bAdded, struct FGameplayTagContainer TagContainer, float TagDuration); // Function BoostMeter_BP.BoostMeter_BP_C.UpdateLocalTagContainer
	void UnsubscribeFromEvents_BP(struct AHUD* HUD); // Function BoostMeter_BP.BoostMeter_BP_C.UnsubscribeFromEvents_BP
	void GameplayTagAdded(struct FGameplayTagContainer TagsAdded, float TagDuration); // Function BoostMeter_BP.BoostMeter_BP_C.GameplayTagAdded
	void SubscribeToEvents_BP(struct AHUD* HUD); // Function BoostMeter_BP.BoostMeter_BP_C.SubscribeToEvents_BP
	void GameplayTagRemoved(struct FGameplayTagContainer TagsAdded); // Function BoostMeter_BP.BoostMeter_BP_C.GameplayTagRemoved
	void Construct(); // Function BoostMeter_BP.BoostMeter_BP_C.Construct
	void ExecuteUbergraph_BoostMeter_BP(int32_t EntryPoint); // Function BoostMeter_BP.BoostMeter_BP_C.ExecuteUbergraph_BoostMeter_BP
}; 



