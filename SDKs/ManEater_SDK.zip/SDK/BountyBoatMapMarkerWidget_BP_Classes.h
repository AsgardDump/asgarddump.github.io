#pragma once 
#include <BountyBoatMapMarkerWidget_BP_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass BountyBoatMapMarkerWidget_BP.BountyBoatMapMarkerWidget_BP_C
// Size: 0x350(Inherited: 0x340) 
struct UBountyBoatMapMarkerWidget_BP_C : public UBountyBoatMapMarkerWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x340(0x8)
	struct UWidgetAnimation* DangerLoop;  // 0x348(0x8)

	void Construct(); // Function BountyBoatMapMarkerWidget_BP.BountyBoatMapMarkerWidget_BP_C.Construct
	void ExecuteUbergraph_BountyBoatMapMarkerWidget_BP(int32_t EntryPoint); // Function BountyBoatMapMarkerWidget_BP.BountyBoatMapMarkerWidget_BP_C.ExecuteUbergraph_BountyBoatMapMarkerWidget_BP
}; 



