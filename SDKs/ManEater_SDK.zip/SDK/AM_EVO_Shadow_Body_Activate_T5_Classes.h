#pragma once 
#include <AM_EVO_Shadow_Body_Activate_T5_Structs.h>
 
 
 
// BlueprintGeneratedClass AM_EVO_Shadow_Body_Activate_T5.AM_EVO_Shadow_Body_Activate_T5_C
// Size: 0x5E0(Inherited: 0x5E0) 
struct UAM_EVO_Shadow_Body_Activate_T5_C : public UME_GameplayAbility_Montage
{

}; 



