#include "SDK.h" 
 
 
void UUserWidget::UpdateShieldHealthPercent(float InPercent){

	static UObject* p_UpdateShieldHealthPercent = UObject::FindObject<UFunction>("Function BossHealthWidget_BP.BossHealthWidget_BP_C.UpdateShieldHealthPercent");

	struct {
		float InPercent;
	} parms;

	parms.InPercent = InPercent;

	ProcessEvent(p_UpdateShieldHealthPercent, &parms);
}

void UUserWidget::UpdateDefeatProgress(int32_t Progress, int32_t NumToDefeat){

	static UObject* p_UpdateDefeatProgress = UObject::FindObject<UFunction>("Function BossHealthWidget_BP.BossHealthWidget_BP_C.UpdateDefeatProgress");

	struct {
		int32_t Progress;
		int32_t NumToDefeat;
	} parms;

	parms.Progress = Progress;
	parms.NumToDefeat = NumToDefeat;

	ProcessEvent(p_UpdateDefeatProgress, &parms);
}

void UUserWidget::HandleVisiblityState(char EBossUIType BossUIType){

	static UObject* p_HandleVisiblityState = UObject::FindObject<UFunction>("Function BossHealthWidget_BP.BossHealthWidget_BP_C.HandleVisiblityState");

	struct {
		char EBossUIType BossUIType;
	} parms;

	parms.BossUIType = BossUIType;

	ProcessEvent(p_HandleVisiblityState, &parms);
}

void UUserWidget::UpdateTimer(float Time){

	static UObject* p_UpdateTimer = UObject::FindObject<UFunction>("Function BossHealthWidget_BP.BossHealthWidget_BP_C.UpdateTimer");

	struct {
		float Time;
	} parms;

	parms.Time = Time;

	ProcessEvent(p_UpdateTimer, &parms);
}

void UUserWidget::UpdateHealthPercent(float InPercent){

	static UObject* p_UpdateHealthPercent = UObject::FindObject<UFunction>("Function BossHealthWidget_BP.BossHealthWidget_BP_C.UpdateHealthPercent");

	struct {
		float InPercent;
	} parms;

	parms.InPercent = InPercent;

	ProcessEvent(p_UpdateHealthPercent, &parms);
}

void UUserWidget::OnHealthBarMadeVisible(struct FText FirstName, struct FText LastName, float Health, struct FText ShieldName){

	static UObject* p_OnHealthBarMadeVisible = UObject::FindObject<UFunction>("Function BossHealthWidget_BP.BossHealthWidget_BP_C.OnHealthBarMadeVisible");

	struct {
		struct FText FirstName;
		struct FText LastName;
		float Health;
		struct FText ShieldName;
	} parms;

	parms.FirstName = FirstName;
	parms.LastName = LastName;
	parms.Health = Health;
	parms.ShieldName = ShieldName;

	ProcessEvent(p_OnHealthBarMadeVisible, &parms);
}

void UUserWidget::OnDefeatHuntersComplete(){

	static UObject* p_OnDefeatHuntersComplete = UObject::FindObject<UFunction>("Function BossHealthWidget_BP.BossHealthWidget_BP_C.OnDefeatHuntersComplete");

	struct {
	} parms;


	ProcessEvent(p_OnDefeatHuntersComplete, &parms);
}

void UUserWidget::ExecuteUbergraph_BossHealthWidget_BP(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph_BossHealthWidget_BP = UObject::FindObject<UFunction>("Function BossHealthWidget_BP.BossHealthWidget_BP_C.ExecuteUbergraph_BossHealthWidget_BP");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph_BossHealthWidget_BP, &parms);
}

