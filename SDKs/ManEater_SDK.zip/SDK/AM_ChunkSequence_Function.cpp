#include "SDK.h" 
 
 
void UME_GameplayAbilitySharkMontage::MontageEnded(struct UAnimMontage* Montage, bool bInterrupted){

	static UObject* p_MontageEnded = UObject::FindObject<UFunction>("Function AM_ChunkSequence.AM_ChunkSequence_C.MontageEnded");

	struct {
		struct UAnimMontage* Montage;
		bool bInterrupted;
	} parms;

	parms.Montage = Montage;
	parms.bInterrupted = bInterrupted;

	ProcessEvent(p_MontageEnded, &parms);
}

void UME_GameplayAbilitySharkMontage::ExecuteUbergraph_AM_ChunkSequence(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph_AM_ChunkSequence = UObject::FindObject<UFunction>("Function AM_ChunkSequence.AM_ChunkSequence_C.ExecuteUbergraph_AM_ChunkSequence");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph_AM_ChunkSequence, &parms);
}

