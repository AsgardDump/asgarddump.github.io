#include "SDK.h" 
 
 
void USceneComponent::Stop(){

	static UObject* p_Stop = UObject::FindObject<UFunction>("Function AudioMixer.SynthComponent.Stop");

	struct {
	} parms;


	ProcessEvent(p_Stop, &parms);
}

void USceneComponent::Start(){

	static UObject* p_Start = UObject::FindObject<UFunction>("Function AudioMixer.SynthComponent.Start");

	struct {
	} parms;


	ProcessEvent(p_Start, &parms);
}

void USceneComponent::SetVolumeMultiplier(float VolumeMultiplier){

	static UObject* p_SetVolumeMultiplier = UObject::FindObject<UFunction>("Function AudioMixer.SynthComponent.SetVolumeMultiplier");

	struct {
		float VolumeMultiplier;
	} parms;

	parms.VolumeMultiplier = VolumeMultiplier;

	ProcessEvent(p_SetVolumeMultiplier, &parms);
}

void USceneComponent::SetSubmixSend(struct USoundSubmixBase* Submix, float SendLevel){

	static UObject* p_SetSubmixSend = UObject::FindObject<UFunction>("Function AudioMixer.SynthComponent.SetSubmixSend");

	struct {
		struct USoundSubmixBase* Submix;
		float SendLevel;
	} parms;

	parms.Submix = Submix;
	parms.SendLevel = SendLevel;

	ProcessEvent(p_SetSubmixSend, &parms);
}

bool USceneComponent::IsPlaying(){

	static UObject* p_IsPlaying = UObject::FindObject<UFunction>("Function AudioMixer.SynthComponent.IsPlaying");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_IsPlaying, &parms);
	return parms.return_value;
}

float UBlueprintFunctionLibrary::TrimAudioCache(float InMegabytesToFree){

	static UObject* p_TrimAudioCache = UObject::FindObject<UFunction>("Function AudioMixer.AudioMixerBlueprintLibrary.TrimAudioCache");

	struct {
		float InMegabytesToFree;
		float return_value;
	} parms;

	parms.InMegabytesToFree = InMegabytesToFree;

	ProcessEvent(p_TrimAudioCache, &parms);
	return parms.return_value;
}

struct USoundWave* UBlueprintFunctionLibrary::StopRecordingOutput(struct UObject* WorldContextObject, uint8_t  ExportType, struct FString Name, struct FString Path, struct USoundSubmix* SubmixToRecord, struct USoundWave* ExistingSoundWaveToOverwrite){

	static UObject* p_StopRecordingOutput = UObject::FindObject<UFunction>("Function AudioMixer.AudioMixerBlueprintLibrary.StopRecordingOutput");

	struct {
		struct UObject* WorldContextObject;
		uint8_t  ExportType;
		struct FString Name;
		struct FString Path;
		struct USoundSubmix* SubmixToRecord;
		struct USoundWave* ExistingSoundWaveToOverwrite;
		struct USoundWave* return_value;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.ExportType = ExportType;
	parms.Name = Name;
	parms.Path = Path;
	parms.SubmixToRecord = SubmixToRecord;
	parms.ExistingSoundWaveToOverwrite = ExistingSoundWaveToOverwrite;

	ProcessEvent(p_StopRecordingOutput, &parms);
	return parms.return_value;
}

void UBlueprintFunctionLibrary::StopAnalyzingOutput(struct UObject* WorldContextObject, struct USoundSubmix* SubmixToStopAnalyzing){

	static UObject* p_StopAnalyzingOutput = UObject::FindObject<UFunction>("Function AudioMixer.AudioMixerBlueprintLibrary.StopAnalyzingOutput");

	struct {
		struct UObject* WorldContextObject;
		struct USoundSubmix* SubmixToStopAnalyzing;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.SubmixToStopAnalyzing = SubmixToStopAnalyzing;

	ProcessEvent(p_StopAnalyzingOutput, &parms);
}

void UBlueprintFunctionLibrary::StartRecordingOutput(struct UObject* WorldContextObject, float ExpectedDuration, struct USoundSubmix* SubmixToRecord){

	static UObject* p_StartRecordingOutput = UObject::FindObject<UFunction>("Function AudioMixer.AudioMixerBlueprintLibrary.StartRecordingOutput");

	struct {
		struct UObject* WorldContextObject;
		float ExpectedDuration;
		struct USoundSubmix* SubmixToRecord;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.ExpectedDuration = ExpectedDuration;
	parms.SubmixToRecord = SubmixToRecord;

	ProcessEvent(p_StartRecordingOutput, &parms);
}

void UBlueprintFunctionLibrary::StartAnalyzingOutput(struct UObject* WorldContextObject, struct USoundSubmix* SubmixToAnalyze, uint8_t  FFTSize, uint8_t  InterpolationMethod, uint8_t  WindowType, float HopSize){

	static UObject* p_StartAnalyzingOutput = UObject::FindObject<UFunction>("Function AudioMixer.AudioMixerBlueprintLibrary.StartAnalyzingOutput");

	struct {
		struct UObject* WorldContextObject;
		struct USoundSubmix* SubmixToAnalyze;
		uint8_t  FFTSize;
		uint8_t  InterpolationMethod;
		uint8_t  WindowType;
		float HopSize;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.SubmixToAnalyze = SubmixToAnalyze;
	parms.FFTSize = FFTSize;
	parms.InterpolationMethod = InterpolationMethod;
	parms.WindowType = WindowType;
	parms.HopSize = HopSize;

	ProcessEvent(p_StartAnalyzingOutput, &parms);
}

void UBlueprintFunctionLibrary::SetBypassSourceEffectChainEntry(struct UObject* WorldContextObject, struct USoundEffectSourcePresetChain* PresetChain, int32_t EntryIndex, bool bBypassed){

	static UObject* p_SetBypassSourceEffectChainEntry = UObject::FindObject<UFunction>("Function AudioMixer.AudioMixerBlueprintLibrary.SetBypassSourceEffectChainEntry");

	struct {
		struct UObject* WorldContextObject;
		struct USoundEffectSourcePresetChain* PresetChain;
		int32_t EntryIndex;
		bool bBypassed;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.PresetChain = PresetChain;
	parms.EntryIndex = EntryIndex;
	parms.bBypassed = bBypassed;

	ProcessEvent(p_SetBypassSourceEffectChainEntry, &parms);
}

void UBlueprintFunctionLibrary::ResumeRecordingOutput(struct UObject* WorldContextObject, struct USoundSubmix* SubmixToPause){

	static UObject* p_ResumeRecordingOutput = UObject::FindObject<UFunction>("Function AudioMixer.AudioMixerBlueprintLibrary.ResumeRecordingOutput");

	struct {
		struct UObject* WorldContextObject;
		struct USoundSubmix* SubmixToPause;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.SubmixToPause = SubmixToPause;

	ProcessEvent(p_ResumeRecordingOutput, &parms);
}

void UBlueprintFunctionLibrary::ReplaceSoundEffectSubmix(struct UObject* WorldContextObject, struct USoundSubmix* InSoundSubmix, int32_t SubmixChainIndex, struct USoundEffectSubmixPreset* SubmixEffectPreset){

	static UObject* p_ReplaceSoundEffectSubmix = UObject::FindObject<UFunction>("Function AudioMixer.AudioMixerBlueprintLibrary.ReplaceSoundEffectSubmix");

	struct {
		struct UObject* WorldContextObject;
		struct USoundSubmix* InSoundSubmix;
		int32_t SubmixChainIndex;
		struct USoundEffectSubmixPreset* SubmixEffectPreset;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.InSoundSubmix = InSoundSubmix;
	parms.SubmixChainIndex = SubmixChainIndex;
	parms.SubmixEffectPreset = SubmixEffectPreset;

	ProcessEvent(p_ReplaceSoundEffectSubmix, &parms);
}

void UBlueprintFunctionLibrary::RemoveSubmixEffectPresetAtIndex(struct UObject* WorldContextObject, struct USoundSubmix* SoundSubmix, int32_t SubmixChainIndex){

	static UObject* p_RemoveSubmixEffectPresetAtIndex = UObject::FindObject<UFunction>("Function AudioMixer.AudioMixerBlueprintLibrary.RemoveSubmixEffectPresetAtIndex");

	struct {
		struct UObject* WorldContextObject;
		struct USoundSubmix* SoundSubmix;
		int32_t SubmixChainIndex;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.SoundSubmix = SoundSubmix;
	parms.SubmixChainIndex = SubmixChainIndex;

	ProcessEvent(p_RemoveSubmixEffectPresetAtIndex, &parms);
}

void UBlueprintFunctionLibrary::RemoveSubmixEffectPreset(struct UObject* WorldContextObject, struct USoundSubmix* SoundSubmix, struct USoundEffectSubmixPreset* SubmixEffectPreset){

	static UObject* p_RemoveSubmixEffectPreset = UObject::FindObject<UFunction>("Function AudioMixer.AudioMixerBlueprintLibrary.RemoveSubmixEffectPreset");

	struct {
		struct UObject* WorldContextObject;
		struct USoundSubmix* SoundSubmix;
		struct USoundEffectSubmixPreset* SubmixEffectPreset;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.SoundSubmix = SoundSubmix;
	parms.SubmixEffectPreset = SubmixEffectPreset;

	ProcessEvent(p_RemoveSubmixEffectPreset, &parms);
}

void UBlueprintFunctionLibrary::RemoveSourceEffectFromPresetChain(struct UObject* WorldContextObject, struct USoundEffectSourcePresetChain* PresetChain, int32_t EntryIndex){

	static UObject* p_RemoveSourceEffectFromPresetChain = UObject::FindObject<UFunction>("Function AudioMixer.AudioMixerBlueprintLibrary.RemoveSourceEffectFromPresetChain");

	struct {
		struct UObject* WorldContextObject;
		struct USoundEffectSourcePresetChain* PresetChain;
		int32_t EntryIndex;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.PresetChain = PresetChain;
	parms.EntryIndex = EntryIndex;

	ProcessEvent(p_RemoveSourceEffectFromPresetChain, &parms);
}

void UBlueprintFunctionLibrary::RemoveMasterSubmixEffect(struct UObject* WorldContextObject, struct USoundEffectSubmixPreset* SubmixEffectPreset){

	static UObject* p_RemoveMasterSubmixEffect = UObject::FindObject<UFunction>("Function AudioMixer.AudioMixerBlueprintLibrary.RemoveMasterSubmixEffect");

	struct {
		struct UObject* WorldContextObject;
		struct USoundEffectSubmixPreset* SubmixEffectPreset;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.SubmixEffectPreset = SubmixEffectPreset;

	ProcessEvent(p_RemoveMasterSubmixEffect, &parms);
}

void UBlueprintFunctionLibrary::PrimeSoundForPlayback(struct USoundWave* SoundWave, struct FDelegate OnLoadCompletion){

	static UObject* p_PrimeSoundForPlayback = UObject::FindObject<UFunction>("Function AudioMixer.AudioMixerBlueprintLibrary.PrimeSoundForPlayback");

	struct {
		struct USoundWave* SoundWave;
		struct FDelegate OnLoadCompletion;
	} parms;

	parms.SoundWave = SoundWave;
	parms.OnLoadCompletion = OnLoadCompletion;

	ProcessEvent(p_PrimeSoundForPlayback, &parms);
}

void UBlueprintFunctionLibrary::PrimeSoundCueForPlayback(struct USoundCue* SoundCue){

	static UObject* p_PrimeSoundCueForPlayback = UObject::FindObject<UFunction>("Function AudioMixer.AudioMixerBlueprintLibrary.PrimeSoundCueForPlayback");

	struct {
		struct USoundCue* SoundCue;
	} parms;

	parms.SoundCue = SoundCue;

	ProcessEvent(p_PrimeSoundCueForPlayback, &parms);
}

void UBlueprintFunctionLibrary::PauseRecordingOutput(struct UObject* WorldContextObject, struct USoundSubmix* SubmixToPause){

	static UObject* p_PauseRecordingOutput = UObject::FindObject<UFunction>("Function AudioMixer.AudioMixerBlueprintLibrary.PauseRecordingOutput");

	struct {
		struct UObject* WorldContextObject;
		struct USoundSubmix* SubmixToPause;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.SubmixToPause = SubmixToPause;

	ProcessEvent(p_PauseRecordingOutput, &parms);
}

void UBlueprintFunctionLibrary::GetPhaseForFrequencies(struct UObject* WorldContextObject, struct TArray<float>& Frequencies, struct TArray<float>& Phases, struct USoundSubmix* SubmixToAnalyze){

	static UObject* p_GetPhaseForFrequencies = UObject::FindObject<UFunction>("Function AudioMixer.AudioMixerBlueprintLibrary.GetPhaseForFrequencies");

	struct {
		struct UObject* WorldContextObject;
		struct TArray<float>& Frequencies;
		struct TArray<float>& Phases;
		struct USoundSubmix* SubmixToAnalyze;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.Frequencies = Frequencies;
	parms.Phases = Phases;
	parms.SubmixToAnalyze = SubmixToAnalyze;

	ProcessEvent(p_GetPhaseForFrequencies, &parms);
}

int32_t UBlueprintFunctionLibrary::GetNumberOfEntriesInSourceEffectChain(struct UObject* WorldContextObject, struct USoundEffectSourcePresetChain* PresetChain){

	static UObject* p_GetNumberOfEntriesInSourceEffectChain = UObject::FindObject<UFunction>("Function AudioMixer.AudioMixerBlueprintLibrary.GetNumberOfEntriesInSourceEffectChain");

	struct {
		struct UObject* WorldContextObject;
		struct USoundEffectSourcePresetChain* PresetChain;
		int32_t return_value;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.PresetChain = PresetChain;

	ProcessEvent(p_GetNumberOfEntriesInSourceEffectChain, &parms);
	return parms.return_value;
}

void UBlueprintFunctionLibrary::GetMagnitudeForFrequencies(struct UObject* WorldContextObject, struct TArray<float>& Frequencies, struct TArray<float>& Magnitudes, struct USoundSubmix* SubmixToAnalyze){

	static UObject* p_GetMagnitudeForFrequencies = UObject::FindObject<UFunction>("Function AudioMixer.AudioMixerBlueprintLibrary.GetMagnitudeForFrequencies");

	struct {
		struct UObject* WorldContextObject;
		struct TArray<float>& Frequencies;
		struct TArray<float>& Magnitudes;
		struct USoundSubmix* SubmixToAnalyze;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.Frequencies = Frequencies;
	parms.Magnitudes = Magnitudes;
	parms.SubmixToAnalyze = SubmixToAnalyze;

	ProcessEvent(p_GetMagnitudeForFrequencies, &parms);
}

void UBlueprintFunctionLibrary::ClearSubmixEffects(struct UObject* WorldContextObject, struct USoundSubmix* SoundSubmix){

	static UObject* p_ClearSubmixEffects = UObject::FindObject<UFunction>("Function AudioMixer.AudioMixerBlueprintLibrary.ClearSubmixEffects");

	struct {
		struct UObject* WorldContextObject;
		struct USoundSubmix* SoundSubmix;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.SoundSubmix = SoundSubmix;

	ProcessEvent(p_ClearSubmixEffects, &parms);
}

void UBlueprintFunctionLibrary::ClearMasterSubmixEffects(struct UObject* WorldContextObject){

	static UObject* p_ClearMasterSubmixEffects = UObject::FindObject<UFunction>("Function AudioMixer.AudioMixerBlueprintLibrary.ClearMasterSubmixEffects");

	struct {
		struct UObject* WorldContextObject;
	} parms;

	parms.WorldContextObject = WorldContextObject;

	ProcessEvent(p_ClearMasterSubmixEffects, &parms);
}

int32_t UBlueprintFunctionLibrary::AddSubmixEffect(struct UObject* WorldContextObject, struct USoundSubmix* SoundSubmix, struct USoundEffectSubmixPreset* SubmixEffectPreset){

	static UObject* p_AddSubmixEffect = UObject::FindObject<UFunction>("Function AudioMixer.AudioMixerBlueprintLibrary.AddSubmixEffect");

	struct {
		struct UObject* WorldContextObject;
		struct USoundSubmix* SoundSubmix;
		struct USoundEffectSubmixPreset* SubmixEffectPreset;
		int32_t return_value;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.SoundSubmix = SoundSubmix;
	parms.SubmixEffectPreset = SubmixEffectPreset;

	ProcessEvent(p_AddSubmixEffect, &parms);
	return parms.return_value;
}

void UBlueprintFunctionLibrary::AddSourceEffectToPresetChain(struct UObject* WorldContextObject, struct USoundEffectSourcePresetChain* PresetChain, struct FSourceEffectChainEntry Entry){

	static UObject* p_AddSourceEffectToPresetChain = UObject::FindObject<UFunction>("Function AudioMixer.AudioMixerBlueprintLibrary.AddSourceEffectToPresetChain");

	struct {
		struct UObject* WorldContextObject;
		struct USoundEffectSourcePresetChain* PresetChain;
		struct FSourceEffectChainEntry Entry;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.PresetChain = PresetChain;
	parms.Entry = Entry;

	ProcessEvent(p_AddSourceEffectToPresetChain, &parms);
}

void UBlueprintFunctionLibrary::AddMasterSubmixEffect(struct UObject* WorldContextObject, struct USoundEffectSubmixPreset* SubmixEffectPreset){

	static UObject* p_AddMasterSubmixEffect = UObject::FindObject<UFunction>("Function AudioMixer.AudioMixerBlueprintLibrary.AddMasterSubmixEffect");

	struct {
		struct UObject* WorldContextObject;
		struct USoundEffectSubmixPreset* SubmixEffectPreset;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.SubmixEffectPreset = SubmixEffectPreset;

	ProcessEvent(p_AddMasterSubmixEffect, &parms);
}

void USoundEffectSubmixPreset::SetSettings(struct FSubmixEffectDynamicsProcessorSettings& Settings){

	static UObject* p_SetSettings = UObject::FindObject<UFunction>("Function AudioMixer.SubmixEffectDynamicsProcessorPreset.SetSettings");

	struct {
		struct FSubmixEffectDynamicsProcessorSettings& Settings;
	} parms;

	parms.Settings = Settings;

	ProcessEvent(p_SetSettings, &parms);
}

void USoundEffectSubmixPreset::SetExternalSubmix(struct USoundSubmix* Submix){

	static UObject* p_SetExternalSubmix = UObject::FindObject<UFunction>("Function AudioMixer.SubmixEffectDynamicsProcessorPreset.SetExternalSubmix");

	struct {
		struct USoundSubmix* Submix;
	} parms;

	parms.Submix = Submix;

	ProcessEvent(p_SetExternalSubmix, &parms);
}

void USoundEffectSubmixPreset::SetSettingsWithReverbEffect(struct UReverbEffect* InReverbEffect, float WetLevel, float DryLevel){

	static UObject* p_SetSettingsWithReverbEffect = UObject::FindObject<UFunction>("Function AudioMixer.SubmixEffectReverbFastPreset.SetSettingsWithReverbEffect");

	struct {
		struct UReverbEffect* InReverbEffect;
		float WetLevel;
		float DryLevel;
	} parms;

	parms.InReverbEffect = InReverbEffect;
	parms.WetLevel = WetLevel;
	parms.DryLevel = DryLevel;

	ProcessEvent(p_SetSettingsWithReverbEffect, &parms);
}

void USoundEffectSubmixPreset::SetSettings(struct FSubmixEffectReverbFastSettings& InSettings){

	static UObject* p_SetSettings = UObject::FindObject<UFunction>("Function AudioMixer.SubmixEffectReverbFastPreset.SetSettings");

	struct {
		struct FSubmixEffectReverbFastSettings& InSettings;
	} parms;

	parms.InSettings = InSettings;

	ProcessEvent(p_SetSettings, &parms);
}

void USoundEffectSubmixPreset::SetSettings(struct FSubmixEffectSubmixEQSettings& InSettings){

	static UObject* p_SetSettings = UObject::FindObject<UFunction>("Function AudioMixer.SubmixEffectSubmixEQPreset.SetSettings");

	struct {
		struct FSubmixEffectSubmixEQSettings& InSettings;
	} parms;

	parms.InSettings = InSettings;

	ProcessEvent(p_SetSettings, &parms);
}

void USoundEffectSubmixPreset::SetSettingsWithReverbEffect(struct UReverbEffect* InReverbEffect, float WetLevel, float DryLevel){

	static UObject* p_SetSettingsWithReverbEffect = UObject::FindObject<UFunction>("Function AudioMixer.SubmixEffectReverbPreset.SetSettingsWithReverbEffect");

	struct {
		struct UReverbEffect* InReverbEffect;
		float WetLevel;
		float DryLevel;
	} parms;

	parms.InReverbEffect = InReverbEffect;
	parms.WetLevel = WetLevel;
	parms.DryLevel = DryLevel;

	ProcessEvent(p_SetSettingsWithReverbEffect, &parms);
}

void USoundEffectSubmixPreset::SetSettings(struct FSubmixEffectReverbSettings& InSettings){

	static UObject* p_SetSettings = UObject::FindObject<UFunction>("Function AudioMixer.SubmixEffectReverbPreset.SetSettings");

	struct {
		struct FSubmixEffectReverbSettings& InSettings;
	} parms;

	parms.InSettings = InSettings;

	ProcessEvent(p_SetSettings, &parms);
}

