#pragma once 
#include <BasicWidgetQueue_BP_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass BasicWidgetQueue_BP.BasicWidgetQueue_BP_C
// Size: 0x288(Inherited: 0x288) 
struct UBasicWidgetQueue_BP_C : public UTwWidgetQueue
{

}; 



