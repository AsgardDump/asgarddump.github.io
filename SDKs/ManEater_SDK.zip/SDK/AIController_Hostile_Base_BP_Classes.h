#pragma once 
#include <AIController_Hostile_Base_BP_Structs.h>
 
 
 
// BlueprintGeneratedClass AIController_Hostile_Base_BP.AIController_Hostile_Base_BP_C
// Size: 0x7C8(Inherited: 0x7C8) 
struct AAIController_Hostile_Base_BP_C : public AME_AnimalAIController
{

}; 



