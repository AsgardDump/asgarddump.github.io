#pragma once 
#include <AM_StationaryWaterReentryForwardsAndUp_Structs.h>
 
 
 
// BlueprintGeneratedClass AM_StationaryWaterReentryForwardsAndUp.AM_StationaryWaterReentryForwardsAndUp_C
// Size: 0x620(Inherited: 0x620) 
struct UAM_StationaryWaterReentryForwardsAndUp_C : public UME_GameplayAbilitySharkMontage
{

}; 



