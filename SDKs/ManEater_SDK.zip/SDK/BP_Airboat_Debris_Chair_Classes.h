#pragma once 
#include <BP_Airboat_Debris_Chair_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Airboat_Debris_Chair.BP_Airboat_Debris_Chair_C
// Size: 0x230(Inherited: 0x230) 
struct ABP_Airboat_Debris_Chair_C : public ABP_VehicleDebris_C
{

	int32_t GetSizeLevel(struct AME_AnimalCharacter* GrabbingAnimal); // Function BP_Airboat_Debris_Chair.BP_Airboat_Debris_Chair_C.GetSizeLevel
}; 



