#pragma once 
#include <AM_StationaryWaterReentryForwardsAndDown_Structs.h>
 
 
 
// BlueprintGeneratedClass AM_StationaryWaterReentryForwardsAndDown.AM_StationaryWaterReentryForwardsAndDown_C
// Size: 0x620(Inherited: 0x620) 
struct UAM_StationaryWaterReentryForwardsAndDown_C : public UME_GameplayAbilitySharkMontage
{

}; 



