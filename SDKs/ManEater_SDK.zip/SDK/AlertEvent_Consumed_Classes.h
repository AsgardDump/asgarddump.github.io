#pragma once 
#include <AlertEvent_Consumed_Structs.h>
 
 
 
// BlueprintGeneratedClass AlertEvent_Consumed.AlertEvent_Consumed_C
// Size: 0x90(Inherited: 0x90) 
struct UAlertEvent_Consumed_C : public UME_AlertEvent
{

}; 



