#pragma once 
#include <AM_TailWhip_FullMouth_Structs.h>
 
 
 
// BlueprintGeneratedClass AM_TailWhip_FullMouth.AM_TailWhip_FullMouth_C
// Size: 0x620(Inherited: 0x620) 
struct UAM_TailWhip_FullMouth_C : public UME_GameplayAbilitySharkMontage
{

}; 



