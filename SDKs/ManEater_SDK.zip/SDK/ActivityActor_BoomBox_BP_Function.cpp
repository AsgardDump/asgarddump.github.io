#include "SDK.h" 
 
 
void ADestructibleActivity_Base_BP_C::ReceiveBeginPlay(){

	static UObject* p_ReceiveBeginPlay = UObject::FindObject<UFunction>("Function ActivityActor_BoomBox_BP.ActivityActor_BoomBox_BP_C.ReceiveBeginPlay");

	struct {
	} parms;


	ProcessEvent(p_ReceiveBeginPlay, &parms);
}

void ADestructibleActivity_Base_BP_C::Music On(){

	static UObject* p_Music On = UObject::FindObject<UFunction>("Function ActivityActor_BoomBox_BP.ActivityActor_BoomBox_BP_C.Music On");

	struct {
	} parms;


	ProcessEvent(p_Music On, &parms);
}

void ADestructibleActivity_Base_BP_C::Music Off(){

	static UObject* p_Music Off = UObject::FindObject<UFunction>("Function ActivityActor_BoomBox_BP.ActivityActor_BoomBox_BP_C.Music Off");

	struct {
	} parms;


	ProcessEvent(p_Music Off, &parms);
}

void ADestructibleActivity_Base_BP_C::ToggleDestruct(){

	static UObject* p_ToggleDestruct = UObject::FindObject<UFunction>("Function ActivityActor_BoomBox_BP.ActivityActor_BoomBox_BP_C.ToggleDestruct");

	struct {
	} parms;


	ProcessEvent(p_ToggleDestruct, &parms);
}

void ADestructibleActivity_Base_BP_C::ExecuteUbergraph_ActivityActor_BoomBox_BP(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph_ActivityActor_BoomBox_BP = UObject::FindObject<UFunction>("Function ActivityActor_BoomBox_BP.ActivityActor_BoomBox_BP_C.ExecuteUbergraph_ActivityActor_BoomBox_BP");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph_ActivityActor_BoomBox_BP, &parms);
}

