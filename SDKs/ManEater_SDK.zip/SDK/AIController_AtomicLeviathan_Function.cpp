#include "SDK.h" 
 
 
void AAIController_Hostile_Base_BP_C::ReceiveBeginPlay(){

	static UObject* p_ReceiveBeginPlay = UObject::FindObject<UFunction>("Function AIController_AtomicLeviathan.AIController_AtomicLeviathan_C.ReceiveBeginPlay");

	struct {
	} parms;


	ProcessEvent(p_ReceiveBeginPlay, &parms);
}

void AAIController_Hostile_Base_BP_C::ThreatStateHasChanged_Event(char EAIThreatAlertState NewAlertState, struct AActor* InstigatingActor){

	static UObject* p_ThreatStateHasChanged_Event = UObject::FindObject<UFunction>("Function AIController_AtomicLeviathan.AIController_AtomicLeviathan_C.ThreatStateHasChanged_Event");

	struct {
		char EAIThreatAlertState NewAlertState;
		struct AActor* InstigatingActor;
	} parms;

	parms.NewAlertState = NewAlertState;
	parms.InstigatingActor = InstigatingActor;

	ProcessEvent(p_ThreatStateHasChanged_Event, &parms);
}

void AAIController_Hostile_Base_BP_C::ExecuteUbergraph_AIController_AtomicLeviathan(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph_AIController_AtomicLeviathan = UObject::FindObject<UFunction>("Function AIController_AtomicLeviathan.AIController_AtomicLeviathan_C.ExecuteUbergraph_AIController_AtomicLeviathan");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph_AIController_AtomicLeviathan, &parms);
}

