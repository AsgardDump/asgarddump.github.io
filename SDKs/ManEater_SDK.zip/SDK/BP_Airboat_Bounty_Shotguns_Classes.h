#pragma once 
#include <BP_Airboat_Bounty_Shotguns_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Airboat_Bounty_Shotguns.BP_Airboat_Bounty_Shotguns_C
// Size: 0xDA4(Inherited: 0xDA4) 
struct ABP_Airboat_Bounty_Shotguns_C : public ABP_Base_Airboat_Bounty_C
{

}; 



