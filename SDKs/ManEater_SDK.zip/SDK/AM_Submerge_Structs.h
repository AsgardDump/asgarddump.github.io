#pragma once 
#include "SDK.h" 
 
 
// Function AM_Submerge.AM_Submerge_C.ExecuteUbergraph_AM_Submerge
// Size: 0x28(Inherited: 0x0) 
struct FExecuteUbergraph_AM_Submerge
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AActor* CallFunc_GetOwningActorFromActorInfo_ReturnValue;  // 0x8(0x8)
	struct AME_PlayerSharkCharacter* K2Node_DynamicCast_AsME_Player_Shark_Character;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct UME_PlayerSharkMovementComponent* CallFunc_GetPlayerSharkMovement_ReturnValue;  // 0x20(0x8)

}; 
