#pragma once 
#include <AudioSettingsMenuPanel_BP_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass AudioSettingsMenuPanel_BP.AudioSettingsMenuPanel_BP_C
// Size: 0x2C8(Inherited: 0x298) 
struct UAudioSettingsMenuPanel_BP_C : public UTwBaseMenuPanel
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x298(0x8)
	struct USettingsStepper_BP_C* DialogStepper;  // 0x2A0(0x8)
	struct USettingsStepper_BP_C* MasterStepper;  // 0x2A8(0x8)
	struct USettingsStepper_BP_C* MusicStepper;  // 0x2B0(0x8)
	struct USettingsStepper_BP_C* NarratorStepper;  // 0x2B8(0x8)
	struct USettingsStepper_BP_C* SFX_Stepper;  // 0x2C0(0x8)

	void NarratorVolumeChanged(int32_t Index); // Function AudioSettingsMenuPanel_BP.AudioSettingsMenuPanel_BP_C.NarratorVolumeChanged
	void DialogVolumeChanged(int32_t Index); // Function AudioSettingsMenuPanel_BP.AudioSettingsMenuPanel_BP_C.DialogVolumeChanged
	void SFXVolumeChanged(int32_t Index); // Function AudioSettingsMenuPanel_BP.AudioSettingsMenuPanel_BP_C.SFXVolumeChanged
	void MusicVolumeChanged(int32_t Index); // Function AudioSettingsMenuPanel_BP.AudioSettingsMenuPanel_BP_C.MusicVolumeChanged
	void MasterVolumeChanged(int32_t Index); // Function AudioSettingsMenuPanel_BP.AudioSettingsMenuPanel_BP_C.MasterVolumeChanged
	struct UWidget* GetDefaultFocusWidget(); // Function AudioSettingsMenuPanel_BP.AudioSettingsMenuPanel_BP_C.GetDefaultFocusWidget
	void Construct(); // Function AudioSettingsMenuPanel_BP.AudioSettingsMenuPanel_BP_C.Construct
	void ExecuteUbergraph_AudioSettingsMenuPanel_BP(int32_t EntryPoint); // Function AudioSettingsMenuPanel_BP.AudioSettingsMenuPanel_BP_C.ExecuteUbergraph_AudioSettingsMenuPanel_BP
}; 



