#pragma once 
#include <AIController_Catfish_BP_Structs.h>
 
 
 
// BlueprintGeneratedClass AIController_Catfish_BP.AIController_Catfish_BP_C
// Size: 0x7C8(Inherited: 0x7C8) 
struct AAIController_Catfish_BP_C : public AAIController_NonHostile_Base_BP_C
{

}; 



