#pragma once 
#include <AM_StartThrashDown_Structs.h>
 
 
 
// BlueprintGeneratedClass AM_StartThrashDown.AM_StartThrashDown_C
// Size: 0x620(Inherited: 0x620) 
struct UAM_StartThrashDown_C : public UME_GameplayAbilitySharkMontage
{

}; 



