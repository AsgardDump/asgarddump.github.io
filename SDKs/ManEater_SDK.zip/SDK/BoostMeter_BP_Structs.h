#pragma once 
#include "SDK.h" 
 
 
// Function BoostMeter_BP.BoostMeter_BP_C.UnsubscribeFromEvents_BP
// Size: 0x8(Inherited: 0x8) 
struct FUnsubscribeFromEvents_BP : public FUnsubscribeFromEvents_BP
{
	struct AHUD* HUD;  // 0x0(0x8)

}; 
// Function BoostMeter_BP.BoostMeter_BP_C.ExecuteUbergraph_BoostMeter_BP
// Size: 0x60(Inherited: 0x0) 
struct FExecuteUbergraph_BoostMeter_BP
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AHUD* K2Node_Event_HUD_2;  // 0x8(0x8)
	struct FGameplayTagContainer K2Node_CustomEvent_TagsAdded_2;  // 0x10(0x20)
	float K2Node_CustomEvent_TagDuration;  // 0x30(0x4)
	char pad_52[4];  // 0x34(0x4)
	struct AHUD* K2Node_Event_HUD;  // 0x38(0x8)
	struct FGameplayTagContainer K2Node_CustomEvent_TagsAdded;  // 0x40(0x20)

}; 
// Function BoostMeter_BP.BoostMeter_BP_C.GameplayTagRemoved
// Size: 0x20(Inherited: 0x0) 
struct FGameplayTagRemoved
{
	struct FGameplayTagContainer TagsAdded;  // 0x0(0x20)

}; 
// Function BoostMeter_BP.BoostMeter_BP_C.UpdateLocalTagContainer
// Size: 0x4B(Inherited: 0x0) 
struct FUpdateLocalTagContainer
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bAdded : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FGameplayTagContainer TagContainer;  // 0x8(0x20)
	float TagDuration;  // 0x28(0x4)
	char pad_44_1 : 7;  // 0x2C(0x1)
	bool TagsChangedDirtyFlag : 1;  // 0x2C(0x1)
	char pad_45[3];  // 0x2D(0x3)
	int32_t Temp_int_Array_Index_Variable;  // 0x30(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x34(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x38(0x4)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x3C(0x4)
	struct FGameplayTag CallFunc_Array_Get_Item;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x48(0x1)
	char pad_73_1 : 7;  // 0x49(0x1)
	bool CallFunc_RemoveGameplayTag_ReturnValue : 1;  // 0x49(0x1)
	char pad_74_1 : 7;  // 0x4A(0x1)
	bool CallFunc_HasTag_ReturnValue : 1;  // 0x4A(0x1)

}; 
// Function BoostMeter_BP.BoostMeter_BP_C.SubscribeToEvents_BP
// Size: 0x8(Inherited: 0x8) 
struct FSubscribeToEvents_BP : public FSubscribeToEvents_BP
{
	struct AHUD* HUD;  // 0x0(0x8)

}; 
// Function BoostMeter_BP.BoostMeter_BP_C.GameplayTagAdded
// Size: 0x24(Inherited: 0x0) 
struct FGameplayTagAdded
{
	struct FGameplayTagContainer TagsAdded;  // 0x0(0x20)
	float TagDuration;  // 0x20(0x4)

}; 
// Function BoostMeter_BP.BoostMeter_BP_C.ProcessTagChange
// Size: 0x21(Inherited: 0x0) 
struct FProcessTagChange
{
	int32_t Temp_int_Variable;  // 0x0(0x4)
	float Temp_float_Variable;  // 0x4(0x4)
	float Temp_float_Variable_2;  // 0x8(0x4)
	float Temp_float_Variable_3;  // 0xC(0x4)
	float Temp_float_Variable_4;  // 0x10(0x4)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool Temp_bool_Variable : 1;  // 0x14(0x1)
	uint8_t  Temp_byte_Variable;  // 0x15(0x1)
	uint8_t  Temp_byte_Variable_2;  // 0x16(0x1)
	char pad_23[1];  // 0x17(0x1)
	float K2Node_Select_Default;  // 0x18(0x4)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue : 1;  // 0x1C(0x1)
	char pad_29_1 : 7;  // 0x1D(0x1)
	bool CallFunc_HasTag_ReturnValue : 1;  // 0x1D(0x1)
	uint8_t  K2Node_Select_Default_2;  // 0x1E(0x1)
	char pad_31_1 : 7;  // 0x1F(0x1)
	bool CallFunc_HasTag_ReturnValue_2 : 1;  // 0x1F(0x1)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_HasTag_ReturnValue_3 : 1;  // 0x20(0x1)

}; 
