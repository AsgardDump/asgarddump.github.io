#pragma once 
#include <AM_StationaryWaterReentryBackwardsAndUp_Structs.h>
 
 
 
// BlueprintGeneratedClass AM_StationaryWaterReentryBackwardsAndUp.AM_StationaryWaterReentryBackwardsAndUp_C
// Size: 0x620(Inherited: 0x620) 
struct UAM_StationaryWaterReentryBackwardsAndUp_C : public UME_GameplayAbilitySharkMontage
{

}; 



