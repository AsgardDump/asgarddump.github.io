#pragma once 
#include "SDK.h" 
 
 
// Function AM_KillSequence.AM_KillSequence_C.ExecuteUbergraph_AM_KillSequence
// Size: 0x19(Inherited: 0x0) 
struct FExecuteUbergraph_AM_KillSequence
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AME_PlayerSharkCharacter* CallFunc_GetPlayerSharkPawn_ReturnValue;  // 0x8(0x8)
	struct UAnimMontage* K2Node_Event_Montage;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_Event_bInterrupted : 1;  // 0x18(0x1)

}; 
// Function AM_KillSequence.AM_KillSequence_C.MontageEnded
// Size: 0x9(Inherited: 0x10) 
struct FMontageEnded : public FMontageEnded
{
	struct UAnimMontage* Montage;  // 0x0(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool bInterrupted : 1;  // 0x8(0x1)

}; 
