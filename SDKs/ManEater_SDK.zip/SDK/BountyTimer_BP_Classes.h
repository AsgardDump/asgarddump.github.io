#pragma once 
#include <BountyTimer_BP_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass BountyTimer_BP.BountyTimer_BP_C
// Size: 0x3F8(Inherited: 0x3F8) 
struct UBountyTimer_BP_C : public UBountyTimer
{

}; 



