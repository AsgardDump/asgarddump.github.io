#pragma once 
#include <AM_StartThrashUp_Structs.h>
 
 
 
// BlueprintGeneratedClass AM_StartThrashUp.AM_StartThrashUp_C
// Size: 0x620(Inherited: 0x620) 
struct UAM_StartThrashUp_C : public UAM_StartThrashDown_C
{

}; 



