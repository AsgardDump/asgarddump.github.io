#pragma once 
#include <ApexSpawnToast_BP_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass ApexSpawnToast_BP.ApexSpawnToast_BP_C
// Size: 0x298(Inherited: 0x278) 
struct UApexSpawnToast_BP_C : public UMEApexSpawnToast
{
	struct UWidgetAnimation* OutAnimation;  // 0x278(0x8)
	struct UWidgetAnimation* InAnimation;  // 0x280(0x8)
	struct UImage* Image_1;  // 0x288(0x8)
	struct UTwInputAwareRichTextBlock* TwInputAwareRichTextBlock_1;  // 0x290(0x8)

}; 



