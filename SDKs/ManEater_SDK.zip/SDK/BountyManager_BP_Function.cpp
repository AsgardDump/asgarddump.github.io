#include "SDK.h" 
 
 
void AME_BountyManager::Infamy Rank Up(int32_t Rank){

	static UObject* p_Infamy Rank Up = UObject::FindObject<UFunction>("Function BountyManager_BP.BountyManager_BP_C.Infamy Rank Up");

	struct {
		int32_t Rank;
	} parms;

	parms.Rank = Rank;

	ProcessEvent(p_Infamy Rank Up, &parms);
}

void AME_BountyManager::Bounty Beginning(){

	static UObject* p_Bounty Beginning = UObject::FindObject<UFunction>("Function BountyManager_BP.BountyManager_BP_C.Bounty Beginning");

	struct {
	} parms;


	ProcessEvent(p_Bounty Beginning, &parms);
}

void AME_BountyManager::Bounty Ending(){

	static UObject* p_Bounty Ending = UObject::FindObject<UFunction>("Function BountyManager_BP.BountyManager_BP_C.Bounty Ending");

	struct {
	} parms;


	ProcessEvent(p_Bounty Ending, &parms);
}

void AME_BountyManager::ReceiveBeginPlay(){

	static UObject* p_ReceiveBeginPlay = UObject::FindObject<UFunction>("Function BountyManager_BP.BountyManager_BP_C.ReceiveBeginPlay");

	struct {
	} parms;


	ProcessEvent(p_ReceiveBeginPlay, &parms);
}

void AME_BountyManager::ExecuteUbergraph_BountyManager_BP(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph_BountyManager_BP = UObject::FindObject<UFunction>("Function BountyManager_BP.BountyManager_BP_C.ExecuteUbergraph_BountyManager_BP");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph_BountyManager_BP, &parms);
}

