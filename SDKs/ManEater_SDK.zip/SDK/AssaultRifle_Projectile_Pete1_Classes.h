#pragma once 
#include <AssaultRifle_Projectile_Pete1_Structs.h>
 
 
 
// BlueprintGeneratedClass AssaultRifle_Projectile_Pete1.AssaultRifle_Projectile_Pete1_C
// Size: 0x270(Inherited: 0x270) 
struct AAssaultRifle_Projectile_Pete1_C : public ABulletprojectile_C
{

}; 



