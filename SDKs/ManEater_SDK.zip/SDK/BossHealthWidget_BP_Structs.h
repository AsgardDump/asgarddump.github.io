#pragma once 
#include "SDK.h" 
 
 
// Function BossHealthWidget_BP.BossHealthWidget_BP_C.HandleVisiblityState
// Size: 0x2(Inherited: 0x0) 
struct FHandleVisiblityState
{
	char EBossUIType BossUIType;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x1(0x1)

}; 
// Function BossHealthWidget_BP.BossHealthWidget_BP_C.ExecuteUbergraph_BossHealthWidget_BP
// Size: 0x10(Inherited: 0x0) 
struct FExecuteUbergraph_BossHealthWidget_BP
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UUMGSequencePlayer* CallFunc_PlayAnimation_ReturnValue;  // 0x8(0x8)

}; 
// Function BossHealthWidget_BP.BossHealthWidget_BP_C.UpdateShieldHealthPercent
// Size: 0x4(Inherited: 0x0) 
struct FUpdateShieldHealthPercent
{
	float InPercent;  // 0x0(0x4)

}; 
// Function BossHealthWidget_BP.BossHealthWidget_BP_C.OnHealthBarMadeVisible
// Size: 0x50(Inherited: 0x0) 
struct FOnHealthBarMadeVisible
{
	struct FText FirstName;  // 0x0(0x18)
	struct FText LastName;  // 0x18(0x18)
	float Health;  // 0x30(0x4)
	char pad_52[4];  // 0x34(0x4)
	struct FText ShieldName;  // 0x38(0x18)

}; 
// Function BossHealthWidget_BP.BossHealthWidget_BP_C.UpdateHealthPercent
// Size: 0x4(Inherited: 0x0) 
struct FUpdateHealthPercent
{
	float InPercent;  // 0x0(0x4)

}; 
// Function BossHealthWidget_BP.BossHealthWidget_BP_C.UpdateTimer
// Size: 0x40(Inherited: 0x0) 
struct FUpdateTimer
{
	float Time;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FString CallFunc_TimeSecondsToString_ReturnValue;  // 0x8(0x10)
	struct FString CallFunc_LeftChop_ReturnValue;  // 0x18(0x10)
	struct FText CallFunc_Conv_StringToText_ReturnValue;  // 0x28(0x18)

}; 
// Function BossHealthWidget_BP.BossHealthWidget_BP_C.UpdateDefeatProgress
// Size: 0x90(Inherited: 0x0) 
struct FUpdateDefeatProgress
{
	int32_t Progress;  // 0x0(0x4)
	int32_t NumToDefeat;  // 0x4(0x4)
	struct FText CallFunc_Conv_IntToText_ReturnValue;  // 0x8(0x18)
	struct FText CallFunc_Conv_IntToText_ReturnValue_2;  // 0x20(0x18)
	struct FString CallFunc_Conv_TextToString_ReturnValue;  // 0x38(0x10)
	struct FString CallFunc_Conv_TextToString_ReturnValue_2;  // 0x48(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0x58(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_2;  // 0x68(0x10)
	struct FText CallFunc_Conv_StringToText_ReturnValue;  // 0x78(0x18)

}; 
