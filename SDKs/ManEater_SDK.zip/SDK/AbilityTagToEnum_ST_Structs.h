#pragma once 
#include "SDK.h" 
 
 
// UserDefinedStruct AbilityTagToEnum_ST.AbilityTagToEnum_ST
// Size: 0x1(Inherited: 0x0) 
struct FAbilityTagToEnum_ST
{
	char Ability_Enum AbilityEnum_2_E0E832F04221B1C8A15D738CF43D948F;  // 0x0(0x1)

}; 
