#include "SDK.h" 
 
 
struct FImpactEffect UBP_Base_IR_C::GetImpactEffects(char EPhysicalSurface ImpactingSurface, bool bUnderwater, bool bScrape){

	static UObject* p_GetImpactEffects = UObject::FindObject<UFunction>("Function BP_APEX_MED_Thrash_IR.BP_APEX_MED_Thrash_IR_C.GetImpactEffects");

	struct {
		char EPhysicalSurface ImpactingSurface;
		bool bUnderwater;
		bool bScrape;
		struct FImpactEffect return_value;
	} parms;

	parms.ImpactingSurface = ImpactingSurface;
	parms.bUnderwater = bUnderwater;
	parms.bScrape = bScrape;

	ProcessEvent(p_GetImpactEffects, &parms);
	return parms.return_value;
}

