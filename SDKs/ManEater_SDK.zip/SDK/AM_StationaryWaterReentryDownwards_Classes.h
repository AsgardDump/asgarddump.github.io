#pragma once 
#include <AM_StationaryWaterReentryDownwards_Structs.h>
 
 
 
// BlueprintGeneratedClass AM_StationaryWaterReentryDownwards.AM_StationaryWaterReentryDownwards_C
// Size: 0x620(Inherited: 0x620) 
struct UAM_StationaryWaterReentryDownwards_C : public UME_GameplayAbilitySharkMontage
{

}; 



