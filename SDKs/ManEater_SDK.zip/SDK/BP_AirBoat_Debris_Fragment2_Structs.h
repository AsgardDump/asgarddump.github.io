#pragma once 
#include "SDK.h" 
 
 
// Function BP_AirBoat_Debris_Fragment2.BP_AirBoat_Debris_Fragment2_C.GetSizeLevel
// Size: 0xC(Inherited: 0x0) 
struct FGetSizeLevel
{
	struct AME_AnimalCharacter* GrabbingAnimal;  // 0x0(0x8)
	int32_t ReturnValue;  // 0x8(0x4)

}; 
