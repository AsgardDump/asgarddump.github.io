#pragma once 
#include <ActivityActor_BoomBox_BP_Structs.h>
 
 
 
// BlueprintGeneratedClass ActivityActor_BoomBox_BP.ActivityActor_BoomBox_BP_C
// Size: 0x2A9(Inherited: 0x280) 
struct AActivityActor_BoomBox_BP_C : public ADestructibleActivity_Base_BP_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x280(0x8)
	struct UVoiceGroupComponent_BP_C* VoiceGroupComponent_BP;  // 0x288(0x8)
	struct UAkAudioEvent* MusicToPlay;  // 0x290(0x8)
	char pad_664_1 : 7;  // 0x298(0x1)
	bool AlawysOn? : 1;  // 0x298(0x1)
	char pad_665[7];  // 0x299(0x7)
	struct AActor* SoundLocation;  // 0x2A0(0x8)
	char pad_680_1 : 7;  // 0x2A8(0x1)
	bool Destroied? : 1;  // 0x2A8(0x1)

	void ReceiveBeginPlay(); // Function ActivityActor_BoomBox_BP.ActivityActor_BoomBox_BP_C.ReceiveBeginPlay
	void Music On(); // Function ActivityActor_BoomBox_BP.ActivityActor_BoomBox_BP_C.Music On
	void Music Off(); // Function ActivityActor_BoomBox_BP.ActivityActor_BoomBox_BP_C.Music Off
	void ToggleDestruct(); // Function ActivityActor_BoomBox_BP.ActivityActor_BoomBox_BP_C.ToggleDestruct
	void ExecuteUbergraph_ActivityActor_BoomBox_BP(int32_t EntryPoint); // Function ActivityActor_BoomBox_BP.ActivityActor_BoomBox_BP_C.ExecuteUbergraph_ActivityActor_BoomBox_BP
}; 



