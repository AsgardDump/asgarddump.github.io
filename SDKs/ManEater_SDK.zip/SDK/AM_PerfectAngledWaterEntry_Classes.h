#pragma once 
#include <AM_PerfectAngledWaterEntry_Structs.h>
 
 
 
// BlueprintGeneratedClass AM_PerfectAngledWaterEntry.AM_PerfectAngledWaterEntry_C
// Size: 0x620(Inherited: 0x620) 
struct UAM_PerfectAngledWaterEntry_C : public UME_GameplayAbilitySharkMontage
{

}; 



