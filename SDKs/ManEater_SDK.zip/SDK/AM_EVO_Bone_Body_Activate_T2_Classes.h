#pragma once 
#include <AM_EVO_Bone_Body_Activate_T2_Structs.h>
 
 
 
// BlueprintGeneratedClass AM_EVO_Bone_Body_Activate_T2.AM_EVO_Bone_Body_Activate_T2_C
// Size: 0x5E0(Inherited: 0x5E0) 
struct UAM_EVO_Bone_Body_Activate_T2_C : public UME_GameplayAbility_Montage
{

}; 



