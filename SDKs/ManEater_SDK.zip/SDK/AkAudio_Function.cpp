#include "SDK.h" 
 
 
void AVolume::OpenPortal(){

	static UObject* p_OpenPortal = UObject::FindObject<UFunction>("Function AkAudio.AkAcousticPortal.OpenPortal");

	struct {
	} parms;


	ProcessEvent(p_OpenPortal, &parms);
}

uint8_t  AVolume::GetCurrentState(){

	static UObject* p_GetCurrentState = UObject::FindObject<UFunction>("Function AkAudio.AkAcousticPortal.GetCurrentState");

	struct {
		uint8_t  return_value;
	} parms;


	ProcessEvent(p_GetCurrentState, &parms);
	return parms.return_value;
}

void AVolume::ClosePortal(){

	static UObject* p_ClosePortal = UObject::FindObject<UFunction>("Function AkAudio.AkAcousticPortal.ClosePortal");

	struct {
	} parms;


	ProcessEvent(p_ClosePortal, &parms);
}

void AActor::StopAmbientSound(){

	static UObject* p_StopAmbientSound = UObject::FindObject<UFunction>("Function AkAudio.AkAmbientSound.StopAmbientSound");

	struct {
	} parms;


	ProcessEvent(p_StopAmbientSound, &parms);
}

void AActor::StartAmbientSound(){

	static UObject* p_StartAmbientSound = UObject::FindObject<UFunction>("Function AkAudio.AkAmbientSound.StartAmbientSound");

	struct {
	} parms;


	ProcessEvent(p_StartAmbientSound, &parms);
}

void USceneComponent::UpdateSurfaceReflectorSet(){

	static UObject* p_UpdateSurfaceReflectorSet = UObject::FindObject<UFunction>("Function AkAudio.AkSurfaceReflectorSetComponent.UpdateSurfaceReflectorSet");

	struct {
	} parms;


	ProcessEvent(p_UpdateSurfaceReflectorSet, &parms);
}

void USceneComponent::SendSurfaceReflectorSet(){

	static UObject* p_SendSurfaceReflectorSet = UObject::FindObject<UFunction>("Function AkAudio.AkSurfaceReflectorSetComponent.SendSurfaceReflectorSet");

	struct {
	} parms;


	ProcessEvent(p_SendSurfaceReflectorSet, &parms);
}

void USceneComponent::RemoveSurfaceReflectorSet(){

	static UObject* p_RemoveSurfaceReflectorSet = UObject::FindObject<UFunction>("Function AkAudio.AkSurfaceReflectorSetComponent.RemoveSurfaceReflectorSet");

	struct {
	} parms;


	ProcessEvent(p_RemoveSurfaceReflectorSet, &parms);
}

void UObject::MigrateMultiCoreRendering(bool NewValue){

	static UObject* p_MigrateMultiCoreRendering = UObject::FindObject<UFunction>("Function AkAudio.AkAndroidInitializationSettings.MigrateMultiCoreRendering");

	struct {
		bool NewValue;
	} parms;

	parms.NewValue = NewValue;

	ProcessEvent(p_MigrateMultiCoreRendering, &parms);
}

void UWidget::SetValue(float InValue){

	static UObject* p_SetValue = UObject::FindObject<UFunction>("Function AkAudio.AkSlider.SetValue");

	struct {
		float InValue;
	} parms;

	parms.InValue = InValue;

	ProcessEvent(p_SetValue, &parms);
}

void UWidget::SetStepSize(float InValue){

	static UObject* p_SetStepSize = UObject::FindObject<UFunction>("Function AkAudio.AkSlider.SetStepSize");

	struct {
		float InValue;
	} parms;

	parms.InValue = InValue;

	ProcessEvent(p_SetStepSize, &parms);
}

void UWidget::SetSliderHandleColor(struct FLinearColor InValue){

	static UObject* p_SetSliderHandleColor = UObject::FindObject<UFunction>("Function AkAudio.AkSlider.SetSliderHandleColor");

	struct {
		struct FLinearColor InValue;
	} parms;

	parms.InValue = InValue;

	ProcessEvent(p_SetSliderHandleColor, &parms);
}

void UWidget::SetSliderBarColor(struct FLinearColor InValue){

	static UObject* p_SetSliderBarColor = UObject::FindObject<UFunction>("Function AkAudio.AkSlider.SetSliderBarColor");

	struct {
		struct FLinearColor InValue;
	} parms;

	parms.InValue = InValue;

	ProcessEvent(p_SetSliderBarColor, &parms);
}

void UWidget::SetLocked(bool InValue){

	static UObject* p_SetLocked = UObject::FindObject<UFunction>("Function AkAudio.AkSlider.SetLocked");

	struct {
		bool InValue;
	} parms;

	parms.InValue = InValue;

	ProcessEvent(p_SetLocked, &parms);
}

void UWidget::SetIndentHandle(bool InValue){

	static UObject* p_SetIndentHandle = UObject::FindObject<UFunction>("Function AkAudio.AkSlider.SetIndentHandle");

	struct {
		bool InValue;
	} parms;

	parms.InValue = InValue;

	ProcessEvent(p_SetIndentHandle, &parms);
}

void UWidget::SetAkSliderItemProperty(struct FString ItemProperty){

	static UObject* p_SetAkSliderItemProperty = UObject::FindObject<UFunction>("Function AkAudio.AkSlider.SetAkSliderItemProperty");

	struct {
		struct FString ItemProperty;
	} parms;

	parms.ItemProperty = ItemProperty;

	ProcessEvent(p_SetAkSliderItemProperty, &parms);
}

void UWidget::SetAkSliderItemId(struct FGuid& ItemId){

	static UObject* p_SetAkSliderItemId = UObject::FindObject<UFunction>("Function AkAudio.AkSlider.SetAkSliderItemId");

	struct {
		struct FGuid& ItemId;
	} parms;

	parms.ItemId = ItemId;

	ProcessEvent(p_SetAkSliderItemId, &parms);
}

float UWidget::GetValue(){

	static UObject* p_GetValue = UObject::FindObject<UFunction>("Function AkAudio.AkSlider.GetValue");

	struct {
		float return_value;
	} parms;


	ProcessEvent(p_GetValue, &parms);
	return parms.return_value;
}

struct FString UWidget::GetAkSliderItemProperty(){

	static UObject* p_GetAkSliderItemProperty = UObject::FindObject<UFunction>("Function AkAudio.AkSlider.GetAkSliderItemProperty");

	struct {
		struct FString return_value;
	} parms;


	ProcessEvent(p_GetAkSliderItemProperty, &parms);
	return parms.return_value;
}

struct FGuid UWidget::GetAkSliderItemId(){

	static UObject* p_GetAkSliderItemId = UObject::FindObject<UFunction>("Function AkAudio.AkSlider.GetAkSliderItemId");

	struct {
		struct FGuid return_value;
	} parms;


	ProcessEvent(p_GetAkSliderItemId, &parms);
	return parms.return_value;
}

void UObject::MigrateMultiCoreRendering(bool NewValue){

	static UObject* p_MigrateMultiCoreRendering = UObject::FindObject<UFunction>("Function AkAudio.AkLuminInitializationSettings.MigrateMultiCoreRendering");

	struct {
		bool NewValue;
	} parms;

	parms.NewValue = NewValue;

	ProcessEvent(p_MigrateMultiCoreRendering, &parms);
}

void UWidget::SetSearchText(struct FString newText){

	static UObject* p_SetSearchText = UObject::FindObject<UFunction>("Function AkAudio.AkItemBoolProperties.SetSearchText");

	struct {
		struct FString newText;
	} parms;

	parms.newText = newText;

	ProcessEvent(p_SetSearchText, &parms);
}

struct FString UWidget::GetSelectedProperty(){

	static UObject* p_GetSelectedProperty = UObject::FindObject<UFunction>("Function AkAudio.AkItemBoolProperties.GetSelectedProperty");

	struct {
		struct FString return_value;
	} parms;


	ProcessEvent(p_GetSelectedProperty, &parms);
	return parms.return_value;
}

struct FString UWidget::GetSearchText(){

	static UObject* p_GetSearchText = UObject::FindObject<UFunction>("Function AkAudio.AkItemBoolProperties.GetSearchText");

	struct {
		struct FString return_value;
	} parms;


	ProcessEvent(p_GetSearchText, &parms);
	return parms.return_value;
}

void USceneComponent::UpdateGeometry(){

	static UObject* p_UpdateGeometry = UObject::FindObject<UFunction>("Function AkAudio.AkGeometryComponent.UpdateGeometry");

	struct {
	} parms;


	ProcessEvent(p_UpdateGeometry, &parms);
}

void USceneComponent::RemoveGeometry(){

	static UObject* p_RemoveGeometry = UObject::FindObject<UFunction>("Function AkAudio.AkGeometryComponent.RemoveGeometry");

	struct {
	} parms;


	ProcessEvent(p_RemoveGeometry, &parms);
}

void USceneComponent::ConvertMesh(){

	static UObject* p_ConvertMesh = UObject::FindObject<UFunction>("Function AkAudio.AkGeometryComponent.ConvertMesh");

	struct {
	} parms;


	ProcessEvent(p_ConvertMesh, &parms);
}

void UObject::MigrateMultiCoreRendering(bool NewValue){

	static UObject* p_MigrateMultiCoreRendering = UObject::FindObject<UFunction>("Function AkAudio.AkPS4InitializationSettings.MigrateMultiCoreRendering");

	struct {
		bool NewValue;
	} parms;

	parms.NewValue = NewValue;

	ProcessEvent(p_MigrateMultiCoreRendering, &parms);
}

float UAkAssetBase::GetMinimumDuration(){

	static UObject* p_GetMinimumDuration = UObject::FindObject<UFunction>("Function AkAudio.AkAudioEvent.GetMinimumDuration");

	struct {
		float return_value;
	} parms;


	ProcessEvent(p_GetMinimumDuration, &parms);
	return parms.return_value;
}

float UAkAssetBase::GetMaximumDuration(){

	static UObject* p_GetMaximumDuration = UObject::FindObject<UFunction>("Function AkAudio.AkAudioEvent.GetMaximumDuration");

	struct {
		float return_value;
	} parms;


	ProcessEvent(p_GetMaximumDuration, &parms);
	return parms.return_value;
}

float UAkAssetBase::GetMaxAttenuationRadius(){

	static UObject* p_GetMaxAttenuationRadius = UObject::FindObject<UFunction>("Function AkAudio.AkAudioEvent.GetMaxAttenuationRadius");

	struct {
		float return_value;
	} parms;


	ProcessEvent(p_GetMaxAttenuationRadius, &parms);
	return parms.return_value;
}

bool UAkAssetBase::GetIsInfinite(){

	static UObject* p_GetIsInfinite = UObject::FindObject<UFunction>("Function AkAudio.AkAudioEvent.GetIsInfinite");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_GetIsInfinite, &parms);
	return parms.return_value;
}

void USceneComponent::Stop(){

	static UObject* p_Stop = UObject::FindObject<UFunction>("Function AkAudio.AkGameObject.Stop");

	struct {
	} parms;


	ProcessEvent(p_Stop, &parms);
}

void USceneComponent::PostAssociatedAkEventAsync(struct UObject* WorldContextObject, int32_t CallbackMask, struct FDelegate& PostEventCallback, struct TArray<struct FAkExternalSourceInfo>& ExternalSources, struct FLatentActionInfo LatentInfo, int32_t& PlayingID){

	static UObject* p_PostAssociatedAkEventAsync = UObject::FindObject<UFunction>("Function AkAudio.AkGameObject.PostAssociatedAkEventAsync");

	struct {
		struct UObject* WorldContextObject;
		int32_t CallbackMask;
		struct FDelegate& PostEventCallback;
		struct TArray<struct FAkExternalSourceInfo>& ExternalSources;
		struct FLatentActionInfo LatentInfo;
		int32_t& PlayingID;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.CallbackMask = CallbackMask;
	parms.PostEventCallback = PostEventCallback;
	parms.ExternalSources = ExternalSources;
	parms.LatentInfo = LatentInfo;
	parms.PlayingID = PlayingID;

	ProcessEvent(p_PostAssociatedAkEventAsync, &parms);
}

int32_t USceneComponent::PostAssociatedAkEvent(int32_t CallbackMask, struct FDelegate& PostEventCallback, struct TArray<struct FAkExternalSourceInfo>& ExternalSources){

	static UObject* p_PostAssociatedAkEvent = UObject::FindObject<UFunction>("Function AkAudio.AkGameObject.PostAssociatedAkEvent");

	struct {
		int32_t CallbackMask;
		struct FDelegate& PostEventCallback;
		struct TArray<struct FAkExternalSourceInfo>& ExternalSources;
		int32_t return_value;
	} parms;

	parms.CallbackMask = CallbackMask;
	parms.PostEventCallback = PostEventCallback;
	parms.ExternalSources = ExternalSources;

	ProcessEvent(p_PostAssociatedAkEvent, &parms);
	return parms.return_value;
}

void USceneComponent::PostAkEventAsync(struct UObject* WorldContextObject, struct UAkAudioEvent* AkEvent, int32_t& PlayingID, int32_t CallbackMask, struct FDelegate& PostEventCallback, struct TArray<struct FAkExternalSourceInfo>& ExternalSources, struct FLatentActionInfo LatentInfo){

	static UObject* p_PostAkEventAsync = UObject::FindObject<UFunction>("Function AkAudio.AkGameObject.PostAkEventAsync");

	struct {
		struct UObject* WorldContextObject;
		struct UAkAudioEvent* AkEvent;
		int32_t& PlayingID;
		int32_t CallbackMask;
		struct FDelegate& PostEventCallback;
		struct TArray<struct FAkExternalSourceInfo>& ExternalSources;
		struct FLatentActionInfo LatentInfo;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.AkEvent = AkEvent;
	parms.PlayingID = PlayingID;
	parms.CallbackMask = CallbackMask;
	parms.PostEventCallback = PostEventCallback;
	parms.ExternalSources = ExternalSources;
	parms.LatentInfo = LatentInfo;

	ProcessEvent(p_PostAkEventAsync, &parms);
}

int32_t USceneComponent::PostAkEvent(struct UAkAudioEvent* AkEvent, int32_t CallbackMask, struct FDelegate& PostEventCallback, struct TArray<struct FAkExternalSourceInfo>& ExternalSources, struct FString in_EventName){

	static UObject* p_PostAkEvent = UObject::FindObject<UFunction>("Function AkAudio.AkGameObject.PostAkEvent");

	struct {
		struct UAkAudioEvent* AkEvent;
		int32_t CallbackMask;
		struct FDelegate& PostEventCallback;
		struct TArray<struct FAkExternalSourceInfo>& ExternalSources;
		struct FString in_EventName;
		int32_t return_value;
	} parms;

	parms.AkEvent = AkEvent;
	parms.CallbackMask = CallbackMask;
	parms.PostEventCallback = PostEventCallback;
	parms.ExternalSources = ExternalSources;
	parms.in_EventName = in_EventName;

	ProcessEvent(p_PostAkEvent, &parms);
	return parms.return_value;
}

void UAkGameObject::UseReverbVolumes(bool inUseReverbVolumes){

	static UObject* p_UseReverbVolumes = UObject::FindObject<UFunction>("Function AkAudio.AkComponent.UseReverbVolumes");

	struct {
		bool inUseReverbVolumes;
	} parms;

	parms.inUseReverbVolumes = inUseReverbVolumes;

	ProcessEvent(p_UseReverbVolumes, &parms);
}

void UAkGameObject::UseEarlyReflections(struct UAkAuxBus* AuxBus, int32_t Order, float BusSendGain, float MaxPathLength, bool SpotReflectors, struct FString AuxBusName){

	static UObject* p_UseEarlyReflections = UObject::FindObject<UFunction>("Function AkAudio.AkComponent.UseEarlyReflections");

	struct {
		struct UAkAuxBus* AuxBus;
		int32_t Order;
		float BusSendGain;
		float MaxPathLength;
		bool SpotReflectors;
		struct FString AuxBusName;
	} parms;

	parms.AuxBus = AuxBus;
	parms.Order = Order;
	parms.BusSendGain = BusSendGain;
	parms.MaxPathLength = MaxPathLength;
	parms.SpotReflectors = SpotReflectors;
	parms.AuxBusName = AuxBusName;

	ProcessEvent(p_UseEarlyReflections, &parms);
}

void UAkGameObject::SetSwitch(struct UAkSwitchValue* SwitchValue, struct FString SwitchGroup, struct FString SwitchState){

	static UObject* p_SetSwitch = UObject::FindObject<UFunction>("Function AkAudio.AkComponent.SetSwitch");

	struct {
		struct UAkSwitchValue* SwitchValue;
		struct FString SwitchGroup;
		struct FString SwitchState;
	} parms;

	parms.SwitchValue = SwitchValue;
	parms.SwitchGroup = SwitchGroup;
	parms.SwitchState = SwitchState;

	ProcessEvent(p_SetSwitch, &parms);
}

void UAkGameObject::SetStopWhenOwnerDestroyed(bool bStopWhenOwnerDestroyed){

	static UObject* p_SetStopWhenOwnerDestroyed = UObject::FindObject<UFunction>("Function AkAudio.AkComponent.SetStopWhenOwnerDestroyed");

	struct {
		bool bStopWhenOwnerDestroyed;
	} parms;

	parms.bStopWhenOwnerDestroyed = bStopWhenOwnerDestroyed;

	ProcessEvent(p_SetStopWhenOwnerDestroyed, &parms);
}

void UAkGameObject::SetRTPCValue(struct UAkRtpc* RTPCValue, float Value, int32_t InterpolationTimeMs, struct FString RTPC){

	static UObject* p_SetRTPCValue = UObject::FindObject<UFunction>("Function AkAudio.AkComponent.SetRTPCValue");

	struct {
		struct UAkRtpc* RTPCValue;
		float Value;
		int32_t InterpolationTimeMs;
		struct FString RTPC;
	} parms;

	parms.RTPCValue = RTPCValue;
	parms.Value = Value;
	parms.InterpolationTimeMs = InterpolationTimeMs;
	parms.RTPC = RTPC;

	ProcessEvent(p_SetRTPCValue, &parms);
}

void UAkGameObject::SetOutputBusVolume(float BusVolume){

	static UObject* p_SetOutputBusVolume = UObject::FindObject<UFunction>("Function AkAudio.AkComponent.SetOutputBusVolume");

	struct {
		float BusVolume;
	} parms;

	parms.BusVolume = BusVolume;

	ProcessEvent(p_SetOutputBusVolume, &parms);
}

void UAkGameObject::SetListeners(struct TArray<struct UAkComponent*>& Listeners){

	static UObject* p_SetListeners = UObject::FindObject<UFunction>("Function AkAudio.AkComponent.SetListeners");

	struct {
		struct TArray<struct UAkComponent*>& Listeners;
	} parms;

	parms.Listeners = Listeners;

	ProcessEvent(p_SetListeners, &parms);
}

void UAkGameObject::SetEarlyReflectionsVolume(float SendVolume){

	static UObject* p_SetEarlyReflectionsVolume = UObject::FindObject<UFunction>("Function AkAudio.AkComponent.SetEarlyReflectionsVolume");

	struct {
		float SendVolume;
	} parms;

	parms.SendVolume = SendVolume;

	ProcessEvent(p_SetEarlyReflectionsVolume, &parms);
}

void UAkGameObject::SetEarlyReflectionsAuxBus(struct FString AuxBusName){

	static UObject* p_SetEarlyReflectionsAuxBus = UObject::FindObject<UFunction>("Function AkAudio.AkComponent.SetEarlyReflectionsAuxBus");

	struct {
		struct FString AuxBusName;
	} parms;

	parms.AuxBusName = AuxBusName;

	ProcessEvent(p_SetEarlyReflectionsAuxBus, &parms);
}

void UAkGameObject::SetAttenuationScalingFactor(float Value){

	static UObject* p_SetAttenuationScalingFactor = UObject::FindObject<UFunction>("Function AkAudio.AkComponent.SetAttenuationScalingFactor");

	struct {
		float Value;
	} parms;

	parms.Value = Value;

	ProcessEvent(p_SetAttenuationScalingFactor, &parms);
}

void UAkGameObject::PostTrigger(struct UAkTrigger* TriggerValue, struct FString Trigger){

	static UObject* p_PostTrigger = UObject::FindObject<UFunction>("Function AkAudio.AkComponent.PostTrigger");

	struct {
		struct UAkTrigger* TriggerValue;
		struct FString Trigger;
	} parms;

	parms.TriggerValue = TriggerValue;
	parms.Trigger = Trigger;

	ProcessEvent(p_PostTrigger, &parms);
}

void UAkGameObject::PostAssociatedAkEventAndWaitForEndAsync(int32_t& PlayingID, struct TArray<struct FAkExternalSourceInfo>& ExternalSources, struct FLatentActionInfo LatentInfo){

	static UObject* p_PostAssociatedAkEventAndWaitForEndAsync = UObject::FindObject<UFunction>("Function AkAudio.AkComponent.PostAssociatedAkEventAndWaitForEndAsync");

	struct {
		int32_t& PlayingID;
		struct TArray<struct FAkExternalSourceInfo>& ExternalSources;
		struct FLatentActionInfo LatentInfo;
	} parms;

	parms.PlayingID = PlayingID;
	parms.ExternalSources = ExternalSources;
	parms.LatentInfo = LatentInfo;

	ProcessEvent(p_PostAssociatedAkEventAndWaitForEndAsync, &parms);
}

int32_t UAkGameObject::PostAssociatedAkEventAndWaitForEnd(struct TArray<struct FAkExternalSourceInfo>& ExternalSources, struct FLatentActionInfo LatentInfo){

	static UObject* p_PostAssociatedAkEventAndWaitForEnd = UObject::FindObject<UFunction>("Function AkAudio.AkComponent.PostAssociatedAkEventAndWaitForEnd");

	struct {
		struct TArray<struct FAkExternalSourceInfo>& ExternalSources;
		struct FLatentActionInfo LatentInfo;
		int32_t return_value;
	} parms;

	parms.ExternalSources = ExternalSources;
	parms.LatentInfo = LatentInfo;

	ProcessEvent(p_PostAssociatedAkEventAndWaitForEnd, &parms);
	return parms.return_value;
}

int32_t UAkGameObject::PostAkEventByName(struct FString in_EventName){

	static UObject* p_PostAkEventByName = UObject::FindObject<UFunction>("Function AkAudio.AkComponent.PostAkEventByName");

	struct {
		struct FString in_EventName;
		int32_t return_value;
	} parms;

	parms.in_EventName = in_EventName;

	ProcessEvent(p_PostAkEventByName, &parms);
	return parms.return_value;
}

void UAkGameObject::PostAkEventAndWaitForEndAsync(struct UAkAudioEvent* AkEvent, int32_t& PlayingID, struct TArray<struct FAkExternalSourceInfo>& ExternalSources, struct FLatentActionInfo LatentInfo){

	static UObject* p_PostAkEventAndWaitForEndAsync = UObject::FindObject<UFunction>("Function AkAudio.AkComponent.PostAkEventAndWaitForEndAsync");

	struct {
		struct UAkAudioEvent* AkEvent;
		int32_t& PlayingID;
		struct TArray<struct FAkExternalSourceInfo>& ExternalSources;
		struct FLatentActionInfo LatentInfo;
	} parms;

	parms.AkEvent = AkEvent;
	parms.PlayingID = PlayingID;
	parms.ExternalSources = ExternalSources;
	parms.LatentInfo = LatentInfo;

	ProcessEvent(p_PostAkEventAndWaitForEndAsync, &parms);
}

int32_t UAkGameObject::PostAkEventAndWaitForEnd(struct UAkAudioEvent* AkEvent, struct FString in_EventName, struct TArray<struct FAkExternalSourceInfo>& ExternalSources, struct FLatentActionInfo LatentInfo){

	static UObject* p_PostAkEventAndWaitForEnd = UObject::FindObject<UFunction>("Function AkAudio.AkComponent.PostAkEventAndWaitForEnd");

	struct {
		struct UAkAudioEvent* AkEvent;
		struct FString in_EventName;
		struct TArray<struct FAkExternalSourceInfo>& ExternalSources;
		struct FLatentActionInfo LatentInfo;
		int32_t return_value;
	} parms;

	parms.AkEvent = AkEvent;
	parms.in_EventName = in_EventName;
	parms.ExternalSources = ExternalSources;
	parms.LatentInfo = LatentInfo;

	ProcessEvent(p_PostAkEventAndWaitForEnd, &parms);
	return parms.return_value;
}

void UAkGameObject::GetRTPCValue(struct UAkRtpc* RTPCValue, uint8_t  InputValueType, float& Value, uint8_t & OutputValueType, struct FString RTPC, int32_t PlayingID){

	static UObject* p_GetRTPCValue = UObject::FindObject<UFunction>("Function AkAudio.AkComponent.GetRTPCValue");

	struct {
		struct UAkRtpc* RTPCValue;
		uint8_t  InputValueType;
		float& Value;
		uint8_t & OutputValueType;
		struct FString RTPC;
		int32_t PlayingID;
	} parms;

	parms.RTPCValue = RTPCValue;
	parms.InputValueType = InputValueType;
	parms.Value = Value;
	parms.OutputValueType = OutputValueType;
	parms.RTPC = RTPC;
	parms.PlayingID = PlayingID;

	ProcessEvent(p_GetRTPCValue, &parms);
}

float UAkGameObject::GetAttenuationRadius(){

	static UObject* p_GetAttenuationRadius = UObject::FindObject<UFunction>("Function AkAudio.AkComponent.GetAttenuationRadius");

	struct {
		float return_value;
	} parms;


	ProcessEvent(p_GetAttenuationRadius, &parms);
	return parms.return_value;
}

void UObject::MigrateMultiCoreRendering(bool NewValue){

	static UObject* p_MigrateMultiCoreRendering = UObject::FindObject<UFunction>("Function AkAudio.AkLinuxInitializationSettings.MigrateMultiCoreRendering");

	struct {
		bool NewValue;
	} parms;

	parms.NewValue = NewValue;

	ProcessEvent(p_MigrateMultiCoreRendering, &parms);
}

int32_t UAkComponent::PostAssociatedAudioInputEvent(){

	static UObject* p_PostAssociatedAudioInputEvent = UObject::FindObject<UFunction>("Function AkAudio.AkAudioInputComponent.PostAssociatedAudioInputEvent");

	struct {
		int32_t return_value;
	} parms;


	ProcessEvent(p_PostAssociatedAudioInputEvent, &parms);
	return parms.return_value;
}

void UContentWidget::SetIsChecked(bool InIsChecked){

	static UObject* p_SetIsChecked = UObject::FindObject<UFunction>("Function AkAudio.AkCheckBox.SetIsChecked");

	struct {
		bool InIsChecked;
	} parms;

	parms.InIsChecked = InIsChecked;

	ProcessEvent(p_SetIsChecked, &parms);
}

void UContentWidget::SetCheckedState(uint8_t  InCheckedState){

	static UObject* p_SetCheckedState = UObject::FindObject<UFunction>("Function AkAudio.AkCheckBox.SetCheckedState");

	struct {
		uint8_t  InCheckedState;
	} parms;

	parms.InCheckedState = InCheckedState;

	ProcessEvent(p_SetCheckedState, &parms);
}

void UContentWidget::SetAkItemId(struct FGuid& ItemId){

	static UObject* p_SetAkItemId = UObject::FindObject<UFunction>("Function AkAudio.AkCheckBox.SetAkItemId");

	struct {
		struct FGuid& ItemId;
	} parms;

	parms.ItemId = ItemId;

	ProcessEvent(p_SetAkItemId, &parms);
}

void UContentWidget::SetAkBoolProperty(struct FString ItemProperty){

	static UObject* p_SetAkBoolProperty = UObject::FindObject<UFunction>("Function AkAudio.AkCheckBox.SetAkBoolProperty");

	struct {
		struct FString ItemProperty;
	} parms;

	parms.ItemProperty = ItemProperty;

	ProcessEvent(p_SetAkBoolProperty, &parms);
}

bool UContentWidget::IsPressed(){

	static UObject* p_IsPressed = UObject::FindObject<UFunction>("Function AkAudio.AkCheckBox.IsPressed");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_IsPressed, &parms);
	return parms.return_value;
}

bool UContentWidget::IsChecked(){

	static UObject* p_IsChecked = UObject::FindObject<UFunction>("Function AkAudio.AkCheckBox.IsChecked");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_IsChecked, &parms);
	return parms.return_value;
}

uint8_t  UContentWidget::GetCheckedState(){

	static UObject* p_GetCheckedState = UObject::FindObject<UFunction>("Function AkAudio.AkCheckBox.GetCheckedState");

	struct {
		uint8_t  return_value;
	} parms;


	ProcessEvent(p_GetCheckedState, &parms);
	return parms.return_value;
}

struct FString UContentWidget::GetAkProperty(){

	static UObject* p_GetAkProperty = UObject::FindObject<UFunction>("Function AkAudio.AkCheckBox.GetAkProperty");

	struct {
		struct FString return_value;
	} parms;


	ProcessEvent(p_GetAkProperty, &parms);
	return parms.return_value;
}

struct FGuid UContentWidget::GetAkItemId(){

	static UObject* p_GetAkItemId = UObject::FindObject<UFunction>("Function AkAudio.AkCheckBox.GetAkItemId");

	struct {
		struct FGuid return_value;
	} parms;


	ProcessEvent(p_GetAkItemId, &parms);
	return parms.return_value;
}

void UObject::MigrateMultiCoreRendering(bool NewValue){

	static UObject* p_MigrateMultiCoreRendering = UObject::FindObject<UFunction>("Function AkAudio.AkHololensInitializationSettings.MigrateMultiCoreRendering");

	struct {
		bool NewValue;
	} parms;

	parms.NewValue = NewValue;

	ProcessEvent(p_MigrateMultiCoreRendering, &parms);
}

void UBlueprintFunctionLibrary::UseReverbVolumes(bool inUseReverbVolumes, struct AActor* Actor){

	static UObject* p_UseReverbVolumes = UObject::FindObject<UFunction>("Function AkAudio.AkGameplayStatics.UseReverbVolumes");

	struct {
		bool inUseReverbVolumes;
		struct AActor* Actor;
	} parms;

	parms.inUseReverbVolumes = inUseReverbVolumes;
	parms.Actor = Actor;

	ProcessEvent(p_UseReverbVolumes, &parms);
}

void UBlueprintFunctionLibrary::UseEarlyReflections(struct AActor* Actor, struct UAkAuxBus* AuxBus, int32_t Order, float BusSendGain, float MaxPathLength, bool SpotReflectors, struct FString AuxBusName){

	static UObject* p_UseEarlyReflections = UObject::FindObject<UFunction>("Function AkAudio.AkGameplayStatics.UseEarlyReflections");

	struct {
		struct AActor* Actor;
		struct UAkAuxBus* AuxBus;
		int32_t Order;
		float BusSendGain;
		float MaxPathLength;
		bool SpotReflectors;
		struct FString AuxBusName;
	} parms;

	parms.Actor = Actor;
	parms.AuxBus = AuxBus;
	parms.Order = Order;
	parms.BusSendGain = BusSendGain;
	parms.MaxPathLength = MaxPathLength;
	parms.SpotReflectors = SpotReflectors;
	parms.AuxBusName = AuxBusName;

	ProcessEvent(p_UseEarlyReflections, &parms);
}

int32_t UBlueprintFunctionLibrary::UnlockPlayList(int32_t SequenceID, struct UObject* WorldContext){

	static UObject* p_UnlockPlayList = UObject::FindObject<UFunction>("Function AkAudio.AkGameplayStatics.UnlockPlayList");

	struct {
		int32_t SequenceID;
		struct UObject* WorldContext;
		int32_t return_value;
	} parms;

	parms.SequenceID = SequenceID;
	parms.WorldContext = WorldContext;

	ProcessEvent(p_UnlockPlayList, &parms);
	return parms.return_value;
}

void UBlueprintFunctionLibrary::UnloadBankByName(struct FString BankName){

	static UObject* p_UnloadBankByName = UObject::FindObject<UFunction>("Function AkAudio.AkGameplayStatics.UnloadBankByName");

	struct {
		struct FString BankName;
	} parms;

	parms.BankName = BankName;

	ProcessEvent(p_UnloadBankByName, &parms);
}

void UBlueprintFunctionLibrary::UnloadBankAsync(struct UAkAudioBank* Bank, struct FDelegate& BankUnloadedCallback){

	static UObject* p_UnloadBankAsync = UObject::FindObject<UFunction>("Function AkAudio.AkGameplayStatics.UnloadBankAsync");

	struct {
		struct UAkAudioBank* Bank;
		struct FDelegate& BankUnloadedCallback;
	} parms;

	parms.Bank = Bank;
	parms.BankUnloadedCallback = BankUnloadedCallback;

	ProcessEvent(p_UnloadBankAsync, &parms);
}

void UBlueprintFunctionLibrary::UnloadBank(struct UAkAudioBank* Bank, struct FString BankName, struct FLatentActionInfo LatentInfo, struct UObject* WorldContextObject){

	static UObject* p_UnloadBank = UObject::FindObject<UFunction>("Function AkAudio.AkGameplayStatics.UnloadBank");

	struct {
		struct UAkAudioBank* Bank;
		struct FString BankName;
		struct FLatentActionInfo LatentInfo;
		struct UObject* WorldContextObject;
	} parms;

	parms.Bank = Bank;
	parms.BankName = BankName;
	parms.LatentInfo = LatentInfo;
	parms.WorldContextObject = WorldContextObject;

	ProcessEvent(p_UnloadBank, &parms);
}

void UBlueprintFunctionLibrary::StopProfilerCapture(){

	static UObject* p_StopProfilerCapture = UObject::FindObject<UFunction>("Function AkAudio.AkGameplayStatics.StopProfilerCapture");

	struct {
	} parms;


	ProcessEvent(p_StopProfilerCapture, &parms);
}

void UBlueprintFunctionLibrary::StopOutputCapture(){

	static UObject* p_StopOutputCapture = UObject::FindObject<UFunction>("Function AkAudio.AkGameplayStatics.StopOutputCapture");

	struct {
	} parms;


	ProcessEvent(p_StopOutputCapture, &parms);
}

void UBlueprintFunctionLibrary::StopAllAmbientSounds(struct UObject* WorldContextObject){

	static UObject* p_StopAllAmbientSounds = UObject::FindObject<UFunction>("Function AkAudio.AkGameplayStatics.StopAllAmbientSounds");

	struct {
		struct UObject* WorldContextObject;
	} parms;

	parms.WorldContextObject = WorldContextObject;

	ProcessEvent(p_StopAllAmbientSounds, &parms);
}

void UBlueprintFunctionLibrary::StopAll(){

	static UObject* p_StopAll = UObject::FindObject<UFunction>("Function AkAudio.AkGameplayStatics.StopAll");

	struct {
	} parms;


	ProcessEvent(p_StopAll, &parms);
}

void UBlueprintFunctionLibrary::StopActor(struct AActor* Actor){

	static UObject* p_StopActor = UObject::FindObject<UFunction>("Function AkAudio.AkGameplayStatics.StopActor");

	struct {
		struct AActor* Actor;
	} parms;

	parms.Actor = Actor;

	ProcessEvent(p_StopActor, &parms);
}

void UBlueprintFunctionLibrary::StartProfilerCapture(struct FString Filename){

	static UObject* p_StartProfilerCapture = UObject::FindObject<UFunction>("Function AkAudio.AkGameplayStatics.StartProfilerCapture");

	struct {
		struct FString Filename;
	} parms;

	parms.Filename = Filename;

	ProcessEvent(p_StartProfilerCapture, &parms);
}

void UBlueprintFunctionLibrary::StartOutputCapture(struct FString Filename){

	static UObject* p_StartOutputCapture = UObject::FindObject<UFunction>("Function AkAudio.AkGameplayStatics.StartOutputCapture");

	struct {
		struct FString Filename;
	} parms;

	parms.Filename = Filename;

	ProcessEvent(p_StartOutputCapture, &parms);
}

void UBlueprintFunctionLibrary::StartAllAmbientSounds(struct UObject* WorldContextObject){

	static UObject* p_StartAllAmbientSounds = UObject::FindObject<UFunction>("Function AkAudio.AkGameplayStatics.StartAllAmbientSounds");

	struct {
		struct UObject* WorldContextObject;
	} parms;

	parms.WorldContextObject = WorldContextObject;

	ProcessEvent(p_StartAllAmbientSounds, &parms);
}

struct UAkComponent* UBlueprintFunctionLibrary::SpawnAkComponentAtLocation(struct UObject* WorldContextObject, struct UAkAudioEvent* AkEvent, struct FVector Location, struct FRotator Orientation, bool AutoPost, struct FString EventName, bool AutoDestroy){

	static UObject* p_SpawnAkComponentAtLocation = UObject::FindObject<UFunction>("Function AkAudio.AkGameplayStatics.SpawnAkComponentAtLocation");

	struct {
		struct UObject* WorldContextObject;
		struct UAkAudioEvent* AkEvent;
		struct FVector Location;
		struct FRotator Orientation;
		bool AutoPost;
		struct FString EventName;
		bool AutoDestroy;
		struct UAkComponent* return_value;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.AkEvent = AkEvent;
	parms.Location = Location;
	parms.Orientation = Orientation;
	parms.AutoPost = AutoPost;
	parms.EventName = EventName;
	parms.AutoDestroy = AutoDestroy;

	ProcessEvent(p_SpawnAkComponentAtLocation, &parms);
	return parms.return_value;
}

void UBlueprintFunctionLibrary::SetSwitch(struct UAkSwitchValue* SwitchValue, struct AActor* Actor, struct FName SwitchGroup, struct FName SwitchState){

	static UObject* p_SetSwitch = UObject::FindObject<UFunction>("Function AkAudio.AkGameplayStatics.SetSwitch");

	struct {
		struct UAkSwitchValue* SwitchValue;
		struct AActor* Actor;
		struct FName SwitchGroup;
		struct FName SwitchState;
	} parms;

	parms.SwitchValue = SwitchValue;
	parms.Actor = Actor;
	parms.SwitchGroup = SwitchGroup;
	parms.SwitchState = SwitchState;

	ProcessEvent(p_SetSwitch, &parms);
}

void UBlueprintFunctionLibrary::SetState(struct UAkStateValue* StateValue, struct FName StateGroup, struct FName State){

	static UObject* p_SetState = UObject::FindObject<UFunction>("Function AkAudio.AkGameplayStatics.SetState");

	struct {
		struct UAkStateValue* StateValue;
		struct FName StateGroup;
		struct FName State;
	} parms;

	parms.StateValue = StateValue;
	parms.StateGroup = StateGroup;
	parms.State = State;

	ProcessEvent(p_SetState, &parms);
}

void UBlueprintFunctionLibrary::SetSpeakerAngles(struct TArray<float>& SpeakerAngles, float HeightAngle, struct FString DeviceShareset){

	static UObject* p_SetSpeakerAngles = UObject::FindObject<UFunction>("Function AkAudio.AkGameplayStatics.SetSpeakerAngles");

	struct {
		struct TArray<float>& SpeakerAngles;
		float HeightAngle;
		struct FString DeviceShareset;
	} parms;

	parms.SpeakerAngles = SpeakerAngles;
	parms.HeightAngle = HeightAngle;
	parms.DeviceShareset = DeviceShareset;

	ProcessEvent(p_SetSpeakerAngles, &parms);
}

void UBlueprintFunctionLibrary::SetRTPCValue(struct UAkRtpc* RTPCValue, float Value, int32_t InterpolationTimeMs, struct AActor* Actor, struct FName RTPC){

	static UObject* p_SetRTPCValue = UObject::FindObject<UFunction>("Function AkAudio.AkGameplayStatics.SetRTPCValue");

	struct {
		struct UAkRtpc* RTPCValue;
		float Value;
		int32_t InterpolationTimeMs;
		struct AActor* Actor;
		struct FName RTPC;
	} parms;

	parms.RTPCValue = RTPCValue;
	parms.Value = Value;
	parms.InterpolationTimeMs = InterpolationTimeMs;
	parms.Actor = Actor;
	parms.RTPC = RTPC;

	ProcessEvent(p_SetRTPCValue, &parms);
}

void UBlueprintFunctionLibrary::SetReflectionsOrder(int32_t Order, bool RefreshPaths){

	static UObject* p_SetReflectionsOrder = UObject::FindObject<UFunction>("Function AkAudio.AkGameplayStatics.SetReflectionsOrder");

	struct {
		int32_t Order;
		bool RefreshPaths;
	} parms;

	parms.Order = Order;
	parms.RefreshPaths = RefreshPaths;

	ProcessEvent(p_SetReflectionsOrder, &parms);
}

void UBlueprintFunctionLibrary::SetPanningRule(uint8_t  PanRule){

	static UObject* p_SetPanningRule = UObject::FindObject<UFunction>("Function AkAudio.AkGameplayStatics.SetPanningRule");

	struct {
		uint8_t  PanRule;
	} parms;

	parms.PanRule = PanRule;

	ProcessEvent(p_SetPanningRule, &parms);
}

void UBlueprintFunctionLibrary::SetOutputBusVolume(float BusVolume, struct AActor* Actor){

	static UObject* p_SetOutputBusVolume = UObject::FindObject<UFunction>("Function AkAudio.AkGameplayStatics.SetOutputBusVolume");

	struct {
		float BusVolume;
		struct AActor* Actor;
	} parms;

	parms.BusVolume = BusVolume;
	parms.Actor = Actor;

	ProcessEvent(p_SetOutputBusVolume, &parms);
}

void UBlueprintFunctionLibrary::SetOcclusionScalingFactor(float ScalingFactor){

	static UObject* p_SetOcclusionScalingFactor = UObject::FindObject<UFunction>("Function AkAudio.AkGameplayStatics.SetOcclusionScalingFactor");

	struct {
		float ScalingFactor;
	} parms;

	parms.ScalingFactor = ScalingFactor;

	ProcessEvent(p_SetOcclusionScalingFactor, &parms);
}

void UBlueprintFunctionLibrary::SetOcclusionRefreshInterval(float RefreshInterval, struct AActor* Actor){

	static UObject* p_SetOcclusionRefreshInterval = UObject::FindObject<UFunction>("Function AkAudio.AkGameplayStatics.SetOcclusionRefreshInterval");

	struct {
		float RefreshInterval;
		struct AActor* Actor;
	} parms;

	parms.RefreshInterval = RefreshInterval;
	parms.Actor = Actor;

	ProcessEvent(p_SetOcclusionRefreshInterval, &parms);
}

void UBlueprintFunctionLibrary::SetMultiplePositions(struct UAkComponent* GameObjectAkComponent, struct TArray<struct FTransform> Positions, uint8_t  MultiPositionType){

	static UObject* p_SetMultiplePositions = UObject::FindObject<UFunction>("Function AkAudio.AkGameplayStatics.SetMultiplePositions");

	struct {
		struct UAkComponent* GameObjectAkComponent;
		struct TArray<struct FTransform> Positions;
		uint8_t  MultiPositionType;
	} parms;

	parms.GameObjectAkComponent = GameObjectAkComponent;
	parms.Positions = Positions;
	parms.MultiPositionType = MultiPositionType;

	ProcessEvent(p_SetMultiplePositions, &parms);
}

void UBlueprintFunctionLibrary::SetMultipleChannelMaskEmitterPositions(struct UAkComponent* GameObjectAkComponent, struct TArray<struct FAkChannelMask> ChannelMasks, struct TArray<struct FTransform> Positions, uint8_t  MultiPositionType){

	static UObject* p_SetMultipleChannelMaskEmitterPositions = UObject::FindObject<UFunction>("Function AkAudio.AkGameplayStatics.SetMultipleChannelMaskEmitterPositions");

	struct {
		struct UAkComponent* GameObjectAkComponent;
		struct TArray<struct FAkChannelMask> ChannelMasks;
		struct TArray<struct FTransform> Positions;
		uint8_t  MultiPositionType;
	} parms;

	parms.GameObjectAkComponent = GameObjectAkComponent;
	parms.ChannelMasks = ChannelMasks;
	parms.Positions = Positions;
	parms.MultiPositionType = MultiPositionType;

	ProcessEvent(p_SetMultipleChannelMaskEmitterPositions, &parms);
}

void UBlueprintFunctionLibrary::SetMultipleChannelEmitterPositions(struct UAkComponent* GameObjectAkComponent, struct TArray<uint8_t > ChannelMasks, struct TArray<struct FTransform> Positions, uint8_t  MultiPositionType){

	static UObject* p_SetMultipleChannelEmitterPositions = UObject::FindObject<UFunction>("Function AkAudio.AkGameplayStatics.SetMultipleChannelEmitterPositions");

	struct {
		struct UAkComponent* GameObjectAkComponent;
		struct TArray<uint8_t > ChannelMasks;
		struct TArray<struct FTransform> Positions;
		uint8_t  MultiPositionType;
	} parms;

	parms.GameObjectAkComponent = GameObjectAkComponent;
	parms.ChannelMasks = ChannelMasks;
	parms.Positions = Positions;
	parms.MultiPositionType = MultiPositionType;

	ProcessEvent(p_SetMultipleChannelEmitterPositions, &parms);
}

void UBlueprintFunctionLibrary::SetCurrentAudioCultureAsync(struct FString AudioCulture, struct FDelegate& Completed){

	static UObject* p_SetCurrentAudioCultureAsync = UObject::FindObject<UFunction>("Function AkAudio.AkGameplayStatics.SetCurrentAudioCultureAsync");

	struct {
		struct FString AudioCulture;
		struct FDelegate& Completed;
	} parms;

	parms.AudioCulture = AudioCulture;
	parms.Completed = Completed;

	ProcessEvent(p_SetCurrentAudioCultureAsync, &parms);
}

void UBlueprintFunctionLibrary::SetCurrentAudioCulture(struct FString AudioCulture, struct FLatentActionInfo LatentInfo, struct UObject* WorldContextObject){

	static UObject* p_SetCurrentAudioCulture = UObject::FindObject<UFunction>("Function AkAudio.AkGameplayStatics.SetCurrentAudioCulture");

	struct {
		struct FString AudioCulture;
		struct FLatentActionInfo LatentInfo;
		struct UObject* WorldContextObject;
	} parms;

	parms.AudioCulture = AudioCulture;
	parms.LatentInfo = LatentInfo;
	parms.WorldContextObject = WorldContextObject;

	ProcessEvent(p_SetCurrentAudioCulture, &parms);
}

void UBlueprintFunctionLibrary::SetBusConfig(struct FString BusName, uint8_t  ChannelConfiguration){

	static UObject* p_SetBusConfig = UObject::FindObject<UFunction>("Function AkAudio.AkGameplayStatics.SetBusConfig");

	struct {
		struct FString BusName;
		uint8_t  ChannelConfiguration;
	} parms;

	parms.BusName = BusName;
	parms.ChannelConfiguration = ChannelConfiguration;

	ProcessEvent(p_SetBusConfig, &parms);
}

int32_t UBlueprintFunctionLibrary::ResolveDialogueEvent(struct FString EventName, struct UAkDialogueArgumentValueNames* ArgumentValueNames, struct UObject* WorldContext){

	static UObject* p_ResolveDialogueEvent = UObject::FindObject<UFunction>("Function AkAudio.AkGameplayStatics.ResolveDialogueEvent");

	struct {
		struct FString EventName;
		struct UAkDialogueArgumentValueNames* ArgumentValueNames;
		struct UObject* WorldContext;
		int32_t return_value;
	} parms;

	parms.EventName = EventName;
	parms.ArgumentValueNames = ArgumentValueNames;
	parms.WorldContext = WorldContext;

	ProcessEvent(p_ResolveDialogueEvent, &parms);
	return parms.return_value;
}

void UBlueprintFunctionLibrary::PostTrigger(struct UAkTrigger* TriggerValue, struct AActor* Actor, struct FName Trigger){

	static UObject* p_PostTrigger = UObject::FindObject<UFunction>("Function AkAudio.AkGameplayStatics.PostTrigger");

	struct {
		struct UAkTrigger* TriggerValue;
		struct AActor* Actor;
		struct FName Trigger;
	} parms;

	parms.TriggerValue = TriggerValue;
	parms.Actor = Actor;
	parms.Trigger = Trigger;

	ProcessEvent(p_PostTrigger, &parms);
}

void UBlueprintFunctionLibrary::PostEventByName(struct FString EventName, struct AActor* Actor, bool bStopWhenAttachedToDestroyed){

	static UObject* p_PostEventByName = UObject::FindObject<UFunction>("Function AkAudio.AkGameplayStatics.PostEventByName");

	struct {
		struct FString EventName;
		struct AActor* Actor;
		bool bStopWhenAttachedToDestroyed;
	} parms;

	parms.EventName = EventName;
	parms.Actor = Actor;
	parms.bStopWhenAttachedToDestroyed = bStopWhenAttachedToDestroyed;

	ProcessEvent(p_PostEventByName, &parms);
}

int32_t UBlueprintFunctionLibrary::PostEventAttached(struct UAkAudioEvent* AkEvent, struct AActor* Actor, struct FName AttachPointName, bool bStopWhenAttachedToDestroyed, struct FString EventName){

	static UObject* p_PostEventAttached = UObject::FindObject<UFunction>("Function AkAudio.AkGameplayStatics.PostEventAttached");

	struct {
		struct UAkAudioEvent* AkEvent;
		struct AActor* Actor;
		struct FName AttachPointName;
		bool bStopWhenAttachedToDestroyed;
		struct FString EventName;
		int32_t return_value;
	} parms;

	parms.AkEvent = AkEvent;
	parms.Actor = Actor;
	parms.AttachPointName = AttachPointName;
	parms.bStopWhenAttachedToDestroyed = bStopWhenAttachedToDestroyed;
	parms.EventName = EventName;

	ProcessEvent(p_PostEventAttached, &parms);
	return parms.return_value;
}

void UBlueprintFunctionLibrary::PostEventAtLocationByName(struct FString EventName, struct FVector Location, struct FRotator Orientation, struct UObject* WorldContextObject){

	static UObject* p_PostEventAtLocationByName = UObject::FindObject<UFunction>("Function AkAudio.AkGameplayStatics.PostEventAtLocationByName");

	struct {
		struct FString EventName;
		struct FVector Location;
		struct FRotator Orientation;
		struct UObject* WorldContextObject;
	} parms;

	parms.EventName = EventName;
	parms.Location = Location;
	parms.Orientation = Orientation;
	parms.WorldContextObject = WorldContextObject;

	ProcessEvent(p_PostEventAtLocationByName, &parms);
}

int32_t UBlueprintFunctionLibrary::PostEventAtLocation(struct UAkAudioEvent* AkEvent, struct FVector Location, struct FRotator Orientation, struct FString EventName, struct UObject* WorldContextObject){

	static UObject* p_PostEventAtLocation = UObject::FindObject<UFunction>("Function AkAudio.AkGameplayStatics.PostEventAtLocation");

	struct {
		struct UAkAudioEvent* AkEvent;
		struct FVector Location;
		struct FRotator Orientation;
		struct FString EventName;
		struct UObject* WorldContextObject;
		int32_t return_value;
	} parms;

	parms.AkEvent = AkEvent;
	parms.Location = Location;
	parms.Orientation = Orientation;
	parms.EventName = EventName;
	parms.WorldContextObject = WorldContextObject;

	ProcessEvent(p_PostEventAtLocation, &parms);
	return parms.return_value;
}

int32_t UBlueprintFunctionLibrary::PostEvent(struct UAkAudioEvent* AkEvent, struct AActor* Actor, int32_t CallbackMask, struct FDelegate& PostEventCallback, struct TArray<struct FAkExternalSourceInfo>& ExternalSources, bool bStopWhenAttachedToDestroyed, struct FString EventName){

	static UObject* p_PostEvent = UObject::FindObject<UFunction>("Function AkAudio.AkGameplayStatics.PostEvent");

	struct {
		struct UAkAudioEvent* AkEvent;
		struct AActor* Actor;
		int32_t CallbackMask;
		struct FDelegate& PostEventCallback;
		struct TArray<struct FAkExternalSourceInfo>& ExternalSources;
		bool bStopWhenAttachedToDestroyed;
		struct FString EventName;
		int32_t return_value;
	} parms;

	parms.AkEvent = AkEvent;
	parms.Actor = Actor;
	parms.CallbackMask = CallbackMask;
	parms.PostEventCallback = PostEventCallback;
	parms.ExternalSources = ExternalSources;
	parms.bStopWhenAttachedToDestroyed = bStopWhenAttachedToDestroyed;
	parms.EventName = EventName;

	ProcessEvent(p_PostEvent, &parms);
	return parms.return_value;
}

void UBlueprintFunctionLibrary::PostAndWaitForEndOfEventAsync(struct UAkAudioEvent* AkEvent, struct AActor* Actor, int32_t& PlayingID, bool bStopWhenAttachedToDestroyed, struct TArray<struct FAkExternalSourceInfo>& ExternalSources, struct FLatentActionInfo LatentInfo){

	static UObject* p_PostAndWaitForEndOfEventAsync = UObject::FindObject<UFunction>("Function AkAudio.AkGameplayStatics.PostAndWaitForEndOfEventAsync");

	struct {
		struct UAkAudioEvent* AkEvent;
		struct AActor* Actor;
		int32_t& PlayingID;
		bool bStopWhenAttachedToDestroyed;
		struct TArray<struct FAkExternalSourceInfo>& ExternalSources;
		struct FLatentActionInfo LatentInfo;
	} parms;

	parms.AkEvent = AkEvent;
	parms.Actor = Actor;
	parms.PlayingID = PlayingID;
	parms.bStopWhenAttachedToDestroyed = bStopWhenAttachedToDestroyed;
	parms.ExternalSources = ExternalSources;
	parms.LatentInfo = LatentInfo;

	ProcessEvent(p_PostAndWaitForEndOfEventAsync, &parms);
}

int32_t UBlueprintFunctionLibrary::PostAndWaitForEndOfEvent(struct UAkAudioEvent* AkEvent, struct AActor* Actor, bool bStopWhenAttachedToDestroyed, struct TArray<struct FAkExternalSourceInfo>& ExternalSources, struct FString EventName, struct FLatentActionInfo LatentInfo){

	static UObject* p_PostAndWaitForEndOfEvent = UObject::FindObject<UFunction>("Function AkAudio.AkGameplayStatics.PostAndWaitForEndOfEvent");

	struct {
		struct UAkAudioEvent* AkEvent;
		struct AActor* Actor;
		bool bStopWhenAttachedToDestroyed;
		struct TArray<struct FAkExternalSourceInfo>& ExternalSources;
		struct FString EventName;
		struct FLatentActionInfo LatentInfo;
		int32_t return_value;
	} parms;

	parms.AkEvent = AkEvent;
	parms.Actor = Actor;
	parms.bStopWhenAttachedToDestroyed = bStopWhenAttachedToDestroyed;
	parms.ExternalSources = ExternalSources;
	parms.EventName = EventName;
	parms.LatentInfo = LatentInfo;

	ProcessEvent(p_PostAndWaitForEndOfEvent, &parms);
	return parms.return_value;
}

int32_t UBlueprintFunctionLibrary::PlayDynamicSequence(int32_t SequenceID, struct UObject* WorldContext){

	static UObject* p_PlayDynamicSequence = UObject::FindObject<UFunction>("Function AkAudio.AkGameplayStatics.PlayDynamicSequence");

	struct {
		int32_t SequenceID;
		struct UObject* WorldContext;
		int32_t return_value;
	} parms;

	parms.SequenceID = SequenceID;
	parms.WorldContext = WorldContext;

	ProcessEvent(p_PlayDynamicSequence, &parms);
	return parms.return_value;
}

int32_t UBlueprintFunctionLibrary::OpenDynamicSequence(struct AActor* Actor, int32_t CallbackMask, struct FDelegate& PostEventCallback){

	static UObject* p_OpenDynamicSequence = UObject::FindObject<UFunction>("Function AkAudio.AkGameplayStatics.OpenDynamicSequence");

	struct {
		struct AActor* Actor;
		int32_t CallbackMask;
		struct FDelegate& PostEventCallback;
		int32_t return_value;
	} parms;

	parms.Actor = Actor;
	parms.CallbackMask = CallbackMask;
	parms.PostEventCallback = PostEventCallback;

	ProcessEvent(p_OpenDynamicSequence, &parms);
	return parms.return_value;
}

struct UAkPlaylist* UBlueprintFunctionLibrary::LockPlayList(int32_t SequenceID, struct UObject* WorldContext){

	static UObject* p_LockPlayList = UObject::FindObject<UFunction>("Function AkAudio.AkGameplayStatics.LockPlayList");

	struct {
		int32_t SequenceID;
		struct UObject* WorldContext;
		struct UAkPlaylist* return_value;
	} parms;

	parms.SequenceID = SequenceID;
	parms.WorldContext = WorldContext;

	ProcessEvent(p_LockPlayList, &parms);
	return parms.return_value;
}

void UBlueprintFunctionLibrary::LoadInitBank(){

	static UObject* p_LoadInitBank = UObject::FindObject<UFunction>("Function AkAudio.AkGameplayStatics.LoadInitBank");

	struct {
	} parms;


	ProcessEvent(p_LoadInitBank, &parms);
}

void UBlueprintFunctionLibrary::LoadBanks(struct TArray<struct UAkAudioBank*>& SoundBanks, bool SynchronizeSoundBanks){

	static UObject* p_LoadBanks = UObject::FindObject<UFunction>("Function AkAudio.AkGameplayStatics.LoadBanks");

	struct {
		struct TArray<struct UAkAudioBank*>& SoundBanks;
		bool SynchronizeSoundBanks;
	} parms;

	parms.SoundBanks = SoundBanks;
	parms.SynchronizeSoundBanks = SynchronizeSoundBanks;

	ProcessEvent(p_LoadBanks, &parms);
}

void UBlueprintFunctionLibrary::LoadBankByName(struct FString BankName){

	static UObject* p_LoadBankByName = UObject::FindObject<UFunction>("Function AkAudio.AkGameplayStatics.LoadBankByName");

	struct {
		struct FString BankName;
	} parms;

	parms.BankName = BankName;

	ProcessEvent(p_LoadBankByName, &parms);
}

void UBlueprintFunctionLibrary::LoadBankAsync(struct UAkAudioBank* Bank, struct FDelegate& BankLoadedCallback){

	static UObject* p_LoadBankAsync = UObject::FindObject<UFunction>("Function AkAudio.AkGameplayStatics.LoadBankAsync");

	struct {
		struct UAkAudioBank* Bank;
		struct FDelegate& BankLoadedCallback;
	} parms;

	parms.Bank = Bank;
	parms.BankLoadedCallback = BankLoadedCallback;

	ProcessEvent(p_LoadBankAsync, &parms);
}

void UBlueprintFunctionLibrary::LoadBank(struct UAkAudioBank* Bank, struct FString BankName, struct FLatentActionInfo LatentInfo, struct UObject* WorldContextObject){

	static UObject* p_LoadBank = UObject::FindObject<UFunction>("Function AkAudio.AkGameplayStatics.LoadBank");

	struct {
		struct UAkAudioBank* Bank;
		struct FString BankName;
		struct FLatentActionInfo LatentInfo;
		struct UObject* WorldContextObject;
	} parms;

	parms.Bank = Bank;
	parms.BankName = BankName;
	parms.LatentInfo = LatentInfo;
	parms.WorldContextObject = WorldContextObject;

	ProcessEvent(p_LoadBank, &parms);
}

bool UBlueprintFunctionLibrary::IsGame(struct UObject* WorldContextObject){

	static UObject* p_IsGame = UObject::FindObject<UFunction>("Function AkAudio.AkGameplayStatics.IsGame");

	struct {
		struct UObject* WorldContextObject;
		bool return_value;
	} parms;

	parms.WorldContextObject = WorldContextObject;

	ProcessEvent(p_IsGame, &parms);
	return parms.return_value;
}

bool UBlueprintFunctionLibrary::IsEditor(){

	static UObject* p_IsEditor = UObject::FindObject<UFunction>("Function AkAudio.AkGameplayStatics.IsEditor");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_IsEditor, &parms);
	return parms.return_value;
}

void UBlueprintFunctionLibrary::GetSpeakerAngles(struct TArray<float>& SpeakerAngles, float& HeightAngle, struct FString DeviceShareset){

	static UObject* p_GetSpeakerAngles = UObject::FindObject<UFunction>("Function AkAudio.AkGameplayStatics.GetSpeakerAngles");

	struct {
		struct TArray<float>& SpeakerAngles;
		float& HeightAngle;
		struct FString DeviceShareset;
	} parms;

	parms.SpeakerAngles = SpeakerAngles;
	parms.HeightAngle = HeightAngle;
	parms.DeviceShareset = DeviceShareset;

	ProcessEvent(p_GetSpeakerAngles, &parms);
}

void UBlueprintFunctionLibrary::GetRTPCValue(struct UAkRtpc* RTPCValue, int32_t PlayingID, uint8_t  InputValueType, float& Value, uint8_t & OutputValueType, struct AActor* Actor, struct FName RTPC){

	static UObject* p_GetRTPCValue = UObject::FindObject<UFunction>("Function AkAudio.AkGameplayStatics.GetRTPCValue");

	struct {
		struct UAkRtpc* RTPCValue;
		int32_t PlayingID;
		uint8_t  InputValueType;
		float& Value;
		uint8_t & OutputValueType;
		struct AActor* Actor;
		struct FName RTPC;
	} parms;

	parms.RTPCValue = RTPCValue;
	parms.PlayingID = PlayingID;
	parms.InputValueType = InputValueType;
	parms.Value = Value;
	parms.OutputValueType = OutputValueType;
	parms.Actor = Actor;
	parms.RTPC = RTPC;

	ProcessEvent(p_GetRTPCValue, &parms);
}

float UBlueprintFunctionLibrary::GetOcclusionScalingFactor(){

	static UObject* p_GetOcclusionScalingFactor = UObject::FindObject<UFunction>("Function AkAudio.AkGameplayStatics.GetOcclusionScalingFactor");

	struct {
		float return_value;
	} parms;


	ProcessEvent(p_GetOcclusionScalingFactor, &parms);
	return parms.return_value;
}

struct FString UBlueprintFunctionLibrary::GetCurrentAudioCulture(){

	static UObject* p_GetCurrentAudioCulture = UObject::FindObject<UFunction>("Function AkAudio.AkGameplayStatics.GetCurrentAudioCulture");

	struct {
		struct FString return_value;
	} parms;


	ProcessEvent(p_GetCurrentAudioCulture, &parms);
	return parms.return_value;
}

struct TArray<struct FString> UBlueprintFunctionLibrary::GetAvailableAudioCultures(){

	static UObject* p_GetAvailableAudioCultures = UObject::FindObject<UFunction>("Function AkAudio.AkGameplayStatics.GetAvailableAudioCultures");

	struct {
		struct TArray<struct FString> return_value;
	} parms;


	ProcessEvent(p_GetAvailableAudioCultures, &parms);
	return parms.return_value;
}

struct UObject* UBlueprintFunctionLibrary::GetAkMediaAssetUserData(struct UAkMediaAsset* Instance, UObject* Type){

	static UObject* p_GetAkMediaAssetUserData = UObject::FindObject<UFunction>("Function AkAudio.AkGameplayStatics.GetAkMediaAssetUserData");

	struct {
		struct UAkMediaAsset* Instance;
		UObject* Type;
		struct UObject* return_value;
	} parms;

	parms.Instance = Instance;
	parms.Type = Type;

	ProcessEvent(p_GetAkMediaAssetUserData, &parms);
	return parms.return_value;
}

struct UAkComponent* UBlueprintFunctionLibrary::GetAkComponent(struct USceneComponent* AttachToComponent, bool& ComponentCreated, struct FName AttachPointName, struct FVector Location, char EAttachLocation LocationType){

	static UObject* p_GetAkComponent = UObject::FindObject<UFunction>("Function AkAudio.AkGameplayStatics.GetAkComponent");

	struct {
		struct USceneComponent* AttachToComponent;
		bool& ComponentCreated;
		struct FName AttachPointName;
		struct FVector Location;
		char EAttachLocation LocationType;
		struct UAkComponent* return_value;
	} parms;

	parms.AttachToComponent = AttachToComponent;
	parms.ComponentCreated = ComponentCreated;
	parms.AttachPointName = AttachPointName;
	parms.Location = Location;
	parms.LocationType = LocationType;

	ProcessEvent(p_GetAkComponent, &parms);
	return parms.return_value;
}

struct UObject* UBlueprintFunctionLibrary::GetAkAudioTypeUserData(struct UAkAudioType* Instance, UObject* Type){

	static UObject* p_GetAkAudioTypeUserData = UObject::FindObject<UFunction>("Function AkAudio.AkGameplayStatics.GetAkAudioTypeUserData");

	struct {
		struct UAkAudioType* Instance;
		UObject* Type;
		struct UObject* return_value;
	} parms;

	parms.Instance = Instance;
	parms.Type = Type;

	ProcessEvent(p_GetAkAudioTypeUserData, &parms);
	return parms.return_value;
}

void UBlueprintFunctionLibrary::ForceAudioDeviceUpdate(float DeltaTime){

	static UObject* p_ForceAudioDeviceUpdate = UObject::FindObject<UFunction>("Function AkAudio.AkGameplayStatics.ForceAudioDeviceUpdate");

	struct {
		float DeltaTime;
	} parms;

	parms.DeltaTime = DeltaTime;

	ProcessEvent(p_ForceAudioDeviceUpdate, &parms);
}

void UBlueprintFunctionLibrary::ExecuteActionOnPlayingID(uint8_t  ActionType, int32_t PlayingID, int32_t TransitionDuration, uint8_t  FadeCurve){

	static UObject* p_ExecuteActionOnPlayingID = UObject::FindObject<UFunction>("Function AkAudio.AkGameplayStatics.ExecuteActionOnPlayingID");

	struct {
		uint8_t  ActionType;
		int32_t PlayingID;
		int32_t TransitionDuration;
		uint8_t  FadeCurve;
	} parms;

	parms.ActionType = ActionType;
	parms.PlayingID = PlayingID;
	parms.TransitionDuration = TransitionDuration;
	parms.FadeCurve = FadeCurve;

	ProcessEvent(p_ExecuteActionOnPlayingID, &parms);
}

void UBlueprintFunctionLibrary::ExecuteActionOnEvent(struct UAkAudioEvent* AkEvent, uint8_t  ActionType, struct AActor* Actor, int32_t TransitionDuration, uint8_t  FadeCurve, int32_t PlayingID){

	static UObject* p_ExecuteActionOnEvent = UObject::FindObject<UFunction>("Function AkAudio.AkGameplayStatics.ExecuteActionOnEvent");

	struct {
		struct UAkAudioEvent* AkEvent;
		uint8_t  ActionType;
		struct AActor* Actor;
		int32_t TransitionDuration;
		uint8_t  FadeCurve;
		int32_t PlayingID;
	} parms;

	parms.AkEvent = AkEvent;
	parms.ActionType = ActionType;
	parms.Actor = Actor;
	parms.TransitionDuration = TransitionDuration;
	parms.FadeCurve = FadeCurve;
	parms.PlayingID = PlayingID;

	ProcessEvent(p_ExecuteActionOnEvent, &parms);
}

int32_t UBlueprintFunctionLibrary::CloseDynamicSequence(int32_t SequenceID, struct UObject* WorldContext){

	static UObject* p_CloseDynamicSequence = UObject::FindObject<UFunction>("Function AkAudio.AkGameplayStatics.CloseDynamicSequence");

	struct {
		int32_t SequenceID;
		struct UObject* WorldContext;
		int32_t return_value;
	} parms;

	parms.SequenceID = SequenceID;
	parms.WorldContext = WorldContext;

	ProcessEvent(p_CloseDynamicSequence, &parms);
	return parms.return_value;
}

void UBlueprintFunctionLibrary::ClearBanks(){

	static UObject* p_ClearBanks = UObject::FindObject<UFunction>("Function AkAudio.AkGameplayStatics.ClearBanks");

	struct {
	} parms;


	ProcessEvent(p_ClearBanks, &parms);
}

void UBlueprintFunctionLibrary::CancelEventCallback(struct FDelegate& PostEventCallback){

	static UObject* p_CancelEventCallback = UObject::FindObject<UFunction>("Function AkAudio.AkGameplayStatics.CancelEventCallback");

	struct {
		struct FDelegate& PostEventCallback;
	} parms;

	parms.PostEventCallback = PostEventCallback;

	ProcessEvent(p_CancelEventCallback, &parms);
}

void UBlueprintFunctionLibrary::AddOutputCaptureMarker(struct FString MarkerText){

	static UObject* p_AddOutputCaptureMarker = UObject::FindObject<UFunction>("Function AkAudio.AkGameplayStatics.AddOutputCaptureMarker");

	struct {
		struct FString MarkerText;
	} parms;

	parms.MarkerText = MarkerText;

	ProcessEvent(p_AddOutputCaptureMarker, &parms);
}

void UObject::BeginDestroy(){

	static UObject* p_BeginDestroy = UObject::FindObject<UFunction>("Function AkAudio.AkDialogueArgumentValueNames.BeginDestroy");

	struct {
	} parms;


	ProcessEvent(p_BeginDestroy, &parms);
}

void UObject::AddArgumentValueName(struct FString& ArgumentValueName){

	static UObject* p_AddArgumentValueName = UObject::FindObject<UFunction>("Function AkAudio.AkDialogueArgumentValueNames.AddArgumentValueName");

	struct {
		struct FString& ArgumentValueName;
	} parms;

	parms.ArgumentValueName = ArgumentValueName;

	ProcessEvent(p_AddArgumentValueName, &parms);
}

uint8_t  UAkEventCallbackInfo::GetType(){

	static UObject* p_GetType = UObject::FindObject<UFunction>("Function AkAudio.AkMIDIEventCallbackInfo.GetType");

	struct {
		uint8_t  return_value;
	} parms;


	ProcessEvent(p_GetType, &parms);
	return parms.return_value;
}

bool UAkEventCallbackInfo::GetProgramChange(struct FAkMidiProgramChange& AsProgramChange){

	static UObject* p_GetProgramChange = UObject::FindObject<UFunction>("Function AkAudio.AkMIDIEventCallbackInfo.GetProgramChange");

	struct {
		struct FAkMidiProgramChange& AsProgramChange;
		bool return_value;
	} parms;

	parms.AsProgramChange = AsProgramChange;

	ProcessEvent(p_GetProgramChange, &parms);
	return parms.return_value;
}

bool UAkEventCallbackInfo::GetPitchBend(struct FAkMidiPitchBend& AsPitchBend){

	static UObject* p_GetPitchBend = UObject::FindObject<UFunction>("Function AkAudio.AkMIDIEventCallbackInfo.GetPitchBend");

	struct {
		struct FAkMidiPitchBend& AsPitchBend;
		bool return_value;
	} parms;

	parms.AsPitchBend = AsPitchBend;

	ProcessEvent(p_GetPitchBend, &parms);
	return parms.return_value;
}

bool UAkEventCallbackInfo::GetNoteOn(struct FAkMidiNoteOnOff& AsNoteOn){

	static UObject* p_GetNoteOn = UObject::FindObject<UFunction>("Function AkAudio.AkMIDIEventCallbackInfo.GetNoteOn");

	struct {
		struct FAkMidiNoteOnOff& AsNoteOn;
		bool return_value;
	} parms;

	parms.AsNoteOn = AsNoteOn;

	ProcessEvent(p_GetNoteOn, &parms);
	return parms.return_value;
}

bool UAkEventCallbackInfo::GetNoteOff(struct FAkMidiNoteOnOff& AsNoteOff){

	static UObject* p_GetNoteOff = UObject::FindObject<UFunction>("Function AkAudio.AkMIDIEventCallbackInfo.GetNoteOff");

	struct {
		struct FAkMidiNoteOnOff& AsNoteOff;
		bool return_value;
	} parms;

	parms.AsNoteOff = AsNoteOff;

	ProcessEvent(p_GetNoteOff, &parms);
	return parms.return_value;
}

bool UAkEventCallbackInfo::GetNoteAftertouch(struct FAkMidiNoteAftertouch& AsNoteAftertouch){

	static UObject* p_GetNoteAftertouch = UObject::FindObject<UFunction>("Function AkAudio.AkMIDIEventCallbackInfo.GetNoteAftertouch");

	struct {
		struct FAkMidiNoteAftertouch& AsNoteAftertouch;
		bool return_value;
	} parms;

	parms.AsNoteAftertouch = AsNoteAftertouch;

	ProcessEvent(p_GetNoteAftertouch, &parms);
	return parms.return_value;
}

bool UAkEventCallbackInfo::GetGeneric(struct FAkMidiGeneric& AsGeneric){

	static UObject* p_GetGeneric = UObject::FindObject<UFunction>("Function AkAudio.AkMIDIEventCallbackInfo.GetGeneric");

	struct {
		struct FAkMidiGeneric& AsGeneric;
		bool return_value;
	} parms;

	parms.AsGeneric = AsGeneric;

	ProcessEvent(p_GetGeneric, &parms);
	return parms.return_value;
}

bool UAkEventCallbackInfo::GetChannelAftertouch(struct FAkMidiChannelAftertouch& AsChannelAftertouch){

	static UObject* p_GetChannelAftertouch = UObject::FindObject<UFunction>("Function AkAudio.AkMIDIEventCallbackInfo.GetChannelAftertouch");

	struct {
		struct FAkMidiChannelAftertouch& AsChannelAftertouch;
		bool return_value;
	} parms;

	parms.AsChannelAftertouch = AsChannelAftertouch;

	ProcessEvent(p_GetChannelAftertouch, &parms);
	return parms.return_value;
}

char UAkEventCallbackInfo::GetChannel(){

	static UObject* p_GetChannel = UObject::FindObject<UFunction>("Function AkAudio.AkMIDIEventCallbackInfo.GetChannel");

	struct {
		char return_value;
	} parms;


	ProcessEvent(p_GetChannel, &parms);
	return parms.return_value;
}

bool UAkEventCallbackInfo::GetCc(struct FAkMidiCc& AsCc){

	static UObject* p_GetCc = UObject::FindObject<UFunction>("Function AkAudio.AkMIDIEventCallbackInfo.GetCc");

	struct {
		struct FAkMidiCc& AsCc;
		bool return_value;
	} parms;

	parms.AsCc = AsCc;

	ProcessEvent(p_GetCc, &parms);
	return parms.return_value;
}

struct FText UBlueprintFunctionLibrary::Conv_FAkBoolPropertyToControlToText(struct FAkBoolPropertyToControl& INAkBoolPropertyToControl){

	static UObject* p_Conv_FAkBoolPropertyToControlToText = UObject::FindObject<UFunction>("Function AkAudio.AkItemBoolPropertiesConv.Conv_FAkBoolPropertyToControlToText");

	struct {
		struct FAkBoolPropertyToControl& INAkBoolPropertyToControl;
		struct FText return_value;
	} parms;

	parms.INAkBoolPropertyToControl = INAkBoolPropertyToControl;

	ProcessEvent(p_Conv_FAkBoolPropertyToControlToText, &parms);
	return parms.return_value;
}

struct FString UBlueprintFunctionLibrary::Conv_FAkBoolPropertyToControlToString(struct FAkBoolPropertyToControl& INAkBoolPropertyToControl){

	static UObject* p_Conv_FAkBoolPropertyToControlToString = UObject::FindObject<UFunction>("Function AkAudio.AkItemBoolPropertiesConv.Conv_FAkBoolPropertyToControlToString");

	struct {
		struct FAkBoolPropertyToControl& INAkBoolPropertyToControl;
		struct FString return_value;
	} parms;

	parms.INAkBoolPropertyToControl = INAkBoolPropertyToControl;

	ProcessEvent(p_Conv_FAkBoolPropertyToControlToString, &parms);
	return parms.return_value;
}

struct FText UBlueprintFunctionLibrary::Conv_FAkPropertyToControlToText(struct FAkPropertyToControl& INAkPropertyToControl){

	static UObject* p_Conv_FAkPropertyToControlToText = UObject::FindObject<UFunction>("Function AkAudio.AkItemPropertiesConv.Conv_FAkPropertyToControlToText");

	struct {
		struct FAkPropertyToControl& INAkPropertyToControl;
		struct FText return_value;
	} parms;

	parms.INAkPropertyToControl = INAkPropertyToControl;

	ProcessEvent(p_Conv_FAkPropertyToControlToText, &parms);
	return parms.return_value;
}

struct FString UBlueprintFunctionLibrary::Conv_FAkPropertyToControlToString(struct FAkPropertyToControl& INAkPropertyToControl){

	static UObject* p_Conv_FAkPropertyToControlToString = UObject::FindObject<UFunction>("Function AkAudio.AkItemPropertiesConv.Conv_FAkPropertyToControlToString");

	struct {
		struct FAkPropertyToControl& INAkPropertyToControl;
		struct FString return_value;
	} parms;

	parms.INAkPropertyToControl = INAkPropertyToControl;

	ProcessEvent(p_Conv_FAkPropertyToControlToString, &parms);
	return parms.return_value;
}

void UWidget::SetSearchText(struct FString newText){

	static UObject* p_SetSearchText = UObject::FindObject<UFunction>("Function AkAudio.AkItemProperties.SetSearchText");

	struct {
		struct FString newText;
	} parms;

	parms.newText = newText;

	ProcessEvent(p_SetSearchText, &parms);
}

struct FString UWidget::GetSelectedProperty(){

	static UObject* p_GetSelectedProperty = UObject::FindObject<UFunction>("Function AkAudio.AkItemProperties.GetSelectedProperty");

	struct {
		struct FString return_value;
	} parms;


	ProcessEvent(p_GetSelectedProperty, &parms);
	return parms.return_value;
}

struct FString UWidget::GetSearchText(){

	static UObject* p_GetSearchText = UObject::FindObject<UFunction>("Function AkAudio.AkItemProperties.GetSearchText");

	struct {
		struct FString return_value;
	} parms;


	ProcessEvent(p_GetSearchText, &parms);
	return parms.return_value;
}

void UObject::MigrateMultiCoreRendering(bool NewValue){

	static UObject* p_MigrateMultiCoreRendering = UObject::FindObject<UFunction>("Function AkAudio.AkMacInitializationSettings.MigrateMultiCoreRendering");

	struct {
		bool NewValue;
	} parms;

	parms.NewValue = NewValue;

	ProcessEvent(p_MigrateMultiCoreRendering, &parms);
}

void UObject::MigrateMultiCoreRendering(bool NewValue){

	static UObject* p_MigrateMultiCoreRendering = UObject::FindObject<UFunction>("Function AkAudio.AkSwitchInitializationSettings.MigrateMultiCoreRendering");

	struct {
		bool NewValue;
	} parms;

	parms.NewValue = NewValue;

	ProcessEvent(p_MigrateMultiCoreRendering, &parms);
}

struct FAKWaapiJsonObject UBlueprintFunctionLibrary::Unsubscribe(struct FAkWaapiSubscriptionId& SubscriptionId, bool& UnsubscriptionDone){

	static UObject* p_Unsubscribe = UObject::FindObject<UFunction>("Function AkAudio.AkWaapiCalls.Unsubscribe");

	struct {
		struct FAkWaapiSubscriptionId& SubscriptionId;
		bool& UnsubscriptionDone;
		struct FAKWaapiJsonObject return_value;
	} parms;

	parms.SubscriptionId = SubscriptionId;
	parms.UnsubscriptionDone = UnsubscriptionDone;

	ProcessEvent(p_Unsubscribe, &parms);
	return parms.return_value;
}

struct FAKWaapiJsonObject UBlueprintFunctionLibrary::SubscribeToWaapi(struct FAkWaapiUri& WaapiUri, struct FAKWaapiJsonObject& WaapiOptions, struct FDelegate& Callback, struct FAkWaapiSubscriptionId& SubscriptionId, bool& SubscriptionDone){

	static UObject* p_SubscribeToWaapi = UObject::FindObject<UFunction>("Function AkAudio.AkWaapiCalls.SubscribeToWaapi");

	struct {
		struct FAkWaapiUri& WaapiUri;
		struct FAKWaapiJsonObject& WaapiOptions;
		struct FDelegate& Callback;
		struct FAkWaapiSubscriptionId& SubscriptionId;
		bool& SubscriptionDone;
		struct FAKWaapiJsonObject return_value;
	} parms;

	parms.WaapiUri = WaapiUri;
	parms.WaapiOptions = WaapiOptions;
	parms.Callback = Callback;
	parms.SubscriptionId = SubscriptionId;
	parms.SubscriptionDone = SubscriptionDone;

	ProcessEvent(p_SubscribeToWaapi, &parms);
	return parms.return_value;
}

void UBlueprintFunctionLibrary::SetSubscriptionID(struct FAkWaapiSubscriptionId& Subscription, int32_t ID){

	static UObject* p_SetSubscriptionID = UObject::FindObject<UFunction>("Function AkAudio.AkWaapiCalls.SetSubscriptionID");

	struct {
		struct FAkWaapiSubscriptionId& Subscription;
		int32_t ID;
	} parms;

	parms.Subscription = Subscription;
	parms.ID = ID;

	ProcessEvent(p_SetSubscriptionID, &parms);
}

bool UBlueprintFunctionLibrary::RegisterWaapiProjectLoadedCallback(struct FDelegate& Callback){

	static UObject* p_RegisterWaapiProjectLoadedCallback = UObject::FindObject<UFunction>("Function AkAudio.AkWaapiCalls.RegisterWaapiProjectLoadedCallback");

	struct {
		struct FDelegate& Callback;
		bool return_value;
	} parms;

	parms.Callback = Callback;

	ProcessEvent(p_RegisterWaapiProjectLoadedCallback, &parms);
	return parms.return_value;
}

bool UBlueprintFunctionLibrary::RegisterWaapiConnectionLostCallback(struct FDelegate& Callback){

	static UObject* p_RegisterWaapiConnectionLostCallback = UObject::FindObject<UFunction>("Function AkAudio.AkWaapiCalls.RegisterWaapiConnectionLostCallback");

	struct {
		struct FDelegate& Callback;
		bool return_value;
	} parms;

	parms.Callback = Callback;

	ProcessEvent(p_RegisterWaapiConnectionLostCallback, &parms);
	return parms.return_value;
}

int32_t UBlueprintFunctionLibrary::GetSubscriptionID(struct FAkWaapiSubscriptionId& Subscription){

	static UObject* p_GetSubscriptionID = UObject::FindObject<UFunction>("Function AkAudio.AkWaapiCalls.GetSubscriptionID");

	struct {
		struct FAkWaapiSubscriptionId& Subscription;
		int32_t return_value;
	} parms;

	parms.Subscription = Subscription;

	ProcessEvent(p_GetSubscriptionID, &parms);
	return parms.return_value;
}

struct FText UBlueprintFunctionLibrary::Conv_FAkWaapiSubscriptionIdToText(struct FAkWaapiSubscriptionId& INAkWaapiSubscriptionId){

	static UObject* p_Conv_FAkWaapiSubscriptionIdToText = UObject::FindObject<UFunction>("Function AkAudio.AkWaapiCalls.Conv_FAkWaapiSubscriptionIdToText");

	struct {
		struct FAkWaapiSubscriptionId& INAkWaapiSubscriptionId;
		struct FText return_value;
	} parms;

	parms.INAkWaapiSubscriptionId = INAkWaapiSubscriptionId;

	ProcessEvent(p_Conv_FAkWaapiSubscriptionIdToText, &parms);
	return parms.return_value;
}

struct FString UBlueprintFunctionLibrary::Conv_FAkWaapiSubscriptionIdToString(struct FAkWaapiSubscriptionId& INAkWaapiSubscriptionId){

	static UObject* p_Conv_FAkWaapiSubscriptionIdToString = UObject::FindObject<UFunction>("Function AkAudio.AkWaapiCalls.Conv_FAkWaapiSubscriptionIdToString");

	struct {
		struct FAkWaapiSubscriptionId& INAkWaapiSubscriptionId;
		struct FString return_value;
	} parms;

	parms.INAkWaapiSubscriptionId = INAkWaapiSubscriptionId;

	ProcessEvent(p_Conv_FAkWaapiSubscriptionIdToString, &parms);
	return parms.return_value;
}

struct FAKWaapiJsonObject UBlueprintFunctionLibrary::CallWaapi(struct FAkWaapiUri& WaapiUri, struct FAKWaapiJsonObject& WaapiArgs, struct FAKWaapiJsonObject& WaapiOptions){

	static UObject* p_CallWaapi = UObject::FindObject<UFunction>("Function AkAudio.AkWaapiCalls.CallWaapi");

	struct {
		struct FAkWaapiUri& WaapiUri;
		struct FAKWaapiJsonObject& WaapiArgs;
		struct FAKWaapiJsonObject& WaapiOptions;
		struct FAKWaapiJsonObject return_value;
	} parms;

	parms.WaapiUri = WaapiUri;
	parms.WaapiArgs = WaapiArgs;
	parms.WaapiOptions = WaapiOptions;

	ProcessEvent(p_CallWaapi, &parms);
	return parms.return_value;
}

struct FText UBlueprintFunctionLibrary::Conv_FAkWaapiFieldNamesToText(struct FAkWaapiFieldNames& INAkWaapiFieldNames){

	static UObject* p_Conv_FAkWaapiFieldNamesToText = UObject::FindObject<UFunction>("Function AkAudio.SAkWaapiFieldNamesConv.Conv_FAkWaapiFieldNamesToText");

	struct {
		struct FAkWaapiFieldNames& INAkWaapiFieldNames;
		struct FText return_value;
	} parms;

	parms.INAkWaapiFieldNames = INAkWaapiFieldNames;

	ProcessEvent(p_Conv_FAkWaapiFieldNamesToText, &parms);
	return parms.return_value;
}

struct FString UBlueprintFunctionLibrary::Conv_FAkWaapiFieldNamesToString(struct FAkWaapiFieldNames& INAkWaapiFieldNames){

	static UObject* p_Conv_FAkWaapiFieldNamesToString = UObject::FindObject<UFunction>("Function AkAudio.SAkWaapiFieldNamesConv.Conv_FAkWaapiFieldNamesToString");

	struct {
		struct FAkWaapiFieldNames& INAkWaapiFieldNames;
		struct FString return_value;
	} parms;

	parms.INAkWaapiFieldNames = INAkWaapiFieldNames;

	ProcessEvent(p_Conv_FAkWaapiFieldNamesToString, &parms);
	return parms.return_value;
}

struct FAKWaapiJsonObject UBlueprintFunctionLibrary::SetStringField(struct FAkWaapiFieldNames& FieldName, struct FString FieldValue, struct FAKWaapiJsonObject Target){

	static UObject* p_SetStringField = UObject::FindObject<UFunction>("Function AkAudio.AkWaapiJsonManager.SetStringField");

	struct {
		struct FAkWaapiFieldNames& FieldName;
		struct FString FieldValue;
		struct FAKWaapiJsonObject Target;
		struct FAKWaapiJsonObject return_value;
	} parms;

	parms.FieldName = FieldName;
	parms.FieldValue = FieldValue;
	parms.Target = Target;

	ProcessEvent(p_SetStringField, &parms);
	return parms.return_value;
}

struct FAKWaapiJsonObject UBlueprintFunctionLibrary::SetObjectField(struct FAkWaapiFieldNames& FieldName, struct FAKWaapiJsonObject FieldValue, struct FAKWaapiJsonObject Target){

	static UObject* p_SetObjectField = UObject::FindObject<UFunction>("Function AkAudio.AkWaapiJsonManager.SetObjectField");

	struct {
		struct FAkWaapiFieldNames& FieldName;
		struct FAKWaapiJsonObject FieldValue;
		struct FAKWaapiJsonObject Target;
		struct FAKWaapiJsonObject return_value;
	} parms;

	parms.FieldName = FieldName;
	parms.FieldValue = FieldValue;
	parms.Target = Target;

	ProcessEvent(p_SetObjectField, &parms);
	return parms.return_value;
}

struct FAKWaapiJsonObject UBlueprintFunctionLibrary::SetNumberField(struct FAkWaapiFieldNames& FieldName, float FieldValue, struct FAKWaapiJsonObject Target){

	static UObject* p_SetNumberField = UObject::FindObject<UFunction>("Function AkAudio.AkWaapiJsonManager.SetNumberField");

	struct {
		struct FAkWaapiFieldNames& FieldName;
		float FieldValue;
		struct FAKWaapiJsonObject Target;
		struct FAKWaapiJsonObject return_value;
	} parms;

	parms.FieldName = FieldName;
	parms.FieldValue = FieldValue;
	parms.Target = Target;

	ProcessEvent(p_SetNumberField, &parms);
	return parms.return_value;
}

struct FAKWaapiJsonObject UBlueprintFunctionLibrary::SetBoolField(struct FAkWaapiFieldNames& FieldName, bool FieldValue, struct FAKWaapiJsonObject Target){

	static UObject* p_SetBoolField = UObject::FindObject<UFunction>("Function AkAudio.AkWaapiJsonManager.SetBoolField");

	struct {
		struct FAkWaapiFieldNames& FieldName;
		bool FieldValue;
		struct FAKWaapiJsonObject Target;
		struct FAKWaapiJsonObject return_value;
	} parms;

	parms.FieldName = FieldName;
	parms.FieldValue = FieldValue;
	parms.Target = Target;

	ProcessEvent(p_SetBoolField, &parms);
	return parms.return_value;
}

struct FAKWaapiJsonObject UBlueprintFunctionLibrary::SetArrayStringFields(struct FAkWaapiFieldNames& FieldName, struct TArray<struct FString>& FieldStringValues, struct FAKWaapiJsonObject Target){

	static UObject* p_SetArrayStringFields = UObject::FindObject<UFunction>("Function AkAudio.AkWaapiJsonManager.SetArrayStringFields");

	struct {
		struct FAkWaapiFieldNames& FieldName;
		struct TArray<struct FString>& FieldStringValues;
		struct FAKWaapiJsonObject Target;
		struct FAKWaapiJsonObject return_value;
	} parms;

	parms.FieldName = FieldName;
	parms.FieldStringValues = FieldStringValues;
	parms.Target = Target;

	ProcessEvent(p_SetArrayStringFields, &parms);
	return parms.return_value;
}

struct FAKWaapiJsonObject UBlueprintFunctionLibrary::SetArrayObjectFields(struct FAkWaapiFieldNames& FieldName, struct TArray<struct FAKWaapiJsonObject>& FieldObjectValues, struct FAKWaapiJsonObject Target){

	static UObject* p_SetArrayObjectFields = UObject::FindObject<UFunction>("Function AkAudio.AkWaapiJsonManager.SetArrayObjectFields");

	struct {
		struct FAkWaapiFieldNames& FieldName;
		struct TArray<struct FAKWaapiJsonObject>& FieldObjectValues;
		struct FAKWaapiJsonObject Target;
		struct FAKWaapiJsonObject return_value;
	} parms;

	parms.FieldName = FieldName;
	parms.FieldObjectValues = FieldObjectValues;
	parms.Target = Target;

	ProcessEvent(p_SetArrayObjectFields, &parms);
	return parms.return_value;
}

struct FString UBlueprintFunctionLibrary::GetStringField(struct FAkWaapiFieldNames& FieldName, struct FAKWaapiJsonObject Target){

	static UObject* p_GetStringField = UObject::FindObject<UFunction>("Function AkAudio.AkWaapiJsonManager.GetStringField");

	struct {
		struct FAkWaapiFieldNames& FieldName;
		struct FAKWaapiJsonObject Target;
		struct FString return_value;
	} parms;

	parms.FieldName = FieldName;
	parms.Target = Target;

	ProcessEvent(p_GetStringField, &parms);
	return parms.return_value;
}

struct FAKWaapiJsonObject UBlueprintFunctionLibrary::GetObjectField(struct FAkWaapiFieldNames& FieldName, struct FAKWaapiJsonObject Target){

	static UObject* p_GetObjectField = UObject::FindObject<UFunction>("Function AkAudio.AkWaapiJsonManager.GetObjectField");

	struct {
		struct FAkWaapiFieldNames& FieldName;
		struct FAKWaapiJsonObject Target;
		struct FAKWaapiJsonObject return_value;
	} parms;

	parms.FieldName = FieldName;
	parms.Target = Target;

	ProcessEvent(p_GetObjectField, &parms);
	return parms.return_value;
}

float UBlueprintFunctionLibrary::GetNumberField(struct FAkWaapiFieldNames& FieldName, struct FAKWaapiJsonObject Target){

	static UObject* p_GetNumberField = UObject::FindObject<UFunction>("Function AkAudio.AkWaapiJsonManager.GetNumberField");

	struct {
		struct FAkWaapiFieldNames& FieldName;
		struct FAKWaapiJsonObject Target;
		float return_value;
	} parms;

	parms.FieldName = FieldName;
	parms.Target = Target;

	ProcessEvent(p_GetNumberField, &parms);
	return parms.return_value;
}

int32_t UBlueprintFunctionLibrary::GetIntegerField(struct FAkWaapiFieldNames& FieldName, struct FAKWaapiJsonObject Target){

	static UObject* p_GetIntegerField = UObject::FindObject<UFunction>("Function AkAudio.AkWaapiJsonManager.GetIntegerField");

	struct {
		struct FAkWaapiFieldNames& FieldName;
		struct FAKWaapiJsonObject Target;
		int32_t return_value;
	} parms;

	parms.FieldName = FieldName;
	parms.Target = Target;

	ProcessEvent(p_GetIntegerField, &parms);
	return parms.return_value;
}

bool UBlueprintFunctionLibrary::GetBoolField(struct FAkWaapiFieldNames& FieldName, struct FAKWaapiJsonObject Target){

	static UObject* p_GetBoolField = UObject::FindObject<UFunction>("Function AkAudio.AkWaapiJsonManager.GetBoolField");

	struct {
		struct FAkWaapiFieldNames& FieldName;
		struct FAKWaapiJsonObject Target;
		bool return_value;
	} parms;

	parms.FieldName = FieldName;
	parms.Target = Target;

	ProcessEvent(p_GetBoolField, &parms);
	return parms.return_value;
}

struct TArray<struct FAKWaapiJsonObject> UBlueprintFunctionLibrary::GetArrayField(struct FAkWaapiFieldNames& FieldName, struct FAKWaapiJsonObject Target){

	static UObject* p_GetArrayField = UObject::FindObject<UFunction>("Function AkAudio.AkWaapiJsonManager.GetArrayField");

	struct {
		struct FAkWaapiFieldNames& FieldName;
		struct FAKWaapiJsonObject Target;
		struct TArray<struct FAKWaapiJsonObject> return_value;
	} parms;

	parms.FieldName = FieldName;
	parms.Target = Target;

	ProcessEvent(p_GetArrayField, &parms);
	return parms.return_value;
}

struct FText UBlueprintFunctionLibrary::Conv_FAKWaapiJsonObjectToText(struct FAKWaapiJsonObject INAKWaapiJsonObject){

	static UObject* p_Conv_FAKWaapiJsonObjectToText = UObject::FindObject<UFunction>("Function AkAudio.AkWaapiJsonManager.Conv_FAKWaapiJsonObjectToText");

	struct {
		struct FAKWaapiJsonObject INAKWaapiJsonObject;
		struct FText return_value;
	} parms;

	parms.INAKWaapiJsonObject = INAKWaapiJsonObject;

	ProcessEvent(p_Conv_FAKWaapiJsonObjectToText, &parms);
	return parms.return_value;
}

struct FString UBlueprintFunctionLibrary::Conv_FAKWaapiJsonObjectToString(struct FAKWaapiJsonObject INAKWaapiJsonObject){

	static UObject* p_Conv_FAKWaapiJsonObjectToString = UObject::FindObject<UFunction>("Function AkAudio.AkWaapiJsonManager.Conv_FAKWaapiJsonObjectToString");

	struct {
		struct FAKWaapiJsonObject INAKWaapiJsonObject;
		struct FString return_value;
	} parms;

	parms.INAKWaapiJsonObject = INAKWaapiJsonObject;

	ProcessEvent(p_Conv_FAKWaapiJsonObjectToString, &parms);
	return parms.return_value;
}

struct FText UBlueprintFunctionLibrary::Conv_FAkWaapiUriToText(struct FAkWaapiUri& INAkWaapiUri){

	static UObject* p_Conv_FAkWaapiUriToText = UObject::FindObject<UFunction>("Function AkAudio.AkWaapiUriConv.Conv_FAkWaapiUriToText");

	struct {
		struct FAkWaapiUri& INAkWaapiUri;
		struct FText return_value;
	} parms;

	parms.INAkWaapiUri = INAkWaapiUri;

	ProcessEvent(p_Conv_FAkWaapiUriToText, &parms);
	return parms.return_value;
}

struct FString UBlueprintFunctionLibrary::Conv_FAkWaapiUriToString(struct FAkWaapiUri& INAkWaapiUri){

	static UObject* p_Conv_FAkWaapiUriToString = UObject::FindObject<UFunction>("Function AkAudio.AkWaapiUriConv.Conv_FAkWaapiUriToString");

	struct {
		struct FAkWaapiUri& INAkWaapiUri;
		struct FString return_value;
	} parms;

	parms.INAkWaapiUri = INAkWaapiUri;

	ProcessEvent(p_Conv_FAkWaapiUriToString, &parms);
	return parms.return_value;
}

void UWidget::SetSearchText(struct FString newText){

	static UObject* p_SetSearchText = UObject::FindObject<UFunction>("Function AkAudio.AkWwiseTree.SetSearchText");

	struct {
		struct FString newText;
	} parms;

	parms.newText = newText;

	ProcessEvent(p_SetSearchText, &parms);
}

struct FAkWwiseObjectDetails UWidget::GetSelectedItem(){

	static UObject* p_GetSelectedItem = UObject::FindObject<UFunction>("Function AkAudio.AkWwiseTree.GetSelectedItem");

	struct {
		struct FAkWwiseObjectDetails return_value;
	} parms;


	ProcessEvent(p_GetSelectedItem, &parms);
	return parms.return_value;
}

struct FString UWidget::GetSearchText(){

	static UObject* p_GetSearchText = UObject::FindObject<UFunction>("Function AkAudio.AkWwiseTree.GetSearchText");

	struct {
		struct FString return_value;
	} parms;


	ProcessEvent(p_GetSearchText, &parms);
	return parms.return_value;
}

void UObject::MigrateMultiCoreRendering(bool NewValue){

	static UObject* p_MigrateMultiCoreRendering = UObject::FindObject<UFunction>("Function AkAudio.AkWindowsInitializationSettings.MigrateMultiCoreRendering");

	struct {
		bool NewValue;
	} parms;

	parms.NewValue = NewValue;

	ProcessEvent(p_MigrateMultiCoreRendering, &parms);
}

void UObject::MigrateMultiCoreRendering(bool NewValue){

	static UObject* p_MigrateMultiCoreRendering = UObject::FindObject<UFunction>("Function AkAudio.AkWinGDKInitializationSettings.MigrateMultiCoreRendering");

	struct {
		bool NewValue;
	} parms;

	parms.NewValue = NewValue;

	ProcessEvent(p_MigrateMultiCoreRendering, &parms);
}

void UObject::MigrateMultiCoreRendering(bool NewValue){

	static UObject* p_MigrateMultiCoreRendering = UObject::FindObject<UFunction>("Function AkAudio.AkXboxOneGDKInitializationSettings.MigrateMultiCoreRendering");

	struct {
		bool NewValue;
	} parms;

	parms.NewValue = NewValue;

	ProcessEvent(p_MigrateMultiCoreRendering, &parms);
}

void UObject::MigrateMultiCoreRendering(bool NewValue){

	static UObject* p_MigrateMultiCoreRendering = UObject::FindObject<UFunction>("Function AkAudio.AkXboxOneInitializationSettings.MigrateMultiCoreRendering");

	struct {
		bool NewValue;
	} parms;

	parms.NewValue = NewValue;

	ProcessEvent(p_MigrateMultiCoreRendering, &parms);
}

void UObject::MigrateMultiCoreRendering(bool NewValue){

	static UObject* p_MigrateMultiCoreRendering = UObject::FindObject<UFunction>("Function AkAudio.AkXSXInitializationSettings.MigrateMultiCoreRendering");

	struct {
		bool NewValue;
	} parms;

	parms.NewValue = NewValue;

	ProcessEvent(p_MigrateMultiCoreRendering, &parms);
}

struct UPostEventAsync* UBlueprintAsyncActionBase::PostEventAsync(struct UObject* WorldContextObject, struct UAkAudioEvent* AkEvent, struct AActor* Actor, int32_t CallbackMask, struct FDelegate& PostEventCallback, struct TArray<struct FAkExternalSourceInfo>& ExternalSources, bool bStopWhenAttachedToDestroyed){

	static UObject* p_PostEventAsync = UObject::FindObject<UFunction>("Function AkAudio.PostEventAsync.PostEventAsync");

	struct {
		struct UObject* WorldContextObject;
		struct UAkAudioEvent* AkEvent;
		struct AActor* Actor;
		int32_t CallbackMask;
		struct FDelegate& PostEventCallback;
		struct TArray<struct FAkExternalSourceInfo>& ExternalSources;
		bool bStopWhenAttachedToDestroyed;
		struct UPostEventAsync* return_value;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.AkEvent = AkEvent;
	parms.Actor = Actor;
	parms.CallbackMask = CallbackMask;
	parms.PostEventCallback = PostEventCallback;
	parms.ExternalSources = ExternalSources;
	parms.bStopWhenAttachedToDestroyed = bStopWhenAttachedToDestroyed;

	ProcessEvent(p_PostEventAsync, &parms);
	return parms.return_value;
}

void UBlueprintAsyncActionBase::PollPostEventFuture(){

	static UObject* p_PollPostEventFuture = UObject::FindObject<UFunction>("Function AkAudio.PostEventAsync.PollPostEventFuture");

	struct {
	} parms;


	ProcessEvent(p_PollPostEventFuture, &parms);
}

struct UPostEventAtLocationAsync* UBlueprintAsyncActionBase::PostEventAtLocationAsync(struct UObject* WorldContextObject, struct UAkAudioEvent* AkEvent, struct FVector Location, struct FRotator Orientation){

	static UObject* p_PostEventAtLocationAsync = UObject::FindObject<UFunction>("Function AkAudio.PostEventAtLocationAsync.PostEventAtLocationAsync");

	struct {
		struct UObject* WorldContextObject;
		struct UAkAudioEvent* AkEvent;
		struct FVector Location;
		struct FRotator Orientation;
		struct UPostEventAtLocationAsync* return_value;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.AkEvent = AkEvent;
	parms.Location = Location;
	parms.Orientation = Orientation;

	ProcessEvent(p_PostEventAtLocationAsync, &parms);
	return parms.return_value;
}

void UBlueprintAsyncActionBase::PollPostEventFuture(){

	static UObject* p_PollPostEventFuture = UObject::FindObject<UFunction>("Function AkAudio.PostEventAtLocationAsync.PollPostEventFuture");

	struct {
	} parms;


	ProcessEvent(p_PollPostEventFuture, &parms);
}

