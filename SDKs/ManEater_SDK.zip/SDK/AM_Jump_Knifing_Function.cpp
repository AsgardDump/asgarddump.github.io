#include "SDK.h" 
 
 
void UME_GameplayAbility_SharkEvade::K2_CommitExecute(){

	static UObject* p_K2_CommitExecute = UObject::FindObject<UFunction>("Function AM_Jump_Knifing.AM_Jump_Knifing_C.K2_CommitExecute");

	struct {
	} parms;


	ProcessEvent(p_K2_CommitExecute, &parms);
}

void UME_GameplayAbility_SharkEvade::ExecuteUbergraph_AM_Jump_Knifing(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph_AM_Jump_Knifing = UObject::FindObject<UFunction>("Function AM_Jump_Knifing.AM_Jump_Knifing_C.ExecuteUbergraph_AM_Jump_Knifing");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph_AM_Jump_Knifing, &parms);
}

