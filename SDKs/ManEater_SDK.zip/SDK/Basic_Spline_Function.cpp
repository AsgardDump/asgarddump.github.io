#include "SDK.h" 
 
 
void AActor::TurnSpawnedLightsOff(){

	static UObject* p_TurnSpawnedLightsOff = UObject::FindObject<UFunction>("Function Basic_Spline.Basic_Spline_C.TurnSpawnedLightsOff");

	struct {
	} parms;


	ProcessEvent(p_TurnSpawnedLightsOff, &parms);
}

void AActor::TurnSpawnedLightsOn(){

	static UObject* p_TurnSpawnedLightsOn = UObject::FindObject<UFunction>("Function Basic_Spline.Basic_Spline_C.TurnSpawnedLightsOn");

	struct {
	} parms;


	ProcessEvent(p_TurnSpawnedLightsOn, &parms);
}

void AActor::ManualDestroyLights(){

	static UObject* p_ManualDestroyLights = UObject::FindObject<UFunction>("Function Basic_Spline.Basic_Spline_C.ManualDestroyLights");

	struct {
	} parms;


	ProcessEvent(p_ManualDestroyLights, &parms);
}

void AActor::GenerateLights(){

	static UObject* p_GenerateLights = UObject::FindObject<UFunction>("Function Basic_Spline.Basic_Spline_C.GenerateLights");

	struct {
	} parms;


	ProcessEvent(p_GenerateLights, &parms);
}

void AActor::SpawnLightAtLocation(ALight* LightInformation, struct FTransform Transform, struct AActor* StaticMesh, struct FName CustomTag, struct FName SocketName){

	static UObject* p_SpawnLightAtLocation = UObject::FindObject<UFunction>("Function Basic_Spline.Basic_Spline_C.SpawnLightAtLocation");

	struct {
		ALight* LightInformation;
		struct FTransform Transform;
		struct AActor* StaticMesh;
		struct FName CustomTag;
		struct FName SocketName;
	} parms;

	parms.LightInformation = LightInformation;
	parms.Transform = Transform;
	parms.StaticMesh = StaticMesh;
	parms.CustomTag = CustomTag;
	parms.SocketName = SocketName;

	ProcessEvent(p_SpawnLightAtLocation, &parms);
}

void AActor::DestroyLights(){

	static UObject* p_DestroyLights = UObject::FindObject<UFunction>("Function Basic_Spline.Basic_Spline_C.DestroyLights");

	struct {
	} parms;


	ProcessEvent(p_DestroyLights, &parms);
}

void AActor::UpdateMesh(int32_t MeshIndex, struct USplineMeshComponent* CurrentMesh){

	static UObject* p_UpdateMesh = UObject::FindObject<UFunction>("Function Basic_Spline.Basic_Spline_C.UpdateMesh");

	struct {
		int32_t MeshIndex;
		struct USplineMeshComponent* CurrentMesh;
	} parms;

	parms.MeshIndex = MeshIndex;
	parms.CurrentMesh = CurrentMesh;

	ProcessEvent(p_UpdateMesh, &parms);
}

void AActor::UserConstructionScript(){

	static UObject* p_UserConstructionScript = UObject::FindObject<UFunction>("Function Basic_Spline.Basic_Spline_C.UserConstructionScript");

	struct {
	} parms;


	ProcessEvent(p_UserConstructionScript, &parms);
}

void AActor::CustomEvent_1(){

	static UObject* p_CustomEvent_1 = UObject::FindObject<UFunction>("Function Basic_Spline.Basic_Spline_C.CustomEvent_1");

	struct {
	} parms;


	ProcessEvent(p_CustomEvent_1, &parms);
}

void AActor::ExecuteUbergraph_Basic_Spline(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph_Basic_Spline = UObject::FindObject<UFunction>("Function Basic_Spline.Basic_Spline_C.ExecuteUbergraph_Basic_Spline");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph_Basic_Spline, &parms);
}

