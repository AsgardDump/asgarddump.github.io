#pragma once 
#include <AM_EvadeRight_Knifing_Structs.h>
 
 
 
// BlueprintGeneratedClass AM_EvadeRight_Knifing.AM_EvadeRight_Knifing_C
// Size: 0x620(Inherited: 0x620) 
struct UAM_EvadeRight_Knifing_C : public UME_GameplayAbility_SharkEvade
{

}; 



