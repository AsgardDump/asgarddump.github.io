#pragma once 
#include <AttributeItem_BP_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass AttributeItem_BP.AttributeItem_BP_C
// Size: 0x250(Inherited: 0x230) 
struct UAttributeItem_BP_C : public UUserWidget
{
	struct UProgressBar* AttributeCurrent;  // 0x230(0x8)
	struct UProgressBar* AttributeDelta;  // 0x238(0x8)
	struct UTextBlock* AttributeName;  // 0x240(0x8)
	struct UProgressBar* BackgroundBar;  // 0x248(0x8)

	void SetPercent(float CurrentPercent, float DeltaPercent); // Function AttributeItem_BP.AttributeItem_BP_C.SetPercent
	void SetAttributeName(struct FText AttributeName); // Function AttributeItem_BP.AttributeItem_BP_C.SetAttributeName
}; 



