#pragma once 
#include <AM_Lunge_Land_Structs.h>
 
 
 
// BlueprintGeneratedClass AM_Lunge_Land.AM_Lunge_Land_C
// Size: 0x638(Inherited: 0x638) 
struct UAM_Lunge_Land_C : public UME_GameplayAbility_LandLunge
{

}; 



