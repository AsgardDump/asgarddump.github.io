#pragma once 
#include <AM_BiteRelease_Structs.h>
 
 
 
// BlueprintGeneratedClass AM_BiteRelease.AM_BiteRelease_C
// Size: 0x620(Inherited: 0x620) 
struct UAM_BiteRelease_C : public UME_GameplayAbilitySharkMontage
{

}; 



