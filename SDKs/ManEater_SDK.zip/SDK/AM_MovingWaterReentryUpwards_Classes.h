#pragma once 
#include <AM_MovingWaterReentryUpwards_Structs.h>
 
 
 
// BlueprintGeneratedClass AM_MovingWaterReentryUpwards.AM_MovingWaterReentryUpwards_C
// Size: 0x620(Inherited: 0x620) 
struct UAM_MovingWaterReentryUpwards_C : public UME_GameplayAbilitySharkMontage
{

}; 



