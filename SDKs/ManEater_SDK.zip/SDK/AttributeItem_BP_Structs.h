#pragma once 
#include "SDK.h" 
 
 
// Function AttributeItem_BP.AttributeItem_BP_C.SetAttributeName
// Size: 0x18(Inherited: 0x0) 
struct FSetAttributeName
{
	struct FText AttributeName;  // 0x0(0x18)

}; 
// Function AttributeItem_BP.AttributeItem_BP_C.SetPercent
// Size: 0x70(Inherited: 0x0) 
struct FSetPercent
{
	float CurrentPercent;  // 0x0(0x4)
	float DeltaPercent;  // 0x4(0x4)
	struct FLinearColor Green;  // 0x8(0x10)
	struct FLinearColor Red;  // 0x18(0x10)
	struct FLinearColor Neutral;  // 0x28(0x10)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool CallFunc_Less_FloatFloat_ReturnValue : 1;  // 0x38(0x1)
	char pad_57_1 : 7;  // 0x39(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue : 1;  // 0x39(0x1)
	char pad_58[6];  // 0x3A(0x6)
	struct UCanvasPanelSlot* CallFunc_SlotAsCanvasSlot_ReturnValue;  // 0x40(0x8)
	struct UCanvasPanelSlot* CallFunc_SlotAsCanvasSlot_ReturnValue_2;  // 0x48(0x8)
	struct UCanvasPanelSlot* CallFunc_SlotAsCanvasSlot_ReturnValue_3;  // 0x50(0x8)
	struct UCanvasPanelSlot* CallFunc_SlotAsCanvasSlot_ReturnValue_4;  // 0x58(0x8)
	struct UCanvasPanelSlot* CallFunc_SlotAsCanvasSlot_ReturnValue_5;  // 0x60(0x8)
	struct UCanvasPanelSlot* CallFunc_SlotAsCanvasSlot_ReturnValue_6;  // 0x68(0x8)

}; 
