#include "SDK.h" 
 
 
void AAIController_GreatWhite_BP_C::ReceiveBeginPlay(){

	static UObject* p_ReceiveBeginPlay = UObject::FindObject<UFunction>("Function AIController_Irradiated_Electric_GreatWhite_BP.AIController_Irradiated_Electric_GreatWhite_BP_C.ReceiveBeginPlay");

	struct {
	} parms;


	ProcessEvent(p_ReceiveBeginPlay, &parms);
}

void AAIController_GreatWhite_BP_C::CustomEvent(char EAIThreatAlertState NewAlertState, struct AActor* InstigatingActor){

	static UObject* p_CustomEvent = UObject::FindObject<UFunction>("Function AIController_Irradiated_Electric_GreatWhite_BP.AIController_Irradiated_Electric_GreatWhite_BP_C.CustomEvent");

	struct {
		char EAIThreatAlertState NewAlertState;
		struct AActor* InstigatingActor;
	} parms;

	parms.NewAlertState = NewAlertState;
	parms.InstigatingActor = InstigatingActor;

	ProcessEvent(p_CustomEvent, &parms);
}

void AAIController_GreatWhite_BP_C::ExecuteUbergraph_AIController_Irradiated_Electric_GreatWhite_BP(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph_AIController_Irradiated_Electric_GreatWhite_BP = UObject::FindObject<UFunction>("Function AIController_Irradiated_Electric_GreatWhite_BP.AIController_Irradiated_Electric_GreatWhite_BP_C.ExecuteUbergraph_AIController_Irradiated_Electric_GreatWhite_BP");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph_AIController_Irradiated_Electric_GreatWhite_BP, &parms);
}

