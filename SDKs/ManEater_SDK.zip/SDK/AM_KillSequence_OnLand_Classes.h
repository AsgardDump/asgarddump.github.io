#pragma once 
#include <AM_KillSequence_OnLand_Structs.h>
 
 
 
// BlueprintGeneratedClass AM_KillSequence_OnLand.AM_KillSequence_OnLand_C
// Size: 0x640(Inherited: 0x640) 
struct UAM_KillSequence_OnLand_C : public UAM_KillSequence_C
{

}; 



