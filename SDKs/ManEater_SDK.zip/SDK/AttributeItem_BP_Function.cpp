#include "SDK.h" 
 
 
void UUserWidget::SetPercent(float CurrentPercent, float DeltaPercent){

	static UObject* p_SetPercent = UObject::FindObject<UFunction>("Function AttributeItem_BP.AttributeItem_BP_C.SetPercent");

	struct {
		float CurrentPercent;
		float DeltaPercent;
	} parms;

	parms.CurrentPercent = CurrentPercent;
	parms.DeltaPercent = DeltaPercent;

	ProcessEvent(p_SetPercent, &parms);
}

void UUserWidget::SetAttributeName(struct FText AttributeName){

	static UObject* p_SetAttributeName = UObject::FindObject<UFunction>("Function AttributeItem_BP.AttributeItem_BP_C.SetAttributeName");

	struct {
		struct FText AttributeName;
	} parms;

	parms.AttributeName = AttributeName;

	ProcessEvent(p_SetAttributeName, &parms);
}

