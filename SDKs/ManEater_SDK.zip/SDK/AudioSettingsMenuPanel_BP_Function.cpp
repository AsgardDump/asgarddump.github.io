#include "SDK.h" 
 
 
void UTwBaseMenuPanel::NarratorVolumeChanged(int32_t Index){

	static UObject* p_NarratorVolumeChanged = UObject::FindObject<UFunction>("Function AudioSettingsMenuPanel_BP.AudioSettingsMenuPanel_BP_C.NarratorVolumeChanged");

	struct {
		int32_t Index;
	} parms;

	parms.Index = Index;

	ProcessEvent(p_NarratorVolumeChanged, &parms);
}

void UTwBaseMenuPanel::DialogVolumeChanged(int32_t Index){

	static UObject* p_DialogVolumeChanged = UObject::FindObject<UFunction>("Function AudioSettingsMenuPanel_BP.AudioSettingsMenuPanel_BP_C.DialogVolumeChanged");

	struct {
		int32_t Index;
	} parms;

	parms.Index = Index;

	ProcessEvent(p_DialogVolumeChanged, &parms);
}

void UTwBaseMenuPanel::SFXVolumeChanged(int32_t Index){

	static UObject* p_SFXVolumeChanged = UObject::FindObject<UFunction>("Function AudioSettingsMenuPanel_BP.AudioSettingsMenuPanel_BP_C.SFXVolumeChanged");

	struct {
		int32_t Index;
	} parms;

	parms.Index = Index;

	ProcessEvent(p_SFXVolumeChanged, &parms);
}

void UTwBaseMenuPanel::MusicVolumeChanged(int32_t Index){

	static UObject* p_MusicVolumeChanged = UObject::FindObject<UFunction>("Function AudioSettingsMenuPanel_BP.AudioSettingsMenuPanel_BP_C.MusicVolumeChanged");

	struct {
		int32_t Index;
	} parms;

	parms.Index = Index;

	ProcessEvent(p_MusicVolumeChanged, &parms);
}

void UTwBaseMenuPanel::MasterVolumeChanged(int32_t Index){

	static UObject* p_MasterVolumeChanged = UObject::FindObject<UFunction>("Function AudioSettingsMenuPanel_BP.AudioSettingsMenuPanel_BP_C.MasterVolumeChanged");

	struct {
		int32_t Index;
	} parms;

	parms.Index = Index;

	ProcessEvent(p_MasterVolumeChanged, &parms);
}

struct UWidget* UTwBaseMenuPanel::GetDefaultFocusWidget(){

	static UObject* p_GetDefaultFocusWidget = UObject::FindObject<UFunction>("Function AudioSettingsMenuPanel_BP.AudioSettingsMenuPanel_BP_C.GetDefaultFocusWidget");

	struct {
		struct UWidget* return_value;
	} parms;


	ProcessEvent(p_GetDefaultFocusWidget, &parms);
	return parms.return_value;
}

void UTwBaseMenuPanel::Construct(){

	static UObject* p_Construct = UObject::FindObject<UFunction>("Function AudioSettingsMenuPanel_BP.AudioSettingsMenuPanel_BP_C.Construct");

	struct {
	} parms;


	ProcessEvent(p_Construct, &parms);
}

void UTwBaseMenuPanel::ExecuteUbergraph_AudioSettingsMenuPanel_BP(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph_AudioSettingsMenuPanel_BP = UObject::FindObject<UFunction>("Function AudioSettingsMenuPanel_BP.AudioSettingsMenuPanel_BP_C.ExecuteUbergraph_AudioSettingsMenuPanel_BP");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph_AudioSettingsMenuPanel_BP, &parms);
}

