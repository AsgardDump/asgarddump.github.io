#pragma once 
#include <ALL_Aligator_ABP_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass ALL_Aligator_ABP.ALL_Aligator_ABP_C
// Size: 0x5C8C(Inherited: 0x5C8C) 
struct UALL_Aligator_ABP_C : public UWildlife_Base_ABP_C
{

}; 



