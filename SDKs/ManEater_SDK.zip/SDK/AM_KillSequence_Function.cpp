#include "SDK.h" 
 
 
void UME_GameplayAbility_KillSequence::MontageEnded(struct UAnimMontage* Montage, bool bInterrupted){

	static UObject* p_MontageEnded = UObject::FindObject<UFunction>("Function AM_KillSequence.AM_KillSequence_C.MontageEnded");

	struct {
		struct UAnimMontage* Montage;
		bool bInterrupted;
	} parms;

	parms.Montage = Montage;
	parms.bInterrupted = bInterrupted;

	ProcessEvent(p_MontageEnded, &parms);
}

void UME_GameplayAbility_KillSequence::ExecuteUbergraph_AM_KillSequence(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph_AM_KillSequence = UObject::FindObject<UFunction>("Function AM_KillSequence.AM_KillSequence_C.ExecuteUbergraph_AM_KillSequence");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph_AM_KillSequence, &parms);
}

