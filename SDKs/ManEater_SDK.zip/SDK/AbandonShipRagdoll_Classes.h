#pragma once 
#include <AbandonShipRagdoll_Structs.h>
 
 
 
// BlueprintGeneratedClass AbandonShipRagdoll.AbandonShipRagdoll_C
// Size: 0x38(Inherited: 0x38) 
struct UAbandonShipRagdoll_C : public UAnimNotify
{

	bool Received_Notify(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation); // Function AbandonShipRagdoll.AbandonShipRagdoll_C.Received_Notify
}; 



