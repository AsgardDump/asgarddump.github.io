#pragma once 
#include <AM_TailWhip_FullMouth_Knifing_Structs.h>
 
 
 
// BlueprintGeneratedClass AM_TailWhip_FullMouth_Knifing.AM_TailWhip_FullMouth_Knifing_C
// Size: 0x620(Inherited: 0x620) 
struct UAM_TailWhip_FullMouth_Knifing_C : public UAM_TailWhip_FullMouth_C
{

}; 



