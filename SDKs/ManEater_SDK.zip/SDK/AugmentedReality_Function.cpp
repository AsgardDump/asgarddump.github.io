#include "SDK.h" 
 
 
struct FVector UARTrackedGeometry::GetExtent(){

	static UObject* p_GetExtent = UObject::FindObject<UFunction>("Function AugmentedReality.AREnvironmentCaptureProbe.GetExtent");

	struct {
		struct FVector return_value;
	} parms;


	ProcessEvent(p_GetExtent, &parms);
	return parms.return_value;
}

struct UAREnvironmentCaptureProbeTexture* UARTrackedGeometry::GetEnvironmentCaptureTexture(){

	static UObject* p_GetEnvironmentCaptureTexture = UObject::FindObject<UFunction>("Function AugmentedReality.AREnvironmentCaptureProbe.GetEnvironmentCaptureTexture");

	struct {
		struct UAREnvironmentCaptureProbeTexture* return_value;
	} parms;


	ProcessEvent(p_GetEnvironmentCaptureTexture, &parms);
	return parms.return_value;
}

bool UDataAsset::ShouldResetTrackedObjects(){

	static UObject* p_ShouldResetTrackedObjects = UObject::FindObject<UFunction>("Function AugmentedReality.ARSessionConfig.ShouldResetTrackedObjects");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_ShouldResetTrackedObjects, &parms);
	return parms.return_value;
}

bool UDataAsset::ShouldResetCameraTracking(){

	static UObject* p_ShouldResetCameraTracking = UObject::FindObject<UFunction>("Function AugmentedReality.ARSessionConfig.ShouldResetCameraTracking");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_ShouldResetCameraTracking, &parms);
	return parms.return_value;
}

bool UDataAsset::ShouldRenderCameraOverlay(){

	static UObject* p_ShouldRenderCameraOverlay = UObject::FindObject<UFunction>("Function AugmentedReality.ARSessionConfig.ShouldRenderCameraOverlay");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_ShouldRenderCameraOverlay, &parms);
	return parms.return_value;
}

bool UDataAsset::ShouldEnableCameraTracking(){

	static UObject* p_ShouldEnableCameraTracking = UObject::FindObject<UFunction>("Function AugmentedReality.ARSessionConfig.ShouldEnableCameraTracking");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_ShouldEnableCameraTracking, &parms);
	return parms.return_value;
}

bool UDataAsset::ShouldEnableAutoFocus(){

	static UObject* p_ShouldEnableAutoFocus = UObject::FindObject<UFunction>("Function AugmentedReality.ARSessionConfig.ShouldEnableAutoFocus");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_ShouldEnableAutoFocus, &parms);
	return parms.return_value;
}

void UDataAsset::SetWorldMapData(struct TArray<char> WorldMapData){

	static UObject* p_SetWorldMapData = UObject::FindObject<UFunction>("Function AugmentedReality.ARSessionConfig.SetWorldMapData");

	struct {
		struct TArray<char> WorldMapData;
	} parms;

	parms.WorldMapData = WorldMapData;

	ProcessEvent(p_SetWorldMapData, &parms);
}

void UDataAsset::SetSessionTrackingFeatureToEnable(uint8_t  InSessionTrackingFeature){

	static UObject* p_SetSessionTrackingFeatureToEnable = UObject::FindObject<UFunction>("Function AugmentedReality.ARSessionConfig.SetSessionTrackingFeatureToEnable");

	struct {
		uint8_t  InSessionTrackingFeature;
	} parms;

	parms.InSessionTrackingFeature = InSessionTrackingFeature;

	ProcessEvent(p_SetSessionTrackingFeatureToEnable, &parms);
}

void UDataAsset::SetResetTrackedObjects(bool bNewValue){

	static UObject* p_SetResetTrackedObjects = UObject::FindObject<UFunction>("Function AugmentedReality.ARSessionConfig.SetResetTrackedObjects");

	struct {
		bool bNewValue;
	} parms;

	parms.bNewValue = bNewValue;

	ProcessEvent(p_SetResetTrackedObjects, &parms);
}

void UDataAsset::SetResetCameraTracking(bool bNewValue){

	static UObject* p_SetResetCameraTracking = UObject::FindObject<UFunction>("Function AugmentedReality.ARSessionConfig.SetResetCameraTracking");

	struct {
		bool bNewValue;
	} parms;

	parms.bNewValue = bNewValue;

	ProcessEvent(p_SetResetCameraTracking, &parms);
}

void UDataAsset::SetFaceTrackingUpdate(uint8_t  InUpdate){

	static UObject* p_SetFaceTrackingUpdate = UObject::FindObject<UFunction>("Function AugmentedReality.ARSessionConfig.SetFaceTrackingUpdate");

	struct {
		uint8_t  InUpdate;
	} parms;

	parms.InUpdate = InUpdate;

	ProcessEvent(p_SetFaceTrackingUpdate, &parms);
}

void UDataAsset::SetFaceTrackingDirection(uint8_t  InDirection){

	static UObject* p_SetFaceTrackingDirection = UObject::FindObject<UFunction>("Function AugmentedReality.ARSessionConfig.SetFaceTrackingDirection");

	struct {
		uint8_t  InDirection;
	} parms;

	parms.InDirection = InDirection;

	ProcessEvent(p_SetFaceTrackingDirection, &parms);
}

void UDataAsset::SetEnableAutoFocus(bool bNewValue){

	static UObject* p_SetEnableAutoFocus = UObject::FindObject<UFunction>("Function AugmentedReality.ARSessionConfig.SetEnableAutoFocus");

	struct {
		bool bNewValue;
	} parms;

	parms.bNewValue = bNewValue;

	ProcessEvent(p_SetEnableAutoFocus, &parms);
}

void UDataAsset::SetDesiredVideoFormat(struct FARVideoFormat NewFormat){

	static UObject* p_SetDesiredVideoFormat = UObject::FindObject<UFunction>("Function AugmentedReality.ARSessionConfig.SetDesiredVideoFormat");

	struct {
		struct FARVideoFormat NewFormat;
	} parms;

	parms.NewFormat = NewFormat;

	ProcessEvent(p_SetDesiredVideoFormat, &parms);
}

void UDataAsset::SetCandidateObjectList(struct TArray<struct UARCandidateObject*>& InCandidateObjects){

	static UObject* p_SetCandidateObjectList = UObject::FindObject<UFunction>("Function AugmentedReality.ARSessionConfig.SetCandidateObjectList");

	struct {
		struct TArray<struct UARCandidateObject*>& InCandidateObjects;
	} parms;

	parms.InCandidateObjects = InCandidateObjects;

	ProcessEvent(p_SetCandidateObjectList, &parms);
}

struct TArray<char> UDataAsset::GetWorldMapData(){

	static UObject* p_GetWorldMapData = UObject::FindObject<UFunction>("Function AugmentedReality.ARSessionConfig.GetWorldMapData");

	struct {
		struct TArray<char> return_value;
	} parms;


	ProcessEvent(p_GetWorldMapData, &parms);
	return parms.return_value;
}

uint8_t  UDataAsset::GetWorldAlignment(){

	static UObject* p_GetWorldAlignment = UObject::FindObject<UFunction>("Function AugmentedReality.ARSessionConfig.GetWorldAlignment");

	struct {
		uint8_t  return_value;
	} parms;


	ProcessEvent(p_GetWorldAlignment, &parms);
	return parms.return_value;
}

uint8_t  UDataAsset::GetSessionType(){

	static UObject* p_GetSessionType = UObject::FindObject<UFunction>("Function AugmentedReality.ARSessionConfig.GetSessionType");

	struct {
		uint8_t  return_value;
	} parms;


	ProcessEvent(p_GetSessionType, &parms);
	return parms.return_value;
}

uint8_t  UDataAsset::GetPlaneDetectionMode(){

	static UObject* p_GetPlaneDetectionMode = UObject::FindObject<UFunction>("Function AugmentedReality.ARSessionConfig.GetPlaneDetectionMode");

	struct {
		uint8_t  return_value;
	} parms;


	ProcessEvent(p_GetPlaneDetectionMode, &parms);
	return parms.return_value;
}

int32_t UDataAsset::GetMaxNumSimultaneousImagesTracked(){

	static UObject* p_GetMaxNumSimultaneousImagesTracked = UObject::FindObject<UFunction>("Function AugmentedReality.ARSessionConfig.GetMaxNumSimultaneousImagesTracked");

	struct {
		int32_t return_value;
	} parms;


	ProcessEvent(p_GetMaxNumSimultaneousImagesTracked, &parms);
	return parms.return_value;
}

uint8_t  UDataAsset::GetLightEstimationMode(){

	static UObject* p_GetLightEstimationMode = UObject::FindObject<UFunction>("Function AugmentedReality.ARSessionConfig.GetLightEstimationMode");

	struct {
		uint8_t  return_value;
	} parms;


	ProcessEvent(p_GetLightEstimationMode, &parms);
	return parms.return_value;
}

uint8_t  UDataAsset::GetFrameSyncMode(){

	static UObject* p_GetFrameSyncMode = UObject::FindObject<UFunction>("Function AugmentedReality.ARSessionConfig.GetFrameSyncMode");

	struct {
		uint8_t  return_value;
	} parms;


	ProcessEvent(p_GetFrameSyncMode, &parms);
	return parms.return_value;
}

uint8_t  UDataAsset::GetFaceTrackingUpdate(){

	static UObject* p_GetFaceTrackingUpdate = UObject::FindObject<UFunction>("Function AugmentedReality.ARSessionConfig.GetFaceTrackingUpdate");

	struct {
		uint8_t  return_value;
	} parms;


	ProcessEvent(p_GetFaceTrackingUpdate, &parms);
	return parms.return_value;
}

uint8_t  UDataAsset::GetFaceTrackingDirection(){

	static UObject* p_GetFaceTrackingDirection = UObject::FindObject<UFunction>("Function AugmentedReality.ARSessionConfig.GetFaceTrackingDirection");

	struct {
		uint8_t  return_value;
	} parms;


	ProcessEvent(p_GetFaceTrackingDirection, &parms);
	return parms.return_value;
}

uint8_t  UDataAsset::GetEnvironmentCaptureProbeType(){

	static UObject* p_GetEnvironmentCaptureProbeType = UObject::FindObject<UFunction>("Function AugmentedReality.ARSessionConfig.GetEnvironmentCaptureProbeType");

	struct {
		uint8_t  return_value;
	} parms;


	ProcessEvent(p_GetEnvironmentCaptureProbeType, &parms);
	return parms.return_value;
}

uint8_t  UDataAsset::GetEnabledSessionTrackingFeature(){

	static UObject* p_GetEnabledSessionTrackingFeature = UObject::FindObject<UFunction>("Function AugmentedReality.ARSessionConfig.GetEnabledSessionTrackingFeature");

	struct {
		uint8_t  return_value;
	} parms;


	ProcessEvent(p_GetEnabledSessionTrackingFeature, &parms);
	return parms.return_value;
}

struct FARVideoFormat UDataAsset::GetDesiredVideoFormat(){

	static UObject* p_GetDesiredVideoFormat = UObject::FindObject<UFunction>("Function AugmentedReality.ARSessionConfig.GetDesiredVideoFormat");

	struct {
		struct FARVideoFormat return_value;
	} parms;


	ProcessEvent(p_GetDesiredVideoFormat, &parms);
	return parms.return_value;
}

struct TArray<struct UARCandidateObject*> UDataAsset::GetCandidateObjectList(){

	static UObject* p_GetCandidateObjectList = UObject::FindObject<UFunction>("Function AugmentedReality.ARSessionConfig.GetCandidateObjectList");

	struct {
		struct TArray<struct UARCandidateObject*> return_value;
	} parms;


	ProcessEvent(p_GetCandidateObjectList, &parms);
	return parms.return_value;
}

struct TArray<struct UARCandidateImage*> UDataAsset::GetCandidateImageList(){

	static UObject* p_GetCandidateImageList = UObject::FindObject<UFunction>("Function AugmentedReality.ARSessionConfig.GetCandidateImageList");

	struct {
		struct TArray<struct UARCandidateImage*> return_value;
	} parms;


	ProcessEvent(p_GetCandidateImageList, &parms);
	return parms.return_value;
}

void UDataAsset::AddCandidateObject(struct UARCandidateObject* CandidateObject){

	static UObject* p_AddCandidateObject = UObject::FindObject<UFunction>("Function AugmentedReality.ARSessionConfig.AddCandidateObject");

	struct {
		struct UARCandidateObject* CandidateObject;
	} parms;

	parms.CandidateObject = CandidateObject;

	ProcessEvent(p_AddCandidateObject, &parms);
}

void UDataAsset::AddCandidateImage(struct UARCandidateImage* NewCandidateImage){

	static UObject* p_AddCandidateImage = UObject::FindObject<UFunction>("Function AugmentedReality.ARSessionConfig.AddCandidateImage");

	struct {
		struct UARCandidateImage* NewCandidateImage;
	} parms;

	parms.NewCandidateImage = NewCandidateImage;

	ProcessEvent(p_AddCandidateImage, &parms);
}

struct UARTrackedGeometry* UBlueprintFunctionLibrary::GetTrackedGeometry(struct FARTraceResult& TraceResult){

	static UObject* p_GetTrackedGeometry = UObject::FindObject<UFunction>("Function AugmentedReality.ARTraceResultLibrary.GetTrackedGeometry");

	struct {
		struct FARTraceResult& TraceResult;
		struct UARTrackedGeometry* return_value;
	} parms;

	parms.TraceResult = TraceResult;

	ProcessEvent(p_GetTrackedGeometry, &parms);
	return parms.return_value;
}

uint8_t  UBlueprintFunctionLibrary::GetTraceChannel(struct FARTraceResult& TraceResult){

	static UObject* p_GetTraceChannel = UObject::FindObject<UFunction>("Function AugmentedReality.ARTraceResultLibrary.GetTraceChannel");

	struct {
		struct FARTraceResult& TraceResult;
		uint8_t  return_value;
	} parms;

	parms.TraceResult = TraceResult;

	ProcessEvent(p_GetTraceChannel, &parms);
	return parms.return_value;
}

struct FTransform UBlueprintFunctionLibrary::GetLocalToWorldTransform(struct FARTraceResult& TraceResult){

	static UObject* p_GetLocalToWorldTransform = UObject::FindObject<UFunction>("Function AugmentedReality.ARTraceResultLibrary.GetLocalToWorldTransform");

	struct {
		struct FARTraceResult& TraceResult;
		struct FTransform return_value;
	} parms;

	parms.TraceResult = TraceResult;

	ProcessEvent(p_GetLocalToWorldTransform, &parms);
	return parms.return_value;
}

struct FTransform UBlueprintFunctionLibrary::GetLocalToTrackingTransform(struct FARTraceResult& TraceResult){

	static UObject* p_GetLocalToTrackingTransform = UObject::FindObject<UFunction>("Function AugmentedReality.ARTraceResultLibrary.GetLocalToTrackingTransform");

	struct {
		struct FARTraceResult& TraceResult;
		struct FTransform return_value;
	} parms;

	parms.TraceResult = TraceResult;

	ProcessEvent(p_GetLocalToTrackingTransform, &parms);
	return parms.return_value;
}

float UBlueprintFunctionLibrary::GetDistanceFromCamera(struct FARTraceResult& TraceResult){

	static UObject* p_GetDistanceFromCamera = UObject::FindObject<UFunction>("Function AugmentedReality.ARTraceResultLibrary.GetDistanceFromCamera");

	struct {
		struct FARTraceResult& TraceResult;
		float return_value;
	} parms;

	parms.TraceResult = TraceResult;

	ProcessEvent(p_GetDistanceFromCamera, &parms);
	return parms.return_value;
}

float UARLightEstimate::GetAmbientIntensityLumens(){

	static UObject* p_GetAmbientIntensityLumens = UObject::FindObject<UFunction>("Function AugmentedReality.ARBasicLightEstimate.GetAmbientIntensityLumens");

	struct {
		float return_value;
	} parms;


	ProcessEvent(p_GetAmbientIntensityLumens, &parms);
	return parms.return_value;
}

float UARLightEstimate::GetAmbientColorTemperatureKelvin(){

	static UObject* p_GetAmbientColorTemperatureKelvin = UObject::FindObject<UFunction>("Function AugmentedReality.ARBasicLightEstimate.GetAmbientColorTemperatureKelvin");

	struct {
		float return_value;
	} parms;


	ProcessEvent(p_GetAmbientColorTemperatureKelvin, &parms);
	return parms.return_value;
}

struct FLinearColor UARLightEstimate::GetAmbientColor(){

	static UObject* p_GetAmbientColor = UObject::FindObject<UFunction>("Function AugmentedReality.ARBasicLightEstimate.GetAmbientColor");

	struct {
		struct FLinearColor return_value;
	} parms;


	ProcessEvent(p_GetAmbientColor, &parms);
	return parms.return_value;
}

struct UARSaveWorldAsyncTaskBlueprintProxy* UARBaseAsyncTaskBlueprintProxy::ARSaveWorld(struct UObject* WorldContextObject){

	static UObject* p_ARSaveWorld = UObject::FindObject<UFunction>("Function AugmentedReality.ARSaveWorldAsyncTaskBlueprintProxy.ARSaveWorld");

	struct {
		struct UObject* WorldContextObject;
		struct UARSaveWorldAsyncTaskBlueprintProxy* return_value;
	} parms;

	parms.WorldContextObject = WorldContextObject;

	ProcessEvent(p_ARSaveWorld, &parms);
	return parms.return_value;
}

void UBlueprintFunctionLibrary::UnpinComponent(struct USceneComponent* ComponentToUnpin){

	static UObject* p_UnpinComponent = UObject::FindObject<UFunction>("Function AugmentedReality.ARBlueprintLibrary.UnpinComponent");

	struct {
		struct USceneComponent* ComponentToUnpin;
	} parms;

	parms.ComponentToUnpin = ComponentToUnpin;

	ProcessEvent(p_UnpinComponent, &parms);
}

void UBlueprintFunctionLibrary::StopARSession(){

	static UObject* p_StopARSession = UObject::FindObject<UFunction>("Function AugmentedReality.ARBlueprintLibrary.StopARSession");

	struct {
	} parms;


	ProcessEvent(p_StopARSession, &parms);
}

void UBlueprintFunctionLibrary::StartARSession(struct UARSessionConfig* SessionConfig){

	static UObject* p_StartARSession = UObject::FindObject<UFunction>("Function AugmentedReality.ARBlueprintLibrary.StartARSession");

	struct {
		struct UARSessionConfig* SessionConfig;
	} parms;

	parms.SessionConfig = SessionConfig;

	ProcessEvent(p_StartARSession, &parms);
}

void UBlueprintFunctionLibrary::SetAlignmentTransform(struct FTransform& InAlignmentTransform){

	static UObject* p_SetAlignmentTransform = UObject::FindObject<UFunction>("Function AugmentedReality.ARBlueprintLibrary.SetAlignmentTransform");

	struct {
		struct FTransform& InAlignmentTransform;
	} parms;

	parms.InAlignmentTransform = InAlignmentTransform;

	ProcessEvent(p_SetAlignmentTransform, &parms);
}

void UBlueprintFunctionLibrary::RemovePin(struct UARPin* PinToRemove){

	static UObject* p_RemovePin = UObject::FindObject<UFunction>("Function AugmentedReality.ARBlueprintLibrary.RemovePin");

	struct {
		struct UARPin* PinToRemove;
	} parms;

	parms.PinToRemove = PinToRemove;

	ProcessEvent(p_RemovePin, &parms);
}

struct UARPin* UBlueprintFunctionLibrary::PinComponentToTraceResult(struct USceneComponent* ComponentToPin, struct FARTraceResult& TraceResult, struct FName DebugName){

	static UObject* p_PinComponentToTraceResult = UObject::FindObject<UFunction>("Function AugmentedReality.ARBlueprintLibrary.PinComponentToTraceResult");

	struct {
		struct USceneComponent* ComponentToPin;
		struct FARTraceResult& TraceResult;
		struct FName DebugName;
		struct UARPin* return_value;
	} parms;

	parms.ComponentToPin = ComponentToPin;
	parms.TraceResult = TraceResult;
	parms.DebugName = DebugName;

	ProcessEvent(p_PinComponentToTraceResult, &parms);
	return parms.return_value;
}

struct UARPin* UBlueprintFunctionLibrary::PinComponent(struct USceneComponent* ComponentToPin, struct FTransform& PinToWorldTransform, struct UARTrackedGeometry* TrackedGeometry, struct FName DebugName){

	static UObject* p_PinComponent = UObject::FindObject<UFunction>("Function AugmentedReality.ARBlueprintLibrary.PinComponent");

	struct {
		struct USceneComponent* ComponentToPin;
		struct FTransform& PinToWorldTransform;
		struct UARTrackedGeometry* TrackedGeometry;
		struct FName DebugName;
		struct UARPin* return_value;
	} parms;

	parms.ComponentToPin = ComponentToPin;
	parms.PinToWorldTransform = PinToWorldTransform;
	parms.TrackedGeometry = TrackedGeometry;
	parms.DebugName = DebugName;

	ProcessEvent(p_PinComponent, &parms);
	return parms.return_value;
}

void UBlueprintFunctionLibrary::PauseARSession(){

	static UObject* p_PauseARSession = UObject::FindObject<UFunction>("Function AugmentedReality.ARBlueprintLibrary.PauseARSession");

	struct {
	} parms;


	ProcessEvent(p_PauseARSession, &parms);
}

struct TArray<struct FARTraceResult> UBlueprintFunctionLibrary::LineTraceTrackedObjects3D(struct FVector Start, struct FVector End, bool bTestFeaturePoints, bool bTestGroundPlane, bool bTestPlaneExtents, bool bTestPlaneBoundaryPolygon){

	static UObject* p_LineTraceTrackedObjects3D = UObject::FindObject<UFunction>("Function AugmentedReality.ARBlueprintLibrary.LineTraceTrackedObjects3D");

	struct {
		struct FVector Start;
		struct FVector End;
		bool bTestFeaturePoints;
		bool bTestGroundPlane;
		bool bTestPlaneExtents;
		bool bTestPlaneBoundaryPolygon;
		struct TArray<struct FARTraceResult> return_value;
	} parms;

	parms.Start = Start;
	parms.End = End;
	parms.bTestFeaturePoints = bTestFeaturePoints;
	parms.bTestGroundPlane = bTestGroundPlane;
	parms.bTestPlaneExtents = bTestPlaneExtents;
	parms.bTestPlaneBoundaryPolygon = bTestPlaneBoundaryPolygon;

	ProcessEvent(p_LineTraceTrackedObjects3D, &parms);
	return parms.return_value;
}

struct TArray<struct FARTraceResult> UBlueprintFunctionLibrary::LineTraceTrackedObjects(struct FVector2D ScreenCoord, bool bTestFeaturePoints, bool bTestGroundPlane, bool bTestPlaneExtents, bool bTestPlaneBoundaryPolygon){

	static UObject* p_LineTraceTrackedObjects = UObject::FindObject<UFunction>("Function AugmentedReality.ARBlueprintLibrary.LineTraceTrackedObjects");

	struct {
		struct FVector2D ScreenCoord;
		bool bTestFeaturePoints;
		bool bTestGroundPlane;
		bool bTestPlaneExtents;
		bool bTestPlaneBoundaryPolygon;
		struct TArray<struct FARTraceResult> return_value;
	} parms;

	parms.ScreenCoord = ScreenCoord;
	parms.bTestFeaturePoints = bTestFeaturePoints;
	parms.bTestGroundPlane = bTestGroundPlane;
	parms.bTestPlaneExtents = bTestPlaneExtents;
	parms.bTestPlaneBoundaryPolygon = bTestPlaneBoundaryPolygon;

	ProcessEvent(p_LineTraceTrackedObjects, &parms);
	return parms.return_value;
}

bool UBlueprintFunctionLibrary::IsSessionTypeSupported(uint8_t  SessionType){

	static UObject* p_IsSessionTypeSupported = UObject::FindObject<UFunction>("Function AugmentedReality.ARBlueprintLibrary.IsSessionTypeSupported");

	struct {
		uint8_t  SessionType;
		bool return_value;
	} parms;

	parms.SessionType = SessionType;

	ProcessEvent(p_IsSessionTypeSupported, &parms);
	return parms.return_value;
}

bool UBlueprintFunctionLibrary::IsSessionTrackingFeatureSupported(uint8_t  SessionType, uint8_t  SessionTrackingFeature){

	static UObject* p_IsSessionTrackingFeatureSupported = UObject::FindObject<UFunction>("Function AugmentedReality.ARBlueprintLibrary.IsSessionTrackingFeatureSupported");

	struct {
		uint8_t  SessionType;
		uint8_t  SessionTrackingFeature;
		bool return_value;
	} parms;

	parms.SessionType = SessionType;
	parms.SessionTrackingFeature = SessionTrackingFeature;

	ProcessEvent(p_IsSessionTrackingFeatureSupported, &parms);
	return parms.return_value;
}

bool UBlueprintFunctionLibrary::IsARSupported(){

	static UObject* p_IsARSupported = UObject::FindObject<UFunction>("Function AugmentedReality.ARBlueprintLibrary.IsARSupported");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_IsARSupported, &parms);
	return parms.return_value;
}

uint8_t  UBlueprintFunctionLibrary::GetWorldMappingStatus(){

	static UObject* p_GetWorldMappingStatus = UObject::FindObject<UFunction>("Function AugmentedReality.ARBlueprintLibrary.GetWorldMappingStatus");

	struct {
		uint8_t  return_value;
	} parms;


	ProcessEvent(p_GetWorldMappingStatus, &parms);
	return parms.return_value;
}

uint8_t  UBlueprintFunctionLibrary::GetTrackingQualityReason(){

	static UObject* p_GetTrackingQualityReason = UObject::FindObject<UFunction>("Function AugmentedReality.ARBlueprintLibrary.GetTrackingQualityReason");

	struct {
		uint8_t  return_value;
	} parms;


	ProcessEvent(p_GetTrackingQualityReason, &parms);
	return parms.return_value;
}

uint8_t  UBlueprintFunctionLibrary::GetTrackingQuality(){

	static UObject* p_GetTrackingQuality = UObject::FindObject<UFunction>("Function AugmentedReality.ARBlueprintLibrary.GetTrackingQuality");

	struct {
		uint8_t  return_value;
	} parms;


	ProcessEvent(p_GetTrackingQuality, &parms);
	return parms.return_value;
}

struct TArray<struct FARVideoFormat> UBlueprintFunctionLibrary::GetSupportedVideoFormats(uint8_t  SessionType){

	static UObject* p_GetSupportedVideoFormats = UObject::FindObject<UFunction>("Function AugmentedReality.ARBlueprintLibrary.GetSupportedVideoFormats");

	struct {
		uint8_t  SessionType;
		struct TArray<struct FARVideoFormat> return_value;
	} parms;

	parms.SessionType = SessionType;

	ProcessEvent(p_GetSupportedVideoFormats, &parms);
	return parms.return_value;
}

struct UARSessionConfig* UBlueprintFunctionLibrary::GetSessionConfig(){

	static UObject* p_GetSessionConfig = UObject::FindObject<UFunction>("Function AugmentedReality.ARBlueprintLibrary.GetSessionConfig");

	struct {
		struct UARSessionConfig* return_value;
	} parms;


	ProcessEvent(p_GetSessionConfig, &parms);
	return parms.return_value;
}

struct TArray<struct FVector> UBlueprintFunctionLibrary::GetPointCloud(){

	static UObject* p_GetPointCloud = UObject::FindObject<UFunction>("Function AugmentedReality.ARBlueprintLibrary.GetPointCloud");

	struct {
		struct TArray<struct FVector> return_value;
	} parms;


	ProcessEvent(p_GetPointCloud, &parms);
	return parms.return_value;
}

struct UARTextureCameraImage* UBlueprintFunctionLibrary::GetPersonSegmentationImage(){

	static UObject* p_GetPersonSegmentationImage = UObject::FindObject<UFunction>("Function AugmentedReality.ARBlueprintLibrary.GetPersonSegmentationImage");

	struct {
		struct UARTextureCameraImage* return_value;
	} parms;


	ProcessEvent(p_GetPersonSegmentationImage, &parms);
	return parms.return_value;
}

struct UARTextureCameraImage* UBlueprintFunctionLibrary::GetPersonSegmentationDepthImage(){

	static UObject* p_GetPersonSegmentationDepthImage = UObject::FindObject<UFunction>("Function AugmentedReality.ARBlueprintLibrary.GetPersonSegmentationDepthImage");

	struct {
		struct UARTextureCameraImage* return_value;
	} parms;


	ProcessEvent(p_GetPersonSegmentationDepthImage, &parms);
	return parms.return_value;
}

struct UARLightEstimate* UBlueprintFunctionLibrary::GetCurrentLightEstimate(){

	static UObject* p_GetCurrentLightEstimate = UObject::FindObject<UFunction>("Function AugmentedReality.ARBlueprintLibrary.GetCurrentLightEstimate");

	struct {
		struct UARLightEstimate* return_value;
	} parms;


	ProcessEvent(p_GetCurrentLightEstimate, &parms);
	return parms.return_value;
}

struct UARTextureCameraImage* UBlueprintFunctionLibrary::GetCameraImage(){

	static UObject* p_GetCameraImage = UObject::FindObject<UFunction>("Function AugmentedReality.ARBlueprintLibrary.GetCameraImage");

	struct {
		struct UARTextureCameraImage* return_value;
	} parms;


	ProcessEvent(p_GetCameraImage, &parms);
	return parms.return_value;
}

struct UARTextureCameraDepth* UBlueprintFunctionLibrary::GetCameraDepth(){

	static UObject* p_GetCameraDepth = UObject::FindObject<UFunction>("Function AugmentedReality.ARBlueprintLibrary.GetCameraDepth");

	struct {
		struct UARTextureCameraDepth* return_value;
	} parms;


	ProcessEvent(p_GetCameraDepth, &parms);
	return parms.return_value;
}

struct FARSessionStatus UBlueprintFunctionLibrary::GetARSessionStatus(){

	static UObject* p_GetARSessionStatus = UObject::FindObject<UFunction>("Function AugmentedReality.ARBlueprintLibrary.GetARSessionStatus");

	struct {
		struct FARSessionStatus return_value;
	} parms;


	ProcessEvent(p_GetARSessionStatus, &parms);
	return parms.return_value;
}

struct TArray<struct UARTrackedPose*> UBlueprintFunctionLibrary::GetAllTrackedPoses(){

	static UObject* p_GetAllTrackedPoses = UObject::FindObject<UFunction>("Function AugmentedReality.ARBlueprintLibrary.GetAllTrackedPoses");

	struct {
		struct TArray<struct UARTrackedPose*> return_value;
	} parms;


	ProcessEvent(p_GetAllTrackedPoses, &parms);
	return parms.return_value;
}

struct TArray<struct UARTrackedPoint*> UBlueprintFunctionLibrary::GetAllTrackedPoints(){

	static UObject* p_GetAllTrackedPoints = UObject::FindObject<UFunction>("Function AugmentedReality.ARBlueprintLibrary.GetAllTrackedPoints");

	struct {
		struct TArray<struct UARTrackedPoint*> return_value;
	} parms;


	ProcessEvent(p_GetAllTrackedPoints, &parms);
	return parms.return_value;
}

struct TArray<struct UARPlaneGeometry*> UBlueprintFunctionLibrary::GetAllTrackedPlanes(){

	static UObject* p_GetAllTrackedPlanes = UObject::FindObject<UFunction>("Function AugmentedReality.ARBlueprintLibrary.GetAllTrackedPlanes");

	struct {
		struct TArray<struct UARPlaneGeometry*> return_value;
	} parms;


	ProcessEvent(p_GetAllTrackedPlanes, &parms);
	return parms.return_value;
}

struct TArray<struct UARTrackedImage*> UBlueprintFunctionLibrary::GetAllTrackedImages(){

	static UObject* p_GetAllTrackedImages = UObject::FindObject<UFunction>("Function AugmentedReality.ARBlueprintLibrary.GetAllTrackedImages");

	struct {
		struct TArray<struct UARTrackedImage*> return_value;
	} parms;


	ProcessEvent(p_GetAllTrackedImages, &parms);
	return parms.return_value;
}

struct TArray<struct UAREnvironmentCaptureProbe*> UBlueprintFunctionLibrary::GetAllTrackedEnvironmentCaptureProbes(){

	static UObject* p_GetAllTrackedEnvironmentCaptureProbes = UObject::FindObject<UFunction>("Function AugmentedReality.ARBlueprintLibrary.GetAllTrackedEnvironmentCaptureProbes");

	struct {
		struct TArray<struct UAREnvironmentCaptureProbe*> return_value;
	} parms;


	ProcessEvent(p_GetAllTrackedEnvironmentCaptureProbes, &parms);
	return parms.return_value;
}

struct TArray<struct FARPose2D> UBlueprintFunctionLibrary::GetAllTracked2DPoses(){

	static UObject* p_GetAllTracked2DPoses = UObject::FindObject<UFunction>("Function AugmentedReality.ARBlueprintLibrary.GetAllTracked2DPoses");

	struct {
		struct TArray<struct FARPose2D> return_value;
	} parms;


	ProcessEvent(p_GetAllTracked2DPoses, &parms);
	return parms.return_value;
}

struct TArray<struct UARPin*> UBlueprintFunctionLibrary::GetAllPins(){

	static UObject* p_GetAllPins = UObject::FindObject<UFunction>("Function AugmentedReality.ARBlueprintLibrary.GetAllPins");

	struct {
		struct TArray<struct UARPin*> return_value;
	} parms;


	ProcessEvent(p_GetAllPins, &parms);
	return parms.return_value;
}

struct TArray<struct UARTrackedGeometry*> UBlueprintFunctionLibrary::GetAllGeometries(){

	static UObject* p_GetAllGeometries = UObject::FindObject<UFunction>("Function AugmentedReality.ARBlueprintLibrary.GetAllGeometries");

	struct {
		struct TArray<struct UARTrackedGeometry*> return_value;
	} parms;


	ProcessEvent(p_GetAllGeometries, &parms);
	return parms.return_value;
}

void UBlueprintFunctionLibrary::DebugDrawTrackedGeometry(struct UARTrackedGeometry* TrackedGeometry, struct UObject* WorldContextObject, struct FLinearColor Color, float OutlineThickness, float PersistForSeconds){

	static UObject* p_DebugDrawTrackedGeometry = UObject::FindObject<UFunction>("Function AugmentedReality.ARBlueprintLibrary.DebugDrawTrackedGeometry");

	struct {
		struct UARTrackedGeometry* TrackedGeometry;
		struct UObject* WorldContextObject;
		struct FLinearColor Color;
		float OutlineThickness;
		float PersistForSeconds;
	} parms;

	parms.TrackedGeometry = TrackedGeometry;
	parms.WorldContextObject = WorldContextObject;
	parms.Color = Color;
	parms.OutlineThickness = OutlineThickness;
	parms.PersistForSeconds = PersistForSeconds;

	ProcessEvent(p_DebugDrawTrackedGeometry, &parms);
}

void UBlueprintFunctionLibrary::DebugDrawPin(struct UARPin* ARPin, struct UObject* WorldContextObject, struct FLinearColor Color, float Scale, float PersistForSeconds){

	static UObject* p_DebugDrawPin = UObject::FindObject<UFunction>("Function AugmentedReality.ARBlueprintLibrary.DebugDrawPin");

	struct {
		struct UARPin* ARPin;
		struct UObject* WorldContextObject;
		struct FLinearColor Color;
		float Scale;
		float PersistForSeconds;
	} parms;

	parms.ARPin = ARPin;
	parms.WorldContextObject = WorldContextObject;
	parms.Color = Color;
	parms.Scale = Scale;
	parms.PersistForSeconds = PersistForSeconds;

	ProcessEvent(p_DebugDrawPin, &parms);
}

struct UARCandidateImage* UBlueprintFunctionLibrary::AddRuntimeCandidateImage(struct UARSessionConfig* SessionConfig, struct UTexture2D* CandidateTexture, struct FString FriendlyName, float PhysicalWidth){

	static UObject* p_AddRuntimeCandidateImage = UObject::FindObject<UFunction>("Function AugmentedReality.ARBlueprintLibrary.AddRuntimeCandidateImage");

	struct {
		struct UARSessionConfig* SessionConfig;
		struct UTexture2D* CandidateTexture;
		struct FString FriendlyName;
		float PhysicalWidth;
		struct UARCandidateImage* return_value;
	} parms;

	parms.SessionConfig = SessionConfig;
	parms.CandidateTexture = CandidateTexture;
	parms.FriendlyName = FriendlyName;
	parms.PhysicalWidth = PhysicalWidth;

	ProcessEvent(p_AddRuntimeCandidateImage, &parms);
	return parms.return_value;
}

bool UBlueprintFunctionLibrary::AddManualEnvironmentCaptureProbe(struct FVector Location, struct FVector Extent){

	static UObject* p_AddManualEnvironmentCaptureProbe = UObject::FindObject<UFunction>("Function AugmentedReality.ARBlueprintLibrary.AddManualEnvironmentCaptureProbe");

	struct {
		struct FVector Location;
		struct FVector Extent;
		bool return_value;
	} parms;

	parms.Location = Location;
	parms.Extent = Extent;

	ProcessEvent(p_AddManualEnvironmentCaptureProbe, &parms);
	return parms.return_value;
}

uint8_t  UObject::GetTrackingState(){

	static UObject* p_GetTrackingState = UObject::FindObject<UFunction>("Function AugmentedReality.ARPin.GetTrackingState");

	struct {
		uint8_t  return_value;
	} parms;


	ProcessEvent(p_GetTrackingState, &parms);
	return parms.return_value;
}

struct UARTrackedGeometry* UObject::GetTrackedGeometry(){

	static UObject* p_GetTrackedGeometry = UObject::FindObject<UFunction>("Function AugmentedReality.ARPin.GetTrackedGeometry");

	struct {
		struct UARTrackedGeometry* return_value;
	} parms;


	ProcessEvent(p_GetTrackedGeometry, &parms);
	return parms.return_value;
}

struct USceneComponent* UObject::GetPinnedComponent(){

	static UObject* p_GetPinnedComponent = UObject::FindObject<UFunction>("Function AugmentedReality.ARPin.GetPinnedComponent");

	struct {
		struct USceneComponent* return_value;
	} parms;


	ProcessEvent(p_GetPinnedComponent, &parms);
	return parms.return_value;
}

struct FTransform UObject::GetLocalToWorldTransform(){

	static UObject* p_GetLocalToWorldTransform = UObject::FindObject<UFunction>("Function AugmentedReality.ARPin.GetLocalToWorldTransform");

	struct {
		struct FTransform return_value;
	} parms;


	ProcessEvent(p_GetLocalToWorldTransform, &parms);
	return parms.return_value;
}

struct FTransform UObject::GetLocalToTrackingTransform(){

	static UObject* p_GetLocalToTrackingTransform = UObject::FindObject<UFunction>("Function AugmentedReality.ARPin.GetLocalToTrackingTransform");

	struct {
		struct FTransform return_value;
	} parms;


	ProcessEvent(p_GetLocalToTrackingTransform, &parms);
	return parms.return_value;
}

struct FName UObject::GetDebugName(){

	static UObject* p_GetDebugName = UObject::FindObject<UFunction>("Function AugmentedReality.ARPin.GetDebugName");

	struct {
		struct FName return_value;
	} parms;


	ProcessEvent(p_GetDebugName, &parms);
	return parms.return_value;
}

void UObject::DebugDraw(struct UWorld* World, struct FLinearColor& Color, float Scale, float PersistForSeconds){

	static UObject* p_DebugDraw = UObject::FindObject<UFunction>("Function AugmentedReality.ARPin.DebugDraw");

	struct {
		struct UWorld* World;
		struct FLinearColor& Color;
		float Scale;
		float PersistForSeconds;
	} parms;

	parms.World = World;
	parms.Color = Color;
	parms.Scale = Scale;
	parms.PersistForSeconds = PersistForSeconds;

	ProcessEvent(p_DebugDraw, &parms);
}

float UDataAsset::GetPhysicalWidth(){

	static UObject* p_GetPhysicalWidth = UObject::FindObject<UFunction>("Function AugmentedReality.ARCandidateImage.GetPhysicalWidth");

	struct {
		float return_value;
	} parms;


	ProcessEvent(p_GetPhysicalWidth, &parms);
	return parms.return_value;
}

float UDataAsset::GetPhysicalHeight(){

	static UObject* p_GetPhysicalHeight = UObject::FindObject<UFunction>("Function AugmentedReality.ARCandidateImage.GetPhysicalHeight");

	struct {
		float return_value;
	} parms;


	ProcessEvent(p_GetPhysicalHeight, &parms);
	return parms.return_value;
}

uint8_t  UDataAsset::GetOrientation(){

	static UObject* p_GetOrientation = UObject::FindObject<UFunction>("Function AugmentedReality.ARCandidateImage.GetOrientation");

	struct {
		uint8_t  return_value;
	} parms;


	ProcessEvent(p_GetOrientation, &parms);
	return parms.return_value;
}

struct FString UDataAsset::GetFriendlyName(){

	static UObject* p_GetFriendlyName = UObject::FindObject<UFunction>("Function AugmentedReality.ARCandidateImage.GetFriendlyName");

	struct {
		struct FString return_value;
	} parms;


	ProcessEvent(p_GetFriendlyName, &parms);
	return parms.return_value;
}

struct UTexture2D* UDataAsset::GetCandidateTexture(){

	static UObject* p_GetCandidateTexture = UObject::FindObject<UFunction>("Function AugmentedReality.ARCandidateImage.GetCandidateTexture");

	struct {
		struct UTexture2D* return_value;
	} parms;


	ProcessEvent(p_GetCandidateTexture, &parms);
	return parms.return_value;
}

struct FTransform UARTrackedGeometry::GetWorldSpaceEyeTransform(uint8_t  Eye){

	static UObject* p_GetWorldSpaceEyeTransform = UObject::FindObject<UFunction>("Function AugmentedReality.ARFaceGeometry.GetWorldSpaceEyeTransform");

	struct {
		uint8_t  Eye;
		struct FTransform return_value;
	} parms;

	parms.Eye = Eye;

	ProcessEvent(p_GetWorldSpaceEyeTransform, &parms);
	return parms.return_value;
}

struct FTransform UARTrackedGeometry::GetLocalSpaceEyeTransform(uint8_t  Eye){

	static UObject* p_GetLocalSpaceEyeTransform = UObject::FindObject<UFunction>("Function AugmentedReality.ARFaceGeometry.GetLocalSpaceEyeTransform");

	struct {
		uint8_t  Eye;
		struct FTransform return_value;
	} parms;

	parms.Eye = Eye;

	ProcessEvent(p_GetLocalSpaceEyeTransform, &parms);
	return parms.return_value;
}

float UARTrackedGeometry::GetBlendShapeValue(uint8_t  BlendShape){

	static UObject* p_GetBlendShapeValue = UObject::FindObject<UFunction>("Function AugmentedReality.ARFaceGeometry.GetBlendShapeValue");

	struct {
		uint8_t  BlendShape;
		float return_value;
	} parms;

	parms.BlendShape = BlendShape;

	ProcessEvent(p_GetBlendShapeValue, &parms);
	return parms.return_value;
}

struct TMap<uint8_t , float> UARTrackedGeometry::GetBlendShapes(){

	static UObject* p_GetBlendShapes = UObject::FindObject<UFunction>("Function AugmentedReality.ARFaceGeometry.GetBlendShapes");

	struct {
		struct TMap<uint8_t , float> return_value;
	} parms;


	ProcessEvent(p_GetBlendShapes, &parms);
	return parms.return_value;
}

struct UARGetCandidateObjectAsyncTaskBlueprintProxy* UARBaseAsyncTaskBlueprintProxy::ARGetCandidateObject(struct UObject* WorldContextObject, struct FVector Location, struct FVector Extent){

	static UObject* p_ARGetCandidateObject = UObject::FindObject<UFunction>("Function AugmentedReality.ARGetCandidateObjectAsyncTaskBlueprintProxy.ARGetCandidateObject");

	struct {
		struct UObject* WorldContextObject;
		struct FVector Location;
		struct FVector Extent;
		struct UARGetCandidateObjectAsyncTaskBlueprintProxy* return_value;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.Location = Location;
	parms.Extent = Extent;

	ProcessEvent(p_ARGetCandidateObject, &parms);
	return parms.return_value;
}

void AGameMode::SetPreviewImageData(struct TArray<char> ImageData){

	static UObject* p_SetPreviewImageData = UObject::FindObject<UFunction>("Function AugmentedReality.ARSharedWorldGameMode.SetPreviewImageData");

	struct {
		struct TArray<char> ImageData;
	} parms;

	parms.ImageData = ImageData;

	ProcessEvent(p_SetPreviewImageData, &parms);
}

void AGameMode::SetARWorldSharingIsReady(){

	static UObject* p_SetARWorldSharingIsReady = UObject::FindObject<UFunction>("Function AugmentedReality.ARSharedWorldGameMode.SetARWorldSharingIsReady");

	struct {
	} parms;


	ProcessEvent(p_SetARWorldSharingIsReady, &parms);
}

void AGameMode::SetARSharedWorldData(struct TArray<char> ARWorldData){

	static UObject* p_SetARSharedWorldData = UObject::FindObject<UFunction>("Function AugmentedReality.ARSharedWorldGameMode.SetARSharedWorldData");

	struct {
		struct TArray<char> ARWorldData;
	} parms;

	parms.ARWorldData = ARWorldData;

	ProcessEvent(p_SetARSharedWorldData, &parms);
}

struct AARSharedWorldGameState* AGameMode::GetARSharedWorldGameState(){

	static UObject* p_GetARSharedWorldGameState = UObject::FindObject<UFunction>("Function AugmentedReality.ARSharedWorldGameMode.GetARSharedWorldGameState");

	struct {
		struct AARSharedWorldGameState* return_value;
	} parms;


	ProcessEvent(p_GetARSharedWorldGameState, &parms);
	return parms.return_value;
}

void AGameState::K2_OnARWorldMapIsReady(){

	static UObject* p_K2_OnARWorldMapIsReady = UObject::FindObject<UFunction>("Function AugmentedReality.ARSharedWorldGameState.K2_OnARWorldMapIsReady");

	struct {
	} parms;


	ProcessEvent(p_K2_OnARWorldMapIsReady, &parms);
}

struct UARPlaneGeometry* UARTrackedGeometry::GetSubsumedBy(){

	static UObject* p_GetSubsumedBy = UObject::FindObject<UFunction>("Function AugmentedReality.ARPlaneGeometry.GetSubsumedBy");

	struct {
		struct UARPlaneGeometry* return_value;
	} parms;


	ProcessEvent(p_GetSubsumedBy, &parms);
	return parms.return_value;
}

uint8_t  UARTrackedGeometry::GetOrientation(){

	static UObject* p_GetOrientation = UObject::FindObject<UFunction>("Function AugmentedReality.ARPlaneGeometry.GetOrientation");

	struct {
		uint8_t  return_value;
	} parms;


	ProcessEvent(p_GetOrientation, &parms);
	return parms.return_value;
}

struct FVector UARTrackedGeometry::GetExtent(){

	static UObject* p_GetExtent = UObject::FindObject<UFunction>("Function AugmentedReality.ARPlaneGeometry.GetExtent");

	struct {
		struct FVector return_value;
	} parms;


	ProcessEvent(p_GetExtent, &parms);
	return parms.return_value;
}

struct FVector UARTrackedGeometry::GetCenter(){

	static UObject* p_GetCenter = UObject::FindObject<UFunction>("Function AugmentedReality.ARPlaneGeometry.GetCenter");

	struct {
		struct FVector return_value;
	} parms;


	ProcessEvent(p_GetCenter, &parms);
	return parms.return_value;
}

struct TArray<struct FVector> UARTrackedGeometry::GetBoundaryPolygonInLocalSpace(){

	static UObject* p_GetBoundaryPolygonInLocalSpace = UObject::FindObject<UFunction>("Function AugmentedReality.ARPlaneGeometry.GetBoundaryPolygonInLocalSpace");

	struct {
		struct TArray<struct FVector> return_value;
	} parms;


	ProcessEvent(p_GetBoundaryPolygonInLocalSpace, &parms);
	return parms.return_value;
}

void APlayerController::ServerMarkReadyForReceiving(){

	static UObject* p_ServerMarkReadyForReceiving = UObject::FindObject<UFunction>("Function AugmentedReality.ARSharedWorldPlayerController.ServerMarkReadyForReceiving");

	struct {
	} parms;


	ProcessEvent(p_ServerMarkReadyForReceiving, &parms);
}

void APlayerController::ClientUpdatePreviewImageData(int32_t Offset, struct TArray<char> Buffer){

	static UObject* p_ClientUpdatePreviewImageData = UObject::FindObject<UFunction>("Function AugmentedReality.ARSharedWorldPlayerController.ClientUpdatePreviewImageData");

	struct {
		int32_t Offset;
		struct TArray<char> Buffer;
	} parms;

	parms.Offset = Offset;
	parms.Buffer = Buffer;

	ProcessEvent(p_ClientUpdatePreviewImageData, &parms);
}

void APlayerController::ClientUpdateARWorldData(int32_t Offset, struct TArray<char> Buffer){

	static UObject* p_ClientUpdateARWorldData = UObject::FindObject<UFunction>("Function AugmentedReality.ARSharedWorldPlayerController.ClientUpdateARWorldData");

	struct {
		int32_t Offset;
		struct TArray<char> Buffer;
	} parms;

	parms.Offset = Offset;
	parms.Buffer = Buffer;

	ProcessEvent(p_ClientUpdateARWorldData, &parms);
}

void APlayerController::ClientInitSharedWorld(int32_t PreviewImageSize, int32_t ARWorldDataSize){

	static UObject* p_ClientInitSharedWorld = UObject::FindObject<UFunction>("Function AugmentedReality.ARSharedWorldPlayerController.ClientInitSharedWorld");

	struct {
		int32_t PreviewImageSize;
		int32_t ARWorldDataSize;
	} parms;

	parms.PreviewImageSize = PreviewImageSize;
	parms.ARWorldDataSize = ARWorldDataSize;

	ProcessEvent(p_ClientInitSharedWorld, &parms);
}

void ASkyLight::SetEnvironmentCaptureProbe(struct UAREnvironmentCaptureProbe* InCaptureProbe){

	static UObject* p_SetEnvironmentCaptureProbe = UObject::FindObject<UFunction>("Function AugmentedReality.ARSkyLight.SetEnvironmentCaptureProbe");

	struct {
		struct UAREnvironmentCaptureProbe* InCaptureProbe;
	} parms;

	parms.InCaptureProbe = InCaptureProbe;

	ProcessEvent(p_SetEnvironmentCaptureProbe, &parms);
}

bool UObject::IsTracked(){

	static UObject* p_IsTracked = UObject::FindObject<UFunction>("Function AugmentedReality.ARTrackedGeometry.IsTracked");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_IsTracked, &parms);
	return parms.return_value;
}

struct UMRMeshComponent* UObject::GetUnderlyingMesh(){

	static UObject* p_GetUnderlyingMesh = UObject::FindObject<UFunction>("Function AugmentedReality.ARTrackedGeometry.GetUnderlyingMesh");

	struct {
		struct UMRMeshComponent* return_value;
	} parms;


	ProcessEvent(p_GetUnderlyingMesh, &parms);
	return parms.return_value;
}

uint8_t  UObject::GetTrackingState(){

	static UObject* p_GetTrackingState = UObject::FindObject<UFunction>("Function AugmentedReality.ARTrackedGeometry.GetTrackingState");

	struct {
		uint8_t  return_value;
	} parms;


	ProcessEvent(p_GetTrackingState, &parms);
	return parms.return_value;
}

uint8_t  UObject::GetObjectClassification(){

	static UObject* p_GetObjectClassification = UObject::FindObject<UFunction>("Function AugmentedReality.ARTrackedGeometry.GetObjectClassification");

	struct {
		uint8_t  return_value;
	} parms;


	ProcessEvent(p_GetObjectClassification, &parms);
	return parms.return_value;
}

struct FTransform UObject::GetLocalToWorldTransform(){

	static UObject* p_GetLocalToWorldTransform = UObject::FindObject<UFunction>("Function AugmentedReality.ARTrackedGeometry.GetLocalToWorldTransform");

	struct {
		struct FTransform return_value;
	} parms;


	ProcessEvent(p_GetLocalToWorldTransform, &parms);
	return parms.return_value;
}

struct FTransform UObject::GetLocalToTrackingTransform(){

	static UObject* p_GetLocalToTrackingTransform = UObject::FindObject<UFunction>("Function AugmentedReality.ARTrackedGeometry.GetLocalToTrackingTransform");

	struct {
		struct FTransform return_value;
	} parms;


	ProcessEvent(p_GetLocalToTrackingTransform, &parms);
	return parms.return_value;
}

float UObject::GetLastUpdateTimestamp(){

	static UObject* p_GetLastUpdateTimestamp = UObject::FindObject<UFunction>("Function AugmentedReality.ARTrackedGeometry.GetLastUpdateTimestamp");

	struct {
		float return_value;
	} parms;


	ProcessEvent(p_GetLastUpdateTimestamp, &parms);
	return parms.return_value;
}

int32_t UObject::GetLastUpdateFrameNumber(){

	static UObject* p_GetLastUpdateFrameNumber = UObject::FindObject<UFunction>("Function AugmentedReality.ARTrackedGeometry.GetLastUpdateFrameNumber");

	struct {
		int32_t return_value;
	} parms;


	ProcessEvent(p_GetLastUpdateFrameNumber, &parms);
	return parms.return_value;
}

struct FName UObject::GetDebugName(){

	static UObject* p_GetDebugName = UObject::FindObject<UFunction>("Function AugmentedReality.ARTrackedGeometry.GetDebugName");

	struct {
		struct FName return_value;
	} parms;


	ProcessEvent(p_GetDebugName, &parms);
	return parms.return_value;
}

struct UARCandidateObject* UARTrackedGeometry::GetDetectedObject(){

	static UObject* p_GetDetectedObject = UObject::FindObject<UFunction>("Function AugmentedReality.ARTrackedObject.GetDetectedObject");

	struct {
		struct UARCandidateObject* return_value;
	} parms;


	ProcessEvent(p_GetDetectedObject, &parms);
	return parms.return_value;
}

struct FVector2D UARTrackedGeometry::GetEstimateSize(){

	static UObject* p_GetEstimateSize = UObject::FindObject<UFunction>("Function AugmentedReality.ARTrackedImage.GetEstimateSize");

	struct {
		struct FVector2D return_value;
	} parms;


	ProcessEvent(p_GetEstimateSize, &parms);
	return parms.return_value;
}

struct UARCandidateImage* UARTrackedGeometry::GetDetectedImage(){

	static UObject* p_GetDetectedImage = UObject::FindObject<UFunction>("Function AugmentedReality.ARTrackedImage.GetDetectedImage");

	struct {
		struct UARCandidateImage* return_value;
	} parms;


	ProcessEvent(p_GetDetectedImage, &parms);
	return parms.return_value;
}

struct FARPose3D UARTrackedGeometry::GetTrackedPoseData(){

	static UObject* p_GetTrackedPoseData = UObject::FindObject<UFunction>("Function AugmentedReality.ARTrackedPose.GetTrackedPoseData");

	struct {
		struct FARPose3D return_value;
	} parms;


	ProcessEvent(p_GetTrackedPoseData, &parms);
	return parms.return_value;
}

void UDataAsset::SetFriendlyName(struct FString NewName){

	static UObject* p_SetFriendlyName = UObject::FindObject<UFunction>("Function AugmentedReality.ARCandidateObject.SetFriendlyName");

	struct {
		struct FString NewName;
	} parms;

	parms.NewName = NewName;

	ProcessEvent(p_SetFriendlyName, &parms);
}

void UDataAsset::SetCandidateObjectData(struct TArray<char>& InCandidateObject){

	static UObject* p_SetCandidateObjectData = UObject::FindObject<UFunction>("Function AugmentedReality.ARCandidateObject.SetCandidateObjectData");

	struct {
		struct TArray<char>& InCandidateObject;
	} parms;

	parms.InCandidateObject = InCandidateObject;

	ProcessEvent(p_SetCandidateObjectData, &parms);
}

void UDataAsset::SetBoundingBox(struct FBox& InBoundingBox){

	static UObject* p_SetBoundingBox = UObject::FindObject<UFunction>("Function AugmentedReality.ARCandidateObject.SetBoundingBox");

	struct {
		struct FBox& InBoundingBox;
	} parms;

	parms.InBoundingBox = InBoundingBox;

	ProcessEvent(p_SetBoundingBox, &parms);
}

struct FString UDataAsset::GetFriendlyName(){

	static UObject* p_GetFriendlyName = UObject::FindObject<UFunction>("Function AugmentedReality.ARCandidateObject.GetFriendlyName");

	struct {
		struct FString return_value;
	} parms;


	ProcessEvent(p_GetFriendlyName, &parms);
	return parms.return_value;
}

struct TArray<char> UDataAsset::GetCandidateObjectData(){

	static UObject* p_GetCandidateObjectData = UObject::FindObject<UFunction>("Function AugmentedReality.ARCandidateObject.GetCandidateObjectData");

	struct {
		struct TArray<char> return_value;
	} parms;


	ProcessEvent(p_GetCandidateObjectData, &parms);
	return parms.return_value;
}

struct FBox UDataAsset::GetBoundingBox(){

	static UObject* p_GetBoundingBox = UObject::FindObject<UFunction>("Function AugmentedReality.ARCandidateObject.GetBoundingBox");

	struct {
		struct FBox return_value;
	} parms;


	ProcessEvent(p_GetBoundingBox, &parms);
	return parms.return_value;
}

