#pragma once 
#include <AM_Atomic_Body_Activate_T3_Structs.h>
 
 
 
// BlueprintGeneratedClass AM_Atomic_Body_Activate_T3.AM_Atomic_Body_Activate_T3_C
// Size: 0x5E0(Inherited: 0x5E0) 
struct UAM_Atomic_Body_Activate_T3_C : public UME_GameplayAbility_Montage
{

}; 



