#pragma once 
#include <AM_Bio-Electric_Body_Activate_T3_Structs.h>
 
 
 
// BlueprintGeneratedClass AM_Bio-Electric_Body_Activate_T3.AM_Bio-Electric_Body_Activate_T3_C
// Size: 0x5E0(Inherited: 0x5E0) 
struct UAM_Bio-Electric_Body_Activate_T3_C : public UME_GameplayAbility_Montage
{

}; 



