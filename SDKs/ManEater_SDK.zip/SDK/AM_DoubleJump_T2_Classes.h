#pragma once 
#include <AM_DoubleJump_T2_Structs.h>
 
 
 
// BlueprintGeneratedClass AM_DoubleJump_T2.AM_DoubleJump_T2_C
// Size: 0x638(Inherited: 0x638) 
struct UAM_DoubleJump_T2_C : public UME_GameplayAbility_SharkAirLunge
{

}; 



