#pragma once 
#include "SDK.h" 
 
 
// Function AIController_Irradiated_KillerWhale_Shadow_BP.AIController_Irradiated_KillerWhale_Shadow_BP_C.ExecuteUbergraph_AIController_Irradiated_KillerWhale_Shadow_BP
// Size: 0x39(Inherited: 0x0) 
struct FExecuteUbergraph_AIController_Irradiated_KillerWhale_Shadow_BP
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AME_PlayerSharkCharacter* CallFunc_GetPlayerSharkPawn_ReturnValue;  // 0x8(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x10(0x10)
	struct UME_AudioEventManager* CallFunc_GetAudioEventManager_ReturnValue;  // 0x20(0x8)
	char EAIThreatAlertState K2Node_CustomEvent_NewAlertState;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct AActor* K2Node_CustomEvent_InstigatingActor;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool CallFunc_CheckEnemyMassVSPlayer_IsLargerThanPlayer_ : 1;  // 0x38(0x1)

}; 
// Function AIController_Irradiated_KillerWhale_Shadow_BP.AIController_Irradiated_KillerWhale_Shadow_BP_C.CustomEvent
// Size: 0x10(Inherited: 0x0) 
struct FCustomEvent
{
	char EAIThreatAlertState NewAlertState;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct AActor* InstigatingActor;  // 0x8(0x8)

}; 
