#pragma once 
#include <AM_MovingWaterReentryBackwardsAndDown_Structs.h>
 
 
 
// BlueprintGeneratedClass AM_MovingWaterReentryBackwardsAndDown.AM_MovingWaterReentryBackwardsAndDown_C
// Size: 0x620(Inherited: 0x620) 
struct UAM_MovingWaterReentryBackwardsAndDown_C : public UME_GameplayAbilitySharkMontage
{

}; 



