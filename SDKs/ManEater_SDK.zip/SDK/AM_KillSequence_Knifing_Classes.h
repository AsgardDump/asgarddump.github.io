#pragma once 
#include <AM_KillSequence_Knifing_Structs.h>
 
 
 
// BlueprintGeneratedClass AM_KillSequence_Knifing.AM_KillSequence_Knifing_C
// Size: 0x640(Inherited: 0x640) 
struct UAM_KillSequence_Knifing_C : public UAM_KillSequence_C
{

}; 



