#pragma once 
#include <AM_Lunge_T1_Structs.h>
 
 
 
// BlueprintGeneratedClass AM_Lunge_T1.AM_Lunge_T1_C
// Size: 0x620(Inherited: 0x620) 
struct UAM_Lunge_T1_C : public UME_GameplayAbilitySharkMontage
{

}; 



