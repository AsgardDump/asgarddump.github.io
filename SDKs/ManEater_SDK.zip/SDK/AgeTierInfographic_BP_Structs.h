#pragma once 
#include "SDK.h" 
 
 
// Function AgeTierInfographic_BP.AgeTierInfographic_BP_C.ExecuteUbergraph_AgeTierInfographic_BP
// Size: 0x4(Inherited: 0x0) 
struct FExecuteUbergraph_AgeTierInfographic_BP
{
	int32_t EntryPoint;  // 0x0(0x4)

}; 
