#pragma once 
#include <AM_Bio-Electric_Body_Activate_T5_Structs.h>
 
 
 
// BlueprintGeneratedClass AM_Bio-Electric_Body_Activate_T5.AM_Bio-Electric_Body_Activate_T5_C
// Size: 0x5E0(Inherited: 0x5E0) 
struct UAM_Bio-Electric_Body_Activate_T5_C : public UME_GameplayAbility_Montage
{

}; 



