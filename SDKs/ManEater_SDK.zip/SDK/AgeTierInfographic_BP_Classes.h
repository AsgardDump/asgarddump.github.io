#pragma once 
#include <AgeTierInfographic_BP_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass AgeTierInfographic_BP.AgeTierInfographic_BP_C
// Size: 0x2F0(Inherited: 0x2D0) 
struct UAgeTierInfographic_BP_C : public UAgeTierInfographicWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x2D0(0x8)
	struct UWidgetAnimation* OutAnimation;  // 0x2D8(0x8)
	struct UImage* ageglow;  // 0x2E0(0x8)
	struct URetainerBox* RetainerBox_1;  // 0x2E8(0x8)

	void Construct(); // Function AgeTierInfographic_BP.AgeTierInfographic_BP_C.Construct
	void ExecuteUbergraph_AgeTierInfographic_BP(int32_t EntryPoint); // Function AgeTierInfographic_BP.AgeTierInfographic_BP_C.ExecuteUbergraph_AgeTierInfographic_BP
}; 



