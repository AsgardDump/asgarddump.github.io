#pragma once 
#include "SDK.h" 
 
 
// Function Apex_AtomicLeviathan_BP.Apex_AtomicLeviathan_BP_C.CharacterDied
// Size: 0x10(Inherited: 0x0) 
struct FCharacterDied
{
	struct AME_Character* Victim;  // 0x0(0x8)
	struct AActor* Killer;  // 0x8(0x8)

}; 
// Function Apex_AtomicLeviathan_BP.Apex_AtomicLeviathan_BP_C.ExecuteUbergraph_Apex_AtomicLeviathan_BP
// Size: 0x230(Inherited: 0x0) 
struct FExecuteUbergraph_Apex_AtomicLeviathan_BP
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	AApex_AtomicLeviathan_BP_C* CallFunc_GetObjectClass_ReturnValue;  // 0x8(0x8)
	struct AActor* K2Node_CustomEvent_DamagedActor;  // 0x10(0x8)
	float K2Node_CustomEvent_Damage;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct UDamageType* K2Node_CustomEvent_DamageType;  // 0x20(0x8)
	struct AController* K2Node_CustomEvent_InstigatedBy;  // 0x28(0x8)
	struct AActor* K2Node_CustomEvent_DamageCauser;  // 0x30(0x8)
	float CallFunc_Subtract_FloatFloat_ReturnValue;  // 0x38(0x4)
	char pad_60_1 : 7;  // 0x3C(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue : 1;  // 0x3C(0x1)
	char pad_61[3];  // 0x3D(0x3)
	float CallFunc_GetHealthMax_ReturnValue;  // 0x40(0x4)
	char pad_68_1 : 7;  // 0x44(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x44(0x1)
	char pad_69[3];  // 0x45(0x3)
	float CallFunc_GetHealthPercentage_ReturnValue;  // 0x48(0x4)
	char pad_76_1 : 7;  // 0x4C(0x1)
	bool CallFunc_LessEqual_FloatFloat_ReturnValue : 1;  // 0x4C(0x1)
	char pad_77[3];  // 0x4D(0x3)
	float K2Node_Event_DeltaSeconds;  // 0x50(0x4)
	char pad_84_1 : 7;  // 0x54(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_2 : 1;  // 0x54(0x1)
	char pad_85_1 : 7;  // 0x55(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x55(0x1)
	char pad_86[2];  // 0x56(0x2)
	struct TArray<struct USceneComponent*> K2Node_MakeArray_Array;  // 0x58(0x10)
	struct ULevelStreaming* CallFunc_GetStreamingLevel_ReturnValue;  // 0x68(0x8)
	struct UAnimMontage* CallFunc_GetCurrentMontage_ReturnValue;  // 0x70(0x8)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x78(0x1)
	char pad_121[7];  // 0x79(0x7)
	struct FTransform CallFunc_GetTransform_ReturnValue;  // 0x80(0x30)
	struct ULevelStreaming* CallFunc_GetStreamingLevel_ReturnValue_2;  // 0xB0(0x8)
	char pad_184_1 : 7;  // 0xB8(0x1)
	bool CallFunc_IsLevelVisible_ReturnValue : 1;  // 0xB8(0x1)
	char pad_185[7];  // 0xB9(0x7)
	struct FTimerHandle CallFunc_K2_SetTimer_ReturnValue;  // 0xC0(0x8)
	struct AME_Character* K2Node_CustomEvent_Victim;  // 0xC8(0x8)
	struct AActor* K2Node_CustomEvent_Killer;  // 0xD0(0x8)
	char pad_216_1 : 7;  // 0xD8(0x1)
	bool K2Node_CustomEvent_ShouldLoad_ : 1;  // 0xD8(0x1)
	char pad_217[7];  // 0xD9(0x7)
	struct ULevelStreaming* CallFunc_GetStreamingLevel_ReturnValue_3;  // 0xE0(0x8)
	char pad_232_1 : 7;  // 0xE8(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0xE8(0x1)
	char pad_233[7];  // 0xE9(0x7)
	struct FGameplayTagContainer K2Node_Event_TagsAdded_2;  // 0xF0(0x20)
	float K2Node_Event_TagDuration;  // 0x110(0x4)
	char pad_276[4];  // 0x114(0x4)
	struct AAIController* CallFunc_GetAIController_ReturnValue;  // 0x118(0x8)
	struct FString CallFunc_GetDebugStringFromGameplayTagContainer_ReturnValue;  // 0x120(0x10)
	struct AAIController_AtomicLeviathan_C* K2Node_DynamicCast_AsAIController_Atomic_Leviathan;  // 0x130(0x8)
	char pad_312_1 : 7;  // 0x138(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x138(0x1)
	char pad_313_1 : 7;  // 0x139(0x1)
	bool CallFunc_EqualEqual_StrStr_ReturnValue : 1;  // 0x139(0x1)
	char pad_314[6];  // 0x13A(0x6)
	struct FGameplayTagContainer K2Node_Event_TagsAdded;  // 0x140(0x20)
	struct FString CallFunc_GetDebugStringFromGameplayTagContainer_ReturnValue_2;  // 0x160(0x10)
	char pad_368_1 : 7;  // 0x170(0x1)
	bool CallFunc_EqualEqual_StrStr_ReturnValue_2 : 1;  // 0x170(0x1)
	char pad_369[7];  // 0x171(0x7)
	struct AGameModeBase* CallFunc_GetGameMode_ReturnValue;  // 0x178(0x8)
	struct ABP_ManeaterGameMode_C* K2Node_DynamicCast_AsBP_Maneater_Game_Mode;  // 0x180(0x8)
	char pad_392_1 : 7;  // 0x188(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x188(0x1)
	char pad_393[7];  // 0x189(0x7)
	AApex_AtomicLeviathan_BP_C* CallFunc_GetObjectClass_ReturnValue_2;  // 0x190(0x8)
	AWildlife_Base_BP_C* CallFunc_GetCurrentApex_ApexClass;  // 0x198(0x8)
	struct AWildlife_Base_BP_C* CallFunc_GetCurrentApex_WildlifeRef;  // 0x1A0(0x8)
	char pad_424_1 : 7;  // 0x1A8(0x1)
	bool CallFunc_NotEqual_ClassClass_ReturnValue : 1;  // 0x1A8(0x1)
	char pad_425[3];  // 0x1A9(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x1AC(0x10)
	char pad_444[4];  // 0x1BC(0x4)
	struct ULevelStreaming* CallFunc_GetStreamingLevel_ReturnValue_4;  // 0x1C0(0x8)
	char pad_456_1 : 7;  // 0x1C8(0x1)
	bool CallFunc_IsValid_ReturnValue_3 : 1;  // 0x1C8(0x1)
	char pad_457_1 : 7;  // 0x1C9(0x1)
	bool CallFunc_IsValid_ReturnValue_4 : 1;  // 0x1C9(0x1)
	char pad_458_1 : 7;  // 0x1CA(0x1)
	bool CallFunc_IsValid_ReturnValue_5 : 1;  // 0x1CA(0x1)
	char pad_459[1];  // 0x1CB(0x1)
	float CallFunc_Subtract_FloatFloat_ReturnValue_2;  // 0x1CC(0x4)
	struct FTimerHandle CallFunc_K2_SetTimer_ReturnValue_2;  // 0x1D0(0x8)
	struct UME_AbilitySystemComponent* CallFunc_GetAbilitySystemComponent_ReturnValue;  // 0x1D8(0x8)
	struct UME_AbilitySystemComponent* CallFunc_GetAbilitySystemComponent_ReturnValue_2;  // 0x1E0(0x8)
	char pad_488_1 : 7;  // 0x1E8(0x1)
	bool CallFunc_TryActivateAbilityByClass_ReturnValue : 1;  // 0x1E8(0x1)
	char pad_489_1 : 7;  // 0x1E9(0x1)
	bool CallFunc_TryActivateAbilityByClass_ReturnValue_2 : 1;  // 0x1E9(0x1)
	char pad_490[2];  // 0x1EA(0x2)
	float CallFunc_GetHealthPercentage_ReturnValue_2;  // 0x1EC(0x4)
	float CallFunc_GetHealthPercentage_ReturnValue_3;  // 0x1F0(0x4)
	char pad_500_1 : 7;  // 0x1F4(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue_2 : 1;  // 0x1F4(0x1)
	char pad_501_1 : 7;  // 0x1F5(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue_3 : 1;  // 0x1F5(0x1)
	char pad_502[2];  // 0x1F6(0x2)
	struct ABP_PlayerShark_C* CallFunc_GetSharkPlayerPawn_SharkPlayer;  // 0x1F8(0x8)
	struct AGameModeBase* CallFunc_GetGameMode_ReturnValue_2;  // 0x200(0x8)
	struct ABP_ManeaterGameMode_C* K2Node_DynamicCast_AsBP_Maneater_Game_Mode_2;  // 0x208(0x8)
	char pad_528_1 : 7;  // 0x210(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x210(0x1)
	char pad_529[7];  // 0x211(0x7)
	struct UME_SpawnPool* CallFunc_GetSpawnPool_ReturnValue;  // 0x218(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x220(0x10)

}; 
// Function Apex_AtomicLeviathan_BP.Apex_AtomicLeviathan_BP_C.UpdateHealthPercentage
// Size: 0x8(Inherited: 0x0) 
struct FUpdateHealthPercentage
{
	float CallFunc_GetHealthMax_ReturnValue;  // 0x0(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x4(0x4)

}; 
// Function Apex_AtomicLeviathan_BP.Apex_AtomicLeviathan_BP_C.GameplayTagRemoved
// Size: 0x20(Inherited: 0x20) 
struct FGameplayTagRemoved : public FGameplayTagRemoved
{
	struct FGameplayTagContainer TagsAdded;  // 0x0(0x20)

}; 
// Function Apex_AtomicLeviathan_BP.Apex_AtomicLeviathan_BP_C.ResetArmor
// Size: 0xC(Inherited: 0x0) 
struct FResetArmor
{
	float CallFunc_GetHealthPercentage_ReturnValue;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	float CallFunc_GetHealth_ReturnValue;  // 0x8(0x4)

}; 
// Function Apex_AtomicLeviathan_BP.Apex_AtomicLeviathan_BP_C.UpdateSpawnedWildlifeAIs
// Size: 0x82(Inherited: 0x0) 
struct FUpdateSpawnedWildlifeAIs
{
	int32_t Temp_int_Array_Index_Variable;  // 0x0(0x4)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x4(0xC)
	float CallFunc_Square_ReturnValue;  // 0x10(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x14(0x4)
	struct AME_PlayerSharkCharacter* CallFunc_GetPlayerSharkPawn_ReturnValue;  // 0x18(0x8)
	float CallFunc_GetSquaredDistanceTo_ReturnValue;  // 0x20(0x4)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_2;  // 0x24(0xC)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue : 1;  // 0x30(0x1)
	char pad_49[3];  // 0x31(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x34(0x4)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x38(0x4)
	char pad_60[4];  // 0x3C(0x4)
	struct TSoftObjectPtr<AME_AIController> CallFunc_Array_Get_Item;  // 0x40(0x28)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x68(0x1)
	char pad_105[7];  // 0x69(0x7)
	struct UObject* CallFunc_Conv_SoftObjectReferenceToObject_ReturnValue;  // 0x70(0x8)
	struct AME_AIController* K2Node_DynamicCast_AsME_AIController;  // 0x78(0x8)
	char pad_128_1 : 7;  // 0x80(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x80(0x1)
	char pad_129_1 : 7;  // 0x81(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x81(0x1)

}; 
// Function Apex_AtomicLeviathan_BP.Apex_AtomicLeviathan_BP_C.Damage Taken
// Size: 0x28(Inherited: 0x0) 
struct FDamage Taken
{
	struct AActor* DamagedActor;  // 0x0(0x8)
	float Damage;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct UDamageType* DamageType;  // 0x10(0x8)
	struct AController* InstigatedBy;  // 0x18(0x8)
	struct AActor* DamageCauser;  // 0x20(0x8)

}; 
// Function Apex_AtomicLeviathan_BP.Apex_AtomicLeviathan_BP_C.TryLoadBoundry
// Size: 0x1(Inherited: 0x0) 
struct FTryLoadBoundry
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ShouldLoad? : 1;  // 0x0(0x1)

}; 
// Function Apex_AtomicLeviathan_BP.Apex_AtomicLeviathan_BP_C.ReceiveTick
// Size: 0x4(Inherited: 0x4) 
struct FReceiveTick : public FReceiveTick
{
	float DeltaSeconds;  // 0x0(0x4)

}; 
// Function Apex_AtomicLeviathan_BP.Apex_AtomicLeviathan_BP_C.ScareSpawnedWildlife
// Size: 0x79(Inherited: 0x0) 
struct FScareSpawnedWildlife
{
	int32_t Temp_int_Array_Index_Variable;  // 0x0(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x4(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct AME_PlayerSharkCharacter* CallFunc_GetPlayerSharkPawn_ReturnValue;  // 0x10(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct TSoftObjectPtr<AME_AIController> CallFunc_Array_Get_Item;  // 0x20(0x28)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)
	struct UObject* CallFunc_Conv_SoftObjectReferenceToObject_ReturnValue;  // 0x50(0x8)
	struct AME_AIController* K2Node_DynamicCast_AsME_AIController;  // 0x58(0x8)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x60(0x1)
	char pad_97[7];  // 0x61(0x7)
	struct APawn* CallFunc_GetPawnAndAIController_Out_Pawn;  // 0x68(0x8)
	struct AME_AIController* CallFunc_GetPawnAndAIController_Out_AIController;  // 0x70(0x8)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x78(0x1)

}; 
// Function Apex_AtomicLeviathan_BP.Apex_AtomicLeviathan_BP_C.SetUpHealthBar
// Size: 0x31(Inherited: 0x0) 
struct FSetUpHealthBar
{
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct AManeaterHUD* CallFunc_GetManeaterHUD_ReturnValue;  // 0x10(0x8)
	struct UManeaterHUDViewController* CallFunc_GetHUDViewController_ReturnValue;  // 0x18(0x8)
	struct UTwBaseView* CallFunc_GetActiveView_ReturnValue;  // 0x20(0x8)
	struct UManeaterHUDView_BP_C* K2Node_DynamicCast_AsManeater_HUDView_BP;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x30(0x1)

}; 
// Function Apex_AtomicLeviathan_BP.Apex_AtomicLeviathan_BP_C.UpdateHealthBar
// Size: 0x14(Inherited: 0x0) 
struct FUpdateHealthBar
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x4(0x4)
	float CallFunc_GetHealth_ReturnValue;  // 0x8(0x4)
	float CallFunc_GetHealthMax_ReturnValue;  // 0xC(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue_2;  // 0x10(0x4)

}; 
// Function Apex_AtomicLeviathan_BP.Apex_AtomicLeviathan_BP_C.SpawnWildlifeIfNeeded
// Size: 0x2F1(Inherited: 0x0) 
struct FSpawnWildlifeIfNeeded
{
	struct USceneComponent* BestSpawner;  // 0x0(0x8)
	struct FVector BestSpawnLocation;  // 0x8(0xC)
	float MinSpawnDistance;  // 0x14(0x4)
	float BestSpawnerDistance;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct TArray<APawn*> SpawnList;  // 0x20(0x10)
	int32_t Temp_int_Array_Index_Variable;  // 0x30(0x4)
	struct FName CallFunc_MakeLiteralName_ReturnValue;  // 0x34(0x8)
	char pad_60[4];  // 0x3C(0x4)
	struct AME_PlayerSharkCharacter* CallFunc_GetPlayerSharkPawn_ReturnValue;  // 0x40(0x8)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x48(0x4)
	int32_t CallFunc_Array_AddUnique_ReturnValue;  // 0x4C(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x50(0x4)
	int32_t Temp_int_Variable;  // 0x54(0x4)
	struct AME_PlayerSharkCharacter* CallFunc_GetPlayerSharkPawn_ReturnValue_2;  // 0x58(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x60(0x4)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x64(0xC)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x70(0x1)
	char pad_113[7];  // 0x71(0x7)
	struct TArray<struct AActor*> Temp_object_Variable;  // 0x78(0x10)
	struct AME_PlayerSharkCharacter* CallFunc_GetPlayerSharkPawn_ReturnValue_3;  // 0x88(0x8)
	struct FRotator CallFunc_FindLookAtRotation_ReturnValue;  // 0x90(0xC)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0x9C(0x4)
	struct TArray<APawn*> K2Node_MakeArray_Array;  // 0xA0(0x10)
	APawn* CallFunc_Array_Get_Item;  // 0xB0(0x8)
	struct AME_AIController* CallFunc_SpawnAIAtLocation_ReturnValue;  // 0xB8(0x8)
	struct TSoftObjectPtr<AME_AIController> CallFunc_Conv_ObjectToSoftObjectReference_ReturnValue;  // 0xC0(0x28)
	char pad_232_1 : 7;  // 0xE8(0x1)
	bool CallFunc_GreaterEqual_FloatFloat_ReturnValue : 1;  // 0xE8(0x1)
	char pad_233[3];  // 0xE9(0x3)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0xEC(0x4)
	struct UBlackboardComponent* CallFunc_GetBlackboard_ReturnValue;  // 0xF0(0x8)
	char pad_248_1 : 7;  // 0xF8(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0xF8(0x1)
	char pad_249[7];  // 0xF9(0x7)
	struct USceneComponent* CallFunc_Array_Get_Item_2;  // 0x100(0x8)
	char pad_264[8];  // 0x108(0x8)
	struct FTransform CallFunc_GetTransform_ReturnValue;  // 0x110(0x30)
	struct FVector CallFunc_BreakTransform_Location;  // 0x140(0xC)
	struct FRotator CallFunc_BreakTransform_Rotation;  // 0x14C(0xC)
	struct FVector CallFunc_BreakTransform_Scale;  // 0x158(0xC)
	char pad_356[12];  // 0x164(0xC)
	struct FTransform CallFunc_K2_GetComponentToWorld_ReturnValue;  // 0x170(0x30)
	char pad_416_1 : 7;  // 0x1A0(0x1)
	bool CallFunc_Array_Contains_ReturnValue : 1;  // 0x1A0(0x1)
	char pad_417[3];  // 0x1A1(0x3)
	struct FVector CallFunc_BreakTransform_Location_2;  // 0x1A4(0xC)
	struct FRotator CallFunc_BreakTransform_Rotation_2;  // 0x1B0(0xC)
	struct FVector CallFunc_BreakTransform_Scale_2;  // 0x1BC(0xC)
	char pad_456_1 : 7;  // 0x1C8(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x1C8(0x1)
	char pad_457[3];  // 0x1C9(0x3)
	struct FVector CallFunc_Subtract_VectorVector_ReturnValue;  // 0x1CC(0xC)
	struct FHitResult CallFunc_SphereTraceSingle_OutHit;  // 0x1D8(0x88)
	char pad_608_1 : 7;  // 0x260(0x1)
	bool CallFunc_SphereTraceSingle_ReturnValue : 1;  // 0x260(0x1)
	char pad_609[3];  // 0x261(0x3)
	float CallFunc_VSize_ReturnValue;  // 0x264(0x4)
	char pad_616_1 : 7;  // 0x268(0x1)
	bool CallFunc_BreakHitResult_bBlockingHit : 1;  // 0x268(0x1)
	char pad_617_1 : 7;  // 0x269(0x1)
	bool CallFunc_BreakHitResult_bInitialOverlap : 1;  // 0x269(0x1)
	char pad_618[2];  // 0x26A(0x2)
	float CallFunc_BreakHitResult_Time;  // 0x26C(0x4)
	float CallFunc_BreakHitResult_Distance;  // 0x270(0x4)
	struct FVector CallFunc_BreakHitResult_Location;  // 0x274(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactPoint;  // 0x280(0xC)
	struct FVector CallFunc_BreakHitResult_Normal;  // 0x28C(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactNormal;  // 0x298(0xC)
	char pad_676[4];  // 0x2A4(0x4)
	struct UPhysicalMaterial* CallFunc_BreakHitResult_PhysMat;  // 0x2A8(0x8)
	struct AActor* CallFunc_BreakHitResult_HitActor;  // 0x2B0(0x8)
	struct UPrimitiveComponent* CallFunc_BreakHitResult_HitComponent;  // 0x2B8(0x8)
	struct FName CallFunc_BreakHitResult_HitBoneName;  // 0x2C0(0x8)
	int32_t CallFunc_BreakHitResult_HitItem;  // 0x2C8(0x4)
	int32_t CallFunc_BreakHitResult_FaceIndex;  // 0x2CC(0x4)
	struct FVector CallFunc_BreakHitResult_TraceStart;  // 0x2D0(0xC)
	struct FVector CallFunc_BreakHitResult_TraceEnd;  // 0x2DC(0xC)
	char pad_744_1 : 7;  // 0x2E8(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue : 1;  // 0x2E8(0x1)
	char pad_745_1 : 7;  // 0x2E9(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_2 : 1;  // 0x2E9(0x1)
	char pad_746[2];  // 0x2EA(0x2)
	int32_t CallFunc_Array_Length_ReturnValue_2;  // 0x2EC(0x4)
	char pad_752_1 : 7;  // 0x2F0(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_2 : 1;  // 0x2F0(0x1)

}; 
// Function Apex_AtomicLeviathan_BP.Apex_AtomicLeviathan_BP_C.TryRemoveHealthBar
// Size: 0x9(Inherited: 0x0) 
struct FTryRemoveHealthBar
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	float CallFunc_GetHealthPercentage_ReturnValue;  // 0x4(0x4)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CallFunc_LessEqual_FloatFloat_ReturnValue : 1;  // 0x8(0x1)

}; 
// Function Apex_AtomicLeviathan_BP.Apex_AtomicLeviathan_BP_C.ShowHealthBar?
// Size: 0x1(Inherited: 0x0) 
struct FShowHealthBar?
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Show? : 1;  // 0x0(0x1)

}; 
// Function Apex_AtomicLeviathan_BP.Apex_AtomicLeviathan_BP_C.MoveToStartingLocation
// Size: 0x25(Inherited: 0x0) 
struct FMoveToStartingLocation
{
	struct FVector CallFunc_BreakTransform_Location;  // 0x0(0xC)
	struct FRotator CallFunc_BreakTransform_Rotation;  // 0xC(0xC)
	struct FVector CallFunc_BreakTransform_Scale;  // 0x18(0xC)
	char pad_36_1 : 7;  // 0x24(0x1)
	bool CallFunc_K2_TeleportTo_ReturnValue : 1;  // 0x24(0x1)

}; 
// Function Apex_AtomicLeviathan_BP.Apex_AtomicLeviathan_BP_C.StartFinaleCinematic
// Size: 0x8(Inherited: 0x0) 
struct FStartFinaleCinematic
{
	struct AME_GameMode* CallFunc_GetManeaterGameMode_ReturnValue;  // 0x0(0x8)

}; 
// Function Apex_AtomicLeviathan_BP.Apex_AtomicLeviathan_BP_C.DestroySpawnedWildlife
// Size: 0x69(Inherited: 0x0) 
struct FDestroySpawnedWildlife
{
	int32_t Temp_int_Array_Index_Variable;  // 0x0(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x4(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x8(0x4)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0xC(0x4)
	struct TSoftObjectPtr<AME_AIController> CallFunc_Array_Get_Item;  // 0x10(0x28)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct UObject* CallFunc_Conv_SoftObjectReferenceToObject_ReturnValue;  // 0x40(0x8)
	struct AME_AIController* K2Node_DynamicCast_AsME_AIController;  // 0x48(0x8)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x50(0x1)
	char pad_81[7];  // 0x51(0x7)
	struct APawn* CallFunc_GetPawnAndAIController_Out_Pawn;  // 0x58(0x8)
	struct AME_AIController* CallFunc_GetPawnAndAIController_Out_AIController;  // 0x60(0x8)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x68(0x1)

}; 
// Function Apex_AtomicLeviathan_BP.Apex_AtomicLeviathan_BP_C.SetUpDynamicMaterials
// Size: 0x20(Inherited: 0x0) 
struct FSetUpDynamicMaterials
{
	struct UMaterialInterface* CallFunc_GetMaterial_ReturnValue;  // 0x0(0x8)
	struct UMaterialInterface* CallFunc_GetMaterial_ReturnValue_2;  // 0x8(0x8)
	struct UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue;  // 0x10(0x8)
	struct UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue_2;  // 0x18(0x8)

}; 
// Function Apex_AtomicLeviathan_BP.Apex_AtomicLeviathan_BP_C.GameplayTagAdded
// Size: 0x24(Inherited: 0x24) 
struct FGameplayTagAdded : public FGameplayTagAdded
{
	struct FGameplayTagContainer TagsAdded;  // 0x0(0x20)
	float TagDuration;  // 0x20(0x4)

}; 
// Function Apex_AtomicLeviathan_BP.Apex_AtomicLeviathan_BP_C.FacePlayer
// Size: 0x2D(Inherited: 0x0) 
struct FFacePlayer
{
	struct AME_PlayerSharkCharacter* CallFunc_GetPlayerSharkPawn_ReturnValue;  // 0x0(0x8)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x8(0xC)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_2;  // 0x14(0xC)
	struct FRotator CallFunc_FindLookAtRotation_ReturnValue;  // 0x20(0xC)
	char pad_44_1 : 7;  // 0x2C(0x1)
	bool CallFunc_K2_SetActorRotation_ReturnValue : 1;  // 0x2C(0x1)

}; 
