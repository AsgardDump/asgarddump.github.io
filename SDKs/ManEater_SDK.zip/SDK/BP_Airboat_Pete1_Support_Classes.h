#pragma once 
#include <BP_Airboat_Pete1_Support_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Airboat_Pete1_Support.BP_Airboat_Pete1_Support_C
// Size: 0xE00(Inherited: 0xE00) 
struct ABP_Airboat_Pete1_Support_C : public ABP_Boss_Support_Boat_C
{

}; 



