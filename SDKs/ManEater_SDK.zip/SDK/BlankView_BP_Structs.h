#pragma once 
#include "SDK.h" 
 
 
// Function BlankView_BP.BlankView_BP_C.ExecuteUbergraph_BlankView_BP
// Size: 0x10(Inherited: 0x0) 
struct FExecuteUbergraph_BlankView_BP
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_SetGamePaused_ReturnValue : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct AHUD* K2Node_Event_HUD;  // 0x8(0x8)

}; 
// Function BlankView_BP.BlankView_BP_C.DoesRequireInputUIMode
// Size: 0x1(Inherited: 0x1) 
struct FDoesRequireInputUIMode : public FDoesRequireInputUIMode
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function BlankView_BP.BlankView_BP_C.SubscribeToEvents_BP
// Size: 0x8(Inherited: 0x8) 
struct FSubscribeToEvents_BP : public FSubscribeToEvents_BP
{
	struct AHUD* HUD;  // 0x0(0x8)

}; 
