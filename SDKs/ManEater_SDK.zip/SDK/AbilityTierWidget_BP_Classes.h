#pragma once 
#include <AbilityTierWidget_BP_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass AbilityTierWidget_BP.AbilityTierWidget_BP_C
// Size: 0x280(Inherited: 0x280) 
struct UAbilityTierWidget_BP_C : public UAbilityTierWidget
{

}; 



