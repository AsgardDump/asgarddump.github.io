#pragma once 
#include <AM_Bio-Electric_Body_Activate_T2_Structs.h>
 
 
 
// BlueprintGeneratedClass AM_Bio-Electric_Body_Activate_T2.AM_Bio-Electric_Body_Activate_T2_C
// Size: 0x5E0(Inherited: 0x5E0) 
struct UAM_Bio-Electric_Body_Activate_T2_C : public UME_GameplayAbility_Montage
{

}; 



