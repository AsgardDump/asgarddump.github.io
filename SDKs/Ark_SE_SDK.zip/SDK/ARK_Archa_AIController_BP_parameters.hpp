#pragma once

// ARK: Survival Evolved (358.6 (STEAM)) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "../SDK.hpp"

namespace Classes
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function Archa_AIController_BP.Archa_AIController_BP_C.UserConstructionScript
struct AArcha_AIController_BP_C_UserConstructionScript_Params
{
};

// Function Archa_AIController_BP.Archa_AIController_BP_C.ExecuteUbergraph_Archa_AIController_BP
struct AArcha_AIController_BP_C_ExecuteUbergraph_Archa_AIController_BP_Params
{
	int                                                EntryPoint;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
