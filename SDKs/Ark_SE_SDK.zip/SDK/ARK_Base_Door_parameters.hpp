#pragma once

// ARK: Survival Evolved (358.6 (STEAM)) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "../SDK.hpp"

namespace Classes
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function Base_Door.Base_Door_C.UserConstructionScript
struct ABase_Door_C_UserConstructionScript_Params
{
};

// Function Base_Door.Base_Door_C.ExecuteUbergraph_Base_Door
struct ABase_Door_C_ExecuteUbergraph_Base_Door_Params
{
	int                                                EntryPoint;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
