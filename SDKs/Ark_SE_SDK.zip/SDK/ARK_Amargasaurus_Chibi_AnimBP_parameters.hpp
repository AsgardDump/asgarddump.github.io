#pragma once

// ARK: Survival Evolved (358.6 (STEAM)) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "../SDK.hpp"

namespace Classes
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function Amargasaurus_Chibi_AnimBP.Amargasaurus_Chibi_AnimBP_C.ExecuteUbergraph_Amargasaurus_Chibi_AnimBP
struct UAmargasaurus_Chibi_AnimBP_C_ExecuteUbergraph_Amargasaurus_Chibi_AnimBP_Params
{
	int                                                EntryPoint;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
