#pragma once

// ARK: Survival Evolved (358.6 (STEAM)) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "../SDK.hpp"

namespace Classes
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function AirConditioner.AirConditioner_C.UserConstructionScript
struct AAirConditioner_C_UserConstructionScript_Params
{
};

// Function AirConditioner.AirConditioner_C.ExecuteUbergraph_AirConditioner
struct AAirConditioner_C_ExecuteUbergraph_AirConditioner_Params
{
	int                                                EntryPoint;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
