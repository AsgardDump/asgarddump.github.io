#pragma once

// ARK: Survival Evolved (358.6 (STEAM)) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "../SDK.hpp"

namespace Classes
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function AmargaSpike_Hot.AmargaSpike_Hot_C.UserConstructionScript
struct AAmargaSpike_Hot_C_UserConstructionScript_Params
{
};

// Function AmargaSpike_Hot.AmargaSpike_Hot_C.ExecuteUbergraph_AmargaSpike_Hot
struct AAmargaSpike_Hot_C_ExecuteUbergraph_AmargaSpike_Hot_Params
{
	int                                                EntryPoint;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
