#pragma once

// ARK: Survival Evolved (358.6 (STEAM)) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "../SDK.hpp"

namespace Classes
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function Argent_Character_BP_Summoned.Argent_Character_BP_Summoned_C.UserConstructionScript
struct AArgent_Character_BP_Summoned_C_UserConstructionScript_Params
{
};

// Function Argent_Character_BP_Summoned.Argent_Character_BP_Summoned_C.ExecuteUbergraph_Argent_Character_BP_Summoned
struct AArgent_Character_BP_Summoned_C_ExecuteUbergraph_Argent_Character_BP_Summoned_Params
{
	int                                                EntryPoint;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
