#pragma once

// ARK: Survival Evolved (358.6 (STEAM)) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "../SDK.hpp"

namespace Classes
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function AmargaSpike_Armor_TrailEmitter.AmargaSpike_Armor_TrailEmitter_C.UserConstructionScript
struct AAmargaSpike_Armor_TrailEmitter_C_UserConstructionScript_Params
{
};

// Function AmargaSpike_Armor_TrailEmitter.AmargaSpike_Armor_TrailEmitter_C.ExecuteUbergraph_AmargaSpike_Armor_TrailEmitter
struct AAmargaSpike_Armor_TrailEmitter_C_ExecuteUbergraph_AmargaSpike_Armor_TrailEmitter_Params
{
	int                                                EntryPoint;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
