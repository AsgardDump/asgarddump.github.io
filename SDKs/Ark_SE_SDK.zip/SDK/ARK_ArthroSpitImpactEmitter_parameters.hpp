#pragma once

// ARK: Survival Evolved (358.6 (STEAM)) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "../SDK.hpp"

namespace Classes
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function ArthroSpitImpactEmitter.ArthroSpitImpactEmitter_C.UserConstructionScript
struct AArthroSpitImpactEmitter_C_UserConstructionScript_Params
{
};

// Function ArthroSpitImpactEmitter.ArthroSpitImpactEmitter_C.ExecuteUbergraph_ArthroSpitImpactEmitter
struct AArthroSpitImpactEmitter_C_ExecuteUbergraph_ArthroSpitImpactEmitter_Params
{
	int                                                EntryPoint;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
