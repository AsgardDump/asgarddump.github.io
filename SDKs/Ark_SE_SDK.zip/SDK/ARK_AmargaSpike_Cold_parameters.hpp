#pragma once

// ARK: Survival Evolved (358.6 (STEAM)) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "../SDK.hpp"

namespace Classes
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function AmargaSpike_Cold.AmargaSpike_Cold_C.UserConstructionScript
struct AAmargaSpike_Cold_C_UserConstructionScript_Params
{
};

// Function AmargaSpike_Cold.AmargaSpike_Cold_C.ExecuteUbergraph_AmargaSpike_Cold
struct AAmargaSpike_Cold_C_ExecuteUbergraph_AmargaSpike_Cold_Params
{
	int                                                EntryPoint;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
