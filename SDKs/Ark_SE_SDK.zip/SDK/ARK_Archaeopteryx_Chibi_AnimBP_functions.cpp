// ARK: Survival Evolved (358.6 (STEAM)) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "../SDK.hpp"

namespace Classes
{
//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function Archaeopteryx_Chibi_AnimBP.Archaeopteryx_Chibi_AnimBP_C.ExecuteUbergraph_Archaeopteryx_Chibi_AnimBP
// ()
// Parameters:
// int                            EntryPoint                     (Parm, ZeroConstructor, IsPlainOldData)

void UArchaeopteryx_Chibi_AnimBP_C::ExecuteUbergraph_Archaeopteryx_Chibi_AnimBP(int EntryPoint)
{
	static auto fn = UObject::FindObject<UFunction>("Function Archaeopteryx_Chibi_AnimBP.Archaeopteryx_Chibi_AnimBP_C.ExecuteUbergraph_Archaeopteryx_Chibi_AnimBP");

	UArchaeopteryx_Chibi_AnimBP_C_ExecuteUbergraph_Archaeopteryx_Chibi_AnimBP_Params params;
	params.EntryPoint = EntryPoint;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
