#pragma once

// ARK: Survival Evolved (358.6 (STEAM)) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

namespace Classes
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// AnimBlueprintGeneratedClass Ankylo_Chibi_AnimBP.Ankylo_Chibi_AnimBP_C
// 0x0000 (0x06C8 - 0x06C8)
class UAnkylo_Chibi_AnimBP_C : public UWyvern_Chibi_AnimBP_BASE_C
{
public:

	static UClass* StaticClass()
	{
		static auto ptr = UObject::FindClass("AnimBlueprintGeneratedClass Ankylo_Chibi_AnimBP.Ankylo_Chibi_AnimBP_C");
		return ptr;
	}


	void ExecuteUbergraph_Ankylo_Chibi_AnimBP(int EntryPoint);
};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
