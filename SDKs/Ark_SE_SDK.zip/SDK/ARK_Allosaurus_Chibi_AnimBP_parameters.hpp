#pragma once

// ARK: Survival Evolved (358.6 (STEAM)) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "../SDK.hpp"

namespace Classes
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function Allosaurus_Chibi_AnimBP.Allosaurus_Chibi_AnimBP_C.ExecuteUbergraph_Allosaurus_Chibi_AnimBP
struct UAllosaurus_Chibi_AnimBP_C_ExecuteUbergraph_Allosaurus_Chibi_AnimBP_Params
{
	int                                                EntryPoint;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
