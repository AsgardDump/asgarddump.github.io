#pragma once

// ARK: Survival Evolved (358.6 (STEAM)) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "../SDK.hpp"

namespace Classes
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function AmargaSpike_Hot_TrailEmitter.AmargaSpike_Hot_TrailEmitter_C.InWaterCheck
struct AAmargaSpike_Hot_TrailEmitter_C_InWaterCheck_Params
{
};

// Function AmargaSpike_Hot_TrailEmitter.AmargaSpike_Hot_TrailEmitter_C.ReceiveBeginPlay
struct AAmargaSpike_Hot_TrailEmitter_C_ReceiveBeginPlay_Params
{
};

// Function AmargaSpike_Hot_TrailEmitter.AmargaSpike_Hot_TrailEmitter_C.UserConstructionScript
struct AAmargaSpike_Hot_TrailEmitter_C_UserConstructionScript_Params
{
};

// Function AmargaSpike_Hot_TrailEmitter.AmargaSpike_Hot_TrailEmitter_C.ExecuteUbergraph_AmargaSpike_Hot_TrailEmitter
struct AAmargaSpike_Hot_TrailEmitter_C_ExecuteUbergraph_AmargaSpike_Hot_TrailEmitter_Params
{
	int                                                EntryPoint;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
