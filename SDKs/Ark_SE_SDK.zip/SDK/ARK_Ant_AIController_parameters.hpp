#pragma once

// ARK: Survival Evolved (358.6 (STEAM)) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "../SDK.hpp"

namespace Classes
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function Ant_AIController.Ant_AIController_C.UserConstructionScript
struct AAnt_AIController_C_UserConstructionScript_Params
{
};

// Function Ant_AIController.Ant_AIController_C.ExecuteUbergraph_Ant_AIController
struct AAnt_AIController_C_ExecuteUbergraph_Ant_AIController_Params
{
	int                                                EntryPoint;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
