#pragma once

// ARK: Survival Evolved (358.6 (STEAM)) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

namespace Classes
{
//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// UserDefinedStruct ArrayOfStrings.ArrayOfStrings
// 0x0010
struct FArrayOfStrings
{
	TArray<struct FString>                             StringArray_3_042E4BCC4FCFD13EE6278BB57BF57A53;           // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
