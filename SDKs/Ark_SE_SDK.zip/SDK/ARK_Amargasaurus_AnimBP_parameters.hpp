#pragma once

// ARK: Survival Evolved (358.6 (STEAM)) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "../SDK.hpp"

namespace Classes
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function Amargasaurus_AnimBP.Amargasaurus_AnimBP_C.ExecuteUbergraph_Amargasaurus_AnimBP
struct UAmargasaurus_AnimBP_C_ExecuteUbergraph_Amargasaurus_AnimBP_Params
{
	int                                                EntryPoint;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
