#pragma once

// ARK: Survival Evolved (358.6 (STEAM)) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "../SDK.hpp"

namespace Classes
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function Anklyo-Anim-Blueprint.Anklyo-Anim-Blueprint_C.ExecuteUbergraph_Anklyo-Anim-Blueprint
struct UAnklyo_Anim_Blueprint_C_ExecuteUbergraph_Anklyo_Anim_Blueprint_Params
{
	int                                                EntryPoint;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
