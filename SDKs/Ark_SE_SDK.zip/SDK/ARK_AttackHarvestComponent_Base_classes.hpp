#pragma once

// ARK: Survival Evolved (358.6 (STEAM)) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

namespace Classes
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// BlueprintGeneratedClass AttackHarvestComponent_Base.AttackHarvestComponent_Base_C
// 0x0000 (0x0250 - 0x0250)
class UAttackHarvestComponent_Base_C : public UPrimalHarvestingComponent
{
public:

	static UClass* StaticClass()
	{
		static auto ptr = UObject::FindClass("BlueprintGeneratedClass AttackHarvestComponent_Base.AttackHarvestComponent_Base_C");
		return ptr;
	}


	void ExecuteUbergraph_AttackHarvestComponent_Base(int EntryPoint);
};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
