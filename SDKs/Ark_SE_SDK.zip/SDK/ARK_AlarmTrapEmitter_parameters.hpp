#pragma once

// ARK: Survival Evolved (358.6 (STEAM)) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "../SDK.hpp"

namespace Classes
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function AlarmTrapEmitter.AlarmTrapEmitter_C.UserConstructionScript
struct AAlarmTrapEmitter_C_UserConstructionScript_Params
{
};

// Function AlarmTrapEmitter.AlarmTrapEmitter_C.ExecuteUbergraph_AlarmTrapEmitter
struct AAlarmTrapEmitter_C_ExecuteUbergraph_AlarmTrapEmitter_Params
{
	int                                                EntryPoint;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
