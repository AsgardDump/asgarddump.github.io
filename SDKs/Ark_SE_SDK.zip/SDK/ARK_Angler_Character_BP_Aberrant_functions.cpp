// ARK: Survival Evolved (358.6 (STEAM)) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "../SDK.hpp"

namespace Classes
{
//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function Angler_Character_BP_Aberrant.Angler_Character_BP_Aberrant_C.UserConstructionScript
// (Event, Public, BlueprintCallable, BlueprintEvent)

void AAngler_Character_BP_Aberrant_C::UserConstructionScript()
{
	static auto fn = UObject::FindObject<UFunction>("Function Angler_Character_BP_Aberrant.Angler_Character_BP_Aberrant_C.UserConstructionScript");

	AAngler_Character_BP_Aberrant_C_UserConstructionScript_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function Angler_Character_BP_Aberrant.Angler_Character_BP_Aberrant_C.ExecuteUbergraph_Angler_Character_BP_Aberrant
// ()
// Parameters:
// int                            EntryPoint                     (Parm, ZeroConstructor, IsPlainOldData)

void AAngler_Character_BP_Aberrant_C::ExecuteUbergraph_Angler_Character_BP_Aberrant(int EntryPoint)
{
	static auto fn = UObject::FindObject<UFunction>("Function Angler_Character_BP_Aberrant.Angler_Character_BP_Aberrant_C.ExecuteUbergraph_Angler_Character_BP_Aberrant");

	AAngler_Character_BP_Aberrant_C_ExecuteUbergraph_Angler_Character_BP_Aberrant_Params params;
	params.EntryPoint = EntryPoint;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
