#pragma once

// ARK: Survival Evolved (358.6 (STEAM)) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "../SDK.hpp"

namespace Classes
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function BaryonyxAnimBlueprint.BaryonyxAnimBlueprint_C.ExecuteUbergraph_BaryonyxAnimBlueprint
struct UBaryonyxAnimBlueprint_C_ExecuteUbergraph_BaryonyxAnimBlueprint_Params
{
	int                                                EntryPoint;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
