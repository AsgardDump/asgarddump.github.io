#pragma once

// ARK: Survival Evolved (358.6 (STEAM)) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "../SDK.hpp"

namespace Classes
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function Ant_Character_BP.Ant_Character_BP_C.UserConstructionScript
struct AAnt_Character_BP_C_UserConstructionScript_Params
{
};

// Function Ant_Character_BP.Ant_Character_BP_C.ExecuteUbergraph_Ant_Character_BP
struct AAnt_Character_BP_C_ExecuteUbergraph_Ant_Character_BP_Params
{
	int                                                EntryPoint;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
