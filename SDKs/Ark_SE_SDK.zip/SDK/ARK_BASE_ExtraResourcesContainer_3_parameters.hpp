#pragma once

// ARK: Survival Evolved (358.6 (STEAM)) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "../SDK.hpp"

namespace Classes
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function BASE_ExtraResourcesContainer_3.BASE_ExtraResourcesContainer_2_C.ExecuteUbergraph_BASE_ExtraResourcesContainer_3
struct UBASE_ExtraResourcesContainer_2_C_ExecuteUbergraph_BASE_ExtraResourcesContainer_3_Params
{
	int                                                EntryPoint;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
