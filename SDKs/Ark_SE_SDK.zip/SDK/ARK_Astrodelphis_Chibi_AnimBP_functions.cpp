// ARK: Survival Evolved (358.6 (STEAM)) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "../SDK.hpp"

namespace Classes
{
//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function Astrodelphis_Chibi_AnimBP.Astrodelphis_Chibi_AnimBP_C.ExecuteUbergraph_Astrodelphis_Chibi_AnimBP
// ()
// Parameters:
// int                            EntryPoint                     (Parm, ZeroConstructor, IsPlainOldData)

void UAstrodelphis_Chibi_AnimBP_C::ExecuteUbergraph_Astrodelphis_Chibi_AnimBP(int EntryPoint)
{
	static auto fn = UObject::FindObject<UFunction>("Function Astrodelphis_Chibi_AnimBP.Astrodelphis_Chibi_AnimBP_C.ExecuteUbergraph_Astrodelphis_Chibi_AnimBP");

	UAstrodelphis_Chibi_AnimBP_C_ExecuteUbergraph_Astrodelphis_Chibi_AnimBP_Params params;
	params.EntryPoint = EntryPoint;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
