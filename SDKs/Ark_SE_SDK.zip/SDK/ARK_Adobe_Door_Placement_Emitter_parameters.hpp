#pragma once

// ARK: Survival Evolved (358.6 (STEAM)) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "../SDK.hpp"

namespace Classes
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function Adobe_Door_Placement_Emitter.Adobe_Door_Placement_Emitter_C.UserConstructionScript
struct AAdobe_Door_Placement_Emitter_C_UserConstructionScript_Params
{
};

// Function Adobe_Door_Placement_Emitter.Adobe_Door_Placement_Emitter_C.ExecuteUbergraph_Adobe_Door_Placement_Emitter
struct AAdobe_Door_Placement_Emitter_C_ExecuteUbergraph_Adobe_Door_Placement_Emitter_Params
{
	int                                                EntryPoint;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
