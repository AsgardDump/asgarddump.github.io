#pragma once

// ARK: Survival Evolved (358.6 (STEAM)) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

namespace Classes
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// AnimBlueprintGeneratedClass Ammonite_AnimBlueprint.Ammonite_AnimBlueprint_C
// 0x0000 (0x1630 - 0x1630)
class UAmmonite_AnimBlueprint_C : public UDinoBlueprintBase_RootBoneName_C
{
public:

	static UClass* StaticClass()
	{
		static auto ptr = UObject::FindClass("AnimBlueprintGeneratedClass Ammonite_AnimBlueprint.Ammonite_AnimBlueprint_C");
		return ptr;
	}


	void ExecuteUbergraph_Ammonite_AnimBlueprint(int EntryPoint);
};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
