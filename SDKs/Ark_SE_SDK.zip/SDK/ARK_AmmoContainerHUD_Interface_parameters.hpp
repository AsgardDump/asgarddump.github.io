#pragma once

// ARK: Survival Evolved (358.6 (STEAM)) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "../SDK.hpp"

namespace Classes
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function AmmoContainerHUD_Interface.AmmoContainerHUD_Interface_C.GetAmmoContainerIcon
struct UAmmoContainerHUD_Interface_C_GetAmmoContainerIcon_Params
{
	class UTexture2D*                                  Icon;                                                     // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
};

// Function AmmoContainerHUD_Interface.AmmoContainerHUD_Interface_C.ProvidedAmmoQuantity
struct UAmmoContainerHUD_Interface_C_ProvidedAmmoQuantity_Params
{
	class APrimalStructureItemContainer*               TurretStructureItemContainer;                             // (Parm, ZeroConstructor, IsPlainOldData)
	class UClass*                                      AmmoItemTemplate;                                         // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                Quantity;                                                 // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	bool                                               AnyAmmoContainersInRange;                                 // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
