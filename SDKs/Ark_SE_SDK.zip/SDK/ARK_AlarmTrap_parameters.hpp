#pragma once

// ARK: Survival Evolved (358.6 (STEAM)) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "../SDK.hpp"

namespace Classes
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function AlarmTrap.AlarmTrap_C.UserConstructionScript
struct AAlarmTrap_C_UserConstructionScript_Params
{
};

// Function AlarmTrap.AlarmTrap_C.ExecuteUbergraph_AlarmTrap
struct AAlarmTrap_C_ExecuteUbergraph_AlarmTrap_Params
{
	int                                                EntryPoint;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
