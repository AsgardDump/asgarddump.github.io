#pragma once

// ARK: Survival Evolved (358.6 (STEAM)) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "../SDK.hpp"

namespace Classes
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function Arthro_Character_BP.Arthro_Character_BP_C.UserConstructionScript
struct AArthro_Character_BP_C_UserConstructionScript_Params
{
};

// Function Arthro_Character_BP.Arthro_Character_BP_C.ReceiveBeginPlay
struct AArthro_Character_BP_C_ReceiveBeginPlay_Params
{
};

// Function Arthro_Character_BP.Arthro_Character_BP_C.ExecuteUbergraph_Arthro_Character_BP
struct AArthro_Character_BP_C_ExecuteUbergraph_Arthro_Character_BP_Params
{
	int                                                EntryPoint;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
