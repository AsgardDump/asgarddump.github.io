#pragma once

// ARK: Survival Evolved (358.6 (STEAM)) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "../SDK.hpp"

namespace Classes
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function Base_DoubleDoor.Base_DoubleDoor_C.UserConstructionScript
struct ABase_DoubleDoor_C_UserConstructionScript_Params
{
};

// Function Base_DoubleDoor.Base_DoubleDoor_C.ExecuteUbergraph_Base_DoubleDoor
struct ABase_DoubleDoor_C_ExecuteUbergraph_Base_DoubleDoor_Params
{
	int                                                EntryPoint;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
