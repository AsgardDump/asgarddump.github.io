// ARK: Survival Evolved (358.6 (STEAM)) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "../SDK.hpp"

namespace Classes
{
//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function Achatina_AnimBlueprint.Achatina_AnimBlueprint_C.ExecuteUbergraph_Achatina_AnimBlueprint
// ()
// Parameters:
// int                            EntryPoint                     (Parm, ZeroConstructor, IsPlainOldData)

void UAchatina_AnimBlueprint_C::ExecuteUbergraph_Achatina_AnimBlueprint(int EntryPoint)
{
	static auto fn = UObject::FindObject<UFunction>("Function Achatina_AnimBlueprint.Achatina_AnimBlueprint_C.ExecuteUbergraph_Achatina_AnimBlueprint");

	UAchatina_AnimBlueprint_C_ExecuteUbergraph_Achatina_AnimBlueprint_Params params;
	params.EntryPoint = EntryPoint;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
