#pragma once

// ARK: Survival Evolved (358.6 (STEAM)) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "../SDK.hpp"

namespace Classes
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function AttackHarvestComponent_Base.AttackHarvestComponent_Base_C.ExecuteUbergraph_AttackHarvestComponent_Base
struct UAttackHarvestComponent_Base_C_ExecuteUbergraph_AttackHarvestComponent_Base_Params
{
	int                                                EntryPoint;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
