#pragma once 
#include "SDK.h" 
 
 
// ScriptStruct AnimNode_RigLogic_Module.AnimNode_RigLogic
// Size: 0xA0(Inherited: 0x10) 
struct FAnimNode_RigLogic : public FAnimNode_Base
{
	struct FPoseLink AnimSequence;  // 0x10(0x10)
	struct UDNAContext* DNAContext;  // 0x20(0x8)
	char pad_40[120];  // 0x28(0x78)

}; 
