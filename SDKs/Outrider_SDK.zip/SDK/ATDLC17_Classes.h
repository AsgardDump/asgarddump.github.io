#pragma once 
#include <ATDLC17_Structs.h>
 
 
 
// BlueprintGeneratedClass ATDLC17.ATDLC17_C
// Size: 0x28(Inherited: 0x28) 
struct UATDLC17_C : public UMadSkillDataObject
{

	float GetSecondaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function ATDLC17.ATDLC17_C.GetSecondaryExtraData
	float GetTertiaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function ATDLC17.ATDLC17_C.GetTertiaryExtraData
	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function ATDLC17.ATDLC17_C.GetPrimaryExtraData
}; 



