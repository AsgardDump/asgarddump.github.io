#pragma once 
#include <BlindFireToRun_Rules_Structs.h>
 
 
 
// BlueprintGeneratedClass BlindFireToRun_Rules.BlindFireToRun_Rules_C
// Size: 0x50(Inherited: 0x50) 
struct UBlindFireToRun_Rules_C : public UMadCameraTransitionFromTargeting
{

	bool CanTransition(); // Function BlindFireToRun_Rules.BlindFireToRun_Rules_C.CanTransition
}; 



