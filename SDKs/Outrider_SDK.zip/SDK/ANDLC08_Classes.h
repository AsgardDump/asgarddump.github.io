#pragma once 
#include <ANDLC08_Structs.h>
 
 
 
// BlueprintGeneratedClass ANDLC08.ANDLC08_C
// Size: 0x28(Inherited: 0x28) 
struct UANDLC08_C : public UMadSkillDataObject
{

	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function ANDLC08.ANDLC08_C.GetPrimaryExtraData
}; 



