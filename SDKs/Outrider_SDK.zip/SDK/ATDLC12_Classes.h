#pragma once 
#include <ATDLC12_Structs.h>
 
 
 
// BlueprintGeneratedClass ATDLC12.ATDLC12_C
// Size: 0x28(Inherited: 0x28) 
struct UATDLC12_C : public UMadSkillDataObject
{

	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function ATDLC12.ATDLC12_C.GetPrimaryExtraData
}; 



