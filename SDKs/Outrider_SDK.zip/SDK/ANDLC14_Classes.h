#pragma once 
#include <ANDLC14_Structs.h>
 
 
 
// BlueprintGeneratedClass ANDLC14.ANDLC14_C
// Size: 0x28(Inherited: 0x28) 
struct UANDLC14_C : public UMadSkillDataObject
{

	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function ANDLC14.ANDLC14_C.GetPrimaryExtraData
}; 



