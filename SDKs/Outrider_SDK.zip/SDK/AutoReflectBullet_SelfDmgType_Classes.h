#pragma once 
#include <AutoReflectBullet_SelfDmgType_Structs.h>
 
 
 
// BlueprintGeneratedClass AutoReflectBullet_SelfDmgType.AutoReflectBullet_SelfDmgType_C
// Size: 0x2C8(Inherited: 0x2C8) 
struct UAutoReflectBullet_SelfDmgType_C : public UMadDamageType
{

}; 



