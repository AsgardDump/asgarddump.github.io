#pragma once 
#include <BP_Abilities_RpgExplosion_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Abilities_RpgExplosion.BP_Abilities_RpgExplosion_C
// Size: 0x470(Inherited: 0x470) 
struct ABP_Abilities_RpgExplosion_C : public AExplosionEffect
{

}; 



