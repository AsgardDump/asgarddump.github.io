#pragma once 
#include <AssaultRifleFOVCameraShake_Structs.h>
 
 
 
// BlueprintGeneratedClass AssaultRifleFOVCameraShake.AssaultRifleFOVCameraShake_C
// Size: 0x160(Inherited: 0x160) 
struct UAssaultRifleFOVCameraShake_C : public UCameraShake
{

}; 



