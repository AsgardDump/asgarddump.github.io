#pragma once 
#include "SDK.h" 
 
 
// Function BlindFireToTargeting_Rules.BlindFireToTargeting_Rules_C.CanTransition
// Size: 0x33(Inherited: 0x1) 
struct FCanTransition : public FCanTransition
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)
	char pad_2[6];  // 0x2(0x6)
	struct TScriptInterface<IWeaponInterface> CallFunc_IsTargeting_self_CastInput;  // 0x8(0x10)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_IsTargeting_ReturnValue : 1;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x19(0x1)
	char pad_26[6];  // 0x1A(0x6)
	struct TScriptInterface<IWeaponInterface> CallFunc_GetFiringState_self_CastInput;  // 0x20(0x10)
	uint8_t  CallFunc_GetFiringState_ReturnValue;  // 0x30(0x1)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // 0x31(0x1)
	char pad_50_1 : 7;  // 0x32(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x32(0x1)

}; 
