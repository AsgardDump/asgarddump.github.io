#pragma once 
#include <AT25_Structs.h>
 
 
 
// BlueprintGeneratedClass AT25.AT25_C
// Size: 0x28(Inherited: 0x28) 
struct UAT25_C : public UMadSkillDataObject
{

	float GetSecondaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function AT25.AT25_C.GetSecondaryExtraData
	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function AT25.AT25_C.GetPrimaryExtraData
}; 



