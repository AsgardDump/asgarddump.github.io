#pragma once 
#include <ANDLC05_Structs.h>
 
 
 
// BlueprintGeneratedClass ANDLC05.ANDLC05_C
// Size: 0x28(Inherited: 0x28) 
struct UANDLC05_C : public UMadSkillDataObject
{

	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function ANDLC05.ANDLC05_C.GetPrimaryExtraData
}; 



