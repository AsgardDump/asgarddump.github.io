#pragma once 
#include <AS44_Structs.h>
 
 
 
// BlueprintGeneratedClass AS44.AS44_C
// Size: 0x28(Inherited: 0x28) 
struct UAS44_C : public UMadSkillDataObject
{

	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function AS44.AS44_C.GetPrimaryExtraData
}; 



