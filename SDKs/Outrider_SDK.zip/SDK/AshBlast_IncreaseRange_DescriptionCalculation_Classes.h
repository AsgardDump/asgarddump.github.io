#pragma once 
#include <AshBlast_IncreaseRange_DescriptionCalculation_Structs.h>
 
 
 
// BlueprintGeneratedClass AshBlast_IncreaseRange_DescriptionCalculation.AshBlast_IncreaseRange_DescriptionCalculation_C
// Size: 0x28(Inherited: 0x28) 
struct UAshBlast_IncreaseRange_DescriptionCalculation_C : public UMadSkillDataObject
{

	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function AshBlast_IncreaseRange_DescriptionCalculation.AshBlast_IncreaseRange_DescriptionCalculation_C.GetPrimaryExtraData
}; 



