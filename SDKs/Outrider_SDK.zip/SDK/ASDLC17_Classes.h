#pragma once 
#include <ASDLC17_Structs.h>
 
 
 
// BlueprintGeneratedClass ASDLC17.ASDLC17_C
// Size: 0x28(Inherited: 0x28) 
struct UASDLC17_C : public UMadSkillDataObject
{

	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function ASDLC17.ASDLC17_C.GetPrimaryExtraData
}; 



