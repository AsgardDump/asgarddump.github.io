#pragma once 
#include <BP_BoltAction_Boss3Prototype_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_BoltAction_Boss3Prototype.BP_BoltAction_Boss3Prototype_C
// Size: 0x1F90(Inherited: 0x1F90) 
struct ABP_BoltAction_Boss3Prototype_C : public AMadRifle
{

}; 



