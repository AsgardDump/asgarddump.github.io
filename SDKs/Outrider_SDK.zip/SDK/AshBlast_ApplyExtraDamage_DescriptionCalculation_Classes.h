#pragma once 
#include <AshBlast_ApplyExtraDamage_DescriptionCalculation_Structs.h>
 
 
 
// BlueprintGeneratedClass AshBlast_ApplyExtraDamage_DescriptionCalculation.AshBlast_ApplyExtraDamage_DescriptionCalculation_C
// Size: 0x28(Inherited: 0x28) 
struct UAshBlast_ApplyExtraDamage_DescriptionCalculation_C : public UMadSkillDataObject
{

	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function AshBlast_ApplyExtraDamage_DescriptionCalculation.AshBlast_ApplyExtraDamage_DescriptionCalculation_C.GetPrimaryExtraData
}; 



