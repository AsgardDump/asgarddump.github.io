#pragma once 
#include <AN03_Structs.h>
 
 
 
// BlueprintGeneratedClass AN03.AN03_C
// Size: 0x28(Inherited: 0x28) 
struct UAN03_C : public UMadSkillDataObject
{

	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function AN03.AN03_C.GetPrimaryExtraData
}; 



