#pragma once 
#include <AnomalyBuffOnKill_DescriptionCalculation_Structs.h>
 
 
 
// BlueprintGeneratedClass AnomalyBuffOnKill_DescriptionCalculation.AnomalyBuffOnKill_DescriptionCalculation_C
// Size: 0x28(Inherited: 0x28) 
struct UAnomalyBuffOnKill_DescriptionCalculation_C : public UMadSkillDataObject
{

	float GetSecondaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function AnomalyBuffOnKill_DescriptionCalculation.AnomalyBuffOnKill_DescriptionCalculation_C.GetSecondaryExtraData
	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function AnomalyBuffOnKill_DescriptionCalculation.AnomalyBuffOnKill_DescriptionCalculation_C.GetPrimaryExtraData
}; 



