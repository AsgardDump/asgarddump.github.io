#pragma once 
#include <BP_BoltAction_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_BoltAction.BP_BoltAction_C
// Size: 0x1F90(Inherited: 0x1F90) 
struct ABP_BoltAction_C : public AMadRifle
{

}; 



