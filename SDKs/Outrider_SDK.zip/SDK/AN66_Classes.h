#pragma once 
#include <AN66_Structs.h>
 
 
 
// BlueprintGeneratedClass AN66.AN66_C
// Size: 0x28(Inherited: 0x28) 
struct UAN66_C : public UMadSkillDataObject
{

	float GetSecondaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function AN66.AN66_C.GetSecondaryExtraData
	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function AN66.AN66_C.GetPrimaryExtraData
}; 



