#pragma once 
#include <BP_Enemy_PumpAction_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Enemy_PumpAction.BP_Enemy_PumpAction_C
// Size: 0x2000(Inherited: 0x2000) 
struct ABP_Enemy_PumpAction_C : public AMadShotgun
{

}; 



