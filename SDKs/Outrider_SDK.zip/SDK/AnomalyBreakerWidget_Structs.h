#pragma once 
#include "SDK.h" 
 
 
// Function AnomalyBreakerWidget.AnomalyBreakerWidget_C.ExecuteUbergraph_AnomalyBreakerWidget
// Size: 0x20(Inherited: 0x0) 
struct FExecuteUbergraph_AnomalyBreakerWidget
{
	int32_t EntryPoint;  // 0x0(0x4)
	uint8_t  K2Node_Event_InAnomalyBreakerVisState;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	float K2Node_Event_InProgress;  // 0x8(0x4)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)
	struct UMaterialInstanceDynamic* CallFunc_GetDynamicMaterial_ReturnValue;  // 0x10(0x8)
	struct UUMGSequencePlayer* CallFunc_PlayAnimation_ReturnValue;  // 0x18(0x8)

}; 
// Function AnomalyBreakerWidget.AnomalyBreakerWidget_C.SetAnomalyBreakerVisState
// Size: 0x1(Inherited: 0x1) 
struct FSetAnomalyBreakerVisState : public FSetAnomalyBreakerVisState
{
	uint8_t  InAnomalyBreakerVisState;  // 0x0(0x1)

}; 
// Function AnomalyBreakerWidget.AnomalyBreakerWidget_C.SetEnragedDurationProgress
// Size: 0x4(Inherited: 0x4) 
struct FSetEnragedDurationProgress : public FSetEnragedDurationProgress
{
	float InProgress;  // 0x0(0x4)

}; 
