#pragma once 
#include <BlindFireToIdle_Rules_Structs.h>
 
 
 
// BlueprintGeneratedClass BlindFireToIdle_Rules.BlindFireToIdle_Rules_C
// Size: 0x50(Inherited: 0x50) 
struct UBlindFireToIdle_Rules_C : public UMadCameraTransitionFromTargeting
{

	bool CanTransition(); // Function BlindFireToIdle_Rules.BlindFireToIdle_Rules_C.CanTransition
}; 



