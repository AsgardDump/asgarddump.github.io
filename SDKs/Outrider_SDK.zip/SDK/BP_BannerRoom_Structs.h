#pragma once 
#include "SDK.h" 
 
 
// Function BP_BannerRoom.BP_BannerRoom_C.ExecuteUbergraph_BP_BannerRoom
// Size: 0x38(Inherited: 0x0) 
struct FExecuteUbergraph_BP_BannerRoom
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AMadPlayerCharacter* CallFunc_GetRoomOwner_ReturnValue;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct AController* CallFunc_GetController_ReturnValue;  // 0x18(0x8)
	struct AMadPlayerController* K2Node_DynamicCast_AsMad_Player_Controller;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct UCameraComponent* K2Node_CustomEvent_Camera;  // 0x30(0x8)

}; 
// Function BP_BannerRoom.BP_BannerRoom_C.OnLeaveTheRoom
// Size: 0x1(Inherited: 0x1) 
struct FOnLeaveTheRoom : public FOnLeaveTheRoom
{
	uint8_t  NewMode;  // 0x0(0x1)

}; 
// Function BP_BannerRoom.BP_BannerRoom_C.ChangeCamera
// Size: 0x8(Inherited: 0x0) 
struct FChangeCamera
{
	struct UCameraComponent* Camera;  // 0x0(0x8)

}; 
// Function BP_BannerRoom.BP_BannerRoom_C.OnModeChanged
// Size: 0x1(Inherited: 0x1) 
struct FOnModeChanged : public FOnModeChanged
{
	uint8_t  NewMode;  // 0x0(0x1)

}; 
