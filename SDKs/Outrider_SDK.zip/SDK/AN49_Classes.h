#pragma once 
#include <AN49_Structs.h>
 
 
 
// BlueprintGeneratedClass AN49.AN49_C
// Size: 0x28(Inherited: 0x28) 
struct UAN49_C : public UMadSkillDataObject
{

	float GetSecondaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function AN49.AN49_C.GetSecondaryExtraData
	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function AN49.AN49_C.GetPrimaryExtraData
}; 



