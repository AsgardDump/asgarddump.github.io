#pragma once 
#include <AssassinLessDmgElits_Structs.h>
 
 
 
// BlueprintGeneratedClass AssassinLessDmgElits.AssassinLessDmgElits_C
// Size: 0x28(Inherited: 0x28) 
struct UAssassinLessDmgElits_C : public UMadSkillDataObject
{

	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function AssassinLessDmgElits.AssassinLessDmgElits_C.GetPrimaryExtraData
}; 



