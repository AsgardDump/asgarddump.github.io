#pragma once 
#include "SDK.h" 
 
 
// Function AIFramework.FWAIComponent.K2_MulticastSpawnParticleAtLocation
// Size: 0x50(Inherited: 0x0) 
struct FK2_MulticastSpawnParticleAtLocation
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct UParticleSystem* EmitterTemplate;  // 0x8(0x8)
	struct FTransform SpawnTransform;  // 0x10(0x30)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool bAutoDestroy : 1;  // 0x40(0x1)
	uint8_t  PoolingMethod;  // 0x41(0x1)
	char pad_66[14];  // 0x42(0xE)

}; 
// Function AIFramework.FWAIController.GetAIComponent
// Size: 0x8(Inherited: 0x0) 
struct FGetAIComponent
{
	struct UFWAIComponent* ReturnValue;  // 0x0(0x8)

}; 
// DelegateFunction AIFramework.OnFollowerDiedDelegate__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FOnFollowerDiedDelegate__DelegateSignature
{
	struct AFWAIController* AI;  // 0x0(0x8)

}; 
// Function AIFramework.FWEncounterManager.StartEncounter
// Size: 0x28(Inherited: 0x0) 
struct FStartEncounter
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct AActor* InstigatorActor;  // 0x8(0x8)
	struct FName InEncounterName;  // 0x10(0x8)
	struct AFWEncounterManager* Encounter;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool bDontStartIfCompleted : 1;  // 0x20(0x1)
	char pad_33_1 : 7;  // 0x21(0x1)
	bool ReturnValue : 1;  // 0x21(0x1)
	char pad_34[6];  // 0x22(0x6)

}; 
// Function AIFramework.CharacterSpawner.EnableSpawnGroup
// Size: 0x8(Inherited: 0x0) 
struct FEnableSpawnGroup
{
	int32_t GroupIndex;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool bResetCounters : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)

}; 
// Function AIFramework.FWAIController.DiscreteDistanceToLenght
// Size: 0x8(Inherited: 0x0) 
struct FDiscreteDistanceToLenght
{
	uint8_t  Distance;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	float ReturnValue;  // 0x4(0x4)

}; 
// Function AIFramework.FWAIController.ClearBehaviorTag
// Size: 0x1(Inherited: 0x0) 
struct FClearBehaviorTag
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function AIFramework.FWAIController.GetSmartObjectUserState
// Size: 0x8(Inherited: 0x0) 
struct FGetSmartObjectUserState
{
	struct USmartObjectUserState* ReturnValue;  // 0x0(0x8)

}; 
// Function AIFramework.FWAISquad.IsAnySquadMemberInRange
// Size: 0x20(Inherited: 0x0) 
struct FIsAnySquadMemberInRange
{
	struct AController* MemberToExclude;  // 0x0(0x8)
	struct FVector Origin;  // 0x8(0xC)
	float MinRadius;  // 0x14(0x4)
	float MaxRadius;  // 0x18(0x4)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool ReturnValue : 1;  // 0x1C(0x1)
	char pad_29[3];  // 0x1D(0x3)

}; 
// Function AIFramework.FWAIComponent.SetDesiredRotation
// Size: 0xC(Inherited: 0x0) 
struct FSetDesiredRotation
{
	struct FRotator InDesiredRotation;  // 0x0(0xC)

}; 
// DelegateFunction AIFramework.WssWaveEndSpawningDelegate__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FWssWaveEndSpawningDelegate__DelegateSignature
{
	struct AFWWaveSpawningSystem* Wss;  // 0x0(0x8)
	int32_t WaveIndex;  // 0x8(0x4)
	struct FName WaveName;  // 0xC(0x8)
	char pad_20[4];  // 0x14(0x4)

}; 
// Function AIFramework.FWAIController.GetLastHitResult
// Size: 0x90(Inherited: 0x0) 
struct FGetLastHitResult
{
	struct FHitResult ReturnValue;  // 0x0(0x90)

}; 
// DelegateFunction AIFramework.OnSmartObjectFinished__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FOnSmartObjectFinished__DelegateSignature
{
	struct USmartObjectSlotComponent* Slot;  // 0x0(0x8)

}; 
// Function AIFramework.FWCoveringComponent.GetCoverInfo
// Size: 0x20(Inherited: 0x0) 
struct FGetCoverInfo
{
	uint8_t  CoverMember;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FCoverSlotInfo ReturnValue;  // 0x8(0x18)

}; 
// Function AIFramework.FWAISquad.GetNumberOfSquadMembers
// Size: 0x4(Inherited: 0x0) 
struct FGetNumberOfSquadMembers
{
	int32_t ReturnValue;  // 0x0(0x4)

}; 
// ScriptStruct AIFramework.FWEncounterWaveData
// Size: 0xA8(Inherited: 0x0) 
struct FFWEncounterWaveData
{
	struct FText Description;  // 0x0(0x18)
	struct FFWEncounterSpawnGroupSetup SpawnGroupInfo;  // 0x18(0x20)
	float WarmupTime;  // 0x38(0x4)
	float MinDelayTimePerSpawn;  // 0x3C(0x4)
	float MaxDelayTimePerSpawn;  // 0x40(0x4)
	float WaveTime;  // 0x44(0x4)
	int32_t SpawnQuantityPerInterval;  // 0x48(0x4)
	float SpawnInterval;  // 0x4C(0x4)
	float RadiusAroundInstigator;  // 0x50(0x4)
	int32_t SpawnsPerWave;  // 0x54(0x4)
	int32_t MaxCharactersAlivePerWave;  // 0x58(0x4)
	int32_t NumCharactersKilledToNotify;  // 0x5C(0x4)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool bUseTotal : 1;  // 0x60(0x1)
	char pad_97[7];  // 0x61(0x7)
	struct TArray<struct ACombatArena*> Arenas;  // 0x68(0x10)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool bDontSpawnWhenVisible : 1;  // 0x78(0x1)
	char pad_121[7];  // 0x79(0x7)
	struct FFWEncounterWaveDifficultyDescriptor GameDifficultyDescriptor;  // 0x80(0x28)

}; 
// DelegateFunction AIFramework.WssBeginCombat__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FWssBeginCombat__DelegateSignature
{
	struct AFWWaveSpawningSystem* Wss;  // 0x0(0x8)

}; 
// Function AIFramework.FWAIController.OnEnemyDeath
// Size: 0x8(Inherited: 0x0) 
struct FOnEnemyDeath
{
	struct ABaseCharacter* EnemyCharacter;  // 0x0(0x8)

}; 
// Function AIFramework.FWAIController.GetSquadLeader
// Size: 0x8(Inherited: 0x0) 
struct FGetSquadLeader
{
	struct AController* ReturnValue;  // 0x0(0x8)

}; 
// Function AIFramework.FWAIComponent.GetFocalPoint
// Size: 0xC(Inherited: 0x0) 
struct FGetFocalPoint
{
	struct FVector ReturnValue;  // 0x0(0xC)

}; 
// DelegateFunction AIFramework.OnGoalBehaviourChangedDelegate__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FOnGoalBehaviourChangedDelegate__DelegateSignature
{
	struct AFWAIController* OwnerController;  // 0x0(0x8)

}; 
// DelegateFunction AIFramework.AnimNotifyDelegate__DelegateSignature
// Size: 0x28(Inherited: 0x0) 
struct FAnimNotifyDelegate__DelegateSignature
{
	uint8_t  NotifyType;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool bUseSharedSpace : 1;  // 0x1(0x1)
	uint8_t  AttachPoint;  // 0x2(0x1)
	char pad_3[1];  // 0x3(0x1)
	struct FName NotifyName;  // 0x4(0x8)
	char pad_12[4];  // 0xC(0x4)
	struct USkeletalMeshComponent* MeshComp;  // 0x10(0x8)
	struct UAnimSequenceBase* Animation;  // 0x18(0x8)
	uint8_t  LocationRule;  // 0x20(0x1)
	uint8_t  RotationRule;  // 0x21(0x1)
	char pad_34[6];  // 0x22(0x6)

}; 
// Function AIFramework.FWAIController.AllowTurnInPlace
// Size: 0x1(Inherited: 0x0) 
struct FAllowTurnInPlace
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Allow : 1;  // 0x0(0x1)

}; 
// Function AIFramework.FWAIController.OnWaponHit
// Size: 0xA8(Inherited: 0x0) 
struct FOnWaponHit
{
	struct AActor* InstigatorActor;  // 0x0(0x8)
	struct FHitResult HitInfo;  // 0x8(0x90)
	UDamageType* DamageType;  // 0x98(0x8)
	float Damage;  // 0xA0(0x4)
	char pad_164[4];  // 0xA4(0x4)

}; 
// Function AIFramework.GoalPoint.WillAcceptMoreAI
// Size: 0x10(Inherited: 0x0) 
struct FWillAcceptMoreAI
{
	struct AAIController* AI;  // 0x0(0x8)
	char EAIForceParam bForce;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool ReturnValue : 1;  // 0x9(0x1)
	char pad_10[6];  // 0xA(0x6)

}; 
// Function AIFramework.FWAIController.GetAIMetrics
// Size: 0x8(Inherited: 0x0) 
struct FGetAIMetrics
{
	struct UFWAIMetrics* ReturnValue;  // 0x0(0x8)

}; 
// Function AIFramework.FWAIController.IsLocationOutsideRecoverArea
// Size: 0x10(Inherited: 0x0) 
struct FIsLocationOutsideRecoverArea
{
	struct FVector TestLocation;  // 0x0(0xC)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool ReturnValue : 1;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)

}; 
// Function AIFramework.FWAIController.BeginMeleeAttack
// Size: 0x50(Inherited: 0x0) 
struct FBeginMeleeAttack
{
	struct FString SocketNames;  // 0x0(0x10)
	struct USkeletalMeshComponent* MeshComp;  // 0x10(0x8)
	struct UAnimSequenceBase* Animation;  // 0x18(0x8)
	float TotalDuration;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)
	struct TArray<struct FVector> SensorLocations;  // 0x28(0x10)
	UDamageType* DamageTypeClass;  // 0x38(0x8)
	struct FName TagName;  // 0x40(0x8)
	struct UFWAnimNotifyState_MeleeAttack* AnimNotify;  // 0x48(0x8)

}; 
// Function AIFramework.FWAIController.EndMeleeAttack
// Size: 0x38(Inherited: 0x0) 
struct FEndMeleeAttack
{
	struct FString SocketNames;  // 0x0(0x10)
	struct USkeletalMeshComponent* MeshComp;  // 0x10(0x8)
	struct UAnimSequenceBase* Animation;  // 0x18(0x8)
	UDamageType* DamageTypeClass;  // 0x20(0x8)
	struct FName TagName;  // 0x28(0x8)
	struct UFWAnimNotifyState_MeleeAttack* AnimNotify;  // 0x30(0x8)

}; 
// Function AIFramework.FWAIController.SetBehaviorTag
// Size: 0x2(Inherited: 0x0) 
struct FSetBehaviorTag
{
	uint8_t  Tag;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool ReturnValue : 1;  // 0x1(0x1)

}; 
// Function AIFramework.FWBlueprintLibrary.K2_GetCharacterLocationAndRotationAfterMontage
// Size: 0x48(Inherited: 0x0) 
struct FK2_GetCharacterLocationAndRotationAfterMontage
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct Acharacter* character;  // 0x8(0x8)
	struct FMontageAssetSelector MontageAsset;  // 0x10(0x20)
	struct FVector OutLocation;  // 0x30(0xC)
	struct FRotator OutRotation;  // 0x3C(0xC)

}; 
// Function AIFramework.FWAIController.FollowGoal
// Size: 0x8(Inherited: 0x0) 
struct FFollowGoal
{
	struct AGoalPoint* Goal;  // 0x0(0x8)

}; 
// Function AIFramework.SmartObjectSlotComponent.SetEnabled
// Size: 0x1(Inherited: 0x0) 
struct FSetEnabled
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bSet : 1;  // 0x0(0x1)

}; 
// Function AIFramework.FWAIResponseComponent.GetAIOwner
// Size: 0x8(Inherited: 0x0) 
struct FGetAIOwner
{
	struct AFWAIController* ReturnValue;  // 0x0(0x8)

}; 
// Function AIFramework.FWAIController.OnStartedBeingTargetBy
// Size: 0x8(Inherited: 0x0) 
struct FOnStartedBeingTargetBy
{
	struct AActor* TargetInstigator;  // 0x0(0x8)

}; 
// Function AIFramework.FWAIPerceptionComponent.EnablePerceptionChannel
// Size: 0x10(Inherited: 0x0) 
struct FEnablePerceptionChannel
{
	UAISense* Sense;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bEnable : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function AIFramework.AISpawnSubsystem.RequestSpawnInRadius
// Size: 0x30(Inherited: 0x0) 
struct FRequestSpawnInRadius
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct FVector Origin;  // 0x8(0xC)
	float Radius;  // 0x14(0x4)
	struct TArray<ABaseCharacter*> CharactersWhitelist;  // 0x18(0x10)
	int32_t MaxSpawnsPerWave;  // 0x28(0x4)
	char pad_44_1 : 7;  // 0x2C(0x1)
	bool ReturnValue : 1;  // 0x2C(0x1)
	char pad_45[3];  // 0x2D(0x3)

}; 
// Function AIFramework.FWAIController.FollowGoals
// Size: 0x10(Inherited: 0x0) 
struct FFollowGoals
{
	struct TArray<struct AGoalPoint*> Goals;  // 0x0(0x10)

}; 
// ScriptStruct AIFramework.AISpawnGroup
// Size: 0x260(Inherited: 0x0) 
struct FAISpawnGroup
{
	int32_t SpawnGroupSeed;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct TSoftClassPtr<UObject> CharacterClassPtr;  // 0x8(0x28)
	struct FFWAIArchetypeVariation ArchetypeVariation;  // 0x30(0x20)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool bIsEnabled : 1;  // 0x50(0x1)
	char pad_81[3];  // 0x51(0x3)
	int32_t Weight;  // 0x54(0x4)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool bRespawnOnDeath : 1;  // 0x58(0x1)
	char pad_89[3];  // 0x59(0x3)
	int32_t NumberOfAllSpawns;  // 0x5C(0x4)
	int32_t MaxAlive;  // 0x60(0x4)
	float InitialSpawnDelay;  // 0x64(0x4)
	float SpawnDelayInSeconds;  // 0x68(0x4)
	char ETeam TeamToSet;  // 0x6C(0x1)
	char pad_109[3];  // 0x6D(0x3)
	struct UBehaviorTree* CustomBehaviorTree;  // 0x70(0x8)
	struct TArray<struct FNameWrapper> CustomLoadoutClasses;  // 0x78(0x10)
	float DefaultHealth;  // 0x88(0x4)
	char pad_140_1 : 7;  // 0x8C(0x1)
	bool PlayPreviewAnimation : 1;  // 0x8C(0x1)
	char pad_141_1 : 7;  // 0x8D(0x1)
	bool PlayPreviewAnimationWithoutSelection : 1;  // 0x8D(0x1)
	char pad_142[2];  // 0x8E(0x2)
	int32_t PreviewAnimationFrame;  // 0x90(0x4)
	char pad_148_1 : 7;  // 0x94(0x1)
	bool bSnapToGround : 1;  // 0x94(0x1)
	char pad_149_1 : 7;  // 0x95(0x1)
	bool bDisableCollision : 1;  // 0x95(0x1)
	char pad_150_1 : 7;  // 0x96(0x1)
	bool bWaitForCustomization : 1;  // 0x96(0x1)
	char pad_151_1 : 7;  // 0x97(0x1)
	bool bNPCReactionsEnabled : 1;  // 0x97(0x1)
	char pad_152_1 : 7;  // 0x98(0x1)
	bool bNotifyAboutEndOfAnimation : 1;  // 0x98(0x1)
	char pad_153[7];  // 0x99(0x7)
	struct FMontageAssetSelector Montage;  // 0xA0(0x20)
	struct AActor* SpawnLocation;  // 0xC0(0x8)
	struct FName SquadName;  // 0xC8(0x8)
	struct TArray<struct FAntFarmControlAttributeDelta> AntFarmInitialState;  // 0xD0(0x10)
	char pad_224_1 : 7;  // 0xE0(0x1)
	bool bSpawnUsingSmartObject : 1;  // 0xE0(0x1)
	char pad_225[7];  // 0xE1(0x7)
	struct AAntFarmGoal* DefaultAntFarm;  // 0xE8(0x8)
	char pad_240_1 : 7;  // 0xF0(0x1)
	bool bTeleportToSmartObject : 1;  // 0xF0(0x1)
	char pad_241[7];  // 0xF1(0x7)
	struct TArray<struct AGoalPoint*> GoalsToAssign;  // 0xF8(0x10)
	char pad_264_1 : 7;  // 0x108(0x1)
	bool bSpawnWithWeaponFromStart : 1;  // 0x108(0x1)
	char pad_265_1 : 7;  // 0x109(0x1)
	bool bAutoAcquireEnemy : 1;  // 0x109(0x1)
	char pad_266[6];  // 0x10A(0x6)
	struct FTransform SpawnCheckPoint;  // 0x110(0x30)
	struct FRotator SkelMeshRotationOffset;  // 0x140(0xC)
	struct FVector SkelMeshTranslationOffset;  // 0x14C(0xC)
	struct FVector SkelMeshScale3D;  // 0x158(0xC)
	char pad_356[12];  // 0x164(0xC)
	struct FTransform AnimTransformation;  // 0x170(0x30)
	int32_t SpawnRequests;  // 0x1A0(0x4)
	int32_t SpawnsCounter;  // 0x1A4(0x4)
	char pad_424[112];  // 0x1A8(0x70)
	struct TArray<struct ABaseCharacter*> CharactersArray;  // 0x218(0x10)
	char pad_552[24];  // 0x228(0x18)
	float VODistance;  // 0x240(0x4)
	char pad_580_1 : 7;  // 0x244(0x1)
	bool bVOIsMale : 1;  // 0x244(0x1)
	char pad_581_1 : 7;  // 0x245(0x1)
	bool bVOIsCivilian : 1;  // 0x245(0x1)
	char pad_582_1 : 7;  // 0x246(0x1)
	bool bVOIsCivilianGroup : 1;  // 0x246(0x1)
	char pad_583[1];  // 0x247(0x1)
	struct FName VOAntfarmTag;  // 0x248(0x8)
	char pad_592_1 : 7;  // 0x250(0x1)
	bool bStartEnabled : 1;  // 0x250(0x1)
	char pad_593[15];  // 0x251(0xF)

}; 
// Function AIFramework.FWAIController.FollowRoute
// Size: 0x10(Inherited: 0x0) 
struct FFollowRoute
{
	struct AAIRoute* InScriptedRoute;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function AIFramework.FWWaveSpawningSystem.GetEnemiesKilled
// Size: 0x8(Inherited: 0x0) 
struct FGetEnemiesKilled
{
	int32_t WaveIndex;  // 0x0(0x4)
	int32_t ReturnValue;  // 0x4(0x4)

}; 
// DelegateFunction AIFramework.FWAIController.FWAIAnimNotifyDelegate__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FFWAIAnimNotifyDelegate__DelegateSignature
{
	struct UFWAnimNotify* AnimNotify;  // 0x0(0x8)
	struct FName NotifyName;  // 0x8(0x8)
	struct USkeletalMeshComponent* MeshComp;  // 0x10(0x8)
	struct UAnimSequenceBase* Animation;  // 0x18(0x8)

}; 
// Function AIFramework.FWAIWeaponComponent.SetProjectileClass
// Size: 0x8(Inherited: 0x0) 
struct FSetProjectileClass
{
	AProjectile* ProjectileClass;  // 0x0(0x8)

}; 
// Function AIFramework.FWWaveSpawningSystem.GetNumberOfWavesAlive
// Size: 0x4(Inherited: 0x0) 
struct FGetNumberOfWavesAlive
{
	int32_t ReturnValue;  // 0x0(0x4)

}; 
// Function AIFramework.FWAIController.GetAIArchetype
// Size: 0x8(Inherited: 0x0) 
struct FGetAIArchetype
{
	UFWAIArchetype* ReturnValue;  // 0x0(0x8)

}; 
// Function AIFramework.FWAIController.GetAIFaction
// Size: 0x8(Inherited: 0x0) 
struct FGetAIFaction
{
	UFWAIFaction* ReturnValue;  // 0x0(0x8)

}; 
// Function AIFramework.FWAIController.GetAIRank
// Size: 0x8(Inherited: 0x0) 
struct FGetAIRank
{
	UFWAIRank* ReturnValue;  // 0x0(0x8)

}; 
// Function AIFramework.FWEncounterData.GetWaveDescription
// Size: 0x20(Inherited: 0x0) 
struct FGetWaveDescription
{
	int32_t Idx;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FText ReturnValue;  // 0x8(0x18)

}; 
// Function AIFramework.FWAIController.GetAnimReplication
// Size: 0x8(Inherited: 0x0) 
struct FGetAnimReplication
{
	struct UPCFAnimReplication* ReturnValue;  // 0x0(0x8)

}; 
// Function AIFramework.FWAIController.GetBaseCharacter
// Size: 0x8(Inherited: 0x0) 
struct FGetBaseCharacter
{
	struct ABaseCharacter* ReturnValue;  // 0x0(0x8)

}; 
// Function AIFramework.FWAIWeaponComponent.GetWeapon
// Size: 0x10(Inherited: 0x0) 
struct FGetWeapon
{
	uint8_t  Slot;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct AWeapon* ReturnValue;  // 0x8(0x8)

}; 
// Function AIFramework.BaseCharacterMovementComponent.SetAvoidanceWeight
// Size: 0x4(Inherited: 0x0) 
struct FSetAvoidanceWeight
{
	float Weight;  // 0x0(0x4)

}; 
// ScriptStruct AIFramework.LoadedCharacterData
// Size: 0x18(Inherited: 0x0) 
struct FLoadedCharacterData
{
	UObject* CharacterClass;  // 0x0(0x8)
	struct TArray<struct FCharacterSkeletalMeshReplicationData> Presets;  // 0x8(0x10)

}; 
// Function AIFramework.FWAIController.GetBehaviorTag
// Size: 0x1(Inherited: 0x0) 
struct FGetBehaviorTag
{
	uint8_t  ReturnValue;  // 0x0(0x1)

}; 
// Function AIFramework.CharacterSpawner.DisableSpawnGroup
// Size: 0x4(Inherited: 0x0) 
struct FDisableSpawnGroup
{
	int32_t GroupIndex;  // 0x0(0x4)

}; 
// ScriptStruct AIFramework.FWDestinationOffsetInfo
// Size: 0x20(Inherited: 0x0) 
struct FFWDestinationOffsetInfo
{
	char pad_0[16];  // 0x0(0x10)
	struct AFWAIController* OffsetClaimedBy;  // 0x10(0x8)
	char pad_24[8];  // 0x18(0x8)

}; 
// Function AIFramework.FWAIController.OnEnemyHealthBelowZero
// Size: 0x8(Inherited: 0x0) 
struct FOnEnemyHealthBelowZero
{
	struct ABaseCharacter* ControllerOwner;  // 0x0(0x8)

}; 
// Function AIFramework.SmartObjectSlotComponent.OnNotifyBeginReceived
// Size: 0x28(Inherited: 0x0) 
struct FOnNotifyBeginReceived
{
	uint8_t  NotifyType;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool bUseSharedSpace : 1;  // 0x1(0x1)
	uint8_t  AttachPoint;  // 0x2(0x1)
	char pad_3[1];  // 0x3(0x1)
	struct FName NotifyName;  // 0x4(0x8)
	char pad_12[4];  // 0xC(0x4)
	struct USkeletalMeshComponent* MeshComp;  // 0x10(0x8)
	struct UAnimSequenceBase* Animation;  // 0x18(0x8)
	uint8_t  LocationRule;  // 0x20(0x1)
	uint8_t  RotationRule;  // 0x21(0x1)
	char pad_34[6];  // 0x22(0x6)

}; 
// Function AIFramework.FWAIController.GetCoverEnterTime
// Size: 0x4(Inherited: 0x0) 
struct FGetCoverEnterTime
{
	float ReturnValue;  // 0x0(0x4)

}; 
// Function AIFramework.FWAIController.GetCoveringComponent
// Size: 0x8(Inherited: 0x0) 
struct FGetCoveringComponent
{
	struct UFWCoveringComponent* ReturnValue;  // 0x0(0x8)

}; 
// Function AIFramework.FWAIController.GetCurrentSmartObjectSlot
// Size: 0x8(Inherited: 0x0) 
struct FGetCurrentSmartObjectSlot
{
	struct USmartObjectSlotComponent* ReturnValue;  // 0x0(0x8)

}; 
// Function AIFramework.FWAIController.GetGoalActor
// Size: 0x8(Inherited: 0x0) 
struct FGetGoalActor
{
	struct AGoalPoint* ReturnValue;  // 0x0(0x8)

}; 
// Function AIFramework.BaseGoalTarget.GetHealth
// Size: 0x4(Inherited: 0x0) 
struct FGetHealth
{
	float ReturnValue;  // 0x0(0x4)

}; 
// Function AIFramework.FWAIController.GetCurrentTargetScore
// Size: 0x4(Inherited: 0x0) 
struct FGetCurrentTargetScore
{
	float ReturnValue;  // 0x0(0x4)

}; 
// Function AIFramework.FWAIController.GetSquad
// Size: 0x8(Inherited: 0x0) 
struct FGetSquad
{
	struct UFWAISquad* ReturnValue;  // 0x0(0x8)

}; 
// Function AIFramework.FWAIController.GetCustomLocation
// Size: 0xC(Inherited: 0x0) 
struct FGetCustomLocation
{
	struct FVector ReturnValue;  // 0x0(0xC)

}; 
// Function AIFramework.AIRoute.OnMoveFinished
// Size: 0x18(Inherited: 0x0) 
struct FOnMoveFinished
{
	struct AFWAIController* AI;  // 0x0(0x8)
	struct ABaseCharacter* character;  // 0x8(0x8)
	char EPawnActionResult WithResult;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function AIFramework.FWAIController.GetDiscreteDistance
// Size: 0x8(Inherited: 0x0) 
struct FGetDiscreteDistance
{
	float Distance;  // 0x0(0x4)
	uint8_t  ReturnValue;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)

}; 
// Function AIFramework.FWAIController.GetLastCombatActionTime
// Size: 0x4(Inherited: 0x0) 
struct FGetLastCombatActionTime
{
	float ReturnValue;  // 0x0(0x4)

}; 
// Function AIFramework.AITask_LaunchCharacter.OnAnimNotify
// Size: 0x20(Inherited: 0x0) 
struct FOnAnimNotify
{
	struct UFWAnimNotify* AnimNotify;  // 0x0(0x8)
	struct FName NotifyName;  // 0x8(0x8)
	struct USkeletalMeshComponent* MeshComp;  // 0x10(0x8)
	struct UAnimSequenceBase* Animation;  // 0x18(0x8)

}; 
// Function AIFramework.FWAIController.OnStoppedBeingTargetBy
// Size: 0x8(Inherited: 0x0) 
struct FOnStoppedBeingTargetBy
{
	struct AActor* TargetInstigator;  // 0x0(0x8)

}; 
// Function AIFramework.FWAIController.ResetScriptedSelectionPriority
// Size: 0x8(Inherited: 0x0) 
struct FResetScriptedSelectionPriority
{
	struct AActor* InEnemy;  // 0x0(0x8)

}; 
// ScriptStruct AIFramework.ConditionalEncounterSetupGroup
// Size: 0x10(Inherited: 0x0) 
struct FConditionalEncounterSetupGroup
{
	struct TArray<struct FEncounterSetup> Setups;  // 0x0(0x10)

}; 
// Function AIFramework.FWAIController.GetLastHitInfo
// Size: 0x200(Inherited: 0x0) 
struct FGetLastHitInfo
{
	struct FTakeHitInfo ReturnValue;  // 0x0(0x200)

}; 
// Function AIFramework.FWBackpackComponent.SetBackpackMaxHealth
// Size: 0x4(Inherited: 0x0) 
struct FSetBackpackMaxHealth
{
	float Amount;  // 0x0(0x4)

}; 
// Function AIFramework.FWAIController.RespondTo
// Size: 0x18(Inherited: 0x0) 
struct FRespondTo
{
	struct FName ChatterID;  // 0x0(0x8)
	struct AActor* Source;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function AIFramework.FWAIController.GetUClassAIArchetype
// Size: 0x8(Inherited: 0x0) 
struct FGetUClassAIArchetype
{
	UObject* ReturnValue;  // 0x0(0x8)

}; 
// Function AIFramework.FWAIController.GetResponseComponent
// Size: 0x8(Inherited: 0x0) 
struct FGetResponseComponent
{
	struct UFWAIResponseComponent* ReturnValue;  // 0x0(0x8)

}; 
// Function AIFramework.FWAIController.GetScriptedSelectionPriority
// Size: 0x10(Inherited: 0x0) 
struct FGetScriptedSelectionPriority
{
	struct AActor* InEnemy;  // 0x0(0x8)
	float ReturnValue;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)

}; 
// Function AIFramework.FWAIController.GetTargetActor
// Size: 0x8(Inherited: 0x0) 
struct FGetTargetActor
{
	struct AActor* ReturnValue;  // 0x0(0x8)

}; 
// Function AIFramework.FWAIController.GetSmartObjectLogic
// Size: 0x8(Inherited: 0x0) 
struct FGetSmartObjectLogic
{
	struct USmartObjectLogic* ReturnValue;  // 0x0(0x8)

}; 
// Function AIFramework.FWAIController.GetSquadName
// Size: 0x8(Inherited: 0x0) 
struct FGetSquadName
{
	struct FName ReturnValue;  // 0x0(0x8)

}; 
// Function AIFramework.FWNavigationSystem.OnLevelTransitionCompleted
// Size: 0x8(Inherited: 0x0) 
struct FOnLevelTransitionCompleted
{
	struct FName regionname;  // 0x0(0x8)

}; 
// DelegateFunction AIFramework.OnBiomeLoaded__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FOnBiomeLoaded__DelegateSignature
{
	struct UBaseBiomeData* Biome;  // 0x0(0x8)

}; 
// Function AIFramework.FWAIController.IsStrafeAllowed
// Size: 0x1(Inherited: 0x0) 
struct FIsStrafeAllowed
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function AIFramework.FWAIController.GetWeaponComponent
// Size: 0x8(Inherited: 0x0) 
struct FGetWeaponComponent
{
	struct UFWAIWeaponComponent* ReturnValue;  // 0x0(0x8)

}; 
// Function AIFramework.FWAIGameplayAbilityInterface.DoesTargetHaveProhibitedTagsForAI
// Size: 0x10(Inherited: 0x0) 
struct FDoesTargetHaveProhibitedTagsForAI
{
	struct AActor* TargetActor;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function AIFramework.FWAIController.IsOutsideRecoverArea
// Size: 0x1(Inherited: 0x0) 
struct FIsOutsideRecoverArea
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function AIFramework.FWAIController.IsUsingNewDamageReaction
// Size: 0x1(Inherited: 0x0) 
struct FIsUsingNewDamageReaction
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function AIFramework.SmartObjectSlotComponent.OnRep_Data
// Size: 0x18(Inherited: 0x0) 
struct FOnRep_Data
{
	struct FRepSmartObject OldData;  // 0x0(0x18)

}; 
// Function AIFramework.FWWaveSpawningSystem.StartWaveByName
// Size: 0x10(Inherited: 0x0) 
struct FStartWaveByName
{
	struct FName WaveName;  // 0x0(0x8)
	struct AFWWaveSpawningSystem* ReturnValue;  // 0x8(0x8)

}; 
// Function AIFramework.FWAIComponent.IsAimOffsetForced
// Size: 0x1(Inherited: 0x0) 
struct FIsAimOffsetForced
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// DelegateFunction AIFramework.OnWaveKilledDelegate__DelegateSignature
// Size: 0x28(Inherited: 0x0) 
struct FOnWaveKilledDelegate__DelegateSignature
{
	struct AFWEncounterManager* EncounterManager;  // 0x0(0x8)
	int32_t Index;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct FText WaveDescription;  // 0x10(0x18)

}; 
// Function AIFramework.FWAIController.IsTurnInPlaceAllowed
// Size: 0x1(Inherited: 0x0) 
struct FIsTurnInPlaceAllowed
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function AIFramework.FWAIController.K2_AreReactionsIgnored
// Size: 0x1(Inherited: 0x0) 
struct FK2_AreReactionsIgnored
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function AIFramework.FWEncounterManager.GetDefaultSetup
// Size: 0x20(Inherited: 0x0) 
struct FGetDefaultSetup
{
	struct FEncounterSetup ReturnValue;  // 0x0(0x20)

}; 
// Function AIFramework.FWAIController.K2_RequestForceFire
// Size: 0x20(Inherited: 0x0) 
struct FK2_RequestForceFire
{
	struct UObject* Source;  // 0x0(0x8)
	struct TArray<struct AActor*> inTargets;  // 0x8(0x10)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool bInForceContinuousFire : 1;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool bRequireLOS : 1;  // 0x19(0x1)
	char pad_26[6];  // 0x1A(0x6)

}; 
// Function AIFramework.FWAIWeaponComponent.NeedsReload
// Size: 0x1(Inherited: 0x0) 
struct FNeedsReload
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function AIFramework.FWAIController.K2_SetIgnoreReactions
// Size: 0x18(Inherited: 0x0) 
struct FK2_SetIgnoreReactions
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bIgnore : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FString DebugReason;  // 0x8(0x10)

}; 
// Function AIFramework.FWAITask_CoverAction.OnDamageEvent
// Size: 0x208(Inherited: 0x0) 
struct FOnDamageEvent
{
	struct ABaseCharacter* EnemyCharacter;  // 0x0(0x8)
	struct FTakeHitInfo TakeHitInfo;  // 0x8(0x200)

}; 
// Function AIFramework.GoalPoint.IsInsideOrOn
// Size: 0x10(Inherited: 0x0) 
struct FIsInsideOrOn
{
	struct FVector In;  // 0x0(0xC)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool ReturnValue : 1;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)

}; 
// Function AIFramework.FWWaveSpawningSystem.StartWaveWithDelay
// Size: 0x8(Inherited: 0x0) 
struct FStartWaveWithDelay
{
	int32_t WaveIndex;  // 0x0(0x4)
	float Seconds;  // 0x4(0x4)

}; 
// Function AIFramework.FWAIController.OnEnemyKilled
// Size: 0x208(Inherited: 0x0) 
struct FOnEnemyKilled
{
	struct ABaseCharacter* ControllerOwner;  // 0x0(0x8)
	struct FTakeHitInfo TakeHitInfo;  // 0x8(0x200)

}; 
// Function AIFramework.FWAIController.OnLethalHitEvent
// Size: 0x208(Inherited: 0x0) 
struct FOnLethalHitEvent
{
	struct ABaseCharacter* EnemyCharacter;  // 0x0(0x8)
	struct FTakeHitInfo TakeHitInfo;  // 0x8(0x200)

}; 
// Function AIFramework.GoalPoint.GetGoalSpace
// Size: 0x8(Inherited: 0x0) 
struct FGetGoalSpace
{
	struct AGoalArea* ReturnValue;  // 0x0(0x8)

}; 
// Function AIFramework.FWEncounterManager.OnBattleEvent
// Size: 0x40(Inherited: 0x0) 
struct FOnBattleEvent
{
	struct FGlobalEventParams GlobalEvent;  // 0x0(0x40)

}; 
// Function AIFramework.FWAIController.PostponePathUpdates
// Size: 0x1(Inherited: 0x0) 
struct FPostponePathUpdates
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Postpone : 1;  // 0x0(0x1)

}; 
// Function AIFramework.FWAIComponent.GetAimOffset
// Size: 0x8(Inherited: 0x0) 
struct FGetAimOffset
{
	struct FVector2D ReturnValue;  // 0x0(0x8)

}; 
// Function AIFramework.FWAIController.RequestChatter
// Size: 0x1(Inherited: 0x0) 
struct FRequestChatter
{
	uint8_t  Type;  // 0x0(0x1)

}; 
// Function AIFramework.FWWaveSpawningSystem.CacheDataForBiome
// Size: 0x8(Inherited: 0x0) 
struct FCacheDataForBiome
{
	struct UBaseBiomeData* CurrentBiome;  // 0x0(0x8)

}; 
// Function AIFramework.FWAIComponent.UseControllerDesiredRotation
// Size: 0x1(Inherited: 0x0) 
struct FUseControllerDesiredRotation
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bUse : 1;  // 0x0(0x1)

}; 
// Function AIFramework.FWAIController.RequestMovementMood
// Size: 0x2(Inherited: 0x0) 
struct FRequestMovementMood
{
	uint8_t  NewMood;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool ReturnValue : 1;  // 0x1(0x1)

}; 
// Function AIFramework.FWWaveSpawningSystem.StartWave
// Size: 0x10(Inherited: 0x0) 
struct FStartWave
{
	int32_t WaveIndex;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AFWWaveSpawningSystem* ReturnValue;  // 0x8(0x8)

}; 
// Function AIFramework.FWEncounterManager.IsCurrentWaveForced
// Size: 0x1(Inherited: 0x0) 
struct FIsCurrentWaveForced
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// ScriptStruct AIFramework.FWPendingSightInfo
// Size: 0x18(Inherited: 0x0) 
struct FFWPendingSightInfo
{
	struct AFWAIController* TestFrom;  // 0x0(0x8)
	struct APawn* TestTo;  // 0x8(0x8)
	char pad_16[8];  // 0x10(0x8)

}; 
// Function AIFramework.FWAIController.SetCurrentSmartObjectSlot
// Size: 0x8(Inherited: 0x0) 
struct FSetCurrentSmartObjectSlot
{
	struct USmartObjectSlotComponent* InSmartObjectSlot;  // 0x0(0x8)

}; 
// ScriptStruct AIFramework.FWAIWeaponCoverAnimationData
// Size: 0x798(Inherited: 0x0) 
struct FFWAIWeaponCoverAnimationData
{
	struct FFWAICoverActionAnimationData CoverType[3];  // 0x0(0x780)
	struct FSoftObjectPath DefaultShooting;  // 0x780(0x18)

}; 
// Function AIFramework.FWAIController.SetCustomLocation
// Size: 0xC(Inherited: 0x0) 
struct FSetCustomLocation
{
	struct FVector InCustomLocation;  // 0x0(0xC)

}; 
// Function AIFramework.FWBlueprintLibrary.CheckCharactersCollisionOnSegment
// Size: 0x28(Inherited: 0x0) 
struct FCheckCharactersCollisionOnSegment
{
	struct ABaseCharacter* character;  // 0x0(0x8)
	struct FVector StartLocation;  // 0x8(0xC)
	struct FVector EndLocation;  // 0x14(0xC)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool ReturnValue : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// Function AIFramework.FWWaveSpawningSystem.IsAnyWaveAlive
// Size: 0x1(Inherited: 0x0) 
struct FIsAnyWaveAlive
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// ScriptStruct AIFramework.MasterBiome
// Size: 0x78(Inherited: 0x0) 
struct FMasterBiome
{
	char pad_0[40];  // 0x0(0x28)
	struct TArray<struct FBiomeCharacterData> BiomeCharacterDatas;  // 0x28(0x10)
	struct TArray<struct FLoadedCharacterData> LoadedCharacterDatas;  // 0x38(0x10)
	char pad_72[48];  // 0x48(0x30)

}; 
// Function AIFramework.FWAIController.SetEnemyThreat
// Size: 0x10(Inherited: 0x0) 
struct FSetEnemyThreat
{
	float Threat;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AActor* InEnemy;  // 0x8(0x8)

}; 
// Function AIFramework.FWAIController.SetGoalActor
// Size: 0x8(Inherited: 0x0) 
struct FSetGoalActor
{
	struct AGoalPoint* InGoalActor;  // 0x0(0x8)

}; 
// Function AIFramework.BaseSmartObject.GetPostSyncMontageEvent
// Size: 0x30(Inherited: 0x0) 
struct FGetPostSyncMontageEvent
{
	struct AAIController* AI;  // 0x0(0x8)
	struct USmartObjectSlotComponent* Slot;  // 0x8(0x8)
	struct FMontageAssetSelector ReturnValue;  // 0x10(0x20)

}; 
// Function AIFramework.FWAIController.SetScriptedSelectionPriority
// Size: 0x10(Inherited: 0x0) 
struct FSetScriptedSelectionPriority
{
	float ScriptedSelectionPriority;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AActor* InEnemy;  // 0x8(0x8)

}; 
// Function AIFramework.SmartObjectSlotComponent.GetUsingCharacter
// Size: 0x8(Inherited: 0x0) 
struct FGetUsingCharacter
{
	struct ABaseCharacter* ReturnValue;  // 0x0(0x8)

}; 
// ScriptStruct AIFramework.SpawnAnimationNetworkData
// Size: 0x40(Inherited: 0x0) 
struct FSpawnAnimationNetworkData
{
	struct UAnimMontage* MontageToPlay;  // 0x0(0x8)
	char pad_8[8];  // 0x8(0x8)
	struct FTransform SpawnTransform;  // 0x10(0x30)

}; 
// Function AIFramework.FWAIController.TickMeleeAttack
// Size: 0x68(Inherited: 0x0) 
struct FTickMeleeAttack
{
	struct FString SocketNames;  // 0x0(0x10)
	struct USkeletalMeshComponent* MeshComp;  // 0x10(0x8)
	struct UAnimSequenceBase* Animation;  // 0x18(0x8)
	float FrameDeltaTime;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)
	struct TArray<struct FVector> PreviousSensorLocations;  // 0x28(0x10)
	struct TArray<struct FVector> CurrentSensorLocations;  // 0x38(0x10)
	UDamageType* DamageTypeClass;  // 0x48(0x8)
	struct FName TagName;  // 0x50(0x8)
	struct UFWAnimNotifyState_MeleeAttack* AnimNotify;  // 0x58(0x8)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool bAllowHittingMultipleTargets : 1;  // 0x60(0x1)
	char pad_97[7];  // 0x61(0x7)

}; 
// Function AIFramework.FWAITask_SetFocus.SetAIFocusAsVector
// Size: 0x20(Inherited: 0x0) 
struct FSetAIFocusAsVector
{
	struct AAIController* Controller;  // 0x0(0x8)
	struct FVector FocusLocation;  // 0x8(0xC)
	float PrecisionAngle;  // 0x14(0x4)
	struct UFWAITask_SetFocus* ReturnValue;  // 0x18(0x8)

}; 
// ScriptStruct AIFramework.MeleeAttackHitData
// Size: 0x18(Inherited: 0x0) 
struct FMeleeAttackHitData
{
	struct UFWAnimNotifyState_MeleeAttack* AnimNotify;  // 0x0(0x8)
	struct TArray<struct AActor*> HitActors;  // 0x8(0x10)

}; 
// Function AIFramework.BaseSmartObject.OnSOEventMontageBlendingOut
// Size: 0x10(Inherited: 0x0) 
struct FOnSOEventMontageBlendingOut
{
	struct UAnimMontage* Montage;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bInterrupted : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// ScriptStruct AIFramework.FWEncounterWaveDifficultyDescriptor
// Size: 0x28(Inherited: 0x0) 
struct FFWEncounterWaveDifficultyDescriptor
{
	uint8_t  SortMethod;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct TArray<struct FFWAIArchetypeVariation> CustomSortList;  // 0x8(0x10)
	struct TArray<struct FFWAIArchetypeVariation> Blacklist;  // 0x18(0x10)

}; 
// ScriptStruct AIFramework.FWForceFireRequest
// Size: 0x20(Inherited: 0x0) 
struct FFWForceFireRequest
{
	char pad_0[8];  // 0x0(0x8)
	struct TArray<struct AActor*> TargetList;  // 0x8(0x10)
	char pad_24[8];  // 0x18(0x8)

}; 
// Function AIFramework.FWCharacterCache.OnBiomeLoad
// Size: 0x18(Inherited: 0x0) 
struct FOnBiomeLoad
{
	struct UBaseBiomeData* Biome;  // 0x0(0x8)
	struct UObject* OwnerObject;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bIsWorldBiome : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// ScriptStruct AIFramework.LocalEnemyInfo
// Size: 0x40(Inherited: 0x0) 
struct FLocalEnemyInfo
{
	struct AActor* Actor;  // 0x0(0x8)
	float Damage;  // 0x8(0x4)
	float ThreatFromDamage;  // 0xC(0x4)
	float Threat;  // 0x10(0x4)
	float GroupThreat;  // 0x14(0x4)
	float ScriptedSelectionPriority;  // 0x18(0x4)
	char bIsPlayer : 1;  // 0x1C(0x1)
	char pad_28_1 : 7;  // 0x1C(0x1)
	char pad_29[4];  // 0x1D(0x4)
	uint32_t LastCoverTest;  // 0x20(0x4)
	char bCoverVisibleLeft : 1;  // 0x24(0x1)
	char bCoverVisibleRight : 1;  // 0x24(0x1)
	char bCoverVisibleUp : 1;  // 0x24(0x1)
	char pad_36_1 : 5;  // 0x24(0x1)
	char pad_37[28];  // 0x25(0x1C)

}; 
// Function AIFramework.FWWaveSpawningSystem.GetEnemiesAliveOverall
// Size: 0x4(Inherited: 0x0) 
struct FGetEnemiesAliveOverall
{
	int32_t ReturnValue;  // 0x0(0x4)

}; 
// DelegateFunction AIFramework.ActorEnteredArenaSignature__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FActorEnteredArenaSignature__DelegateSignature
{
	struct AActor* EnteringActor;  // 0x0(0x8)

}; 
// DelegateFunction AIFramework.ActorLeftArenaSignature__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FActorLeftArenaSignature__DelegateSignature
{
	struct AActor* EnteringActor;  // 0x0(0x8)

}; 
// DelegateFunction AIFramework.OnArenaSwitchedOnDelegate__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FOnArenaSwitchedOnDelegate__DelegateSignature
{
	struct ACombatArena* SwitchedOnArena;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bSwitchedByTriggerVolume : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// DelegateFunction AIFramework.WssKillCountReachedDelegate__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FWssKillCountReachedDelegate__DelegateSignature
{
	struct AFWWaveSpawningSystem* Wss;  // 0x0(0x8)
	int32_t WaveIndex;  // 0x8(0x4)
	struct FName WaveName;  // 0xC(0x8)
	int32_t NotifierIndex;  // 0x14(0x4)

}; 
// DelegateFunction AIFramework.OnArenaSwitchedOffDelegate__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FOnArenaSwitchedOffDelegate__DelegateSignature
{
	struct ACombatArena* SwitchedOffArena;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bSwitchedByTriggerVolume : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	int32_t AIsLeftToFallback;  // 0xC(0x4)

}; 
// Function AIFramework.FWAIWeaponComponent.EnableAutoFiring
// Size: 0x1(Inherited: 0x0) 
struct FEnableAutoFiring
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bEnable : 1;  // 0x0(0x1)

}; 
// Function AIFramework.FWWaveSpawningSystem.OnLevelTransitionStartedHandler
// Size: 0x10(Inherited: 0x0) 
struct FOnLevelTransitionStartedHandler
{
	struct FName FromRegionName;  // 0x0(0x8)
	struct FName ToRegionName;  // 0x8(0x8)

}; 
// Function AIFramework.GoalPoint.Enable
// Size: 0x1(Inherited: 0x0) 
struct FEnable
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bEnabled : 1;  // 0x0(0x1)

}; 
// DelegateFunction AIFramework.OnArenaChanged__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FOnArenaChanged__DelegateSignature
{
	struct ACombatArena* Arena;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bSpawnersAdded : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// DelegateFunction AIFramework.WaveKilledEventDelegate__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FWaveKilledEventDelegate__DelegateSignature
{
	struct AFWWaveSpawningSystem* Wss;  // 0x0(0x8)
	int32_t WaveIndex;  // 0x8(0x4)
	struct FName WaveName;  // 0xC(0x8)
	int32_t NumWavesKilled;  // 0x14(0x4)
	struct ABaseCharacter* KilledCharacter;  // 0x18(0x8)

}; 
// DelegateFunction AIFramework.WssCharacterKilledDelegate__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FWssCharacterKilledDelegate__DelegateSignature
{
	struct AFWWaveSpawningSystem* Wss;  // 0x0(0x8)
	int32_t WaveIndex;  // 0x8(0x4)
	struct FName WaveName;  // 0xC(0x8)
	char pad_20[4];  // 0x14(0x4)
	struct ABaseCharacter* character;  // 0x18(0x8)

}; 
// DelegateFunction AIFramework.WssCharacterSpawnedDelegate__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FWssCharacterSpawnedDelegate__DelegateSignature
{
	struct AFWWaveSpawningSystem* Wss;  // 0x0(0x8)
	int32_t WaveIndex;  // 0x8(0x4)
	struct FName WaveName;  // 0xC(0x8)
	char pad_20[4];  // 0x14(0x4)
	struct ABaseCharacter* character;  // 0x18(0x8)

}; 
// Function AIFramework.FWEncounterManager.OnArenaChanged
// Size: 0x10(Inherited: 0x0) 
struct FOnArenaChanged
{
	struct ACombatArena* CombatArena;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bSpawnersAdded : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// DelegateFunction AIFramework.WssHPCountReachedDelegate__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FWssHPCountReachedDelegate__DelegateSignature
{
	struct AFWWaveSpawningSystem* Wss;  // 0x0(0x8)
	int32_t WaveIndex;  // 0x8(0x4)
	struct FName WaveName;  // 0xC(0x8)
	int32_t NotifierIndex;  // 0x14(0x4)

}; 
// Function AIFramework.FWAIDamageReactionComponent.OnAnimationTaskFinished
// Size: 0x10(Inherited: 0x0) 
struct FOnAnimationTaskFinished
{
	struct UFWAITask* Task;  // 0x0(0x8)
	uint8_t  Result;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// ScriptStruct AIFramework.GroupMaterialData
// Size: 0x50(Inherited: 0x0) 
struct FGroupMaterialData
{
	struct TMap<int8_t, struct UMaterialInterface*> Materials;  // 0x0(0x50)

}; 
// ScriptStruct AIFramework.FWProjectileController
// Size: 0x150(Inherited: 0x0) 
struct FFWProjectileController
{
	struct AActor* OwnerActor;  // 0x0(0x8)
	struct Acharacter* PawnInstigatorOverride;  // 0x8(0x8)
	uint32_t NumberOfTrajectories;  // 0x10(0x4)
	float StartArcValue;  // 0x14(0x4)
	float EndArcValue;  // 0x18(0x4)
	char bRecalculateProjectileTrajectory : 1;  // 0x1C(0x1)
	char bAsyncProjectileTrajectoryCheck : 1;  // 0x1C(0x1)
	char pad_28_1 : 6;  // 0x1C(0x1)
	char pad_29[4];  // 0x1D(0x4)
	struct FName BoneName;  // 0x20(0x8)
	struct FVector ThrowLocationOffset;  // 0x28(0xC)
	float ProjectileTrajectoryCalculationFrequency;  // 0x34(0x4)
	char EDrawDebugTrace ProjectileTrajectoryDrawDebugType;  // 0x38(0x1)
	char pad_57[3];  // 0x39(0x3)
	float ProjectileTrajectoryDrawDebugTime;  // 0x3C(0x4)
	AProjectile* DefaultProjectileClass;  // 0x40(0x8)
	float TargetLocationPrecisionPct;  // 0x48(0x4)
	char pad_76[260];  // 0x4C(0x104)

}; 
// DelegateFunction AIFramework.WssWaveBeginSpawningDelegate__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FWssWaveBeginSpawningDelegate__DelegateSignature
{
	struct AFWWaveSpawningSystem* Wss;  // 0x0(0x8)
	int32_t WaveIndex;  // 0x8(0x4)
	struct FName WaveName;  // 0xC(0x8)
	char pad_20[4];  // 0x14(0x4)

}; 
// DelegateFunction AIFramework.WssBeginWorkDelegate__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FWssBeginWorkDelegate__DelegateSignature
{
	struct AFWWaveSpawningSystem* Wss;  // 0x0(0x8)

}; 
// DelegateFunction AIFramework.WssTeamWipeoutDelegate__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FWssTeamWipeoutDelegate__DelegateSignature
{
	struct AFWWaveSpawningSystem* Wss;  // 0x0(0x8)

}; 
// DelegateFunction AIFramework.WssShutdownDelegate__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FWssShutdownDelegate__DelegateSignature
{
	struct AFWWaveSpawningSystem* Wss;  // 0x0(0x8)

}; 
// Function AIFramework.FWWaveSpawningSystem.GetPlayersCount
// Size: 0x4(Inherited: 0x0) 
struct FGetPlayersCount
{
	int32_t ReturnValue;  // 0x0(0x4)

}; 
// Function AIFramework.FWEncounterManager.OnCharacterKilled
// Size: 0x208(Inherited: 0x0) 
struct FOnCharacterKilled
{
	struct ABaseCharacter* character;  // 0x0(0x8)
	struct FTakeHitInfo TakeHitInfo;  // 0x8(0x200)

}; 
// DelegateFunction AIFramework.OnGoalAvailableDelegate__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FOnGoalAvailableDelegate__DelegateSignature
{
	struct AGoalPoint* Goal;  // 0x0(0x8)

}; 
// Function AIFramework.FWAISquad.GetSquadMemberPawns
// Size: 0x10(Inherited: 0x0) 
struct FGetSquadMemberPawns
{
	struct TArray<struct APawn*> SquadMemberPawns;  // 0x0(0x10)

}; 
// DelegateFunction AIFramework.AITaskEndedCompletedSignature__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FAITaskEndedCompletedSignature__DelegateSignature
{
	struct UFWAITask* Task;  // 0x0(0x8)
	uint8_t  Result;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// DelegateFunction AIFramework.OnSmartObjectStarted__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FOnSmartObjectStarted__DelegateSignature
{
	struct AAIRoute* Route;  // 0x0(0x8)
	struct AFWAIController* AIController;  // 0x8(0x8)
	struct ABaseCharacter* character;  // 0x10(0x8)
	char EPawnActionResult WithResult;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)

}; 
// Function AIFramework.FWCharacterCache.OnBiomeUnload
// Size: 0x10(Inherited: 0x0) 
struct FOnBiomeUnload
{
	struct UBaseBiomeData* Biome;  // 0x0(0x8)
	struct UObject* OwnerObject;  // 0x8(0x8)

}; 
// ScriptStruct AIFramework.FloatPlayerCount
// Size: 0xC(Inherited: 0x0) 
struct FFloatPlayerCount
{
	float One;  // 0x0(0x4)
	float Two;  // 0x4(0x4)
	float Three;  // 0x8(0x4)

}; 
// DelegateFunction AIFramework.OnMovementMoodChangedEvent__DelegateSignature
// Size: 0x2(Inherited: 0x0) 
struct FOnMovementMoodChangedEvent__DelegateSignature
{
	uint8_t  LastMood;  // 0x0(0x1)
	uint8_t  NewMood;  // 0x1(0x1)

}; 
// Function AIFramework.FWAIWeaponComponent.DropProjectileAway
// Size: 0x18(Inherited: 0x0) 
struct FDropProjectileAway
{
	float MinDistance;  // 0x0(0x4)
	float MaxDistance;  // 0x4(0x4)
	float ExtraHeight;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct Acharacter* PawnInstigatorOverride;  // 0x10(0x8)

}; 
// Function AIFramework.BaseSmartObject.GetSlotsInUseCount
// Size: 0x4(Inherited: 0x0) 
struct FGetSlotsInUseCount
{
	int32_t ReturnValue;  // 0x0(0x4)

}; 
// DelegateFunction AIFramework.OnReactionSignalDelegate__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FOnReactionSignalDelegate__DelegateSignature
{
	struct UFWAIRes_ReactionsToPlayer* ReactionsResponse;  // 0x0(0x8)

}; 
// DelegateFunction AIFramework.OnSpawnSignature__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FOnSpawnSignature__DelegateSignature
{
	struct Acharacter* SpawnedCharacter;  // 0x0(0x8)
	struct AFWAIController* AIController;  // 0x8(0x8)
	int32_t SpawnGroupId;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)

}; 
// DelegateFunction AIFramework.OnKilledSpawnSignature__DelegateSignature
// Size: 0x210(Inherited: 0x0) 
struct FOnKilledSpawnSignature__DelegateSignature
{
	struct ABaseCharacter* character;  // 0x0(0x8)
	struct FTakeHitInfo TakeHitInfo;  // 0x8(0x200)
	int32_t SpawnGroupId;  // 0x208(0x4)
	char pad_524[4];  // 0x20C(0x4)

}; 
// Function AIFramework.FWBlueprintLibrary.GetAllCharactersWithArchetype
// Size: 0x38(Inherited: 0x0) 
struct FGetAllCharactersWithArchetype
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct FFWAIArchetypeVariation ArchetypeVariation;  // 0x8(0x20)
	struct TArray<struct ABaseCharacter*> OutCharacters;  // 0x28(0x10)

}; 
// DelegateFunction AIFramework.OnWaveBeginSpawningDelegate__DelegateSignature
// Size: 0x28(Inherited: 0x0) 
struct FOnWaveBeginSpawningDelegate__DelegateSignature
{
	struct AFWEncounterManager* EncounterManager;  // 0x0(0x8)
	int32_t Index;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct FText WaveDescription;  // 0x10(0x18)

}; 
// DelegateFunction AIFramework.OnWaveEndSpawningDelegate__DelegateSignature
// Size: 0x28(Inherited: 0x0) 
struct FOnWaveEndSpawningDelegate__DelegateSignature
{
	struct AFWEncounterManager* EncounterManager;  // 0x0(0x8)
	int32_t Index;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct FText WaveDescription;  // 0x10(0x18)

}; 
// DelegateFunction AIFramework.OnWaveTimeElapsedDelegate__DelegateSignature
// Size: 0x28(Inherited: 0x0) 
struct FOnWaveTimeElapsedDelegate__DelegateSignature
{
	struct AFWEncounterManager* EncounterManager;  // 0x0(0x8)
	int32_t Index;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct FText WaveDescription;  // 0x10(0x18)

}; 
// DelegateFunction AIFramework.OnCharactersWereKilledDelegate__DelegateSignature
// Size: 0x28(Inherited: 0x0) 
struct FOnCharactersWereKilledDelegate__DelegateSignature
{
	struct AFWEncounterManager* EncounterManager;  // 0x0(0x8)
	int32_t Index;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct FText WaveDescription;  // 0x10(0x18)

}; 
// Function AIFramework.FWLinkedActorsInterface.UnlinkActors
// Size: 0x18(Inherited: 0x0) 
struct FUnlinkActors
{
	struct TArray<struct AActor*> Actors;  // 0x0(0x10)
	int32_t ReturnValue;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)

}; 
// DelegateFunction AIFramework.OnEncounterResetDelegate__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FOnEncounterResetDelegate__DelegateSignature
{
	struct AFWEncounterManager* EncounterManager;  // 0x0(0x8)
	int32_t LastWaveIndex;  // 0x8(0x4)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool bAutomaticallyReset : 1;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)

}; 
// Function AIFramework.BaseGoalTarget.SetMaxHealth
// Size: 0x4(Inherited: 0x0) 
struct FSetMaxHealth
{
	float InMaxHealth;  // 0x0(0x4)

}; 
// Function AIFramework.FWWaveSpawningSystem.GetEnemiesSpawned
// Size: 0x8(Inherited: 0x0) 
struct FGetEnemiesSpawned
{
	int32_t WaveIndex;  // 0x0(0x4)
	int32_t ReturnValue;  // 0x4(0x4)

}; 
// Function AIFramework.FWAIComponent.GetDesiredRotation
// Size: 0xC(Inherited: 0x0) 
struct FGetDesiredRotation
{
	struct FRotator ReturnValue;  // 0x0(0xC)

}; 
// DelegateFunction AIFramework.OnCharacterSpawnedDelegate__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FOnCharacterSpawnedDelegate__DelegateSignature
{
	struct AFWEncounterManager* EncounterManager;  // 0x0(0x8)
	int32_t Index;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct ABaseCharacter* character;  // 0x10(0x8)

}; 
// Function AIFramework.FWBlueprintLibrary.LogSegment
// Size: 0x48(Inherited: 0x0) 
struct FLogSegment
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct FVector SegmentStart;  // 0x8(0xC)
	struct FVector SegmentEnd;  // 0x14(0xC)
	struct FString Text;  // 0x20(0x10)
	struct FLinearColor Color;  // 0x30(0x10)
	struct FName CategoryName;  // 0x40(0x8)

}; 
// Function AIFramework.FWWaveSpawningSystem.GetEnemiesSpawnedOverall
// Size: 0x4(Inherited: 0x0) 
struct FGetEnemiesSpawnedOverall
{
	int32_t ReturnValue;  // 0x0(0x4)

}; 
// DelegateFunction AIFramework.OnCharacterKilledDelegate__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FOnCharacterKilledDelegate__DelegateSignature
{
	struct AFWEncounterManager* EncounterManager;  // 0x0(0x8)
	int32_t Index;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)

}; 
// DelegateFunction AIFramework.OnWaveBeginCombat__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FOnWaveBeginCombat__DelegateSignature
{
	struct AFWEncounterManager* EncounterManager;  // 0x0(0x8)
	int32_t Index;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)

}; 
// DelegateFunction AIFramework.OnEvaluateSetupCondition__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FOnEvaluateSetupCondition__DelegateSignature
{
	struct AFWEncounterManager* EncounterManager;  // 0x0(0x8)
	int32_t SetupIndex;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)

}; 
// DelegateFunction AIFramework.OnAllWavesEndSpawningDelegate__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FOnAllWavesEndSpawningDelegate__DelegateSignature
{
	struct AFWEncounterManager* EncounterManager;  // 0x0(0x8)

}; 
// DelegateFunction AIFramework.OnAllWavesWereKilledDelegate__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FOnAllWavesWereKilledDelegate__DelegateSignature
{
	struct AFWEncounterManager* EncounterManager;  // 0x0(0x8)

}; 
// DelegateFunction AIFramework.OnVolumeStateChanged__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FOnVolumeStateChanged__DelegateSignature
{
	struct ASpawnVolume* Volume;  // 0x0(0x8)

}; 
// Function AIFramework.FWWaveSpawningSystem.GetEnemiesAlive
// Size: 0x8(Inherited: 0x0) 
struct FGetEnemiesAlive
{
	int32_t WaveIndex;  // 0x0(0x4)
	int32_t ReturnValue;  // 0x4(0x4)

}; 
// ScriptStruct AIFramework.AINavLOSCacher
// Size: 0x40(Inherited: 0x0) 
struct FAINavLOSCacher
{
	struct TArray<struct FAINavPredictionEntry> PredictionEntries;  // 0x0(0x10)
	struct TArray<struct FAINavLOSEntryPerPawn> LOSEntriesPerPawn;  // 0x10(0x10)
	float PredictionMaxTestDistance;  // 0x20(0x4)
	float PredictionTestDistanceExtra;  // 0x24(0x4)
	float MaxPredictionDirectionVarianceDeg;  // 0x28(0x4)
	float MaxUnusedTime;  // 0x2C(0x4)
	float MaxLOSDelta;  // 0x30(0x4)
	char pad_52_1 : 7;  // 0x34(0x1)
	bool bEnablePredictionCaching : 1;  // 0x34(0x1)
	char pad_53_1 : 7;  // 0x35(0x1)
	bool bEnableLOSCaching : 1;  // 0x35(0x1)
	char pad_54[2];  // 0x36(0x2)
	float CleanupDelay;  // 0x38(0x4)
	char pad_60[4];  // 0x3C(0x4)

}; 
// ScriptStruct AIFramework.AIDamageWindow
// Size: 0x20(Inherited: 0x0) 
struct FAIDamageWindow
{
	char pad_0[32];  // 0x0(0x20)

}; 
// ScriptStruct AIFramework.ContinousSpawnSetup
// Size: 0x48(Inherited: 0x0) 
struct FContinousSpawnSetup
{
	struct TArray<struct ACharacterSpawner*> CollectedSpawners;  // 0x0(0x10)
	char pad_16[56];  // 0x10(0x38)

}; 
// Function AIFramework.FWWaveSpawningSystem.IsRunning
// Size: 0x1(Inherited: 0x0) 
struct FIsRunning
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// ScriptStruct AIFramework.AISpawnSubsystemTickFunction
// Size: 0x120(Inherited: 0x118) 
struct FAISpawnSubsystemTickFunction : public FTickFunction
{
	char pad_280[8];  // 0x118(0x8)

}; 
// ScriptStruct AIFramework.MovementMoodSetup
// Size: 0x24(Inherited: 0x0) 
struct FMovementMoodSetup
{
	float MaxSpeed;  // 0x0(0x4)
	float MaxAcceleration;  // 0x4(0x4)
	struct FRotator RotationRate;  // 0x8(0xC)
	struct FRotator InPlaceRotationRate;  // 0x14(0xC)
	char bUseControllerDesiredRotation : 1;  // 0x20(0x1)
	char bOrientRotationToMovement : 1;  // 0x20(0x1)
	char pad_32_1 : 6;  // 0x20(0x1)
	char pad_33[4];  // 0x21(0x4)

}; 
// ScriptStruct AIFramework.RepSmartObject
// Size: 0x18(Inherited: 0x0) 
struct FRepSmartObject
{
	struct ABaseCharacter* UsingCharacter;  // 0x0(0x8)
	uint8_t  CurrentUsageState;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	float CurrentMontageStartTime;  // 0xC(0x4)
	struct FName CurrentMontageSection;  // 0x10(0x8)

}; 
// ScriptStruct AIFramework.RepSmartObjectAnimNotify
// Size: 0xC(Inherited: 0x0) 
struct FRepSmartObjectAnimNotify
{
	struct FName NotifyName;  // 0x0(0x8)
	uint8_t  NotifyType;  // 0x8(0x1)
	uint8_t  Attachment;  // 0x9(0x1)
	uint8_t  LocationRule;  // 0xA(0x1)
	uint8_t  RotationRule;  // 0xB(0x1)

}; 
// ScriptStruct AIFramework.FactReaction
// Size: 0x30(Inherited: 0x0) 
struct FFactReaction
{
	struct FFactExpression Expression;  // 0x0(0x18)
	struct FReactionsGoalPointSettings Reaction;  // 0x18(0x18)

}; 
// Function AIFramework.FWEncounterManager.GetWaveTime
// Size: 0x4(Inherited: 0x0) 
struct FGetWaveTime
{
	float ReturnValue;  // 0x0(0x4)

}; 
// ScriptStruct AIFramework.FWAISlideToCoverAnimationData
// Size: 0x60(Inherited: 0x0) 
struct FFWAISlideToCoverAnimationData
{
	struct FSoftObjectPath SlideToCoverMontage[4];  // 0x0(0x60)

}; 
// ScriptStruct AIFramework.ReactionsGoalPointSettings
// Size: 0x18(Inherited: 0x0) 
struct FReactionsGoalPointSettings
{
	uint8_t  Reaction;  // 0x0(0x1)
	char ReactionTime;  // 0x1(0x1)
	char ReactionCooldownTime;  // 0x2(0x1)
	char ReactionCooldownMaxTime;  // 0x3(0x1)
	char bSpeakOnlyOnce : 1;  // 0x4(0x1)
	char pad_4_1 : 7;  // 0x4(0x1)
	char pad_5[4];  // 0x5(0x4)
	struct FNameWrapper SpeechLineToPlay;  // 0x8(0x10)

}; 
// ScriptStruct AIFramework.CharacterCacheRepData
// Size: 0x28(Inherited: 0x0) 
struct FCharacterCacheRepData
{
	int32_t SynchronizationStreamSeed;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct TArray<struct FUint64Group> BiomeLoadedCharacters_NetworkState;  // 0x8(0x10)
	struct TArray<struct UBaseBiomeData*> Biomes_NetworkState;  // 0x18(0x10)

}; 
// ScriptStruct AIFramework.Uint64Group
// Size: 0x10(Inherited: 0x0) 
struct FUint64Group
{
	uint64_t High;  // 0x0(0x8)
	uint64_t Low;  // 0x8(0x8)

}; 
// Function AIFramework.GoalPoint.AssignFollower
// Size: 0x10(Inherited: 0x0) 
struct FAssignFollower
{
	struct AAIController* AI;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bRemoveOld : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool ReturnValue : 1;  // 0x9(0x1)
	char pad_10[6];  // 0xA(0x6)

}; 
// ScriptStruct AIFramework.BiomeCharacterData
// Size: 0x28(Inherited: 0x0) 
struct FBiomeCharacterData
{
	char pad_0[8];  // 0x0(0x8)
	struct FFWAIArchetypeVariation Variation;  // 0x8(0x20)

}; 
// ScriptStruct AIFramework.CharacterAssetPool
// Size: 0x50(Inherited: 0x0) 
struct FCharacterAssetPool
{
	char pad_0[64];  // 0x0(0x40)
	struct TArray<struct UObject*> LoadedObjects;  // 0x40(0x10)

}; 
// ScriptStruct AIFramework.AntFarmControlAttributeDelta
// Size: 0xC(Inherited: 0x0) 
struct FAntFarmControlAttributeDelta
{
	struct FGameplayTag Attribute;  // 0x0(0x8)
	float DeltaValue;  // 0x8(0x4)

}; 
// Function AIFramework.FWAIWeaponComponent.CheckLOS
// Size: 0x1(Inherited: 0x0) 
struct FCheckLOS
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bCheck : 1;  // 0x0(0x1)

}; 
// Function AIFramework.FWAIResponse.ShouldRespond
// Size: 0x20(Inherited: 0x0) 
struct FShouldRespond
{
	struct UFWAIResponseChannel* SourceChannel;  // 0x0(0x8)
	struct AFWAIController* AI;  // 0x8(0x8)
	struct ABaseCharacter* character;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool ReturnValue : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)

}; 
// ScriptStruct AIFramework.GoalFireTarget
// Size: 0x18(Inherited: 0x0) 
struct FGoalFireTarget
{
	struct AActor* Target;  // 0x0(0x8)
	struct TArray<struct AFWAIController*> Shooters;  // 0x8(0x10)

}; 
// Function AIFramework.GoalPoint.AssignFollowers
// Size: 0x18(Inherited: 0x0) 
struct FAssignFollowers
{
	struct TArray<struct AAIController*> AIControllers;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bRemoveOld : 1;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool ReturnValue : 1;  // 0x11(0x1)
	char pad_18[6];  // 0x12(0x6)

}; 
// Function AIFramework.FWEncounterManager.OnArenaSwitchedOff
// Size: 0x10(Inherited: 0x0) 
struct FOnArenaSwitchedOff
{
	struct ACombatArena* CombatArena;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bSwitchedByTriggerVolume : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	int32_t AIsLeftToFallback;  // 0xC(0x4)

}; 
// ScriptStruct AIFramework.AINavLOSEntryPerPawn
// Size: 0x18(Inherited: 0x0) 
struct FAINavLOSEntryPerPawn
{
	struct APawn* Pawn;  // 0x0(0x8)
	char pad_8[16];  // 0x8(0x10)

}; 
// Function AIFramework.FWWaveSpawningSystem.ResetWaveByName
// Size: 0x10(Inherited: 0x0) 
struct FResetWaveByName
{
	struct FName WaveName;  // 0x0(0x8)
	struct AFWWaveSpawningSystem* ReturnValue;  // 0x8(0x8)

}; 
// ScriptStruct AIFramework.AINavPredictionEntry
// Size: 0x38(Inherited: 0x0) 
struct FAINavPredictionEntry
{
	struct APawn* Pawn;  // 0x0(0x8)
	char pad_8[48];  // 0x8(0x30)

}; 
// Function AIFramework.FWBackpackComponent.GetBackpackMaxHealth
// Size: 0x4(Inherited: 0x0) 
struct FGetBackpackMaxHealth
{
	float ReturnValue;  // 0x0(0x4)

}; 
// ScriptStruct AIFramework.AIReactionsManagerTickFunction
// Size: 0x120(Inherited: 0x118) 
struct FAIReactionsManagerTickFunction : public FTickFunction
{
	char pad_280[8];  // 0x118(0x8)

}; 
// ScriptStruct AIFramework.WAIResChannel_AbilityTagStatus
// Size: 0xC(Inherited: 0x0) 
struct FWAIResChannel_AbilityTagStatus
{
	struct FGameplayTag Tag;  // 0x0(0x8)
	int32_t TagCounter;  // 0x8(0x4)

}; 
// Function AIFramework.FWSplinePathFollowingComponent.SplineOnMantleTaskEnded
// Size: 0x10(Inherited: 0x0) 
struct FSplineOnMantleTaskEnded
{
	struct UFWAITask* Task;  // 0x0(0x8)
	uint8_t  Result;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// ScriptStruct AIFramework.FWAISquadTickFunction
// Size: 0x120(Inherited: 0x118) 
struct FFWAISquadTickFunction : public FTickFunction
{
	char pad_280[8];  // 0x118(0x8)

}; 
// ScriptStruct AIFramework.FWSquadMemberInfo
// Size: 0x8(Inherited: 0x0) 
struct FFWSquadMemberInfo
{
	struct AController* Member;  // 0x0(0x8)

}; 
// Function AIFramework.FWAISquad.RegisterSquadMember
// Size: 0x10(Inherited: 0x0) 
struct FRegisterSquadMember
{
	struct AController* NewMember;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bLeader : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// ScriptStruct AIFramework.FWSquadEnemyInfo
// Size: 0x48(Inherited: 0x0) 
struct FFWSquadEnemyInfo
{
	struct Acharacter* character;  // 0x0(0x8)
	struct FVector KnownLocation;  // 0x8(0xC)
	char pad_20[4];  // 0x14(0x4)
	struct FCoverSlotInfo KnownCover;  // 0x18(0x18)
	float LastContactTime;  // 0x30(0x4)
	float InitialContactTime;  // 0x34(0x4)
	struct TArray<struct AFWAIController*> VisibleTo;  // 0x38(0x10)

}; 
// ScriptStruct AIFramework.FWExtendedSquadEnemyInfo
// Size: 0x108(Inherited: 0x0) 
struct FFWExtendedSquadEnemyInfo
{
	struct Acharacter* character;  // 0x0(0x8)
	struct FFWDestinationOffsetInfo DestinationOffsets[8];  // 0x8(0x100)

}; 
// Function AIFramework.FWWaveSpawningSystem.GetEnemiesSpawnedByName
// Size: 0xC(Inherited: 0x0) 
struct FGetEnemiesSpawnedByName
{
	struct FName WaveName;  // 0x0(0x8)
	int32_t ReturnValue;  // 0x8(0x4)

}; 
// Function AIFramework.CharacterSpawner.IsSpawnerEnabledOnStart
// Size: 0x1(Inherited: 0x0) 
struct FIsSpawnerEnabledOnStart
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// ScriptStruct AIFramework.SemaphorePendingUnlockItem
// Size: 0x20(Inherited: 0x0) 
struct FSemaphorePendingUnlockItem
{
	char pad_0[8];  // 0x0(0x8)
	struct AActor* Target;  // 0x8(0x8)
	struct AFWAIController* Owner;  // 0x10(0x8)
	char pad_24[8];  // 0x18(0x8)

}; 
// ScriptStruct AIFramework.WAIConcurentSemaphoreGroup
// Size: 0x50(Inherited: 0x0) 
struct FWAIConcurentSemaphoreGroup
{
	struct TMap<UFWAISemaphoreGroupClass*, struct FFWAISemaphoreGroupData> Map;  // 0x0(0x50)

}; 
// Function AIFramework.FWAIComponent.GetPawn
// Size: 0x8(Inherited: 0x0) 
struct FGetPawn
{
	struct APawn* ReturnValue;  // 0x0(0x8)

}; 
// ScriptStruct AIFramework.FWAISemaphoreGroupData
// Size: 0x18(Inherited: 0x0) 
struct FFWAISemaphoreGroupData
{
	char pad_0[8];  // 0x0(0x8)
	struct TArray<struct AFWAIController*> ClaimedBy;  // 0x8(0x10)

}; 
// ScriptStruct AIFramework.AISystemTickFunction
// Size: 0x120(Inherited: 0x118) 
struct FAISystemTickFunction : public FTickFunction
{
	char pad_280[8];  // 0x118(0x8)

}; 
// ScriptStruct AIFramework.AITaskJumpNetworkData
// Size: 0x38(Inherited: 0x0) 
struct FAITaskJumpNetworkData
{
	struct UAnimMontage* SelectedAnimation;  // 0x0(0x8)
	struct UCurveFloat* HeightInterpolationCurve;  // 0x8(0x8)
	struct FVector LinkStart;  // 0x10(0xC)
	struct FVector LinkEnd;  // 0x1C(0xC)
	float EndOffsetForJumpUp;  // 0x28(0x4)
	float VerticalEndOffsetForJumpUp;  // 0x2C(0x4)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool bCanOvershootLinkEndWhenHasSpace : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)

}; 
// Function AIFramework.CombatArena.TriggerAssault
// Size: 0x1(Inherited: 0x0) 
struct FTriggerAssault
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bRecursiveParentFallback : 1;  // 0x0(0x1)

}; 
// Function AIFramework.CharacterSpawner.EnableSpawner
// Size: 0x1(Inherited: 0x0) 
struct FEnableSpawner
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bResetCounters : 1;  // 0x0(0x1)

}; 
// Function AIFramework.FWAIResponse.GetAvatar
// Size: 0x8(Inherited: 0x0) 
struct FGetAvatar
{
	struct ABaseCharacter* ReturnValue;  // 0x0(0x8)

}; 
// ScriptStruct AIFramework.FWCombatSpot
// Size: 0x30(Inherited: 0x0) 
struct FFWCombatSpot
{
	struct FCoverSlotInfo CoverSlotInfo;  // 0x0(0x18)
	struct FVector Location;  // 0x18(0xC)
	char pad_36[4];  // 0x24(0x4)
	struct AActor* Actor;  // 0x28(0x8)

}; 
// ScriptStruct AIFramework.FWRepathData
// Size: 0x8(Inherited: 0x0) 
struct FFWRepathData
{
	float PathDistance;  // 0x0(0x4)
	float GoalDistance;  // 0x4(0x4)

}; 
// ScriptStruct AIFramework.FWEncounterArchWhitelistEntry
// Size: 0x48(Inherited: 0x0) 
struct FFWEncounterArchWhitelistEntry
{
	float PercentagePerWave;  // 0x0(0x4)
	int32_t TotalSpawns;  // 0x4(0x4)
	UFWAIArchetype* Archetype;  // 0x8(0x8)
	ABaseCharacter* CharacterType;  // 0x10(0x8)
	struct FFWAIArchetypeVariation ArchetypeVariation;  // 0x18(0x20)
	UFWAIRank* Rank;  // 0x38(0x8)
	UFWAIFaction* Faction;  // 0x40(0x8)

}; 
// ScriptStruct AIFramework.AISpawnParams
// Size: 0x1A0(Inherited: 0x0) 
struct FAISpawnParams
{
	struct FFWAIArchetypeVariation ArchetypeVariation;  // 0x0(0x20)
	APawn* PawnClass;  // 0x20(0x8)
	AAIController* ControllerClass;  // 0x28(0x8)
	struct FSpawnParamsAI ParamsAI;  // 0x30(0x18)
	char pad_72[8];  // 0x48(0x8)
	struct FTransform SpawnCheckPoint;  // 0x50(0x30)
	struct TArray<struct FNameWrapper> LoadoutClasses;  // 0x80(0x10)
	struct FMontageAssetSelector SpawnAnimation;  // 0x90(0x20)
	struct AActor* Instigator;  // 0xB0(0x8)
	char pad_184_1 : 7;  // 0xB8(0x1)
	bool bSnapToGround : 1;  // 0xB8(0x1)
	char pad_185_1 : 7;  // 0xB9(0x1)
	bool bWaitForCustomization : 1;  // 0xB9(0x1)
	char pad_186_1 : 7;  // 0xBA(0x1)
	bool bNotifyAboutEndOfAnimation : 1;  // 0xBA(0x1)
	char ENavPathType NavigationPathType;  // 0xBB(0x1)
	char pad_188_1 : 7;  // 0xBC(0x1)
	bool bLaunchCharacter : 1;  // 0xBC(0x1)
	char pad_189[3];  // 0xBD(0x3)
	struct FVector LaunchDestination;  // 0xC0(0xC)
	float LaunchExtraHeightInMiddle;  // 0xCC(0x4)
	float LaunchGroundSpeed;  // 0xD0(0x4)
	char pad_212_1 : 7;  // 0xD4(0x1)
	bool bNotifyAboutEndOfLaunch : 1;  // 0xD4(0x1)
	char pad_213[3];  // 0xD5(0x3)
	struct FName AnimNotifyNameToWaitFor;  // 0xD8(0x8)
	int32_t UserData;  // 0xE0(0x4)
	char pad_228[4];  // 0xE4(0x4)
	struct TArray<struct AGoalPoint*> GoalsToAssign;  // 0xE8(0x10)
	char pad_248_1 : 7;  // 0xF8(0x1)
	bool bSpawnUsingSmartObject : 1;  // 0xF8(0x1)
	char pad_249_1 : 7;  // 0xF9(0x1)
	bool bNPCReactionsEnabled : 1;  // 0xF9(0x1)
	char pad_250_1 : 7;  // 0xFA(0x1)
	bool bSpawnWithWeaponFromStart : 1;  // 0xFA(0x1)
	char pad_251_1 : 7;  // 0xFB(0x1)
	bool bAutoAcquireEnemy : 1;  // 0xFB(0x1)
	char pad_252[100];  // 0xFC(0x64)
	struct ABaseCharacter* character;  // 0x160(0x8)
	struct AAIController* Controller;  // 0x168(0x8)
	char pad_368[48];  // 0x170(0x30)

}; 
// Function AIFramework.FWWaveSpawningSystem.GetNumberOfWavesStarted
// Size: 0x4(Inherited: 0x0) 
struct FGetNumberOfWavesStarted
{
	int32_t ReturnValue;  // 0x0(0x4)

}; 
// ScriptStruct AIFramework.SpawnParamsAI
// Size: 0x18(Inherited: 0x0) 
struct FSpawnParamsAI
{
	struct UBehaviorTree* BehaviorTree;  // 0x0(0x8)
	struct FGenericTeamId TeamID;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool bUseTeamId : 1;  // 0x9(0x1)
	char pad_10_1 : 7;  // 0xA(0x1)
	bool bDisableAI : 1;  // 0xA(0x1)
	char pad_11[1];  // 0xB(0x1)
	struct FName SquadName;  // 0xC(0x8)
	char pad_20[4];  // 0x14(0x4)

}; 
// Function AIFramework.BaseSmartObject.FinishSmartObjectUsage
// Size: 0x8(Inherited: 0x0) 
struct FFinishSmartObjectUsage
{
	struct USmartObjectSlotComponent* Slot;  // 0x0(0x8)

}; 
// Function AIFramework.GoalPoint.WillAcceptAIType
// Size: 0x10(Inherited: 0x0) 
struct FWillAcceptAIType
{
	UFWAIArchetype* Type;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function AIFramework.FWWaveSpawningSystem.StartWaveByNameWithDelay
// Size: 0xC(Inherited: 0x0) 
struct FStartWaveByNameWithDelay
{
	struct FName WaveName;  // 0x0(0x8)
	float Seconds;  // 0x8(0x4)

}; 
// ScriptStruct AIFramework.EQSQueryOverrideItem
// Size: 0x10(Inherited: 0x0) 
struct FEQSQueryOverrideItem
{
	struct UEnvQuery* EnvQuery;  // 0x0(0x8)
	uint8_t  QueryType;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function AIFramework.BaseSmartObject.OnSmartObjectNotify
// Size: 0x20(Inherited: 0x0) 
struct FOnSmartObjectNotify
{
	struct ABaseCharacter* CharacterUsingMe;  // 0x0(0x8)
	struct USmartObjectSlotComponent* Slot;  // 0x8(0x8)
	struct FName NotifyName;  // 0x10(0x8)
	uint8_t  NotifyType;  // 0x18(0x1)
	uint8_t  AttachPoint;  // 0x19(0x1)
	char pad_26[6];  // 0x1A(0x6)

}; 
// ScriptStruct AIFramework.SightTraceData
// Size: 0x38(Inherited: 0x0) 
struct FSightTraceData
{
	struct FFWPendingSightInfo SightCheck;  // 0x0(0x18)
	char pad_24[32];  // 0x18(0x20)

}; 
// Function AIFramework.CharacterSpawner.EnableGroup
// Size: 0x8(Inherited: 0x0) 
struct FEnableGroup
{
	int32_t GroupIndex;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool bEnable : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool bResetCounters : 1;  // 0x5(0x1)
	char pad_6[2];  // 0x6(0x2)

}; 
// ScriptStruct AIFramework.AIVisibilitySystemTickFunction
// Size: 0x120(Inherited: 0x118) 
struct FAIVisibilitySystemTickFunction : public FTickFunction
{
	char pad_280[8];  // 0x118(0x8)

}; 
// ScriptStruct AIFramework.MadAI_SingleThrowEntry
// Size: 0x20(Inherited: 0x0) 
struct FMadAI_SingleThrowEntry
{
	struct FMontageAssetSelector Montage;  // 0x0(0x20)

}; 
// ScriptStruct AIFramework.FWAIWeaponAnimationData
// Size: 0x268(Inherited: 0x0) 
struct FFWAIWeaponAnimationData
{
	struct FFWAIActionAnimationData ShootingType[4];  // 0x0(0x240)
	struct FSoftObjectPath DefaultShooting;  // 0x240(0x18)
	struct TArray<struct FSoftObjectPath> Dash;  // 0x258(0x10)

}; 
// ScriptStruct AIFramework.FWAIActionAnimationData
// Size: 0x90(Inherited: 0x0) 
struct FFWAIActionAnimationData
{
	struct FSoftObjectPath OneShotAnimations[6];  // 0x0(0x90)

}; 
// ScriptStruct AIFramework.FWAICoverActionAnimationData
// Size: 0x280(Inherited: 0x0) 
struct FFWAICoverActionAnimationData
{
	struct FSoftObjectPath LeanLeft[4];  // 0x0(0x60)
	struct FSoftObjectPath LeanRight[4];  // 0x60(0x60)
	struct FSoftObjectPath LeftPopUp[4];  // 0xC0(0x60)
	struct FSoftObjectPath RightPopUp[4];  // 0x120(0x60)
	struct TArray<struct FSoftObjectPath> CustomLeanLeft;  // 0x180(0x10)
	struct TArray<struct FSoftObjectPath> CustomLeanRight;  // 0x190(0x10)
	struct TArray<struct FSoftObjectPath> CustomLeftPopUp;  // 0x1A0(0x10)
	struct TArray<struct FSoftObjectPath> CustomRightPopUp;  // 0x1B0(0x10)
	struct TArray<struct FFWAICoverActionPeekHideAnimationData> PeekHideLeft;  // 0x1C0(0x10)
	struct TArray<struct FFWAICoverActionPeekHideAnimationData> PeekHideRight;  // 0x1D0(0x10)
	struct TArray<struct FFWAICoverActionPeekHideAnimationData> PeekHideUpLeft;  // 0x1E0(0x10)
	struct TArray<struct FFWAICoverActionPeekHideAnimationData> PeekHideUpRight;  // 0x1F0(0x10)
	struct FSoftObjectPath ChangeDirection;  // 0x200(0x18)
	struct FSoftObjectPath SlideToCoverMontage[4];  // 0x218(0x60)
	uint32_t ValidActionsSignature;  // 0x278(0x4)
	char pad_636[4];  // 0x27C(0x4)

}; 
// Function AIFramework.FWBlueprintLibrary.ForceCollisionOnCharacter
// Size: 0x18(Inherited: 0x0) 
struct FForceCollisionOnCharacter
{
	struct ABaseCharacter* Char;  // 0x0(0x8)
	struct FName Reason;  // 0x8(0x8)
	int32_t ReturnValue;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)

}; 
// Function AIFramework.ActionArea.GetExternalSpawner
// Size: 0x10(Inherited: 0x0) 
struct FGetExternalSpawner
{
	struct TArray<struct TSoftObjectPtr<ACharacterSpawner>> ReturnValue;  // 0x0(0x10)

}; 
// ScriptStruct AIFramework.FWAICoverActionPeekHideAnimationData
// Size: 0x30(Inherited: 0x0) 
struct FFWAICoverActionPeekHideAnimationData
{
	struct FSoftObjectPath Peek;  // 0x0(0x18)
	struct FSoftObjectPath Hide;  // 0x18(0x18)

}; 
// Function AIFramework.FWAIWeaponComponent.IsReloading
// Size: 0x1(Inherited: 0x0) 
struct FIsReloading
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// ScriptStruct AIFramework.FWArchetypesMapping
// Size: 0x10(Inherited: 0x0) 
struct FFWArchetypesMapping
{
	struct TArray<struct FFWArchetypesMappingReplacement> Replacements;  // 0x0(0x10)

}; 
// ScriptStruct AIFramework.FWArchetypesMappingReplacement
// Size: 0x18(Inherited: 0x0) 
struct FFWArchetypesMappingReplacement
{
	UFWAIArchetype* Source;  // 0x0(0x8)
	struct TArray<UFWAIArchetype*> Targets;  // 0x8(0x10)

}; 
// ScriptStruct AIFramework.FWEnvLine
// Size: 0x10(Inherited: 0x0) 
struct FFWEnvLine
{
	UEnvQueryContext* LineFrom;  // 0x0(0x8)
	UEnvQueryContext* LineTo;  // 0x8(0x8)

}; 
// ScriptStruct AIFramework.EncounterSetup
// Size: 0x20(Inherited: 0x0) 
struct FEncounterSetup
{
	struct FName EventName;  // 0x0(0x8)
	int32_t EncounterLevel;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct TArray<struct FFWEncounterWaveData> Waves;  // 0x10(0x10)

}; 
// Function AIFramework.FWAITask_PlaySpawnAnimation.OnOwnerKilled
// Size: 0x208(Inherited: 0x0) 
struct FOnOwnerKilled
{
	struct ABaseCharacter* character;  // 0x0(0x8)
	struct FTakeHitInfo TakeHitInfo;  // 0x8(0x200)

}; 
// Function AIFramework.FWAISquad.GetSquadMembersInRange
// Size: 0x28(Inherited: 0x0) 
struct FGetSquadMembersInRange
{
	struct AController* MemberToExclude;  // 0x0(0x8)
	struct FVector Origin;  // 0x8(0xC)
	float Radius;  // 0x14(0x4)
	struct TArray<struct AController*> OutControllers;  // 0x18(0x10)

}; 
// ScriptStruct AIFramework.FWEncounterSpawnGroupSetup
// Size: 0x20(Inherited: 0x0) 
struct FFWEncounterSpawnGroupSetup
{
	struct TArray<struct FFWEncounterArchWhitelistEntry> ArchetypesWhitelist;  // 0x0(0x10)
	struct TArray<ABaseCharacter*> CharactersWhitelist;  // 0x10(0x10)

}; 
// Function AIFramework.GoalPoint.OnCharacterSpawned
// Size: 0x18(Inherited: 0x0) 
struct FOnCharacterSpawned
{
	struct Acharacter* Pawn;  // 0x0(0x8)
	struct AFWAIController* Controller;  // 0x8(0x8)
	int32_t SpawnGroupIndex;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)

}; 
// ScriptStruct AIFramework.FWWaveDataOverride
// Size: 0x30(Inherited: 0x0) 
struct FFWWaveDataOverride
{
	struct FText Description;  // 0x0(0x18)
	struct TArray<struct FFWEncounterArchWhitelistEntry> ArchetypesWhitelist;  // 0x18(0x10)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool bUseTotal : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)

}; 
// ScriptStruct AIFramework.WssTransient
// Size: 0x78(Inherited: 0x0) 
struct FWssTransient
{
	struct TArray<struct ABaseCharacter*> LivingCharacters;  // 0x0(0x10)
	struct UBaseBiomeData* SelectedBiome;  // 0x10(0x8)
	struct TArray<struct APlayerCameraManager*> ActiveCameraManagers;  // 0x18(0x10)
	char pad_40[80];  // 0x28(0x50)

}; 
// ScriptStruct AIFramework.SpawnWaveData
// Size: 0x90(Inherited: 0x0) 
struct FSpawnWaveData
{
	struct FName WaveName;  // 0x0(0x8)
	struct TArray<struct FSpawnVariationData> SpawnVariations;  // 0x8(0x10)
	struct TArray<struct ASpawnVolume*> SpawnVolumes;  // 0x18(0x10)
	struct FIntPlayerCount SpawnQuantityPerInterval;  // 0x28(0xC)
	struct FFloatPlayerCount SpawnInterval;  // 0x34(0xC)
	struct FFloatPlayerCount IntervalDelta;  // 0x40(0xC)
	char pad_76[4];  // 0x4C(0x4)
	struct TArray<struct FIntPlayerCount> NotifiyCharactersCountKilled;  // 0x50(0x10)
	struct TArray<struct FFloatPlayerCount> NotifyAverageHealth;  // 0x60(0x10)
	struct FIntPlayerCount CharactersCountKilledToNotify;  // 0x70(0xC)
	struct FFloatPlayerCount AverageHealthToNotify;  // 0x7C(0xC)
	char pad_136_1 : 7;  // 0x88(0x1)
	bool bDisabled : 1;  // 0x88(0x1)
	char pad_137[7];  // 0x89(0x7)

}; 
// Function AIFramework.FWWaveSpawningSystem.StartWavesByNames
// Size: 0x20(Inherited: 0x0) 
struct FStartWavesByNames
{
	struct TArray<struct FName> WaveNamesToStart;  // 0x0(0x10)
	struct TArray<struct AFWWaveSpawningSystem*> ReturnValue;  // 0x10(0x10)

}; 
// ScriptStruct AIFramework.AntFarmControlAttributeState
// Size: 0x38(Inherited: 0x0) 
struct FAntFarmControlAttributeState
{
	struct FGameplayTagContainer AttributeTag;  // 0x0(0x20)
	float AttributeValue;  // 0x20(0x4)
	float CurrentWeightedValue;  // 0x24(0x4)
	struct TArray<struct USmartObjectSlotComponent*> CurrentSmartObjectsSlots;  // 0x28(0x10)

}; 
// ScriptStruct AIFramework.IntPlayerCount
// Size: 0xC(Inherited: 0x0) 
struct FIntPlayerCount
{
	int32_t One;  // 0x0(0x4)
	int32_t Two;  // 0x4(0x4)
	int32_t Three;  // 0x8(0x4)

}; 
// ScriptStruct AIFramework.SpawnVariationData
// Size: 0x38(Inherited: 0x0) 
struct FSpawnVariationData
{
	struct FIntPlayerCount Quantity;  // 0x0(0xC)
	char pad_12[4];  // 0xC(0x4)
	struct FFWAIArchetypeVariation Variation;  // 0x10(0x20)
	char pad_48[8];  // 0x30(0x8)

}; 
// Function AIFramework.BaseSmartObject.GetUsingCharacters
// Size: 0x18(Inherited: 0x0) 
struct FGetUsingCharacters
{
	struct TArray<struct ABaseCharacter*> OutCharacters;  // 0x0(0x10)
	int32_t ReturnValue;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)

}; 
// ScriptStruct AIFramework.AntFarmControlAttributeData
// Size: 0x30(Inherited: 0x0) 
struct FAntFarmControlAttributeData
{
	struct FGameplayTagContainer AttributeTag;  // 0x0(0x20)
	struct UCurveFloat* ControlCurve;  // 0x20(0x8)
	float ControlWeight;  // 0x28(0x4)
	char pad_44[4];  // 0x2C(0x4)

}; 
// ScriptStruct AIFramework.WaypointAutoConnectSettings
// Size: 0x20(Inherited: 0x0) 
struct FWaypointAutoConnectSettings
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bAutoConnect : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool bConnectBothWays : 1;  // 0x1(0x1)
	char pad_2[2];  // 0x2(0x2)
	float MaxConnectRange;  // 0x4(0x4)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bPreferIndirectConnection : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool bTraceCheckWithGeometry : 1;  // 0x9(0x1)
	char pad_10[6];  // 0xA(0x6)
	struct TArray<struct AWaypoint*> ExcludedWaypoints;  // 0x10(0x10)

}; 
// Function AIFramework.FWWaveSpawningSystem.GetNumberOfWavesKilled
// Size: 0x4(Inherited: 0x0) 
struct FGetNumberOfWavesKilled
{
	int32_t ReturnValue;  // 0x0(0x4)

}; 
// ScriptStruct AIFramework.WaypointConnection
// Size: 0x28(Inherited: 0x0) 
struct FWaypointConnection
{
	struct AWaypoint* End;  // 0x0(0x8)
	float Weight;  // 0x8(0x4)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool bCustomConnection : 1;  // 0xC(0x1)
	char pad_13_1 : 7;  // 0xD(0x1)
	bool bUseDisableExpr : 1;  // 0xD(0x1)
	char pad_14[2];  // 0xE(0x2)
	struct FFactExpression DisableExpr;  // 0x10(0x18)

}; 
// Function AIFramework.FWAIComponent.Client_PlayAnimWithCustomMovementMode
// Size: 0x18(Inherited: 0x0) 
struct FClient_PlayAnimWithCustomMovementMode
{
	struct UAnimMontage* Montage;  // 0x0(0x8)
	float PlayRate;  // 0x8(0x4)
	struct FName SectionToPlay;  // 0xC(0x8)
	char EMovementMode CustomMovementMode;  // 0x14(0x1)
	char pad_21[3];  // 0x15(0x3)

}; 
// Function AIFramework.BaseSmartObject.ShouldExecuteSmartObjectNotify
// Size: 0x20(Inherited: 0x0) 
struct FShouldExecuteSmartObjectNotify
{
	struct ABaseCharacter* CharacterUsingMe;  // 0x0(0x8)
	struct USmartObjectSlotComponent* Slot;  // 0x8(0x8)
	struct FName NotifyName;  // 0x10(0x8)
	uint8_t  NotifyType;  // 0x18(0x1)
	uint8_t  AttachPoint;  // 0x19(0x1)
	char pad_26_1 : 7;  // 0x1A(0x1)
	bool ReturnValue : 1;  // 0x1A(0x1)
	char pad_27[5];  // 0x1B(0x5)

}; 
// Function AIFramework.FWAIComponent.Client_PlayAntFarmAnimation
// Size: 0x10(Inherited: 0x0) 
struct FClient_PlayAntFarmAnimation
{
	struct UAnimMontage* Montage;  // 0x0(0x8)
	struct FName SectionName;  // 0x8(0x8)

}; 
// Function AIFramework.FWWaveSpawningSystem.GetEnemiesAliveByName
// Size: 0xC(Inherited: 0x0) 
struct FGetEnemiesAliveByName
{
	struct FName WaveName;  // 0x0(0x8)
	int32_t ReturnValue;  // 0x8(0x4)

}; 
// Function AIFramework.FWAIComponent.Client_SetupAnimWithCustomMovementMode
// Size: 0x10(Inherited: 0x0) 
struct FClient_SetupAnimWithCustomMovementMode
{
	struct UAnimMontage* Montage;  // 0x0(0x8)
	char EMovementMode CustomMovementMode;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool EnableCorrectionOnClient : 1;  // 0x9(0x1)
	char pad_10_1 : 7;  // 0xA(0x1)
	bool bDisableCollision : 1;  // 0xA(0x1)
	char pad_11[5];  // 0xB(0x5)

}; 
// Function AIFramework.FWAIComponent.CustomMovementModeAnimEnded
// Size: 0x10(Inherited: 0x0) 
struct FCustomMovementModeAnimEnded
{
	struct UAnimMontage* Montage;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bInterrupted : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function AIFramework.FWAIComponent.GetAimLocation
// Size: 0xC(Inherited: 0x0) 
struct FGetAimLocation
{
	struct FVector ReturnValue;  // 0x0(0xC)

}; 
// Function AIFramework.FWAIComponent.GetController
// Size: 0x8(Inherited: 0x0) 
struct FGetController
{
	struct AFWAIController* ReturnValue;  // 0x0(0x8)

}; 
// Function AIFramework.FWAIComponent.HasAuthority
// Size: 0x1(Inherited: 0x0) 
struct FHasAuthority
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function AIFramework.FWAIComponent.IsAimLocationUsed
// Size: 0x1(Inherited: 0x0) 
struct FIsAimLocationUsed
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function AIFramework.AISpawnSubsystem.OnAITaskEnded
// Size: 0x10(Inherited: 0x0) 
struct FOnAITaskEnded
{
	struct UFWAITask* Task;  // 0x0(0x8)
	uint8_t  Result;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function AIFramework.FWAIComponent.IsUsingControllerDesiredRotation
// Size: 0x1(Inherited: 0x0) 
struct FIsUsingControllerDesiredRotation
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function AIFramework.FWBlueprintLibrary.PredictActorLocation
// Size: 0x28(Inherited: 0x0) 
struct FPredictActorLocation
{
	struct APawn* Pawn;  // 0x0(0x8)
	float PredictionTime;  // 0x8(0x4)
	float PredictionMaxDistance;  // 0xC(0x4)
	struct FVector ExtraExtent;  // 0x10(0xC)
	struct FVector ReturnValue;  // 0x1C(0xC)

}; 
// Function AIFramework.FWAIComponent.MulticastSpawnParticleAtLocation
// Size: 0x50(Inherited: 0x0) 
struct FMulticastSpawnParticleAtLocation
{
	struct UWorld* World;  // 0x0(0x8)
	struct UParticleSystem* EmitterTemplate;  // 0x8(0x8)
	struct FTransform SpawnTransform;  // 0x10(0x30)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool bAutoDestroy : 1;  // 0x40(0x1)
	uint8_t  PoolingMethod;  // 0x41(0x1)
	char pad_66[14];  // 0x42(0xE)

}; 
// Function AIFramework.FWAIComponent.OnAnimMontageEnded
// Size: 0x10(Inherited: 0x0) 
struct FOnAnimMontageEnded
{
	struct UAnimMontage* Montage;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bInterrupted : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function AIFramework.FWAIComponent.SetAimOffset
// Size: 0x8(Inherited: 0x0) 
struct FSetAimOffset
{
	struct FVector2D Offset;  // 0x0(0x8)

}; 
// Function AIFramework.BaseSmartObject.GetLoopMontageEvent
// Size: 0x30(Inherited: 0x0) 
struct FGetLoopMontageEvent
{
	struct AAIController* AI;  // 0x0(0x8)
	struct USmartObjectSlotComponent* Slot;  // 0x8(0x8)
	struct FMontageAssetSelector ReturnValue;  // 0x10(0x20)

}; 
// Function AIFramework.BaseGoalTarget.K2_SetTeam
// Size: 0x1(Inherited: 0x0) 
struct FK2_SetTeam
{
	char ETeam NewTeam;  // 0x0(0x1)

}; 
// Function AIFramework.FWEncounterManager.GetNumCharactersAlive
// Size: 0x4(Inherited: 0x0) 
struct FGetNumCharactersAlive
{
	int32_t ReturnValue;  // 0x0(0x4)

}; 
// Function AIFramework.FWAIComponent.SetFocalPoint
// Size: 0xC(Inherited: 0x0) 
struct FSetFocalPoint
{
	struct FVector InFocalPoint;  // 0x0(0xC)

}; 
// Function AIFramework.FWAIResponseChannel.IsSuppressed
// Size: 0x1(Inherited: 0x0) 
struct FIsSuppressed
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function AIFramework.FWAIResponse.ReceiveExecution
// Size: 0x8(Inherited: 0x0) 
struct FReceiveExecution
{
	struct UFWAIResponseChannel* SourceChannel;  // 0x0(0x8)

}; 
// Function AIFramework.FWAIResChannel_AbilityTag.GetTagStatus
// Size: 0xC(Inherited: 0x0) 
struct FGetTagStatus
{
	struct FWAIResChannel_AbilityTagStatus ReturnValue;  // 0x0(0xC)

}; 
// Function AIFramework.FWAISquad.GetRandomMemberFromSquadOtherThanGiven
// Size: 0x10(Inherited: 0x0) 
struct FGetRandomMemberFromSquadOtherThanGiven
{
	struct AController* MemberToExclude;  // 0x0(0x8)
	struct AController* ReturnValue;  // 0x8(0x8)

}; 
// Function AIFramework.FWAISquad.GetSquadLeadaer
// Size: 0x8(Inherited: 0x0) 
struct FGetSquadLeadaer
{
	struct AController* ReturnValue;  // 0x0(0x8)

}; 
// Function AIFramework.AIRoute.OnActorPostEditMove
// Size: 0x8(Inherited: 0x0) 
struct FOnActorPostEditMove
{
	struct AActor* Actor;  // 0x0(0x8)

}; 
// Function AIFramework.FWAISquad.GetSquadMembers
// Size: 0x10(Inherited: 0x0) 
struct FGetSquadMembers
{
	struct TArray<struct AController*> SquadMembers;  // 0x0(0x10)

}; 
// Function AIFramework.FWAIResponseComponent.SuppressResponseChannelByType
// Size: 0x8(Inherited: 0x0) 
struct FSuppressResponseChannelByType
{
	UFWAIResponseChannel* Type;  // 0x0(0x8)

}; 
// Function AIFramework.FWAISquad.UnregisterSquadMember
// Size: 0x8(Inherited: 0x0) 
struct FUnregisterSquadMember
{
	struct AController* OldMember;  // 0x0(0x8)

}; 
// Function AIFramework.FWAISystem.AddAvoidPoint
// Size: 0x28(Inherited: 0x0) 
struct FAddAvoidPoint
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct FVector InCentre;  // 0x8(0xC)
	float InRadius;  // 0x14(0x4)
	float InHalfHeight;  // 0x18(0x4)
	float InTimeToLive;  // 0x1C(0x4)
	int32_t InGroupMask;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)

}; 
// Function AIFramework.FWAIResponseChannel.IsActive
// Size: 0x1(Inherited: 0x0) 
struct FIsActive
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function AIFramework.FWAISystem.ConditionalCreateSquad
// Size: 0x20(Inherited: 0x0) 
struct FConditionalCreateSquad
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct FName SquadName;  // 0x8(0x8)
	struct AFWAIController* AI;  // 0x10(0x8)
	struct UFWAISquad* ReturnValue;  // 0x18(0x8)

}; 
// Function AIFramework.FWAISystem.GetAISquadByName
// Size: 0x18(Inherited: 0x0) 
struct FGetAISquadByName
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct FName SquadName;  // 0x8(0x8)
	struct UFWAISquad* ReturnValue;  // 0x10(0x8)

}; 
// Function AIFramework.FWEncounterManager.AssignSetup
// Size: 0x8(Inherited: 0x0) 
struct FAssignSetup
{
	struct UFWEncounterData* InEncounterSetup;  // 0x0(0x8)

}; 
// Function AIFramework.FWAISystem.GetCharactersInRange
// Size: 0x28(Inherited: 0x0) 
struct FGetCharactersInRange
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct AActor* CenterActor;  // 0x8(0x8)
	float RadiusAroundCenterActor;  // 0x10(0x4)
	char ETeam Team;  // 0x14(0x1)
	char pad_21_1 : 7;  // 0x15(0x1)
	bool bIncludeCenterActorInResult : 1;  // 0x15(0x1)
	char pad_22[2];  // 0x16(0x2)
	struct TArray<struct AActor*> OutFoundCharacters;  // 0x18(0x10)

}; 
// Function AIFramework.FWBackpackComponent.OnComponentsMaterialGroupReset
// Size: 0x10(Inherited: 0x0) 
struct FOnComponentsMaterialGroupReset
{
	struct UMeshComponent* MeshComponent;  // 0x0(0x8)
	uint8_t  SlotType;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function AIFramework.FWBackpackComponent.GetBackpackHealth
// Size: 0x4(Inherited: 0x0) 
struct FGetBackpackHealth
{
	float ReturnValue;  // 0x0(0x4)

}; 
// Function AIFramework.FWBackpackComponent.OnComponentsMaterialGroupApplied
// Size: 0x18(Inherited: 0x0) 
struct FOnComponentsMaterialGroupApplied
{
	struct UMeshComponent* MeshComponent;  // 0x0(0x8)
	struct FName GroupName;  // 0x8(0x8)
	uint8_t  SlotType;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function AIFramework.BaseCharacterMovementComponent.GetMovementMoodSpeed
// Size: 0x8(Inherited: 0x0) 
struct FGetMovementMoodSpeed
{
	uint8_t  Mood;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	float ReturnValue;  // 0x4(0x4)

}; 
// Function AIFramework.BaseCharacterMovementComponent.IsUsingNewAnimationSystem
// Size: 0x1(Inherited: 0x0) 
struct FIsUsingNewAnimationSystem
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function AIFramework.BaseCharacterMovementComponent.OverrideMovementMoodSpeed
// Size: 0x8(Inherited: 0x0) 
struct FOverrideMovementMoodSpeed
{
	uint8_t  Mood;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	float Speed;  // 0x4(0x4)

}; 
// Function AIFramework.FWAIResponseComponent.NudgeChannelByName
// Size: 0x8(Inherited: 0x0) 
struct FNudgeChannelByName
{
	struct FName ChannelName;  // 0x0(0x8)

}; 
// Function AIFramework.CharacterSpawner.IsAllowedToSpawn
// Size: 0x1B0(Inherited: 0x0) 
struct FIsAllowedToSpawn
{
	struct FAISpawnParams SpawnParams;  // 0x0(0x1A0)
	char pad_416_1 : 7;  // 0x1A0(0x1)
	bool ReturnValue : 1;  // 0x1A0(0x1)
	char pad_417[15];  // 0x1A1(0xF)

}; 
// Function AIFramework.CharacterSpawner.IsSpawnerEnabled
// Size: 0x1(Inherited: 0x0) 
struct FIsSpawnerEnabled
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function AIFramework.FWAIReactionEpicentre.OnTaskEnded
// Size: 0x10(Inherited: 0x0) 
struct FOnTaskEnded
{
	struct UFWAITask* Task;  // 0x0(0x8)
	uint8_t  Result;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function AIFramework.CharacterSpawner.RequestSpawnAI
// Size: 0x88(Inherited: 0x0) 
struct FRequestSpawnAI
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct FFWAIArchetypeVariation ArchetypeVariation;  // 0x8(0x20)
	struct FVector SpawnLocation;  // 0x28(0xC)
	struct FRotator SpawnRotation;  // 0x34(0xC)
	struct TArray<struct FNameWrapper> CustomLoadoutClasses;  // 0x40(0x10)
	struct FMontageAssetSelector Montage;  // 0x50(0x20)
	char ETeam Team;  // 0x70(0x1)
	char pad_113[7];  // 0x71(0x7)
	struct AActor* SpawnInstigator;  // 0x78(0x8)
	char pad_128_1 : 7;  // 0x80(0x1)
	bool bDisableCollision : 1;  // 0x80(0x1)
	char pad_129[7];  // 0x81(0x7)

}; 
// Function AIFramework.FWWaveSpawningSystem.OnCharacterKilledHandler
// Size: 0x208(Inherited: 0x0) 
struct FOnCharacterKilledHandler
{
	struct ABaseCharacter* character;  // 0x0(0x8)
	struct FTakeHitInfo TakeHitInfo;  // 0x8(0x200)

}; 
// Function AIFramework.FWPathFollowingComponent.OnMantleTaskEnded
// Size: 0x10(Inherited: 0x0) 
struct FOnMantleTaskEnded
{
	struct UFWAITask* Task;  // 0x0(0x8)
	uint8_t  Result;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function AIFramework.FWEncounterManager.EnableEncounter
// Size: 0x1(Inherited: 0x0) 
struct FEnableEncounter
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bEnable : 1;  // 0x0(0x1)

}; 
// Function AIFramework.FWEncounterManager.EnqueueAdditionalSpawn
// Size: 0x10(Inherited: 0x0) 
struct FEnqueueAdditionalSpawn
{
	struct ACharacterSpawner* Spawner;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bIncreaseLimits : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool ReturnValue : 1;  // 0x9(0x1)
	char pad_10[6];  // 0xA(0x6)

}; 
// Function AIFramework.FWEncounterManager.ForceNextWave
// Size: 0x1(Inherited: 0x0) 
struct FForceNextWave
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function AIFramework.FWAIWeaponComponent.GetActiveWeapon
// Size: 0x8(Inherited: 0x0) 
struct FGetActiveWeapon
{
	struct AWeapon* ReturnValue;  // 0x0(0x8)

}; 
// Function AIFramework.FWEncounterManager.GetCurrentSetup
// Size: 0x20(Inherited: 0x0) 
struct FGetCurrentSetup
{
	struct FEncounterSetup ReturnValue;  // 0x0(0x20)

}; 
// Function AIFramework.FWEncounterManager.GetCurrentWaveIndex
// Size: 0x4(Inherited: 0x0) 
struct FGetCurrentWaveIndex
{
	int32_t ReturnValue;  // 0x0(0x4)

}; 
// Function AIFramework.FWWaveSpawningSystem.AbilityStartWaveByNameFromCurrentWss
// Size: 0x10(Inherited: 0x0) 
struct FAbilityStartWaveByNameFromCurrentWss
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct FName WaveName;  // 0x8(0x8)

}; 
// Function AIFramework.FWEncounterManager.GetNumCharactersLeft
// Size: 0x4(Inherited: 0x0) 
struct FGetNumCharactersLeft
{
	int32_t ReturnValue;  // 0x0(0x4)

}; 
// Function AIFramework.FWEncounterManager.GetSpawnsPerWave
// Size: 0x4(Inherited: 0x0) 
struct FGetSpawnsPerWave
{
	int32_t ReturnValue;  // 0x0(0x4)

}; 
// Function AIFramework.FWEncounterData.GetWave
// Size: 0xB0(Inherited: 0x0) 
struct FGetWave
{
	int32_t Idx;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FFWEncounterWaveData ReturnValue;  // 0x8(0xA8)

}; 
// Function AIFramework.FWEncounterManager.IsAvailable
// Size: 0x1(Inherited: 0x0) 
struct FIsAvailable
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function AIFramework.FWEncounterManager.IsEncounterCompleted
// Size: 0x1(Inherited: 0x0) 
struct FIsEncounterCompleted
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function AIFramework.FWAIWeaponComponent.AllowReload
// Size: 0x1(Inherited: 0x0) 
struct FAllowReload
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Allow : 1;  // 0x0(0x1)

}; 
// Function AIFramework.FWEncounterManager.OnArenaSwitchedOn
// Size: 0x10(Inherited: 0x0) 
struct FOnArenaSwitchedOn
{
	struct ACombatArena* CombatArena;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bSwitchedByTriggerVolume : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function AIFramework.FWEncounterManager.OnSpawned
// Size: 0x1C0(Inherited: 0x0) 
struct FOnSpawned
{
	struct AActor* InInstigator;  // 0x0(0x8)
	struct ACharacterSpawner* Spawner;  // 0x8(0x8)
	struct AAIController* Controller;  // 0x10(0x8)
	struct APawn* Pawn;  // 0x18(0x8)
	struct FAISpawnParams AISpawnParams;  // 0x20(0x1A0)

}; 
// Function AIFramework.FWEncounterManager.ResetEncounter
// Size: 0x18(Inherited: 0x0) 
struct FResetEncounter
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct FName InEncounterName;  // 0x8(0x8)
	struct AFWEncounterManager* Encounter;  // 0x10(0x8)

}; 
// Function AIFramework.FWEncounterManager.SetConditionAsValid
// Size: 0x1(Inherited: 0x0) 
struct FSetConditionAsValid
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bForceRestart : 1;  // 0x0(0x1)

}; 
// Function AIFramework.SpawnVolume.SetSpawnVolumeEnabled
// Size: 0x1(Inherited: 0x0) 
struct FSetSpawnVolumeEnabled
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bEnabled : 1;  // 0x0(0x1)

}; 
// Function AIFramework.FWEncounterManager.SetEncounterCompleted
// Size: 0x1(Inherited: 0x0) 
struct FSetEncounterCompleted
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bCompleted : 1;  // 0x0(0x1)

}; 
// Function AIFramework.FWEncounterManager.StopEncounter
// Size: 0x18(Inherited: 0x0) 
struct FStopEncounter
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct FName InEncounterName;  // 0x8(0x8)
	struct AFWEncounterManager* Encounter;  // 0x10(0x8)

}; 
// Function AIFramework.FWPathFollowingComponent.GetDestinationActor
// Size: 0x8(Inherited: 0x0) 
struct FGetDestinationActor
{
	struct AActor* ReturnValue;  // 0x0(0x8)

}; 
// Function AIFramework.FWPathFollowingComponent.OnJumpTaskEnded
// Size: 0x10(Inherited: 0x0) 
struct FOnJumpTaskEnded
{
	struct UFWAITask* Task;  // 0x0(0x8)
	uint8_t  Result;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function AIFramework.FWWaveSpawningSystem.GetEnemiesKilledByName
// Size: 0xC(Inherited: 0x0) 
struct FGetEnemiesKilledByName
{
	struct FName WaveName;  // 0x0(0x8)
	int32_t ReturnValue;  // 0x8(0x4)

}; 
// Function AIFramework.FWWaveSpawningSystem.GetEnemiesKilledOverall
// Size: 0x4(Inherited: 0x0) 
struct FGetEnemiesKilledOverall
{
	int32_t ReturnValue;  // 0x0(0x4)

}; 
// Function AIFramework.FWWaveSpawningSystem.GetNumberOfWavesNotStarted
// Size: 0x4(Inherited: 0x0) 
struct FGetNumberOfWavesNotStarted
{
	int32_t ReturnValue;  // 0x0(0x4)

}; 
// Function AIFramework.FWWaveSpawningSystem.GetTimesWaveStarted
// Size: 0x8(Inherited: 0x0) 
struct FGetTimesWaveStarted
{
	int32_t WaveIndex;  // 0x0(0x4)
	int32_t ReturnValue;  // 0x4(0x4)

}; 
// Function AIFramework.FWWaveSpawningSystem.GetWaveIndex
// Size: 0xC(Inherited: 0x0) 
struct FGetWaveIndex
{
	struct FName WaveName;  // 0x0(0x8)
	int32_t ReturnValue;  // 0x8(0x4)

}; 
// Function AIFramework.FWWaveSpawningSystem.GetWaveName
// Size: 0xC(Inherited: 0x0) 
struct FGetWaveName
{
	int32_t WaveIndex;  // 0x0(0x4)
	struct FName ReturnValue;  // 0x4(0x8)

}; 
// Function AIFramework.CombatArena.UseInternalSpawnPoints
// Size: 0x1(Inherited: 0x0) 
struct FUseInternalSpawnPoints
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Use : 1;  // 0x0(0x1)

}; 
// Function AIFramework.FWWaveSpawningSystem.IsWaveByNameKilled
// Size: 0xC(Inherited: 0x0) 
struct FIsWaveByNameKilled
{
	struct FName WaveName;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)

}; 
// Function AIFramework.FWWaveSpawningSystem.IsWaveKilled
// Size: 0x8(Inherited: 0x0) 
struct FIsWaveKilled
{
	int32_t WaveIndex;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool ReturnValue : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)

}; 
// Function AIFramework.AntFarmGoal.K2_GetNextSmartObject
// Size: 0x18(Inherited: 0x0) 
struct FK2_GetNextSmartObject
{
	struct AFWAIController* Querier;  // 0x0(0x8)
	struct ABaseSmartObject* InSmartObject;  // 0x8(0x8)
	struct ABaseSmartObject* ReturnValue;  // 0x10(0x8)

}; 
// Function AIFramework.CombatArena.OnServerRespawnPlayerHandler
// Size: 0x1(Inherited: 0x0) 
struct FOnServerRespawnPlayerHandler
{
	uint8_t  RespawnReason;  // 0x0(0x1)

}; 
// Function AIFramework.SmartObjectSlotComponent.IsEnabled
// Size: 0x1(Inherited: 0x0) 
struct FIsEnabled
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function AIFramework.FWWaveSpawningSystem.OnSpawnVolumeStateChanged
// Size: 0x8(Inherited: 0x0) 
struct FOnSpawnVolumeStateChanged
{
	struct ASpawnVolume* Volume;  // 0x0(0x8)

}; 
// Function AIFramework.FWWaveSpawningSystem.Print
// Size: 0x18(Inherited: 0x0) 
struct FPrint
{
	struct FString Message;  // 0x0(0x10)
	uint8_t  Type;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function AIFramework.FWWaveSpawningSystem.ResetWave
// Size: 0x10(Inherited: 0x0) 
struct FResetWave
{
	int32_t WaveIndex;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AFWWaveSpawningSystem* ReturnValue;  // 0x8(0x8)

}; 
// Function AIFramework.FWAIWeaponComponent.EnableProjectileCalculations
// Size: 0x1(Inherited: 0x0) 
struct FEnableProjectileCalculations
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bEnable : 1;  // 0x0(0x1)

}; 
// Function AIFramework.FWWaveSpawningSystem.ShutdownCurrentWss
// Size: 0x8(Inherited: 0x0) 
struct FShutdownCurrentWss
{
	struct UObject* WorldContextObject;  // 0x0(0x8)

}; 
// Function AIFramework.FWWaveSpawningSystem.StaticPrint
// Size: 0x20(Inherited: 0x0) 
struct FStaticPrint
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct FString Message;  // 0x8(0x10)
	uint8_t  Type;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)

}; 
// Function AIFramework.GoalPoint.GetGoalRadius
// Size: 0x4(Inherited: 0x0) 
struct FGetGoalRadius
{
	float ReturnValue;  // 0x0(0x4)

}; 
// Function AIFramework.AISpawnSubsystem.StartContinuousSpawnInRadius
// Size: 0x38(Inherited: 0x0) 
struct FStartContinuousSpawnInRadius
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct FVector Origin;  // 0x8(0xC)
	float Radius;  // 0x14(0x4)
	float Frequency;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct TArray<ABaseCharacter*> CharactersWhitelist;  // 0x20(0x10)
	int32_t MaxSpawnsPerWave;  // 0x30(0x4)
	char pad_52_1 : 7;  // 0x34(0x1)
	bool ReturnValue : 1;  // 0x34(0x1)
	char pad_53[3];  // 0x35(0x3)

}; 
// Function AIFramework.AISpawnSubsystem.StopContinuousSpawnInRadius
// Size: 0x8(Inherited: 0x0) 
struct FStopContinuousSpawnInRadius
{
	struct UObject* WorldContextObject;  // 0x0(0x8)

}; 
// Function AIFramework.AITask_LaunchCharacter.OnLandedCallback
// Size: 0x90(Inherited: 0x0) 
struct FOnLandedCallback
{
	struct FHitResult Hit;  // 0x0(0x90)

}; 
// Function AIFramework.FWCharacterCache.OnBiomeUnloadDEBUG
// Size: 0x10(Inherited: 0x0) 
struct FOnBiomeUnloadDEBUG
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct UBaseBiomeData* Biome;  // 0x8(0x8)

}; 
// Function AIFramework.GoalPoint.GetAssignedAIs
// Size: 0x10(Inherited: 0x0) 
struct FGetAssignedAIs
{
	struct TArray<struct AFWAIController*> ReturnValue;  // 0x0(0x10)

}; 
// Function AIFramework.GoalPoint.GetBounds
// Size: 0x1C(Inherited: 0x0) 
struct FGetBounds
{
	struct FBox ReturnValue;  // 0x0(0x1C)

}; 
// Function AIFramework.GoalPoint.GetFollowers
// Size: 0x10(Inherited: 0x0) 
struct FGetFollowers
{
	struct TArray<struct AFWAIController*> ReturnValue;  // 0x0(0x10)

}; 
// Function AIFramework.GoalPoint.OnFollowerDied
// Size: 0x8(Inherited: 0x0) 
struct FOnFollowerDied
{
	struct AAIController* AI;  // 0x0(0x8)

}; 
// Function AIFramework.GoalPoint.OnRevertGoalSpecificAIBehavior
// Size: 0x8(Inherited: 0x0) 
struct FOnRevertGoalSpecificAIBehavior
{
	struct AFWAIController* AI;  // 0x0(0x8)

}; 
// Function AIFramework.GoalPoint.OnSetupGoalSpecificAIBehavior
// Size: 0x8(Inherited: 0x0) 
struct FOnSetupGoalSpecificAIBehavior
{
	struct AFWAIController* AI;  // 0x0(0x8)

}; 
// Function AIFramework.GoalPoint.RegisterFollower
// Size: 0x10(Inherited: 0x0) 
struct FRegisterFollower
{
	struct AAIController* NewAI;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bCheckToAccept : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool ReturnValue : 1;  // 0x9(0x1)
	char pad_10[6];  // 0xA(0x6)

}; 
// Function AIFramework.GoalPoint.UnregisterFollower
// Size: 0x8(Inherited: 0x0) 
struct FUnregisterFollower
{
	struct AAIController* AI;  // 0x0(0x8)

}; 
// Function AIFramework.BaseGoalTarget.GetMaxHealth
// Size: 0x4(Inherited: 0x0) 
struct FGetMaxHealth
{
	float ReturnValue;  // 0x0(0x4)

}; 
// Function AIFramework.BaseGoalTarget.K2_GetTeam
// Size: 0x1(Inherited: 0x0) 
struct FK2_GetTeam
{
	char ETeam ReturnValue;  // 0x0(0x1)

}; 
// Function AIFramework.BaseGoalTarget.SetHealth
// Size: 0x4(Inherited: 0x0) 
struct FSetHealth
{
	float InHealth;  // 0x0(0x4)

}; 
// Function AIFramework.SmartObjectSlotComponent.IsInUse
// Size: 0x1(Inherited: 0x0) 
struct FIsInUse
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function AIFramework.BaseSmartObject.CanStartSynchronization
// Size: 0x1(Inherited: 0x0) 
struct FCanStartSynchronization
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function AIFramework.BaseSmartObject.GetEnterMontageEvent
// Size: 0x30(Inherited: 0x0) 
struct FGetEnterMontageEvent
{
	struct AAIController* AI;  // 0x0(0x8)
	struct USmartObjectSlotComponent* Slot;  // 0x8(0x8)
	struct FMontageAssetSelector ReturnValue;  // 0x10(0x20)

}; 
// Function AIFramework.FWAIWeaponComponent.ForceFireAtTarget
// Size: 0x1(Inherited: 0x0) 
struct FForceFireAtTarget
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Force : 1;  // 0x0(0x1)

}; 
// Function AIFramework.BaseSmartObject.GetExitMontageEvent
// Size: 0x30(Inherited: 0x0) 
struct FGetExitMontageEvent
{
	struct AAIController* AI;  // 0x0(0x8)
	struct USmartObjectSlotComponent* Slot;  // 0x8(0x8)
	struct FMontageAssetSelector ReturnValue;  // 0x10(0x20)

}; 
// Function AIFramework.BaseSmartObject.GetForceOutMontageEvent
// Size: 0x30(Inherited: 0x0) 
struct FGetForceOutMontageEvent
{
	struct AAIController* AI;  // 0x0(0x8)
	struct USmartObjectSlotComponent* Slot;  // 0x8(0x8)
	struct FMontageAssetSelector ReturnValue;  // 0x10(0x20)

}; 
// Function AIFramework.BaseSmartObject.GetSyncLoopMontageEvent
// Size: 0x30(Inherited: 0x0) 
struct FGetSyncLoopMontageEvent
{
	struct AAIController* AI;  // 0x0(0x8)
	struct USmartObjectSlotComponent* Slot;  // 0x8(0x8)
	struct FMontageAssetSelector ReturnValue;  // 0x10(0x20)

}; 
// Function AIFramework.FWAnimationProxyDataEnemy.OnMontagesPreloaded
// Size: 0x10(Inherited: 0x0) 
struct FOnMontagesPreloaded
{
	struct TArray<struct FSoftObjectPath> LoadedAssets;  // 0x0(0x10)

}; 
// Function AIFramework.BaseSmartObject.OnSmartObjectEnded
// Size: 0x8(Inherited: 0x0) 
struct FOnSmartObjectEnded
{
	struct USmartObjectSlotComponent* Slot;  // 0x0(0x8)

}; 
// Function AIFramework.BaseSmartObject.OnSmartObjectSkippedEnter
// Size: 0x10(Inherited: 0x0) 
struct FOnSmartObjectSkippedEnter
{
	struct ABaseCharacter* CharacterUsingMe;  // 0x0(0x8)
	struct USmartObjectSlotComponent* Slot;  // 0x8(0x8)

}; 
// Function AIFramework.BaseSmartObject.OnSmartObjectStarted
// Size: 0x10(Inherited: 0x0) 
struct FOnSmartObjectStarted
{
	struct ABaseCharacter* CharacterUsingMe;  // 0x0(0x8)
	struct USmartObjectSlotComponent* Slot;  // 0x8(0x8)

}; 
// Function AIFramework.BTTask_UseSmartObject.OnSmartObjectFinished
// Size: 0x8(Inherited: 0x0) 
struct FOnSmartObjectFinished
{
	struct USmartObjectSlotComponent* Slot;  // 0x0(0x8)

}; 
// Function AIFramework.FWCharacterCache.OnBiomeLoadDEBUG
// Size: 0x18(Inherited: 0x0) 
struct FOnBiomeLoadDEBUG
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct UBaseBiomeData* Biome;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bIsWorldBiome : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function AIFramework.CombatArena.OnReffedTriggerTouch
// Size: 0x10(Inherited: 0x0) 
struct FOnReffedTriggerTouch
{
	struct AActor* OverlappedActor;  // 0x0(0x8)
	struct AActor* OtherActor;  // 0x8(0x8)

}; 
// Function AIFramework.CombatArena.TriggerFallback
// Size: 0x1(Inherited: 0x0) 
struct FTriggerFallback
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bRecursiveParentFallback : 1;  // 0x0(0x1)

}; 
// Function AIFramework.FWAIAimAttractorsInterface.GetAttractors
// Size: 0x18(Inherited: 0x0) 
struct FGetAttractors
{
	struct TArray<struct FVector> OutAttractors;  // 0x0(0x10)
	struct AFWAIController* Instigator;  // 0x10(0x8)

}; 
// Function AIFramework.FWAIGameplayAbilityInterface.CanHitTarget
// Size: 0x18(Inherited: 0x0) 
struct FCanHitTarget
{
	struct ABaseCharacter* Source;  // 0x0(0x8)
	struct AActor* Target;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bUseIdealYawRotationToTarget : 1;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool ReturnValue : 1;  // 0x11(0x1)
	char pad_18[6];  // 0x12(0x6)

}; 
// Function AIFramework.FWAIPerceptionComponent.GetCallForHelpRating
// Size: 0x10(Inherited: 0x0) 
struct FGetCallForHelpRating
{
	struct AActor* Actor;  // 0x0(0x8)
	float ReturnValue;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)

}; 
// Function AIFramework.FWAIPerceptionComponent.GetRecentDamageTakenFromActor
// Size: 0x10(Inherited: 0x0) 
struct FGetRecentDamageTakenFromActor
{
	struct AActor* Actor;  // 0x0(0x8)
	float ReturnValue;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)

}; 
// Function AIFramework.FWAIReactionActor.AttachReactionToActor
// Size: 0x8(Inherited: 0x0) 
struct FAttachReactionToActor
{
	struct AActor* TargetActor;  // 0x0(0x8)

}; 
// Function AIFramework.FWAIRes_StepAside.OnMantle
// Size: 0x18(Inherited: 0x0) 
struct FOnMantle
{
	struct FVector EventOrigin;  // 0x0(0xC)
	char pad_12[4];  // 0xC(0x4)
	struct ABaseCharacter* InstigatorCharacter;  // 0x10(0x8)

}; 
// Function AIFramework.FWAIResponseChannel.ReceiveTick
// Size: 0x4(Inherited: 0x0) 
struct FReceiveTick
{
	float DeltaSeconds;  // 0x0(0x4)

}; 
// Function AIFramework.FWAIResponseComponent.NudgeChannelByClass
// Size: 0x8(Inherited: 0x0) 
struct FNudgeChannelByClass
{
	UFWAIResponseChannel* ChannelClass;  // 0x0(0x8)

}; 
// Function AIFramework.FWAIWeaponComponent.OnActorHit
// Size: 0x90(Inherited: 0x0) 
struct FOnActorHit
{
	struct FHitResult Impact;  // 0x0(0x90)

}; 
// Function AIFramework.FWAIResponseComponent.OnOwnerEndPlay
// Size: 0x10(Inherited: 0x0) 
struct FOnOwnerEndPlay
{
	struct AActor* Actor;  // 0x0(0x8)
	char EEndPlayReason EndPlayReason;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function AIFramework.FWAIResponseComponent.SuppressResponsesByType
// Size: 0x8(Inherited: 0x0) 
struct FSuppressResponsesByType
{
	UFWAIResponse* Type;  // 0x0(0x8)

}; 
// Function AIFramework.FWAIResponseComponent.UnSuppressResponseChannelByType
// Size: 0x8(Inherited: 0x0) 
struct FUnSuppressResponseChannelByType
{
	UFWAIResponseChannel* Type;  // 0x0(0x8)

}; 
// Function AIFramework.FWAIResponseComponent.UnSuppressResponsesByType
// Size: 0x8(Inherited: 0x0) 
struct FUnSuppressResponsesByType
{
	UFWAIResponse* Type;  // 0x0(0x8)

}; 
// Function AIFramework.FWAIWeaponComponent.AllowWeaponFiring
// Size: 0x1(Inherited: 0x0) 
struct FAllowWeaponFiring
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Allow : 1;  // 0x0(0x1)

}; 
// Function AIFramework.FWAIWeaponComponent.EquipWeapon
// Size: 0x2(Inherited: 0x0) 
struct FEquipWeapon
{
	uint8_t  Slot;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool ReturnValue : 1;  // 0x1(0x1)

}; 
// Function AIFramework.FWAIWeaponComponent.GetActiveWeaponSlot
// Size: 0x1(Inherited: 0x0) 
struct FGetActiveWeaponSlot
{
	uint8_t  ReturnValue;  // 0x0(0x1)

}; 
// Function AIFramework.FWAIWeaponComponent.IsAutoFiringEnabled
// Size: 0x1(Inherited: 0x0) 
struct FIsAutoFiringEnabled
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function AIFramework.FWAIWeaponComponent.IsValidTrajectory
// Size: 0x1(Inherited: 0x0) 
struct FIsValidTrajectory
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function AIFramework.FWAIWeaponComponent.SetPendingWeapon
// Size: 0x2(Inherited: 0x0) 
struct FSetPendingWeapon
{
	uint8_t  Slot;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool ReturnValue : 1;  // 0x1(0x1)

}; 
// Function AIFramework.FWBlueprintLibrary.RestoreDefaultCollisionOnCharacter
// Size: 0x10(Inherited: 0x0) 
struct FRestoreDefaultCollisionOnCharacter
{
	struct ABaseCharacter* Char;  // 0x0(0x8)
	int32_t ID;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)

}; 
// Function AIFramework.FWAIWeaponComponent.UnequipWeapon
// Size: 0x1(Inherited: 0x0) 
struct FUnequipWeapon
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function AIFramework.FWBlueprintLibrary.CheckNavLOS
// Size: 0x40(Inherited: 0x0) 
struct FCheckNavLOS
{
	struct APawn* Pawn;  // 0x0(0x8)
	struct FVector Start;  // 0x8(0xC)
	struct FVector Destination;  // 0x14(0xC)
	struct FVector HitLocation;  // 0x20(0xC)
	struct FVector ExtraExtent;  // 0x2C(0xC)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool ReturnValue : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)

}; 
// Function AIFramework.FWBlueprintLibrary.GenerateRandomNonOverlappingCirclesInCircle
// Size: 0x20(Inherited: 0x0) 
struct FGenerateRandomNonOverlappingCirclesInCircle
{
	float InnerCircleRadius;  // 0x0(0x4)
	float SpaceBetweenCircles;  // 0x4(0x4)
	float OuterCircleRadius;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct TArray<struct FVector2D> OutPoints;  // 0x10(0x10)

}; 
// Function AIFramework.FWBlueprintLibrary.HasDirectNavPath
// Size: 0x30(Inherited: 0x0) 
struct FHasDirectNavPath
{
	struct APawn* Pawn;  // 0x0(0x8)
	struct FVector Destination;  // 0x8(0xC)
	struct FVector DirectPathEnd;  // 0x14(0xC)
	struct FVector ExtraExtent;  // 0x20(0xC)
	char pad_44_1 : 7;  // 0x2C(0x1)
	bool ReturnValue : 1;  // 0x2C(0x1)
	char pad_45[3];  // 0x2D(0x3)

}; 
// Function AIFramework.FWBlueprintLibrary.K2_GetBestHitInfoFromDamage
// Size: 0xC0(Inherited: 0x0) 
struct FK2_GetBestHitInfoFromDamage
{
	struct FDamageEvent Event;  // 0x0(0x10)
	struct AActor* HitActor;  // 0x10(0x8)
	struct AActor* HitInstigator;  // 0x18(0x8)
	struct FHitResult OutHitInfo;  // 0x20(0x90)
	struct FVector OutImpulseDir;  // 0xB0(0xC)
	char pad_188[4];  // 0xBC(0x4)

}; 
// Function AIFramework.FWBlueprintLibrary.K2_GetCharacterLocationAfterMontage
// Size: 0x40(Inherited: 0x0) 
struct FK2_GetCharacterLocationAfterMontage
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct Acharacter* character;  // 0x8(0x8)
	struct FMontageAssetSelector MontageAsset;  // 0x10(0x20)
	struct FVector ReturnValue;  // 0x30(0xC)
	char pad_60[4];  // 0x3C(0x4)

}; 
// Function AIFramework.FWBlueprintLibrary.K2_GetCharacterRotationAfterMontage
// Size: 0x40(Inherited: 0x0) 
struct FK2_GetCharacterRotationAfterMontage
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct Acharacter* character;  // 0x8(0x8)
	struct FMontageAssetSelector MontageAsset;  // 0x10(0x20)
	struct FRotator ReturnValue;  // 0x30(0xC)
	char pad_60[4];  // 0x3C(0x4)

}; 
// Function AIFramework.FWBlueprintLibrary.K2_GetRootMotionWorldSpaceTranslation
// Size: 0x40(Inherited: 0x0) 
struct FK2_GetRootMotionWorldSpaceTranslation
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct Acharacter* character;  // 0x8(0x8)
	struct FMontageAssetSelector MontageAsset;  // 0x10(0x20)
	struct FVector OutAnimTranslation;  // 0x30(0xC)
	char pad_60[4];  // 0x3C(0x4)

}; 
// Function AIFramework.FWBlueprintLibrary.K2_GetValidAnimations
// Size: 0x38(Inherited: 0x0) 
struct FK2_GetValidAnimations
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct ABaseCharacter* character;  // 0x8(0x8)
	struct TArray<struct FMontageAssetSelector> Animations;  // 0x10(0x10)
	struct TArray<struct FMontageAssetSelector> ValidAnimations;  // 0x20(0x10)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool TestNavmesh : 1;  // 0x30(0x1)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool TestColision : 1;  // 0x31(0x1)
	char ECollisionChannel Channel;  // 0x32(0x1)
	char pad_51[5];  // 0x33(0x5)

}; 
// Function AIFramework.FWBlueprintLibrary.K2_SelectRandomValidAnimation
// Size: 0x48(Inherited: 0x0) 
struct FK2_SelectRandomValidAnimation
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct ABaseCharacter* character;  // 0x8(0x8)
	struct TArray<struct FMontageAssetSelector> Animations;  // 0x10(0x10)
	struct FMontageAssetSelector Montage;  // 0x20(0x20)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool TestNavmesh : 1;  // 0x40(0x1)
	char pad_65_1 : 7;  // 0x41(0x1)
	bool TestColision : 1;  // 0x41(0x1)
	char ECollisionChannel Channel;  // 0x42(0x1)
	char pad_67[5];  // 0x43(0x5)

}; 
// Function AIFramework.FWBlueprintLibrary.MakeCoverSlotInfo
// Size: 0x28(Inherited: 0x0) 
struct FMakeCoverSlotInfo
{
	struct ACoverBase* InHotSpot;  // 0x0(0x8)
	int32_t InSlotIndex;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct FCoverSlotInfo ReturnValue;  // 0x10(0x18)

}; 
// Function AIFramework.FWBlueprintLibrary.PredictActorLocationForVelocity
// Size: 0x38(Inherited: 0x0) 
struct FPredictActorLocationForVelocity
{
	struct APawn* Pawn;  // 0x0(0x8)
	float PredictionTime;  // 0x8(0x4)
	float PredictionMaxDistance;  // 0xC(0x4)
	struct FVector InVelocity;  // 0x10(0xC)
	struct FVector ExtraExtent;  // 0x1C(0xC)
	struct FVector ReturnValue;  // 0x28(0xC)
	char pad_52[4];  // 0x34(0x4)

}; 
// Function AIFramework.FWLinkedActorsInterface.LinkActor
// Size: 0x10(Inherited: 0x0) 
struct FLinkActor
{
	struct AActor* Actor;  // 0x0(0x8)
	int32_t ReturnValue;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)

}; 
// Function AIFramework.FWLinkedActorsInterface.LinkActors
// Size: 0x18(Inherited: 0x0) 
struct FLinkActors
{
	struct TArray<struct AActor*> Actors;  // 0x0(0x10)
	int32_t ReturnValue;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)

}; 
// Function AIFramework.FWLinkedActorsInterface.UnlinkActor
// Size: 0x10(Inherited: 0x0) 
struct FUnlinkActor
{
	struct AActor* Actor;  // 0x0(0x8)
	int32_t ReturnValue;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)

}; 
// Function AIFramework.FWLinkedActorsInterface.UnlinkAllActors
// Size: 0x4(Inherited: 0x0) 
struct FUnlinkAllActors
{
	int32_t ReturnValue;  // 0x0(0x4)

}; 
// Function AIFramework.FWSplinePathFollowingComponent.SplineOnJumpDownTaskEnded
// Size: 0x10(Inherited: 0x0) 
struct FSplineOnJumpDownTaskEnded
{
	struct UFWAITask* Task;  // 0x0(0x8)
	uint8_t  Result;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function AIFramework.SpawnVolume.UseWithEncounterManager
// Size: 0x1(Inherited: 0x0) 
struct FUseWithEncounterManager
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bShouldBeUsed : 1;  // 0x0(0x1)

}; 
