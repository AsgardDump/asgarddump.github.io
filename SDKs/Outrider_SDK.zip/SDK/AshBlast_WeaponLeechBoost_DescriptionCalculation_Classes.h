#pragma once 
#include <AshBlast_WeaponLeechBoost_DescriptionCalculation_Structs.h>
 
 
 
// BlueprintGeneratedClass AshBlast_WeaponLeechBoost_DescriptionCalculation.AshBlast_WeaponLeechBoost_DescriptionCalculation_C
// Size: 0x28(Inherited: 0x28) 
struct UAshBlast_WeaponLeechBoost_DescriptionCalculation_C : public UMadSkillDataObject
{

	float GetSecondaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function AshBlast_WeaponLeechBoost_DescriptionCalculation.AshBlast_WeaponLeechBoost_DescriptionCalculation_C.GetSecondaryExtraData
	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function AshBlast_WeaponLeechBoost_DescriptionCalculation.AshBlast_WeaponLeechBoost_DescriptionCalculation_C.GetPrimaryExtraData
}; 



