#pragma once 
#include "SDK.h" 
 
 
// Function BP_ExtraEquip_Minigun.BP_ExtraEquip_Minigun_C.ExecuteUbergraph_BP_ExtraEquip_Minigun
// Size: 0x4(Inherited: 0x0) 
struct FExecuteUbergraph_BP_ExtraEquip_Minigun
{
	int32_t EntryPoint;  // 0x0(0x4)

}; 
