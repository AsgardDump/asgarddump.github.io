#pragma once 
#include <ATDLC03_Structs.h>
 
 
 
// BlueprintGeneratedClass ATDLC03.ATDLC03_C
// Size: 0x28(Inherited: 0x28) 
struct UATDLC03_C : public UMadSkillDataObject
{

	float GetTertiaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function ATDLC03.ATDLC03_C.GetTertiaryExtraData
	float GetSecondaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function ATDLC03.ATDLC03_C.GetSecondaryExtraData
	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function ATDLC03.ATDLC03_C.GetPrimaryExtraData
}; 



