#pragma once 
#include <ANDLC01_Structs.h>
 
 
 
// BlueprintGeneratedClass ANDLC01.ANDLC01_C
// Size: 0x28(Inherited: 0x28) 
struct UANDLC01_C : public UMadSkillDataObject
{

	float GetQuaternaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function ANDLC01.ANDLC01_C.GetQuaternaryExtraData
	float GetTertiaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function ANDLC01.ANDLC01_C.GetTertiaryExtraData
	float GetSecondaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function ANDLC01.ANDLC01_C.GetSecondaryExtraData
	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function ANDLC01.ANDLC01_C.GetPrimaryExtraData
}; 



