#pragma once 
#include <AIFramework_Structs.h>
 
 
 
// Class AIFramework.FWNavTestRenderingComponent
// Size: 0x510(Inherited: 0x510) 
struct UFWNavTestRenderingComponent : public UNavTestRenderingComponent
{

}; 



// Class AIFramework.FWAIResChannel_HeavyDamage
// Size: 0x48(Inherited: 0x48) 
struct UFWAIResChannel_HeavyDamage : public UFWAIResChannel_Damage
{

}; 



// Class AIFramework.BakedNavLink
// Size: 0x360(Inherited: 0x320) 
struct ABakedNavLink : public AActor
{
	char pad_800[8];  // 0x320(0x8)
	struct FVector Left;  // 0x328(0xC)
	struct FVector Right;  // 0x334(0xC)
	UNavArea* NavArea;  // 0x340(0x8)
	struct FNavAgentSelector SupportedAgents;  // 0x348(0x4)
	char ENavLinkDirection Direction;  // 0x34C(0x1)
	char pad_845[3];  // 0x34D(0x3)
	struct UNavLinkRenderingComponent* EdRenderComp;  // 0x350(0x8)
	struct UBillboardComponent* SpriteComponent;  // 0x358(0x8)

}; 



// Class AIFramework.PawnAction_FollowRoute
// Size: 0xD8(Inherited: 0xC0) 
struct UPawnAction_FollowRoute : public UPawnAction_Sequence
{
	char pad_192[24];  // 0xC0(0x18)

}; 



// Class AIFramework.AIRoute
// Size: 0x380(Inherited: 0x348) 
struct AAIRoute : public ANavigationObjectBase
{
	uint8_t  RouteType;  // 0x348(0x1)
	char pad_841[7];  // 0x349(0x7)
	struct TArray<struct AActor*> RouteList;  // 0x350(0x10)
	char bDrawWithoutSelection : 1;  // 0x360(0x1)
	char pad_864_1 : 7;  // 0x360(0x1)
	char pad_865[8];  // 0x361(0x8)
	struct UBillboardComponent* SpriteComponent;  // 0x368(0x8)
	struct FMulticastInlineDelegate OnMoveFinishedEvent;  // 0x370(0x10)

	void OnMoveFinished(struct AFWAIController* AI, struct ABaseCharacter* character, char EPawnActionResult WithResult); // Function AIFramework.AIRoute.OnMoveFinished
	void OnActorPostEditMove(struct AActor* Actor); // Function AIFramework.AIRoute.OnActorPostEditMove
}; 



// Class AIFramework.FWAnimNotifyState
// Size: 0x40(Inherited: 0x38) 
struct UFWAnimNotifyState : public UAnimNotifyState
{
	struct FName TagName;  // 0x38(0x8)

}; 



// Class AIFramework.FWAIRes_Perception
// Size: 0x70(Inherited: 0x70) 
struct UFWAIRes_Perception : public UFWAIResponse
{

}; 



// Class AIFramework.AIRouteNode
// Size: 0x358(Inherited: 0x348) 
struct AAIRouteNode : public ANavigationObjectBase
{
	struct UAnimMontage* CustomWaitAnimation;  // 0x348(0x8)
	struct UBillboardComponent* SpriteComponent;  // 0x350(0x8)

}; 



// Class AIFramework.FWAnimNotify
// Size: 0x40(Inherited: 0x38) 
struct UFWAnimNotify : public UAnimNotify
{
	struct FName TagName;  // 0x38(0x8)

}; 



// Class AIFramework.FWAIWeaponComponent
// Size: 0x358(Inherited: 0x1A8) 
struct UFWAIWeaponComponent : public UActorComponent
{
	char pad_424_1 : 7;  // 0x1A8(0x1)
	char bAutoFiringDisabled : 1;  // 0x1A8(0x1)
	char pad_425[55];  // 0x1A9(0x37)
	struct UFWAIWeaponAnimationDataAsset* AIWeaponAnimationDataAsset;  // 0x1E0(0x8)
	struct FFWProjectileController ProjectileController;  // 0x1E8(0x150)
	uint8_t  ActiveWeaponSlot;  // 0x338(0x1)
	char pad_825[7];  // 0x339(0x7)
	struct AWeapon* WeaponSlots[3];  // 0x340(0x18)

	bool UnequipWeapon(); // Function AIFramework.FWAIWeaponComponent.UnequipWeapon
	void TryStopFireImmediately(); // Function AIFramework.FWAIWeaponComponent.TryStopFireImmediately
	void ThrowGrenade(); // Function AIFramework.FWAIWeaponComponent.ThrowGrenade
	void SetProjectileClass(AProjectile* ProjectileClass); // Function AIFramework.FWAIWeaponComponent.SetProjectileClass
	bool SetPendingWeapon(uint8_t  Slot); // Function AIFramework.FWAIWeaponComponent.SetPendingWeapon
	void OnActorHit(struct FHitResult& Impact); // Function AIFramework.FWAIWeaponComponent.OnActorHit
	bool NeedsReload(); // Function AIFramework.FWAIWeaponComponent.NeedsReload
	bool IsValidTrajectory(); // Function AIFramework.FWAIWeaponComponent.IsValidTrajectory
	bool IsReloading(); // Function AIFramework.FWAIWeaponComponent.IsReloading
	bool IsAutoFiringEnabled(); // Function AIFramework.FWAIWeaponComponent.IsAutoFiringEnabled
	struct AWeapon* GetWeapon(uint8_t  Slot); // Function AIFramework.FWAIWeaponComponent.GetWeapon
	uint8_t  GetActiveWeaponSlot(); // Function AIFramework.FWAIWeaponComponent.GetActiveWeaponSlot
	struct AWeapon* GetActiveWeapon(); // Function AIFramework.FWAIWeaponComponent.GetActiveWeapon
	void ForceFireAtTarget(bool Force); // Function AIFramework.FWAIWeaponComponent.ForceFireAtTarget
	bool EquipWeapon(uint8_t  Slot); // Function AIFramework.FWAIWeaponComponent.EquipWeapon
	void EnableProjectileCalculations(bool bEnable); // Function AIFramework.FWAIWeaponComponent.EnableProjectileCalculations
	void EnableAutoFiring(bool bEnable); // Function AIFramework.FWAIWeaponComponent.EnableAutoFiring
	void DropProjectileAway(float MinDistance, float MaxDistance, float ExtraHeight, struct Acharacter* PawnInstigatorOverride); // Function AIFramework.FWAIWeaponComponent.DropProjectileAway
	void DropProjectile(); // Function AIFramework.FWAIWeaponComponent.DropProjectile
	void CheckLOS(bool bCheck); // Function AIFramework.FWAIWeaponComponent.CheckLOS
	void AllowWeaponFiring(bool Allow); // Function AIFramework.FWAIWeaponComponent.AllowWeaponFiring
	void AllowReload(bool Allow); // Function AIFramework.FWAIWeaponComponent.AllowReload
}; 



// Class AIFramework.FWAIDamageReactionRenderingComponent
// Size: 0x510(Inherited: 0x510) 
struct UFWAIDamageReactionRenderingComponent : public UPrimitiveComponent
{

}; 



// Class AIFramework.ActionAreaRenderingComponent
// Size: 0x510(Inherited: 0x510) 
struct UActionAreaRenderingComponent : public UPrimitiveComponent
{

}; 



// Class AIFramework.AITask_PlayAnimation
// Size: 0xD0(Inherited: 0x98) 
struct UAITask_PlayAnimation : public UFWAITask
{
	char pad_152[16];  // 0x98(0x10)
	struct UAnimMontage* MontageToPlay;  // 0xA8(0x8)
	char pad_176[32];  // 0xB0(0x20)

}; 



// Class AIFramework.FWAIController
// Size: 0xBC8(Inherited: 0x440) 
struct AFWAIController : public ABaseAIController
{
	char pad_1088[32];  // 0x440(0x20)
	struct UBehaviorTree* DefaultBehaviorTree;  // 0x460(0x8)
	struct UChatterAIMapping* ChatterMapping;  // 0x468(0x8)
	UFWAISquad* DesiredAISquadClass;  // 0x470(0x8)
	float MaxAISquadMeleeRadius;  // 0x478(0x4)
	float MinDistanceToGenerateMidPoints;  // 0x47C(0x4)
	float MidPointGenerationRadiusInCloseDistance;  // 0x480(0x4)
	float MidPointGenerationMinVelocityInCloseDistance;  // 0x484(0x4)
	struct UFWAISquad* MySquad;  // 0x488(0x8)
	char ETeam DefaultTeam;  // 0x490(0x1)
	char pad_1169[7];  // 0x491(0x7)
	struct TArray<struct FLocalEnemyInfo> LocalEnemyList;  // 0x498(0x10)
	float AITeamStimulusRange;  // 0x4A8(0x4)
	char pad_1196[4];  // 0x4AC(0x4)
	struct FTakeHitInfo LastHitInfo;  // 0x4B0(0x200)
	struct FHitResult LastHitResult;  // 0x6B0(0x90)
	float LastTakeDamageTime;  // 0x740(0x4)
	float LastCombatActionTime;  // 0x744(0x4)
	float LastMeleeHitTime;  // 0x748(0x4)
	float LastCombatHitTime;  // 0x74C(0x4)
	float LastGrenadeAttackTime;  // 0x750(0x4)
	float CoverEnterTime;  // 0x754(0x4)
	float CoverCombatStartTime;  // 0x758(0x4)
	float LevelOfDanger;  // 0x75C(0x4)
	char pad_1888_1 : 7;  // 0x760(0x1)
	bool bUseTargetSelectCurrentTargetDecay : 1;  // 0x760(0x1)
	char pad_1889_1 : 7;  // 0x761(0x1)
	bool bUseTargetSelectDamageThreat : 1;  // 0x761(0x1)
	char pad_1890[2];  // 0x762(0x2)
	float CurrentTargetMaxDuration;  // 0x764(0x4)
	float CurrentTargetMinDuration;  // 0x768(0x4)
	float CurrentTargetMinScore;  // 0x76C(0x4)
	char pad_1904[4];  // 0x770(0x4)
	float MaxThreatOnDamageFraction;  // 0x774(0x4)
	float TotalThreatLoseDuration;  // 0x778(0x4)
	float ThreatRegenRate;  // 0x77C(0x4)
	float ThreatMaxPlayer;  // 0x780(0x4)
	float ThreatMaxAI;  // 0x784(0x4)
	float ThreatGainOnProximityPlayer;  // 0x788(0x4)
	float ThreatGainOnProximityAI;  // 0x78C(0x4)
	float ThreatProximityDistance;  // 0x790(0x4)
	float MaxGroupThreatDistance;  // 0x794(0x4)
	float GroupThreatLoseDuration;  // 0x798(0x4)
	float HeavyDamageTimeLimit;  // 0x79C(0x4)
	float HeavyDamageThresholdPct;  // 0x7A0(0x4)
	char bChangeTargetsDuringAction : 1;  // 0x7A4(0x1)
	char bSquadBasedEnemySelection : 1;  // 0x7A4(0x1)
	char bCallOnPreNewEnemySet : 1;  // 0x7A4(0x1)
	char bCallOnPostNewEnemySet : 1;  // 0x7A4(0x1)
	char bEventOnTargetChange : 1;  // 0x7A4(0x1)
	char pad_1956_1 : 3;  // 0x7A4(0x1)
	char pad_1957[4];  // 0x7A5(0x4)
	float NextTargetSelectionTime;  // 0x7A8(0x4)
	float TargetSelectionInterval;  // 0x7AC(0x4)
	struct TArray<struct FFWForceFireRequest> ForceFireRequests;  // 0x7B0(0x10)
	struct TArray<struct AActor*> TargetList;  // 0x7C0(0x10)
	struct TArray<struct AActor*> ProhibitedTargetList;  // 0x7D0(0x10)
	struct AActor* SquadAssignedTarget;  // 0x7E0(0x8)
	float NextAllowedSquadTargetAssignment;  // 0x7E8(0x4)
	char pad_2028[4];  // 0x7EC(0x4)
	struct AActor* FireTarget;  // 0x7F0(0x8)
	struct AActor* SelectedFireTarget;  // 0x7F8(0x8)
	struct ABaseCharacter* Enemy;  // 0x800(0x8)
	struct FEQSParametrizedQueryExecutionRequest EQSEnemySelectionRequest;  // 0x808(0x48)
	char pad_2128[8];  // 0x850(0x8)
	struct TMap<struct AActor*, float> TargetingStartTimes;  // 0x858(0x50)
	char pad_2216[40];  // 0x8A8(0x28)
	float ShootingMeExtraHeight;  // 0x8D0(0x4)
	float ShootingMeDistance;  // 0x8D4(0x4)
	float ShootingMeCoverDistance;  // 0x8D8(0x4)
	char pad_2268[4];  // 0x8DC(0x4)
	struct UFWAIResponseComponent* ResponseComponent;  // 0x8E0(0x8)
	struct TArray<UFWAIResponse*> ResponseClasses;  // 0x8E8(0x10)
	struct TArray<struct UFWAIResponse*> ActiveResponses;  // 0x8F8(0x10)
	char pad_2312[128];  // 0x908(0x80)
	struct UFWAIWeaponComponent* WeaponComponent;  // 0x988(0x8)
	char pad_2448_1 : 7;  // 0x990(0x1)
	bool bUseAimLocation : 1;  // 0x990(0x1)
	char pad_2449[3];  // 0x991(0x3)
	struct FVector2D BurstDuration;  // 0x994(0x8)
	struct FVector2D ReFireDelay;  // 0x99C(0x8)
	float ValidFireDot;  // 0x9A4(0x4)
	float LOSLastSensedLocationMaxDistance;  // 0x9A8(0x4)
	float LOSLastSensedLocationMaxAgeInSeconds;  // 0x9AC(0x4)
	char pad_2480[33];  // 0x9B0(0x21)
	char pad_2513_1 : 7;  // 0x9D1(0x1)
	bool bUseMeleeFrontalHit : 1;  // 0x9D1(0x1)
	char pad_2514[2];  // 0x9D2(0x2)
	float MeleeFrontalHitDistance;  // 0x9D4(0x4)
	float MeleeFrontalFOV;  // 0x9D8(0x4)
	char pad_2524[4];  // 0x9DC(0x4)
	struct TArray<struct UFWAnimNotifyState_MeleeAttack*> SuccessfulMeleeStates;  // 0x9E0(0x10)
	struct TArray<struct FMeleeAttackHitData> SuccessfulMeleeTargets;  // 0x9F0(0x10)
	struct AAIRoute* ScriptedRoute;  // 0xA00(0x8)
	struct AGoalPoint* CurrentGoalPoint;  // 0xA08(0x8)
	struct USmartObjectUserState* SmartObjectUserState;  // 0xA10(0x8)
	struct ACombatArena* MyCombatArena;  // 0xA18(0x8)
	char bShouldFollowGoals : 1;  // 0xA20(0x1)
	char pad_2592_1 : 7;  // 0xA20(0x1)
	char pad_2593[24];  // 0xA21(0x18)
	char pad_2616_1 : 7;  // 0xA38(0x1)
	bool bSupportCombatArena : 1;  // 0xA38(0x1)
	char pad_2617[7];  // 0xA39(0x7)
	struct FMulticastInlineDelegate OnSmartObjectNotifyBegin;  // 0xA40(0x10)
	UFWAITask_MantleOverCover* MantleOverCoverTask;  // 0xA50(0x8)
	UFWAITask_MantleOverCover* ClimbCoverTask;  // 0xA58(0x8)
	UFWAITask_Jump* JumpTask;  // 0xA60(0x8)
	char pad_2664_1 : 7;  // 0xA68(0x1)
	bool bSupportFlanking : 1;  // 0xA68(0x1)
	char pad_2665[3];  // 0xA69(0x3)
	float MinTimeInValidCoverWhileFlanking;  // 0xA6C(0x4)
	float MinTimeToStayInCoverAfterBeingTargeted;  // 0xA70(0x4)
	float MinFlankingAngle;  // 0xA74(0x4)
	struct UFWCoveringComponent* CoveringComponent;  // 0xA78(0x8)
	char pad_2688[8];  // 0xA80(0x8)
	UAITask_MoveTo* ClassOfMoveToTask;  // 0xA88(0x8)
	char bDisableStringPullingForPaths : 1;  // 0xA90(0x1)
	char bAllowTurnInPlace : 1;  // 0xA90(0x1)
	char bLimitControlRotationByThreshold : 1;  // 0xA90(0x1)
	char pad_2704_1 : 5;  // 0xA90(0x1)
	char pad_2705[4];  // 0xA91(0x4)
	float ControlRotationThreshold;  // 0xA94(0x4)
	float ControlRotationPrecision;  // 0xA98(0x4)
	char pad_2716[76];  // 0xA9C(0x4C)
	struct FMulticastInlineDelegate OnAnimNotify;  // 0xAE8(0x10)
	struct UFWAIMetrics* AIMetrics;  // 0xAF8(0x8)
	char pad_2816_1 : 7;  // 0xB00(0x1)
	bool bSendBattleEvent : 1;  // 0xB00(0x1)
	char pad_2817[7];  // 0xB01(0x7)
	struct TArray<struct FVector> EQSPointsOfInterest;  // 0xB08(0x10)
	UFWAIArchetype* AIArchetype;  // 0xB18(0x8)
	struct UEnvQuery* UsedEQSQueries[c];  // 0xB20(0x60)
	struct AController* ExplosionCauser;  // 0xB80(0x8)
	struct UFWAIComponent* BaseAIComponent;  // 0xB88(0x8)
	struct ABaseCharacter* MyBaseCharacter;  // 0xB90(0x8)
	UFWAIComponent* AIComponentClass;  // 0xB98(0x8)
	struct UPCFAnimReplication* AnimReplication;  // 0xBA0(0x8)
	char pad_2984[16];  // 0xBA8(0x10)
	struct UFWAIDamageReactionComponent* DamageReactionComp;  // 0xBB8(0x8)
	char pad_3008_1 : 7;  // 0xBC0(0x1)
	bool bEnableAntFarmMovementOptimization : 1;  // 0xBC0(0x1)
	char pad_3009[7];  // 0xBC1(0x7)

	void UpdateLastTakeDamageTime(); // Function AIFramework.FWAIController.UpdateLastTakeDamageTime
	void UpdateLastMeleeHitTime(); // Function AIFramework.FWAIController.UpdateLastMeleeHitTime
	void UpdateLastGrenadeAttackTime(); // Function AIFramework.FWAIController.UpdateLastGrenadeAttackTime
	void UpdateLastCombatHitTime(); // Function AIFramework.FWAIController.UpdateLastCombatHitTime
	void UpdateLastCombatActionTime(); // Function AIFramework.FWAIController.UpdateLastCombatActionTime
	void UpdateCoverEnterTime(); // Function AIFramework.FWAIController.UpdateCoverEnterTime
	void TickMeleeAttack(struct FString SocketNames, struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation, float FrameDeltaTime, struct TArray<struct FVector>& PreviousSensorLocations, struct TArray<struct FVector>& CurrentSensorLocations, UDamageType* DamageTypeClass, struct FName TagName, struct UFWAnimNotifyState_MeleeAttack* AnimNotify, bool bAllowHittingMultipleTargets); // Function AIFramework.FWAIController.TickMeleeAttack
	void SetScriptedSelectionPriority(float ScriptedSelectionPriority, struct AActor* InEnemy); // Function AIFramework.FWAIController.SetScriptedSelectionPriority
	void SetGoalActor(struct AGoalPoint* InGoalActor); // Function AIFramework.FWAIController.SetGoalActor
	void SetEnemyThreat(float Threat, struct AActor* InEnemy); // Function AIFramework.FWAIController.SetEnemyThreat
	void SetCustomLocation(struct FVector& InCustomLocation); // Function AIFramework.FWAIController.SetCustomLocation
	void SetCurrentSmartObjectSlot(struct USmartObjectSlotComponent* InSmartObjectSlot); // Function AIFramework.FWAIController.SetCurrentSmartObjectSlot
	bool SetBehaviorTag(uint8_t  Tag); // Function AIFramework.FWAIController.SetBehaviorTag
	bool RespondTo(struct FName ChatterID, struct AActor* Source); // Function AIFramework.FWAIController.RespondTo
	void ResetScriptedSelectionPriority(struct AActor* InEnemy); // Function AIFramework.FWAIController.ResetScriptedSelectionPriority
	void ResetScriptedSelectionPrioritiesForAll(); // Function AIFramework.FWAIController.ResetScriptedSelectionPrioritiesForAll
	bool RequestMovementMood(uint8_t  NewMood); // Function AIFramework.FWAIController.RequestMovementMood
	void RequestChatter(uint8_t  Type); // Function AIFramework.FWAIController.RequestChatter
	void PostponePathUpdates(bool Postpone); // Function AIFramework.FWAIController.PostponePathUpdates
	void OnWaponHit(struct AActor* InstigatorActor, struct FHitResult& HitInfo, UDamageType* DamageType, float Damage); // Function AIFramework.FWAIController.OnWaponHit
	void OnStoppedBeingTargetBy(struct AActor* TargetInstigator); // Function AIFramework.FWAIController.OnStoppedBeingTargetBy
	void OnStartedBeingTargetBy(struct AActor* TargetInstigator); // Function AIFramework.FWAIController.OnStartedBeingTargetBy
	void OnLethalHitEvent(struct ABaseCharacter* EnemyCharacter, struct FTakeHitInfo TakeHitInfo); // Function AIFramework.FWAIController.OnLethalHitEvent
	void OnEnemyKilled(struct ABaseCharacter* ControllerOwner, struct FTakeHitInfo TakeHitInfo); // Function AIFramework.FWAIController.OnEnemyKilled
	void OnEnemyHealthBelowZero(struct ABaseCharacter* ControllerOwner); // Function AIFramework.FWAIController.OnEnemyHealthBelowZero
	void OnEnemyDeath(struct ABaseCharacter* EnemyCharacter); // Function AIFramework.FWAIController.OnEnemyDeath
	void OnDamageEvent(struct ABaseCharacter* EnemyCharacter, struct FTakeHitInfo TakeHitInfo); // Function AIFramework.FWAIController.OnDamageEvent
	void K2_SetIgnoreReactions(bool bIgnore, struct FString DebugReason); // Function AIFramework.FWAIController.K2_SetIgnoreReactions
	void K2_RequestForceFire(struct UObject* Source, struct TArray<struct AActor*>& inTargets, bool bInForceContinuousFire, bool bRequireLOS); // Function AIFramework.FWAIController.K2_RequestForceFire
	void K2_HandleDeath(); // Function AIFramework.FWAIController.K2_HandleDeath
	bool K2_AreReactionsIgnored(); // Function AIFramework.FWAIController.K2_AreReactionsIgnored
	bool IsUsingNewDamageReaction(); // Function AIFramework.FWAIController.IsUsingNewDamageReaction
	bool IsTurnInPlaceAllowed(); // Function AIFramework.FWAIController.IsTurnInPlaceAllowed
	bool IsStrafeAllowed(); // Function AIFramework.FWAIController.IsStrafeAllowed
	bool IsOutsideRecoverArea(); // Function AIFramework.FWAIController.IsOutsideRecoverArea
	bool IsLocationOutsideRecoverArea(struct FVector& TestLocation); // Function AIFramework.FWAIController.IsLocationOutsideRecoverArea
	struct UFWAIWeaponComponent* GetWeaponComponent(); // Function AIFramework.FWAIController.GetWeaponComponent
	UObject* GetUClassAIArchetype(); // Function AIFramework.FWAIController.GetUClassAIArchetype
	struct AActor* GetTargetActor(); // Function AIFramework.FWAIController.GetTargetActor
	struct FName GetSquadName(); // Function AIFramework.FWAIController.GetSquadName
	struct AController* GetSquadLeader(); // Function AIFramework.FWAIController.GetSquadLeader
	struct UFWAISquad* GetSquad(); // Function AIFramework.FWAIController.GetSquad
	struct USmartObjectUserState* GetSmartObjectUserState(); // Function AIFramework.FWAIController.GetSmartObjectUserState
	struct USmartObjectLogic* GetSmartObjectLogic(); // Function AIFramework.FWAIController.GetSmartObjectLogic
	float GetScriptedSelectionPriority(struct AActor* InEnemy); // Function AIFramework.FWAIController.GetScriptedSelectionPriority
	struct UFWAIResponseComponent* GetResponseComponent(); // Function AIFramework.FWAIController.GetResponseComponent
	struct FHitResult GetLastHitResult(); // Function AIFramework.FWAIController.GetLastHitResult
	struct FTakeHitInfo GetLastHitInfo(); // Function AIFramework.FWAIController.GetLastHitInfo
	float GetLastCombatActionTime(); // Function AIFramework.FWAIController.GetLastCombatActionTime
	struct AGoalPoint* GetGoalActor(); // Function AIFramework.FWAIController.GetGoalActor
	uint8_t  GetDiscreteDistance(float Distance); // Function AIFramework.FWAIController.GetDiscreteDistance
	struct FVector GetCustomLocation(); // Function AIFramework.FWAIController.GetCustomLocation
	float GetCurrentTargetScore(); // Function AIFramework.FWAIController.GetCurrentTargetScore
	struct USmartObjectSlotComponent* GetCurrentSmartObjectSlot(); // Function AIFramework.FWAIController.GetCurrentSmartObjectSlot
	struct UFWCoveringComponent* GetCoveringComponent(); // Function AIFramework.FWAIController.GetCoveringComponent
	float GetCoverEnterTime(); // Function AIFramework.FWAIController.GetCoverEnterTime
	uint8_t  GetBehaviorTag(); // Function AIFramework.FWAIController.GetBehaviorTag
	struct ABaseCharacter* GetBaseCharacter(); // Function AIFramework.FWAIController.GetBaseCharacter
	struct UPCFAnimReplication* GetAnimReplication(); // Function AIFramework.FWAIController.GetAnimReplication
	UFWAIRank* GetAIRank(); // Function AIFramework.FWAIController.GetAIRank
	struct UFWAIMetrics* GetAIMetrics(); // Function AIFramework.FWAIController.GetAIMetrics
	UFWAIFaction* GetAIFaction(); // Function AIFramework.FWAIController.GetAIFaction
	struct UFWAIComponent* GetAIComponent(); // Function AIFramework.FWAIController.GetAIComponent
	UFWAIArchetype* GetAIArchetype(); // Function AIFramework.FWAIController.GetAIArchetype
	void FWAIAnimNotifyDelegate__DelegateSignature(struct UFWAnimNotify* AnimNotify, struct FName NotifyName, struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation); // DelegateFunction AIFramework.FWAIController.FWAIAnimNotifyDelegate__DelegateSignature
	bool FollowRoute(struct AAIRoute* InScriptedRoute); // Function AIFramework.FWAIController.FollowRoute
	void FollowGoals(struct TArray<struct AGoalPoint*> Goals); // Function AIFramework.FWAIController.FollowGoals
	void FollowGoal(struct AGoalPoint* Goal); // Function AIFramework.FWAIController.FollowGoal
	void EndMeleeAttack(struct FString SocketNames, struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation, UDamageType* DamageTypeClass, struct FName TagName, struct UFWAnimNotifyState_MeleeAttack* AnimNotify); // Function AIFramework.FWAIController.EndMeleeAttack
	float DiscreteDistanceToLenght(uint8_t  Distance); // Function AIFramework.FWAIController.DiscreteDistanceToLenght
	bool ClearBehaviorTag(); // Function AIFramework.FWAIController.ClearBehaviorTag
	void BeginMeleeAttack(struct FString SocketNames, struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation, float TotalDuration, struct TArray<struct FVector>& SensorLocations, UDamageType* DamageTypeClass, struct FName TagName, struct UFWAnimNotifyState_MeleeAttack* AnimNotify); // Function AIFramework.FWAIController.BeginMeleeAttack
	void AllowTurnInPlace(bool Allow); // Function AIFramework.FWAIController.AllowTurnInPlace
}; 



// Class AIFramework.AISpawnSubsystemInterface
// Size: 0x28(Inherited: 0x28) 
struct UAISpawnSubsystemInterface : public UInterface
{

	void SpawnStarted(); // Function AIFramework.AISpawnSubsystemInterface.SpawnStarted
	void SpawnFullyEnded(); // Function AIFramework.AISpawnSubsystemInterface.SpawnFullyEnded
	void SpawnEnded(); // Function AIFramework.AISpawnSubsystemInterface.SpawnEnded
	void RestoreCharacterSettingsAfterSpawnAnim(); // Function AIFramework.AISpawnSubsystemInterface.RestoreCharacterSettingsAfterSpawnAnim
	void PrepareCharacterSettingsForSpawnAnim(); // Function AIFramework.AISpawnSubsystemInterface.PrepareCharacterSettingsForSpawnAnim
}; 



// Class AIFramework.BTDecorator_InWeaponRange
// Size: 0x98(Inherited: 0x90) 
struct UBTDecorator_InWeaponRange : public UBTDecorator_BlackboardBase
{
	uint8_t  RangeType;  // 0x90(0x1)
	char pad_145_1 : 7;  // 0x91(0x1)
	bool bSpecifyWeapon : 1;  // 0x91(0x1)
	uint8_t  WeaponSlot;  // 0x92(0x1)
	char pad_147[5];  // 0x93(0x5)

}; 



// Class AIFramework.FWAIComponent
// Size: 0x218(Inherited: 0x1A8) 
struct UFWAIComponent : public UActorComponent
{
	struct UAnimMontage* RequestedAnimation;  // 0x1A8(0x8)
	struct ABaseCharacter* TargetPlayerForReaction;  // 0x1B0(0x8)
	struct FVector_NetQuantize10 TargetPointForReaction;  // 0x1B8(0xC)
	float TargetAlphaForReaction;  // 0x1C4(0x4)
	char pad_456[4];  // 0x1C8(0x4)
	struct FVector_NetQuantize10 AimLocation;  // 0x1CC(0xC)
	struct FVector2D AimOffset;  // 0x1D8(0x8)
	struct FVector_NetQuantize10 FocalPoint;  // 0x1E0(0xC)
	struct FRotator DesiredRotation;  // 0x1EC(0xC)
	char bUseAimLocation : 1;  // 0x1F8(0x1)
	char bAimOffsetForced : 1;  // 0x1F8(0x1)
	char bUseControllerDesiredRotation : 1;  // 0x1F8(0x1)
	char bShouldCorrectActiveMontageOnClient : 1;  // 0x1F8(0x1)
	char pad_504_1 : 4;  // 0x1F8(0x1)
	char pad_505[32];  // 0x1F9(0x20)

	void UseControllerDesiredRotation(bool bUse); // Function AIFramework.FWAIComponent.UseControllerDesiredRotation
	void SetFocalPoint(struct FVector& InFocalPoint); // Function AIFramework.FWAIComponent.SetFocalPoint
	void SetDesiredRotation(struct FRotator& InDesiredRotation); // Function AIFramework.FWAIComponent.SetDesiredRotation
	void SetAimOffset(struct FVector2D& Offset); // Function AIFramework.FWAIComponent.SetAimOffset
	void OnRep_UseControllerDesiredRotation(); // Function AIFramework.FWAIComponent.OnRep_UseControllerDesiredRotation
	void OnAnimMontageEnded(struct UAnimMontage* Montage, bool bInterrupted); // Function AIFramework.FWAIComponent.OnAnimMontageEnded
	void MulticastSpawnParticleAtLocation(struct UWorld* World, struct UParticleSystem* EmitterTemplate, struct FTransform SpawnTransform, bool bAutoDestroy, uint8_t  PoolingMethod); // Function AIFramework.FWAIComponent.MulticastSpawnParticleAtLocation
	void K2_MulticastSpawnParticleAtLocation(struct UObject* WorldContextObject, struct UParticleSystem* EmitterTemplate, struct FTransform& SpawnTransform, bool bAutoDestroy, uint8_t  PoolingMethod); // Function AIFramework.FWAIComponent.K2_MulticastSpawnParticleAtLocation
	bool IsUsingControllerDesiredRotation(); // Function AIFramework.FWAIComponent.IsUsingControllerDesiredRotation
	bool IsAimOffsetForced(); // Function AIFramework.FWAIComponent.IsAimOffsetForced
	bool IsAimLocationUsed(); // Function AIFramework.FWAIComponent.IsAimLocationUsed
	bool HasAuthority(); // Function AIFramework.FWAIComponent.HasAuthority
	struct APawn* GetPawn(); // Function AIFramework.FWAIComponent.GetPawn
	struct FVector GetFocalPoint(); // Function AIFramework.FWAIComponent.GetFocalPoint
	struct FRotator GetDesiredRotation(); // Function AIFramework.FWAIComponent.GetDesiredRotation
	struct AFWAIController* GetController(); // Function AIFramework.FWAIComponent.GetController
	struct FVector2D GetAimOffset(); // Function AIFramework.FWAIComponent.GetAimOffset
	struct FVector GetAimLocation(); // Function AIFramework.FWAIComponent.GetAimLocation
	void CustomMovementModeAnimEnded(struct UAnimMontage* Montage, bool bInterrupted); // Function AIFramework.FWAIComponent.CustomMovementModeAnimEnded
	void Client_SetupAnimWithCustomMovementMode(struct UAnimMontage* Montage, char EMovementMode CustomMovementMode, bool EnableCorrectionOnClient, bool bDisableCollision); // Function AIFramework.FWAIComponent.Client_SetupAnimWithCustomMovementMode
	void Client_PlayAntFarmAnimation(struct UAnimMontage* Montage, struct FName SectionName); // Function AIFramework.FWAIComponent.Client_PlayAntFarmAnimation
	void Client_PlayAnimWithCustomMovementMode(struct UAnimMontage* Montage, float PlayRate, struct FName SectionToPlay, char EMovementMode CustomMovementMode); // Function AIFramework.FWAIComponent.Client_PlayAnimWithCustomMovementMode
}; 



// Class AIFramework.FWBTDecorator_IsSmartObjectCharacterEnterComplete
// Size: 0x68(Inherited: 0x68) 
struct UFWBTDecorator_IsSmartObjectCharacterEnterComplete : public UBTDecorator
{

}; 



// Class AIFramework.FWAIRes_ReactionsToPlayer
// Size: 0x130(Inherited: 0x70) 
struct UFWAIRes_ReactionsToPlayer : public UFWAIResponse
{
	struct FReactionsGoalPointSettings OverwritableSettings;  // 0x70(0x18)
	float LookAtFadeInTime;  // 0x88(0x4)
	float LookAtFadeOutTime;  // 0x8C(0x4)
	struct FName OurHeadSocketName;  // 0x90(0x8)
	struct FName LookAtTargetSocketName;  // 0x98(0x8)
	float DefaultHearingAngleLimit;  // 0xA0(0x4)
	char pad_164_1 : 7;  // 0xA4(0x1)
	bool bUseHearingAngleLimit : 1;  // 0xA4(0x1)
	char pad_165[3];  // 0xA5(0x3)
	float HearingAngleLimit;  // 0xA8(0x4)
	float SpeechMaxDistance;  // 0xAC(0x4)
	struct UWorld* World;  // 0xB0(0x8)
	struct UFWAIReactionsManager* ReactionsManager;  // 0xB8(0x8)
	struct UFWAISystem* AISys;  // 0xC0(0x8)
	struct FTimerHandle ReactionDelayTimerHandle;  // 0xC8(0x8)
	struct FTimerHandle SpeechDelayTimerHandle;  // 0xD0(0x8)
	struct FTimerHandle ReactionCooldownTimerHandle;  // 0xD8(0x8)
	char pad_224[32];  // 0xE0(0x20)
	struct FReactionsGoalPointSettings GoalPointSettings;  // 0x100(0x18)
	char bUpdateBehaviour : 1;  // 0x118(0x1)
	char bReactionDelayEnabled : 1;  // 0x118(0x1)
	char bReactionCooldownEnabled : 1;  // 0x118(0x1)
	char bSpeaking : 1;  // 0x118(0x1)
	char bHadSpoken : 1;  // 0x118(0x1)
	char bWasLastReactionSensedBySight : 1;  // 0x118(0x1)
	char pad_280_1 : 2;  // 0x118(0x1)
	char pad_281[2];  // 0x119(0x2)
	int16_t SightAngleLimit;  // 0x11A(0x2)
	char pad_284[4];  // 0x11C(0x4)
	struct AFWAIController* AIController;  // 0x120(0x8)
	struct UFWAIComponent* AIComponent;  // 0x128(0x8)

}; 



// Class AIFramework.FWMontageProvider
// Size: 0x28(Inherited: 0x28) 
struct UFWMontageProvider : public UObject
{

}; 



// Class AIFramework.FWSpaceWrappingDestinationProvider
// Size: 0x28(Inherited: 0x28) 
struct UFWSpaceWrappingDestinationProvider : public UObject
{

}; 



// Class AIFramework.AITask_LaunchCharacter
// Size: 0xE0(Inherited: 0x98) 
struct UAITask_LaunchCharacter : public UFWAITask
{
	char pad_152[72];  // 0x98(0x48)

	void OnLandedCallback(struct FHitResult& Hit); // Function AIFramework.AITask_LaunchCharacter.OnLandedCallback
	void OnAnimNotify(struct UFWAnimNotify* AnimNotify, struct FName NotifyName, struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation); // Function AIFramework.AITask_LaunchCharacter.OnAnimNotify
}; 



// Class AIFramework.FWAIDamageReactionComponent
// Size: 0x208(Inherited: 0x1A8) 
struct UFWAIDamageReactionComponent : public UActorComponent
{
	char pad_424[8];  // 0x1A8(0x8)
	struct UAnimMontage* RecoveryToPlay;  // 0x1B0(0x8)
	struct UAITask_PlayDamageReaction* CurrentTwitchTask;  // 0x1B8(0x8)
	struct UAITask_PlayDamageReaction* CurrentFullBodyTask;  // 0x1C0(0x8)
	struct UAnimMontage* LastFBReactionMontage;  // 0x1C8(0x8)
	struct UAnimMontage* LastFBRecoveryMontage;  // 0x1D0(0x8)
	char pad_472[40];  // 0x1D8(0x28)
	struct UFWAIDamageReactionRenderingComponent* RenderComponent;  // 0x200(0x8)

	void OnAnimationTaskFinished(struct UFWAITask* Task, uint8_t  Result); // Function AIFramework.FWAIDamageReactionComponent.OnAnimationTaskFinished
}; 



// Class AIFramework.FWAIResChannel_Damage
// Size: 0x48(Inherited: 0x48) 
struct UFWAIResChannel_Damage : public UFWAIResponseChannel
{

}; 



// Class AIFramework.FWAIMetrics
// Size: 0x50(Inherited: 0x28) 
struct UFWAIMetrics : public UObject
{
	float MediumDiscreteDistance;  // 0x28(0x4)
	float ShortDiscreteDistance;  // 0x2C(0x4)
	float CloseDiscreteDistance;  // 0x30(0x4)
	float MeleeDiscreteDistance;  // 0x34(0x4)
	uint8_t  MinPreferedDistance;  // 0x38(0x1)
	uint8_t  MaxPreferedDistance;  // 0x39(0x1)
	char pad_58[2];  // 0x3A(0x2)
	struct FVector2D CoverSelectionDistance;  // 0x3C(0x8)
	float WeaponMaxDistance;  // 0x44(0x4)
	float WeaponEffectiveDistance;  // 0x48(0x4)
	char pad_76[4];  // 0x4C(0x4)

}; 



// Class AIFramework.FWBTDecorator_HasTargetMoved
// Size: 0xC0(Inherited: 0x90) 
struct UFWBTDecorator_HasTargetMoved : public UBTDecorator_BlackboardBase
{
	struct FBlackboardKeySelector TargetPositionKey;  // 0x90(0x28)
	float MinDistanceToTravel;  // 0xB8(0x4)
	float MaxSightDeviationDot;  // 0xBC(0x4)

}; 



// Class AIFramework.FWSpaceWrappingDestinationProvider_CoverMantleMidpoint
// Size: 0x28(Inherited: 0x28) 
struct UFWSpaceWrappingDestinationProvider_CoverMantleMidpoint : public UFWSpaceWrappingDestinationProvider
{

}; 



// Class AIFramework.SmartObjectSlotComponent
// Size: 0x710(Inherited: 0x530) 
struct USmartObjectSlotComponent : public USphereComponent
{
	char pad_1328[24];  // 0x530(0x18)
	struct UObject* CachedNavParent;  // 0x548(0x8)
	struct FReactionsGoalPointSettings ReactionsSettings;  // 0x550(0x18)
	struct TArray<struct FFactReaction> FactReactionsSettings;  // 0x568(0x10)
	int32_t OrderInSequence;  // 0x578(0x4)
	char pad_1404_1 : 7;  // 0x57C(0x1)
	bool bIsDisabled : 1;  // 0x57C(0x1)
	char pad_1405_1 : 7;  // 0x57D(0x1)
	bool bShowPreview : 1;  // 0x57D(0x1)
	uint8_t  SmartObjectType;  // 0x57E(0x1)
	char pad_1407[1];  // 0x57F(0x1)
	struct FAntFarmControlAttributeDelta MainModification;  // 0x580(0xC)
	char pad_1420[4];  // 0x58C(0x4)
	struct TArray<struct FAntFarmControlAttributeDelta> OtherModifications;  // 0x590(0x10)
	struct UAnimMontage* MontageToPlay;  // 0x5A0(0x8)
	struct TArray<struct FName> MontageForceOutSections;  // 0x5A8(0x10)
	char pad_1464_1 : 7;  // 0x5B8(0x1)
	bool bRepeatLoopSectionOnCompletion : 1;  // 0x5B8(0x1)
	char pad_1465_1 : 7;  // 0x5B9(0x1)
	bool bAlwaysCompleteLoopAnimation : 1;  // 0x5B9(0x1)
	char pad_1466_1 : 7;  // 0x5BA(0x1)
	bool bIsInfiniteLoop : 1;  // 0x5BA(0x1)
	char pad_1467_1 : 7;  // 0x5BB(0x1)
	bool bRequiresFlying : 1;  // 0x5BB(0x1)
	float DURATION;  // 0x5BC(0x4)
	float DurationRandomDeviation;  // 0x5C0(0x4)
	char pad_1476[4];  // 0x5C4(0x4)
	struct UAnimMontage* SynchronizedMontage;  // 0x5C8(0x8)
	struct FName SynchronizedMontageStartSection;  // 0x5D0(0x8)
	struct TArray<struct FName> SynchronizedMontageForceOutSections;  // 0x5D8(0x10)
	struct UAnimMontage* PostSyncMontage;  // 0x5E8(0x8)
	char bUseWeapon : 1;  // 0x5F0(0x1)
	char bSkipSlotRotationForCharacter : 1;  // 0x5F0(0x1)
	char bNeverSkipEnterAnimation : 1;  // 0x5F0(0x1)
	char bRestrictUsageByArchetype : 1;  // 0x5F0(0x1)
	char bSkipForceOutOnTakenDamage : 1;  // 0x5F0(0x1)
	char bShouldSkipForceOut : 1;  // 0x5F0(0x1)
	char bDisableRootMotionWhileInEnterOrLoopStage : 1;  // 0x5F0(0x1)
	char pad_1520_1 : 1;  // 0x5F0(0x1)
	uint8_t  MovementMood;  // 0x5F1(0x1)
	char pad_1522[6];  // 0x5F2(0x6)
	struct FFWAIArchetypeVariation AllowedArchetypeVariation;  // 0x5F8(0x20)
	char pad_1560[24];  // 0x618(0x18)
	struct FRepSmartObject RepData;  // 0x630(0x18)
	struct ABaseCharacter* ClaimingCharacter;  // 0x648(0x8)
	struct FName StartSection;  // 0x650(0x8)
	struct FName LoopSection;  // 0x658(0x8)
	struct FName EndSection;  // 0x660(0x8)
	char pad_1640[16];  // 0x668(0x10)
	char pad_1656_1 : 7;  // 0x678(0x1)
	bool bModificationsNotRequired : 1;  // 0x678(0x1)
	char pad_1657[7];  // 0x679(0x7)
	struct TMap<struct USceneComponent*, struct FTransform> InitialTransforms;  // 0x680(0x50)
	char pad_1744[64];  // 0x6D0(0x40)

	void SetEnabled(bool bSet); // Function AIFramework.SmartObjectSlotComponent.SetEnabled
	void OnRep_Data(struct FRepSmartObject& OldData); // Function AIFramework.SmartObjectSlotComponent.OnRep_Data
	void OnNotifyBeginReceived(uint8_t  NotifyType, bool bUseSharedSpace, uint8_t  AttachPoint, struct FName NotifyName, struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation, uint8_t  LocationRule, uint8_t  RotationRule); // Function AIFramework.SmartObjectSlotComponent.OnNotifyBeginReceived
	bool IsInUse(); // Function AIFramework.SmartObjectSlotComponent.IsInUse
	bool IsEnabled(); // Function AIFramework.SmartObjectSlotComponent.IsEnabled
	void HandleInterpolatedMoveFinished(); // Function AIFramework.SmartObjectSlotComponent.HandleInterpolatedMoveFinished
	struct ABaseCharacter* GetUsingCharacter(); // Function AIFramework.SmartObjectSlotComponent.GetUsingCharacter
}; 



// Class AIFramework.FWAIDataProvider_Metrics
// Size: 0x48(Inherited: 0x28) 
struct UFWAIDataProvider_Metrics : public UAIDataProvider
{
	float MeleeDistance;  // 0x28(0x4)
	float CloseDistance;  // 0x2C(0x4)
	float ShortDistance;  // 0x30(0x4)
	float MediumDistance;  // 0x34(0x4)
	float MinPreferedDistance;  // 0x38(0x4)
	float MaxPreferedDistance;  // 0x3C(0x4)
	float MinCoverSelectionDistance;  // 0x40(0x4)
	float MaxCoverSelectionDistance;  // 0x44(0x4)

}; 



// Class AIFramework.FWBTService_ContextOverride
// Size: 0x70(Inherited: 0x70) 
struct UFWBTService_ContextOverride : public UBTService
{

}; 



// Class AIFramework.FWAIResponse
// Size: 0x70(Inherited: 0x28) 
struct UFWAIResponse : public UObject
{
	struct TArray<UFWAIResponseChannel*> AutoSubscribeChannel;  // 0x28(0x10)
	struct TArray<UFWAIResponseChannel*> SubscribedChannel;  // 0x38(0x10)
	float TimerInterval;  // 0x48(0x4)
	float TimerRandomDeviation;  // 0x4C(0x4)
	float TimerNextActivationTime;  // 0x50(0x4)
	char pad_84[4];  // 0x54(0x4)
	struct AFWAIController* AIOwner;  // 0x58(0x8)
	struct ABaseCharacter* Avatar;  // 0x60(0x8)
	char bSuppressed : 1;  // 0x68(0x1)
	char pad_104_1 : 7;  // 0x68(0x1)
	char pad_105[8];  // 0x69(0x8)

	void UnSuppress(); // Function AIFramework.FWAIResponse.UnSuppress
	void Suppress(); // Function AIFramework.FWAIResponse.Suppress
	bool ShouldRespond(struct UFWAIResponseChannel* SourceChannel, struct AFWAIController* AI, struct ABaseCharacter* character); // Function AIFramework.FWAIResponse.ShouldRespond
	void ReceiveExecution(struct UFWAIResponseChannel* SourceChannel); // Function AIFramework.FWAIResponse.ReceiveExecution
	bool IsSuppressed(); // Function AIFramework.FWAIResponse.IsSuppressed
	struct ABaseCharacter* GetAvatar(); // Function AIFramework.FWAIResponse.GetAvatar
	struct AFWAIController* GetAIOwner(); // Function AIFramework.FWAIResponse.GetAIOwner
}; 



// Class AIFramework.FWAIRes_Damage
// Size: 0x80(Inherited: 0x70) 
struct UFWAIRes_Damage : public UFWAIResponse
{
	char pad_112[16];  // 0x70(0x10)

}; 



// Class AIFramework.FWAITask
// Size: 0x98(Inherited: 0x70) 
struct UFWAITask : public UAITask
{
	struct FMulticastInlineDelegate OnAITaskEnded;  // 0x70(0x10)
	char pad_128[24];  // 0x80(0x18)

}; 



// Class AIFramework.FWAIRes_AbilityTag
// Size: 0x78(Inherited: 0x70) 
struct UFWAIRes_AbilityTag : public UFWAIResponse
{
	struct FGameplayTag AbilityTag;  // 0x70(0x8)

	struct FWAIResChannel_AbilityTagStatus GetTagStatus(struct UFWAIResChannel_AbilityTag* SourceChannel); // Function AIFramework.FWAIRes_AbilityTag.GetTagStatus
}; 



// Class AIFramework.FWAISquad
// Size: 0x1D0(Inherited: 0x28) 
struct UFWAISquad : public UObject
{
	struct FName SquadName;  // 0x28(0x8)
	float EnemySelectionInterval;  // 0x30(0x4)
	float AssignedTargetPersistanceTime;  // 0x34(0x4)
	char pad_56[8];  // 0x38(0x8)
	struct AController* SquadLeader;  // 0x40(0x8)
	struct TArray<struct AGoalPoint*> NewGoals;  // 0x48(0x10)
	struct TArray<struct FFWSquadEnemyInfo> SquadEnemyList;  // 0x58(0x10)
	struct TArray<struct AFWAIController*> GoalRequest;  // 0x68(0x10)
	struct TArray<struct FFWSquadMemberInfo> SquadMembers;  // 0x78(0x10)
	char pad_136[292];  // 0x88(0x124)
	float FlankingSelectDelay;  // 0x1AC(0x4)
	float FlankingSelectAfterEventDelay;  // 0x1B0(0x4)
	float FlankingBeenAttackedInterval;  // 0x1B4(0x4)
	float FlankingRandomScoreWeight;  // 0x1B8(0x4)
	float FlankingAngleScoreWeight;  // 0x1BC(0x4)
	float FlankingAlreadySelectedWeight;  // 0x1C0(0x4)
	float FlankingBeingAttackedScoreWeight;  // 0x1C4(0x4)
	int32_t FlankingRatio;  // 0x1C8(0x4)
	float FlankingGoodFlankingAngle;  // 0x1CC(0x4)

	void UnregisterSquadMember(struct AController* OldMember); // Function AIFramework.FWAISquad.UnregisterSquadMember
	void RegisterSquadMember(struct AController* NewMember, bool bLeader); // Function AIFramework.FWAISquad.RegisterSquadMember
	bool IsAnySquadMemberInRange(struct AController* MemberToExclude, struct FVector Origin, float MinRadius, float MaxRadius); // Function AIFramework.FWAISquad.IsAnySquadMemberInRange
	void GetSquadMembersInRange(struct AController* MemberToExclude, struct FVector Origin, float Radius, struct TArray<struct AController*>& OutControllers); // Function AIFramework.FWAISquad.GetSquadMembersInRange
	void GetSquadMembers(struct TArray<struct AController*>& SquadMembers); // Function AIFramework.FWAISquad.GetSquadMembers
	void GetSquadMemberPawns(struct TArray<struct APawn*>& SquadMemberPawns); // Function AIFramework.FWAISquad.GetSquadMemberPawns
	struct AController* GetSquadLeadaer(); // Function AIFramework.FWAISquad.GetSquadLeadaer
	struct AController* GetRandomMemberFromSquadOtherThanGiven(struct AController* MemberToExclude); // Function AIFramework.FWAISquad.GetRandomMemberFromSquadOtherThanGiven
	int32_t GetNumberOfSquadMembers(); // Function AIFramework.FWAISquad.GetNumberOfSquadMembers
}; 



// Class AIFramework.FWEQSTestingPawn
// Size: 0x760(Inherited: 0x660) 
struct AFWEQSTestingPawn : public AEQSTestingPawn
{
	ABaseCharacter* CharacterClass;  // 0x658(0x8)
	struct FFWAIArchetypeVariation TestSource;  // 0x660(0x20)
	struct AGoalPoint* TestGoal;  // 0x680(0x8)
	struct ACombatArena* TestCombatArea;  // 0x688(0x8)
	struct AActor* TestTarget;  // 0x690(0x8)
	struct AActor* FakeSlotActor;  // 0x698(0x8)
	struct FNavAgentProperties NavAgentProps;  // 0x6A0(0x38)
	float WeaponRange;  // 0x6D8(0x4)
	float EffectiveWeaponRange;  // 0x6DC(0x4)
	float SightRadius;  // 0x6E0(0x4)
	float MeleeDistance;  // 0x6E4(0x4)
	float CloseDistance;  // 0x6E8(0x4)
	float ShortDistance;  // 0x6EC(0x4)
	float MediumDistance;  // 0x6F0(0x4)
	struct FVector2D PreferedDistance;  // 0x6F4(0x8)
	struct FVector2D CoverSelectionDistance;  // 0x6FC(0x8)
	char ETeam Team;  // 0x704(0x1)
	struct TArray<struct AActor*> PlayerAlphaSquad;  // 0x708(0x10)
	struct TArray<struct AActor*> PlayerBetaSquad;  // 0x718(0x10)
	struct TArray<struct AActor*> EnemyAlphaSquad;  // 0x728(0x10)
	struct TArray<struct AActor*> EnemyBetaSquad;  // 0x738(0x10)
	struct TArray<struct FVector> EQSPointsOfInterest;  // 0x748(0x10)
	char bDrawOnlyWhenSelected : 1;  // 0x758(0x1)
	char pad_1885_1 : 7;  // 0x75D(0x1)
	char pad_1886[3];  // 0x75E(0x3)

}; 



// Class AIFramework.FWAIGameplayAbilityInterface
// Size: 0x28(Inherited: 0x28) 
struct UFWAIGameplayAbilityInterface : public UInterface
{

	bool DoesTargetHaveProhibitedTagsForAI(struct AActor* TargetActor); // Function AIFramework.FWAIGameplayAbilityInterface.DoesTargetHaveProhibitedTagsForAI
	bool CanHitTarget(struct ABaseCharacter* Source, struct AActor* Target, bool bUseIdealYawRotationToTarget); // Function AIFramework.FWAIGameplayAbilityInterface.CanHitTarget
}; 



// Class AIFramework.FWAISquad_Melee
// Size: 0x1F0(Inherited: 0x1D0) 
struct UFWAISquad_Melee : public UFWAISquad
{
	struct TArray<struct FFWExtendedSquadEnemyInfo> ExtendedSquadEnemyInfo;  // 0x1D0(0x10)
	char pad_480[16];  // 0x1E0(0x10)

}; 



// Class AIFramework.FWAITask_Jump
// Size: 0x160(Inherited: 0xD0) 
struct UFWAITask_Jump : public UAITask_PlayAnimation
{
	char pad_208[36];  // 0xD0(0x24)
	float JumpOverDiffRange;  // 0xF4(0x4)
	float RotationBlendingTime;  // 0xF8(0x4)
	char pad_252_1 : 7;  // 0xFC(0x1)
	bool bDisableCollisionOnAirborne : 1;  // 0xFC(0x1)
	char pad_253[27];  // 0xFD(0x1B)
	struct FAITaskJumpNetworkData NetworkData;  // 0x118(0x38)
	struct UAnimMontage* SelectedAnimation;  // 0x150(0x8)
	char pad_344[8];  // 0x158(0x8)

	void OnRep_NetworkData(); // Function AIFramework.FWAITask_Jump.OnRep_NetworkData
}; 



// Class AIFramework.FWEnvQueryContext_CombatArea
// Size: 0x28(Inherited: 0x28) 
struct UFWEnvQueryContext_CombatArea : public UEnvQueryContext
{

}; 



// Class AIFramework.FWAIWeaponAnimationDataAsset
// Size: 0x80(Inherited: 0x30) 
struct UFWAIWeaponAnimationDataAsset : public UDataAsset
{
	struct TMap<UWeaponType*, struct FFWAIWeaponAnimationData> WeaponAnimationData;  // 0x30(0x50)

}; 



// Class AIFramework.FWAISemaphoreGroupClass
// Size: 0x30(Inherited: 0x28) 
struct UFWAISemaphoreGroupClass : public UObject
{
	char ConcurrentLimit;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)

}; 



// Class AIFramework.FWAIVisibilitySystem
// Size: 0x290(Inherited: 0x28) 
struct UFWAIVisibilitySystem : public UObject
{
	char pad_40[24];  // 0x28(0x18)
	struct TArray<struct FFWPendingSightInfo> PendingChecks;  // 0x40(0x10)
	char pad_80[80];  // 0x50(0x50)
	struct TMap<struct AFWAIController*, float> PerceptionUpdateCounters;  // 0xA0(0x50)
	char pad_240[16];  // 0xF0(0x10)
	struct TMap<uint64_t, struct FSightTraceData> AsyncSightCheckRequests;  // 0x100(0x50)
	char pad_336_1 : 7;  // 0x150(0x1)
	bool bUseAsyncTraceForSightCheck : 1;  // 0x150(0x1)
	char pad_337[3];  // 0x151(0x3)
	float CacheValidDuration;  // 0x154(0x4)
	int32_t MaxCacheSize;  // 0x158(0x4)
	float MaxSightTimeCost;  // 0x15C(0x4)
	int32_t MaxSightTraces;  // 0x160(0x4)
	float PerceptionUpdateInterval;  // 0x164(0x4)
	char pad_360[4];  // 0x168(0x4)
	float CacheCleanupInterval;  // 0x16C(0x4)
	char pad_368[288];  // 0x170(0x120)

}; 



// Class AIFramework.FWAISystem
// Size: 0x430(Inherited: 0x128) 
struct UFWAISystem : public UAISystem
{
	struct AFWCharacterCache* CharacterCache;  // 0x128(0x8)
	struct AFWWaveSpawningSystem* CurrentWss;  // 0x130(0x8)
	char pad_312[16];  // 0x138(0x10)
	int32_t ActionAreaGridSpace;  // 0x148(0x4)
	int32_t ActionAreaMinSpotDistToCover;  // 0x14C(0x4)
	struct TArray<struct ACombatArena*> ActiveCombatAreas;  // 0x150(0x10)
	int32_t MaxNumberOfReactionsAtTime;  // 0x160(0x4)
	float GlobalCooldownTime;  // 0x164(0x4)
	float GlobalCooldownMaxTime;  // 0x168(0x4)
	int32_t MaxNumberOfSpawns;  // 0x16C(0x4)
	char pad_368[24];  // 0x170(0x18)
	struct FSoftObjectPath SmartObjectLogicAssetRef;  // 0x188(0x18)
	char pad_416_1 : 7;  // 0x1A0(0x1)
	bool bAntFarmEnableOptimization : 1;  // 0x1A0(0x1)
	char pad_417[3];  // 0x1A1(0x3)
	float AntFarmMinimalDistanceToPlayer;  // 0x1A4(0x4)
	struct USmartObjectLogic* SmartObjectLogic;  // 0x1A8(0x8)
	float SignificanceCheckTickRate;  // 0x1B0(0x4)
	char pad_436[84];  // 0x1B4(0x54)
	struct TArray<struct FSemaphorePendingUnlockItem> SemaphorePendingUnlocks;  // 0x208(0x10)
	struct TMap<struct AActor*, struct FWAIConcurentSemaphoreGroup> BTConcurentSemaphoreGroupsPerTarget;  // 0x218(0x50)
	char pad_616[8];  // 0x268(0x8)
	struct FSoftClassPath AISPawnSystemClassName;  // 0x270(0x18)
	struct UAISpawnSubsystem* AISpawnSubsystem;  // 0x288(0x8)
	struct FSoftClassPath AIReactionsManagerClassName;  // 0x290(0x18)
	struct UFWAIReactionsManager* AIReactionsManager;  // 0x2A8(0x8)
	struct UFWAIVisibilitySystem* AIVisibilitySystem;  // 0x2B0(0x8)
	struct ACombatArena* CurrentCombatArea;  // 0x2B8(0x8)
	struct TArray<struct AGoalPoint*> Goals;  // 0x2C0(0x10)
	struct TArray<struct UFWAISquad*> Squads;  // 0x2D0(0x10)
	struct TArray<struct AFWEncounterManager*> ActiveEncounterManagers;  // 0x2E0(0x10)
	char pad_752[320];  // 0x2F0(0x140)

	void GetCharactersInRange(struct UObject* WorldContextObject, struct AActor* CenterActor, float RadiusAroundCenterActor, char ETeam Team, bool bIncludeCenterActorInResult, struct TArray<struct AActor*>& OutFoundCharacters); // Function AIFramework.FWAISystem.GetCharactersInRange
	struct UFWAISquad* GetAISquadByName(struct UObject* WorldContextObject, struct FName SquadName); // Function AIFramework.FWAISystem.GetAISquadByName
	struct UFWAISquad* ConditionalCreateSquad(struct UObject* WorldContextObject, struct FName SquadName, struct AFWAIController* AI); // Function AIFramework.FWAISystem.ConditionalCreateSquad
	void AddAvoidPoint(struct UObject* WorldContextObject, struct FVector InCentre, float InRadius, float InHalfHeight, float InTimeToLive, int32_t InGroupMask); // Function AIFramework.FWAISystem.AddAvoidPoint
}; 



// Class AIFramework.FWBackpackComponent
// Size: 0xEC0(Inherited: 0xE20) 
struct UFWBackpackComponent : public USkeletalMeshComponent
{
	struct FString SocketName;  // 0xE18(0x10)
	Acharacter* DamageInstigatorCharacter;  // 0xE28(0x8)
	char pad_3640_1 : 7;  // 0xE38(0x1)
	bool bBackpackEnabled : 1;  // 0xE30(0x1)
	float MaxHealth;  // 0xE34(0x4)
	float Health;  // 0xE3C(0x4)
	struct UCharacterCustomizationComponent* CustomizationComponent;  // 0xE40(0x8)
	char pad_3657[7];  // 0xE49(0x7)
	struct AController* DamageInstigator;  // 0xE50(0x8)
	char pad_3672[8];  // 0xE58(0x8)
	struct TMap<struct FName, struct FGroupMaterialData> LoadedMaterials;  // 0xE60(0x50)
	char pad_3760[16];  // 0xEB0(0x10)

	void SetBackpackMaxHealth(float Amount); // Function AIFramework.FWBackpackComponent.SetBackpackMaxHealth
	void OnRep_Health(); // Function AIFramework.FWBackpackComponent.OnRep_Health
	void OnComponentsMaterialGroupReset(struct UMeshComponent* MeshComponent, uint8_t  SlotType); // Function AIFramework.FWBackpackComponent.OnComponentsMaterialGroupReset
	void OnComponentsMaterialGroupApplied(struct UMeshComponent* MeshComponent, struct FName GroupName, uint8_t  SlotType); // Function AIFramework.FWBackpackComponent.OnComponentsMaterialGroupApplied
	void HideBackpack(); // Function AIFramework.FWBackpackComponent.HideBackpack
	float GetBackpackMaxHealth(); // Function AIFramework.FWBackpackComponent.GetBackpackMaxHealth
	float GetBackpackHealth(); // Function AIFramework.FWBackpackComponent.GetBackpackHealth
}; 



// Class AIFramework.FWEncounterSetupOverrideData
// Size: 0x48(Inherited: 0x30) 
struct UFWEncounterSetupOverrideData : public UDataAsset
{
	struct TArray<struct FFWWaveDataOverride> Waves;  // 0x30(0x10)
	struct UBaseBiomeData* Biome;  // 0x40(0x8)

}; 



// Class AIFramework.FWAITask_MantleOverCover
// Size: 0x110(Inherited: 0xD0) 
struct UFWAITask_MantleOverCover : public UAITask_PlayAnimation
{
	char pad_208[28];  // 0xD0(0x1C)
	float MantleLength;  // 0xEC(0x4)
	float HitDetectionDistance;  // 0xF0(0x4)
	float HitDetectionFOV;  // 0xF4(0x4)
	char pad_248_1 : 7;  // 0xF8(0x1)
	bool bOrientTowardTargetRotation : 1;  // 0xF8(0x1)
	char pad_249[7];  // 0xF9(0x7)
	struct UAnimMontage* SelectedAnimation;  // 0x100(0x8)
	char pad_264[8];  // 0x108(0x8)

}; 



// Class AIFramework.QueryTest_CurrentCover
// Size: 0x268(Inherited: 0x268) 
struct UQueryTest_CurrentCover : public UEnvQueryTest
{

}; 



// Class AIFramework.FWPathFollowingComponent
// Size: 0x418(Inherited: 0x370) 
struct UFWPathFollowingComponent : public UPcfPathFollowingComponent
{
	struct TArray<struct FFWRepathData> RepathData;  // 0x370(0x10)
	float PartialPathUpdateTime;  // 0x380(0x4)
	char pad_900_1 : 7;  // 0x384(0x1)
	bool bSmooth : 1;  // 0x384(0x1)
	char pad_901[3];  // 0x385(0x3)
	int32_t SmoothingLookAheadPoints;  // 0x388(0x4)
	float SmoothingLookAheadDistance;  // 0x38C(0x4)
	char pad_912_1 : 7;  // 0x390(0x1)
	bool bLimitRVONearEndPoint : 1;  // 0x390(0x1)
	char pad_913[3];  // 0x391(0x3)
	float LimitRVONearEndPointAtDistance;  // 0x394(0x4)
	float DisableRVONearEndPointAtDistance;  // 0x398(0x4)
	char pad_924_1 : 7;  // 0x39C(0x1)
	bool bSmoothFromActorLocation : 1;  // 0x39C(0x1)
	char pad_925_1 : 7;  // 0x39D(0x1)
	bool bGoalPredictionPathfindingEnabled : 1;  // 0x39D(0x1)
	char pad_926[2];  // 0x39E(0x2)
	struct UAITask_PlayAnimation* CoverLinkActionTask;  // 0x3A0(0x8)
	char pad_936[56];  // 0x3A8(0x38)
	struct AActor* PredictionHistoryTarget;  // 0x3E0(0x8)
	char pad_1000[48];  // 0x3E8(0x30)

	void OnMantleTaskEnded(struct UFWAITask* Task, uint8_t  Result); // Function AIFramework.FWPathFollowingComponent.OnMantleTaskEnded
	void OnJumpTaskEnded(struct UFWAITask* Task, uint8_t  Result); // Function AIFramework.FWPathFollowingComponent.OnJumpTaskEnded
	struct AActor* GetDestinationActor(); // Function AIFramework.FWPathFollowingComponent.GetDestinationActor
}; 



// Class AIFramework.FWAIWeaponCoverAnimationDataAsset
// Size: 0x80(Inherited: 0x30) 
struct UFWAIWeaponCoverAnimationDataAsset : public UDataAsset
{
	struct TMap<AWeapon*, struct FFWAIWeaponCoverAnimationData> WeaponData;  // 0x30(0x50)

}; 



// Class AIFramework.FWAITask_CoverAction
// Size: 0xE8(Inherited: 0xD0) 
struct UFWAITask_CoverAction : public UAITask_PlayAnimation
{
	char pad_208[24];  // 0xD0(0x18)

	void OnDamageEvent(struct ABaseCharacter* EnemyCharacter, struct FTakeHitInfo TakeHitInfo); // Function AIFramework.FWAITask_CoverAction.OnDamageEvent
}; 



// Class AIFramework.FWAITask_PeekAction
// Size: 0x110(Inherited: 0xE8) 
struct UFWAITask_PeekAction : public UFWAITask_CoverAction
{
	float MaxDamageSenseAge;  // 0xE8(0x4)
	float MaxSightSenseAge;  // 0xEC(0x4)
	char pad_240[16];  // 0xF0(0x10)
	struct UAnimMontage* ActionMontage;  // 0x100(0x8)
	struct UAnimMontage* MontageToHide;  // 0x108(0x8)

}; 



// Class AIFramework.ActionAreaDebugRenderingComponent
// Size: 0x510(Inherited: 0x510) 
struct UActionAreaDebugRenderingComponent : public UPrimitiveComponent
{

}; 



// Class AIFramework.AnimNotify_SmartObject
// Size: 0x48(Inherited: 0x38) 
struct UAnimNotify_SmartObject : public UAnimNotify
{
	uint8_t  NotifyType;  // 0x38(0x1)
	uint8_t  AttachPoint;  // 0x39(0x1)
	uint8_t  LocationRule;  // 0x3A(0x1)
	uint8_t  RotationRule;  // 0x3B(0x1)
	struct FName SmartObjectNotifyName;  // 0x3C(0x8)
	char pad_68_1 : 7;  // 0x44(0x1)
	bool bUseSharedSpace : 1;  // 0x44(0x1)
	char pad_69[3];  // 0x45(0x3)

}; 



// Class AIFramework.FWAnimNotifyState_MeleeAttack
// Size: 0xA0(Inherited: 0x40) 
struct UFWAnimNotifyState_MeleeAttack : public UFWAnimNotifyState
{
	UDamageType* DamageTypeClass;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool bAllowHittingMultipleTargets : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)
	struct FString SensorSockets;  // 0x50(0x10)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool bUseOneHitFOVTest : 1;  // 0x60(0x1)
	char pad_97[3];  // 0x61(0x3)
	float HitDetectionFOV;  // 0x64(0x4)
	float HitDetectionFOVOffset;  // 0x68(0x4)
	float HitDetectionDistance;  // 0x6C(0x4)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool bDisableControllerEvents : 1;  // 0x70(0x1)
	char pad_113_1 : 7;  // 0x71(0x1)
	bool bAttachToMesh : 1;  // 0x71(0x1)
	char pad_114[2];  // 0x72(0x2)
	float CentreOffset;  // 0x74(0x4)
	float CentreZOffset;  // 0x78(0x4)
	char pad_124[36];  // 0x7C(0x24)

}; 



// Class AIFramework.EnvQueryGenerator_GridBasedDisk
// Size: 0x148(Inherited: 0xD0) 
struct UEnvQueryGenerator_GridBasedDisk : public UEnvQueryGenerator_ProjectedPoints
{
	struct FAIDataProviderFloatValue Radius;  // 0xD0(0x38)
	struct FAIDataProviderFloatValue SpaceBetween;  // 0x108(0x38)
	UEnvQueryContext* GenerateAround;  // 0x140(0x8)

}; 



// Class AIFramework.FWBTTask_PlayMontageSimple
// Size: 0xA0(Inherited: 0x70) 
struct UFWBTTask_PlayMontageSimple : public UBTTaskNode
{
	struct FMontageAssetSelector Montage;  // 0x70(0x20)
	struct UBehaviorTreeComponent* MyOwnerComp;  // 0x90(0x8)
	char bNonBlocking : 1;  // 0x98(0x1)
	char bCanAbortAnimation : 1;  // 0x98(0x1)
	char pad_152_1 : 6;  // 0x98(0x1)
	char pad_153[8];  // 0x99(0x8)

}; 



// Class AIFramework.BTDecorator_CanFireAt
// Size: 0x98(Inherited: 0x90) 
struct UBTDecorator_CanFireAt : public UBTDecorator_BlackboardBase
{
	char pad_144_1 : 7;  // 0x90(0x1)
	bool bFromTheHip : 1;  // 0x90(0x1)
	char pad_145[7];  // 0x91(0x7)

}; 



// Class AIFramework.ActionArea
// Size: 0x3C8(Inherited: 0x358) 
struct AActionArea : public ATriggerVolume
{
	char pad_856[8];  // 0x358(0x8)
	struct TArray<struct TSoftObjectPtr<ACharacterSpawner>> ExternalSpawners;  // 0x360(0x10)
	struct TArray<struct TSoftObjectPtr<AActor>> References;  // 0x370(0x10)
	struct TArray<struct ASpawnVolume*> ExternalSpawnVolumes;  // 0x380(0x10)
	struct TArray<struct ACharacterSpawner*> SpawnPoints;  // 0x390(0x10)
	struct TArray<struct ACharacterSpawner*> ExternalSpawnPoints;  // 0x3A0(0x10)
	struct TArray<struct ACharacterSpawner*> InternalSpawnPoints;  // 0x3B0(0x10)
	char bUseInternalSpawnPoints : 1;  // 0x3C0(0x1)
	char bEnabled : 1;  // 0x3C0(0x1)
	char bStartEnabled : 1;  // 0x3C0(0x1)
	char pad_960_1 : 5;  // 0x3C0(0x1)
	char pad_961[8];  // 0x3C1(0x8)

	bool IsEnabled(); // Function AIFramework.ActionArea.IsEnabled
	struct TArray<struct TSoftObjectPtr<ACharacterSpawner>> GetExternalSpawner(); // Function AIFramework.ActionArea.GetExternalSpawner
	void Enable(); // Function AIFramework.ActionArea.Enable
	void Disable(); // Function AIFramework.ActionArea.Disable
}; 



// Class AIFramework.FWAITask_JumpOver
// Size: 0xF8(Inherited: 0xD0) 
struct UFWAITask_JumpOver : public UAITask_PlayAnimation
{
	char pad_208[32];  // 0xD0(0x20)
	struct UAnimMontage* MontageWithSections;  // 0xF0(0x8)

}; 



// Class AIFramework.FWBTTask_MoveTo
// Size: 0xB8(Inherited: 0xB0) 
struct UFWBTTask_MoveTo : public UBTTask_MoveTo
{
	char bAllowFire : 1;  // 0xB0(0x1)
	char bAllowReload : 1;  // 0xB0(0x1)
	char pad_176_1 : 6;  // 0xB0(0x1)
	char pad_177[4];  // 0xB1(0x4)
	char pad_180_1 : 7;  // 0xB4(0x1)
	bool bOverrideMovementMood : 1;  // 0xB4(0x1)
	uint8_t  MovementMood;  // 0xB5(0x1)
	uint8_t  InvalidateCover;  // 0xB6(0x1)
	char pad_183[1];  // 0xB7(0x1)

}; 



// Class AIFramework.BTDecorator_AlliesObscuringTarget
// Size: 0xA0(Inherited: 0x68) 
struct UBTDecorator_AlliesObscuringTarget : public UBTDecorator
{
	struct FBlackboardKeySelector TargetKey;  // 0x68(0x28)
	float MinAngle;  // 0x90(0x4)
	float MinDistance;  // 0x94(0x4)
	char pad_152_1 : 7;  // 0x98(0x1)
	bool bUseOnlySquadMembers : 1;  // 0x98(0x1)
	char pad_153[7];  // 0x99(0x7)

}; 



// Class AIFramework.FWEnvQueryContext_BlackboardLocation
// Size: 0x30(Inherited: 0x28) 
struct UFWEnvQueryContext_BlackboardLocation : public UEnvQueryContext
{
	struct FName BlackboardLocationKey;  // 0x28(0x8)

}; 



// Class AIFramework.FWBTDecorator_IsInRequiredPathFollowingStatus
// Size: 0x70(Inherited: 0x68) 
struct UFWBTDecorator_IsInRequiredPathFollowingStatus : public UBTDecorator
{
	char EPathFollowingStatus RequiredPathFollowingStatus;  // 0x68(0x1)
	char pad_105[7];  // 0x69(0x7)

}; 



// Class AIFramework.DefendGoal
// Size: 0x428(Inherited: 0x428) 
struct ADefendGoal : public AGoalPoint
{

}; 



// Class AIFramework.BaseCharacterMovementComponent
// Size: 0xA50(Inherited: 0x900) 
struct UBaseCharacterMovementComponent : public UPcfCharacterMovementComponent
{
	char pad_2304_1 : 7;  // 0x900(0x1)
	bool NEW_ANIMATION_SYSTEM : 1;  // 0x8F8(0x1)
	char pad_2305_1 : 7;  // 0x901(0x1)
	bool bLimitSpeedByDirection : 1;  // 0x8F9(0x1)
	float MaxSpeedSideways;  // 0x8FC(0x4)
	float MaxSpeedBack;  // 0x900(0x4)
	uint8_t  MovementMood;  // 0x904(0x1)
	struct FMovementMoodSetup MovementMoodsConfig[8];  // 0x908(0x120)
	struct FMulticastInlineDelegate OnMovementMoodChangedEvent;  // 0xA28(0x10)
	float ExtraRVORadius;  // 0xA38(0x4)
	char pad_2623[17];  // 0xA3F(0x11)

	void SetAvoidanceWeight(float Weight); // Function AIFramework.BaseCharacterMovementComponent.SetAvoidanceWeight
	void OverrideMovementMoodSpeed(uint8_t  Mood, float Speed); // Function AIFramework.BaseCharacterMovementComponent.OverrideMovementMoodSpeed
	void OnRep_MovementMood(); // Function AIFramework.BaseCharacterMovementComponent.OnRep_MovementMood
	bool IsUsingNewAnimationSystem(); // Function AIFramework.BaseCharacterMovementComponent.IsUsingNewAnimationSystem
	float GetMovementMoodSpeed(uint8_t  Mood); // Function AIFramework.BaseCharacterMovementComponent.GetMovementMoodSpeed
}; 



// Class AIFramework.FireAtTargetGoal
// Size: 0x448(Inherited: 0x428) 
struct AFireAtTargetGoal : public AGoalPoint
{
	struct TArray<struct FGoalFireTarget> ShootersPerTarget;  // 0x428(0x10)
	char pad_1080_1 : 7;  // 0x438(0x1)
	bool bFireAtClosest : 1;  // 0x438(0x1)
	char pad_1081_1 : 7;  // 0x439(0x1)
	bool bRefreshTargets : 1;  // 0x439(0x1)
	char pad_1082_1 : 7;  // 0x43A(0x1)
	bool bCanReloadWeapon : 1;  // 0x43A(0x1)
	char pad_1083[1];  // 0x43B(0x1)
	float TargetsRefreshDelay;  // 0x43C(0x4)
	char pad_1088[8];  // 0x440(0x8)

}; 



// Class AIFramework.CharacterSpawner
// Size: 0x3C0(Inherited: 0x320) 
struct ACharacterSpawner : public AActor
{
	char pad_800_1 : 7;  // 0x320(0x1)
	bool bStartEnabled : 1;  // 0x320(0x1)
	char pad_801_1 : 7;  // 0x321(0x1)
	bool bEnabled : 1;  // 0x321(0x1)
	char pad_802_1 : 7;  // 0x322(0x1)
	bool bBannedFromEncounterManager : 1;  // 0x322(0x1)
	char pad_803[1];  // 0x323(0x1)
	char pad_804_1 : 7;  // 0x324(0x1)
	bool bSuppressDamageUntilMontageFinish : 1;  // 0x324(0x1)
	char pad_805_1 : 7;  // 0x325(0x1)
	bool bLaunchCharacter : 1;  // 0x325(0x1)
	char pad_806[2];  // 0x326(0x2)
	struct TArray<struct FAISpawnGroup> SpawnGroups;  // 0x328(0x10)
	int32_t NextSkelMeshIndex;  // 0x338(0x4)
	char pad_828[4];  // 0x33C(0x4)
	struct FMulticastInlineDelegate OnSpawn;  // 0x340(0x10)
	struct FMulticastInlineDelegate OnCharacterKilledDelegate;  // 0x350(0x10)
	struct FMulticastInlineDelegate OnKilledSpawnDelegate;  // 0x360(0x10)
	struct UFWAISystem* AISystem;  // 0x370(0x8)
	struct ABaseGameMode* BaseGameMode;  // 0x378(0x8)
	char pad_896[8];  // 0x380(0x8)
	struct TArray<struct TSoftObjectPtr<AActionArea>> LinktToActionAreas;  // 0x388(0x10)
	struct FVector LaunchDestination;  // 0x398(0xC)
	float LaunchRadius;  // 0x3A4(0x4)
	float LaunchGroundSpeed;  // 0x3A8(0x4)
	float LaunchExtraHeightInMiddle;  // 0x3AC(0x4)
	char pad_944_1 : 7;  // 0x3B0(0x1)
	bool bNotifyAboutEndOfLaunch : 1;  // 0x3B0(0x1)
	char pad_945_1 : 7;  // 0x3B1(0x1)
	bool bWaitForAnimationNotify : 1;  // 0x3B1(0x1)
	char pad_946[2];  // 0x3B2(0x2)
	struct FName AnimNotifyNameOverride;  // 0x3B4(0x8)
	char pad_956[4];  // 0x3BC(0x4)

	void RequestSpawnAI(struct UObject* WorldContextObject, struct FFWAIArchetypeVariation ArchetypeVariation, struct FVector SpawnLocation, struct FRotator SpawnRotation, struct TArray<struct FNameWrapper> CustomLoadoutClasses, struct FMontageAssetSelector Montage, char ETeam Team, struct AActor* SpawnInstigator, bool bDisableCollision); // Function AIFramework.CharacterSpawner.RequestSpawnAI
	void OnCharacterKilled(struct ABaseCharacter* character, struct FTakeHitInfo TakeHitInfo); // Function AIFramework.CharacterSpawner.OnCharacterKilled
	bool IsSpawnerEnabledOnStart(); // Function AIFramework.CharacterSpawner.IsSpawnerEnabledOnStart
	bool IsSpawnerEnabled(); // Function AIFramework.CharacterSpawner.IsSpawnerEnabled
	bool IsAllowedToSpawn(struct FAISpawnParams& SpawnParams); // Function AIFramework.CharacterSpawner.IsAllowedToSpawn
	void EnableSpawnGroup(int32_t GroupIndex, bool bResetCounters); // Function AIFramework.CharacterSpawner.EnableSpawnGroup
	void EnableSpawner(bool bResetCounters); // Function AIFramework.CharacterSpawner.EnableSpawner
	void EnableGroup(int32_t GroupIndex, bool bEnable, bool bResetCounters); // Function AIFramework.CharacterSpawner.EnableGroup
	void Enable(bool bEnable, bool bResetCounters); // Function AIFramework.CharacterSpawner.Enable
	void DisableSpawnGroup(int32_t GroupIndex); // Function AIFramework.CharacterSpawner.DisableSpawnGroup
	void DisableSpawner(); // Function AIFramework.CharacterSpawner.DisableSpawner
}; 



// Class AIFramework.AntFarmGoal
// Size: 0x438(Inherited: 0x428) 
struct AAntFarmGoal : public AGoalPoint
{
	struct TArray<struct TWeakObjectPtr<ABaseSmartObject>> MySmartObjects;  // 0x428(0x10)

	struct ABaseSmartObject* K2_GetNextSmartObject(struct AFWAIController* Querier, struct ABaseSmartObject* InSmartObject); // Function AIFramework.AntFarmGoal.K2_GetNextSmartObject
}; 



// Class AIFramework.AITask_PlayAnimationWithAdjust
// Size: 0xF8(Inherited: 0xD0) 
struct UAITask_PlayAnimationWithAdjust : public UAITask_PlayAnimation
{
	char pad_208[40];  // 0xD0(0x28)

}; 



// Class AIFramework.BTTask_PlaySmartObjectMontage
// Size: 0x88(Inherited: 0x78) 
struct UBTTask_PlaySmartObjectMontage : public UBTTask_GameplayTaskBase
{
	struct UFWMontageProvider* MontageProvider;  // 0x78(0x8)
	uint8_t  SmartObjectUsageState;  // 0x80(0x1)
	char pad_129[3];  // 0x81(0x3)
	char bCanAbortAnimation : 1;  // 0x84(0x1)
	char bUpdatePendingWeapon : 1;  // 0x84(0x1)
	char bEarlyFinishOnBlendOut : 1;  // 0x84(0x1)
	char bEarlyFinishBeforeBlendOut : 1;  // 0x84(0x1)
	char pad_132_1 : 4;  // 0x84(0x1)
	char pad_133[4];  // 0x85(0x4)

}; 



// Class AIFramework.FWCrowdFollowingComponent
// Size: 0x3B8(Inherited: 0x390) 
struct UFWCrowdFollowingComponent : public UCrowdFollowingComponent
{
	float CrowdCheckRadiusMultiplayer;  // 0x390(0x4)
	char pad_916[4];  // 0x394(0x4)
	struct UFWAITask_MantleOverCover* MantleTask;  // 0x398(0x8)
	char pad_928[24];  // 0x3A0(0x18)

	void OnMantleTaskEnded(struct UFWAITask* Task, uint8_t  Result); // Function AIFramework.FWCrowdFollowingComponent.OnMantleTaskEnded
}; 



// Class AIFramework.BTDecorator_Distance
// Size: 0xD8(Inherited: 0xD0) 
struct UBTDecorator_Distance : public UBTDecorator_DistanceBetween
{
	uint8_t  DiscreteDistance;  // 0xD0(0x1)
	char pad_209[7];  // 0xD1(0x7)

}; 



// Class AIFramework.GoalPoint
// Size: 0x428(Inherited: 0x320) 
struct AGoalPoint : public AActor
{
	char pad_800[8];  // 0x320(0x8)
	uint8_t  GoalCoverGeneration;  // 0x328(0x1)
	char pad_809[3];  // 0x329(0x3)
	float GoalRadius;  // 0x32C(0x4)
	float GoalHeight;  // 0x330(0x4)
	char pad_820[4];  // 0x334(0x4)
	struct AGoalArea* GoalSpace;  // 0x338(0x8)
	uint8_t  OrderType;  // 0x340(0x1)
	char MaxSkippablePointsNumber;  // 0x341(0x1)
	char pad_834[6];  // 0x342(0x6)
	struct FString SequenceOrder;  // 0x348(0x10)
	struct TArray<struct AActor*> References;  // 0x358(0x10)
	struct TArray<struct ACover*> Covers;  // 0x368(0x10)
	char ETeam TeamUsage;  // 0x378(0x1)
	char pad_889[7];  // 0x379(0x7)
	struct TArray<struct ACharacterSpawner*> Spawners;  // 0x380(0x10)
	struct TArray<struct AFWAIController*> Followers;  // 0x390(0x10)
	struct TArray<struct AFWAIController*> AssignedAIs;  // 0x3A0(0x10)
	int32_t MaxFollowers;  // 0x3B0(0x4)
	char pad_948[4];  // 0x3B4(0x4)
	struct UBehaviorTree* BTOverride;  // 0x3B8(0x8)
	struct TArray<struct FEQSQueryOverrideItem> EQSOverrides;  // 0x3C0(0x10)
	struct TArray<struct UAISenseConfig*> SensesConfigOverrides;  // 0x3D0(0x10)
	char pad_992[4];  // 0x3E0(0x4)
	float ReplenishDelay;  // 0x3E4(0x4)
	int32_t ReplenishAfterNumberGone;  // 0x3E8(0x4)
	char pad_1004[4];  // 0x3EC(0x4)
	struct TArray<UFWAIArchetype*> ValidAITypes;  // 0x3F0(0x10)
	char pad_1024_1 : 7;  // 0x400(0x1)
	bool bPriorityGoal : 1;  // 0x400(0x1)
	char pad_1025[3];  // 0x401(0x3)
	char bUseOnlyAssigned : 1;  // 0x404(0x1)
	char bRestrictAITypes : 1;  // 0x404(0x1)
	char bAcceptAIsOnlyInRadius : 1;  // 0x404(0x1)
	char bReplenish : 1;  // 0x404(0x1)
	char bBreakableByCombatFlow : 1;  // 0x404(0x1)
	char pad_1028_1 : 3;  // 0x404(0x1)
	char pad_1029[4];  // 0x405(0x4)
	uint8_t  AssignmentType;  // 0x408(0x1)
	char pad_1033[3];  // 0x409(0x3)
	char pad_1036_1 : 2;  // 0x40C(0x1)
	char bIsEnabled : 1;  // 0x40C(0x1)
	char bHasGoalSpecificAIBehavior : 1;  // 0x40C(0x1)
	char bStartGoalEnabled : 1;  // 0x40C(0x1)
	char pad_1036_2 : 3;  // 0x40C(0x1)
	char pad_1037[4];  // 0x40D(0x4)
	struct USceneComponent* SceneComponent;  // 0x410(0x8)
	struct FMulticastInlineDelegate OnFollowerDiedEvent;  // 0x418(0x10)

	bool WillAcceptMoreAI(struct AAIController* AI, char EAIForceParam bForce); // Function AIFramework.GoalPoint.WillAcceptMoreAI
	bool WillAcceptAIType(UFWAIArchetype* Type); // Function AIFramework.GoalPoint.WillAcceptAIType
	void UnregisterFollower(struct AAIController* AI); // Function AIFramework.GoalPoint.UnregisterFollower
	bool RegisterFollower(struct AAIController* NewAI, bool bCheckToAccept); // Function AIFramework.GoalPoint.RegisterFollower
	void OnSetupGoalSpecificAIBehavior(struct AFWAIController* AI); // Function AIFramework.GoalPoint.OnSetupGoalSpecificAIBehavior
	void OnRevertGoalSpecificAIBehavior(struct AFWAIController* AI); // Function AIFramework.GoalPoint.OnRevertGoalSpecificAIBehavior
	void OnFollowerDied(struct AAIController* AI); // Function AIFramework.GoalPoint.OnFollowerDied
	void OnCharacterSpawned(struct Acharacter* Pawn, struct AFWAIController* Controller, int32_t SpawnGroupIndex); // Function AIFramework.GoalPoint.OnCharacterSpawned
	bool IsInsideOrOn(struct FVector& In); // Function AIFramework.GoalPoint.IsInsideOrOn
	bool IsEnabled(); // Function AIFramework.GoalPoint.IsEnabled
	struct AGoalArea* GetGoalSpace(); // Function AIFramework.GoalPoint.GetGoalSpace
	float GetGoalRadius(); // Function AIFramework.GoalPoint.GetGoalRadius
	struct TArray<struct AFWAIController*> GetFollowers(); // Function AIFramework.GoalPoint.GetFollowers
	struct FBox GetBounds(); // Function AIFramework.GoalPoint.GetBounds
	struct TArray<struct AFWAIController*> GetAssignedAIs(); // Function AIFramework.GoalPoint.GetAssignedAIs
	void Enable(bool bEnabled); // Function AIFramework.GoalPoint.Enable
	bool AssignFollowers(struct TArray<struct AAIController*>& AIControllers, bool bRemoveOld); // Function AIFramework.GoalPoint.AssignFollowers
	bool AssignFollower(struct AAIController* AI, bool bRemoveOld); // Function AIFramework.GoalPoint.AssignFollower
}; 



// Class AIFramework.FWEncounterManager
// Size: 0x600(Inherited: 0x320) 
struct AFWEncounterManager : public AActor
{
	char pad_800[8];  // 0x320(0x8)
	int32_t WavePreviewIndex;  // 0x328(0x4)
	struct FName EncounterName;  // 0x32C(0x8)
	char pad_820_1 : 7;  // 0x334(0x1)
	bool bEnabled : 1;  // 0x334(0x1)
	char pad_821[3];  // 0x335(0x3)
	struct ACombatArena* EncounterArena;  // 0x338(0x8)
	struct UFWEncounterData* EncounterSetup;  // 0x340(0x8)
	struct TArray<struct FFWEncounterWaveData> Waves;  // 0x348(0x10)
	struct FEncounterSetup DefaultSetup;  // 0x358(0x20)
	struct TArray<struct FConditionalEncounterSetupGroup> ConditionalSetups;  // 0x378(0x10)
	char pad_904_1 : 7;  // 0x388(0x1)
	bool bAppendImportedData : 1;  // 0x388(0x1)
	char pad_905[7];  // 0x389(0x7)
	struct UFWEncounterData* SetupToImport;  // 0x390(0x8)
	struct FMulticastInlineDelegate OnWaveBeginSpawning;  // 0x398(0x10)
	struct FMulticastInlineDelegate OnWaveEndSpawning;  // 0x3A8(0x10)
	struct FMulticastInlineDelegate OnWaveKilled;  // 0x3B8(0x10)
	struct FMulticastInlineDelegate OnWaveTimeElapsed;  // 0x3C8(0x10)
	struct FMulticastInlineDelegate OnAllWavesEndSpawning;  // 0x3D8(0x10)
	struct FMulticastInlineDelegate OnAllWavesWereKilled;  // 0x3E8(0x10)
	struct FMulticastInlineDelegate OnCharactersWereKilled;  // 0x3F8(0x10)
	struct FMulticastInlineDelegate OnSpawnedCharacterKilled;  // 0x408(0x10)
	struct FMulticastInlineDelegate OnCharacterSpawned;  // 0x418(0x10)
	struct FMulticastInlineDelegate OnSetupConditionEvaluation;  // 0x428(0x10)
	struct FMulticastInlineDelegate OnWaveBeginCombat;  // 0x438(0x10)
	struct FMulticastInlineDelegate OnEncounterReset;  // 0x448(0x10)
	struct UFWAISystem* AISystem;  // 0x458(0x8)
	struct ABaseGameMode* BaseGameMode;  // 0x460(0x8)
	struct UAISpawnSubsystem* SpawnSubsystem;  // 0x468(0x8)
	struct UFWAdaptiveMusicSystem* AdaptiveMusicSystem;  // 0x470(0x8)
	struct AActor* EncounterInstigator;  // 0x478(0x8)
	char pad_1152[208];  // 0x480(0xD0)
	struct TArray<struct ABaseCharacter*> SpawnedCharacters;  // 0x550(0x10)
	struct TArray<struct ACharacterSpawner*> BusySpawners;  // 0x560(0x10)
	char pad_1392[144];  // 0x570(0x90)

	void StopEncounter(struct UObject* WorldContextObject, struct FName InEncounterName, struct AFWEncounterManager* Encounter); // Function AIFramework.FWEncounterManager.StopEncounter
	bool StartEncounter(struct UObject* WorldContextObject, struct AActor* InstigatorActor, struct FName InEncounterName, struct AFWEncounterManager* Encounter, bool bDontStartIfCompleted); // Function AIFramework.FWEncounterManager.StartEncounter
	void SetEncounterCompleted(bool bCompleted); // Function AIFramework.FWEncounterManager.SetEncounterCompleted
	void SetConditionAsValid(bool bForceRestart); // Function AIFramework.FWEncounterManager.SetConditionAsValid
	void ResetEncounter(struct UObject* WorldContextObject, struct FName InEncounterName, struct AFWEncounterManager* Encounter); // Function AIFramework.FWEncounterManager.ResetEncounter
	void OnTeamWipeout(); // Function AIFramework.FWEncounterManager.OnTeamWipeout
	void OnSpawned(struct AActor* InInstigator, struct ACharacterSpawner* Spawner, struct AAIController* Controller, struct APawn* Pawn, struct FAISpawnParams& AISpawnParams); // Function AIFramework.FWEncounterManager.OnSpawned
	void OnCharacterKilled(struct ABaseCharacter* character, struct FTakeHitInfo TakeHitInfo); // Function AIFramework.FWEncounterManager.OnCharacterKilled
	void OnBattleEvent(struct FGlobalEventParams& GlobalEvent); // Function AIFramework.FWEncounterManager.OnBattleEvent
	void OnArenaSwitchedOn(struct ACombatArena* CombatArena, bool bSwitchedByTriggerVolume); // Function AIFramework.FWEncounterManager.OnArenaSwitchedOn
	void OnArenaSwitchedOff(struct ACombatArena* CombatArena, bool bSwitchedByTriggerVolume, int32_t AIsLeftToFallback); // Function AIFramework.FWEncounterManager.OnArenaSwitchedOff
	void OnArenaChanged(struct ACombatArena* CombatArena, bool bSpawnersAdded); // Function AIFramework.FWEncounterManager.OnArenaChanged
	bool IsEncounterCompleted(); // Function AIFramework.FWEncounterManager.IsEncounterCompleted
	bool IsCurrentWaveForced(); // Function AIFramework.FWEncounterManager.IsCurrentWaveForced
	bool IsAvailable(); // Function AIFramework.FWEncounterManager.IsAvailable
	float GetWaveTime(); // Function AIFramework.FWEncounterManager.GetWaveTime
	struct FText GetWaveDescription(int32_t Idx); // Function AIFramework.FWEncounterManager.GetWaveDescription
	struct FFWEncounterWaveData GetWave(char Idx); // Function AIFramework.FWEncounterManager.GetWave
	int32_t GetSpawnsPerWave(); // Function AIFramework.FWEncounterManager.GetSpawnsPerWave
	int32_t GetNumCharactersLeft(); // Function AIFramework.FWEncounterManager.GetNumCharactersLeft
	int32_t GetNumCharactersAlive(); // Function AIFramework.FWEncounterManager.GetNumCharactersAlive
	struct FEncounterSetup GetDefaultSetup(); // Function AIFramework.FWEncounterManager.GetDefaultSetup
	int32_t GetCurrentWaveIndex(); // Function AIFramework.FWEncounterManager.GetCurrentWaveIndex
	struct FEncounterSetup GetCurrentSetup(); // Function AIFramework.FWEncounterManager.GetCurrentSetup
	bool ForceNextWave(); // Function AIFramework.FWEncounterManager.ForceNextWave
	bool EnqueueAdditionalSpawn(struct ACharacterSpawner* Spawner, bool bIncreaseLimits); // Function AIFramework.FWEncounterManager.EnqueueAdditionalSpawn
	void EnableEncounter(bool bEnable); // Function AIFramework.FWEncounterManager.EnableEncounter
	void AssignSetup(struct UFWEncounterData* InEncounterSetup); // Function AIFramework.FWEncounterManager.AssignSetup
}; 



// Class AIFramework.FWEnvQueryTest_HasDirectPath
// Size: 0x288(Inherited: 0x268) 
struct UFWEnvQueryTest_HasDirectPath : public UEnvQueryTest
{
	UEnvQueryContext* Context;  // 0x268(0x8)
	UNavigationQueryFilter* FilterClass;  // 0x270(0x8)
	char pad_632_1 : 7;  // 0x278(0x1)
	bool bProject : 1;  // 0x278(0x1)
	char pad_633_1 : 7;  // 0x279(0x1)
	bool bProjectContext : 1;  // 0x279(0x1)
	char pad_634[2];  // 0x27A(0x2)
	float ProjectDown;  // 0x27C(0x4)
	float ProjectUp;  // 0x280(0x4)
	char pad_644[4];  // 0x284(0x4)

}; 



// Class AIFramework.FWNavigationFilter_NoLinks
// Size: 0x48(Inherited: 0x48) 
struct UFWNavigationFilter_NoLinks : public UNavigationQueryFilter
{

}; 



// Class AIFramework.BaseSmartObject
// Size: 0x420(Inherited: 0x320) 
struct ABaseSmartObject : public AActor
{
	struct FMulticastInlineDelegate OnSmartObjectFinished;  // 0x320(0x10)
	struct UAnimMontage* InProgressEventMontage;  // 0x330(0x8)
	struct ABaseCharacter* CharBlockingSync;  // 0x338(0x8)
	struct USmartObjectSlotComponent* DefaultSlotComponent;  // 0x340(0x8)
	char pad_840[8];  // 0x348(0x8)
	struct TArray<struct AGoalPoint*> LinkedGoals;  // 0x350(0x10)
	struct UAnimMontage* MontageToPlay;  // 0x360(0x8)
	struct UBehaviorTree* SmartObjectBehaviorTree;  // 0x368(0x8)
	char pad_880_1 : 7;  // 0x370(0x1)
	bool bSuppressDamageDuringUse : 1;  // 0x370(0x1)
	char pad_881_1 : 7;  // 0x371(0x1)
	bool bDisableCollisionDuringUse : 1;  // 0x371(0x1)
	char pad_882_1 : 7;  // 0x372(0x1)
	bool bAutomaticallySynchronize : 1;  // 0x372(0x1)
	char pad_883[1];  // 0x373(0x1)
	float TimeBetweenSyncLoops;  // 0x374(0x4)
	float SynchronizedMontageInitialDelay;  // 0x378(0x4)
	int32_t NumSynchronizedLoopsToPlay;  // 0x37C(0x4)
	char pad_896[4];  // 0x380(0x4)
	float AfterSynchronizationDuration;  // 0x384(0x4)
	float AfterSynchronizationDurationRandomDeviation;  // 0x388(0x4)
	char pad_908[4];  // 0x38C(0x4)
	struct FString SequenceOrder;  // 0x390(0x10)
	char pad_928_1 : 7;  // 0x3A0(0x1)
	bool bIsSequentialSmartObject : 1;  // 0x3A0(0x1)
	char pad_929[3];  // 0x3A1(0x3)
	float LastSequenceFinishTime;  // 0x3A4(0x4)
	struct TMap<struct FName, struct FString> SmartObjectSockets;  // 0x3A8(0x50)
	char pad_1016_1 : 7;  // 0x3F8(0x1)
	bool bEnableObjectsAutoplacement : 1;  // 0x3F8(0x1)
	char pad_1017[7];  // 0x3F9(0x7)
	struct TArray<struct ABaseCharacter*> CharactersUsingMe;  // 0x400(0x10)
	struct USmartObjectSharedSpaceComponent* CachedSharedSpaceComponent;  // 0x410(0x8)
	char pad_1048_1 : 7;  // 0x418(0x1)
	bool bOverrideMinDistanceToPlayer : 1;  // 0x418(0x1)
	char pad_1049[3];  // 0x419(0x3)
	float MinimalDistanceToPlayer;  // 0x41C(0x4)

	void TrySynchronization(); // Function AIFramework.BaseSmartObject.TrySynchronization
	bool ShouldExecuteSmartObjectNotify(struct ABaseCharacter* CharacterUsingMe, struct USmartObjectSlotComponent* Slot, struct FName NotifyName, uint8_t  NotifyType, uint8_t  AttachPoint); // Function AIFramework.BaseSmartObject.ShouldExecuteSmartObjectNotify
	void PlaySynchronizedLoopSection(); // Function AIFramework.BaseSmartObject.PlaySynchronizedLoopSection
	void OnSOEventMontageBlendingOut(struct UAnimMontage* Montage, bool bInterrupted); // Function AIFramework.BaseSmartObject.OnSOEventMontageBlendingOut
	void OnSmartObjectSyncLoopStarted(); // Function AIFramework.BaseSmartObject.OnSmartObjectSyncLoopStarted
	void OnSmartObjectSyncLoopEnded(); // Function AIFramework.BaseSmartObject.OnSmartObjectSyncLoopEnded
	void OnSmartObjectStartSynchronization(); // Function AIFramework.BaseSmartObject.OnSmartObjectStartSynchronization
	void OnSmartObjectStarted(struct ABaseCharacter* CharacterUsingMe, struct USmartObjectSlotComponent* Slot); // Function AIFramework.BaseSmartObject.OnSmartObjectStarted
	void OnSmartObjectSkippedEnter(struct ABaseCharacter* CharacterUsingMe, struct USmartObjectSlotComponent* Slot); // Function AIFramework.BaseSmartObject.OnSmartObjectSkippedEnter
	void OnSmartObjectNotify(struct ABaseCharacter* CharacterUsingMe, struct USmartObjectSlotComponent* Slot, struct FName NotifyName, uint8_t  NotifyType, uint8_t  AttachPoint); // Function AIFramework.BaseSmartObject.OnSmartObjectNotify
	void OnSmartObjectEnded(struct USmartObjectSlotComponent* Slot); // Function AIFramework.BaseSmartObject.OnSmartObjectEnded
	int32_t GetUsingCharacters(struct TArray<struct ABaseCharacter*>& OutCharacters); // Function AIFramework.BaseSmartObject.GetUsingCharacters
	struct FMontageAssetSelector GetSyncLoopMontageEvent(struct AAIController* AI, struct USmartObjectSlotComponent* Slot); // Function AIFramework.BaseSmartObject.GetSyncLoopMontageEvent
	int32_t GetSlotsInUseCount(); // Function AIFramework.BaseSmartObject.GetSlotsInUseCount
	struct FMontageAssetSelector GetPostSyncMontageEvent(struct AAIController* AI, struct USmartObjectSlotComponent* Slot); // Function AIFramework.BaseSmartObject.GetPostSyncMontageEvent
	struct FMontageAssetSelector GetLoopMontageEvent(struct AAIController* AI, struct USmartObjectSlotComponent* Slot); // Function AIFramework.BaseSmartObject.GetLoopMontageEvent
	struct FMontageAssetSelector GetForceOutMontageEvent(struct AAIController* AI, struct USmartObjectSlotComponent* Slot); // Function AIFramework.BaseSmartObject.GetForceOutMontageEvent
	struct FMontageAssetSelector GetExitMontageEvent(struct AAIController* AI, struct USmartObjectSlotComponent* Slot); // Function AIFramework.BaseSmartObject.GetExitMontageEvent
	struct FMontageAssetSelector GetEnterMontageEvent(struct AAIController* AI, struct USmartObjectSlotComponent* Slot); // Function AIFramework.BaseSmartObject.GetEnterMontageEvent
	void FinishSmartObjectUsage(struct USmartObjectSlotComponent* Slot); // Function AIFramework.BaseSmartObject.FinishSmartObjectUsage
	bool CanStartSynchronization(); // Function AIFramework.BaseSmartObject.CanStartSynchronization
}; 



// Class AIFramework.QueryContext_AllEnemies
// Size: 0x28(Inherited: 0x28) 
struct UQueryContext_AllEnemies : public UEnvQueryContext
{

}; 



// Class AIFramework.QueryContext_AllEnemiesWithinHostileRange
// Size: 0x30(Inherited: 0x28) 
struct UQueryContext_AllEnemiesWithinHostileRange : public UEnvQueryContext
{
	char pad_40[8];  // 0x28(0x8)

}; 



// Class AIFramework.FWWaveSpawningSystem
// Size: 0x698(Inherited: 0x320) 
struct AFWWaveSpawningSystem : public AActor
{
	struct FMulticastInlineDelegate OnWaveKilled;  // 0x320(0x10)
	struct FMulticastInlineDelegate OnCharacterKilled;  // 0x330(0x10)
	struct FMulticastInlineDelegate OnCharacterSpawned;  // 0x340(0x10)
	struct FMulticastInlineDelegate OnHPCountReached;  // 0x350(0x10)
	struct FMulticastInlineDelegate OnKillCountReached;  // 0x360(0x10)
	struct FMulticastInlineDelegate OnWaveEndSpawning;  // 0x370(0x10)
	struct FMulticastInlineDelegate OnWaveBeginSpawning;  // 0x380(0x10)
	struct FMulticastInlineDelegate OnWSSBeginWork;  // 0x390(0x10)
	struct FMulticastInlineDelegate OnTeamWipeout;  // 0x3A0(0x10)
	struct FMulticastInlineDelegate OnShutdown;  // 0x3B0(0x10)
	struct FMulticastInlineDelegate OnBeginCombat;  // 0x3C0(0x10)
	char pad_976_1 : 7;  // 0x3D0(0x1)
	bool bStartMusic : 1;  // 0x3D0(0x1)
	char pad_977[7];  // 0x3D1(0x7)
	struct UBaseBiomeData* Biome;  // 0x3D8(0x8)
	struct TArray<struct FSpawnWaveData> Waves;  // 0x3E0(0x10)
	char pad_1008[536];  // 0x3F0(0x218)
	struct FWssTransient transient;  // 0x608(0x78)
	char pad_1664[24];  // 0x680(0x18)

	void StaticPrint(struct UObject* WorldContextObject, struct FString Message, uint8_t  Type); // Function AIFramework.FWWaveSpawningSystem.StaticPrint
	void StartWaveWithDelay(int32_t WaveIndex, float Seconds); // Function AIFramework.FWWaveSpawningSystem.StartWaveWithDelay
	struct TArray<struct AFWWaveSpawningSystem*> StartWavesByNames(struct TArray<struct FName>& WaveNamesToStart); // Function AIFramework.FWWaveSpawningSystem.StartWavesByNames
	void StartWaveByNameWithDelay(struct FName WaveName, float Seconds); // Function AIFramework.FWWaveSpawningSystem.StartWaveByNameWithDelay
	struct AFWWaveSpawningSystem* StartWaveByName(struct FName WaveName); // Function AIFramework.FWWaveSpawningSystem.StartWaveByName
	struct AFWWaveSpawningSystem* StartWave(int32_t WaveIndex); // Function AIFramework.FWWaveSpawningSystem.StartWave
	void ShutdownWss(); // Function AIFramework.FWWaveSpawningSystem.ShutdownWss
	void ShutdownCurrentWss(struct UObject* WorldContextObject); // Function AIFramework.FWWaveSpawningSystem.ShutdownCurrentWss
	struct AFWWaveSpawningSystem* ResetWaveByName(struct FName WaveName); // Function AIFramework.FWWaveSpawningSystem.ResetWaveByName
	struct AFWWaveSpawningSystem* ResetWave(int32_t WaveIndex); // Function AIFramework.FWWaveSpawningSystem.ResetWave
	void Print(struct FString Message, uint8_t  Type); // Function AIFramework.FWWaveSpawningSystem.Print
	void OnSpawnVolumeStateChanged(struct ASpawnVolume* Volume); // Function AIFramework.FWWaveSpawningSystem.OnSpawnVolumeStateChanged
	void OnServerRespawnPlayerHandler(uint8_t  RespawnReason); // Function AIFramework.FWWaveSpawningSystem.OnServerRespawnPlayerHandler
	void OnLevelTransitionStartedHandler(struct FName FromRegionName, struct FName ToRegionName); // Function AIFramework.FWWaveSpawningSystem.OnLevelTransitionStartedHandler
	void OnCharacterKilledHandler(struct ABaseCharacter* character, struct FTakeHitInfo TakeHitInfo); // Function AIFramework.FWWaveSpawningSystem.OnCharacterKilledHandler
	bool IsWaveKilled(int32_t WaveIndex); // Function AIFramework.FWWaveSpawningSystem.IsWaveKilled
	bool IsWaveByNameKilled(struct FName WaveName); // Function AIFramework.FWWaveSpawningSystem.IsWaveByNameKilled
	bool IsRunning(); // Function AIFramework.FWWaveSpawningSystem.IsRunning
	bool IsAnyWaveAlive(); // Function AIFramework.FWWaveSpawningSystem.IsAnyWaveAlive
	struct FName GetWaveName(int32_t WaveIndex); // Function AIFramework.FWWaveSpawningSystem.GetWaveName
	int32_t GetWaveIndex(struct FName WaveName); // Function AIFramework.FWWaveSpawningSystem.GetWaveIndex
	int32_t GetTimesWaveStarted(int32_t WaveIndex); // Function AIFramework.FWWaveSpawningSystem.GetTimesWaveStarted
	int32_t GetPlayersCount(); // Function AIFramework.FWWaveSpawningSystem.GetPlayersCount
	int32_t GetNumberOfWavesStarted(); // Function AIFramework.FWWaveSpawningSystem.GetNumberOfWavesStarted
	int32_t GetNumberOfWavesNotStarted(); // Function AIFramework.FWWaveSpawningSystem.GetNumberOfWavesNotStarted
	int32_t GetNumberOfWavesKilled(); // Function AIFramework.FWWaveSpawningSystem.GetNumberOfWavesKilled
	int32_t GetNumberOfWavesAlive(); // Function AIFramework.FWWaveSpawningSystem.GetNumberOfWavesAlive
	int32_t GetEnemiesSpawnedOverall(); // Function AIFramework.FWWaveSpawningSystem.GetEnemiesSpawnedOverall
	int32_t GetEnemiesSpawnedByName(struct FName WaveName); // Function AIFramework.FWWaveSpawningSystem.GetEnemiesSpawnedByName
	int32_t GetEnemiesSpawned(int32_t WaveIndex); // Function AIFramework.FWWaveSpawningSystem.GetEnemiesSpawned
	int32_t GetEnemiesKilledOverall(); // Function AIFramework.FWWaveSpawningSystem.GetEnemiesKilledOverall
	int32_t GetEnemiesKilledByName(struct FName WaveName); // Function AIFramework.FWWaveSpawningSystem.GetEnemiesKilledByName
	int32_t GetEnemiesKilled(int32_t WaveIndex); // Function AIFramework.FWWaveSpawningSystem.GetEnemiesKilled
	int32_t GetEnemiesAliveOverall(); // Function AIFramework.FWWaveSpawningSystem.GetEnemiesAliveOverall
	int32_t GetEnemiesAliveByName(struct FName WaveName); // Function AIFramework.FWWaveSpawningSystem.GetEnemiesAliveByName
	int32_t GetEnemiesAlive(int32_t WaveIndex); // Function AIFramework.FWWaveSpawningSystem.GetEnemiesAlive
	void CacheDataForBiome(struct UBaseBiomeData* CurrentBiome); // Function AIFramework.FWWaveSpawningSystem.CacheDataForBiome
	void AbilityStartWaveByNameFromCurrentWss(struct UObject* WorldContextObject, struct FName WaveName); // Function AIFramework.FWWaveSpawningSystem.AbilityStartWaveByNameFromCurrentWss
}; 



// Class AIFramework.FWEnvQueryTest_IsReachable
// Size: 0x2F8(Inherited: 0x268) 
struct UFWEnvQueryTest_IsReachable : public UEnvQueryTest
{
	UEnvQueryContext* Context;  // 0x268(0x8)
	struct FAIDataProviderFloatValue ExtraRadius;  // 0x270(0x38)
	struct FAIDataProviderFloatValue RadiusMultiplier;  // 0x2A8(0x38)
	UNavigationQueryFilter* FilterClass;  // 0x2E0(0x8)
	char pad_744_1 : 7;  // 0x2E8(0x1)
	bool bProject : 1;  // 0x2E8(0x1)
	char pad_745_1 : 7;  // 0x2E9(0x1)
	bool bProjectContext : 1;  // 0x2E9(0x1)
	char pad_746_1 : 7;  // 0x2EA(0x1)
	bool bUseContextNavQueryExtentForItems : 1;  // 0x2EA(0x1)
	char pad_747[1];  // 0x2EB(0x1)
	float ProjectDown;  // 0x2EC(0x4)
	float ProjectUp;  // 0x2F0(0x4)
	char pad_756[4];  // 0x2F4(0x4)

}; 



// Class AIFramework.FWBTDecorator_CheckGameplayTagsOnActor
// Size: 0xC8(Inherited: 0xC8) 
struct UFWBTDecorator_CheckGameplayTagsOnActor : public UBTDecorator_CheckGameplayTagsOnActor
{

}; 



// Class AIFramework.WaypointNavigationGraph
// Size: 0x860(Inherited: 0x530) 
struct AWaypointNavigationGraph : public ANavigationData
{
	char pad_1328[816];  // 0x530(0x330)

}; 



// Class AIFramework.AIRouteRenderingComponent
// Size: 0x510(Inherited: 0x510) 
struct UAIRouteRenderingComponent : public UPrimitiveComponent
{

}; 



// Class AIFramework.AISpawnSubsystem
// Size: 0x1D0(Inherited: 0x28) 
struct UAISpawnSubsystem : public UObject
{
	struct UFWAISystem* AISystem;  // 0x28(0x8)
	struct ABaseGameMode* BaseGameMode;  // 0x30(0x8)
	char pad_56[8];  // 0x38(0x8)
	struct TArray<struct FAISpawnParams> SpawnRequests;  // 0x40(0x10)
	char pad_80[312];  // 0x50(0x138)
	struct FContinousSpawnSetup ContinousSpawnSetup;  // 0x188(0x48)

	void StopContinuousSpawnInRadius(struct UObject* WorldContextObject); // Function AIFramework.AISpawnSubsystem.StopContinuousSpawnInRadius
	bool StartContinuousSpawnInRadius(struct UObject* WorldContextObject, struct FVector Origin, float Radius, float Frequency, struct TArray<ABaseCharacter*> CharactersWhitelist, int32_t MaxSpawnsPerWave); // Function AIFramework.AISpawnSubsystem.StartContinuousSpawnInRadius
	bool RequestSpawnInRadius(struct UObject* WorldContextObject, struct FVector Origin, float Radius, struct TArray<ABaseCharacter*> CharactersWhitelist, int32_t MaxSpawnsPerWave); // Function AIFramework.AISpawnSubsystem.RequestSpawnInRadius
	void OnAITaskEnded(struct UFWAITask* Task, uint8_t  Result); // Function AIFramework.AISpawnSubsystem.OnAITaskEnded
}; 



// Class AIFramework.FWAITask_Dash
// Size: 0xD8(Inherited: 0xD0) 
struct UFWAITask_Dash : public UAITask_PlayAnimation
{
	char pad_208[8];  // 0xD0(0x8)

}; 



// Class AIFramework.AssaultGoal
// Size: 0x448(Inherited: 0x448) 
struct AAssaultGoal : public AFireAtTargetGoal
{

}; 



// Class AIFramework.FWBTTask_ExecuteGameplayAbility
// Size: 0xA0(Inherited: 0x78) 
struct UFWBTTask_ExecuteGameplayAbility : public UBTTask_GameplayTaskBase
{
	UFWAITask_ExecuteGameplayAbility* AITask;  // 0x78(0x8)
	struct FGameplayTagContainer GameplayAbilityTag;  // 0x80(0x20)

}; 



// Class AIFramework.BaseGoalTarget
// Size: 0x398(Inherited: 0x320) 
struct ABaseGoalTarget : public AActor
{
	char pad_800[120];  // 0x320(0x78)

	void SetMaxHealth(float InMaxHealth); // Function AIFramework.BaseGoalTarget.SetMaxHealth
	void SetHealth(float InHealth); // Function AIFramework.BaseGoalTarget.SetHealth
	void K2_SetTeam(char ETeam NewTeam); // Function AIFramework.BaseGoalTarget.K2_SetTeam
	char ETeam K2_GetTeam(); // Function AIFramework.BaseGoalTarget.K2_GetTeam
	float GetMaxHealth(); // Function AIFramework.BaseGoalTarget.GetMaxHealth
	float GetHealth(); // Function AIFramework.BaseGoalTarget.GetHealth
}; 



// Class AIFramework.BTDecorator_DistanceBetween
// Size: 0xD0(Inherited: 0x68) 
struct UBTDecorator_DistanceBetween : public UBTDecorator
{
	char EArithmeticKeyOperation Operator;  // 0x68(0x1)
	char pad_105[7];  // 0x69(0x7)
	struct FBlackboardKeySelector BlackboardKeyA;  // 0x70(0x28)
	struct FBlackboardKeySelector BlackboardKeyB;  // 0x98(0x28)
	float SpecifiedDistance;  // 0xC0(0x4)
	char pad_196[4];  // 0xC4(0x4)
	char bUseSelf : 1;  // 0xC8(0x1)
	char bCalculateAs2D : 1;  // 0xC8(0x1)
	char bCalculateZOnly : 1;  // 0xC8(0x1)
	char pad_200_1 : 5;  // 0xC8(0x1)
	char pad_201[4];  // 0xC9(0x4)
	float DistanceCalculationUpdateRate;  // 0xCC(0x4)

}; 



// Class AIFramework.SmartObjectSharedSpaceComponent
// Size: 0x580(Inherited: 0x530) 
struct USmartObjectSharedSpaceComponent : public USphereComponent
{
	struct TMap<struct USceneComponent*, struct FTransform> InitialTransforms;  // 0x528(0x50)

}; 



// Class AIFramework.FWCharacterCache
// Size: 0x480(Inherited: 0x320) 
struct AFWCharacterCache : public AActor
{
	char pad_800[8];  // 0x320(0x8)
	struct FMulticastInlineDelegate OnBiomeLoaded;  // 0x328(0x10)
	struct FMasterBiome MasterBiome;  // 0x338(0x78)
	struct TArray<struct UObject*> BiomesLoadedForObjects;  // 0x3B0(0x10)
	struct FCharacterCacheRepData RepData;  // 0x3C0(0x28)
	struct FCharacterAssetPool Assets;  // 0x3E8(0x50)
	char pad_1080[72];  // 0x438(0x48)

	void OnRep_RepDataChanged(); // Function AIFramework.FWCharacterCache.OnRep_RepDataChanged
	void OnBiomeUnloadDEBUG(struct UObject* WorldContextObject, struct UBaseBiomeData* Biome); // Function AIFramework.FWCharacterCache.OnBiomeUnloadDEBUG
	void OnBiomeUnload(struct UBaseBiomeData* Biome, struct UObject* OwnerObject); // Function AIFramework.FWCharacterCache.OnBiomeUnload
	void OnBiomeLoadDEBUG(struct UObject* WorldContextObject, struct UBaseBiomeData* Biome, bool bIsWorldBiome); // Function AIFramework.FWCharacterCache.OnBiomeLoadDEBUG
	void OnBiomeLoad(struct UBaseBiomeData* Biome, struct UObject* OwnerObject, bool bIsWorldBiome); // Function AIFramework.FWCharacterCache.OnBiomeLoad
}; 



// Class AIFramework.BlackboardKeyType_CombatSpot
// Size: 0x30(Inherited: 0x30) 
struct UBlackboardKeyType_CombatSpot : public UBlackboardKeyType
{

}; 



// Class AIFramework.FWEnvQueryContext_BBCustomLocation
// Size: 0x30(Inherited: 0x30) 
struct UFWEnvQueryContext_BBCustomLocation : public UFWEnvQueryContext_BlackboardLocation
{

}; 



// Class AIFramework.BTDecorator_CanCombatActionEx
// Size: 0x70(Inherited: 0x68) 
struct UBTDecorator_CanCombatActionEx : public UBTDecorator
{
	char bRequireSight : 1;  // 0x68(0x1)
	char bOnlyInMoveDirection : 1;  // 0x68(0x1)
	char pad_104_1 : 6;  // 0x68(0x1)
	char pad_105[8];  // 0x69(0x8)

}; 



// Class AIFramework.FWBTTask_CoverActionExt
// Size: 0x98(Inherited: 0x78) 
struct UFWBTTask_CoverActionExt : public UBTTask_GameplayTaskBase
{
	char pad_120_1 : 7;  // 0x78(0x1)
	bool bReqireSight : 1;  // 0x78(0x1)
	char pad_121_1 : 7;  // 0x79(0x1)
	bool bForceCollision : 1;  // 0x79(0x1)
	char pad_122[2];  // 0x7A(0x2)
	float WaitTime;  // 0x7C(0x4)
	float RandomDeviation;  // 0x80(0x4)
	char bAutoReloadOnLowAmmo : 1;  // 0x84(0x1)
	char pad_132_1 : 7;  // 0x84(0x1)
	char pad_133[4];  // 0x85(0x4)
	UFWAITask_CoverAction* AITask;  // 0x88(0x8)
	uint8_t  ShootingType;  // 0x90(0x1)
	char pad_145[7];  // 0x91(0x7)

}; 



// Class AIFramework.BTDecorator_InCombatFlowArea
// Size: 0x98(Inherited: 0x68) 
struct UBTDecorator_InCombatFlowArea : public UBTDecorator
{
	struct FBlackboardKeySelector ActorToCheck;  // 0x68(0x28)
	char pad_144[4];  // 0x90(0x4)
	float CheckUpdateRate;  // 0x94(0x4)

}; 



// Class AIFramework.FWAIResponseChannel
// Size: 0x48(Inherited: 0x28) 
struct UFWAIResponseChannel : public UObject
{
	struct FName ChannelName;  // 0x28(0x8)
	char bNeedsPoll : 1;  // 0x30(0x1)
	char bChannelSuppressed : 1;  // 0x30(0x1)
	char bIsActive : 1;  // 0x30(0x1)
	char pad_48_1 : 5;  // 0x30(0x1)
	char pad_49[8];  // 0x31(0x8)
	struct TArray<struct UFWAIResponse*> Responses;  // 0x38(0x10)

	void UnSuppress(); // Function AIFramework.FWAIResponseChannel.UnSuppress
	void Suppress(); // Function AIFramework.FWAIResponseChannel.Suppress
	void ReceiveTick(float DeltaSeconds); // Function AIFramework.FWAIResponseChannel.ReceiveTick
	void OnDeactivate(); // Function AIFramework.FWAIResponseChannel.OnDeactivate
	void OnActivate(); // Function AIFramework.FWAIResponseChannel.OnActivate
	bool IsSuppressed(); // Function AIFramework.FWAIResponseChannel.IsSuppressed
	bool IsActive(); // Function AIFramework.FWAIResponseChannel.IsActive
}; 



// Class AIFramework.BTDecorator_IsHumanPlayer
// Size: 0x90(Inherited: 0x90) 
struct UBTDecorator_IsHumanPlayer : public UBTDecorator_BlackboardBase
{

}; 



// Class AIFramework.BTDecorator_IsReachable
// Size: 0xB8(Inherited: 0x68) 
struct UBTDecorator_IsReachable : public UBTDecorator
{
	struct FBlackboardKeySelector DestinationKey;  // 0x68(0x28)
	float ExtraDistance;  // 0x90(0x4)
	float DistanceMultiplier;  // 0x94(0x4)
	UNavigationQueryFilter* FilterClass;  // 0x98(0x8)
	float TestInterval;  // 0xA0(0x4)
	float TestIntervalVariance;  // 0xA4(0x4)
	char pad_168_1 : 7;  // 0xA8(0x1)
	bool bProject : 1;  // 0xA8(0x1)
	char pad_169[3];  // 0xA9(0x3)
	float ProjectDown;  // 0xAC(0x4)
	float ProjectUp;  // 0xB0(0x4)
	char pad_180_1 : 7;  // 0xB4(0x1)
	bool bCheckVerticalDistance : 1;  // 0xB4(0x1)
	char pad_181[3];  // 0xB5(0x3)

}; 



// Class AIFramework.BTDecorator_PerceptionExist
// Size: 0xA0(Inherited: 0x90) 
struct UBTDecorator_PerceptionExist : public UBTDecorator_BlackboardBase
{
	UAISense* SenseClass;  // 0x90(0x8)
	float SenseAge;  // 0x98(0x4)
	char pad_156_1 : 7;  // 0x9C(0x1)
	bool bAnyHostile : 1;  // 0x9C(0x1)
	char pad_157[3];  // 0x9D(0x3)

}; 



// Class AIFramework.FWBTDecorator_HysteresisDistanceRange
// Size: 0x180(Inherited: 0x68) 
struct UFWBTDecorator_HysteresisDistanceRange : public UBTDecorator
{
	struct FBlackboardKeySelector FromKey;  // 0x68(0x28)
	struct FBlackboardKeySelector ToKey;  // 0x90(0x28)
	struct FBlackboardKeySelector MinDistanceKey;  // 0xB8(0x28)
	float MinDistance;  // 0xE0(0x4)
	char pad_228[4];  // 0xE4(0x4)
	struct FBlackboardKeySelector MaxDistanceKey;  // 0xE8(0x28)
	float MaxDistance;  // 0x110(0x4)
	char pad_276[4];  // 0x114(0x4)
	struct FBlackboardKeySelector HysteresisToEnterKey;  // 0x118(0x28)
	float HysteresisToEnter;  // 0x140(0x4)
	char pad_324[4];  // 0x144(0x4)
	struct FBlackboardKeySelector HysteresisToExitKey;  // 0x148(0x28)
	float HysteresisToExit;  // 0x170(0x4)
	char pad_372_1 : 7;  // 0x174(0x1)
	bool bUse2DDistance : 1;  // 0x174(0x1)
	char pad_373[3];  // 0x175(0x3)
	float UpdateRate;  // 0x178(0x4)
	char pad_380[4];  // 0x17C(0x4)

}; 



// Class AIFramework.BTDecorator_SOEnterAnimPlayCondition
// Size: 0x68(Inherited: 0x68) 
struct UBTDecorator_SOEnterAnimPlayCondition : public UBTDecorator
{

}; 



// Class AIFramework.BTDecorator_SOUsageCondition
// Size: 0x70(Inherited: 0x68) 
struct UBTDecorator_SOUsageCondition : public UBTDecorator
{
	uint8_t  AllowedState;  // 0x68(0x1)
	char pad_105[7];  // 0x69(0x7)

}; 



// Class AIFramework.BTService_SelectEnemy
// Size: 0xC0(Inherited: 0x70) 
struct UBTService_SelectEnemy : public UBTService
{
	struct FEQSParametrizedQueryExecutionRequest EQSRequest;  // 0x70(0x48)
	char bUseSquadBasedTargetSelection : 1;  // 0xB8(0x1)
	char pad_184_1 : 7;  // 0xB8(0x1)
	char pad_185[8];  // 0xB9(0x8)

}; 



// Class AIFramework.BTService_ValidateCover
// Size: 0xD0(Inherited: 0x70) 
struct UBTService_ValidateCover : public UBTService
{
	struct FEQSParametrizedQueryExecutionRequest EQSRequest;  // 0x70(0x48)
	uint8_t  CoverSelector;  // 0xB8(0x1)
	char pad_185[23];  // 0xB9(0x17)

}; 



// Class AIFramework.WaypointGraphRenderingComponent
// Size: 0x560(Inherited: 0x510) 
struct UWaypointGraphRenderingComponent : public UPrimitiveComponent
{
	char pad_1296[80];  // 0x510(0x50)

}; 



// Class AIFramework.BTService_ValidateLocation
// Size: 0xF0(Inherited: 0x70) 
struct UBTService_ValidateLocation : public UBTService
{
	struct FBlackboardKeySelector ResultKey;  // 0x70(0x28)
	struct FEQSParametrizedQueryExecutionRequest EQSRequest;  // 0x98(0x48)
	char pad_224[16];  // 0xE0(0x10)

}; 



// Class AIFramework.BTTask_ChooseNextSmartObject
// Size: 0x160(Inherited: 0x70) 
struct UBTTask_ChooseNextSmartObject : public UBTTaskNode
{
	struct FBlackboardKeySelector SmartObjectSlotKey;  // 0x70(0x28)
	struct FBlackboardKeySelector SmartObjectLocationKey;  // 0x98(0x28)
	struct FBlackboardKeySelector SmartObjectDirectionKey;  // 0xC0(0x28)
	struct FBlackboardKeySelector SmartObjectEntryLocationKey;  // 0xE8(0x28)
	struct FBlackboardKeySelector SmartObjectLocationAfterEntryKey;  // 0x110(0x28)
	struct FBlackboardKeySelector SmartObjectRotationKey;  // 0x138(0x28)

}; 



// Class AIFramework.BTTask_ClearClaimedSmartObject
// Size: 0x70(Inherited: 0x70) 
struct UBTTask_ClearClaimedSmartObject : public UBTTaskNode
{

}; 



// Class AIFramework.FWEnvQueryContext_DestinationCover
// Size: 0x28(Inherited: 0x28) 
struct UFWEnvQueryContext_DestinationCover : public UEnvQueryContext
{

}; 



// Class AIFramework.BTTask_CompleteSmartObjectSyncedMontage
// Size: 0x98(Inherited: 0x70) 
struct UBTTask_CompleteSmartObjectSyncedMontage : public UBTTaskNode
{
	struct FBlackboardKeySelector SmartObjectSyncedStartKey;  // 0x70(0x28)

}; 



// Class AIFramework.BTTask_Fail
// Size: 0x70(Inherited: 0x70) 
struct UBTTask_Fail : public UBTTaskNode
{

}; 



// Class AIFramework.BTTask_FinishSmartObjectUsage
// Size: 0x98(Inherited: 0x70) 
struct UBTTask_FinishSmartObjectUsage : public UBTTaskNode
{
	struct FBlackboardKeySelector SmartObjectInitiatedKey;  // 0x70(0x28)

}; 



// Class AIFramework.BTTask_HiddenMoveDirectlyToward
// Size: 0xB8(Inherited: 0xB8) 
struct UBTTask_HiddenMoveDirectlyToward : public UBTTask_MoveDirectlyToward
{

}; 



// Class AIFramework.BTTask_FrameworkMoveDirectlyToward
// Size: 0xB8(Inherited: 0xB8) 
struct UBTTask_FrameworkMoveDirectlyToward : public UFWBTTask_MoveTo
{

}; 



// Class AIFramework.EQSResultHandler_SetCoverDestination
// Size: 0x28(Inherited: 0x28) 
struct UEQSResultHandler_SetCoverDestination : public UEQSResultHandler
{

}; 



// Class AIFramework.BTTask_FrameworkRotateToFaceBBEntry
// Size: 0xA8(Inherited: 0xA0) 
struct UBTTask_FrameworkRotateToFaceBBEntry : public UBTTask_RotateToFaceBBEntry
{
	char pad_160_1 : 7;  // 0xA0(0x1)
	bool bUseControllerDesiredRotation : 1;  // 0xA0(0x1)
	char pad_161[7];  // 0xA1(0x7)

}; 



// Class AIFramework.BTTask_FrameworkRunEQSQuery
// Size: 0x158(Inherited: 0x150) 
struct UBTTask_FrameworkRunEQSQuery : public UBTTask_RunEQSQuery
{
	UEQSResultHandler* ResultHandler;  // 0x150(0x8)

}; 



// Class AIFramework.BTTask_FrameworkWait
// Size: 0x88(Inherited: 0x78) 
struct UBTTask_FrameworkWait : public UBTTask_Wait
{
	char bAllowFire : 1;  // 0x78(0x1)
	char bAllowReload : 1;  // 0x78(0x1)
	char bAllowTurnInPlace : 1;  // 0x78(0x1)
	char bForceFireAtTarget : 1;  // 0x78(0x1)
	char bWeaponRangeCheck : 1;  // 0x78(0x1)
	char pad_120_1 : 3;  // 0x78(0x1)
	char pad_121[4];  // 0x79(0x4)
	char pad_124_1 : 7;  // 0x7C(0x1)
	bool bModifyAllowFireSetting : 1;  // 0x7C(0x1)
	char pad_125_1 : 7;  // 0x7D(0x1)
	bool bModifyAllowReloadSetting : 1;  // 0x7D(0x1)
	char pad_126_1 : 7;  // 0x7E(0x1)
	bool bModifyAllowTurnInPlaceSetting : 1;  // 0x7E(0x1)
	char pad_127_1 : 7;  // 0x7F(0x1)
	bool bModifyForceFireAtTargetSetting : 1;  // 0x7F(0x1)
	char pad_128_1 : 7;  // 0x80(0x1)
	bool bModifyWeaponRangeCheck : 1;  // 0x80(0x1)
	char pad_129[7];  // 0x81(0x7)

}; 



// Class AIFramework.QueryContext_NotCloseAllyDestinations
// Size: 0x30(Inherited: 0x30) 
struct UQueryContext_NotCloseAllyDestinations : public UQueryContext_AllyDestinations
{

}; 



// Class AIFramework.FWNavigationTestingActor
// Size: 0x428(Inherited: 0x418) 
struct AFWNavigationTestingActor : public ANavigationTestingActor
{
	char bDrawCoversAlongPath : 1;  // 0x418(0x1)
	char bDrawTilesAlongPath : 1;  // 0x418(0x1)
	char pad_1048_1 : 6;  // 0x418(0x1)
	char pad_1049[4];  // 0x419(0x4)
	char ENavPathType NavigationPathType;  // 0x41C(0x1)
	char pad_1053[3];  // 0x41D(0x3)
	char bDrawControlPoints : 1;  // 0x420(0x1)
	char pad_1056_1 : 7;  // 0x420(0x1)
	char pad_1057[4];  // 0x421(0x4)
	float ActorsDistance;  // 0x424(0x4)

}; 



// Class AIFramework.BTTask_InvalidateCover
// Size: 0x78(Inherited: 0x70) 
struct UBTTask_InvalidateCover : public UBTTaskNode
{
	uint8_t  Cover;  // 0x70(0x1)
	char pad_113[7];  // 0x71(0x7)

}; 



// Class AIFramework.FWAnimNotifyState_ExtendedSpaceWrapping
// Size: 0x98(Inherited: 0x40) 
struct UFWAnimNotifyState_ExtendedSpaceWrapping : public UFWAnimNotifyState
{
	struct FVector2D AnimRootMotionTranslationScale;  // 0x40(0x8)
	uint8_t  TurnDirection;  // 0x48(0x4)
	uint8_t  TurnMode;  // 0x4C(0x4)
	struct FVector2D AnimRootMotionRotationScale;  // 0x50(0x8)
	float RotationSpeed;  // 0x58(0x4)
	float OptimalDistance;  // 0x5C(0x4)
	float TrackingDuration;  // 0x60(0x4)
	uint8_t  WrappingType;  // 0x64(0x1)
	char pad_101[3];  // 0x65(0x3)
	char bOffsetByCharacterRadius : 1;  // 0x68(0x1)
	char bOffsetByTargetRadius : 1;  // 0x68(0x1)
	char bProjectDistanceOnRootMotion : 1;  // 0x68(0x1)
	char bUsePrediction : 1;  // 0x68(0x1)
	char bLimitPredictionToAnimationEnd : 1;  // 0x68(0x1)
	char pad_104_1 : 3;  // 0x68(0x1)
	char pad_105[4];  // 0x69(0x4)
	float PredictionTime;  // 0x6C(0x4)
	float PredictionMaxDistance;  // 0x70(0x4)
	char pad_116_1 : 7;  // 0x74(0x1)
	bool bForceRotateForwardDirection : 1;  // 0x74(0x1)
	char pad_117[3];  // 0x75(0x3)
	float DeltaAngle;  // 0x78(0x4)
	char pad_124_1 : 7;  // 0x7C(0x1)
	bool bUseRVO : 1;  // 0x7C(0x1)
	char pad_125_1 : 7;  // 0x7D(0x1)
	bool bQueryRotationFromDestinationProvider : 1;  // 0x7D(0x1)
	char pad_126[2];  // 0x7E(0x2)
	UFWSpaceWrappingDestinationProvider* DestinationProvider;  // 0x80(0x8)
	uint8_t  PhysicsTeleportType;  // 0x88(0x1)
	char pad_137[15];  // 0x89(0xF)

}; 



// Class AIFramework.BTTask_PlayMontage
// Size: 0xB0(Inherited: 0x70) 
struct UBTTask_PlayMontage : public UBTTaskNode
{
	char pad_112_1 : 7;  // 0x70(0x1)
	bool bUseMontageProvider : 1;  // 0x70(0x1)
	char pad_113[7];  // 0x71(0x7)
	struct FMontageAssetSelector Montage;  // 0x78(0x20)
	struct UFWMontageProvider* MontageProvider;  // 0x98(0x8)
	struct UAnimMontage* MontageToPlay;  // 0xA0(0x8)
	char bNonBlocking : 1;  // 0xA8(0x1)
	char bCanAbortAnimation : 1;  // 0xA8(0x1)
	char bForceCollision : 1;  // 0xA8(0x1)
	char bEarlyFinishOnBlendOut : 1;  // 0xA8(0x1)
	char bEarlyFinishBeforeBlendOut : 1;  // 0xA8(0x1)
	char bTestRootMotionOnNavmesh : 1;  // 0xA8(0x1)
	char pad_168_1 : 2;  // 0xA8(0x1)
	char pad_169[8];  // 0xA9(0x8)

}; 



// Class AIFramework.BTTask_Success
// Size: 0x70(Inherited: 0x70) 
struct UBTTask_Success : public UBTTaskNode
{

}; 



// Class AIFramework.BTTask_UseSmartObject
// Size: 0xD8(Inherited: 0x70) 
struct UBTTask_UseSmartObject : public UBTTaskNode
{
	char pad_112[8];  // 0x70(0x8)
	struct AWeapon* CurrentWeapon;  // 0x78(0x8)
	struct UBehaviorTreeComponent* MyOwnerComp;  // 0x80(0x8)
	struct FBlackboardKeySelector SmartObjectSlotKey;  // 0x88(0x28)
	struct FBlackboardKeySelector SpawnedWithSOKey;  // 0xB0(0x28)

	void OnSmartObjectFinished(struct USmartObjectSlotComponent* Slot); // Function AIFramework.BTTask_UseSmartObject.OnSmartObjectFinished
}; 



// Class AIFramework.CharacterSpawnerRenderingComponent
// Size: 0x510(Inherited: 0x510) 
struct UCharacterSpawnerRenderingComponent : public UPrimitiveComponent
{

}; 



// Class AIFramework.FWEnvQueryTest_LineOfSight
// Size: 0x2A0(Inherited: 0x268) 
struct UFWEnvQueryTest_LineOfSight : public UEnvQueryTest
{
	struct FAIDataProviderBoolValue FromTheHip;  // 0x268(0x38)

}; 



// Class AIFramework.CombatArena
// Size: 0x470(Inherited: 0x3C8) 
struct ACombatArena : public AActionArea
{
	struct FMulticastInlineDelegate OnPlayerEntered;  // 0x3C8(0x10)
	struct FMulticastInlineDelegate OnPlayerLeft;  // 0x3D8(0x10)
	struct FMulticastInlineDelegate OnArenaSwitchedOn;  // 0x3E8(0x10)
	struct FMulticastInlineDelegate OnArenaSwitchedOff;  // 0x3F8(0x10)
	struct FMulticastInlineDelegate OnArenaChanged;  // 0x408(0x10)
	struct ACombatArena* NextCombatArea;  // 0x418(0x8)
	struct ACombatArena* PrevCombatArea;  // 0x420(0x8)
	uint8_t  Scenario;  // 0x428(0x1)
	char pad_1065_1 : 7;  // 0x429(0x1)
	bool bFallbackWhenPlayerEnters : 1;  // 0x429(0x1)
	char pad_1066_1 : 7;  // 0x42A(0x1)
	bool bConsiderAllPlayers : 1;  // 0x42A(0x1)
	char pad_1067[5];  // 0x42B(0x5)
	struct AVolume* FallbackTrigger;  // 0x430(0x8)
	char pad_1080_1 : 7;  // 0x438(0x1)
	bool bFallbackOnLowNumbers : 1;  // 0x438(0x1)
	char pad_1081[3];  // 0x439(0x3)
	int32_t AIsDeadToFallback;  // 0x43C(0x4)
	int32_t AIsLeftToFallback;  // 0x440(0x4)
	char pad_1092[4];  // 0x444(0x4)
	struct TArray<struct APlayerController*> PlayersPopulation;  // 0x448(0x10)
	struct TArray<struct AFWAIController*> AIPopulation;  // 0x458(0x10)
	char pad_1128[8];  // 0x468(0x8)

	void UseInternalSpawnPoints(bool Use); // Function AIFramework.CombatArena.UseInternalSpawnPoints
	void TriggerFallback(bool bRecursiveParentFallback); // Function AIFramework.CombatArena.TriggerFallback
	void TriggerAssault(bool bRecursiveParentFallback); // Function AIFramework.CombatArena.TriggerAssault
	void OnServerRespawnPlayerHandler(uint8_t  RespawnReason); // Function AIFramework.CombatArena.OnServerRespawnPlayerHandler
	void OnReffedTriggerTouch(struct AActor* OverlappedActor, struct AActor* OtherActor); // Function AIFramework.CombatArena.OnReffedTriggerTouch
}; 



// Class AIFramework.AIDataProvider_GoalPoint
// Size: 0x50(Inherited: 0x40) 
struct UAIDataProvider_GoalPoint : public UAIDataProvider_QueryParams
{
	float Radius;  // 0x40(0x4)
	float AreaWidth;  // 0x44(0x4)
	float AreaLength;  // 0x48(0x4)
	char pad_76[4];  // 0x4C(0x4)

}; 



// Class AIFramework.FWEnvQueryTest_UnusedForTime
// Size: 0x278(Inherited: 0x268) 
struct UFWEnvQueryTest_UnusedForTime : public UEnvQueryTest
{
	UEnvQueryContext* Context;  // 0x268(0x8)
	char pad_624_1 : 7;  // 0x270(0x1)
	bool bCurrentCoverUsedTimeIsZero : 1;  // 0x270(0x1)
	char pad_625[7];  // 0x271(0x7)

}; 



// Class AIFramework.FWAnimNotify_StopFiring
// Size: 0x40(Inherited: 0x40) 
struct UFWAnimNotify_StopFiring : public UFWAnimNotify
{

}; 



// Class AIFramework.AIDataProvider_Character
// Size: 0x38(Inherited: 0x28) 
struct UAIDataProvider_Character : public UAIDataProvider
{
	float WeaponRange;  // 0x28(0x4)
	float EffectiveWeaponRange;  // 0x2C(0x4)
	float SightRadius;  // 0x30(0x4)
	float DistanceToTarget;  // 0x34(0x4)

}; 



// Class AIFramework.EnvQueryGenerator_Disk
// Size: 0x2D8(Inherited: 0x260) 
struct UEnvQueryGenerator_Disk : public UEnvQueryGenerator_OnCircle
{
	struct FAIDataProviderIntValue NumberOfCircles;  // 0x260(0x38)
	struct FAIDataProviderFloatValue CirclesDistance;  // 0x298(0x38)
	uint8_t  CirclesSpacingMethod;  // 0x2D0(0x1)
	char pad_721[7];  // 0x2D1(0x7)

}; 



// Class AIFramework.EnvQueryGenerator_GoalLinkedActors
// Size: 0xA0(Inherited: 0x98) 
struct UEnvQueryGenerator_GoalLinkedActors : public UEnvQueryGenerator
{
	AGoalPoint* GoalClassFilter;  // 0x98(0x8)

}; 



// Class AIFramework.EnvQueryGenerator_RectangularGrid
// Size: 0x180(Inherited: 0xD0) 
struct UEnvQueryGenerator_RectangularGrid : public UEnvQueryGenerator_ProjectedPoints
{
	struct FAIDataProviderFloatValue GridWidth;  // 0xD0(0x38)
	struct FAIDataProviderFloatValue GridLength;  // 0x108(0x38)
	struct FAIDataProviderFloatValue SpaceBetween;  // 0x140(0x38)
	UEnvQueryContext* GenerateAround;  // 0x178(0x8)

}; 



// Class AIFramework.EnvQueryItemType_CoverSlot
// Size: 0x30(Inherited: 0x30) 
struct UEnvQueryItemType_CoverSlot : public UEnvQueryItemType_VectorBase
{

}; 



// Class AIFramework.FWAIAimAttractorsInterface
// Size: 0x28(Inherited: 0x28) 
struct UFWAIAimAttractorsInterface : public UInterface
{

	void GetAttractors(struct TArray<struct FVector>& OutAttractors, struct AFWAIController* Instigator); // Function AIFramework.FWAIAimAttractorsInterface.GetAttractors
}; 



// Class AIFramework.AITask_PlayDamageReaction
// Size: 0xD0(Inherited: 0xD0) 
struct UAITask_PlayDamageReaction : public UAITask_PlayAnimation
{

}; 



// Class AIFramework.MadAnimNotify_AllowNextReaction
// Size: 0x38(Inherited: 0x38) 
struct UMadAnimNotify_AllowNextReaction : public UAnimNotify
{

}; 



// Class AIFramework.FWBTDecorator_ForceFail
// Size: 0x68(Inherited: 0x68) 
struct UFWBTDecorator_ForceFail : public UBTDecorator
{

}; 



// Class AIFramework.FWBTDecorator_IsDoingCoverAction
// Size: 0x98(Inherited: 0x90) 
struct UFWBTDecorator_IsDoingCoverAction : public UBTDecorator_BlackboardBase
{
	char pad_144_1 : 7;  // 0x90(0x1)
	bool bNotInCoverAsTrue : 1;  // 0x90(0x1)
	char pad_145[7];  // 0x91(0x7)

}; 



// Class AIFramework.FWAIPerceptionComponent
// Size: 0x280(Inherited: 0x278) 
struct UFWAIPerceptionComponent : public UAIPerceptionComponent
{
	char pad_632_1 : 7;  // 0x278(0x1)
	bool bSightUseSimpleTargetLocation : 1;  // 0x278(0x1)
	char pad_633[7];  // 0x279(0x7)

	float GetRecentDamageTakenFromActor(struct AActor* Actor); // Function AIFramework.FWAIPerceptionComponent.GetRecentDamageTakenFromActor
	float GetCallForHelpRating(struct AActor* Actor); // Function AIFramework.FWAIPerceptionComponent.GetCallForHelpRating
	void EnablePerceptionChannel(UAISense* Sense, bool bEnable); // Function AIFramework.FWAIPerceptionComponent.EnablePerceptionChannel
}; 



// Class AIFramework.FWAIReactionTask
// Size: 0xA0(Inherited: 0x98) 
struct UFWAIReactionTask : public UFWAITask
{
	char pad_152[8];  // 0x98(0x8)

}; 



// Class AIFramework.EQSResultHandler_SetCombatSpot
// Size: 0x28(Inherited: 0x28) 
struct UEQSResultHandler_SetCombatSpot : public UEQSResultHandler
{

}; 



// Class AIFramework.FWAISemaphoreGroupClass_Test
// Size: 0x30(Inherited: 0x30) 
struct UFWAISemaphoreGroupClass_Test : public UFWAISemaphoreGroupClass
{

}; 



// Class AIFramework.FWAITask_Reaction_Stare
// Size: 0xD0(Inherited: 0xA0) 
struct UFWAITask_Reaction_Stare : public UFWAIReactionTask
{
	float DurationMin;  // 0xA0(0x4)
	float DurationMax;  // 0xA4(0x4)
	char pad_168[40];  // 0xA8(0x28)

}; 



// Class AIFramework.FWAITask_Reaction_RunTo
// Size: 0xA8(Inherited: 0xA0) 
struct UFWAITask_Reaction_RunTo : public UFWAIReactionTask
{
	float AcceptanceRadius;  // 0xA0(0x4)
	char pad_164[4];  // 0xA4(0x4)

}; 



// Class AIFramework.FWAITask_Reaction_RunAway
// Size: 0xC8(Inherited: 0xA0) 
struct UFWAITask_Reaction_RunAway : public UFWAIReactionTask
{
	float MaxDistance;  // 0xA0(0x4)
	char pad_164[36];  // 0xA4(0x24)

}; 



// Class AIFramework.FWAnimNotifyState_OSARequest
// Size: 0x40(Inherited: 0x40) 
struct UFWAnimNotifyState_OSARequest : public UFWAnimNotify
{

}; 



// Class AIFramework.FWAIReactionActor
// Size: 0x348(Inherited: 0x320) 
struct AFWAIReactionActor : public AActor
{
	char pad_800_1 : 7;  // 0x320(0x1)
	bool bEnabled : 1;  // 0x320(0x1)
	char pad_801[7];  // 0x321(0x7)
	struct TArray<struct UFWAIReactionEpicentre*> Epicentres;  // 0x328(0x10)
	char pad_824[16];  // 0x338(0x10)

	void AttachReactionToActor(struct AActor* TargetActor); // Function AIFramework.FWAIReactionActor.AttachReactionToActor
}; 



// Class AIFramework.FWAIReactionEpicentre
// Size: 0x88(Inherited: 0x28) 
struct UFWAIReactionEpicentre : public UObject
{
	float RangeMin;  // 0x28(0x4)
	float RangeMax;  // 0x2C(0x4)
	int32_t MinAI;  // 0x30(0x4)
	int32_t MaxAI;  // 0x34(0x4)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool bWaitForAllToFinish : 1;  // 0x38(0x1)
	char pad_57_1 : 7;  // 0x39(0x1)
	bool bRemoveWhenAllReactionsFinished : 1;  // 0x39(0x1)
	char pad_58[2];  // 0x3A(0x2)
	float COOLDOWN;  // 0x3C(0x4)
	int32_t MaxTimesUsed;  // 0x40(0x4)
	char pad_68[4];  // 0x44(0x4)
	struct TArray<UFWAIArchetype*> EnabledForArchetypes;  // 0x48(0x10)
	struct UFWAIReactionTask* ReactionToStart;  // 0x58(0x8)
	char pad_96[40];  // 0x60(0x28)

	void OnTaskEnded(struct UFWAITask* Task, uint8_t  Result); // Function AIFramework.FWAIReactionEpicentre.OnTaskEnded
}; 



// Class AIFramework.FWAIReactionsManager
// Size: 0x198(Inherited: 0x28) 
struct UFWAIReactionsManager : public UObject
{
	char pad_40[40];  // 0x28(0x28)
	float GlobalCooldownTime;  // 0x50(0x4)
	float GlobalCooldownMaxTime;  // 0x54(0x4)
	int32_t MaxNumberOfReactionsAtTime;  // 0x58(0x4)
	char pad_92[308];  // 0x5C(0x134)
	struct UWorld* World;  // 0x190(0x8)

}; 



// Class AIFramework.FWAIRes_StepAside
// Size: 0x88(Inherited: 0x70) 
struct UFWAIRes_StepAside : public UFWAIResponse
{
	char pad_112[24];  // 0x70(0x18)

	void OnMantle(struct FVector& EventOrigin, struct ABaseCharacter* InstigatorCharacter); // Function AIFramework.FWAIRes_StepAside.OnMantle
}; 



// Class AIFramework.FWAIResChannel_AbilityTag
// Size: 0x68(Inherited: 0x48) 
struct UFWAIResChannel_AbilityTag : public UFWAIResponseChannel
{
	char pad_72[32];  // 0x48(0x20)

	struct FWAIResChannel_AbilityTagStatus GetTagStatus(); // Function AIFramework.FWAIResChannel_AbilityTag.GetTagStatus
}; 



// Class AIFramework.FWAIPerceptionResponseChannel
// Size: 0x60(Inherited: 0x48) 
struct UFWAIPerceptionResponseChannel : public UFWAIResponseChannel
{
	struct AActor* LastInstigator;  // 0x48(0x8)
	char pad_80[16];  // 0x50(0x10)

}; 



// Class AIFramework.FWEnvQueryGenerator_CombatGrid
// Size: 0x118(Inherited: 0xD0) 
struct UFWEnvQueryGenerator_CombatGrid : public UEnvQueryGenerator_ProjectedPoints
{
	struct FAIDataProviderFloatValue Radius;  // 0xD0(0x38)
	UEnvQueryContext* GenerateAround;  // 0x108(0x8)
	char bUseRadiusWithGoal : 1;  // 0x110(0x1)
	char pad_272_1 : 7;  // 0x110(0x1)
	char pad_273[8];  // 0x111(0x8)

}; 



// Class AIFramework.FWAIResChannel_Perception
// Size: 0x60(Inherited: 0x60) 
struct UFWAIResChannel_Perception : public UFWAIPerceptionResponseChannel
{

}; 



// Class AIFramework.FWAIResChannel_StepAside
// Size: 0x48(Inherited: 0x48) 
struct UFWAIResChannel_StepAside : public UFWAIResponseChannel
{

}; 



// Class AIFramework.GoalRenderingComponent
// Size: 0x510(Inherited: 0x510) 
struct UGoalRenderingComponent : public UPrimitiveComponent
{

}; 



// Class AIFramework.FWAIResChannel_ThreatLevel
// Size: 0x48(Inherited: 0x48) 
struct UFWAIResChannel_ThreatLevel : public UFWAIResponseChannel
{

}; 



// Class AIFramework.FWAIResChannel_Timer
// Size: 0x48(Inherited: 0x48) 
struct UFWAIResChannel_Timer : public UFWAIResponseChannel
{

}; 



// Class AIFramework.FWSplinePathFollowingComponent
// Size: 0x438(Inherited: 0x418) 
struct UFWSplinePathFollowingComponent : public UFWPathFollowingComponent
{
	float SmoothingLookAheadDistanceCutting;  // 0x418(0x4)
	char pad_1052[28];  // 0x41C(0x1C)

	void SplineOnMantleTaskEnded(struct UFWAITask* Task, uint8_t  Result); // Function AIFramework.FWSplinePathFollowingComponent.SplineOnMantleTaskEnded
	void SplineOnJumpDownTaskEnded(struct UFWAITask* Task, uint8_t  Result); // Function AIFramework.FWSplinePathFollowingComponent.SplineOnJumpDownTaskEnded
}; 



// Class AIFramework.FWAnimNotifyState_VerticalSpaceWrapping
// Size: 0x58(Inherited: 0x40) 
struct UFWAnimNotifyState_VerticalSpaceWrapping : public UFWAnimNotifyState
{
	struct FVector2D AnimRootMotionTranslationScale;  // 0x40(0x8)
	float OptimalDistance;  // 0x48(0x4)
	uint8_t  DistanceMode;  // 0x4C(0x4)
	char pad_80[8];  // 0x50(0x8)

}; 



// Class AIFramework.FWAIResponseComponent
// Size: 0x218(Inherited: 0x1A8) 
struct UFWAIResponseComponent : public UActorComponent
{
	struct TMap<struct FName, struct UFWAIResponseChannel*> Channels;  // 0x1A8(0x50)
	struct TArray<struct UFWAIResponseChannel*> PollChannels;  // 0x1F8(0x10)
	struct AFWAIController* AIOwner;  // 0x208(0x8)
	char pad_528[8];  // 0x210(0x8)

	void UnSuppressResponsesByType(UFWAIResponse* Type); // Function AIFramework.FWAIResponseComponent.UnSuppressResponsesByType
	void UnSuppressResponseChannelByType(UFWAIResponseChannel* Type); // Function AIFramework.FWAIResponseComponent.UnSuppressResponseChannelByType
	void UnSuppressAllChannels(); // Function AIFramework.FWAIResponseComponent.UnSuppressAllChannels
	void UnSuppressAll(); // Function AIFramework.FWAIResponseComponent.UnSuppressAll
	void SuppressResponsesByType(UFWAIResponse* Type); // Function AIFramework.FWAIResponseComponent.SuppressResponsesByType
	void SuppressResponseChannelByType(UFWAIResponseChannel* Type); // Function AIFramework.FWAIResponseComponent.SuppressResponseChannelByType
	void SuppressAllChannels(); // Function AIFramework.FWAIResponseComponent.SuppressAllChannels
	void SuppressAll(); // Function AIFramework.FWAIResponseComponent.SuppressAll
	void OnOwnerEndPlay(struct AActor* Actor, char EEndPlayReason EndPlayReason); // Function AIFramework.FWAIResponseComponent.OnOwnerEndPlay
	void NudgeChannelByName(struct FName ChannelName); // Function AIFramework.FWAIResponseComponent.NudgeChannelByName
	void NudgeChannelByClass(UFWAIResponseChannel* ChannelClass); // Function AIFramework.FWAIResponseComponent.NudgeChannelByClass
	struct AFWAIController* GetAIOwner(); // Function AIFramework.FWAIResponseComponent.GetAIOwner
}; 



// Class AIFramework.FWAnimNotify_CameraShake
// Size: 0x68(Inherited: 0x40) 
struct UFWAnimNotify_CameraShake : public UFWAnimNotify
{
	UCameraShake* Shake;  // 0x40(0x8)
	struct FVector EpicenterOffset;  // 0x48(0xC)
	float InnerRadius;  // 0x54(0x4)
	float OuterRadius;  // 0x58(0x4)
	float Falloff;  // 0x5C(0x4)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool bOrientShakeTowardsEpicenter : 1;  // 0x60(0x1)
	char pad_97[7];  // 0x61(0x7)

}; 



// Class AIFramework.FWAISemaphoreGroupClass_FireTickets
// Size: 0x38(Inherited: 0x30) 
struct UFWAISemaphoreGroupClass_FireTickets : public UFWAISemaphoreGroupClass
{
	char ClampMinConcurrentLimit;  // 0x30(0x1)
	char ClampMaxConcurrentLimit;  // 0x31(0x1)
	int8_t LinearFunctionA;  // 0x32(0x1)
	int8_t LinearFunctionB;  // 0x33(0x1)
	char pad_52[4];  // 0x34(0x4)

}; 



// Class AIFramework.SpawnVolume
// Size: 0x380(Inherited: 0x358) 
struct ASpawnVolume : public ATriggerVolume
{
	struct FMulticastInlineDelegate OnStateChanged;  // 0x358(0x10)
	char bStartEnabled : 1;  // 0x368(0x1)
	char pad_872_1 : 7;  // 0x368(0x1)
	char pad_873[8];  // 0x369(0x8)
	struct TArray<struct ACharacterSpawner*> SpawnPoints;  // 0x370(0x10)

	void UseWithEncounterManager(bool bShouldBeUsed); // Function AIFramework.SpawnVolume.UseWithEncounterManager
	void SetSpawnVolumeEnabled(bool bEnabled); // Function AIFramework.SpawnVolume.SetSpawnVolumeEnabled
	void EnableAllSpawners(); // Function AIFramework.SpawnVolume.EnableAllSpawners
	void DisableAllSpawners(); // Function AIFramework.SpawnVolume.DisableAllSpawners
}; 



// Class AIFramework.FWAISemaphoreGroupClass_Melee
// Size: 0x30(Inherited: 0x30) 
struct UFWAISemaphoreGroupClass_Melee : public UFWAISemaphoreGroupClass
{

}; 



// Class AIFramework.EQSResultHandler
// Size: 0x28(Inherited: 0x28) 
struct UEQSResultHandler : public UObject
{

}; 



// Class AIFramework.FWAITask_CombatActionEx
// Size: 0xD8(Inherited: 0xD0) 
struct UFWAITask_CombatActionEx : public UAITask_PlayAnimation
{
	char pad_208[8];  // 0xD0(0x8)

}; 



// Class AIFramework.QueryTest_PerceptionExists
// Size: 0x270(Inherited: 0x268) 
struct UQueryTest_PerceptionExists : public UEnvQueryTest
{
	UAISense* SenseClass;  // 0x268(0x8)

}; 



// Class AIFramework.FWAITask_CustomCoverAction
// Size: 0xE8(Inherited: 0xE8) 
struct UFWAITask_CustomCoverAction : public UFWAITask_CoverAction
{

}; 



// Class AIFramework.FWAITask_ExecuteGameplayAbility
// Size: 0xB0(Inherited: 0x98) 
struct UFWAITask_ExecuteGameplayAbility : public UFWAITask
{
	char pad_152[24];  // 0x98(0x18)

}; 



// Class AIFramework.FWAITask_MantleOverCoverNoAnim
// Size: 0x128(Inherited: 0x110) 
struct UFWAITask_MantleOverCoverNoAnim : public UFWAITask_MantleOverCover
{
	float MoveTime;  // 0x110(0x4)
	char pad_276[20];  // 0x114(0x14)

}; 



// Class AIFramework.FWAITask_PlaySpawnAnimation
// Size: 0x110(Inherited: 0x98) 
struct UFWAITask_PlaySpawnAnimation : public UFWAITask
{
	char pad_152[8];  // 0x98(0x8)
	struct FSpawnAnimationNetworkData NetworkData;  // 0xA0(0x40)
	char pad_224[48];  // 0xE0(0x30)

	void OnRep_NetworkData(); // Function AIFramework.FWAITask_PlaySpawnAnimation.OnRep_NetworkData
	void OnOwnerKilled(struct ABaseCharacter* character, struct FTakeHitInfo TakeHitInfo); // Function AIFramework.FWAITask_PlaySpawnAnimation.OnOwnerKilled
}; 



// Class AIFramework.FWAITask_SetFocus
// Size: 0xB0(Inherited: 0x98) 
struct UFWAITask_SetFocus : public UFWAITask
{
	char pad_152[24];  // 0x98(0x18)

	struct UFWAITask_SetFocus* SetAIFocusAsVector(struct AAIController* Controller, struct FVector& FocusLocation, float PrecisionAngle); // Function AIFramework.FWAITask_SetFocus.SetAIFocusAsVector
}; 



// Class AIFramework.MadDataAsset_ThrowProjectileVariants
// Size: 0x40(Inherited: 0x30) 
struct UMadDataAsset_ThrowProjectileVariants : public UDataAsset
{
	struct TArray<struct FMadAI_SingleThrowEntry> Variants;  // 0x30(0x10)

}; 



// Class AIFramework.FWAnimationProxyDataEnemy
// Size: 0x78(Inherited: 0x28) 
struct UFWAnimationProxyDataEnemy : public UBaseAnimProxyData
{
	struct TMap<struct FSoftObjectPath, struct UAnimMontage*> AnimMontageCache;  // 0x28(0x50)

	void OnMontagesPreloaded(struct TArray<struct FSoftObjectPath> LoadedAssets); // Function AIFramework.FWAnimationProxyDataEnemy.OnMontagesPreloaded
}; 



// Class AIFramework.FWAnimNotify_StartFiring
// Size: 0x48(Inherited: 0x40) 
struct UFWAnimNotify_StartFiring : public UFWAnimNotify
{
	char pad_64_1 : 7;  // 0x40(0x1)
	bool bForceFire : 1;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)

}; 



// Class AIFramework.FWAnimNotify_RadialDamage
// Size: 0x68(Inherited: 0x40) 
struct UFWAnimNotify_RadialDamage : public UFWAnimNotify
{
	UDamageType* DamageTypeClass;  // 0x40(0x8)
	float BaseDamage;  // 0x48(0x4)
	float DamageInnerRadius;  // 0x4C(0x4)
	float DamageOuterRadius;  // 0x50(0x4)
	float DamageFalloff;  // 0x54(0x4)
	struct FVector EpicenterOffset;  // 0x58(0xC)
	char pad_100_1 : 7;  // 0x64(0x1)
	bool bDoFullDamage : 1;  // 0x64(0x1)
	char ECollisionChannel DamagePreventionChannel;  // 0x65(0x1)
	char pad_102[2];  // 0x66(0x2)

}; 



// Class AIFramework.FWAnimNotify_SingleMeleeHit
// Size: 0x60(Inherited: 0x40) 
struct UFWAnimNotify_SingleMeleeHit : public UFWAnimNotify
{
	float HitDetectionFOV;  // 0x40(0x4)
	float HitDetectionDistance;  // 0x44(0x4)
	struct FName DirectionBone;  // 0x48(0x8)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool bNegativeBone : 1;  // 0x50(0x1)
	char pad_81[7];  // 0x51(0x7)
	UDamageType* DamageTypeClass;  // 0x58(0x8)

}; 



// Class AIFramework.FWEnvQueryContext_BlackboardActor
// Size: 0x30(Inherited: 0x28) 
struct UFWEnvQueryContext_BlackboardActor : public UEnvQueryContext
{
	struct FName BlackboardActorKey;  // 0x28(0x8)

}; 



// Class AIFramework.FWAnimNotify_ApplyExplosionTemplate
// Size: 0x58(Inherited: 0x40) 
struct UFWAnimNotify_ApplyExplosionTemplate : public UFWAnimNotify
{
	UExplosionTemplate* ExplosionTemplate;  // 0x40(0x8)
	struct FName BoneName;  // 0x48(0x8)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool bUseMovePrediction : 1;  // 0x50(0x1)
	char pad_81_1 : 7;  // 0x51(0x1)
	bool bSpawnAtTargetLocation : 1;  // 0x51(0x1)
	char pad_82_1 : 7;  // 0x52(0x1)
	bool bSpawnAtAllTargetsLocations : 1;  // 0x52(0x1)
	char pad_83_1 : 7;  // 0x53(0x1)
	bool bIgnorePlayers : 1;  // 0x53(0x1)
	char pad_84[4];  // 0x54(0x4)

}; 



// Class AIFramework.FWEnvQueryTest_GroupThreatLevel
// Size: 0x270(Inherited: 0x268) 
struct UFWEnvQueryTest_GroupThreatLevel : public UEnvQueryTest
{
	UEnvQueryContext* Context;  // 0x268(0x8)

}; 



// Class AIFramework.FWEnvQueryContext_WoundedSquadMembers
// Size: 0x28(Inherited: 0x28) 
struct UFWEnvQueryContext_WoundedSquadMembers : public UEnvQueryContext
{

}; 



// Class AIFramework.FWAnimNotifyState_SetNewMovementMode
// Size: 0x48(Inherited: 0x40) 
struct UFWAnimNotifyState_SetNewMovementMode : public UFWAnimNotifyState
{
	char EMovementMode NewMovementMode;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)

}; 



// Class AIFramework.FWAnimNotify_ApplyDamage
// Size: 0x48(Inherited: 0x40) 
struct UFWAnimNotify_ApplyDamage : public UFWAnimNotify
{
	UDamageType* DamageTypeClass;  // 0x40(0x8)

}; 



// Class AIFramework.FWAnimNotifyState_SpaceWrapping
// Size: 0x190(Inherited: 0x40) 
struct UFWAnimNotifyState_SpaceWrapping : public UFWAnimNotifyState
{
	struct FVector2D AnimRootMotionTranslationScale;  // 0x40(0x8)
	float RotationCorrectionRange;  // 0x48(0x4)
	float RotationSpeed;  // 0x4C(0x4)
	uint8_t  WrappingType;  // 0x50(0x1)
	char pad_81[3];  // 0x51(0x3)
	char bOffsetByCharacterRadius : 1;  // 0x54(0x1)
	char bOffsetByTargetRadius : 1;  // 0x54(0x1)
	char pad_84_1 : 6;  // 0x54(0x1)
	char pad_85[4];  // 0x55(0x4)
	UFWSpaceWrappingDestinationProvider* DestinationProvider;  // 0x58(0x8)
	char pad_96[304];  // 0x60(0x130)

}; 



// Class AIFramework.FWEnvQueryTest_ScriptedSelectionPriority
// Size: 0x270(Inherited: 0x268) 
struct UFWEnvQueryTest_ScriptedSelectionPriority : public UEnvQueryTest
{
	UEnvQueryContext* Context;  // 0x268(0x8)

}; 



// Class AIFramework.FWEnvQueryTest_IsMoving
// Size: 0x2A0(Inherited: 0x268) 
struct UFWEnvQueryTest_IsMoving : public UEnvQueryTest
{
	struct FAIDataProviderFloatValue SpeedThreshold;  // 0x268(0x38)

}; 



// Class AIFramework.FWSpaceWrappingDestinationProvider_EnemyTarget
// Size: 0x28(Inherited: 0x28) 
struct UFWSpaceWrappingDestinationProvider_EnemyTarget : public UFWSpaceWrappingDestinationProvider
{

}; 



// Class AIFramework.FWSpaceWrappingDestinationProvider_FocalPoint
// Size: 0x28(Inherited: 0x28) 
struct UFWSpaceWrappingDestinationProvider_FocalPoint : public UFWSpaceWrappingDestinationProvider
{

}; 



// Class AIFramework.FWSpaceWrappingDestinationProvider_MoveTarget
// Size: 0x30(Inherited: 0x28) 
struct UFWSpaceWrappingDestinationProvider_MoveTarget : public UFWSpaceWrappingDestinationProvider
{
	float RotationCorrectionRange;  // 0x28(0x4)
	char pad_44[4];  // 0x2C(0x4)

}; 



// Class AIFramework.FWSpaceWrappingDestinationProvider_NextPathPoint
// Size: 0x28(Inherited: 0x28) 
struct UFWSpaceWrappingDestinationProvider_NextPathPoint : public UFWSpaceWrappingDestinationProvider
{

}; 



// Class AIFramework.FWSpaceWrappingDestinationProvider_CustomLocation
// Size: 0x28(Inherited: 0x28) 
struct UFWSpaceWrappingDestinationProvider_CustomLocation : public UFWSpaceWrappingDestinationProvider
{

}; 



// Class AIFramework.FWDebugCameraControllerVolume
// Size: 0x378(Inherited: 0x358) 
struct AFWDebugCameraControllerVolume : public AVolume
{
	struct AActor* ObservationPoint;  // 0x358(0x8)
	char pad_864[24];  // 0x360(0x18)

}; 



// Class AIFramework.PcfSpaceWrappingDestinationProvider_MeleeSlotOrTarget
// Size: 0x28(Inherited: 0x28) 
struct UPcfSpaceWrappingDestinationProvider_MeleeSlotOrTarget : public UFWSpaceWrappingDestinationProvider
{

}; 



// Class AIFramework.FWBlueprintLibrary
// Size: 0x28(Inherited: 0x28) 
struct UFWBlueprintLibrary : public UBlueprintFunctionLibrary
{

	void RestoreDefaultCollisionOnCharacter(struct ABaseCharacter* Char, int32_t ID); // Function AIFramework.FWBlueprintLibrary.RestoreDefaultCollisionOnCharacter
	struct FVector PredictActorLocationForVelocity(struct APawn* Pawn, float PredictionTime, float PredictionMaxDistance, struct FVector& InVelocity, struct FVector& ExtraExtent); // Function AIFramework.FWBlueprintLibrary.PredictActorLocationForVelocity
	struct FVector PredictActorLocation(struct APawn* Pawn, float PredictionTime, float PredictionMaxDistance, struct FVector& ExtraExtent); // Function AIFramework.FWBlueprintLibrary.PredictActorLocation
	struct FCoverSlotInfo MakeCoverSlotInfo(struct ACoverBase* InHotSpot, int32_t InSlotIndex); // Function AIFramework.FWBlueprintLibrary.MakeCoverSlotInfo
	void LogSegment(struct UObject* WorldContextObject, struct FVector SegmentStart, struct FVector SegmentEnd, struct FString Text, struct FLinearColor Color, struct FName CategoryName); // Function AIFramework.FWBlueprintLibrary.LogSegment
	void K2_SelectRandomValidAnimation(struct UObject* WorldContextObject, struct ABaseCharacter* character, struct TArray<struct FMontageAssetSelector>& Animations, struct FMontageAssetSelector& Montage, bool TestNavmesh, bool TestColision, char ECollisionChannel Channel); // Function AIFramework.FWBlueprintLibrary.K2_SelectRandomValidAnimation
	void K2_GetValidAnimations(struct UObject* WorldContextObject, struct ABaseCharacter* character, struct TArray<struct FMontageAssetSelector>& Animations, struct TArray<struct FMontageAssetSelector>& ValidAnimations, bool TestNavmesh, bool TestColision, char ECollisionChannel Channel); // Function AIFramework.FWBlueprintLibrary.K2_GetValidAnimations
	void K2_GetRootMotionWorldSpaceTranslation(struct UObject* WorldContextObject, struct Acharacter* character, struct FMontageAssetSelector MontageAsset, struct FVector& OutAnimTranslation); // Function AIFramework.FWBlueprintLibrary.K2_GetRootMotionWorldSpaceTranslation
	struct FRotator K2_GetCharacterRotationAfterMontage(struct UObject* WorldContextObject, struct Acharacter* character, struct FMontageAssetSelector MontageAsset); // Function AIFramework.FWBlueprintLibrary.K2_GetCharacterRotationAfterMontage
	void K2_GetCharacterLocationAndRotationAfterMontage(struct UObject* WorldContextObject, struct Acharacter* character, struct FMontageAssetSelector MontageAsset, struct FVector& OutLocation, struct FRotator& OutRotation); // Function AIFramework.FWBlueprintLibrary.K2_GetCharacterLocationAndRotationAfterMontage
	struct FVector K2_GetCharacterLocationAfterMontage(struct UObject* WorldContextObject, struct Acharacter* character, struct FMontageAssetSelector MontageAsset); // Function AIFramework.FWBlueprintLibrary.K2_GetCharacterLocationAfterMontage
	void K2_GetBestHitInfoFromDamage(struct FDamageEvent& Event, struct AActor* HitActor, struct AActor* HitInstigator, struct FHitResult& OutHitInfo, struct FVector& OutImpulseDir); // Function AIFramework.FWBlueprintLibrary.K2_GetBestHitInfoFromDamage
	bool HasDirectNavPath(struct APawn* Pawn, struct FVector& Destination, struct FVector& DirectPathEnd, struct FVector& ExtraExtent); // Function AIFramework.FWBlueprintLibrary.HasDirectNavPath
	void GetAllCharactersWithArchetype(struct UObject* WorldContextObject, struct FFWAIArchetypeVariation ArchetypeVariation, struct TArray<struct ABaseCharacter*>& OutCharacters); // Function AIFramework.FWBlueprintLibrary.GetAllCharactersWithArchetype
	void GenerateRandomNonOverlappingCirclesInCircle(float InnerCircleRadius, float SpaceBetweenCircles, float OuterCircleRadius, struct TArray<struct FVector2D>& OutPoints); // Function AIFramework.FWBlueprintLibrary.GenerateRandomNonOverlappingCirclesInCircle
	int32_t ForceCollisionOnCharacter(struct ABaseCharacter* Char, struct FName& Reason); // Function AIFramework.FWBlueprintLibrary.ForceCollisionOnCharacter
	bool CheckNavLOS(struct APawn* Pawn, struct FVector& Start, struct FVector& Destination, struct FVector& HitLocation, struct FVector& ExtraExtent); // Function AIFramework.FWBlueprintLibrary.CheckNavLOS
	bool CheckCharactersCollisionOnSegment(struct ABaseCharacter* character, struct FVector& StartLocation, struct FVector& EndLocation); // Function AIFramework.FWBlueprintLibrary.CheckCharactersCollisionOnSegment
}; 



// Class AIFramework.FWEnvQueryContext_PointsOfInterest
// Size: 0x28(Inherited: 0x28) 
struct UFWEnvQueryContext_PointsOfInterest : public UEnvQueryContext
{

}; 



// Class AIFramework.FWBTComposite_LoopedSelector
// Size: 0x90(Inherited: 0x90) 
struct UFWBTComposite_LoopedSelector : public UBTCompositeNode
{

}; 



// Class AIFramework.QueryContext_AllyDestinations
// Size: 0x30(Inherited: 0x28) 
struct UQueryContext_AllyDestinations : public UEnvQueryContext
{
	char bUseOnlySquadMembers : 1;  // 0x28(0x1)
	char bFilterAllies : 1;  // 0x28(0x1)
	char pad_40_1 : 6;  // 0x28(0x1)
	char pad_41[8];  // 0x29(0x8)

}; 



// Class AIFramework.FWBTComposite_Random
// Size: 0xA8(Inherited: 0x90) 
struct UFWBTComposite_Random : public UBTCompositeNode
{
	char pad_144_1 : 7;  // 0x90(0x1)
	bool bRetryOnFail : 1;  // 0x90(0x1)
	char pad_145_1 : 7;  // 0x91(0x1)
	bool bRetryOnSuccess : 1;  // 0x91(0x1)
	char pad_146[6];  // 0x92(0x6)
	struct TArray<float> ChildrenWeights;  // 0x98(0x10)

}; 



// Class AIFramework.FWBTContext_AbilitiesContext
// Size: 0xD0(Inherited: 0x70) 
struct UFWBTContext_AbilitiesContext : public UFWBTService_ContextOverride
{
	struct FGameplayTagContainer CancelAbilitiesWithTag;  // 0x70(0x20)
	struct FGameplayTagContainer BlockAbilitiesWithTag;  // 0x90(0x20)
	struct FGameplayTagContainer LooseGameplayTagsToSet;  // 0xB0(0x20)

}; 



// Class AIFramework.FWBTContext_ClaimSemaphore
// Size: 0xB0(Inherited: 0x70) 
struct UFWBTContext_ClaimSemaphore : public UFWBTService_ContextOverride
{
	float UnlockDelay;  // 0x70(0x4)
	char pad_116[4];  // 0x74(0x4)
	UFWAISemaphoreGroupClass* GroupClass;  // 0x78(0x8)
	struct FBlackboardKeySelector PerTargetActor;  // 0x80(0x28)
	char bUsePerTargetActor : 1;  // 0xA8(0x1)
	char bUnlockSemaphoreAfterDelay : 1;  // 0xA8(0x1)
	char bUnlockSemaphoreIfStartedReaction : 1;  // 0xA8(0x1)
	char pad_168_1 : 5;  // 0xA8(0x1)
	char pad_169[8];  // 0xA9(0x8)

}; 



// Class AIFramework.FWBTContext_SuppressResponseByClass
// Size: 0x88(Inherited: 0x70) 
struct UFWBTContext_SuppressResponseByClass : public UFWBTService_ContextOverride
{
	char bAllResponses : 1;  // 0x70(0x1)
	char pad_112_1 : 7;  // 0x70(0x1)
	char pad_113[8];  // 0x71(0x8)
	struct TArray<UFWAIResponse*> ResponseClasses;  // 0x78(0x10)

}; 



// Class AIFramework.FWBTContext_SuppressResponseChannelByClass
// Size: 0x88(Inherited: 0x70) 
struct UFWBTContext_SuppressResponseChannelByClass : public UFWBTService_ContextOverride
{
	char bAllChannels : 1;  // 0x70(0x1)
	char pad_112_1 : 7;  // 0x70(0x1)
	char pad_113[8];  // 0x71(0x8)
	struct TArray<UFWAIResponseChannel*> ChannelClasses;  // 0x78(0x10)

}; 



// Class AIFramework.FWBTContext_TargetSelection
// Size: 0xC0(Inherited: 0x70) 
struct UFWBTContext_TargetSelection : public UFWBTService_ContextOverride
{
	struct FEQSParametrizedQueryExecutionRequest EQSRequest;  // 0x70(0x48)
	char bUseSquadBasedTargetSelection : 1;  // 0xB8(0x1)
	char pad_184_1 : 7;  // 0xB8(0x1)
	char pad_185[8];  // 0xB9(0x8)

}; 



// Class AIFramework.FWBTDecorator_Accumulator
// Size: 0x78(Inherited: 0x68) 
struct UFWBTDecorator_Accumulator : public UBTDecorator
{
	uint8_t  AccessBeforeThreshold;  // 0x68(0x1)
	uint8_t  AccessAfterThreshold;  // 0x69(0x1)
	char pad_106[2];  // 0x6A(0x2)
	int32_t minThreshold;  // 0x6C(0x4)
	int32_t maxThreshold;  // 0x70(0x4)
	char pad_116_1 : 7;  // 0x74(0x1)
	bool bResetOnAccess : 1;  // 0x74(0x1)
	char pad_117[3];  // 0x75(0x3)

}; 



// Class AIFramework.FWBTDecorator_ConeCheck
// Size: 0xF0(Inherited: 0xF0) 
struct UFWBTDecorator_ConeCheck : public UBTDecorator_ConeCheck
{

}; 



// Class AIFramework.FWEnvQueryContext_TargetSightLocation
// Size: 0x28(Inherited: 0x28) 
struct UFWEnvQueryContext_TargetSightLocation : public UEnvQueryContext
{

}; 



// Class AIFramework.FWBTDecorator_Cooldown
// Size: 0x78(Inherited: 0x70) 
struct UFWBTDecorator_Cooldown : public UBTDecorator_Cooldown
{
	char pad_112_1 : 7;  // 0x70(0x1)
	bool bCoolDownAfterSuccess : 1;  // 0x70(0x1)
	char pad_113_1 : 7;  // 0x71(0x1)
	bool bCoolDownAfterFail : 1;  // 0x71(0x1)
	char pad_114_1 : 7;  // 0x72(0x1)
	bool bCoolDownAfterAbort : 1;  // 0x72(0x1)
	char pad_115[5];  // 0x73(0x5)

}; 



// Class AIFramework.FWBTDecorator_QueryGameplayAbility
// Size: 0xD8(Inherited: 0x68) 
struct UFWBTDecorator_QueryGameplayAbility : public UBTDecorator
{
	struct FGameplayTagContainer GameplayAbilityTag;  // 0x68(0x20)
	struct FBlackboardKeySelector Target;  // 0x88(0x28)
	struct FGameplayTagContainer ActiveAbilityTagsToSkipTesting;  // 0xB0(0x20)
	char pad_208_1 : 7;  // 0xD0(0x1)
	bool bUseTarget : 1;  // 0xD0(0x1)
	char pad_209[3];  // 0xD1(0x3)
	float TimeInterval;  // 0xD4(0x4)

}; 



// Class AIFramework.FWEnvQuery_ValueStandingCover
// Size: 0x270(Inherited: 0x268) 
struct UFWEnvQuery_ValueStandingCover : public UEnvQueryTest
{
	UEnvQueryContext* ContextActor;  // 0x268(0x8)

}; 



// Class AIFramework.FWBTDecorator_GameplayAbility_CanActivate
// Size: 0xD8(Inherited: 0xD8) 
struct UFWBTDecorator_GameplayAbility_CanActivate : public UFWBTDecorator_QueryGameplayAbility
{

}; 



// Class AIFramework.FWBTDecorator_GameplayAbility_CanHitTarget
// Size: 0xE0(Inherited: 0xD8) 
struct UFWBTDecorator_GameplayAbility_CanHitTarget : public UFWBTDecorator_QueryGameplayAbility
{
	char UseIdealYawRotationToTarget : 1;  // 0xD8(0x1)
	char pad_216_1 : 7;  // 0xD8(0x1)
	char pad_217[8];  // 0xD9(0x8)

}; 



// Class AIFramework.FWBTDecorator_GameplayAbility_DoesTargetHaveProhibitedTags
// Size: 0xD8(Inherited: 0xD8) 
struct UFWBTDecorator_GameplayAbility_DoesTargetHaveProhibitedTags : public UFWBTDecorator_QueryGameplayAbility
{

}; 



// Class AIFramework.FWBTDecorator_GameplayAbility_HasGameplayAbility
// Size: 0x88(Inherited: 0x68) 
struct UFWBTDecorator_GameplayAbility_HasGameplayAbility : public UBTDecorator
{
	struct FGameplayTagContainer GameplayAbilityTag;  // 0x68(0x20)

}; 



// Class AIFramework.FWEnvQueryTest_InCombatArea
// Size: 0x278(Inherited: 0x268) 
struct UFWEnvQueryTest_InCombatArea : public UEnvQueryTest
{
	UEnvQueryContext* Context;  // 0x268(0x8)
	char pad_624_1 : 7;  // 0x270(0x1)
	bool bUseGoalPoint : 1;  // 0x270(0x1)
	char pad_625[7];  // 0x271(0x7)

}; 



// Class AIFramework.FWBTDecorator_GameplayAbility_HasGameplayTags
// Size: 0xC0(Inherited: 0x68) 
struct UFWBTDecorator_GameplayAbility_HasGameplayTags : public UBTDecorator
{
	struct FGameplayTagContainer GameplayAbilityTag;  // 0x68(0x20)
	uint8_t  GameplayTagMatchingType;  // 0x88(0x1)
	char pad_137[7];  // 0x89(0x7)
	struct FBlackboardKeySelector Target;  // 0x90(0x28)
	float TimeInterval;  // 0xB8(0x4)
	char pad_188[4];  // 0xBC(0x4)

}; 



// Class AIFramework.FWBTDecorator_GameplayAbility_IsOnCooldown
// Size: 0xD8(Inherited: 0xD8) 
struct UFWBTDecorator_GameplayAbility_IsOnCooldown : public UFWBTDecorator_QueryGameplayAbility
{

}; 



// Class AIFramework.FWBTDecorator_HasAdditionalWeapon
// Size: 0x68(Inherited: 0x68) 
struct UFWBTDecorator_HasAdditionalWeapon : public UBTDecorator
{

}; 



// Class AIFramework.FWBTDecorator_HasRequiredHealthLevel
// Size: 0x98(Inherited: 0x90) 
struct UFWBTDecorator_HasRequiredHealthLevel : public UBTDecorator_BlackboardBase
{
	float RequiredHealthLevel;  // 0x90(0x4)
	char pad_148[4];  // 0x94(0x4)

}; 



// Class AIFramework.FWBTTask_CombatActionExt
// Size: 0x90(Inherited: 0x78) 
struct UFWBTTask_CombatActionExt : public UBTTask_GameplayTaskBase
{
	char pad_120_1 : 7;  // 0x78(0x1)
	bool bRequireSight : 1;  // 0x78(0x1)
	char pad_121[3];  // 0x79(0x3)
	float WaitTime;  // 0x7C(0x4)
	float RandomDeviation;  // 0x80(0x4)
	char bAutoReloadOnLowAmmo : 1;  // 0x84(0x1)
	char bOnlyInMoveDirection : 1;  // 0x84(0x1)
	char bCanBeAborted : 1;  // 0x84(0x1)
	char pad_132_1 : 5;  // 0x84(0x1)
	char pad_133[4];  // 0x85(0x4)
	UFWAITask_CombatActionEx* AITask;  // 0x88(0x8)

}; 



// Class AIFramework.FWBTDecorator_InFrontCover
// Size: 0x90(Inherited: 0x90) 
struct UFWBTDecorator_InFrontCover : public UBTDecorator_BlackboardBase
{

}; 



// Class AIFramework.FWBTDecorator_IsInRequiredMovementMood
// Size: 0x70(Inherited: 0x68) 
struct UFWBTDecorator_IsInRequiredMovementMood : public UBTDecorator
{
	uint8_t  RequiredMovementMood;  // 0x68(0x1)
	char pad_105[7];  // 0x69(0x7)

}; 



// Class AIFramework.FWBTDecorator_IsSmartObjectClaimed
// Size: 0x68(Inherited: 0x68) 
struct UFWBTDecorator_IsSmartObjectClaimed : public UBTDecorator
{

}; 



// Class AIFramework.FWBTDecorator_IsSmartObjectSelectedByOptimization
// Size: 0x68(Inherited: 0x68) 
struct UFWBTDecorator_IsSmartObjectSelectedByOptimization : public UBTDecorator
{

}; 



// Class AIFramework.FWBTDecorator_IsSmartObjectUsingWeapon
// Size: 0x68(Inherited: 0x68) 
struct UFWBTDecorator_IsSmartObjectUsingWeapon : public UBTDecorator
{

}; 



// Class AIFramework.FWBTDecorator_RandomFail
// Size: 0x70(Inherited: 0x68) 
struct UFWBTDecorator_RandomFail : public UBTDecorator
{
	float Probability;  // 0x68(0x4)
	char pad_108[4];  // 0x6C(0x4)

}; 



// Class AIFramework.FWBTDecorator_Semaphore
// Size: 0xB8(Inherited: 0x68) 
struct UFWBTDecorator_Semaphore : public UBTDecorator
{
	char bUseLimitFromSystem : 1;  // 0x68(0x1)
	char pad_104_1 : 7;  // 0x68(0x1)
	char pad_105[4];  // 0x69(0x4)
	int32_t ConcurrentLimit;  // 0x6C(0x4)
	float UnlockDelay;  // 0x70(0x4)
	char bUnlockSemaphoreAfterDelay : 1;  // 0x74(0x1)
	char pad_116_1 : 7;  // 0x74(0x1)
	char pad_117[4];  // 0x75(0x4)
	UFWAISemaphoreGroupClass* GroupClass;  // 0x78(0x8)
	char bUsePerTargetActor : 1;  // 0x80(0x1)
	char pad_128_1 : 7;  // 0x80(0x1)
	char pad_129[8];  // 0x81(0x8)
	struct FBlackboardKeySelector PerTargetActor;  // 0x88(0x28)
	char bUseOldBehaviorToClaim : 1;  // 0xB0(0x1)
	char bUnlockSemaphoreIfStartedReaction : 1;  // 0xB0(0x1)
	char pad_176_1 : 6;  // 0xB0(0x1)
	char pad_177[8];  // 0xB1(0x8)

}; 



// Class AIFramework.FWBTService_AddAbilityEffect
// Size: 0x90(Inherited: 0x70) 
struct UFWBTService_AddAbilityEffect : public UBTService
{
	char pad_112_1 : 7;  // 0x70(0x1)
	bool bRemoveOnEnd : 1;  // 0x70(0x1)
	char pad_113[7];  // 0x71(0x7)
	UGameplayEffect* Effect;  // 0x78(0x8)
	struct FString CachedDescription;  // 0x80(0x10)

}; 



// Class AIFramework.FWBTDecorator_TargetDidntChange
// Size: 0x90(Inherited: 0x68) 
struct UFWBTDecorator_TargetDidntChange : public UBTDecorator
{
	struct FBlackboardKeySelector TargetKey;  // 0x68(0x28)

}; 



// Class AIFramework.FWBTDecorator_TraceActor
// Size: 0xA0(Inherited: 0x68) 
struct UFWBTDecorator_TraceActor : public UBTDecorator
{
	struct FBlackboardKeySelector TargetKey;  // 0x68(0x28)
	float RadiusScale;  // 0x90(0x4)
	float HalfHeightScale;  // 0x94(0x4)
	char ECollisionChannel TraceChannel;  // 0x98(0x1)
	char pad_153[7];  // 0x99(0x7)

}; 



// Class AIFramework.FWBTDecorator_ValidCoveringComponent
// Size: 0x68(Inherited: 0x68) 
struct UFWBTDecorator_ValidCoveringComponent : public UBTDecorator
{

}; 



// Class AIFramework.FWBTDecorator_ValidWeaponComponent
// Size: 0x68(Inherited: 0x68) 
struct UFWBTDecorator_ValidWeaponComponent : public UBTDecorator
{

}; 



// Class AIFramework.FWBTService_AddGameplayTags
// Size: 0xB0(Inherited: 0x70) 
struct UFWBTService_AddGameplayTags : public UBTService
{
	char pad_112_1 : 7;  // 0x70(0x1)
	bool bRemoveOnEnd : 1;  // 0x70(0x1)
	char pad_113[7];  // 0x71(0x7)
	struct FGameplayTagContainer GameplayTags;  // 0x78(0x20)
	char bShowPropertyDetails : 1;  // 0x98(0x1)
	char pad_152_1 : 7;  // 0x98(0x1)
	char pad_153[8];  // 0x99(0x8)
	struct FString CachedDescription;  // 0xA0(0x10)

}; 



// Class AIFramework.FWBTService_CheckMovementProximity
// Size: 0x78(Inherited: 0x70) 
struct UFWBTService_CheckMovementProximity : public UBTService
{
	float DistanceToProcess;  // 0x70(0x4)
	float TimeToAbort;  // 0x74(0x4)

}; 



// Class AIFramework.FWBTTask_ClearBehaviorTag
// Size: 0x70(Inherited: 0x70) 
struct UFWBTTask_ClearBehaviorTag : public UBTTaskNode
{

}; 



// Class AIFramework.FWBTTask_Dash
// Size: 0xB8(Inherited: 0x78) 
struct UFWBTTask_Dash : public UBTTask_GameplayTaskBase
{
	float WaitTime;  // 0x78(0x4)
	float RandomDeviation;  // 0x7C(0x4)
	char EMovementMode OverrideMoveMode;  // 0x80(0x1)
	char pad_129[7];  // 0x81(0x7)
	struct FBlackboardKeySelector TowardsKey;  // 0x88(0x28)
	UFWAITask_Dash* AITask;  // 0xB0(0x8)

}; 



// Class AIFramework.FWBTTask_ExecuteAITask
// Size: 0x80(Inherited: 0x78) 
struct UFWBTTask_ExecuteAITask : public UBTTask_GameplayTaskBase
{
	UFWAITask* AITask;  // 0x78(0x8)

}; 



// Class AIFramework.PcfEnvQueryTest_DistanceToLine
// Size: 0x278(Inherited: 0x268) 
struct UPcfEnvQueryTest_DistanceToLine : public UEnvQueryTest
{
	UEnvQueryContext* LineEnd;  // 0x268(0x8)
	UEnvQueryContext* DistanceFrom;  // 0x270(0x8)

}; 



// Class AIFramework.FWBTTask_OSARequest
// Size: 0x80(Inherited: 0x70) 
struct UFWBTTask_OSARequest : public UBTTaskNode
{
	float PreShootDelay;  // 0x70(0x4)
	float PostShootDelay;  // 0x74(0x4)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool bPauseMovement : 1;  // 0x78(0x1)
	char pad_121_1 : 7;  // 0x79(0x1)
	bool bAllowTurnInPlace : 1;  // 0x79(0x1)
	char pad_122_1 : 7;  // 0x7A(0x1)
	bool bModifyTurnInPlaceSettings : 1;  // 0x7A(0x1)
	char pad_123[5];  // 0x7B(0x5)

}; 



// Class AIFramework.FWBTTask_UpdateGameplayEffect
// Size: 0x80(Inherited: 0x70) 
struct UFWBTTask_UpdateGameplayEffect : public UBTTaskNode
{
	UGameplayEffect* GameplayEffect;  // 0x70(0x8)
	char bAddEffect : 1;  // 0x78(0x1)
	char pad_120_1 : 7;  // 0x78(0x1)
	char pad_121[4];  // 0x79(0x4)
	float LevelToApply;  // 0x7C(0x4)

}; 



// Class AIFramework.FWBTTask_WaitStop
// Size: 0x70(Inherited: 0x70) 
struct UFWBTTask_WaitStop : public UBTTaskNode
{

}; 



// Class AIFramework.FWCoveringComponent
// Size: 0x1E0(Inherited: 0x1A8) 
struct UFWCoveringComponent : public UActorComponent
{
	struct FCoverSlotInfo CurrentCover;  // 0x1A8(0x18)
	struct FCoverSlotInfo DestinationCover;  // 0x1C0(0x18)
	struct UFWAIWeaponCoverAnimationDataAsset* AIWeaponAnimationDataAsset;  // 0x1D8(0x8)

	struct FCoverSlotInfo GetCoverInfo(uint8_t  CoverMember); // Function AIFramework.FWCoveringComponent.GetCoverInfo
}; 



// Class AIFramework.FWEncounterData
// Size: 0x40(Inherited: 0x30) 
struct UFWEncounterData : public UDataAsset
{
	struct TArray<struct FFWEncounterWaveData> Waves;  // 0x30(0x10)

	struct FText GetWaveDescription(int32_t Idx); // Function AIFramework.FWEncounterData.GetWaveDescription
	struct FFWEncounterWaveData GetWave(int32_t Idx); // Function AIFramework.FWEncounterData.GetWave
}; 



// Class AIFramework.FWEnvQueryContext_BigCharacterPivotLocation
// Size: 0x28(Inherited: 0x28) 
struct UFWEnvQueryContext_BigCharacterPivotLocation : public UEnvQueryContext
{

}; 



// Class AIFramework.FWEnvQueryContext_BBTargetActor
// Size: 0x30(Inherited: 0x30) 
struct UFWEnvQueryContext_BBTargetActor : public UFWEnvQueryContext_BlackboardActor
{

}; 



// Class AIFramework.FWEnvQueryContext_ControlRotationOffsetPoint
// Size: 0x30(Inherited: 0x28) 
struct UFWEnvQueryContext_ControlRotationOffsetPoint : public UEnvQueryContext
{
	float DirectionOffset;  // 0x28(0x4)
	char pad_44[4];  // 0x2C(0x4)

}; 



// Class AIFramework.FWEnvQueryContext_CurrentCover
// Size: 0x28(Inherited: 0x28) 
struct UFWEnvQueryContext_CurrentCover : public UEnvQueryContext
{

}; 



// Class AIFramework.FWEnvQueryTest_IsDoingCoverAction
// Size: 0x268(Inherited: 0x268) 
struct UFWEnvQueryTest_IsDoingCoverAction : public UEnvQueryTest
{

}; 



// Class AIFramework.FWEnvQueryContext_TargetLastSenseLocation
// Size: 0x28(Inherited: 0x28) 
struct UFWEnvQueryContext_TargetLastSenseLocation : public UEnvQueryContext
{

}; 



// Class AIFramework.FWEnvQueryContext_TraceLocation
// Size: 0x48(Inherited: 0x28) 
struct UFWEnvQueryContext_TraceLocation : public UEnvQueryContext
{
	struct FVector StartTraceOffset;  // 0x28(0xC)
	struct FVector EndTraceOffset;  // 0x34(0xC)
	char ECollisionChannel TraceChannel;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)

}; 



// Class AIFramework.FWEnvQueryContext_TraceLocationRand
// Size: 0x78(Inherited: 0x48) 
struct UFWEnvQueryContext_TraceLocationRand : public UFWEnvQueryContext_TraceLocation
{
	struct FVector StartTraceMinRandomOffset;  // 0x48(0xC)
	struct FVector StartTraceMaxRandomOffset;  // 0x54(0xC)
	struct FVector EndTraceMinRandomOffset;  // 0x60(0xC)
	struct FVector EndTraceMaxRandomOffset;  // 0x6C(0xC)

}; 



// Class AIFramework.FWEnvQueryGenerator_AssignedCover
// Size: 0xA0(Inherited: 0x98) 
struct UFWEnvQueryGenerator_AssignedCover : public UEnvQueryGenerator
{
	uint8_t  CoverSelector;  // 0x98(0x1)
	char pad_153[7];  // 0x99(0x7)

}; 



// Class AIFramework.FWEnvQueryGenerator_CoverSlots
// Size: 0xE0(Inherited: 0x98) 
struct UFWEnvQueryGenerator_CoverSlots : public UEnvQueryGenerator
{
	UEnvQueryContext* GenerateAround;  // 0x98(0x8)
	struct FAIDataProviderFloatValue Radius;  // 0xA0(0x38)
	uint8_t  Filter;  // 0xD8(0x1)
	uint8_t  CustomFilter;  // 0xD9(0x1)
	char pad_218[2];  // 0xDA(0x2)
	char bIncludeOwnersSlot : 1;  // 0xDC(0x1)
	char pad_220_1 : 7;  // 0xDC(0x1)
	char pad_221[4];  // 0xDD(0x4)

}; 



// Class AIFramework.SmartObject_BackgroundNPC
// Size: 0x420(Inherited: 0x420) 
struct ASmartObject_BackgroundNPC : public ABaseSmartObject
{

}; 



// Class AIFramework.FWEnvQueryItemType_CombatSpot
// Size: 0x30(Inherited: 0x30) 
struct UFWEnvQueryItemType_CombatSpot : public UEnvQueryItemType_VectorBase
{

}; 



// Class AIFramework.FWEnvQueryTest_CanTraceContext
// Size: 0x310(Inherited: 0x268) 
struct UFWEnvQueryTest_CanTraceContext : public UEnvQueryTest
{
	struct FEnvTraceData TraceData;  // 0x268(0x30)
	struct FAIDataProviderFloatValue ItemHeightOffset;  // 0x298(0x38)
	struct FAIDataProviderFloatValue ContextHeightOffset;  // 0x2D0(0x38)
	UEnvQueryContext* Context;  // 0x308(0x8)

}; 



// Class AIFramework.FWEnvQueryTest_CoverDotTest
// Size: 0x280(Inherited: 0x268) 
struct UFWEnvQueryTest_CoverDotTest : public UEnvQueryTest
{
	float HorizontalExposedDot;  // 0x268(0x4)
	float HorizontalUnexposedDot;  // 0x26C(0x4)
	float VerticalDot;  // 0x270(0x4)
	char pad_628[4];  // 0x274(0x4)
	UEnvQueryContext* Context;  // 0x278(0x8)

}; 



// Class AIFramework.FWEnvQueryTest_DistancesComparisonThreshold
// Size: 0x288(Inherited: 0x268) 
struct UFWEnvQueryTest_DistancesComparisonThreshold : public UEnvQueryTest
{
	struct FFWEnvLine LineA;  // 0x268(0x10)
	struct FFWEnvLine LineB;  // 0x278(0x10)

}; 



// Class AIFramework.FWEnvQueryTest_IsCloseVertToNavMesh
// Size: 0x278(Inherited: 0x268) 
struct UFWEnvQueryTest_IsCloseVertToNavMesh : public UEnvQueryTest
{
	float ProjectDown;  // 0x268(0x4)
	float ProjectUp;  // 0x26C(0x4)
	UNavigationQueryFilter* FilterClass;  // 0x270(0x8)

}; 



// Class AIFramework.FWEnvQueryTest_IsInCover
// Size: 0x268(Inherited: 0x268) 
struct UFWEnvQueryTest_IsInCover : public UEnvQueryTest
{

}; 



// Class AIFramework.FWEnvQueryTest_IsNearNavMeshEdge
// Size: 0x290(Inherited: 0x268) 
struct UFWEnvQueryTest_IsNearNavMeshEdge : public UEnvQueryTest
{
	UEnvQueryContext* Context;  // 0x268(0x8)
	float Distance;  // 0x270(0x4)
	char pad_628[4];  // 0x274(0x4)
	UNavigationQueryFilter* FilterClass;  // 0x278(0x8)
	char pad_640_1 : 7;  // 0x280(0x1)
	bool bProject : 1;  // 0x280(0x1)
	char pad_641[3];  // 0x281(0x3)
	float ProjectDown;  // 0x284(0x4)
	float ProjectUp;  // 0x288(0x4)
	char pad_652[4];  // 0x28C(0x4)

}; 



// Class AIFramework.FWEnvQueryTest_Pathfinding
// Size: 0x340(Inherited: 0x2F0) 
struct UFWEnvQueryTest_Pathfinding : public UEnvQueryTest_Pathfinding
{
	uint8_t  PathFindMode;  // 0x2F0(0x1)
	char pad_753[7];  // 0x2F1(0x7)
	struct FAIDataProviderBoolValue CompareWithIdealPath;  // 0x2F8(0x38)
	UEnvQueryContext* IdealPathStartContext;  // 0x330(0x8)
	UEnvQueryContext* IdealPathEndContext;  // 0x338(0x8)

}; 



// Class AIFramework.FWEnvQueryTest_ThreatLevel
// Size: 0x270(Inherited: 0x268) 
struct UFWEnvQueryTest_ThreatLevel : public UEnvQueryTest
{
	UEnvQueryContext* Context;  // 0x268(0x8)

}; 



// Class AIFramework.FWEnvQueryTest_TimeSinceDanger
// Size: 0x268(Inherited: 0x268) 
struct UFWEnvQueryTest_TimeSinceDanger : public UEnvQueryTest
{

}; 



// Class AIFramework.FWLinkedActorsInterface
// Size: 0x28(Inherited: 0x28) 
struct UFWLinkedActorsInterface : public UInterface
{

	int32_t UnlinkAllActors(); // Function AIFramework.FWLinkedActorsInterface.UnlinkAllActors
	int32_t UnlinkActors(struct TArray<struct AActor*>& Actors); // Function AIFramework.FWLinkedActorsInterface.UnlinkActors
	int32_t UnlinkActor(struct AActor* Actor); // Function AIFramework.FWLinkedActorsInterface.UnlinkActor
	int32_t LinkActors(struct TArray<struct AActor*>& Actors); // Function AIFramework.FWLinkedActorsInterface.LinkActors
	int32_t LinkActor(struct AActor* Actor); // Function AIFramework.FWLinkedActorsInterface.LinkActor
}; 



// Class AIFramework.FWNavigationFilter
// Size: 0x48(Inherited: 0x48) 
struct UFWNavigationFilter : public UNavigationQueryFilter
{

}; 



// Class AIFramework.FWNavigationSystem
// Size: 0x5B8(Inherited: 0x550) 
struct UFWNavigationSystem : public UNavigationSystemV1
{
	char pad_1360[8];  // 0x550(0x8)
	struct TArray<ANavigationData*> NavigationClassesAllowedOnClientSide;  // 0x558(0x10)
	char pad_1384[80];  // 0x568(0x50)

	void OnLevelTransitionCompleted(struct FName regionname); // Function AIFramework.FWNavigationSystem.OnLevelTransitionCompleted
}; 



// Class AIFramework.FWRecastNavMesh
// Size: 0x608(Inherited: 0x5E8) 
struct AFWRecastNavMesh : public ARecastNavMesh
{
	char pad_1512[32];  // 0x5E8(0x20)

}; 



// Class AIFramework.GoalArea
// Size: 0x3C8(Inherited: 0x3C8) 
struct AGoalArea : public AActionArea
{

}; 



// Class AIFramework.PcfBTDecorator_DisanceToAllEnemies
// Size: 0x70(Inherited: 0x68) 
struct UPcfBTDecorator_DisanceToAllEnemies : public UBTDecorator
{
	char EArithmeticKeyOperation Operator;  // 0x68(0x1)
	char pad_105[3];  // 0x69(0x3)
	float SpecifiedDistance;  // 0x6C(0x4)

}; 



// Class AIFramework.PcfBTService_SetFiringAllowed
// Size: 0x78(Inherited: 0x70) 
struct UPcfBTService_SetFiringAllowed : public UBTService
{
	char pad_112_1 : 7;  // 0x70(0x1)
	bool bAllowed : 1;  // 0x70(0x1)
	char pad_113[7];  // 0x71(0x7)

}; 



// Class AIFramework.PcfEnvQueryContext_AllAllies
// Size: 0x28(Inherited: 0x28) 
struct UPcfEnvQueryContext_AllAllies : public UEnvQueryContext
{

}; 



// Class AIFramework.QueryContext_AllEnemiesWithinEffectiveHostileRange
// Size: 0x30(Inherited: 0x30) 
struct UQueryContext_AllEnemiesWithinEffectiveHostileRange : public UQueryContext_AllEnemiesWithinHostileRange
{

}; 



// Class AIFramework.QueryContext_AllPlayers
// Size: 0x28(Inherited: 0x28) 
struct UQueryContext_AllPlayers : public UEnvQueryContext
{

}; 



// Class AIFramework.QueryContext_Goal
// Size: 0x28(Inherited: 0x28) 
struct UQueryContext_Goal : public UEnvQueryContext
{

}; 



// Class AIFramework.QueryContext_SquadMembers
// Size: 0x28(Inherited: 0x28) 
struct UQueryContext_SquadMembers : public UEnvQueryContext
{

}; 



// Class AIFramework.QueryContext_Target
// Size: 0x28(Inherited: 0x28) 
struct UQueryContext_Target : public UEnvQueryContext
{

}; 



// Class AIFramework.QueryContext_TargetFlankRefDirection
// Size: 0x28(Inherited: 0x28) 
struct UQueryContext_TargetFlankRefDirection : public UEnvQueryContext
{

}; 



// Class AIFramework.QueryGenerator_Enemies
// Size: 0xD8(Inherited: 0x98) 
struct UQueryGenerator_Enemies : public UEnvQueryGenerator
{
	char pad_152_1 : 7;  // 0x98(0x1)
	bool bPerceivedEnemiesOnly : 1;  // 0x98(0x1)
	char pad_153_1 : 7;  // 0x99(0x1)
	bool bSleepCapableAIUsePerceivedEnemiesOnly : 1;  // 0x99(0x1)
	char pad_154[6];  // 0x9A(0x6)
	struct FAIDataProviderFloatValue MaxTimeSincePerceived;  // 0xA0(0x38)

}; 



// Class AIFramework.QueryGenerator_HumanPlayers
// Size: 0x98(Inherited: 0x98) 
struct UQueryGenerator_HumanPlayers : public UEnvQueryGenerator
{

}; 



// Class AIFramework.QueryTest_CanFireAt
// Size: 0x2B0(Inherited: 0x268) 
struct UQueryTest_CanFireAt : public UEnvQueryTest
{
	struct FAIDataProviderBoolValue TraceFromContext;  // 0x268(0x38)
	UEnvQueryContext* ToContext;  // 0x2A0(0x8)
	float LocationTestZOffset;  // 0x2A8(0x4)
	char pad_684[4];  // 0x2AC(0x4)

}; 



// Class AIFramework.QueryTest_CoverSlotActions
// Size: 0x270(Inherited: 0x268) 
struct UQueryTest_CoverSlotActions : public UEnvQueryTest
{
	uint8_t  ActionsFilter;  // 0x268(0x1)
	char pad_617[7];  // 0x269(0x7)

}; 



// Class AIFramework.QueryTest_CurrentTarget
// Size: 0x268(Inherited: 0x268) 
struct UQueryTest_CurrentTarget : public UEnvQueryTest
{

}; 



// Class AIFramework.QueryTest_EngagingCounter
// Size: 0x278(Inherited: 0x268) 
struct UQueryTest_EngagingCounter : public UEnvQueryTest
{
	UEnvQueryContext* Context;  // 0x268(0x8)
	APawn* Filter;  // 0x270(0x8)

}; 



// Class AIFramework.QueryTest_IsPlayer
// Size: 0x268(Inherited: 0x268) 
struct UQueryTest_IsPlayer : public UEnvQueryTest
{

}; 



// Class AIFramework.QueryTest_PerceptionAge
// Size: 0x270(Inherited: 0x268) 
struct UQueryTest_PerceptionAge : public UEnvQueryTest
{
	UAISense* SenseClass;  // 0x268(0x8)

}; 



// Class AIFramework.QueryTest_PerceptionAll
// Size: 0x348(Inherited: 0x268) 
struct UQueryTest_PerceptionAll : public UEnvQueryTest
{
	struct TMap<UAISense*, struct FAIDataProviderFloatValue> ScoresPerSense;  // 0x268(0x50)
	struct FAIDataProviderFloatValue MinSenseAge;  // 0x2B8(0x38)
	struct FAIDataProviderFloatValue MaxSenseAge;  // 0x2F0(0x38)
	struct FEnvNamedValue MinAge;  // 0x328(0x10)
	struct FEnvNamedValue MaxAge;  // 0x338(0x10)

}; 



// Class AIFramework.QueryTest_Random
// Size: 0x268(Inherited: 0x268) 
struct UQueryTest_Random : public UEnvQueryTest
{

}; 



// Class AIFramework.SmartObjectUserState
// Size: 0x58(Inherited: 0x28) 
struct USmartObjectUserState : public UObject
{
	struct USmartObjectSlotComponent* ClaimedSmartObjectSlot;  // 0x28(0x8)
	struct TArray<struct FAntFarmControlAttributeState> AttributeStates;  // 0x30(0x10)
	struct USmartObjectSlotComponent* SlotToUseNext;  // 0x40(0x8)
	struct USmartObjectSlotComponent* LastUsedSlot;  // 0x48(0x8)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool bInitialized : 1;  // 0x50(0x1)
	char pad_81[7];  // 0x51(0x7)

}; 



// Class AIFramework.SmartObjectLogic
// Size: 0x40(Inherited: 0x30) 
struct USmartObjectLogic : public UAIGlobalsDataAsset
{
	struct TArray<struct FAntFarmControlAttributeData> ControlAttributes;  // 0x30(0x10)

}; 



// Class AIFramework.SmartObjectRenderingComponent
// Size: 0x510(Inherited: 0x510) 
struct USmartObjectRenderingComponent : public UPrimitiveComponent
{

}; 



// Class AIFramework.Waypoint
// Size: 0x348(Inherited: 0x320) 
struct AWaypoint : public AActor
{
	int16_t NodeRef;  // 0x320(0x2)
	char pad_802[2];  // 0x322(0x2)
	int32_t StartQueryRadius;  // 0x324(0x4)
	int32_t EndQueryRadius;  // 0x328(0x4)
	char pad_812[4];  // 0x32C(0x4)
	struct TArray<struct FWaypointConnection> Connections;  // 0x330(0x10)
	struct UCapsuleComponent* CapsuleComponent;  // 0x340(0x8)

}; 



// Class AIFramework.WaypointDebugRenderingComponent
// Size: 0x510(Inherited: 0x510) 
struct UWaypointDebugRenderingComponent : public UPrimitiveComponent
{

}; 



// Class AIFramework.WaypointNavigationSettings
// Size: 0x60(Inherited: 0x38) 
struct UWaypointNavigationSettings : public UDeveloperSettings
{
	struct FString SubLevelSuffix;  // 0x38(0x10)
	struct TArray<struct FAssetPath> NameCheckExcludedLevels;  // 0x48(0x10)
	float StartQueryRadius;  // 0x58(0x4)
	float EndQueryRadius;  // 0x5C(0x4)

}; 



