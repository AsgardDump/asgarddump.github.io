#pragma once 
#include <ATDLC07_Structs.h>
 
 
 
// BlueprintGeneratedClass ATDLC07.ATDLC07_C
// Size: 0x28(Inherited: 0x28) 
struct UATDLC07_C : public UMadSkillDataObject
{

	float GetQuaternaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function ATDLC07.ATDLC07_C.GetQuaternaryExtraData
	float GetTertiaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function ATDLC07.ATDLC07_C.GetTertiaryExtraData
	float GetSecondaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function ATDLC07.ATDLC07_C.GetSecondaryExtraData
	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function ATDLC07.ATDLC07_C.GetPrimaryExtraData
}; 



