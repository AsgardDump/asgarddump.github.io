#pragma once 
#include <BP_ASR_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_ASR.BP_ASR_C
// Size: 0x1F90(Inherited: 0x1F90) 
struct ABP_ASR_C : public AMadRifle
{

}; 



