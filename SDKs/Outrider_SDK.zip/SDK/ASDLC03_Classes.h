#pragma once 
#include <ASDLC03_Structs.h>
 
 
 
// BlueprintGeneratedClass ASDLC03.ASDLC03_C
// Size: 0x28(Inherited: 0x28) 
struct UASDLC03_C : public UMadSkillDataObject
{

	float GetSecondaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function ASDLC03.ASDLC03_C.GetSecondaryExtraData
	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function ASDLC03.ASDLC03_C.GetPrimaryExtraData
}; 



