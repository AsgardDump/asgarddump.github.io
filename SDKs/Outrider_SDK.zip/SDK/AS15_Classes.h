#pragma once 
#include <AS15_Structs.h>
 
 
 
// BlueprintGeneratedClass AS15.AS15_C
// Size: 0x28(Inherited: 0x28) 
struct UAS15_C : public UMadSkillDataObject
{

	float GetTertiaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function AS15.AS15_C.GetTertiaryExtraData
	float GetSecondaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function AS15.AS15_C.GetSecondaryExtraData
	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function AS15.AS15_C.GetPrimaryExtraData
}; 



