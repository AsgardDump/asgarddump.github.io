#pragma once 
#include <ANDLC19_Structs.h>
 
 
 
// BlueprintGeneratedClass ANDLC19.ANDLC19_C
// Size: 0x28(Inherited: 0x28) 
struct UANDLC19_C : public UMadSkillDataObject
{

	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function ANDLC19.ANDLC19_C.GetPrimaryExtraData
}; 



