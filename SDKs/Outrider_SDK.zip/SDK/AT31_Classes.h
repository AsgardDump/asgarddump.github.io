#pragma once 
#include <AT31_Structs.h>
 
 
 
// BlueprintGeneratedClass AT31.AT31_C
// Size: 0x28(Inherited: 0x28) 
struct UAT31_C : public UMadSkillDataObject
{

	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function AT31.AT31_C.GetPrimaryExtraData
}; 



