#pragma once 
#include "SDK.h" 
 
 
// ScriptStruct AudioExtensions.SoundModulationParameter
// Size: 0x14(Inherited: 0x0) 
struct FSoundModulationParameter
{
	struct FName Control;  // 0x0(0x8)
	float Value;  // 0x8(0x4)
	char pad_12[8];  // 0xC(0x8)

}; 
// ScriptStruct AudioExtensions.SoundModulation
// Size: 0x10(Inherited: 0x0) 
struct FSoundModulation
{
	struct TArray<struct USoundModulationPluginSourceSettingsBase*> Settings;  // 0x0(0x10)

}; 
