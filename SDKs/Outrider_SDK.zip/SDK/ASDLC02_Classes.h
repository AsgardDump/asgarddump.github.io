#pragma once 
#include <ASDLC02_Structs.h>
 
 
 
// BlueprintGeneratedClass ASDLC02.ASDLC02_C
// Size: 0x28(Inherited: 0x28) 
struct UASDLC02_C : public UMadSkillDataObject
{

	float GetSecondaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function ASDLC02.ASDLC02_C.GetSecondaryExtraData
	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function ASDLC02.ASDLC02_C.GetPrimaryExtraData
}; 



