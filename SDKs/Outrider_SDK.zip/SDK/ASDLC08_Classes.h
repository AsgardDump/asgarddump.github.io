#pragma once 
#include <ASDLC08_Structs.h>
 
 
 
// BlueprintGeneratedClass ASDLC08.ASDLC08_C
// Size: 0x28(Inherited: 0x28) 
struct UASDLC08_C : public UMadSkillDataObject
{

	float GetQuaternaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function ASDLC08.ASDLC08_C.GetQuaternaryExtraData
	float GetTertiaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function ASDLC08.ASDLC08_C.GetTertiaryExtraData
	float GetSecondaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function ASDLC08.ASDLC08_C.GetSecondaryExtraData
	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function ASDLC08.ASDLC08_C.GetPrimaryExtraData
}; 



