#pragma once 
#include <BP_FlamingTurret_ProjectileExplosion_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_FlamingTurret_ProjectileExplosion.BP_FlamingTurret_ProjectileExplosion_C
// Size: 0x1E0(Inherited: 0x1E0) 
struct UBP_FlamingTurret_ProjectileExplosion_C : public UMadExplosionTemplate
{

}; 



