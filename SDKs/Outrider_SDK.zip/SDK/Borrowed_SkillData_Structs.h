#pragma once 
#include "SDK.h" 
 
 
// Function Borrowed_SkillData.Borrowed_SkillData_C.GetSecondaryExtraData
// Size: 0x58(Inherited: 0x10) 
struct FGetSecondaryExtraData : public FGetSecondaryExtraData
{
	struct AMadBaseCharacter* MadInstigatorCharacter;  // 0x0(0x8)
	int32_t ItemLevel;  // 0x8(0x4)
	float ReturnValue;  // 0xC(0x4)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool Temp_bool_Variable : 1;  // 0x10(0x1)
	struct TScriptInterface<IGameplayTagAssetInterface> K2Node_DynamicCast_AsGameplay_Tag_Asset_Interface;  // 0x18(0x10)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x28(0x1)
	char pad_50_1 : 7;  // 0x32(0x1)
	bool CallFunc_HasMatchingGameplayTag_ReturnValue : 1;  // 0x29(0x1)
	char pad_51_1 : 7;  // 0x33(0x1)
	bool CallFunc_GetFloatAttribute_bSuccessfullyFoundAttribute : 1;  // 0x2A(0x1)
	float CallFunc_GetFloatAttribute_ReturnValue;  // 0x2C(0x4)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0x30(0x1)
	char EEvaluateCurveTableResult CallFunc_EvaluateCurveTableRow_OutResult;  // 0x31(0x1)
	float CallFunc_EvaluateCurveTableRow_OutXY;  // 0x34(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x38(0x4)
	char pad_66_1 : 7;  // 0x42(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x3C(0x1)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0x40(0x4)
	char EEvaluateCurveTableResult CallFunc_EvaluateCurveTableRow_OutResult_2;  // 0x44(0x1)
	float CallFunc_EvaluateCurveTableRow_OutXY_2;  // 0x48(0x4)
	float K2Node_Select_Default;  // 0x4C(0x4)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool K2Node_SwitchEnum_CmpSuccess_2 : 1;  // 0x50(0x1)
	char pad_81[3];  // 0x51(0x3)
	float CallFunc_Multiply_FloatFloat_ReturnValue_2;  // 0x54(0x4)

}; 
// Function Borrowed_SkillData.Borrowed_SkillData_C.GetPrimaryExtraData
// Size: 0x44(Inherited: 0x10) 
struct FGetPrimaryExtraData : public FGetPrimaryExtraData
{
	struct AMadBaseCharacter* MadInstigatorCharacter;  // 0x0(0x8)
	int32_t ItemLevel;  // 0x8(0x4)
	float ReturnValue;  // 0xC(0x4)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_GetFloatAttribute_bSuccessfullyFoundAttribute : 1;  // 0x10(0x1)
	float CallFunc_GetFloatAttribute_ReturnValue;  // 0x14(0x4)
	char pad_37_1 : 7;  // 0x25(0x1)
	bool CallFunc_GetFloatAttribute_bSuccessfullyFoundAttribute_2 : 1;  // 0x18(0x1)
	float CallFunc_GetFloatAttribute_ReturnValue_2;  // 0x1C(0x4)
	char EEvaluateCurveTableResult CallFunc_EvaluateCurveTableRow_OutResult;  // 0x20(0x1)
	float CallFunc_EvaluateCurveTableRow_OutXY;  // 0x24(0x4)
	char pad_47_1 : 7;  // 0x2F(0x1)
	bool CallFunc_GetFloatAttribute_bSuccessfullyFoundAttribute_3 : 1;  // 0x28(0x1)
	float CallFunc_GetFloatAttribute_ReturnValue_3;  // 0x2C(0x4)
	char pad_52_1 : 7;  // 0x34(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x30(0x1)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x34(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_2;  // 0x38(0x4)
	int32_t CallFunc_FCeil_ReturnValue;  // 0x3C(0x4)
	float CallFunc_Conv_IntToFloat_ReturnValue;  // 0x40(0x4)

}; 
