#pragma once 
#include <ASDLC20_Structs.h>
 
 
 
// BlueprintGeneratedClass ASDLC20.ASDLC20_C
// Size: 0x28(Inherited: 0x28) 
struct UASDLC20_C : public UMadSkillDataObject
{

	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function ASDLC20.ASDLC20_C.GetPrimaryExtraData
}; 



