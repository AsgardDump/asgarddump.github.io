#pragma once 
#include <AS01_Structs.h>
 
 
 
// BlueprintGeneratedClass AS01.AS01_C
// Size: 0x28(Inherited: 0x28) 
struct UAS01_C : public UMadSkillDataObject
{

	float GetSecondaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function AS01.AS01_C.GetSecondaryExtraData
	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function AS01.AS01_C.GetPrimaryExtraData
}; 



