#pragma once 
#include <AN79_Structs.h>
 
 
 
// BlueprintGeneratedClass AN79.AN79_C
// Size: 0x28(Inherited: 0x28) 
struct UAN79_C : public UMadSkillDataObject
{

	float GetTertiaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function AN79.AN79_C.GetTertiaryExtraData
	float GetSecondaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function AN79.AN79_C.GetSecondaryExtraData
	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function AN79.AN79_C.GetPrimaryExtraData
}; 



