#pragma once 
#include <BP_Enemy_CryoTurretGun_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Enemy_CryoTurretGun.BP_Enemy_CryoTurretGun_C
// Size: 0x1F90(Inherited: 0x1F90) 
struct ABP_Enemy_CryoTurretGun_C : public AMadAssaultWeapon
{

}; 



