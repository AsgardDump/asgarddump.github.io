#pragma once 
#include <ASDLC09_Structs.h>
 
 
 
// BlueprintGeneratedClass ASDLC09.ASDLC09_C
// Size: 0x28(Inherited: 0x28) 
struct UASDLC09_C : public UMadSkillDataObject
{

	float GetSecondaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function ASDLC09.ASDLC09_C.GetSecondaryExtraData
	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function ASDLC09.ASDLC09_C.GetPrimaryExtraData
}; 



