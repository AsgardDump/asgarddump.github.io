#pragma once 
#include <ASDLC06_Structs.h>
 
 
 
// BlueprintGeneratedClass ASDLC06.ASDLC06_C
// Size: 0x28(Inherited: 0x28) 
struct UASDLC06_C : public UMadSkillDataObject
{

	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function ASDLC06.ASDLC06_C.GetPrimaryExtraData
}; 



