#pragma once 
#include <ANDLC16_Structs.h>
 
 
 
// BlueprintGeneratedClass ANDLC16.ANDLC16_C
// Size: 0x28(Inherited: 0x28) 
struct UANDLC16_C : public UMadSkillDataObject
{

	float GetSecondaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function ANDLC16.ANDLC16_C.GetSecondaryExtraData
	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function ANDLC16.ANDLC16_C.GetPrimaryExtraData
}; 



