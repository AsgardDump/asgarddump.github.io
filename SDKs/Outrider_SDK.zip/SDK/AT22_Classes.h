#pragma once 
#include <AT22_Structs.h>
 
 
 
// BlueprintGeneratedClass AT22.AT22_C
// Size: 0x28(Inherited: 0x28) 
struct UAT22_C : public UMadSkillDataObject
{

	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function AT22.AT22_C.GetPrimaryExtraData
}; 



