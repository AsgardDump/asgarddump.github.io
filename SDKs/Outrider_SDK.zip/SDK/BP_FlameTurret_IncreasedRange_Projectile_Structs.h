#pragma once 
#include "SDK.h" 
 
 
// Function BP_FlameTurret_IncreasedRange_Projectile.BP_FlameTurret_IncreasedRange_Projectile_C.ExecuteUbergraph_BP_FlameTurret_IncreasedRange_Projectile
// Size: 0x18(Inherited: 0x0) 
struct FExecuteUbergraph_BP_FlameTurret_IncreasedRange_Projectile
{
	int32_t EntryPoint;  // 0x0(0x4)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x4(0xC)
	struct UAudioComponent* CallFunc_SpawnSoundAtLocation_ReturnValue;  // 0x10(0x8)

}; 
