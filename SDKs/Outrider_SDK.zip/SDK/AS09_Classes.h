#pragma once 
#include <AS09_Structs.h>
 
 
 
// BlueprintGeneratedClass AS09.AS09_C
// Size: 0x28(Inherited: 0x28) 
struct UAS09_C : public UMadSkillDataObject
{

	float GetSecondaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function AS09.AS09_C.GetSecondaryExtraData
	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function AS09.AS09_C.GetPrimaryExtraData
}; 



