#pragma once 
#include <AN69_Structs.h>
 
 
 
// BlueprintGeneratedClass AN69.AN69_C
// Size: 0x28(Inherited: 0x28) 
struct UAN69_C : public UMadSkillDataObject
{

	float GetSecondaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function AN69.AN69_C.GetSecondaryExtraData
	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function AN69.AN69_C.GetPrimaryExtraData
}; 



