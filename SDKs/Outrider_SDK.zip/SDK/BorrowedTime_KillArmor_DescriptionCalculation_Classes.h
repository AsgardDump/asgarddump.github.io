#pragma once 
#include <BorrowedTime_KillArmor_DescriptionCalculation_Structs.h>
 
 
 
// BlueprintGeneratedClass BorrowedTime_KillArmor_DescriptionCalculation.BorrowedTime_KillArmor_DescriptionCalculation_C
// Size: 0x28(Inherited: 0x28) 
struct UBorrowedTime_KillArmor_DescriptionCalculation_C : public UMadSkillDataObject
{

	float GetTertiaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function BorrowedTime_KillArmor_DescriptionCalculation.BorrowedTime_KillArmor_DescriptionCalculation_C.GetTertiaryExtraData
	float GetSecondaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function BorrowedTime_KillArmor_DescriptionCalculation.BorrowedTime_KillArmor_DescriptionCalculation_C.GetSecondaryExtraData
	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function BorrowedTime_KillArmor_DescriptionCalculation.BorrowedTime_KillArmor_DescriptionCalculation_C.GetPrimaryExtraData
}; 



