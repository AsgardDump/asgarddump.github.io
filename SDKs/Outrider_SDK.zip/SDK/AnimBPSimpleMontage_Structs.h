#pragma once 
#include "SDK.h" 
 
 
// Function AnimBPSimpleMontage.AnimBPSimpleMontage_C.ExecuteUbergraph_AnimBPSimpleMontage
// Size: 0x20(Inherited: 0x0) 
struct FExecuteUbergraph_AnimBPSimpleMontage
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x8(0x10)
	struct UDNAContext* CallFunc_GetLateralDNAContext_ReturnValue;  // 0x18(0x8)

}; 
// Function AnimBPSimpleMontage.AnimBPSimpleMontage_C.AnimGraph
// Size: 0x10(Inherited: 0x0) 
struct FAnimGraph
{
	struct FPoseLink AnimGraph;  // 0x0(0x10)

}; 
