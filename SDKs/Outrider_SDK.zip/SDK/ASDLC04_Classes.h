#pragma once 
#include <ASDLC04_Structs.h>
 
 
 
// BlueprintGeneratedClass ASDLC04.ASDLC04_C
// Size: 0x28(Inherited: 0x28) 
struct UASDLC04_C : public UMadSkillDataObject
{

	float GetSecondaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function ASDLC04.ASDLC04_C.GetSecondaryExtraData
	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function ASDLC04.ASDLC04_C.GetPrimaryExtraData
}; 



