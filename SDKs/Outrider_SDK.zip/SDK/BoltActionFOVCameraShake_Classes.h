#pragma once 
#include <BoltActionFOVCameraShake_Structs.h>
 
 
 
// BlueprintGeneratedClass BoltActionFOVCameraShake.BoltActionFOVCameraShake_C
// Size: 0x160(Inherited: 0x160) 
struct UBoltActionFOVCameraShake_C : public UCameraShake
{

}; 



