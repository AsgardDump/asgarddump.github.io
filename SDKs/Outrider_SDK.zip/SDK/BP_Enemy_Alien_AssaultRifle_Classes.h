#pragma once 
#include <BP_Enemy_Alien_AssaultRifle_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Enemy_Alien_AssaultRifle.BP_Enemy_Alien_AssaultRifle_C
// Size: 0x1F90(Inherited: 0x1F90) 
struct ABP_Enemy_Alien_AssaultRifle_C : public AMadAssaultWeapon
{

}; 



