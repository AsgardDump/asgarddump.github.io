#pragma once 
#include <AS73_Structs.h>
 
 
 
// BlueprintGeneratedClass AS73.AS73_C
// Size: 0x28(Inherited: 0x28) 
struct UAS73_C : public UMadSkillDataObject
{

	float GetSecondaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function AS73.AS73_C.GetSecondaryExtraData
	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function AS73.AS73_C.GetPrimaryExtraData
}; 



