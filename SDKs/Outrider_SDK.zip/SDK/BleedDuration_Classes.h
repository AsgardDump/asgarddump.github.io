#pragma once 
#include <BleedDuration_Structs.h>
 
 
 
// BlueprintGeneratedClass BleedDuration.BleedDuration_C
// Size: 0x28(Inherited: 0x28) 
struct UBleedDuration_C : public UMadSkillDataObject
{

	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function BleedDuration.BleedDuration_C.GetPrimaryExtraData
}; 



