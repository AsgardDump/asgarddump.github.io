#pragma once 
#include <BP_AdaptiveMusicSystem_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_AdaptiveMusicSystem.BP_AdaptiveMusicSystem_C
// Size: 0xC0(Inherited: 0xC0) 
struct UBP_AdaptiveMusicSystem_C : public UFWAdaptiveMusicSystem
{

}; 



