#pragma once 
#include <BP_AssaultRifle_Boss3Prototype_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_AssaultRifle_Boss3Prototype.BP_AssaultRifle_Boss3Prototype_C
// Size: 0x1F90(Inherited: 0x1F90) 
struct ABP_AssaultRifle_Boss3Prototype_C : public AMadAssaultWeapon
{

}; 



