#pragma once 
#include <ATDLC11_Structs.h>
 
 
 
// BlueprintGeneratedClass ATDLC11.ATDLC11_C
// Size: 0x28(Inherited: 0x28) 
struct UATDLC11_C : public UMadSkillDataObject
{

	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function ATDLC11.ATDLC11_C.GetPrimaryExtraData
}; 



