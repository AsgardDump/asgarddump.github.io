#pragma once 
#include <ActorSequence_Structs.h>
 
 
 
// Class ActorSequence.ActorSequenceComponent
// Size: 0x1D0(Inherited: 0x1A8) 
struct UActorSequenceComponent : public UActorComponent
{
	struct FMovieSceneSequencePlaybackSettings PlaybackSettings;  // 0x1A8(0x14)
	char pad_444[4];  // 0x1BC(0x4)
	struct UActorSequence* Sequence;  // 0x1C0(0x8)
	struct UActorSequencePlayer* SequencePlayer;  // 0x1C8(0x8)

}; 



// Class ActorSequence.ActorSequence
// Size: 0x370(Inherited: 0x348) 
struct UActorSequence : public UMovieSceneSequence
{
	struct UMovieScene* MovieScene;  // 0x348(0x8)
	struct FActorSequenceObjectReferenceMap ObjectReferences;  // 0x350(0x20)

}; 



// Class ActorSequence.ActorSequencePlayer
// Size: 0x880(Inherited: 0x880) 
struct UActorSequencePlayer : public UMovieSceneSequencePlayer
{

}; 



