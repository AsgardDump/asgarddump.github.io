#pragma once 
#include <BP_GravityJumpExplosion_BlindSeer_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_GravityJumpExplosion_BlindSeer.BP_GravityJumpExplosion_BlindSeer_C
// Size: 0x1E0(Inherited: 0x1E0) 
struct UBP_GravityJumpExplosion_BlindSeer_C : public UMadExplosionTemplate
{

}; 



