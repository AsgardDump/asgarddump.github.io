#pragma once 
#include <BP_AutoShotgun_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_AutoShotgun.BP_AutoShotgun_C
// Size: 0x2000(Inherited: 0x2000) 
struct ABP_AutoShotgun_C : public AMadShotgun
{

}; 



