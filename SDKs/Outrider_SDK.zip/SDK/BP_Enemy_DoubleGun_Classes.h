#pragma once 
#include <BP_Enemy_DoubleGun_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Enemy_DoubleGun.BP_Enemy_DoubleGun_C
// Size: 0x1F90(Inherited: 0x1F90) 
struct ABP_Enemy_DoubleGun_C : public AMadAssaultWeapon
{

}; 



