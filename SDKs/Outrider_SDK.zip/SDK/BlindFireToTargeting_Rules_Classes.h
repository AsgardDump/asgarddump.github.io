#pragma once 
#include <BlindFireToTargeting_Rules_Structs.h>
 
 
 
// BlueprintGeneratedClass BlindFireToTargeting_Rules.BlindFireToTargeting_Rules_C
// Size: 0x50(Inherited: 0x50) 
struct UBlindFireToTargeting_Rules_C : public UCameraTransitionRules
{

	bool CanTransition(); // Function BlindFireToTargeting_Rules.BlindFireToTargeting_Rules_C.CanTransition
}; 



