#pragma once 
#include "SDK.h" 
 
 
// Function AshBlast_EnemyArmorDown_DescriptionCalculation.AshBlast_EnemyArmorDown_DescriptionCalculation_C.GetSecondaryExtraData
// Size: 0x28(Inherited: 0x10) 
struct FGetSecondaryExtraData : public FGetSecondaryExtraData
{
	struct AMadBaseCharacter* MadInstigatorCharacter;  // 0x0(0x8)
	int32_t ItemLevel;  // 0x8(0x4)
	float ReturnValue;  // 0xC(0x4)
	float CallFunc_Conv_IntToFloat_ReturnValue;  // 0x10(0x4)
	char EEvaluateCurveTableResult CallFunc_EvaluateCurveTableRow_OutResult;  // 0x14(0x1)
	float CallFunc_EvaluateCurveTableRow_OutXY;  // 0x18(0x4)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x1C(0x1)
	int32_t CallFunc_Round_ReturnValue;  // 0x20(0x4)
	float CallFunc_Conv_IntToFloat_ReturnValue_2;  // 0x24(0x4)

}; 
// Function AshBlast_EnemyArmorDown_DescriptionCalculation.AshBlast_EnemyArmorDown_DescriptionCalculation_C.GetPrimaryExtraData
// Size: 0x2C(Inherited: 0x10) 
struct FGetPrimaryExtraData : public FGetPrimaryExtraData
{
	struct AMadBaseCharacter* MadInstigatorCharacter;  // 0x0(0x8)
	int32_t ItemLevel;  // 0x8(0x4)
	float ReturnValue;  // 0xC(0x4)
	float CallFunc_Conv_IntToFloat_ReturnValue;  // 0x10(0x4)
	char EEvaluateCurveTableResult CallFunc_EvaluateCurveTableRow_OutResult;  // 0x14(0x1)
	float CallFunc_EvaluateCurveTableRow_OutXY;  // 0x18(0x4)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x1C(0x1)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x20(0x4)
	int32_t CallFunc_Round_ReturnValue;  // 0x24(0x4)
	float CallFunc_Conv_IntToFloat_ReturnValue_2;  // 0x28(0x4)

}; 
