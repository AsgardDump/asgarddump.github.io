#pragma once 
#include <AS06_Structs.h>
 
 
 
// BlueprintGeneratedClass AS06.AS06_C
// Size: 0x28(Inherited: 0x28) 
struct UAS06_C : public UMadSkillDataObject
{

	float GetSecondaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function AS06.AS06_C.GetSecondaryExtraData
	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function AS06.AS06_C.GetPrimaryExtraData
}; 



