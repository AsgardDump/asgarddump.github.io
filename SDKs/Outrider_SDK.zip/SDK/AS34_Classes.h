#pragma once 
#include <AS34_Structs.h>
 
 
 
// BlueprintGeneratedClass AS34.AS34_C
// Size: 0x28(Inherited: 0x28) 
struct UAS34_C : public UMadSkillDataObject
{

	float GetSecondaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function AS34.AS34_C.GetSecondaryExtraData
	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function AS34.AS34_C.GetPrimaryExtraData
}; 



