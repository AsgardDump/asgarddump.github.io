#pragma once 
#include <BP_FlameTurretGun_AddDamage_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_FlameTurretGun_AddDamage.BP_FlameTurretGun_AddDamage_C
// Size: 0x1FA0(Inherited: 0x1FA0) 
struct ABP_FlameTurretGun_AddDamage_C : public AMadFlamethrower
{

}; 



