#pragma once 
#include <AnimFramework_Structs.h>
 
 
 
// Class AnimFramework.FWAnimInstance_Base
// Size: 0x380(Inherited: 0x2C0) 
struct UFWAnimInstance_Base : public UAnimInstance
{
	struct TArray<struct FAnimRootMotionAdjuster> RootMotionAdjustments;  // 0x2C0(0x10)
	char pad_720[176];  // 0x2D0(0xB0)

	void UpdateRootMotionAdjustmentTarget(int32_t AdjusterId, struct FVector& InTargetPosWS, struct FRotator& InTargetRotWS, bool bUseMaxAllowedDistanceError, float MaxAllowedDistanceError, bool bUseMaxAllowedAngleError, float MaxAllowedAngleError); // Function AnimFramework.FWAnimInstance_Base.UpdateRootMotionAdjustmentTarget
	bool TurnOnRagdollByBones(float TransitionTime, struct TArray<struct FName>& BoneNamesToStartRagdoll, bool bIncludeSelf); // Function AnimFramework.FWAnimInstance_Base.TurnOnRagdollByBones
	bool TurnOnRagdoll(float TransitionTime); // Function AnimFramework.FWAnimInstance_Base.TurnOnRagdoll
	bool TurnOffRagdoll(float TransitionTime); // Function AnimFramework.FWAnimInstance_Base.TurnOffRagdoll
	int32_t RequestRootMotionAdjustmentOnSurface(struct FVector& InTargetPosWS, struct UAnimMontage* AnimMontage, float AdjustmentStartTime, float AdjustmentEndTime, bool bAdjustAbsolute, float MaxDistanceErrorAllowed, struct UCurveFloat* InterpolationCurve); // Function AnimFramework.FWAnimInstance_Base.RequestRootMotionAdjustmentOnSurface
	int32_t RequestRootMotionAdjustmentOnRotation(struct FRotator& InTargetRotWS, struct UAnimMontage* AnimMontage, float AdjustmentStartTime, float AdjustmentEndTime, bool bAdjustAbsolute, float MaxDistanceErrorAllowed, struct UCurveFloat* InterpolationCurve); // Function AnimFramework.FWAnimInstance_Base.RequestRootMotionAdjustmentOnRotation
	int32_t RequestRootMotionAdjustmentOnHeight(struct FVector& InTargetPosWS, struct UAnimMontage* AnimMontage, float AdjustmentStartTime, float AdjustmentEndTime, bool bAdjustAbsolute, float MaxDistanceErrorAllowed, struct UCurveFloat* InterpolationCurve); // Function AnimFramework.FWAnimInstance_Base.RequestRootMotionAdjustmentOnHeight
	int32_t RequestRootMotionAdjustment(struct FAnimRootMotionAdjusterTargetData& InAdjData); // Function AnimFramework.FWAnimInstance_Base.RequestRootMotionAdjustment
	void RequestAdjusterTermination(int32_t AdjusterId); // Function AnimFramework.FWAnimInstance_Base.RequestAdjusterTermination
	bool IsSlotPlayingAnyAnimation(struct FName SlotNodeName); // Function AnimFramework.FWAnimInstance_Base.IsSlotPlayingAnyAnimation
	bool IsRagdollBlending(); // Function AnimFramework.FWAnimInstance_Base.IsRagdollBlending
	bool IsPlayingSlotAdditiveAnimation(struct FName SlotNodeName); // Function AnimFramework.FWAnimInstance_Base.IsPlayingSlotAdditiveAnimation
}; 



// Class AnimFramework.AnimNotifyState_LeftFootDown
// Size: 0x58(Inherited: 0x58) 
struct UAnimNotifyState_LeftFootDown : public UAnimNotifyState_Foot
{

}; 



// Class AnimFramework.AnimNotifyState_Foot
// Size: 0x58(Inherited: 0x50) 
struct UAnimNotifyState_Foot : public UAnimNotifyState_CharacterEffect
{
	char pad_80[8];  // 0x50(0x8)

}; 



// Class AnimFramework.AnimProxyBasedAnimInstance
// Size: 0x9B0(Inherited: 0x2C0) 
struct UAnimProxyBasedAnimInstance : public UAnimInstance
{
	uint8_t  FootStatus;  // 0x2C0(0x1)
	uint8_t  PreviousFootStatus;  // 0x2C1(0x1)
	uint8_t  RightFootStatus;  // 0x2C2(0x1)
	uint8_t  LeftFootStatus;  // 0x2C3(0x1)
	char bIsCorrectPoseForTransition : 1;  // 0x2C4(0x1)
	char bIsCorrectFootStatusForTransition : 1;  // 0x2C4(0x1)
	char pad_708_1 : 6;  // 0x2C4(0x1)
	char pad_709[4];  // 0x2C5(0x4)
	float CorrectPoseForTransitionTimeout;  // 0x2C8(0x4)
	char pad_716[4];  // 0x2CC(0x4)
	struct FAnimInstanceProxy Proxy;  // 0x2D0(0x6E0)

	void StopMontageOnSlot(struct FName SlotNodeName, float BlendOut); // Function AnimFramework.AnimProxyBasedAnimInstance.StopMontageOnSlot
	void StopMontageOnGroup(struct FName InGroupName, float BlendOut); // Function AnimFramework.AnimProxyBasedAnimInstance.StopMontageOnGroup
	bool IsSlotNodePlayingMontage(struct FName SlotNodeName, bool bIncludeBlendingOut); // Function AnimFramework.AnimProxyBasedAnimInstance.IsSlotNodePlayingMontage
	bool IsMontagePlayingOnGroup(struct FName InGroupName, bool bIncludeBlendingOut); // Function AnimFramework.AnimProxyBasedAnimInstance.IsMontagePlayingOnGroup
	float GetRelevantGateTimeRemaining(int32_t MachineIndex, int32_t StateIndex); // Function AnimFramework.AnimProxyBasedAnimInstance.GetRelevantGateTimeRemaining
	bool GetIsCorrectPoseForTransition(int32_t MachineIndex, int32_t StateIndex, int32_t TransitionIndex); // Function AnimFramework.AnimProxyBasedAnimInstance.GetIsCorrectPoseForTransition
	bool GetIsCorrectFootStatusForTransition(int32_t MachineIndex, int32_t StateIndex, int32_t TransitionIndex); // Function AnimFramework.AnimProxyBasedAnimInstance.GetIsCorrectFootStatusForTransition
}; 



// Class AnimFramework.AnimNotify_RequestClothExtendedSimulation
// Size: 0x40(Inherited: 0x38) 
struct UAnimNotify_RequestClothExtendedSimulation : public UAnimNotify
{
	int32_t ExtendedFrames;  // 0x38(0x4)
	float ExtendedSimulationTime;  // 0x3C(0x4)

}; 



// Class AnimFramework.AnimNotifyState_WithAudioSettings
// Size: 0x40(Inherited: 0x38) 
struct UAnimNotifyState_WithAudioSettings : public UAnimNotifyState
{
	float VolumeMultiplier;  // 0x38(0x4)
	float PitchMultiplier;  // 0x3C(0x4)

}; 



// Class AnimFramework.AnimNotifyState_CharacterEffect
// Size: 0x50(Inherited: 0x40) 
struct UAnimNotifyState_CharacterEffect : public UAnimNotifyState_WithAudioSettings
{
	struct FName BoneSocket;  // 0x40(0x8)
	char EAxis LocalUp;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 



// Class AnimFramework.BaseAnimInstanceForHumanNPC
// Size: 0x9C0(Inherited: 0x9B0) 
struct UBaseAnimInstanceForHumanNPC : public UAnimProxyBasedAnimInstance
{
	struct FVector ReactionLookAtTarget;  // 0x9B0(0xC)
	float ReactionLookAtHeadAlpha;  // 0x9BC(0x4)

}; 



// Class AnimFramework.AnimNotify_CoverLowOut
// Size: 0x40(Inherited: 0x40) 
struct UAnimNotify_CoverLowOut : public UAnimNotify_WithAudioSettings
{

}; 



// Class AnimFramework.AnimNotifyState_RightFootDown
// Size: 0x58(Inherited: 0x58) 
struct UAnimNotifyState_RightFootDown : public UAnimNotifyState_Foot
{

}; 



// Class AnimFramework.AnimNotify_PoseSync
// Size: 0x38(Inherited: 0x38) 
struct UAnimNotify_PoseSync : public UAnimNotify
{

}; 



// Class AnimFramework.AnimNotifyState_SlideToCover
// Size: 0x58(Inherited: 0x50) 
struct UAnimNotifyState_SlideToCover : public UAnimNotifyState_CharacterEffect
{
	float TraceDistance;  // 0x50(0x4)
	char pad_84[4];  // 0x54(0x4)

}; 



// Class AnimFramework.StreamableCinematic
// Size: 0x50(Inherited: 0x28) 
struct UStreamableCinematic : public UObject
{
	char pad_40[8];  // 0x28(0x8)
	struct ULevelSequence* Sequence;  // 0x30(0x8)
	char pad_56[24];  // 0x38(0x18)

	void Unload(); // Function AnimFramework.StreamableCinematic.Unload
	void OnLevelLoaded(); // Function AnimFramework.StreamableCinematic.OnLevelLoaded
	void Load(); // Function AnimFramework.StreamableCinematic.Load
	void GetOrWait(struct FDelegate& Callback); // Function AnimFramework.StreamableCinematic.GetOrWait
}; 



// Class AnimFramework.AnimNotify_CoverHighOut
// Size: 0x40(Inherited: 0x40) 
struct UAnimNotify_CoverHighOut : public UAnimNotify_WithAudioSettings
{

}; 



// Class AnimFramework.AnimNotify_WithAudioSettings
// Size: 0x40(Inherited: 0x38) 
struct UAnimNotify_WithAudioSettings : public UAnimNotify
{
	float VolumeMultiplier;  // 0x38(0x4)
	float PitchMultiplier;  // 0x3C(0x4)

}; 



// Class AnimFramework.AnimNotify_Foot
// Size: 0x60(Inherited: 0x40) 
struct UAnimNotify_Foot : public UAnimNotify_WithAudioSettings
{
	char pad_64[4];  // 0x40(0x4)
	struct FName BoneSocket;  // 0x44(0x8)
	struct FVector FXScale;  // 0x4C(0xC)
	float TraceDistance;  // 0x58(0x4)
	char EAxis LocalUp;  // 0x5C(0x1)
	char pad_93_1 : 7;  // 0x5D(0x1)
	bool bCallBPFunction : 1;  // 0x5D(0x1)
	char pad_94[2];  // 0x5E(0x2)

}; 



// Class AnimFramework.CharacterEffectsInterface
// Size: 0x28(Inherited: 0x28) 
struct UCharacterEffectsInterface : public UInterface
{

}; 



// Class AnimFramework.AnimNotify_LeftFootDown
// Size: 0x60(Inherited: 0x60) 
struct UAnimNotify_LeftFootDown : public UAnimNotify_Foot
{

}; 



// Class AnimFramework.CinematicContainerActor
// Size: 0x328(Inherited: 0x320) 
struct ACinematicContainerActor : public AActor
{
	struct ULevelSequence* Sequence;  // 0x320(0x8)

}; 



// Class AnimFramework.AnimNotify_BodyMove_Base
// Size: 0x40(Inherited: 0x40) 
struct UAnimNotify_BodyMove_Base : public UAnimNotify_WithAudioSettings
{

}; 



// Class AnimFramework.AnimNotify_LeftFootUp
// Size: 0x60(Inherited: 0x60) 
struct UAnimNotify_LeftFootUp : public UAnimNotify_Foot
{

}; 



// Class AnimFramework.AnimNotify_RightFootDown
// Size: 0x60(Inherited: 0x60) 
struct UAnimNotify_RightFootDown : public UAnimNotify_Foot
{

}; 



// Class AnimFramework.AnimNotify_CoverHighIn
// Size: 0x40(Inherited: 0x40) 
struct UAnimNotify_CoverHighIn : public UAnimNotify_WithAudioSettings
{

}; 



// Class AnimFramework.AnimNotify_RightFootUp
// Size: 0x60(Inherited: 0x60) 
struct UAnimNotify_RightFootUp : public UAnimNotify_Foot
{

}; 



// Class AnimFramework.AnimNotify_CoverLowIn
// Size: 0x40(Inherited: 0x40) 
struct UAnimNotify_CoverLowIn : public UAnimNotify_WithAudioSettings
{

}; 



// Class AnimFramework.AnimNotify_Roll
// Size: 0x40(Inherited: 0x40) 
struct UAnimNotify_Roll : public UAnimNotify_WithAudioSettings
{

}; 



// Class AnimFramework.AnimNotify_JumpOverObstacle
// Size: 0x48(Inherited: 0x40) 
struct UAnimNotify_JumpOverObstacle : public UAnimNotify_WithAudioSettings
{
	struct FName BoneSocket;  // 0x40(0x8)

}; 



// Class AnimFramework.AnimNotify_MeleeSwing
// Size: 0x40(Inherited: 0x40) 
struct UAnimNotify_MeleeSwing : public UAnimNotify_WithAudioSettings
{

}; 



// Class AnimFramework.AnimNotify_BodyMove_Medium
// Size: 0x48(Inherited: 0x48) 
struct UAnimNotify_BodyMove_Medium : public UAnimNotify_BodyMove_Base_WithHiddenValue
{

}; 



// Class AnimFramework.AnimNotify_Bodyfall
// Size: 0x48(Inherited: 0x40) 
struct UAnimNotify_Bodyfall : public UAnimNotify_WithAudioSettings
{
	struct FName BoneSocket;  // 0x40(0x8)

}; 



// Class AnimFramework.AnimNotify_CustomAudio
// Size: 0x58(Inherited: 0x40) 
struct UAnimNotify_CustomAudio : public UAnimNotify_WithAudioSettings
{
	struct FName NotifyName;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool bReactsToSurface : 1;  // 0x48(0x1)
	char pad_73[3];  // 0x49(0x3)
	struct FName BoneSocket;  // 0x4C(0x8)
	char EAxis LocalUp;  // 0x54(0x1)
	char pad_85[3];  // 0x55(0x3)

}; 



// Class AnimFramework.AnimNotify_BodyMove_Slow
// Size: 0x48(Inherited: 0x48) 
struct UAnimNotify_BodyMove_Slow : public UAnimNotify_BodyMove_Base_WithHiddenValue
{

}; 



// Class AnimFramework.AnimNotify_BodyMove_Base_WithHiddenValue
// Size: 0x48(Inherited: 0x40) 
struct UAnimNotify_BodyMove_Base_WithHiddenValue : public UAnimNotify_BodyMove_Base
{
	char pad_64[8];  // 0x40(0x8)

}; 



// Class AnimFramework.AnimNotify_BodyMove
// Size: 0x48(Inherited: 0x40) 
struct UAnimNotify_BodyMove : public UAnimNotify_BodyMove_Base
{
	uint8_t  MoveVelocityType;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)

}; 



// Class AnimFramework.AnimNotify_BodyMove_Fast
// Size: 0x48(Inherited: 0x48) 
struct UAnimNotify_BodyMove_Fast : public UAnimNotify_BodyMove_Base_WithHiddenValue
{

}; 



// Class AnimFramework.FWAnimNotifyState_EnableRagdoll
// Size: 0x50(Inherited: 0x38) 
struct UFWAnimNotifyState_EnableRagdoll : public UAnimNotifyState
{
	struct TArray<struct FName> BoneNames;  // 0x38(0x10)
	float TransitionTime;  // 0x48(0x4)
	char pad_76[4];  // 0x4C(0x4)

}; 



// Class AnimFramework.AnimNotifyState_SpawnCameraAndForceFeedbackEffects
// Size: 0xA0(Inherited: 0x38) 
struct UAnimNotifyState_SpawnCameraAndForceFeedbackEffects : public UAnimNotifyState
{
	struct TSoftObjectPtr<UForceFeedbackEffect> ForceFeedbackEffect;  // 0x38(0x28)
	struct TSoftObjectPtr<UForceFeedbackAttenuation> ForceFeedbackAttenuation;  // 0x60(0x28)
	char pad_136_1 : 7;  // 0x88(0x1)
	bool bLoopForceFeedback : 1;  // 0x88(0x1)
	char pad_137[7];  // 0x89(0x7)
	UCameraShake* CameraShakeEffect;  // 0x90(0x8)
	float Radius;  // 0x98(0x4)
	char pad_156_1 : 7;  // 0x9C(0x1)
	bool bOrientShakeTowardsEpicenter : 1;  // 0x9C(0x1)
	char pad_157[3];  // 0x9D(0x3)

}; 



// Class AnimFramework.CharacterEffectsSystemInterface
// Size: 0x28(Inherited: 0x28) 
struct UCharacterEffectsSystemInterface : public UInterface
{

}; 



// Class AnimFramework.FWAnimNotify_StartRagdoll
// Size: 0x40(Inherited: 0x38) 
struct UFWAnimNotify_StartRagdoll : public UAnimNotify
{
	float TransitionTime;  // 0x38(0x4)
	char pad_60[4];  // 0x3C(0x4)

}; 



// Class AnimFramework.FWAnimNotifyState_PlaySound
// Size: 0x68(Inherited: 0x38) 
struct UFWAnimNotifyState_PlaySound : public UAnimNotifyState
{
	struct USoundBase* Sound;  // 0x38(0x8)
	float VolumeMultiplier;  // 0x40(0x4)
	float PitchMultiplier;  // 0x44(0x4)
	float FadeInTime;  // 0x48(0x4)
	float FadeInVolume;  // 0x4C(0x4)
	float FadeOutTime;  // 0x50(0x4)
	float FadeOutVolume;  // 0x54(0x4)
	struct FName AttachName;  // 0x58(0x8)
	struct UAudioComponent* PlayingSoundComponent;  // 0x60(0x8)

}; 



// Class AnimFramework.AnimFrameworkBlueprintLibrary
// Size: 0x28(Inherited: 0x28) 
struct UAnimFrameworkBlueprintLibrary : public UBlueprintFunctionLibrary
{

	struct UStreamableCinematic* CreateStreamableCinematicSequence(struct FName CinematicLevelName); // Function AnimFramework.AnimFrameworkBlueprintLibrary.CreateStreamableCinematicSequence
}; 



