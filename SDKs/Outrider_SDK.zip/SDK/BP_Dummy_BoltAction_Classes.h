#pragma once 
#include <BP_Dummy_BoltAction_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Dummy_BoltAction.BP_Dummy_BoltAction_C
// Size: 0x1F90(Inherited: 0x1F90) 
struct ABP_Dummy_BoltAction_C : public AMadRifle
{

}; 



