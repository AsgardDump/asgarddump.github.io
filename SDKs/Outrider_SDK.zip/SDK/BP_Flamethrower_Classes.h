#pragma once 
#include <BP_Flamethrower_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Flamethrower.BP_Flamethrower_C
// Size: 0x1FA0(Inherited: 0x1FA0) 
struct ABP_Flamethrower_C : public AMadFlamethrower
{

}; 



