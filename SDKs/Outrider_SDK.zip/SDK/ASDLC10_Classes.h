#pragma once 
#include <ASDLC10_Structs.h>
 
 
 
// BlueprintGeneratedClass ASDLC10.ASDLC10_C
// Size: 0x28(Inherited: 0x28) 
struct UASDLC10_C : public UMadSkillDataObject
{

	float GetSecondaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function ASDLC10.ASDLC10_C.GetSecondaryExtraData
	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function ASDLC10.ASDLC10_C.GetPrimaryExtraData
}; 



