#pragma once 
#include <AN39_Structs.h>
 
 
 
// BlueprintGeneratedClass AN39.AN39_C
// Size: 0x28(Inherited: 0x28) 
struct UAN39_C : public UMadSkillDataObject
{

	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function AN39.AN39_C.GetPrimaryExtraData
}; 



