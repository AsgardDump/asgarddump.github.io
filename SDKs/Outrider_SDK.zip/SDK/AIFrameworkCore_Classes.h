#pragma once 
#include <AIFrameworkCore_Structs.h>
 
 
 
// Class AIFrameworkCore.FWNavArea_Jump
// Size: 0x48(Inherited: 0x48) 
struct UFWNavArea_Jump : public UNavArea
{

}; 



// Class AIFrameworkCore.FWNavArea_DisabledMantleOverCover
// Size: 0x48(Inherited: 0x48) 
struct UFWNavArea_DisabledMantleOverCover : public UNavArea
{

}; 



// Class AIFrameworkCore.FWNavArea_MantleOverCover
// Size: 0x48(Inherited: 0x48) 
struct UFWNavArea_MantleOverCover : public UNavArea
{

}; 



// Class AIFrameworkCore.FWNavArea_ClimbUp
// Size: 0x48(Inherited: 0x48) 
struct UFWNavArea_ClimbUp : public UNavArea
{

}; 



// Class AIFrameworkCore.FWNavArea_Unwalkable
// Size: 0x48(Inherited: 0x48) 
struct UFWNavArea_Unwalkable : public UNavArea
{

}; 



