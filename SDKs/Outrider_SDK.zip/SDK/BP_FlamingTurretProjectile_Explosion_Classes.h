#pragma once 
#include <BP_FlamingTurretProjectile_Explosion_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_FlamingTurretProjectile_Explosion.BP_FlamingTurretProjectile_Explosion_C
// Size: 0x470(Inherited: 0x470) 
struct ABP_FlamingTurretProjectile_Explosion_C : public AExplosionEffect
{

}; 



