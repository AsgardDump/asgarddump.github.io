#pragma once 
#include <AshBlast_ConsumeFire_DescriptionCalculation_Structs.h>
 
 
 
// BlueprintGeneratedClass AshBlast_ConsumeFire_DescriptionCalculation.AshBlast_ConsumeFire_DescriptionCalculation_C
// Size: 0x28(Inherited: 0x28) 
struct UAshBlast_ConsumeFire_DescriptionCalculation_C : public UMadSkillDataObject
{

	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function AshBlast_ConsumeFire_DescriptionCalculation.AshBlast_ConsumeFire_DescriptionCalculation_C.GetPrimaryExtraData
}; 



