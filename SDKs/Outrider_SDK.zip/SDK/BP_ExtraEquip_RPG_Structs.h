#pragma once 
#include "SDK.h" 
 
 
// Function BP_ExtraEquip_RPG.BP_ExtraEquip_RPG_C.ExecuteUbergraph_BP_ExtraEquip_RPG
// Size: 0x4(Inherited: 0x0) 
struct FExecuteUbergraph_BP_ExtraEquip_RPG
{
	int32_t EntryPoint;  // 0x0(0x4)

}; 
