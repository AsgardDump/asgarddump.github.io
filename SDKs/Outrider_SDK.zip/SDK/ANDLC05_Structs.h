#pragma once 
#include "SDK.h" 
 
 
// Function ANDLC05.ANDLC05_C.GetPrimaryExtraData
// Size: 0x19(Inherited: 0x10) 
struct FGetPrimaryExtraData : public FGetPrimaryExtraData
{
	struct AMadBaseCharacter* MadInstigatorCharacter;  // 0x0(0x8)
	int32_t ItemLevel;  // 0x8(0x4)
	float ReturnValue;  // 0xC(0x4)
	char EEvaluateCurveTableResult CallFunc_EvaluateCurveTableRow_OutResult;  // 0x10(0x1)
	float CallFunc_EvaluateCurveTableRow_OutXY;  // 0x14(0x4)
	char pad_37_1 : 7;  // 0x25(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x18(0x1)

}; 
