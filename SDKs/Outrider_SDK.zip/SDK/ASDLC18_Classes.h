#pragma once 
#include <ASDLC18_Structs.h>
 
 
 
// BlueprintGeneratedClass ASDLC18.ASDLC18_C
// Size: 0x28(Inherited: 0x28) 
struct UASDLC18_C : public UMadSkillDataObject
{

	float GetTertiaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function ASDLC18.ASDLC18_C.GetTertiaryExtraData
	float GetSecondaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function ASDLC18.ASDLC18_C.GetSecondaryExtraData
	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function ASDLC18.ASDLC18_C.GetPrimaryExtraData
}; 



