#pragma once 
#include <ATDLC10_Structs.h>
 
 
 
// BlueprintGeneratedClass ATDLC10.ATDLC10_C
// Size: 0x28(Inherited: 0x28) 
struct UATDLC10_C : public UMadSkillDataObject
{

	float GetSecondaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function ATDLC10.ATDLC10_C.GetSecondaryExtraData
	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function ATDLC10.ATDLC10_C.GetPrimaryExtraData
}; 



