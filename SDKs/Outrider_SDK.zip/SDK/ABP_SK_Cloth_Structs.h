#pragma once 
#include "SDK.h" 
 
 
// Function ABP_SK_Cloth.ABP_SK_Cloth_C.ExecuteUbergraph_ABP_SK_Cloth
// Size: 0x3C(Inherited: 0x0) 
struct FExecuteUbergraph_ABP_SK_Cloth
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	float CallFunc_GetInstanceCurrentStateElapsedTime_ReturnValue;  // 0x8(0x4)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue : 1;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)
	struct AActor* CallFunc_Array_Get_Item;  // 0x10(0x8)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x18(0xC)
	char pad_36_1 : 7;  // 0x24(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x24(0x1)
	char pad_37_1 : 7;  // 0x25(0x1)
	bool CallFunc_Array_IsValidIndex_ReturnValue : 1;  // 0x25(0x1)
	char pad_38[2];  // 0x26(0x2)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x28(0x4)
	char pad_44_1 : 7;  // 0x2C(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue : 1;  // 0x2C(0x1)
	char pad_45_1 : 7;  // 0x2D(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue_2 : 1;  // 0x2D(0x1)
	char pad_46[2];  // 0x2E(0x2)
	struct FVector CallFunc_Add_VectorVector_ReturnValue;  // 0x30(0xC)

}; 
// Function ABP_SK_Cloth.ABP_SK_Cloth_C.AnimGraph
// Size: 0x10(Inherited: 0x0) 
struct FAnimGraph
{
	struct FPoseLink AnimGraph;  // 0x0(0x10)

}; 
