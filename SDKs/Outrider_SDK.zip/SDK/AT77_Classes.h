#pragma once 
#include <AT77_Structs.h>
 
 
 
// BlueprintGeneratedClass AT77.AT77_C
// Size: 0x28(Inherited: 0x28) 
struct UAT77_C : public UMadSkillDataObject
{

	float GetTertiaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function AT77.AT77_C.GetTertiaryExtraData
	float GetSecondaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function AT77.AT77_C.GetSecondaryExtraData
	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function AT77.AT77_C.GetPrimaryExtraData
}; 



