#pragma once 
#include <AS00_Structs.h>
 
 
 
// BlueprintGeneratedClass AS00.AS00_C
// Size: 0x28(Inherited: 0x28) 
struct UAS00_C : public UMadSkillDataObject
{

	float GetCalculatedDamage(struct AMadBaseCharacter* MadInstigatorCharacter); // Function AS00.AS00_C.GetCalculatedDamage
	float GetTertiaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function AS00.AS00_C.GetTertiaryExtraData
	float GetSecondaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function AS00.AS00_C.GetSecondaryExtraData
	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function AS00.AS00_C.GetPrimaryExtraData
}; 



