#pragma once 
#include <AS71_Structs.h>
 
 
 
// BlueprintGeneratedClass AS71.AS71_C
// Size: 0x28(Inherited: 0x28) 
struct UAS71_C : public UMadSkillDataObject
{

	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function AS71.AS71_C.GetPrimaryExtraData
}; 



