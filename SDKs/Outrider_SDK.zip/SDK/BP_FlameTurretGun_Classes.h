#pragma once 
#include <BP_FlameTurretGun_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_FlameTurretGun.BP_FlameTurretGun_C
// Size: 0x1FA0(Inherited: 0x1FA0) 
struct ABP_FlameTurretGun_C : public AMadFlamethrower
{

}; 



