#pragma once 
#include <AT12_Structs.h>
 
 
 
// BlueprintGeneratedClass AT12.AT12_C
// Size: 0x28(Inherited: 0x28) 
struct UAT12_C : public UMadSkillDataObject
{

	float GetSecondaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function AT12.AT12_C.GetSecondaryExtraData
	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function AT12.AT12_C.GetPrimaryExtraData
}; 



