#pragma once 
#include <BorrowedTime_RandomSkillCooldown_Calculation_Structs.h>
 
 
 
// BlueprintGeneratedClass BorrowedTime_RandomSkillCooldown_Calculation.BorrowedTime_RandomSkillCooldown_Calculation_C
// Size: 0x28(Inherited: 0x28) 
struct UBorrowedTime_RandomSkillCooldown_Calculation_C : public UMadSkillDataObject
{

	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function BorrowedTime_RandomSkillCooldown_Calculation.BorrowedTime_RandomSkillCooldown_Calculation_C.GetPrimaryExtraData
}; 



