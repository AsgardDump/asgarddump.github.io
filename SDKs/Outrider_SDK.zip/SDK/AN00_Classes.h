#pragma once 
#include <AN00_Structs.h>
 
 
 
// BlueprintGeneratedClass AN00.AN00_C
// Size: 0x28(Inherited: 0x28) 
struct UAN00_C : public UMadSkillDataObject
{

	float GetCalculatedDamage(struct AMadBaseCharacter* MadInstigatorCharacter); // Function AN00.AN00_C.GetCalculatedDamage
	float GetTertiaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function AN00.AN00_C.GetTertiaryExtraData
	float GetSecondaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function AN00.AN00_C.GetSecondaryExtraData
	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function AN00.AN00_C.GetPrimaryExtraData
}; 



