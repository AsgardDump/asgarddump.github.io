#pragma once 
#include <BP_Dummy_Minigun_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Dummy_Minigun.BP_Dummy_Minigun_C
// Size: 0x1F90(Inherited: 0x1F90) 
struct ABP_Dummy_Minigun_C : public AMadHeavyWeapon
{

}; 



