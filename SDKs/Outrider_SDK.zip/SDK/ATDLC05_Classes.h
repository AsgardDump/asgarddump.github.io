#pragma once 
#include <ATDLC05_Structs.h>
 
 
 
// BlueprintGeneratedClass ATDLC05.ATDLC05_C
// Size: 0x28(Inherited: 0x28) 
struct UATDLC05_C : public UMadSkillDataObject
{

	float GetSecondaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function ATDLC05.ATDLC05_C.GetSecondaryExtraData
	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function ATDLC05.ATDLC05_C.GetPrimaryExtraData
}; 



