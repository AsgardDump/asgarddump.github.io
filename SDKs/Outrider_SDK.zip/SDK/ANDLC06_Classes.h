#pragma once 
#include <ANDLC06_Structs.h>
 
 
 
// BlueprintGeneratedClass ANDLC06.ANDLC06_C
// Size: 0x28(Inherited: 0x28) 
struct UANDLC06_C : public UMadSkillDataObject
{

	float GetTertiaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function ANDLC06.ANDLC06_C.GetTertiaryExtraData
	float GetSecondaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function ANDLC06.ANDLC06_C.GetSecondaryExtraData
	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function ANDLC06.ANDLC06_C.GetPrimaryExtraData
}; 



