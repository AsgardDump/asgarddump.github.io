#pragma once 
#include <ApBonusTOFirepower_Structs.h>
 
 
 
// BlueprintGeneratedClass ApBonusTOFirepower.ApBonusTOFirepower_C
// Size: 0x28(Inherited: 0x28) 
struct UApBonusTOFirepower_C : public UMadSkillDataObject
{

	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function ApBonusTOFirepower.ApBonusTOFirepower_C.GetPrimaryExtraData
}; 



