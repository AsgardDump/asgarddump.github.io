#pragma once 
#include <BP_Abilities_RpgExplosionBigger_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Abilities_RpgExplosionBigger.BP_Abilities_RpgExplosionBigger_C
// Size: 0x470(Inherited: 0x470) 
struct ABP_Abilities_RpgExplosionBigger_C : public AExplosionEffect
{

}; 



