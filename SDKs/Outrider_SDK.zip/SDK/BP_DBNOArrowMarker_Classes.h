#pragma once 
#include <BP_DBNOArrowMarker_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_DBNOArrowMarker.BP_DBNOArrowMarker_C
// Size: 0x340(Inherited: 0x320) 
struct ABP_DBNOArrowMarker_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x320(0x8)
	struct UBase3DWidgetComponent* OffscreenIndicator;  // 0x328(0x8)
	struct UBase3DWidgetComponent* ArrowIndicator;  // 0x330(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x338(0x8)

	void ReceiveBeginPlay(); // Function BP_DBNOArrowMarker.BP_DBNOArrowMarker_C.ReceiveBeginPlay
	void ExecuteUbergraph_BP_DBNOArrowMarker(int32_t EntryPoint); // Function BP_DBNOArrowMarker.BP_DBNOArrowMarker_C.ExecuteUbergraph_BP_DBNOArrowMarker
}; 



