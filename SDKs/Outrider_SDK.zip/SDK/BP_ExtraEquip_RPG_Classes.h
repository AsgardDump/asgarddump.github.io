#pragma once 
#include <BP_ExtraEquip_RPG_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_ExtraEquip_RPG.BP_ExtraEquip_RPG_C
// Size: 0x3B0(Inherited: 0x3A8) 
struct ABP_ExtraEquip_RPG_C : public ASkeletalMeshActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x3A8(0x8)

	void ReceiveBeginPlay(); // Function BP_ExtraEquip_RPG.BP_ExtraEquip_RPG_C.ReceiveBeginPlay
	void ExecuteUbergraph_BP_ExtraEquip_RPG(int32_t EntryPoint); // Function BP_ExtraEquip_RPG.BP_ExtraEquip_RPG_C.ExecuteUbergraph_BP_ExtraEquip_RPG
}; 



