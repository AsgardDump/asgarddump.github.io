#pragma once 
#include <BlackHole_AddDamage_DescriptionCalculation_Structs.h>
 
 
 
// BlueprintGeneratedClass BlackHole_AddDamage_DescriptionCalculation.BlackHole_AddDamage_DescriptionCalculation_C
// Size: 0x28(Inherited: 0x28) 
struct UBlackHole_AddDamage_DescriptionCalculation_C : public UMadSkillDataObject
{

	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function BlackHole_AddDamage_DescriptionCalculation.BlackHole_AddDamage_DescriptionCalculation_C.GetPrimaryExtraData
}; 



