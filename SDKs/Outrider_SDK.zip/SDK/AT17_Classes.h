#pragma once 
#include <AT17_Structs.h>
 
 
 
// BlueprintGeneratedClass AT17.AT17_C
// Size: 0x28(Inherited: 0x28) 
struct UAT17_C : public UMadSkillDataObject
{

	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function AT17.AT17_C.GetPrimaryExtraData
}; 



