#pragma once 
#include <AT51_Structs.h>
 
 
 
// BlueprintGeneratedClass AT51.AT51_C
// Size: 0x28(Inherited: 0x28) 
struct UAT51_C : public UMadSkillDataObject
{

	float GetSecondaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function AT51.AT51_C.GetSecondaryExtraData
	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function AT51.AT51_C.GetPrimaryExtraData
}; 



