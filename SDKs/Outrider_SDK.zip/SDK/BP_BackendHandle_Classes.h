#pragma once 
#include <BP_BackendHandle_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_BackendHandle.BP_BackendHandle_C
// Size: 0x148(Inherited: 0x148) 
struct UBP_BackendHandle_C : public UMadBackendHandle
{

}; 



