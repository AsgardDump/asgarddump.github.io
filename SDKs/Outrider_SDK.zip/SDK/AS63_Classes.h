#pragma once 
#include <AS63_Structs.h>
 
 
 
// BlueprintGeneratedClass AS63.AS63_C
// Size: 0x28(Inherited: 0x28) 
struct UAS63_C : public UMadSkillDataObject
{

	float GetSecondaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function AS63.AS63_C.GetSecondaryExtraData
	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function AS63.AS63_C.GetPrimaryExtraData
}; 



