#pragma once 
#include <AN62_Structs.h>
 
 
 
// BlueprintGeneratedClass AN62.AN62_C
// Size: 0x28(Inherited: 0x28) 
struct UAN62_C : public UMadSkillDataObject
{

	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function AN62.AN62_C.GetPrimaryExtraData
}; 



