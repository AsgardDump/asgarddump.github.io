#pragma once 
#include <BorrowedTime_CDReduction_DescriptionCalculation_Structs.h>
 
 
 
// BlueprintGeneratedClass BorrowedTime_CDReduction_DescriptionCalculation.BorrowedTime_CDReduction_DescriptionCalculation_C
// Size: 0x28(Inherited: 0x28) 
struct UBorrowedTime_CDReduction_DescriptionCalculation_C : public UMadSkillDataObject
{

	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function BorrowedTime_CDReduction_DescriptionCalculation.BorrowedTime_CDReduction_DescriptionCalculation_C.GetPrimaryExtraData
}; 



