#pragma once 
#include <BP_GravityJumpExplosion_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_GravityJumpExplosion.BP_GravityJumpExplosion_C
// Size: 0x1E0(Inherited: 0x1E0) 
struct UBP_GravityJumpExplosion_C : public UMadExplosionTemplate
{

}; 



