#pragma once 
#include <BP_BannerRoom_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_BannerRoom.BP_BannerRoom_C
// Size: 0x718(Inherited: 0x6F0) 
struct ABP_BannerRoom_C : public AMadTheRoom
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x6F0(0x8)
	struct USpotLightComponent* SpotLight1;  // 0x6F8(0x8)
	struct UStaticMeshComponent* SM_Base_Lite;  // 0x700(0x8)
	struct UPointLightComponent* PointLight;  // 0x708(0x8)
	struct UPostProcessComponent* PostProcess;  // 0x710(0x8)

	void OnModeChanged(uint8_t  NewMode); // Function BP_BannerRoom.BP_BannerRoom_C.OnModeChanged
	void OnLeaveTheRoom(uint8_t  NewMode); // Function BP_BannerRoom.BP_BannerRoom_C.OnLeaveTheRoom
	void ChangeCamera(struct UCameraComponent* Camera); // Function BP_BannerRoom.BP_BannerRoom_C.ChangeCamera
	void ExecuteUbergraph_BP_BannerRoom(int32_t EntryPoint); // Function BP_BannerRoom.BP_BannerRoom_C.ExecuteUbergraph_BP_BannerRoom
}; 



