#pragma once 
#include <BP_Dummy_PumpAction_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Dummy_PumpAction.BP_Dummy_PumpAction_C
// Size: 0x2000(Inherited: 0x2000) 
struct ABP_Dummy_PumpAction_C : public AMadShotgun
{

}; 



