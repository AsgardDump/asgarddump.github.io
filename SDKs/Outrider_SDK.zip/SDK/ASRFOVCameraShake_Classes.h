#pragma once 
#include <ASRFOVCameraShake_Structs.h>
 
 
 
// BlueprintGeneratedClass ASRFOVCameraShake.ASRFOVCameraShake_C
// Size: 0x160(Inherited: 0x160) 
struct UASRFOVCameraShake_C : public UCameraShake
{

}; 



