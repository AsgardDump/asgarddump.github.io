#pragma once 
#include <ATDLC06_Structs.h>
 
 
 
// BlueprintGeneratedClass ATDLC06.ATDLC06_C
// Size: 0x28(Inherited: 0x28) 
struct UATDLC06_C : public UMadSkillDataObject
{

	float GetQuaternaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function ATDLC06.ATDLC06_C.GetQuaternaryExtraData
	float GetTertiaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function ATDLC06.ATDLC06_C.GetTertiaryExtraData
	float GetSecondaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function ATDLC06.ATDLC06_C.GetSecondaryExtraData
	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function ATDLC06.ATDLC06_C.GetPrimaryExtraData
}; 



