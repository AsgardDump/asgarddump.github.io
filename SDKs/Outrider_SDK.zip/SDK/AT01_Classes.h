#pragma once 
#include <AT01_Structs.h>
 
 
 
// BlueprintGeneratedClass AT01.AT01_C
// Size: 0x28(Inherited: 0x28) 
struct UAT01_C : public UMadSkillDataObject
{

	float GetTertiaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function AT01.AT01_C.GetTertiaryExtraData
	float GetSecondaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function AT01.AT01_C.GetSecondaryExtraData
	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function AT01.AT01_C.GetPrimaryExtraData
}; 



