#pragma once 
#include <AS78_Structs.h>
 
 
 
// BlueprintGeneratedClass AS78.AS78_C
// Size: 0x28(Inherited: 0x28) 
struct UAS78_C : public UMadSkillDataObject
{

	float GetSecondaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function AS78.AS78_C.GetSecondaryExtraData
	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function AS78.AS78_C.GetPrimaryExtraData
}; 



