#pragma once 
#include <ANDLC13_Structs.h>
 
 
 
// BlueprintGeneratedClass ANDLC13.ANDLC13_C
// Size: 0x28(Inherited: 0x28) 
struct UANDLC13_C : public UMadSkillDataObject
{

	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function ANDLC13.ANDLC13_C.GetPrimaryExtraData
}; 



