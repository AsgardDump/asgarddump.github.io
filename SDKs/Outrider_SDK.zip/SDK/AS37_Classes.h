#pragma once 
#include <AS37_Structs.h>
 
 
 
// BlueprintGeneratedClass AS37.AS37_C
// Size: 0x28(Inherited: 0x28) 
struct UAS37_C : public UMadSkillDataObject
{

	float GetSecondaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function AS37.AS37_C.GetSecondaryExtraData
	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function AS37.AS37_C.GetPrimaryExtraData
}; 



