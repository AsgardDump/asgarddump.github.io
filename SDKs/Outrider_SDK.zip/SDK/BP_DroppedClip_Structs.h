#pragma once 
#include "SDK.h" 
 
 
// Function BP_DroppedClip.BP_DroppedClip_C.ExecuteUbergraph_BP_DroppedClip
// Size: 0x1D(Inherited: 0x0) 
struct FExecuteUbergraph_BP_DroppedClip
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Temp_bool_Has_Been_Initd_Variable : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool Temp_bool_IsClosed_Variable : 1;  // 0x5(0x1)
	char pad_6[2];  // 0x6(0x2)
	struct UPrimitiveComponent* K2Node_Event_OtherComp;  // 0x8(0x8)
	struct FVector K2Node_Event_HitLocation;  // 0x10(0xC)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool CallFunc_NotEqual_ByteByte_ReturnValue : 1;  // 0x1C(0x1)

}; 
// Function BP_DroppedClip.BP_DroppedClip_C.ReceiveHit
// Size: 0xD0(Inherited: 0xD0) 
struct FReceiveHit : public FReceiveHit
{
	struct UPrimitiveComponent* MyComp;  // 0x0(0x8)
	struct AActor* Other;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	char pad_232_1 : 7;  // 0xE8(0x1)
	bool bSelfMoved : 1;  // 0x18(0x1)
	struct FVector HitLocation;  // 0x1C(0xC)
	struct FVector HitNormal;  // 0x28(0xC)
	struct FVector NormalImpulse;  // 0x34(0xC)
	struct FHitResult Hit;  // 0x40(0x90)

}; 
