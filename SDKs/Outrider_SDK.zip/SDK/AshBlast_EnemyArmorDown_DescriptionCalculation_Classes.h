#pragma once 
#include <AshBlast_EnemyArmorDown_DescriptionCalculation_Structs.h>
 
 
 
// BlueprintGeneratedClass AshBlast_EnemyArmorDown_DescriptionCalculation.AshBlast_EnemyArmorDown_DescriptionCalculation_C
// Size: 0x28(Inherited: 0x28) 
struct UAshBlast_EnemyArmorDown_DescriptionCalculation_C : public UMadSkillDataObject
{

	float GetSecondaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function AshBlast_EnemyArmorDown_DescriptionCalculation.AshBlast_EnemyArmorDown_DescriptionCalculation_C.GetSecondaryExtraData
	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function AshBlast_EnemyArmorDown_DescriptionCalculation.AshBlast_EnemyArmorDown_DescriptionCalculation_C.GetPrimaryExtraData
}; 



