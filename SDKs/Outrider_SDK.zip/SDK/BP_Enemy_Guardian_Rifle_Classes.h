#pragma once 
#include <BP_Enemy_Guardian_Rifle_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Enemy_Guardian_Rifle.BP_Enemy_Guardian_Rifle_C
// Size: 0x1F90(Inherited: 0x1F90) 
struct ABP_Enemy_Guardian_Rifle_C : public AMadAssaultWeapon
{

}; 



