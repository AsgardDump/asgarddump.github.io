#pragma once 
#include <BleedDmgType_Structs.h>
 
 
 
// BlueprintGeneratedClass BleedDmgType.BleedDmgType_C
// Size: 0x2C8(Inherited: 0x2C8) 
struct UBleedDmgType_C : public UMadDamageType
{

}; 



