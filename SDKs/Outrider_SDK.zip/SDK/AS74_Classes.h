#pragma once 
#include <AS74_Structs.h>
 
 
 
// BlueprintGeneratedClass AS74.AS74_C
// Size: 0x28(Inherited: 0x28) 
struct UAS74_C : public UMadSkillDataObject
{

	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function AS74.AS74_C.GetPrimaryExtraData
}; 



