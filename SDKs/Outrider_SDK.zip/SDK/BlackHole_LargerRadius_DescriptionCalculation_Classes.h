#pragma once 
#include <BlackHole_LargerRadius_DescriptionCalculation_Structs.h>
 
 
 
// BlueprintGeneratedClass BlackHole_LargerRadius_DescriptionCalculation.BlackHole_LargerRadius_DescriptionCalculation_C
// Size: 0x28(Inherited: 0x28) 
struct UBlackHole_LargerRadius_DescriptionCalculation_C : public UMadSkillDataObject
{

	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function BlackHole_LargerRadius_DescriptionCalculation.BlackHole_LargerRadius_DescriptionCalculation_C.GetPrimaryExtraData
}; 



