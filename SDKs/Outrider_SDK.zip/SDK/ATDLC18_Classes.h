#pragma once 
#include <ATDLC18_Structs.h>
 
 
 
// BlueprintGeneratedClass ATDLC18.ATDLC18_C
// Size: 0x28(Inherited: 0x28) 
struct UATDLC18_C : public UMadSkillDataObject
{

	float GetSecondaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function ATDLC18.ATDLC18_C.GetSecondaryExtraData
	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function ATDLC18.ATDLC18_C.GetPrimaryExtraData
}; 



