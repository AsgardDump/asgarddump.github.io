#pragma once 
#include <ANDLC15_Structs.h>
 
 
 
// BlueprintGeneratedClass ANDLC15.ANDLC15_C
// Size: 0x28(Inherited: 0x28) 
struct UANDLC15_C : public UMadSkillDataObject
{

	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function ANDLC15.ANDLC15_C.GetPrimaryExtraData
}; 



