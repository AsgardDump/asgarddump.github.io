#pragma once 
#include <ANDLC04_Structs.h>
 
 
 
// BlueprintGeneratedClass ANDLC04.ANDLC04_C
// Size: 0x28(Inherited: 0x28) 
struct UANDLC04_C : public UMadSkillDataObject
{

	float GetSecondaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function ANDLC04.ANDLC04_C.GetSecondaryExtraData
	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function ANDLC04.ANDLC04_C.GetPrimaryExtraData
}; 



