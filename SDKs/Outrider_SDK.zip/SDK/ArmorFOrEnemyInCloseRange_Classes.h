#pragma once 
#include <ArmorFOrEnemyInCloseRange_Structs.h>
 
 
 
// BlueprintGeneratedClass ArmorFOrEnemyInCloseRange.ArmorForEnemyInCloseRange_C
// Size: 0x28(Inherited: 0x28) 
struct UArmorForEnemyInCloseRange_C : public UMadSkillDataObject
{

	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function ArmorFOrEnemyInCloseRange.ArmorForEnemyInCloseRange_C.GetPrimaryExtraData
}; 



