#pragma once 
#include <AshTimeBonus_Structs.h>
 
 
 
// BlueprintGeneratedClass AshTimeBonus.AshTimeBonus_C
// Size: 0x28(Inherited: 0x28) 
struct UAshTimeBonus_C : public UMadSkillDataObject
{

	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function AshTimeBonus.AshTimeBonus_C.GetPrimaryExtraData
}; 



