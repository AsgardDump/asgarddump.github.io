#pragma once 
#include <AssassinDmgFromBehind_Structs.h>
 
 
 
// BlueprintGeneratedClass AssassinDmgFromBehind.AssassinDmgFromBehind_C
// Size: 0x28(Inherited: 0x28) 
struct UAssassinDmgFromBehind_C : public UMadSkillDataObject
{

	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function AssassinDmgFromBehind.AssassinDmgFromBehind_C.GetPrimaryExtraData
}; 



