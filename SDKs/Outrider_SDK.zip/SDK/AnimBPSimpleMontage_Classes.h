#pragma once 
#include <AnimBPSimpleMontage_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass AnimBPSimpleMontage.AnimBPSimpleMontage_C
// Size: 0xA78(Inherited: 0x3E0) 
struct UAnimBPSimpleMontage_C : public UMadAnimInstance_AntFarmSimple
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x3E0(0x8)
	struct FAnimNode_Root AnimGraphNode_Root;  // 0x3E8(0x30)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer;  // 0x418(0x78)
	struct FAnimNode_Slot AnimGraphNode_Slot_2;  // 0x490(0x60)
	struct FAnimNode_LayeredBoneBlend AnimGraphNode_LayeredBoneBlend;  // 0x4F0(0xC0)
	struct FAnimNode_Slot AnimGraphNode_Slot;  // 0x5B0(0x60)
	struct FAnimNode_RigLogic AnimGraphNode_RigLogic;  // 0x610(0xA0)
	struct FAnimNode_RefPose AnimGraphNode_LocalRefPose;  // 0x6B0(0x18)
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool;  // 0x6C8(0xA0)
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose;  // 0x768(0xB8)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_2;  // 0x820(0x28)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose;  // 0x848(0x28)
	struct FAnimNode_AimOffsetLookAt AnimGraphNode_AimOffsetLookAt;  // 0x870(0x1F0)
	struct UDNAContext* DNAC;  // 0xA60(0x8)
	struct UAnimSequenceBase* IdleAnimation;  // 0xA68(0x8)
	float L_Hand_AnimOffset_IKConstraintWeight;  // 0xA70(0x4)
	float R_Hand_AnimOffset_IKConstraintWeight;  // 0xA74(0x4)

	void AnimGraph(struct FPoseLink& AnimGraph); // Function AnimBPSimpleMontage.AnimBPSimpleMontage_C.AnimGraph
	void BlueprintBeginPlay(); // Function AnimBPSimpleMontage.AnimBPSimpleMontage_C.BlueprintBeginPlay
	void DNAContextChanged(); // Function AnimBPSimpleMontage.AnimBPSimpleMontage_C.DNAContextChanged
	void BlueprintInitializeAnimation(); // Function AnimBPSimpleMontage.AnimBPSimpleMontage_C.BlueprintInitializeAnimation
	void ExecuteUbergraph_AnimBPSimpleMontage(int32_t EntryPoint); // Function AnimBPSimpleMontage.AnimBPSimpleMontage_C.ExecuteUbergraph_AnimBPSimpleMontage
}; 



