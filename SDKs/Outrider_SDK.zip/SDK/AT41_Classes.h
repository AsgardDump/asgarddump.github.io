#pragma once 
#include <AT41_Structs.h>
 
 
 
// BlueprintGeneratedClass AT41.AT41_C
// Size: 0x28(Inherited: 0x28) 
struct UAT41_C : public UMadSkillDataObject
{

	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function AT41.AT41_C.GetPrimaryExtraData
}; 



