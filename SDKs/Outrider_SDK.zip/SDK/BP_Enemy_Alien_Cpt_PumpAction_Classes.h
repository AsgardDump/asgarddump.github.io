#pragma once 
#include <BP_Enemy_Alien_Cpt_PumpAction_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Enemy_Alien_Cpt_PumpAction.BP_Enemy_Alien_Cpt_PumpAction_C
// Size: 0x2000(Inherited: 0x2000) 
struct ABP_Enemy_Alien_Cpt_PumpAction_C : public AMadShotgun
{

}; 



