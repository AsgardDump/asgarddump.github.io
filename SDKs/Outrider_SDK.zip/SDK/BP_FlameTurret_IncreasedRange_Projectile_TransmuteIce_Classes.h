#pragma once 
#include <BP_FlameTurret_IncreasedRange_Projectile_TransmuteIce_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_FlameTurret_IncreasedRange_Projectile_TransmuteIce.BP_FlameTurret_IncreasedRange_Projectile_TransmuteIce_C
// Size: 0x608(Inherited: 0x600) 
struct ABP_FlameTurret_IncreasedRange_Projectile_TransmuteIce_C : public AMadProjectile
{
	struct UAudioComponent* ShotSFX;  // 0x600(0x8)

}; 



