#pragma once 
#include <BP_FlameTurret_IncreaseRange_TransmuteIce_Weapon_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_FlameTurret_IncreaseRange_TransmuteIce_Weapon.BP_FlameTurret_IncreaseRange_TransmuteIce_Weapon_C
// Size: 0x1FE0(Inherited: 0x1FE0) 
struct ABP_FlameTurret_IncreaseRange_TransmuteIce_Weapon_C : public AMadRPG
{

}; 



