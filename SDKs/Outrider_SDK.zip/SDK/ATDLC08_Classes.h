#pragma once 
#include <ATDLC08_Structs.h>
 
 
 
// BlueprintGeneratedClass ATDLC08.ATDLC08_C
// Size: 0x28(Inherited: 0x28) 
struct UATDLC08_C : public UMadSkillDataObject
{

	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function ATDLC08.ATDLC08_C.GetPrimaryExtraData
}; 



