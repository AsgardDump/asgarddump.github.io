#pragma once 
#include <BorrowedTime_DamageVsElites_Calculation_Structs.h>
 
 
 
// BlueprintGeneratedClass BorrowedTime_DamageVsElites_Calculation.BorrowedTime_DamageVsElites_Calculation_C
// Size: 0x28(Inherited: 0x28) 
struct UBorrowedTime_DamageVsElites_Calculation_C : public UMadSkillDataObject
{

	float GetTertiaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function BorrowedTime_DamageVsElites_Calculation.BorrowedTime_DamageVsElites_Calculation_C.GetTertiaryExtraData
	float GetSecondaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function BorrowedTime_DamageVsElites_Calculation.BorrowedTime_DamageVsElites_Calculation_C.GetSecondaryExtraData
	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function BorrowedTime_DamageVsElites_Calculation.BorrowedTime_DamageVsElites_Calculation_C.GetPrimaryExtraData
}; 



