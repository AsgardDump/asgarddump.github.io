#pragma once 
#include <AS51_Structs.h>
 
 
 
// BlueprintGeneratedClass AS51.AS51_C
// Size: 0x28(Inherited: 0x28) 
struct UAS51_C : public UMadSkillDataObject
{

	float GetSecondaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function AS51.AS51_C.GetSecondaryExtraData
	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function AS51.AS51_C.GetPrimaryExtraData
}; 



