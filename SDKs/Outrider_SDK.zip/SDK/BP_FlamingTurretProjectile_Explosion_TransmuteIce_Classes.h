#pragma once 
#include <BP_FlamingTurretProjectile_Explosion_TransmuteIce_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_FlamingTurretProjectile_Explosion_TransmuteIce.BP_FlamingTurretProjectile_Explosion_TransmuteIce_C
// Size: 0x470(Inherited: 0x470) 
struct ABP_FlamingTurretProjectile_Explosion_TransmuteIce_C : public AExplosionEffect
{

}; 



