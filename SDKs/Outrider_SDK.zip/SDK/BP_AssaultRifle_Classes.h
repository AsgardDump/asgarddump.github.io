#pragma once 
#include <BP_AssaultRifle_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_AssaultRifle.BP_AssaultRifle_C
// Size: 0x1F90(Inherited: 0x1F90) 
struct ABP_AssaultRifle_C : public AMadAssaultWeapon
{

}; 



