#pragma once 
#include <AT43_Structs.h>
 
 
 
// BlueprintGeneratedClass AT43.AT43_C
// Size: 0x28(Inherited: 0x28) 
struct UAT43_C : public UMadSkillDataObject
{

	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function AT43.AT43_C.GetPrimaryExtraData
}; 



