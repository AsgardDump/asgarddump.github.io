#pragma once 
#include <BorrowedTime_WeaponIncrease_DescriptionCalculation_Structs.h>
 
 
 
// BlueprintGeneratedClass BorrowedTime_WeaponIncrease_DescriptionCalculation.BorrowedTime_WeaponIncrease_DescriptionCalculation_C
// Size: 0x28(Inherited: 0x28) 
struct UBorrowedTime_WeaponIncrease_DescriptionCalculation_C : public UMadSkillDataObject
{

	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function BorrowedTime_WeaponIncrease_DescriptionCalculation.BorrowedTime_WeaponIncrease_DescriptionCalculation_C.GetPrimaryExtraData
}; 



