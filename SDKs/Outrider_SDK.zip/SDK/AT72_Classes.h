#pragma once 
#include <AT72_Structs.h>
 
 
 
// BlueprintGeneratedClass AT72.AT72_C
// Size: 0x28(Inherited: 0x28) 
struct UAT72_C : public UMadSkillDataObject
{

	float GetSecondaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function AT72.AT72_C.GetSecondaryExtraData
	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function AT72.AT72_C.GetPrimaryExtraData
}; 



