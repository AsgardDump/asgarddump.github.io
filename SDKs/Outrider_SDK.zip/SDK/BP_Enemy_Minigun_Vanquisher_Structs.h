#pragma once 
#include "SDK.h" 
 
 
// Function BP_Enemy_Minigun_Vanquisher.BP_Enemy_Minigun_Vanquisher_C.ExecuteUbergraph_BP_Enemy_Minigun_Vanquisher
// Size: 0x10(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Enemy_Minigun_Vanquisher
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue;  // 0x8(0x8)

}; 
