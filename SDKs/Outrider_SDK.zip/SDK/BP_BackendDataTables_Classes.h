#pragma once 
#include <BP_BackendDataTables_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_BackendDataTables.BP_BackendDataTables_C
// Size: 0x268(Inherited: 0x268) 
struct UBP_BackendDataTables_C : public UMadBackendDataTables
{

}; 



