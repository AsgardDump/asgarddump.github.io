#pragma once 
#include <AudioMixer_Structs.h>
 
 
 
// Class AudioMixer.SynthComponent
// Size: 0x7D0(Inherited: 0x300) 
struct USynthComponent : public USceneComponent
{
	char bAutoDestroy : 1;  // 0x2F8(0x1)
	char bStopWhenOwnerDestroyed : 1;  // 0x2F8(0x1)
	char bAllowSpatialization : 1;  // 0x2F8(0x1)
	char bOverrideAttenuation : 1;  // 0x2F8(0x1)
	char bOutputToBusOnly : 1;  // 0x2FC(0x1)
	struct USoundAttenuation* AttenuationSettings;  // 0x300(0x8)
	struct FSoundAttenuationSettings AttenuationOverrides;  // 0x308(0x3A0)
	struct USoundConcurrency* ConcurrencySettings;  // 0x6A8(0x8)
	struct TSet<struct USoundConcurrency*> ConcurrencySet;  // 0x6B0(0x50)
	struct USoundClass* SoundClass;  // 0x700(0x8)
	struct USoundEffectSourcePresetChain* SourceEffectChain;  // 0x708(0x8)
	struct USoundSubmixBase* SoundSubmix;  // 0x710(0x8)
	struct TArray<struct FSoundSubmixSendInfo> SoundSubmixSends;  // 0x718(0x10)
	struct TArray<struct FSoundSourceBusSendInfo> BusSends;  // 0x728(0x10)
	struct FSoundModulation Modulation;  // 0x738(0x10)
	struct TArray<struct FSoundSourceBusSendInfo> PreEffectBusSends;  // 0x748(0x10)
	char bIsUISound : 1;  // 0x758(0x1)
	char bIsPreviewSound : 1;  // 0x758(0x1)
	char pad_1880_1 : 1;  // 0x758(0x1)
	char pad_1881[4];  // 0x759(0x4)
	int32_t EnvelopeFollowerAttackTime;  // 0x75C(0x4)
	int32_t EnvelopeFollowerReleaseTime;  // 0x760(0x4)
	char pad_1892[4];  // 0x764(0x4)
	struct FMulticastInlineDelegate OnAudioEnvelopeValue;  // 0x768(0x10)
	char pad_1912[32];  // 0x778(0x20)
	struct USynthSound* Synth;  // 0x798(0x8)
	struct UAudioComponent* AudioComponent;  // 0x7A0(0x8)
	char pad_1960[40];  // 0x7A8(0x28)

	void Stop(); // Function AudioMixer.SynthComponent.Stop
	void Start(); // Function AudioMixer.SynthComponent.Start
	void SetVolumeMultiplier(float VolumeMultiplier); // Function AudioMixer.SynthComponent.SetVolumeMultiplier
	void SetSubmixSend(struct USoundSubmixBase* Submix, float SendLevel); // Function AudioMixer.SynthComponent.SetSubmixSend
	bool IsPlaying(); // Function AudioMixer.SynthComponent.IsPlaying
}; 



// Class AudioMixer.AudioGenerator
// Size: 0xA8(Inherited: 0x28) 
struct UAudioGenerator : public UObject
{
	char pad_40[128];  // 0x28(0x80)

}; 



// Class AudioMixer.AudioMixerBlueprintLibrary
// Size: 0x28(Inherited: 0x28) 
struct UAudioMixerBlueprintLibrary : public UBlueprintFunctionLibrary
{

	float TrimAudioCache(float InMegabytesToFree); // Function AudioMixer.AudioMixerBlueprintLibrary.TrimAudioCache
	struct USoundWave* StopRecordingOutput(struct UObject* WorldContextObject, uint8_t  ExportType, struct FString Name, struct FString Path, struct USoundSubmix* SubmixToRecord, struct USoundWave* ExistingSoundWaveToOverwrite); // Function AudioMixer.AudioMixerBlueprintLibrary.StopRecordingOutput
	void StopAnalyzingOutput(struct UObject* WorldContextObject, struct USoundSubmix* SubmixToStopAnalyzing); // Function AudioMixer.AudioMixerBlueprintLibrary.StopAnalyzingOutput
	void StartRecordingOutput(struct UObject* WorldContextObject, float ExpectedDuration, struct USoundSubmix* SubmixToRecord); // Function AudioMixer.AudioMixerBlueprintLibrary.StartRecordingOutput
	void StartAnalyzingOutput(struct UObject* WorldContextObject, struct USoundSubmix* SubmixToAnalyze, uint8_t  FFTSize, uint8_t  InterpolationMethod, uint8_t  WindowType, float HopSize); // Function AudioMixer.AudioMixerBlueprintLibrary.StartAnalyzingOutput
	void SetBypassSourceEffectChainEntry(struct UObject* WorldContextObject, struct USoundEffectSourcePresetChain* PresetChain, int32_t EntryIndex, bool bBypassed); // Function AudioMixer.AudioMixerBlueprintLibrary.SetBypassSourceEffectChainEntry
	void ResumeRecordingOutput(struct UObject* WorldContextObject, struct USoundSubmix* SubmixToPause); // Function AudioMixer.AudioMixerBlueprintLibrary.ResumeRecordingOutput
	void ReplaceSoundEffectSubmix(struct UObject* WorldContextObject, struct USoundSubmix* InSoundSubmix, int32_t SubmixChainIndex, struct USoundEffectSubmixPreset* SubmixEffectPreset); // Function AudioMixer.AudioMixerBlueprintLibrary.ReplaceSoundEffectSubmix
	void RemoveSubmixEffectPresetAtIndex(struct UObject* WorldContextObject, struct USoundSubmix* SoundSubmix, int32_t SubmixChainIndex); // Function AudioMixer.AudioMixerBlueprintLibrary.RemoveSubmixEffectPresetAtIndex
	void RemoveSubmixEffectPreset(struct UObject* WorldContextObject, struct USoundSubmix* SoundSubmix, struct USoundEffectSubmixPreset* SubmixEffectPreset); // Function AudioMixer.AudioMixerBlueprintLibrary.RemoveSubmixEffectPreset
	void RemoveSourceEffectFromPresetChain(struct UObject* WorldContextObject, struct USoundEffectSourcePresetChain* PresetChain, int32_t EntryIndex); // Function AudioMixer.AudioMixerBlueprintLibrary.RemoveSourceEffectFromPresetChain
	void RemoveMasterSubmixEffect(struct UObject* WorldContextObject, struct USoundEffectSubmixPreset* SubmixEffectPreset); // Function AudioMixer.AudioMixerBlueprintLibrary.RemoveMasterSubmixEffect
	void PrimeSoundForPlayback(struct USoundWave* SoundWave, struct FDelegate OnLoadCompletion); // Function AudioMixer.AudioMixerBlueprintLibrary.PrimeSoundForPlayback
	void PrimeSoundCueForPlayback(struct USoundCue* SoundCue); // Function AudioMixer.AudioMixerBlueprintLibrary.PrimeSoundCueForPlayback
	void PauseRecordingOutput(struct UObject* WorldContextObject, struct USoundSubmix* SubmixToPause); // Function AudioMixer.AudioMixerBlueprintLibrary.PauseRecordingOutput
	void GetPhaseForFrequencies(struct UObject* WorldContextObject, struct TArray<float>& Frequencies, struct TArray<float>& Phases, struct USoundSubmix* SubmixToAnalyze); // Function AudioMixer.AudioMixerBlueprintLibrary.GetPhaseForFrequencies
	int32_t GetNumberOfEntriesInSourceEffectChain(struct UObject* WorldContextObject, struct USoundEffectSourcePresetChain* PresetChain); // Function AudioMixer.AudioMixerBlueprintLibrary.GetNumberOfEntriesInSourceEffectChain
	void GetMagnitudeForFrequencies(struct UObject* WorldContextObject, struct TArray<float>& Frequencies, struct TArray<float>& Magnitudes, struct USoundSubmix* SubmixToAnalyze); // Function AudioMixer.AudioMixerBlueprintLibrary.GetMagnitudeForFrequencies
	void ClearSubmixEffects(struct UObject* WorldContextObject, struct USoundSubmix* SoundSubmix); // Function AudioMixer.AudioMixerBlueprintLibrary.ClearSubmixEffects
	void ClearMasterSubmixEffects(struct UObject* WorldContextObject); // Function AudioMixer.AudioMixerBlueprintLibrary.ClearMasterSubmixEffects
	int32_t AddSubmixEffect(struct UObject* WorldContextObject, struct USoundSubmix* SoundSubmix, struct USoundEffectSubmixPreset* SubmixEffectPreset); // Function AudioMixer.AudioMixerBlueprintLibrary.AddSubmixEffect
	void AddSourceEffectToPresetChain(struct UObject* WorldContextObject, struct USoundEffectSourcePresetChain* PresetChain, struct FSourceEffectChainEntry Entry); // Function AudioMixer.AudioMixerBlueprintLibrary.AddSourceEffectToPresetChain
	void AddMasterSubmixEffect(struct UObject* WorldContextObject, struct USoundEffectSubmixPreset* SubmixEffectPreset); // Function AudioMixer.AudioMixerBlueprintLibrary.AddMasterSubmixEffect
}; 



// Class AudioMixer.SubmixEffectDynamicsProcessorPreset
// Size: 0x108(Inherited: 0x40) 
struct USubmixEffectDynamicsProcessorPreset : public USoundEffectSubmixPreset
{
	char pad_64[120];  // 0x40(0x78)
	struct FSubmixEffectDynamicsProcessorSettings Settings;  // 0xB8(0x50)

	void SetSettings(struct FSubmixEffectDynamicsProcessorSettings& Settings); // Function AudioMixer.SubmixEffectDynamicsProcessorPreset.SetSettings
	void SetExternalSubmix(struct USoundSubmix* Submix); // Function AudioMixer.SubmixEffectDynamicsProcessorPreset.SetExternalSubmix
}; 



// Class AudioMixer.SubmixEffectReverbFastPreset
// Size: 0xD8(Inherited: 0x40) 
struct USubmixEffectReverbFastPreset : public USoundEffectSubmixPreset
{
	char pad_64[96];  // 0x40(0x60)
	struct FSubmixEffectReverbFastSettings Settings;  // 0xA0(0x38)

	void SetSettingsWithReverbEffect(struct UReverbEffect* InReverbEffect, float WetLevel, float DryLevel); // Function AudioMixer.SubmixEffectReverbFastPreset.SetSettingsWithReverbEffect
	void SetSettings(struct FSubmixEffectReverbFastSettings& InSettings); // Function AudioMixer.SubmixEffectReverbFastPreset.SetSettings
}; 



// Class AudioMixer.SubmixEffectSubmixEQPreset
// Size: 0x88(Inherited: 0x40) 
struct USubmixEffectSubmixEQPreset : public USoundEffectSubmixPreset
{
	char pad_64[56];  // 0x40(0x38)
	struct FSubmixEffectSubmixEQSettings Settings;  // 0x78(0x10)

	void SetSettings(struct FSubmixEffectSubmixEQSettings& InSettings); // Function AudioMixer.SubmixEffectSubmixEQPreset.SetSettings
}; 



// Class AudioMixer.SubmixEffectReverbPreset
// Size: 0xD0(Inherited: 0x40) 
struct USubmixEffectReverbPreset : public USoundEffectSubmixPreset
{
	char pad_64[92];  // 0x40(0x5C)
	struct FSubmixEffectReverbSettings Settings;  // 0x9C(0x34)

	void SetSettingsWithReverbEffect(struct UReverbEffect* InReverbEffect, float WetLevel, float DryLevel); // Function AudioMixer.SubmixEffectReverbPreset.SetSettingsWithReverbEffect
	void SetSettings(struct FSubmixEffectReverbSettings& InSettings); // Function AudioMixer.SubmixEffectReverbPreset.SetSettings
}; 



// Class AudioMixer.SynthSound
// Size: 0x3C0(Inherited: 0x3A0) 
struct USynthSound : public USoundWaveProcedural
{
	struct USynthComponent* OwningSynthComponent;  // 0x3A0(0x8)
	char pad_936[24];  // 0x3A8(0x18)

}; 



