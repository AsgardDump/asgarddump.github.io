#pragma once 
#include <BP_ConvoyTruckStopTriggerGravityJump_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_ConvoyTruckStopTriggerGravityJump.BP_ConvoyTruckStopTriggerGravityJump_C
// Size: 0x330(Inherited: 0x328) 
struct ABP_ConvoyTruckStopTriggerGravityJump_C : public AMadConvoyTruckStopTrigger
{
	struct USphereComponent* Pawn;  // 0x328(0x8)

}; 



