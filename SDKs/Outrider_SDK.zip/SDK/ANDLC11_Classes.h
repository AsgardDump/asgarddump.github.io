#pragma once 
#include <ANDLC11_Structs.h>
 
 
 
// BlueprintGeneratedClass ANDLC11.ANDLC11_C
// Size: 0x28(Inherited: 0x28) 
struct UANDLC11_C : public UMadSkillDataObject
{

	float GetQuaternaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function ANDLC11.ANDLC11_C.GetQuaternaryExtraData
	float GetTertiaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function ANDLC11.ANDLC11_C.GetTertiaryExtraData
	float GetSecondaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function ANDLC11.ANDLC11_C.GetSecondaryExtraData
	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function ANDLC11.ANDLC11_C.GetPrimaryExtraData
}; 



