#pragma once 
#include <ASDLC01_Structs.h>
 
 
 
// BlueprintGeneratedClass ASDLC01.ASDLC01_C
// Size: 0x28(Inherited: 0x28) 
struct UASDLC01_C : public UMadSkillDataObject
{

	float GetSecondaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function ASDLC01.ASDLC01_C.GetSecondaryExtraData
	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function ASDLC01.ASDLC01_C.GetPrimaryExtraData
}; 



