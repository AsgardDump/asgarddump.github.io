#pragma once 
#include <AugmentedReality_Structs.h>
 
 
 
// Class AugmentedReality.ARFaceGeometry
// Size: 0x1E0(Inherited: 0xF0) 
struct UARFaceGeometry : public UARTrackedGeometry
{
	struct FVector LookAtTarget;  // 0xE8(0xC)
	char pad_252_1 : 7;  // 0xFC(0x1)
	bool bIsTracked : 1;  // 0xF4(0x1)
	struct TMap<uint8_t , float> BlendShapes;  // 0xF8(0x50)
	char pad_333[147];  // 0x14D(0x93)

	struct FTransform GetWorldSpaceEyeTransform(uint8_t  Eye); // Function AugmentedReality.ARFaceGeometry.GetWorldSpaceEyeTransform
	struct FTransform GetLocalSpaceEyeTransform(uint8_t  Eye); // Function AugmentedReality.ARFaceGeometry.GetLocalSpaceEyeTransform
	float GetBlendShapeValue(uint8_t  BlendShape); // Function AugmentedReality.ARFaceGeometry.GetBlendShapeValue
	struct TMap<uint8_t , float> GetBlendShapes(); // Function AugmentedReality.ARFaceGeometry.GetBlendShapes
}; 



// Class AugmentedReality.ARGetCandidateObjectAsyncTaskBlueprintProxy
// Size: 0x98(Inherited: 0x50) 
struct UARGetCandidateObjectAsyncTaskBlueprintProxy : public UARBaseAsyncTaskBlueprintProxy
{
	struct FMulticastInlineDelegate OnSuccess;  // 0x50(0x10)
	struct FMulticastInlineDelegate OnFailed;  // 0x60(0x10)
	char pad_112[40];  // 0x70(0x28)

	struct UARGetCandidateObjectAsyncTaskBlueprintProxy* ARGetCandidateObject(struct UObject* WorldContextObject, struct FVector Location, struct FVector Extent); // Function AugmentedReality.ARGetCandidateObjectAsyncTaskBlueprintProxy.ARGetCandidateObject
}; 



// Class AugmentedReality.ARBlueprintLibrary
// Size: 0x28(Inherited: 0x28) 
struct UARBlueprintLibrary : public UBlueprintFunctionLibrary
{

	void UnpinComponent(struct USceneComponent* ComponentToUnpin); // Function AugmentedReality.ARBlueprintLibrary.UnpinComponent
	void StopARSession(); // Function AugmentedReality.ARBlueprintLibrary.StopARSession
	void StartARSession(struct UARSessionConfig* SessionConfig); // Function AugmentedReality.ARBlueprintLibrary.StartARSession
	void SetAlignmentTransform(struct FTransform& InAlignmentTransform); // Function AugmentedReality.ARBlueprintLibrary.SetAlignmentTransform
	void RemovePin(struct UARPin* PinToRemove); // Function AugmentedReality.ARBlueprintLibrary.RemovePin
	struct UARPin* PinComponentToTraceResult(struct USceneComponent* ComponentToPin, struct FARTraceResult& TraceResult, struct FName DebugName); // Function AugmentedReality.ARBlueprintLibrary.PinComponentToTraceResult
	struct UARPin* PinComponent(struct USceneComponent* ComponentToPin, struct FTransform& PinToWorldTransform, struct UARTrackedGeometry* TrackedGeometry, struct FName DebugName); // Function AugmentedReality.ARBlueprintLibrary.PinComponent
	void PauseARSession(); // Function AugmentedReality.ARBlueprintLibrary.PauseARSession
	struct TArray<struct FARTraceResult> LineTraceTrackedObjects3D(struct FVector Start, struct FVector End, bool bTestFeaturePoints, bool bTestGroundPlane, bool bTestPlaneExtents, bool bTestPlaneBoundaryPolygon); // Function AugmentedReality.ARBlueprintLibrary.LineTraceTrackedObjects3D
	struct TArray<struct FARTraceResult> LineTraceTrackedObjects(struct FVector2D ScreenCoord, bool bTestFeaturePoints, bool bTestGroundPlane, bool bTestPlaneExtents, bool bTestPlaneBoundaryPolygon); // Function AugmentedReality.ARBlueprintLibrary.LineTraceTrackedObjects
	bool IsSessionTypeSupported(uint8_t  SessionType); // Function AugmentedReality.ARBlueprintLibrary.IsSessionTypeSupported
	bool IsSessionTrackingFeatureSupported(uint8_t  SessionType, uint8_t  SessionTrackingFeature); // Function AugmentedReality.ARBlueprintLibrary.IsSessionTrackingFeatureSupported
	bool IsARSupported(); // Function AugmentedReality.ARBlueprintLibrary.IsARSupported
	uint8_t  GetWorldMappingStatus(); // Function AugmentedReality.ARBlueprintLibrary.GetWorldMappingStatus
	uint8_t  GetTrackingQualityReason(); // Function AugmentedReality.ARBlueprintLibrary.GetTrackingQualityReason
	uint8_t  GetTrackingQuality(); // Function AugmentedReality.ARBlueprintLibrary.GetTrackingQuality
	struct TArray<struct FARVideoFormat> GetSupportedVideoFormats(uint8_t  SessionType); // Function AugmentedReality.ARBlueprintLibrary.GetSupportedVideoFormats
	struct UARSessionConfig* GetSessionConfig(); // Function AugmentedReality.ARBlueprintLibrary.GetSessionConfig
	struct TArray<struct FVector> GetPointCloud(); // Function AugmentedReality.ARBlueprintLibrary.GetPointCloud
	struct UARTextureCameraImage* GetPersonSegmentationImage(); // Function AugmentedReality.ARBlueprintLibrary.GetPersonSegmentationImage
	struct UARTextureCameraImage* GetPersonSegmentationDepthImage(); // Function AugmentedReality.ARBlueprintLibrary.GetPersonSegmentationDepthImage
	struct UARLightEstimate* GetCurrentLightEstimate(); // Function AugmentedReality.ARBlueprintLibrary.GetCurrentLightEstimate
	struct UARTextureCameraImage* GetCameraImage(); // Function AugmentedReality.ARBlueprintLibrary.GetCameraImage
	struct UARTextureCameraDepth* GetCameraDepth(); // Function AugmentedReality.ARBlueprintLibrary.GetCameraDepth
	struct FARSessionStatus GetARSessionStatus(); // Function AugmentedReality.ARBlueprintLibrary.GetARSessionStatus
	struct TArray<struct UARTrackedPose*> GetAllTrackedPoses(); // Function AugmentedReality.ARBlueprintLibrary.GetAllTrackedPoses
	struct TArray<struct UARTrackedPoint*> GetAllTrackedPoints(); // Function AugmentedReality.ARBlueprintLibrary.GetAllTrackedPoints
	struct TArray<struct UARPlaneGeometry*> GetAllTrackedPlanes(); // Function AugmentedReality.ARBlueprintLibrary.GetAllTrackedPlanes
	struct TArray<struct UARTrackedImage*> GetAllTrackedImages(); // Function AugmentedReality.ARBlueprintLibrary.GetAllTrackedImages
	struct TArray<struct UAREnvironmentCaptureProbe*> GetAllTrackedEnvironmentCaptureProbes(); // Function AugmentedReality.ARBlueprintLibrary.GetAllTrackedEnvironmentCaptureProbes
	struct TArray<struct FARPose2D> GetAllTracked2DPoses(); // Function AugmentedReality.ARBlueprintLibrary.GetAllTracked2DPoses
	struct TArray<struct UARPin*> GetAllPins(); // Function AugmentedReality.ARBlueprintLibrary.GetAllPins
	struct TArray<struct UARTrackedGeometry*> GetAllGeometries(); // Function AugmentedReality.ARBlueprintLibrary.GetAllGeometries
	void DebugDrawTrackedGeometry(struct UARTrackedGeometry* TrackedGeometry, struct UObject* WorldContextObject, struct FLinearColor Color, float OutlineThickness, float PersistForSeconds); // Function AugmentedReality.ARBlueprintLibrary.DebugDrawTrackedGeometry
	void DebugDrawPin(struct UARPin* ARPin, struct UObject* WorldContextObject, struct FLinearColor Color, float Scale, float PersistForSeconds); // Function AugmentedReality.ARBlueprintLibrary.DebugDrawPin
	struct UARCandidateImage* AddRuntimeCandidateImage(struct UARSessionConfig* SessionConfig, struct UTexture2D* CandidateTexture, struct FString FriendlyName, float PhysicalWidth); // Function AugmentedReality.ARBlueprintLibrary.AddRuntimeCandidateImage
	bool AddManualEnvironmentCaptureProbe(struct FVector Location, struct FVector Extent); // Function AugmentedReality.ARBlueprintLibrary.AddManualEnvironmentCaptureProbe
}; 



// Class AugmentedReality.ARTrackableNotifyComponent
// Size: 0x2F8(Inherited: 0x1A8) 
struct UARTrackableNotifyComponent : public UActorComponent
{
	struct FMulticastInlineDelegate OnAddTrackedGeometry;  // 0x1A8(0x10)
	struct FMulticastInlineDelegate OnUpdateTrackedGeometry;  // 0x1B8(0x10)
	struct FMulticastInlineDelegate OnRemoveTrackedGeometry;  // 0x1C8(0x10)
	struct FMulticastInlineDelegate OnAddTrackedPlane;  // 0x1D8(0x10)
	struct FMulticastInlineDelegate OnUpdateTrackedPlane;  // 0x1E8(0x10)
	struct FMulticastInlineDelegate OnRemoveTrackedPlane;  // 0x1F8(0x10)
	struct FMulticastInlineDelegate OnAddTrackedPoint;  // 0x208(0x10)
	struct FMulticastInlineDelegate OnUpdateTrackedPoint;  // 0x218(0x10)
	struct FMulticastInlineDelegate OnRemoveTrackedPoint;  // 0x228(0x10)
	struct FMulticastInlineDelegate OnAddTrackedImage;  // 0x238(0x10)
	struct FMulticastInlineDelegate OnUpdateTrackedImage;  // 0x248(0x10)
	struct FMulticastInlineDelegate OnRemoveTrackedImage;  // 0x258(0x10)
	struct FMulticastInlineDelegate OnAddTrackedFace;  // 0x268(0x10)
	struct FMulticastInlineDelegate OnUpdateTrackedFace;  // 0x278(0x10)
	struct FMulticastInlineDelegate OnRemoveTrackedFace;  // 0x288(0x10)
	struct FMulticastInlineDelegate OnAddTrackedEnvProbe;  // 0x298(0x10)
	struct FMulticastInlineDelegate OnUpdateTrackedEnvProbe;  // 0x2A8(0x10)
	struct FMulticastInlineDelegate OnRemoveTrackedEnvProbe;  // 0x2B8(0x10)
	struct FMulticastInlineDelegate OnAddTrackedObject;  // 0x2C8(0x10)
	struct FMulticastInlineDelegate OnUpdateTrackedObject;  // 0x2D8(0x10)
	struct FMulticastInlineDelegate OnRemoveTrackedObject;  // 0x2E8(0x10)

}; 



// Class AugmentedReality.ARTraceResultDummy
// Size: 0x28(Inherited: 0x28) 
struct UARTraceResultDummy : public UObject
{

}; 



// Class AugmentedReality.ARLightEstimate
// Size: 0x28(Inherited: 0x28) 
struct UARLightEstimate : public UObject
{

}; 



// Class AugmentedReality.ARTraceResultLibrary
// Size: 0x28(Inherited: 0x28) 
struct UARTraceResultLibrary : public UBlueprintFunctionLibrary
{

	struct UARTrackedGeometry* GetTrackedGeometry(struct FARTraceResult& TraceResult); // Function AugmentedReality.ARTraceResultLibrary.GetTrackedGeometry
	uint8_t  GetTraceChannel(struct FARTraceResult& TraceResult); // Function AugmentedReality.ARTraceResultLibrary.GetTraceChannel
	struct FTransform GetLocalToWorldTransform(struct FARTraceResult& TraceResult); // Function AugmentedReality.ARTraceResultLibrary.GetLocalToWorldTransform
	struct FTransform GetLocalToTrackingTransform(struct FARTraceResult& TraceResult); // Function AugmentedReality.ARTraceResultLibrary.GetLocalToTrackingTransform
	float GetDistanceFromCamera(struct FARTraceResult& TraceResult); // Function AugmentedReality.ARTraceResultLibrary.GetDistanceFromCamera
}; 



// Class AugmentedReality.ARBaseAsyncTaskBlueprintProxy
// Size: 0x50(Inherited: 0x30) 
struct UARBaseAsyncTaskBlueprintProxy : public UBlueprintAsyncActionBase
{
	char pad_48[32];  // 0x30(0x20)

}; 



// Class AugmentedReality.ARSaveWorldAsyncTaskBlueprintProxy
// Size: 0x80(Inherited: 0x50) 
struct UARSaveWorldAsyncTaskBlueprintProxy : public UARBaseAsyncTaskBlueprintProxy
{
	struct FMulticastInlineDelegate OnSuccess;  // 0x50(0x10)
	struct FMulticastInlineDelegate OnFailed;  // 0x60(0x10)
	char pad_112[16];  // 0x70(0x10)

	struct UARSaveWorldAsyncTaskBlueprintProxy* ARSaveWorld(struct UObject* WorldContextObject); // Function AugmentedReality.ARSaveWorldAsyncTaskBlueprintProxy.ARSaveWorld
}; 



// Class AugmentedReality.ARBasicLightEstimate
// Size: 0x40(Inherited: 0x28) 
struct UARBasicLightEstimate : public UARLightEstimate
{
	float AmbientIntensityLumens;  // 0x28(0x4)
	float AmbientColorTemperatureKelvin;  // 0x2C(0x4)
	struct FLinearColor AmbientColor;  // 0x30(0x10)

	float GetAmbientIntensityLumens(); // Function AugmentedReality.ARBasicLightEstimate.GetAmbientIntensityLumens
	float GetAmbientColorTemperatureKelvin(); // Function AugmentedReality.ARBasicLightEstimate.GetAmbientColorTemperatureKelvin
	struct FLinearColor GetAmbientColor(); // Function AugmentedReality.ARBasicLightEstimate.GetAmbientColor
}; 



// Class AugmentedReality.AROriginActor
// Size: 0x320(Inherited: 0x320) 
struct AAROriginActor : public AActor
{

}; 



// Class AugmentedReality.ARCandidateImage
// Size: 0x58(Inherited: 0x30) 
struct UARCandidateImage : public UDataAsset
{
	struct UTexture2D* CandidateTexture;  // 0x30(0x8)
	struct FString FriendlyName;  // 0x38(0x10)
	float Width;  // 0x48(0x4)
	float Height;  // 0x4C(0x4)
	uint8_t  Orientation;  // 0x50(0x1)
	char pad_81[7];  // 0x51(0x7)

	float GetPhysicalWidth(); // Function AugmentedReality.ARCandidateImage.GetPhysicalWidth
	float GetPhysicalHeight(); // Function AugmentedReality.ARCandidateImage.GetPhysicalHeight
	uint8_t  GetOrientation(); // Function AugmentedReality.ARCandidateImage.GetOrientation
	struct FString GetFriendlyName(); // Function AugmentedReality.ARCandidateImage.GetFriendlyName
	struct UTexture2D* GetCandidateTexture(); // Function AugmentedReality.ARCandidateImage.GetCandidateTexture
}; 



// Class AugmentedReality.ARPin
// Size: 0xF0(Inherited: 0x28) 
struct UARPin : public UObject
{
	struct UARTrackedGeometry* TrackedGeometry;  // 0x28(0x8)
	struct USceneComponent* PinnedComponent;  // 0x30(0x8)
	char pad_56[8];  // 0x38(0x8)
	struct FTransform LocalToTrackingTransform;  // 0x40(0x30)
	struct FTransform LocalToAlignedTrackingTransform;  // 0x70(0x30)
	uint8_t  TrackingState;  // 0xA0(0x1)
	char pad_161[31];  // 0xA1(0x1F)
	struct FMulticastInlineDelegate OnARTrackingStateChanged;  // 0xC0(0x10)
	struct FMulticastInlineDelegate OnARTransformUpdated;  // 0xD0(0x10)
	char pad_224[16];  // 0xE0(0x10)

	uint8_t  GetTrackingState(); // Function AugmentedReality.ARPin.GetTrackingState
	struct UARTrackedGeometry* GetTrackedGeometry(); // Function AugmentedReality.ARPin.GetTrackedGeometry
	struct USceneComponent* GetPinnedComponent(); // Function AugmentedReality.ARPin.GetPinnedComponent
	struct FTransform GetLocalToWorldTransform(); // Function AugmentedReality.ARPin.GetLocalToWorldTransform
	struct FTransform GetLocalToTrackingTransform(); // Function AugmentedReality.ARPin.GetLocalToTrackingTransform
	struct FName GetDebugName(); // Function AugmentedReality.ARPin.GetDebugName
	void DebugDraw(struct UWorld* World, struct FLinearColor& Color, float Scale, float PersistForSeconds); // Function AugmentedReality.ARPin.DebugDraw
}; 



// Class AugmentedReality.AREnvironmentCaptureProbe
// Size: 0x100(Inherited: 0xF0) 
struct UAREnvironmentCaptureProbe : public UARTrackedGeometry
{
	char pad_240[8];  // 0xF0(0x8)
	struct UAREnvironmentCaptureProbeTexture* EnvironmentCaptureTexture;  // 0xF8(0x8)

	struct FVector GetExtent(); // Function AugmentedReality.AREnvironmentCaptureProbe.GetExtent
	struct UAREnvironmentCaptureProbeTexture* GetEnvironmentCaptureTexture(); // Function AugmentedReality.AREnvironmentCaptureProbe.GetEnvironmentCaptureTexture
}; 



// Class AugmentedReality.ARTrackedQRCode
// Size: 0x110(Inherited: 0x100) 
struct UARTrackedQRCode : public UARTrackedImage
{
	struct FString QRCode;  // 0xF8(0x10)
	int32_t Version;  // 0x108(0x4)

}; 



// Class AugmentedReality.ARSessionConfig
// Size: 0xA8(Inherited: 0x30) 
struct UARSessionConfig : public UDataAsset
{
	char pad_48_1 : 7;  // 0x30(0x1)
	bool bGenerateMeshDataFromTrackedGeometry : 1;  // 0x30(0x1)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool bGenerateCollisionForMeshData : 1;  // 0x31(0x1)
	char pad_50_1 : 7;  // 0x32(0x1)
	bool bGenerateNavMeshForMeshData : 1;  // 0x32(0x1)
	char pad_51_1 : 7;  // 0x33(0x1)
	bool bUseMeshDataForOcclusion : 1;  // 0x33(0x1)
	char pad_52_1 : 7;  // 0x34(0x1)
	bool bRenderMeshDataInWireframe : 1;  // 0x34(0x1)
	char pad_53_1 : 7;  // 0x35(0x1)
	bool bTrackSceneObjects : 1;  // 0x35(0x1)
	char pad_54_1 : 7;  // 0x36(0x1)
	bool bUsePersonSegmentationForOcclusion : 1;  // 0x36(0x1)
	uint8_t  WorldAlignment;  // 0x37(0x1)
	uint8_t  SessionType;  // 0x38(0x1)
	uint8_t  PlaneDetectionMode;  // 0x39(0x1)
	char pad_58_1 : 7;  // 0x3A(0x1)
	bool bHorizontalPlaneDetection : 1;  // 0x3A(0x1)
	char pad_59_1 : 7;  // 0x3B(0x1)
	bool bVerticalPlaneDetection : 1;  // 0x3B(0x1)
	char pad_60_1 : 7;  // 0x3C(0x1)
	bool bEnableAutoFocus : 1;  // 0x3C(0x1)
	uint8_t  LightEstimationMode;  // 0x3D(0x1)
	uint8_t  FrameSyncMode;  // 0x3E(0x1)
	char pad_63_1 : 7;  // 0x3F(0x1)
	bool bEnableAutomaticCameraOverlay : 1;  // 0x3F(0x1)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool bEnableAutomaticCameraTracking : 1;  // 0x40(0x1)
	char pad_65_1 : 7;  // 0x41(0x1)
	bool bResetCameraTracking : 1;  // 0x41(0x1)
	char pad_66_1 : 7;  // 0x42(0x1)
	bool bResetTrackedObjects : 1;  // 0x42(0x1)
	char pad_67[5];  // 0x43(0x5)
	struct TArray<struct UARCandidateImage*> CandidateImages;  // 0x48(0x10)
	int32_t MaxNumSimultaneousImagesTracked;  // 0x58(0x4)
	uint8_t  EnvironmentCaptureProbeType;  // 0x5C(0x1)
	char pad_93[3];  // 0x5D(0x3)
	struct TArray<char> WorldMapData;  // 0x60(0x10)
	struct TArray<struct UARCandidateObject*> CandidateObjects;  // 0x70(0x10)
	struct FARVideoFormat DesiredVideoFormat;  // 0x80(0xC)
	uint8_t  FaceTrackingDirection;  // 0x8C(0x1)
	uint8_t  FaceTrackingUpdate;  // 0x8D(0x1)
	char pad_142[2];  // 0x8E(0x2)
	struct TArray<char> SerializedARCandidateImageDatabase;  // 0x90(0x10)
	uint8_t  EnabledSessionTrackingFeature;  // 0xA0(0x1)
	char pad_161[7];  // 0xA1(0x7)

	bool ShouldResetTrackedObjects(); // Function AugmentedReality.ARSessionConfig.ShouldResetTrackedObjects
	bool ShouldResetCameraTracking(); // Function AugmentedReality.ARSessionConfig.ShouldResetCameraTracking
	bool ShouldRenderCameraOverlay(); // Function AugmentedReality.ARSessionConfig.ShouldRenderCameraOverlay
	bool ShouldEnableCameraTracking(); // Function AugmentedReality.ARSessionConfig.ShouldEnableCameraTracking
	bool ShouldEnableAutoFocus(); // Function AugmentedReality.ARSessionConfig.ShouldEnableAutoFocus
	void SetWorldMapData(struct TArray<char> WorldMapData); // Function AugmentedReality.ARSessionConfig.SetWorldMapData
	void SetSessionTrackingFeatureToEnable(uint8_t  InSessionTrackingFeature); // Function AugmentedReality.ARSessionConfig.SetSessionTrackingFeatureToEnable
	void SetResetTrackedObjects(bool bNewValue); // Function AugmentedReality.ARSessionConfig.SetResetTrackedObjects
	void SetResetCameraTracking(bool bNewValue); // Function AugmentedReality.ARSessionConfig.SetResetCameraTracking
	void SetFaceTrackingUpdate(uint8_t  InUpdate); // Function AugmentedReality.ARSessionConfig.SetFaceTrackingUpdate
	void SetFaceTrackingDirection(uint8_t  InDirection); // Function AugmentedReality.ARSessionConfig.SetFaceTrackingDirection
	void SetEnableAutoFocus(bool bNewValue); // Function AugmentedReality.ARSessionConfig.SetEnableAutoFocus
	void SetDesiredVideoFormat(struct FARVideoFormat NewFormat); // Function AugmentedReality.ARSessionConfig.SetDesiredVideoFormat
	void SetCandidateObjectList(struct TArray<struct UARCandidateObject*>& InCandidateObjects); // Function AugmentedReality.ARSessionConfig.SetCandidateObjectList
	struct TArray<char> GetWorldMapData(); // Function AugmentedReality.ARSessionConfig.GetWorldMapData
	uint8_t  GetWorldAlignment(); // Function AugmentedReality.ARSessionConfig.GetWorldAlignment
	uint8_t  GetSessionType(); // Function AugmentedReality.ARSessionConfig.GetSessionType
	uint8_t  GetPlaneDetectionMode(); // Function AugmentedReality.ARSessionConfig.GetPlaneDetectionMode
	int32_t GetMaxNumSimultaneousImagesTracked(); // Function AugmentedReality.ARSessionConfig.GetMaxNumSimultaneousImagesTracked
	uint8_t  GetLightEstimationMode(); // Function AugmentedReality.ARSessionConfig.GetLightEstimationMode
	uint8_t  GetFrameSyncMode(); // Function AugmentedReality.ARSessionConfig.GetFrameSyncMode
	uint8_t  GetFaceTrackingUpdate(); // Function AugmentedReality.ARSessionConfig.GetFaceTrackingUpdate
	uint8_t  GetFaceTrackingDirection(); // Function AugmentedReality.ARSessionConfig.GetFaceTrackingDirection
	uint8_t  GetEnvironmentCaptureProbeType(); // Function AugmentedReality.ARSessionConfig.GetEnvironmentCaptureProbeType
	uint8_t  GetEnabledSessionTrackingFeature(); // Function AugmentedReality.ARSessionConfig.GetEnabledSessionTrackingFeature
	struct FARVideoFormat GetDesiredVideoFormat(); // Function AugmentedReality.ARSessionConfig.GetDesiredVideoFormat
	struct TArray<struct UARCandidateObject*> GetCandidateObjectList(); // Function AugmentedReality.ARSessionConfig.GetCandidateObjectList
	struct TArray<struct UARCandidateImage*> GetCandidateImageList(); // Function AugmentedReality.ARSessionConfig.GetCandidateImageList
	void AddCandidateObject(struct UARCandidateObject* CandidateObject); // Function AugmentedReality.ARSessionConfig.AddCandidateObject
	void AddCandidateImage(struct UARCandidateImage* NewCandidateImage); // Function AugmentedReality.ARSessionConfig.AddCandidateImage
}; 



// Class AugmentedReality.ARSharedWorldGameMode
// Size: 0x470(Inherited: 0x408) 
struct AARSharedWorldGameMode : public AGameMode
{
	int32_t BufferSizePerChunk;  // 0x408(0x4)
	char pad_1036[100];  // 0x40C(0x64)

	void SetPreviewImageData(struct TArray<char> ImageData); // Function AugmentedReality.ARSharedWorldGameMode.SetPreviewImageData
	void SetARWorldSharingIsReady(); // Function AugmentedReality.ARSharedWorldGameMode.SetARWorldSharingIsReady
	void SetARSharedWorldData(struct TArray<char> ARWorldData); // Function AugmentedReality.ARSharedWorldGameMode.SetARSharedWorldData
	struct AARSharedWorldGameState* GetARSharedWorldGameState(); // Function AugmentedReality.ARSharedWorldGameMode.GetARSharedWorldGameState
}; 



// Class AugmentedReality.ARSharedWorldGameState
// Size: 0x3C8(Inherited: 0x390) 
struct AARSharedWorldGameState : public AGameState
{
	struct TArray<char> PreviewImageData;  // 0x390(0x10)
	struct TArray<char> ARWorldData;  // 0x3A0(0x10)
	int32_t PreviewImageBytesTotal;  // 0x3B0(0x4)
	int32_t ARWorldBytesTotal;  // 0x3B4(0x4)
	int32_t PreviewImageBytesDelivered;  // 0x3B8(0x4)
	int32_t ARWorldBytesDelivered;  // 0x3BC(0x4)
	char pad_960[8];  // 0x3C0(0x8)

	void K2_OnARWorldMapIsReady(); // Function AugmentedReality.ARSharedWorldGameState.K2_OnARWorldMapIsReady
}; 



// Class AugmentedReality.ARPlaneGeometry
// Size: 0x120(Inherited: 0xF0) 
struct UARPlaneGeometry : public UARTrackedGeometry
{
	uint8_t  Orientation;  // 0xE8(0x1)
	struct FVector Center;  // 0xEC(0xC)
	struct FVector Extent;  // 0xF8(0xC)
	char pad_265[15];  // 0x109(0xF)
	struct UARPlaneGeometry* SubsumedBy;  // 0x118(0x8)

	struct UARPlaneGeometry* GetSubsumedBy(); // Function AugmentedReality.ARPlaneGeometry.GetSubsumedBy
	uint8_t  GetOrientation(); // Function AugmentedReality.ARPlaneGeometry.GetOrientation
	struct FVector GetExtent(); // Function AugmentedReality.ARPlaneGeometry.GetExtent
	struct FVector GetCenter(); // Function AugmentedReality.ARPlaneGeometry.GetCenter
	struct TArray<struct FVector> GetBoundaryPolygonInLocalSpace(); // Function AugmentedReality.ARPlaneGeometry.GetBoundaryPolygonInLocalSpace
}; 



// Class AugmentedReality.ARSharedWorldPlayerController
// Size: 0x6A0(Inherited: 0x698) 
struct AARSharedWorldPlayerController : public APlayerController
{
	char pad_1688[8];  // 0x698(0x8)

	void ServerMarkReadyForReceiving(); // Function AugmentedReality.ARSharedWorldPlayerController.ServerMarkReadyForReceiving
	void ClientUpdatePreviewImageData(int32_t Offset, struct TArray<char> Buffer); // Function AugmentedReality.ARSharedWorldPlayerController.ClientUpdatePreviewImageData
	void ClientUpdateARWorldData(int32_t Offset, struct TArray<char> Buffer); // Function AugmentedReality.ARSharedWorldPlayerController.ClientUpdateARWorldData
	void ClientInitSharedWorld(int32_t PreviewImageSize, int32_t ARWorldDataSize); // Function AugmentedReality.ARSharedWorldPlayerController.ClientInitSharedWorld
}; 



// Class AugmentedReality.ARSkyLight
// Size: 0x340(Inherited: 0x330) 
struct AARSkyLight : public ASkyLight
{
	struct UAREnvironmentCaptureProbe* CaptureProbe;  // 0x330(0x8)
	char pad_824[8];  // 0x338(0x8)

	void SetEnvironmentCaptureProbe(struct UAREnvironmentCaptureProbe* InCaptureProbe); // Function AugmentedReality.ARSkyLight.SetEnvironmentCaptureProbe
}; 



// Class AugmentedReality.ARTexture
// Size: 0x1B0(Inherited: 0x190) 
struct UARTexture : public UTexture
{
	uint8_t  TextureType;  // 0x188(0x1)
	float Timestamp;  // 0x18C(0x4)
	struct FGuid ExternalTextureGuid;  // 0x190(0x10)
	struct FVector2D Size;  // 0x1A0(0x8)
	char pad_429[3];  // 0x1AD(0x3)

}; 



// Class AugmentedReality.ARTextureCameraImage
// Size: 0x1B0(Inherited: 0x1B0) 
struct UARTextureCameraImage : public UARTexture
{

}; 



// Class AugmentedReality.ARTextureCameraDepth
// Size: 0x1B0(Inherited: 0x1B0) 
struct UARTextureCameraDepth : public UARTexture
{
	uint8_t  DepthQuality;  // 0x1A8(0x1)
	uint8_t  DepthAccuracy;  // 0x1A9(0x1)
	char pad_434_1 : 7;  // 0x1B2(0x1)
	bool bIsTemporallySmoothed : 1;  // 0x1AA(0x1)

}; 



// Class AugmentedReality.AREnvironmentCaptureProbeTexture
// Size: 0x200(Inherited: 0x1E0) 
struct UAREnvironmentCaptureProbeTexture : public UTextureCube
{
	uint8_t  TextureType;  // 0x1E0(0x1)
	char pad_481[3];  // 0x1E1(0x3)
	float Timestamp;  // 0x1E4(0x4)
	struct FGuid ExternalTextureGuid;  // 0x1E8(0x10)
	struct FVector2D Size;  // 0x1F8(0x8)

}; 



// Class AugmentedReality.ARTrackedGeometry
// Size: 0xF0(Inherited: 0x28) 
struct UARTrackedGeometry : public UObject
{
	struct FGuid UniqueId;  // 0x28(0x10)
	char pad_56[8];  // 0x38(0x8)
	struct FTransform LocalToTrackingTransform;  // 0x40(0x30)
	struct FTransform LocalToAlignedTrackingTransform;  // 0x70(0x30)
	uint8_t  TrackingState;  // 0xA0(0x1)
	char pad_161[15];  // 0xA1(0xF)
	struct UMRMeshComponent* UnderlyingMesh;  // 0xB0(0x8)
	uint8_t  ObjectClassification;  // 0xB8(0x1)
	char pad_185[23];  // 0xB9(0x17)
	int32_t LastUpdateFrameNumber;  // 0xD0(0x4)
	char pad_212[12];  // 0xD4(0xC)
	struct FName DebugName;  // 0xE0(0x8)
	char pad_232[8];  // 0xE8(0x8)

	bool IsTracked(); // Function AugmentedReality.ARTrackedGeometry.IsTracked
	struct UMRMeshComponent* GetUnderlyingMesh(); // Function AugmentedReality.ARTrackedGeometry.GetUnderlyingMesh
	uint8_t  GetTrackingState(); // Function AugmentedReality.ARTrackedGeometry.GetTrackingState
	uint8_t  GetObjectClassification(); // Function AugmentedReality.ARTrackedGeometry.GetObjectClassification
	struct FTransform GetLocalToWorldTransform(); // Function AugmentedReality.ARTrackedGeometry.GetLocalToWorldTransform
	struct FTransform GetLocalToTrackingTransform(); // Function AugmentedReality.ARTrackedGeometry.GetLocalToTrackingTransform
	float GetLastUpdateTimestamp(); // Function AugmentedReality.ARTrackedGeometry.GetLastUpdateTimestamp
	int32_t GetLastUpdateFrameNumber(); // Function AugmentedReality.ARTrackedGeometry.GetLastUpdateFrameNumber
	struct FName GetDebugName(); // Function AugmentedReality.ARTrackedGeometry.GetDebugName
}; 



// Class AugmentedReality.ARTrackedPoint
// Size: 0xF0(Inherited: 0xF0) 
struct UARTrackedPoint : public UARTrackedGeometry
{

}; 



// Class AugmentedReality.ARTrackedObject
// Size: 0xF0(Inherited: 0xF0) 
struct UARTrackedObject : public UARTrackedGeometry
{
	struct UARCandidateObject* DetectedObject;  // 0xE8(0x8)

	struct UARCandidateObject* GetDetectedObject(); // Function AugmentedReality.ARTrackedObject.GetDetectedObject
}; 



// Class AugmentedReality.ARTrackedImage
// Size: 0x100(Inherited: 0xF0) 
struct UARTrackedImage : public UARTrackedGeometry
{
	struct UARCandidateImage* DetectedImage;  // 0xE8(0x8)
	struct FVector2D EstimatedSize;  // 0xF0(0x8)

	struct FVector2D GetEstimateSize(); // Function AugmentedReality.ARTrackedImage.GetEstimateSize
	struct UARCandidateImage* GetDetectedImage(); // Function AugmentedReality.ARTrackedImage.GetDetectedImage
}; 



// Class AugmentedReality.ARTrackedPose
// Size: 0x140(Inherited: 0xF0) 
struct UARTrackedPose : public UARTrackedGeometry
{
	char pad_240[80];  // 0xF0(0x50)

	struct FARPose3D GetTrackedPoseData(); // Function AugmentedReality.ARTrackedPose.GetTrackedPoseData
}; 



// Class AugmentedReality.ARTypesDummyClass
// Size: 0x28(Inherited: 0x28) 
struct UARTypesDummyClass : public UObject
{

}; 



// Class AugmentedReality.ARCandidateObject
// Size: 0x70(Inherited: 0x30) 
struct UARCandidateObject : public UDataAsset
{
	struct TArray<char> CandidateObjectData;  // 0x30(0x10)
	struct FString FriendlyName;  // 0x40(0x10)
	struct FBox BoundingBox;  // 0x50(0x1C)
	char pad_108[4];  // 0x6C(0x4)

	void SetFriendlyName(struct FString NewName); // Function AugmentedReality.ARCandidateObject.SetFriendlyName
	void SetCandidateObjectData(struct TArray<char>& InCandidateObject); // Function AugmentedReality.ARCandidateObject.SetCandidateObjectData
	void SetBoundingBox(struct FBox& InBoundingBox); // Function AugmentedReality.ARCandidateObject.SetBoundingBox
	struct FString GetFriendlyName(); // Function AugmentedReality.ARCandidateObject.GetFriendlyName
	struct TArray<char> GetCandidateObjectData(); // Function AugmentedReality.ARCandidateObject.GetCandidateObjectData
	struct FBox GetBoundingBox(); // Function AugmentedReality.ARCandidateObject.GetBoundingBox
}; 



