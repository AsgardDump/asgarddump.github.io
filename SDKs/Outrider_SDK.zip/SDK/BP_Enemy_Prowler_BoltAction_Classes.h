#pragma once 
#include <BP_Enemy_Prowler_BoltAction_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Enemy_Prowler_BoltAction.BP_Enemy_Prowler_BoltAction_C
// Size: 0x1FF8(Inherited: 0x1FF8) 
struct ABP_Enemy_Prowler_BoltAction_C : public ABP_Enemy_Alien_BoltAction_C
{

}; 



