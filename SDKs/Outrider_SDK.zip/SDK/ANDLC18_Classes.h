#pragma once 
#include <ANDLC18_Structs.h>
 
 
 
// BlueprintGeneratedClass ANDLC18.ANDLC18_C
// Size: 0x28(Inherited: 0x28) 
struct UANDLC18_C : public UMadSkillDataObject
{

	float GetSecondaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function ANDLC18.ANDLC18_C.GetSecondaryExtraData
	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function ANDLC18.ANDLC18_C.GetPrimaryExtraData
}; 



