#pragma once 
#include <BlackHole_SkillData_Structs.h>
 
 
 
// BlueprintGeneratedClass BlackHole_SkillData.BlackHole_SkillData_C
// Size: 0x28(Inherited: 0x28) 
struct UBlackHole_SkillData_C : public UMadSkillDataObject
{

	float GetCalculatedDamage(struct AMadBaseCharacter* MadInstigatorCharacter); // Function BlackHole_SkillData.BlackHole_SkillData_C.GetCalculatedDamage
}; 



