#pragma once 
#include <BP_DroppedClip_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_DroppedClip.BP_DroppedClip_C
// Size: 0x338(Inherited: 0x328) 
struct ABP_DroppedClip_C : public ADroppedClip
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x328(0x8)
	struct USoundBase* GroundHitCue;  // 0x330(0x8)

	void ReceiveHit(struct UPrimitiveComponent* MyComp, struct AActor* Other, struct UPrimitiveComponent* OtherComp, bool bSelfMoved, struct FVector HitLocation, struct FVector HitNormal, struct FVector NormalImpulse, struct FHitResult& Hit); // Function BP_DroppedClip.BP_DroppedClip_C.ReceiveHit
	void ExecuteUbergraph_BP_DroppedClip(int32_t EntryPoint); // Function BP_DroppedClip.BP_DroppedClip_C.ExecuteUbergraph_BP_DroppedClip
}; 



