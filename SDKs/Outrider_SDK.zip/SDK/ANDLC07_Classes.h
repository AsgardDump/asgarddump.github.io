#pragma once 
#include <ANDLC07_Structs.h>
 
 
 
// BlueprintGeneratedClass ANDLC07.ANDLC07_C
// Size: 0x28(Inherited: 0x28) 
struct UANDLC07_C : public UMadSkillDataObject
{

	float GetSecondaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function ANDLC07.ANDLC07_C.GetSecondaryExtraData
	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function ANDLC07.ANDLC07_C.GetPrimaryExtraData
}; 



