#pragma once 
#include <AssassinReloadBoost_Structs.h>
 
 
 
// BlueprintGeneratedClass AssassinReloadBoost.AssassinReloadBoost_C
// Size: 0x28(Inherited: 0x28) 
struct UAssassinReloadBoost_C : public UMadSkillDataObject
{

	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function AssassinReloadBoost.AssassinReloadBoost_C.GetPrimaryExtraData
}; 



