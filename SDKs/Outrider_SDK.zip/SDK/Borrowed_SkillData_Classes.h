#pragma once 
#include <Borrowed_SkillData_Structs.h>
 
 
 
// BlueprintGeneratedClass Borrowed_SkillData.Borrowed_SkillData_C
// Size: 0x28(Inherited: 0x28) 
struct UBorrowed_SkillData_C : public UMadSkillDataObject
{

	float GetSecondaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function Borrowed_SkillData.Borrowed_SkillData_C.GetSecondaryExtraData
	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function Borrowed_SkillData.Borrowed_SkillData_C.GetPrimaryExtraData
}; 



