#pragma once 
#include <AT32_Structs.h>
 
 
 
// BlueprintGeneratedClass AT32.AT32_C
// Size: 0x28(Inherited: 0x28) 
struct UAT32_C : public UMadSkillDataObject
{

	float GetTertiaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function AT32.AT32_C.GetTertiaryExtraData
	float GetSecondaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function AT32.AT32_C.GetSecondaryExtraData
	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function AT32.AT32_C.GetPrimaryExtraData
}; 



