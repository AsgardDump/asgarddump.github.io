#pragma once 
#include "SDK.h" 
 
 
// Function BorrowedTime_LowerFocus_DescriptionCalculation.BorrowedTime_LowerFocus_DescriptionCalculation_C.GetPrimaryExtraData
// Size: 0x44(Inherited: 0x10) 
struct FGetPrimaryExtraData : public FGetPrimaryExtraData
{
	struct AMadBaseCharacter* MadInstigatorCharacter;  // 0x0(0x8)
	int32_t ItemLevel;  // 0x8(0x4)
	float ReturnValue;  // 0xC(0x4)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool Temp_bool_Variable : 1;  // 0x10(0x1)
	float CallFunc_Conv_IntToFloat_ReturnValue;  // 0x14(0x4)
	char pad_37_1 : 7;  // 0x25(0x1)
	bool CallFunc_GetFloatAttribute_bSuccessfullyFoundAttribute : 1;  // 0x18(0x1)
	float CallFunc_GetFloatAttribute_ReturnValue;  // 0x1C(0x4)
	char EEvaluateCurveTableResult CallFunc_EvaluateCurveTableRow_OutResult;  // 0x20(0x1)
	float CallFunc_EvaluateCurveTableRow_OutXY;  // 0x24(0x4)
	char pad_47_1 : 7;  // 0x2F(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x28(0x1)
	float Temp_float_Variable;  // 0x2C(0x4)
	float K2Node_Select_Default;  // 0x30(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x34(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_2;  // 0x38(0x4)
	int32_t CallFunc_Round_ReturnValue;  // 0x3C(0x4)
	float CallFunc_Conv_IntToFloat_ReturnValue_2;  // 0x40(0x4)

}; 
