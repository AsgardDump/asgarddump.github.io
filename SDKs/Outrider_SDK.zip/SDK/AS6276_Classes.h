#pragma once 
#include <AS6276_Structs.h>
 
 
 
// BlueprintGeneratedClass AS6276.AS6276_C
// Size: 0x28(Inherited: 0x28) 
struct UAS6276_C : public UMadSkillDataObject
{

	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function AS6276.AS6276_C.GetPrimaryExtraData
}; 



