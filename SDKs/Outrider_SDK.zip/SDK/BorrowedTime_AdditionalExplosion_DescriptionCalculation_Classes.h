#pragma once 
#include <BorrowedTime_AdditionalExplosion_DescriptionCalculation_Structs.h>
 
 
 
// BlueprintGeneratedClass BorrowedTime_AdditionalExplosion_DescriptionCalculation.BorrowedTime_AdditionalExplosion_DescriptionCalculation_C
// Size: 0x28(Inherited: 0x28) 
struct UBorrowedTime_AdditionalExplosion_DescriptionCalculation_C : public UMadSkillDataObject
{

	float GetSecondaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function BorrowedTime_AdditionalExplosion_DescriptionCalculation.BorrowedTime_AdditionalExplosion_DescriptionCalculation_C.GetSecondaryExtraData
	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function BorrowedTime_AdditionalExplosion_DescriptionCalculation.BorrowedTime_AdditionalExplosion_DescriptionCalculation_C.GetPrimaryExtraData
}; 



