#pragma once 
#include <AT64_Structs.h>
 
 
 
// BlueprintGeneratedClass AT64.AT64_C
// Size: 0x28(Inherited: 0x28) 
struct UAT64_C : public UMadSkillDataObject
{

	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function AT64.AT64_C.GetPrimaryExtraData
}; 



