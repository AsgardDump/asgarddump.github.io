#pragma once 
#include <BP_FlameTurret_IncreasedRange_Projectile_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_FlameTurret_IncreasedRange_Projectile.BP_FlameTurret_IncreasedRange_Projectile_C
// Size: 0x608(Inherited: 0x600) 
struct ABP_FlameTurret_IncreasedRange_Projectile_C : public AMadProjectile
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x600(0x8)

	void ReceiveBeginPlay(); // Function BP_FlameTurret_IncreasedRange_Projectile.BP_FlameTurret_IncreasedRange_Projectile_C.ReceiveBeginPlay
	void ExecuteUbergraph_BP_FlameTurret_IncreasedRange_Projectile(int32_t EntryPoint); // Function BP_FlameTurret_IncreasedRange_Projectile.BP_FlameTurret_IncreasedRange_Projectile_C.ExecuteUbergraph_BP_FlameTurret_IncreasedRange_Projectile
}; 



