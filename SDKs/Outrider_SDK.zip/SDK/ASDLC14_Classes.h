#pragma once 
#include <ASDLC14_Structs.h>
 
 
 
// BlueprintGeneratedClass ASDLC14.ASDLC14_C
// Size: 0x28(Inherited: 0x28) 
struct UASDLC14_C : public UMadSkillDataObject
{

	float GetQuaternaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function ASDLC14.ASDLC14_C.GetQuaternaryExtraData
	float GetTertiaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function ASDLC14.ASDLC14_C.GetTertiaryExtraData
	float GetSecondaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function ASDLC14.ASDLC14_C.GetSecondaryExtraData
	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function ASDLC14.ASDLC14_C.GetPrimaryExtraData
}; 



