#pragma once 
#include <AT55_Structs.h>
 
 
 
// BlueprintGeneratedClass AT55.AT55_C
// Size: 0x28(Inherited: 0x28) 
struct UAT55_C : public UMadSkillDataObject
{

	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function AT55.AT55_C.GetPrimaryExtraData
}; 



