#pragma once 
#include <AS28_Structs.h>
 
 
 
// BlueprintGeneratedClass AS28.AS28_C
// Size: 0x28(Inherited: 0x28) 
struct UAS28_C : public UMadSkillDataObject
{

	float GetSecondaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function AS28.AS28_C.GetSecondaryExtraData
	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function AS28.AS28_C.GetPrimaryExtraData
}; 



