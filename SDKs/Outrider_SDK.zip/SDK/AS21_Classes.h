#pragma once 
#include <AS21_Structs.h>
 
 
 
// BlueprintGeneratedClass AS21.AS21_C
// Size: 0x28(Inherited: 0x28) 
struct UAS21_C : public UMadSkillDataObject
{

	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function AS21.AS21_C.GetPrimaryExtraData
}; 



