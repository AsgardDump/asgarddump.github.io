#pragma once 
#include "SDK.h" 
 
 
// Function BP_Enemy_Alien_BoltAction.BP_Enemy_Alien_BoltAction_C.StartLaserFlicker
// Size: 0x4(Inherited: 0x4) 
struct FStartLaserFlicker : public FStartLaserFlicker
{
	float TimeToFlicker;  // 0x0(0x4)

}; 
// Function BP_Enemy_Alien_BoltAction.BP_Enemy_Alien_BoltAction_C.ExecuteUbergraph_BP_Enemy_Alien_BoltAction
// Size: 0x10(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Enemy_Alien_BoltAction
{
	int32_t EntryPoint;  // 0x0(0x4)
	float K2Node_Event_TimeToFlicker;  // 0x4(0x4)
	float CallFunc_GetTimelineLength_ReturnValue;  // 0x8(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0xC(0x4)

}; 
