#pragma once 
#include <AS49_Structs.h>
 
 
 
// BlueprintGeneratedClass AS49.AS49_C
// Size: 0x28(Inherited: 0x28) 
struct UAS49_C : public UMadSkillDataObject
{

	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function AS49.AS49_C.GetPrimaryExtraData
}; 



