#pragma once 
#include <BP_Enemy_Flamethrower_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Enemy_Flamethrower.BP_Enemy_Flamethrower_C
// Size: 0x1FA0(Inherited: 0x1FA0) 
struct ABP_Enemy_Flamethrower_C : public AMadFlamethrower
{

}; 



