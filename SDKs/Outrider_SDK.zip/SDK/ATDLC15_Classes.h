#pragma once 
#include <ATDLC15_Structs.h>
 
 
 
// BlueprintGeneratedClass ATDLC15.ATDLC15_C
// Size: 0x28(Inherited: 0x28) 
struct UATDLC15_C : public UMadSkillDataObject
{

	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function ATDLC15.ATDLC15_C.GetPrimaryExtraData
}; 



