#pragma once 
#include <AN35_Structs.h>
 
 
 
// BlueprintGeneratedClass AN35.AN35_C
// Size: 0x28(Inherited: 0x28) 
struct UAN35_C : public UMadSkillDataObject
{

	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function AN35.AN35_C.GetPrimaryExtraData
}; 



