#pragma once 
#include <AN47_Structs.h>
 
 
 
// BlueprintGeneratedClass AN47.AN47_C
// Size: 0x28(Inherited: 0x28) 
struct UAN47_C : public UMadSkillDataObject
{

	float GetSecondaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function AN47.AN47_C.GetSecondaryExtraData
	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function AN47.AN47_C.GetPrimaryExtraData
}; 



