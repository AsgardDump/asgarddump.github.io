#pragma once 
#include <BP_Ally_AssaultRifle_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Ally_AssaultRifle.BP_Ally_AssaultRifle_C
// Size: 0x1F90(Inherited: 0x1F90) 
struct ABP_Ally_AssaultRifle_C : public ABP_AssaultRifle_C
{

}; 



