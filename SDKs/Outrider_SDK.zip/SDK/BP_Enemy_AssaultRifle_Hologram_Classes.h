#pragma once 
#include <BP_Enemy_AssaultRifle_Hologram_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Enemy_AssaultRifle_Hologram.BP_Enemy_AssaultRifle_Hologram_C
// Size: 0x1FB4(Inherited: 0x1F90) 
struct ABP_Enemy_AssaultRifle_Hologram_C : public ABP_Enemy_AssaultRifle_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x1F90(0x8)
	float HideWeapon_HideWeapon_752731C14C5DA400771139BB79525C0A;  // 0x1F98(0x4)
	char ETimelineDirection HideWeapon__Direction_752731C14C5DA400771139BB79525C0A;  // 0x1F9C(0x1)
	char pad_8093[3];  // 0x1F9D(0x3)
	struct UTimelineComponent* HideWeapon;  // 0x1FA0(0x8)
	struct UMaterialInstanceDynamic* WeaponMI;  // 0x1FA8(0x8)
	float StartZ;  // 0x1FB0(0x4)

	void HideWeapon__FinishedFunc(); // Function BP_Enemy_AssaultRifle_Hologram.BP_Enemy_AssaultRifle_Hologram_C.HideWeapon__FinishedFunc
	void HideWeapon__UpdateFunc(); // Function BP_Enemy_AssaultRifle_Hologram.BP_Enemy_AssaultRifle_Hologram_C.HideWeapon__UpdateFunc
	void HideHoloWeapon(); // Function BP_Enemy_AssaultRifle_Hologram.BP_Enemy_AssaultRifle_Hologram_C.HideHoloWeapon
	void ReceiveBeginPlay(); // Function BP_Enemy_AssaultRifle_Hologram.BP_Enemy_AssaultRifle_Hologram_C.ReceiveBeginPlay
	void ExecuteUbergraph_BP_Enemy_AssaultRifle_Hologram(int32_t EntryPoint); // Function BP_Enemy_AssaultRifle_Hologram.BP_Enemy_AssaultRifle_Hologram_C.ExecuteUbergraph_BP_Enemy_AssaultRifle_Hologram
}; 



