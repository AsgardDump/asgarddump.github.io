#pragma once 
#include <ASDLC12_Structs.h>
 
 
 
// BlueprintGeneratedClass ASDLC12.ASDLC12_C
// Size: 0x28(Inherited: 0x28) 
struct UASDLC12_C : public UMadSkillDataObject
{

	float GetSecondaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function ASDLC12.ASDLC12_C.GetSecondaryExtraData
	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function ASDLC12.ASDLC12_C.GetPrimaryExtraData
}; 



