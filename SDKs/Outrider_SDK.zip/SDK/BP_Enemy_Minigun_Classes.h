#pragma once 
#include <BP_Enemy_Minigun_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Enemy_Minigun.BP_Enemy_Minigun_C
// Size: 0x2060(Inherited: 0x2060) 
struct ABP_Enemy_Minigun_C : public AMadMinigun
{

}; 



