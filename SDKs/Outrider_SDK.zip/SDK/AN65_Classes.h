#pragma once 
#include <AN65_Structs.h>
 
 
 
// BlueprintGeneratedClass AN65.AN65_C
// Size: 0x28(Inherited: 0x28) 
struct UAN65_C : public UMadSkillDataObject
{

	float GetSecondaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function AN65.AN65_C.GetSecondaryExtraData
	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function AN65.AN65_C.GetPrimaryExtraData
}; 



