#pragma once 
#include <BP_BackendCurveTables_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_BackendCurveTables.BP_BackendCurveTables_C
// Size: 0x1E0(Inherited: 0x1E0) 
struct UBP_BackendCurveTables_C : public UMadBackendCurveTables
{

}; 



