#pragma once 
#include "SDK.h" 
 
 
// Function BlackHole_SkillData.BlackHole_SkillData_C.GetCalculatedDamage
// Size: 0x40(Inherited: 0x10) 
struct FGetCalculatedDamage : public FGetCalculatedDamage
{
	struct AMadBaseCharacter* MadInstigatorCharacter;  // 0x0(0x8)
	float ReturnValue;  // 0x8(0x4)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool CallFunc_GetFloatAttribute_bSuccessfullyFoundAttribute : 1;  // 0xC(0x1)
	float CallFunc_GetFloatAttribute_ReturnValue;  // 0x10(0x4)
	char pad_33_1 : 7;  // 0x21(0x1)
	bool CallFunc_GetFloatAttribute_bSuccessfullyFoundAttribute_2 : 1;  // 0x14(0x1)
	float CallFunc_GetFloatAttribute_ReturnValue_2;  // 0x18(0x4)
	char EEvaluateCurveTableResult CallFunc_EvaluateCurveTableRow_OutResult;  // 0x1C(0x1)
	float CallFunc_EvaluateCurveTableRow_OutXY;  // 0x20(0x4)
	char pad_43_1 : 7;  // 0x2B(0x1)
	bool CallFunc_GetFloatAttribute_bSuccessfullyFoundAttribute_3 : 1;  // 0x24(0x1)
	float CallFunc_GetFloatAttribute_ReturnValue_3;  // 0x28(0x4)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x2C(0x1)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x30(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0x34(0x4)
	int32_t CallFunc_FCeil_ReturnValue;  // 0x38(0x4)
	float CallFunc_Conv_IntToFloat_ReturnValue;  // 0x3C(0x4)

}; 
