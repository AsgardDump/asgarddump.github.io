#pragma once 
#include <AT28_Structs.h>
 
 
 
// BlueprintGeneratedClass AT28.AT28_C
// Size: 0x28(Inherited: 0x28) 
struct UAT28_C : public UMadSkillDataObject
{

	float GetSecondaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function AT28.AT28_C.GetSecondaryExtraData
	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function AT28.AT28_C.GetPrimaryExtraData
}; 



