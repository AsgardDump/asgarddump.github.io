#pragma once 
#include <AN12_Structs.h>
 
 
 
// BlueprintGeneratedClass AN12.AN12_C
// Size: 0x28(Inherited: 0x28) 
struct UAN12_C : public UMadSkillDataObject
{

	float GetSecondaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function AN12.AN12_C.GetSecondaryExtraData
	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function AN12.AN12_C.GetPrimaryExtraData
}; 



