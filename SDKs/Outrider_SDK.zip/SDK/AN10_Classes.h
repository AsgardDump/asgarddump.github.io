#pragma once 
#include <AN10_Structs.h>
 
 
 
// BlueprintGeneratedClass AN10.AN10_C
// Size: 0x28(Inherited: 0x28) 
struct UAN10_C : public UMadSkillDataObject
{

	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function AN10.AN10_C.GetPrimaryExtraData
}; 



