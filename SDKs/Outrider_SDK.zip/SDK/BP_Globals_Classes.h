#pragma once 
#include <BP_Globals_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Globals.BP_Globals_C
// Size: 0xDF8(Inherited: 0xDF8) 
struct UBP_Globals_C : public UMadGlobals
{

}; 



