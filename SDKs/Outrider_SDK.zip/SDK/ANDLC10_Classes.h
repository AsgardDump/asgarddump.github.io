#pragma once 
#include <ANDLC10_Structs.h>
 
 
 
// BlueprintGeneratedClass ANDLC10.ANDLC10_C
// Size: 0x28(Inherited: 0x28) 
struct UANDLC10_C : public UMadSkillDataObject
{

	float GetSecondaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function ANDLC10.ANDLC10_C.GetSecondaryExtraData
	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function ANDLC10.ANDLC10_C.GetPrimaryExtraData
}; 



