#pragma once 
#include <AT53_Structs.h>
 
 
 
// BlueprintGeneratedClass AT53.AT53_C
// Size: 0x28(Inherited: 0x28) 
struct UAT53_C : public UMadSkillDataObject
{

	float GetTertiaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function AT53.AT53_C.GetTertiaryExtraData
	float GetSecondaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function AT53.AT53_C.GetSecondaryExtraData
	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function AT53.AT53_C.GetPrimaryExtraData
}; 



