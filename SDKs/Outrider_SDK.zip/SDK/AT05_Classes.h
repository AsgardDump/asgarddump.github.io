#pragma once 
#include <AT05_Structs.h>
 
 
 
// BlueprintGeneratedClass AT05.AT05_C
// Size: 0x28(Inherited: 0x28) 
struct UAT05_C : public UMadSkillDataObject
{

	float GetTertiaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function AT05.AT05_C.GetTertiaryExtraData
	float GetSecondaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function AT05.AT05_C.GetSecondaryExtraData
	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function AT05.AT05_C.GetPrimaryExtraData
}; 



