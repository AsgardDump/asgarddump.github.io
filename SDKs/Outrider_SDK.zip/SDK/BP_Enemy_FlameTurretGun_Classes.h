#pragma once 
#include <BP_Enemy_FlameTurretGun_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Enemy_FlameTurretGun.BP_Enemy_FlameTurretGun_C
// Size: 0x1FA0(Inherited: 0x1FA0) 
struct ABP_Enemy_FlameTurretGun_C : public AMadFlamethrower
{

}; 



