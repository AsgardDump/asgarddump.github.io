#pragma once 
#include <ATDLC20_Structs.h>
 
 
 
// BlueprintGeneratedClass ATDLC20.ATDLC20_C
// Size: 0x28(Inherited: 0x28) 
struct UATDLC20_C : public UMadSkillDataObject
{

	float GetSecondaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function ATDLC20.ATDLC20_C.GetSecondaryExtraData
	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function ATDLC20.ATDLC20_C.GetPrimaryExtraData
}; 



