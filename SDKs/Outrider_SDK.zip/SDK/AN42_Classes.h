#pragma once 
#include <AN42_Structs.h>
 
 
 
// BlueprintGeneratedClass AN42.AN42_C
// Size: 0x28(Inherited: 0x28) 
struct UAN42_C : public UMadSkillDataObject
{

	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function AN42.AN42_C.GetPrimaryExtraData
}; 



