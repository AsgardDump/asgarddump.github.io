#pragma once 
#include <AutoShotgunFOVCameraShake_Structs.h>
 
 
 
// BlueprintGeneratedClass AutoShotgunFOVCameraShake.AutoShotgunFOVCameraShake_C
// Size: 0x160(Inherited: 0x160) 
struct UAutoShotgunFOVCameraShake_C : public UCameraShake
{

}; 



