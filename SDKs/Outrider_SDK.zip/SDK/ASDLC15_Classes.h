#pragma once 
#include <ASDLC15_Structs.h>
 
 
 
// BlueprintGeneratedClass ASDLC15.ASDLC15_C
// Size: 0x28(Inherited: 0x28) 
struct UASDLC15_C : public UMadSkillDataObject
{

	float GetSecondaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function ASDLC15.ASDLC15_C.GetSecondaryExtraData
	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function ASDLC15.ASDLC15_C.GetPrimaryExtraData
}; 



