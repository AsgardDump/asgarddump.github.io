#pragma once 
#include "SDK.h" 
 
 
// Function BP_Enemy_AssaultRifle_Hologram.BP_Enemy_AssaultRifle_Hologram_C.ExecuteUbergraph_BP_Enemy_AssaultRifle_Hologram
// Size: 0x48(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Enemy_AssaultRifle_Hologram
{
	int32_t EntryPoint;  // 0x0(0x4)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x4(0xC)
	float CallFunc_BreakVector_X;  // 0x10(0x4)
	float CallFunc_BreakVector_Y;  // 0x14(0x4)
	float CallFunc_BreakVector_Z;  // 0x18(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0x1C(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue_2;  // 0x20(0x4)
	float CallFunc_Lerp_ReturnValue;  // 0x24(0x4)
	struct UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue;  // 0x28(0x8)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_2;  // 0x30(0xC)
	char pad_60[4];  // 0x3C(0x4)
	struct UAudioComponent* CallFunc_SpawnSoundAtLocation_ReturnValue;  // 0x40(0x8)

}; 
