#pragma once 
#include <BP_Enemy_Alien_Cpt_BoltAction_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Enemy_Alien_Cpt_BoltAction.BP_Enemy_Alien_Cpt_BoltAction_C
// Size: 0x1FF8(Inherited: 0x1FE0) 
struct ABP_Enemy_Alien_Cpt_BoltAction_C : public AMadBoltAction
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x1FE0(0x8)
	float LaserFlicker_Alpha_6A38773647FFFA8C359CCE8264843220;  // 0x1FE8(0x4)
	char ETimelineDirection LaserFlicker__Direction_6A38773647FFFA8C359CCE8264843220;  // 0x1FEC(0x1)
	char pad_8173[3];  // 0x1FED(0x3)
	struct UTimelineComponent* LaserFlicker;  // 0x1FF0(0x8)

	void LaserFlicker__FinishedFunc(); // Function BP_Enemy_Alien_Cpt_BoltAction.BP_Enemy_Alien_Cpt_BoltAction_C.LaserFlicker__FinishedFunc
	void LaserFlicker__UpdateFunc(); // Function BP_Enemy_Alien_Cpt_BoltAction.BP_Enemy_Alien_Cpt_BoltAction_C.LaserFlicker__UpdateFunc
	void StartLaserFlicker(float TimeToFlicker); // Function BP_Enemy_Alien_Cpt_BoltAction.BP_Enemy_Alien_Cpt_BoltAction_C.StartLaserFlicker
	void ReceiveBeginPlay(); // Function BP_Enemy_Alien_Cpt_BoltAction.BP_Enemy_Alien_Cpt_BoltAction_C.ReceiveBeginPlay
	void ExecuteUbergraph_BP_Enemy_Alien_Cpt_BoltAction(int32_t EntryPoint); // Function BP_Enemy_Alien_Cpt_BoltAction.BP_Enemy_Alien_Cpt_BoltAction_C.ExecuteUbergraph_BP_Enemy_Alien_Cpt_BoltAction
}; 



