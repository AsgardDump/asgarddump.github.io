#pragma once 
#include "SDK.h" 
 
 
// ScriptStruct AnimFramework.AnimNode_RootBoneDelay
// Size: 0x48(Inherited: 0x10) 
struct FAnimNode_RootBoneDelay : public FAnimNode_Base
{
	struct FPoseLink BasePose;  // 0x10(0x10)
	char pad_32[12];  // 0x20(0xC)
	struct FVector InputDeltaMovementWS;  // 0x2C(0xC)
	float MaxBlendSpeed;  // 0x38(0x4)
	float MinBlendSpeed;  // 0x3C(0x4)
	float MaxDistanceFromAnimationPose;  // 0x40(0x4)
	char pad_68_1 : 7;  // 0x44(0x1)
	bool bApplyReceivedDelta : 1;  // 0x44(0x1)
	char pad_69_1 : 7;  // 0x45(0x1)
	bool bIgnoreZAxis : 1;  // 0x45(0x1)
	char pad_70_1 : 7;  // 0x46(0x1)
	bool bActive : 1;  // 0x46(0x1)
	char pad_71[1];  // 0x47(0x1)

}; 
// ScriptStruct AnimFramework.AnimNode_CableDynamics
// Size: 0x190(Inherited: 0xD0) 
struct FAnimNode_CableDynamics : public FAnimNode_SkeletalControlBase
{
	struct FBoneReference StartBone;  // 0xD0(0x10)
	struct FBoneReference EndBone;  // 0xE0(0x10)
	int32_t NumSegments;  // 0xF0(0x4)
	int32_t SolverIterations;  // 0xF4(0x4)
	float SubstepTime;  // 0xF8(0x4)
	float Damping;  // 0xFC(0x4)
	struct TArray<struct FBoneReference> CollidingBones;  // 0x100(0x10)
	char pad_272[128];  // 0x110(0x80)

}; 
// ScriptStruct AnimFramework.PcfAnimNode_BakeToIK
// Size: 0xF0(Inherited: 0xD0) 
struct FPcfAnimNode_BakeToIK : public FAnimNode_SkeletalControlBase
{
	struct TArray<struct FPcfBakeToIKNodeEffector> Effectors;  // 0xD0(0x10)
	struct TArray<struct FVector> IkTargetsWorldSpace;  // 0xE0(0x10)

}; 
// DelegateFunction AnimFramework.CinematicReady__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FCinematicReady__DelegateSignature
{
	struct ULevelSequence* Sequence;  // 0x0(0x8)

}; 
// ScriptStruct AnimFramework.AnimNode_BoneDrivenControllerSplitted
// Size: 0x110(Inherited: 0xD0) 
struct FAnimNode_BoneDrivenControllerSplitted : public FAnimNode_SkeletalControlBase
{
	struct FComponentSpacePoseLink SourcePose;  // 0xD0(0x10)
	struct TArray<struct FBoneControllerMapping> Mapping;  // 0xE0(0x10)
	uint8_t  DestinationMode;  // 0xF0(0x1)
	uint8_t  ModificationMode;  // 0xF1(0x1)
	char pad_242_1 : 7;  // 0xF2(0x1)
	bool bUseAbsoluteValue : 1;  // 0xF2(0x1)
	char pad_243_1 : 7;  // 0xF3(0x1)
	bool bUsePositiveOnly : 1;  // 0xF3(0x1)
	char pad_244_1 : 7;  // 0xF4(0x1)
	bool bUseNegativeOnly : 1;  // 0xF4(0x1)
	char pad_245[3];  // 0xF5(0x3)
	float Multiplier;  // 0xF8(0x4)
	char pad_252_1 : 7;  // 0xFC(0x1)
	bool bUseRange : 1;  // 0xFC(0x1)
	char pad_253[3];  // 0xFD(0x3)
	float RangeMin;  // 0x100(0x4)
	float RangeMax;  // 0x104(0x4)
	float RemappedMin;  // 0x108(0x4)
	float RemappedMax;  // 0x10C(0x4)

}; 
// ScriptStruct AnimFramework.AnimNode_AnimDynamicsAxisLock
// Size: 0x460(Inherited: 0x450) 
struct FAnimNode_AnimDynamicsAxisLock : public FAnimNode_AnimDynamics
{
	char bDontAffectTargetTranslationX : 1;  // 0x450(0x1)
	char bDontAffectTargetTranslationY : 1;  // 0x450(0x1)
	char bDontAffectTargetTranslationZ : 1;  // 0x450(0x1)
	char bDontAffectTargetRotationX : 1;  // 0x450(0x1)
	char bDontAffectTargetRotationY : 1;  // 0x450(0x1)
	char bDontAffectTargetRotationZ : 1;  // 0x450(0x1)
	char bDontAffectTargetScaleX : 1;  // 0x450(0x1)
	char bDontAffectTargetScaleY : 1;  // 0x450(0x1)
	char bDontAffectTargetScaleZ : 1;  // 0x451(0x1)
	char pad_1105_1 : 7;  // 0x451(0x1)
	char pad_1106[15];  // 0x452(0xF)

}; 
// ScriptStruct AnimFramework.BlendBetweenTwoPositions
// Size: 0x14(Inherited: 0x0) 
struct FBlendBetweenTwoPositions
{
	float BlendSpeed;  // 0x0(0x4)
	float PositionToStartBlend;  // 0x4(0x4)
	float PositionToFullBlend;  // 0x8(0x4)
	char pad_12[8];  // 0xC(0x8)

}; 
// ScriptStruct AnimFramework.PcfBakeToIKNodeEffector
// Size: 0xB0(Inherited: 0x0) 
struct FPcfBakeToIKNodeEffector
{
	struct FAnimBakeToTwoBoneIK EndEffector;  // 0x0(0x90)
	struct FBoneReference IKTargetBone;  // 0x90(0x10)
	struct FVector IKTargetOffsetComponentSpace;  // 0xA0(0xC)
	char pad_172_1 : 7;  // 0xAC(0x1)
	bool bTransformSwivelAngleBasedOnTarget : 1;  // 0xAC(0x1)
	char pad_173_1 : 7;  // 0xAD(0x1)
	bool bBakeRotation : 1;  // 0xAD(0x1)
	char pad_174_1 : 7;  // 0xAE(0x1)
	bool bBakeLocation : 1;  // 0xAE(0x1)
	char pad_175[1];  // 0xAF(0x1)

}; 
// ScriptStruct AnimFramework.StateMachineTransition
// Size: 0x10(Inherited: 0x0) 
struct FStateMachineTransition
{
	struct FName MachineName;  // 0x0(0x8)
	struct FName StateName;  // 0x8(0x8)

}; 
// ScriptStruct AnimFramework.AnimNode_ActiveRagdoll
// Size: 0x1E0(Inherited: 0xD0) 
struct FAnimNode_ActiveRagdoll : public FAnimNode_SkeletalControlBase
{
	float CriticalBonesMaxDistanceThreshold;  // 0xD0(0x4)
	float CriticalBonesMinDistanceThreshold;  // 0xD4(0x4)
	float CriticalBonesMaxAngleThreshold;  // 0xD8(0x4)
	float CriticalBonesMinAngleThreshold;  // 0xDC(0x4)
	char pad_224_1 : 7;  // 0xE0(0x1)
	bool bAdjustCriticalBoneWeight : 1;  // 0xE0(0x1)
	char pad_225[3];  // 0xE1(0x3)
	float MaxDistanceThreshold;  // 0xE4(0x4)
	float MinDistanceThreshold;  // 0xE8(0x4)
	float MaxAngleThreshold;  // 0xEC(0x4)
	float MinAngleThreshold;  // 0xF0(0x4)
	char pad_244_1 : 7;  // 0xF4(0x1)
	bool bAdjustBoneWeight : 1;  // 0xF4(0x1)
	char pad_245[3];  // 0xF5(0x3)
	float ForceMaxGain;  // 0xF8(0x4)
	float ForceMinGain;  // 0xFC(0x4)
	float TorqueMaxGain;  // 0x100(0x4)
	float TorqueMinGain;  // 0x104(0x4)
	float LinearBlendSpeed;  // 0x108(0x4)
	float RotationBlendSpeed;  // 0x10C(0x4)
	struct FVector PoseOffset;  // 0x110(0xC)
	float TransitionTime;  // 0x11C(0x4)
	char pad_288_1 : 7;  // 0x120(0x1)
	bool bIgnoreRoot : 1;  // 0x120(0x1)
	char pad_289[7];  // 0x121(0x7)
	struct TArray<struct FBoneReference> CriticalBones;  // 0x128(0x10)
	char pad_312[168];  // 0x138(0xA8)

}; 
// ScriptStruct AnimFramework.AnimNode_ApplyAdditiveConstrained
// Size: 0xE8(Inherited: 0xC8) 
struct FAnimNode_ApplyAdditiveConstrained : public FAnimNode_ApplyAdditive
{
	struct TArray<struct FAnimBakeToTwoBoneIK> EffectorBones;  // 0xC8(0x10)
	struct FLODBlendProperties IKLODBlend;  // 0xD8(0xC)
	char pad_228[4];  // 0xE4(0x4)

}; 
// Function AnimFramework.FWAnimInstance_Base.RequestRootMotionAdjustment
// Size: 0x58(Inherited: 0x0) 
struct FRequestRootMotionAdjustment
{
	struct FAnimRootMotionAdjusterTargetData InAdjData;  // 0x0(0x50)
	int32_t ReturnValue;  // 0x50(0x4)
	char pad_84[4];  // 0x54(0x4)

}; 
// ScriptStruct AnimFramework.FiringDataSetup
// Size: 0x18(Inherited: 0x0) 
struct FFiringDataSetup
{
	struct UAnimSequence* StartSequence;  // 0x0(0x8)
	struct UAnimSequence* LoopSequence;  // 0x8(0x8)
	struct UAnimSequence* StopSequence;  // 0x10(0x8)

}; 
// ScriptStruct AnimFramework.AnimNode_BlendListByObjectType
// Size: 0xB0(Inherited: 0x98) 
struct FAnimNode_BlendListByObjectType : public FAnimNode_BlendListBase
{
	struct TArray<UObject*> ObjectTypes;  // 0x98(0x10)
	UObject* InputType;  // 0xA8(0x8)

}; 
// ScriptStruct AnimFramework.BoneControllerMapping
// Size: 0x34(Inherited: 0x0) 
struct FBoneControllerMapping
{
	struct FBoneReference Source;  // 0x0(0x10)
	struct FBoneReference Destination;  // 0x10(0x10)
	struct FComponentMapping Mapping[9];  // 0x20(0x12)
	char pad_50[2];  // 0x32(0x2)

}; 
// ScriptStruct AnimFramework.AnimNode_IKAttachment
// Size: 0x210(Inherited: 0xD0) 
struct FAnimNode_IKAttachment : public FAnimNode_SkeletalControlBase
{
	struct FSocketReference AttachmentSocket;  // 0xD0(0x40)
	struct FAnimBakeToTwoBoneIK AttachingBone;  // 0x110(0x90)
	struct FSocketReference AttachingOffsetSocket;  // 0x1A0(0x40)
	struct FVector ExtraOffsetLocalSpace;  // 0x1E0(0xC)
	char pad_492_1 : 7;  // 0x1EC(0x1)
	bool bMoveSwivelAngleToSolverSpace : 1;  // 0x1EC(0x1)
	char pad_493_1 : 7;  // 0x1ED(0x1)
	bool bCalculateDistanceUsingExtraOffsetLocalSpace : 1;  // 0x1ED(0x1)
	char pad_494[2];  // 0x1EE(0x2)
	float DistanceToStartIKBlend;  // 0x1F0(0x4)
	float DistanceForFullIKBlend;  // 0x1F4(0x4)
	float IKBlendSpeedIn;  // 0x1F8(0x4)
	float IKBlendSpeedOut;  // 0x1FC(0x4)
	char pad_512[16];  // 0x200(0x10)

}; 
// ScriptStruct AnimFramework.BlendInTime
// Size: 0x18(Inherited: 0x0) 
struct FBlendInTime
{
	float BlendTime;  // 0x0(0x4)
	char pad_4[20];  // 0x4(0x14)

}; 
// ScriptStruct AnimFramework.ComponentMapping
// Size: 0x2(Inherited: 0x0) 
struct FComponentMapping
{
	char EComponentType Destination;  // 0x0(0x1)
	char EComponentType Source;  // 0x1(0x1)

}; 
// ScriptStruct AnimFramework.AnimNode_LayeredBoneBlendPerAxis
// Size: 0xD8(Inherited: 0xC0) 
struct FAnimNode_LayeredBoneBlendPerAxis : public FAnimNode_LayeredBoneBlend
{
	struct TArray<struct FBoneReference> BonesForBlending;  // 0xC0(0x10)
	char bDontAffectTargetTranslationX : 1;  // 0xD0(0x1)
	char bDontAffectTargetTranslationY : 1;  // 0xD0(0x1)
	char bDontAffectTargetTranslationZ : 1;  // 0xD0(0x1)
	char bDontAffectTargetRotationX : 1;  // 0xD0(0x1)
	char bDontAffectTargetRotationY : 1;  // 0xD0(0x1)
	char bDontAffectTargetRotationZ : 1;  // 0xD0(0x1)
	char bDontAffectTargetScaleX : 1;  // 0xD0(0x1)
	char bDontAffectTargetScaleY : 1;  // 0xD0(0x1)
	char bDontAffectTargetScaleZ : 1;  // 0xD1(0x1)
	char pad_209_1 : 7;  // 0xD1(0x1)
	char pad_210[7];  // 0xD2(0x7)

}; 
// ScriptStruct AnimFramework.AnimNode_FootPlacement
// Size: 0x168(Inherited: 0xD0) 
struct FAnimNode_FootPlacement : public FAnimNode_SkeletalControlBase
{
	struct TArray<struct FFootPlacementData> FeetPlacement;  // 0xD0(0x10)
	struct FPelvisAdjustmentData PelvisAdjustmentData;  // 0xE0(0x60)
	struct FVector UpVector;  // 0x140(0xC)
	float AverageFootDisplacementToPelvisWeight;  // 0x14C(0x4)
	char pad_336_1 : 7;  // 0x150(0x1)
	bool bScaleDistancesBasedOnMeshScale : 1;  // 0x150(0x1)
	char pad_337_1 : 7;  // 0x151(0x1)
	bool bAdjustFootRotation : 1;  // 0x151(0x1)
	char pad_338_1 : 7;  // 0x152(0x1)
	bool bOnlyCastRayForBallBone : 1;  // 0x152(0x1)
	char pad_339[1];  // 0x153(0x1)
	int32_t RotationLODThreshold;  // 0x154(0x4)
	float BallRayWeight;  // 0x158(0x4)
	float HeelRayWeight;  // 0x15C(0x4)
	char pad_352[8];  // 0x160(0x8)

}; 
// ScriptStruct AnimFramework.MovementMoodData
// Size: 0x80(Inherited: 0x0) 
struct FMovementMoodData
{
	struct UAnimSequence* Idle;  // 0x0(0x8)
	struct UBlendSpaceBase* TurnInPlace;  // 0x8(0x8)
	struct UAimOffsetBlendSpace* AimOffset;  // 0x10(0x8)
	struct UBlendSpaceBase* Movement_LDown;  // 0x18(0x8)
	struct UBlendSpaceBase* Movement_RDown;  // 0x20(0x8)
	struct UBlendSpaceBase* MovementToIdle_LDown;  // 0x28(0x8)
	struct UBlendSpaceBase* MovementToIdle_RDown;  // 0x30(0x8)
	struct UAnimMontage* MantleOverCover;  // 0x38(0x8)
	struct UAnimSequence* IdleMovementMoodTransitions[8];  // 0x40(0x40)

}; 
// ScriptStruct AnimFramework.PelvisAdjustmentData
// Size: 0x60(Inherited: 0x0) 
struct FPelvisAdjustmentData
{
	char pad_0[8];  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bAdjustPelvis : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	struct FBoneReference PelvisBone;  // 0xC(0x10)
	struct FVectorRK4SpringInterpolator PelvisOffsetInterpolator;  // 0x1C(0x8)
	char pad_36[60];  // 0x24(0x3C)

}; 
// ScriptStruct AnimFramework.FootPlacementData
// Size: 0x360(Inherited: 0x0) 
struct FFootPlacementData
{
	struct FAnimBakeToTwoBoneIK BoneIK;  // 0x0(0x90)
	struct FRayCastData RayCastingData;  // 0x90(0x220)
	char pad_688[176];  // 0x2B0(0xB0)

}; 
// Function AnimFramework.FWAnimInstance_Base.UpdateRootMotionAdjustmentTarget
// Size: 0x2C(Inherited: 0x0) 
struct FUpdateRootMotionAdjustmentTarget
{
	int32_t AdjusterId;  // 0x0(0x4)
	struct FVector InTargetPosWS;  // 0x4(0xC)
	struct FRotator InTargetRotWS;  // 0x10(0xC)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool bUseMaxAllowedDistanceError : 1;  // 0x1C(0x1)
	char pad_29[3];  // 0x1D(0x3)
	float MaxAllowedDistanceError;  // 0x20(0x4)
	char pad_36_1 : 7;  // 0x24(0x1)
	bool bUseMaxAllowedAngleError : 1;  // 0x24(0x1)
	char pad_37[3];  // 0x25(0x3)
	float MaxAllowedAngleError;  // 0x28(0x4)

}; 
// ScriptStruct AnimFramework.RayCastData
// Size: 0x220(Inherited: 0x0) 
struct FRayCastData
{
	struct FBoneReference FootBone;  // 0x0(0x10)
	struct FBoneReference BallBone;  // 0x10(0x10)
	char ECollisionChannel CollisionChannel;  // 0x20(0x1)
	char pad_33_1 : 7;  // 0x21(0x1)
	bool bTraceComplex : 1;  // 0x21(0x1)
	char pad_34_1 : 7;  // 0x22(0x1)
	bool bKeepRefPoseRotWhilePlanted : 1;  // 0x22(0x1)
	char pad_35[1];  // 0x23(0x1)
	struct FRayPosition RaySettings;  // 0x24(0x24)
	struct FRayHitBlendLocation FootLocation;  // 0x48(0x34)
	char pad_124[52];  // 0x7C(0x34)
	struct FRayHitRotation BallRotation;  // 0xB0(0x40)
	char pad_240[64];  // 0xF0(0x40)
	struct FRayHitRotation HeelRotation;  // 0x130(0x40)
	float FootAngleLimit;  // 0x170(0x4)
	float FootWidth;  // 0x174(0x4)
	float FootAdjustmentBlendSpeed;  // 0x178(0x4)
	float OffsetFromGround;  // 0x17C(0x4)
	char pad_384[160];  // 0x180(0xA0)

}; 
// Function AnimFramework.FWAnimInstance_Base.TurnOnRagdoll
// Size: 0x8(Inherited: 0x0) 
struct FTurnOnRagdoll
{
	float TransitionTime;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool ReturnValue : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)

}; 
// ScriptStruct AnimFramework.RayHitRotation
// Size: 0x40(Inherited: 0x0) 
struct FRayHitRotation
{
	struct FBlendInTime BlendPositionToHitPoint;  // 0x0(0x18)
	float TargetToTargetBlendSpeed;  // 0x18(0x4)
	char pad_28[36];  // 0x1C(0x24)

}; 
// ScriptStruct AnimFramework.RayHitBlendLocation
// Size: 0x34(Inherited: 0x0) 
struct FRayHitBlendLocation
{
	struct FBlendInTime BlendPositionToHitPoint;  // 0x0(0x18)
	float TargetToTargetBlendSpeed;  // 0x18(0x4)
	char pad_28[24];  // 0x1C(0x18)

}; 
// Function AnimFramework.AnimProxyBasedAnimInstance.GetRelevantGateTimeRemaining
// Size: 0xC(Inherited: 0x0) 
struct FGetRelevantGateTimeRemaining
{
	int32_t MachineIndex;  // 0x0(0x4)
	int32_t StateIndex;  // 0x4(0x4)
	float ReturnValue;  // 0x8(0x4)

}; 
// ScriptStruct AnimFramework.RayPosition
// Size: 0x24(Inherited: 0x0) 
struct FRayPosition
{
	float StartRayOffset;  // 0x0(0x4)
	float EndRayOffsetMin;  // 0x4(0x4)
	float EndRayOffsetMax;  // 0x8(0x4)
	struct FBlendBetweenTwoPositions FootPositionForEndRayOffsetBlend;  // 0xC(0x14)
	char pad_32[4];  // 0x20(0x4)

}; 
// Function AnimFramework.FWAnimInstance_Base.RequestRootMotionAdjustmentOnSurface
// Size: 0x38(Inherited: 0x0) 
struct FRequestRootMotionAdjustmentOnSurface
{
	struct FVector InTargetPosWS;  // 0x0(0xC)
	char pad_12[4];  // 0xC(0x4)
	struct UAnimMontage* AnimMontage;  // 0x10(0x8)
	float AdjustmentStartTime;  // 0x18(0x4)
	float AdjustmentEndTime;  // 0x1C(0x4)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool bAdjustAbsolute : 1;  // 0x20(0x1)
	char pad_33[3];  // 0x21(0x3)
	float MaxDistanceErrorAllowed;  // 0x24(0x4)
	struct UCurveFloat* InterpolationCurve;  // 0x28(0x8)
	int32_t ReturnValue;  // 0x30(0x4)
	char pad_52[4];  // 0x34(0x4)

}; 
// ScriptStruct AnimFramework.AnimNode_TransitionsGate
// Size: 0x128(Inherited: 0x98) 
struct FAnimNode_TransitionsGate : public FAnimNode_BlendListBase
{
	int32_t ActiveChildIndex;  // 0x98(0x4)
	char pad_156[4];  // 0x9C(0x4)
	struct FTransitionRequest AwaitingAnimation;  // 0xA0(0x48)
	float PositionToJump;  // 0xE8(0x4)
	char pad_236[20];  // 0xEC(0x14)
	float BlendWeight;  // 0x100(0x4)
	char pad_260_1 : 7;  // 0x104(0x1)
	bool bIgnoreForRelevancyTest : 1;  // 0x104(0x1)
	char pad_261[3];  // 0x105(0x3)
	struct FName GateName;  // 0x108(0x8)
	char pad_272[24];  // 0x110(0x18)

}; 
// ScriptStruct AnimFramework.AnimNode_ExtendedFootPlacement
// Size: 0x1F0(Inherited: 0x168) 
struct FAnimNode_ExtendedFootPlacement : public FAnimNode_FootPlacement
{
	struct FSpineAdjustmentData SpineAdjustmentData;  // 0x168(0x88)

}; 
// ScriptStruct AnimFramework.SpineAdjustmentData
// Size: 0x88(Inherited: 0x60) 
struct FSpineAdjustmentData : public FPelvisAdjustmentData
{
	struct FBoneReference ChainRootBone;  // 0x60(0x10)
	float BoneLimitDegree;  // 0x70(0x4)
	char pad_116_1 : 7;  // 0x74(0x1)
	bool bKeepTipBoneRotation : 1;  // 0x74(0x1)
	char pad_117_1 : 7;  // 0x75(0x1)
	bool bCastRayForSpine : 1;  // 0x75(0x1)
	char ECollisionChannel CollisionChannel;  // 0x76(0x1)
	char pad_119[17];  // 0x77(0x11)

}; 
// Function AnimFramework.AnimProxyBasedAnimInstance.GetIsCorrectPoseForTransition
// Size: 0x10(Inherited: 0x0) 
struct FGetIsCorrectPoseForTransition
{
	int32_t MachineIndex;  // 0x0(0x4)
	int32_t StateIndex;  // 0x4(0x4)
	int32_t TransitionIndex;  // 0x8(0x4)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool ReturnValue : 1;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)

}; 
// Function AnimFramework.FWAnimInstance_Base.TurnOffRagdoll
// Size: 0x8(Inherited: 0x0) 
struct FTurnOffRagdoll
{
	float TransitionTime;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool ReturnValue : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)

}; 
// ScriptStruct AnimFramework.AnimNode_HandGrip
// Size: 0x1C0(Inherited: 0xD0) 
struct FAnimNode_HandGrip : public FAnimNode_SkeletalControlBase
{
	struct FComponentSpacePoseLink BasePose;  // 0xD0(0x10)
	struct FAnimBakeToTwoBoneIK FollowerBone;  // 0xE0(0x90)
	struct FBoneReference LeaderBone;  // 0x170(0x10)
	struct FVector ExtraOffsetComponentSpace;  // 0x180(0xC)
	struct FVector WeaponScaleWorldSpace;  // 0x18C(0xC)
	struct FBoneReference FkBlendTriggerBone;  // 0x198(0x10)
	float BlendSpeed;  // 0x1A8(0x4)
	float MinDistanceToStartBlending;  // 0x1AC(0x4)
	char pad_432_1 : 7;  // 0x1B0(0x1)
	bool bOverrideMaxDistanceFromStretchedIKChain : 1;  // 0x1B0(0x1)
	char pad_433[3];  // 0x1B1(0x3)
	float OverridenMaxDistanceFromStretchedIKChain;  // 0x1B4(0x4)
	char pad_440[8];  // 0x1B8(0x8)

}; 
// ScriptStruct AnimFramework.AnimNode_LayeredBoneBlendConstrained
// Size: 0x108(Inherited: 0xC0) 
struct FAnimNode_LayeredBoneBlendConstrained : public FAnimNode_LayeredBoneBlend
{
	struct TArray<struct FAnimBakeToTwoBoneIK> mEffectorBones;  // 0xC0(0x10)
	struct FVector PelvisBoneTranslationBlendMask;  // 0xD0(0xC)
	struct FVector PelvisBoneRotationBlendMask;  // 0xDC(0xC)
	struct FBoneReference PelvisBone;  // 0xE8(0x10)
	int32_t BlendPoseToOverridePelvis;  // 0xF8(0x4)
	struct FLODBlendProperties IKLODBlend;  // 0xFC(0xC)

}; 
// ScriptStruct AnimFramework.AnimNode_LockFoot
// Size: 0x360(Inherited: 0xD0) 
struct FAnimNode_LockFoot : public FAnimNode_SkeletalControlBase
{
	struct FLockedFoot LeftLockedFoot;  // 0xD0(0x110)
	struct FLockedFoot RightLockedFoot;  // 0x1E0(0x110)
	struct FBoneReference pelvis;  // 0x2F0(0x10)
	float MaxDistnaceFromGround;  // 0x300(0x4)
	float MaxDistnaceFromFkPose;  // 0x304(0x4)
	float MaxAngleDifferenceFromFkFoot;  // 0x308(0x4)
	float BlendSpeed;  // 0x30C(0x4)
	float PelvisBlendSpeed;  // 0x310(0x4)
	float FootLengthFactor;  // 0x314(0x4)
	char pad_792_1 : 7;  // 0x318(0x1)
	bool bScaleDistancesBasedOnMeshScale : 1;  // 0x318(0x1)
	char pad_793[71];  // 0x319(0x47)

}; 
// ScriptStruct AnimFramework.LockedFoot
// Size: 0x110(Inherited: 0x0) 
struct FLockedFoot
{
	struct FAnimBakeToTwoBoneIK BakeToIK;  // 0x0(0x90)
	char pad_144[108];  // 0x90(0x6C)
	struct FBoneReference FootBallJoint;  // 0xFC(0x10)
	char pad_268[4];  // 0x10C(0x4)

}; 
// Function AnimFramework.FWAnimInstance_Base.RequestAdjusterTermination
// Size: 0x4(Inherited: 0x0) 
struct FRequestAdjusterTermination
{
	int32_t AdjusterId;  // 0x0(0x4)

}; 
// ScriptStruct AnimFramework.AnimNode_SingleAnimation
// Size: 0x100(Inherited: 0x30) 
struct FAnimNode_SingleAnimation : public FAnimNode_AssetPlayerBase
{
	struct UAnimationAsset* AnimationAsset;  // 0x30(0x8)
	float X;  // 0x38(0x4)
	float Y;  // 0x3C(0x4)
	float Z;  // 0x40(0x4)
	char pad_68[4];  // 0x44(0x4)
	struct UAnimSequenceBase* AsSequence;  // 0x48(0x8)
	struct UBlendSpaceBase* AsBlendSpace;  // 0x50(0x8)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool bLoopAnimation : 1;  // 0x58(0x1)
	char pad_89[3];  // 0x59(0x3)
	float PlayRate;  // 0x5C(0x4)
	float StartAtTime;  // 0x60(0x4)
	float EndNotificationAtTime;  // 0x64(0x4)
	char pad_104[16];  // 0x68(0x10)
	struct FBlendFilter BlendFilter;  // 0x78(0x78)
	struct TArray<struct FBlendSampleData> BlendSampleDataCache;  // 0xF0(0x10)

}; 
// ScriptStruct AnimFramework.TransitionRequest
// Size: 0x48(Inherited: 0x0) 
struct FTransitionRequest
{
	struct UAnimationAsset* AnimationAsset;  // 0x0(0x8)
	float X;  // 0x8(0x4)
	float Y;  // 0xC(0x4)
	float Z;  // 0x10(0x4)
	float PlayRate;  // 0x14(0x4)
	float StartAtTime;  // 0x18(0x4)
	float BlendTime;  // 0x1C(0x4)
	float EndNotificationAtTime;  // 0x20(0x4)
	char bLoopAnimation : 1;  // 0x24(0x1)
	char pad_36_1 : 7;  // 0x24(0x1)
	char pad_37[36];  // 0x25(0x24)

}; 
// ScriptStruct AnimFramework.AnimRootMotionAdjuster
// Size: 0x140(Inherited: 0x0) 
struct FAnimRootMotionAdjuster
{
	struct UAnimMontage* MontageToBeAdjusted;  // 0x0(0x8)
	char pad_8[8];  // 0x8(0x8)
	struct UCurveFloat* WeightCurve;  // 0x10(0x8)
	char pad_24[296];  // 0x18(0x128)

}; 
// Function AnimFramework.StreamableCinematic.GetOrWait
// Size: 0x10(Inherited: 0x0) 
struct FGetOrWait
{
	struct FDelegate Callback;  // 0x0(0x10)

}; 
// ScriptStruct AnimFramework.AnimRootMotionAdjusterTargetData
// Size: 0x50(Inherited: 0x0) 
struct FAnimRootMotionAdjusterTargetData
{
	struct UAnimMontage* AnimMontage;  // 0x0(0x8)
	float AdjustmentStartTime;  // 0x8(0x4)
	float AdjustmentEndTime;  // 0xC(0x4)
	struct UCurveFloat* WeightCurve;  // 0x10(0x8)
	uint8_t  BlendType;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)
	struct FVector TargetLocWS;  // 0x1C(0xC)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool bAdjustLocOnSurface : 1;  // 0x28(0x1)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool bAdjustHeight : 1;  // 0x29(0x1)
	char pad_42_1 : 7;  // 0x2A(0x1)
	bool bUseMaxAllowedDistanceError : 1;  // 0x2A(0x1)
	char pad_43_1 : 7;  // 0x2B(0x1)
	bool bUseMaxLinearSpeedError : 1;  // 0x2B(0x1)
	float MaxAllowedDistanceError;  // 0x2C(0x4)
	float MaxLinearSpeedError;  // 0x30(0x4)
	struct FRotator TargetRotWS;  // 0x34(0xC)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool bAdjustRot : 1;  // 0x40(0x1)
	char pad_65_1 : 7;  // 0x41(0x1)
	bool bJustAdjustYawRotation : 1;  // 0x41(0x1)
	char pad_66_1 : 7;  // 0x42(0x1)
	bool bIsAbsoluteAdjustment : 1;  // 0x42(0x1)
	char pad_67_1 : 7;  // 0x43(0x1)
	bool bUseMaxAllowedAngleError : 1;  // 0x43(0x1)
	char pad_68_1 : 7;  // 0x44(0x1)
	bool bUseMaxAngularSpeedError : 1;  // 0x44(0x1)
	char pad_69[3];  // 0x45(0x3)
	float MaxAllowedAngleError;  // 0x48(0x4)
	float MaxAngularSpeedError;  // 0x4C(0x4)

}; 
// ScriptStruct AnimFramework.CoverDataSetup
// Size: 0x40(Inherited: 0x0) 
struct FCoverDataSetup
{
	struct UAnimSequence* IdleLeft;  // 0x0(0x8)
	struct UAnimSequence* IdleRight;  // 0x8(0x8)
	struct UBlendSpaceBase* MovementToIdle_Left;  // 0x10(0x8)
	struct UBlendSpaceBase* MovementToIdle_Right;  // 0x18(0x8)
	struct UAnimSequence* LeftToRightIdle;  // 0x20(0x8)
	struct UAnimSequence* RightToLeftIdle;  // 0x28(0x8)
	struct TArray<struct FCoverActionDataSetup> CoverActions;  // 0x30(0x10)

}; 
// ScriptStruct AnimFramework.CoverActionDataSetup
// Size: 0x18(Inherited: 0x0) 
struct FCoverActionDataSetup
{
	struct UAnimSequence* StartSequence;  // 0x0(0x8)
	struct UAnimSequence* IdleSequence;  // 0x8(0x8)
	struct UAnimSequence* StopSequence;  // 0x10(0x8)

}; 
// Function AnimFramework.AnimProxyBasedAnimInstance.IsMontagePlayingOnGroup
// Size: 0xC(Inherited: 0x0) 
struct FIsMontagePlayingOnGroup
{
	struct FName InGroupName;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bIncludeBlendingOut : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool ReturnValue : 1;  // 0x9(0x1)
	char pad_10[2];  // 0xA(0x2)

}; 
// ScriptStruct AnimFramework.StateCachedData
// Size: 0x30(Inherited: 0x0) 
struct FStateCachedData
{
	struct FName MachineName;  // 0x0(0x8)
	struct FName StateName;  // 0x8(0x8)
	char pad_16[32];  // 0x10(0x20)

}; 
// ScriptStruct AnimFramework.TransitionGateNodeData
// Size: 0xB0(Inherited: 0x0) 
struct FTransitionGateNodeData
{
	struct FName MachineName;  // 0x0(0x8)
	struct FName StateName;  // 0x8(0x8)
	struct FName GateName;  // 0x10(0x8)
	int32_t MachineIdx;  // 0x18(0x4)
	int32_t StateIdx;  // 0x1C(0x4)
	struct FTransitionRequest AwaitingAnimationRequest;  // 0x20(0x48)
	struct FTransitionRequest OldAnimationRequest;  // 0x68(0x48)

}; 
// Function AnimFramework.FWAnimInstance_Base.IsPlayingSlotAdditiveAnimation
// Size: 0xC(Inherited: 0x0) 
struct FIsPlayingSlotAdditiveAnimation
{
	struct FName SlotNodeName;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)

}; 
// Function AnimFramework.FWAnimInstance_Base.IsRagdollBlending
// Size: 0x1(Inherited: 0x0) 
struct FIsRagdollBlending
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function AnimFramework.FWAnimInstance_Base.IsSlotPlayingAnyAnimation
// Size: 0xC(Inherited: 0x0) 
struct FIsSlotPlayingAnyAnimation
{
	struct FName SlotNodeName;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)

}; 
// Function AnimFramework.FWAnimInstance_Base.RequestRootMotionAdjustmentOnHeight
// Size: 0x38(Inherited: 0x0) 
struct FRequestRootMotionAdjustmentOnHeight
{
	struct FVector InTargetPosWS;  // 0x0(0xC)
	char pad_12[4];  // 0xC(0x4)
	struct UAnimMontage* AnimMontage;  // 0x10(0x8)
	float AdjustmentStartTime;  // 0x18(0x4)
	float AdjustmentEndTime;  // 0x1C(0x4)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool bAdjustAbsolute : 1;  // 0x20(0x1)
	char pad_33[3];  // 0x21(0x3)
	float MaxDistanceErrorAllowed;  // 0x24(0x4)
	struct UCurveFloat* InterpolationCurve;  // 0x28(0x8)
	int32_t ReturnValue;  // 0x30(0x4)
	char pad_52[4];  // 0x34(0x4)

}; 
// Function AnimFramework.FWAnimInstance_Base.RequestRootMotionAdjustmentOnRotation
// Size: 0x38(Inherited: 0x0) 
struct FRequestRootMotionAdjustmentOnRotation
{
	struct FRotator InTargetRotWS;  // 0x0(0xC)
	char pad_12[4];  // 0xC(0x4)
	struct UAnimMontage* AnimMontage;  // 0x10(0x8)
	float AdjustmentStartTime;  // 0x18(0x4)
	float AdjustmentEndTime;  // 0x1C(0x4)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool bAdjustAbsolute : 1;  // 0x20(0x1)
	char pad_33[3];  // 0x21(0x3)
	float MaxDistanceErrorAllowed;  // 0x24(0x4)
	struct UCurveFloat* InterpolationCurve;  // 0x28(0x8)
	int32_t ReturnValue;  // 0x30(0x4)
	char pad_52[4];  // 0x34(0x4)

}; 
// Function AnimFramework.FWAnimInstance_Base.TurnOnRagdollByBones
// Size: 0x20(Inherited: 0x0) 
struct FTurnOnRagdollByBones
{
	float TransitionTime;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct TArray<struct FName> BoneNamesToStartRagdoll;  // 0x8(0x10)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool bIncludeSelf : 1;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool ReturnValue : 1;  // 0x19(0x1)
	char pad_26[6];  // 0x1A(0x6)

}; 
// Function AnimFramework.AnimProxyBasedAnimInstance.GetIsCorrectFootStatusForTransition
// Size: 0x10(Inherited: 0x0) 
struct FGetIsCorrectFootStatusForTransition
{
	int32_t MachineIndex;  // 0x0(0x4)
	int32_t StateIndex;  // 0x4(0x4)
	int32_t TransitionIndex;  // 0x8(0x4)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool ReturnValue : 1;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)

}; 
// Function AnimFramework.AnimProxyBasedAnimInstance.IsSlotNodePlayingMontage
// Size: 0xC(Inherited: 0x0) 
struct FIsSlotNodePlayingMontage
{
	struct FName SlotNodeName;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bIncludeBlendingOut : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool ReturnValue : 1;  // 0x9(0x1)
	char pad_10[2];  // 0xA(0x2)

}; 
// Function AnimFramework.AnimProxyBasedAnimInstance.StopMontageOnGroup
// Size: 0xC(Inherited: 0x0) 
struct FStopMontageOnGroup
{
	struct FName InGroupName;  // 0x0(0x8)
	float BlendOut;  // 0x8(0x4)

}; 
// Function AnimFramework.AnimProxyBasedAnimInstance.StopMontageOnSlot
// Size: 0xC(Inherited: 0x0) 
struct FStopMontageOnSlot
{
	struct FName SlotNodeName;  // 0x0(0x8)
	float BlendOut;  // 0x8(0x4)

}; 
// Function AnimFramework.AnimFrameworkBlueprintLibrary.CreateStreamableCinematicSequence
// Size: 0x10(Inherited: 0x0) 
struct FCreateStreamableCinematicSequence
{
	struct FName CinematicLevelName;  // 0x0(0x8)
	struct UStreamableCinematic* ReturnValue;  // 0x8(0x8)

}; 
