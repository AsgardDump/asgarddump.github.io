#pragma once 
#include <ATDLC16_Structs.h>
 
 
 
// BlueprintGeneratedClass ATDLC16.ATDLC16_C
// Size: 0x28(Inherited: 0x28) 
struct UATDLC16_C : public UMadSkillDataObject
{

	float GetSecondaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function ATDLC16.ATDLC16_C.GetSecondaryExtraData
	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function ATDLC16.ATDLC16_C.GetPrimaryExtraData
}; 



