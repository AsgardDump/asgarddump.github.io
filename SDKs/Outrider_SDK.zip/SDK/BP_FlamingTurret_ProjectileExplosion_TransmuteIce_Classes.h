#pragma once 
#include <BP_FlamingTurret_ProjectileExplosion_TransmuteIce_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_FlamingTurret_ProjectileExplosion_TransmuteIce.BP_FlamingTurret_ProjectileExplosion_TransmuteIce_C
// Size: 0x1E0(Inherited: 0x1E0) 
struct UBP_FlamingTurret_ProjectileExplosion_TransmuteIce_C : public UMadExplosionTemplate
{

}; 



