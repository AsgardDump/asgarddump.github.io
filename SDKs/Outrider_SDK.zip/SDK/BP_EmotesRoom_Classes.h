#pragma once 
#include <BP_EmotesRoom_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_EmotesRoom.BP_EmotesRoom_C
// Size: 0x770(Inherited: 0x6F0) 
struct ABP_EmotesRoom_C : public AMadTheRoom
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x6F0(0x8)
	struct UArrowComponent* Arrow2;  // 0x6F8(0x8)
	struct USpotLightComponent* char_RimLeftLight;  // 0x700(0x8)
	struct UArrowComponent* Arrow1;  // 0x708(0x8)
	struct USpotLightComponent* char_MainDirectLight;  // 0x710(0x8)
	struct UArrowComponent* Arrow;  // 0x718(0x8)
	struct USpotLightComponent* char_FaceDirectLight;  // 0x720(0x8)
	struct UPointLightComponent* char_AddLeftLight;  // 0x728(0x8)
	struct USpotLightComponent* SpotLight4;  // 0x730(0x8)
	struct USpotLightComponent* SpotLight3;  // 0x738(0x8)
	struct USpotLightComponent* SpotLight2;  // 0x740(0x8)
	struct USpotLightComponent* SpotLight1;  // 0x748(0x8)
	struct UStaticMeshComponent* StaticMesh;  // 0x750(0x8)
	struct UStaticMeshComponent* Cube;  // 0x758(0x8)
	struct UPostProcessComponent* PostProcess;  // 0x760(0x8)
	struct UCameraComponent* Camera;  // 0x768(0x8)

	void OnModeChanged(uint8_t  NewMode); // Function BP_EmotesRoom.BP_EmotesRoom_C.OnModeChanged
	void ChangeCamera(struct UCameraComponent* Camera); // Function BP_EmotesRoom.BP_EmotesRoom_C.ChangeCamera
	void OnLeaveTheRoom(uint8_t  NewMode); // Function BP_EmotesRoom.BP_EmotesRoom_C.OnLeaveTheRoom
	void ExecuteUbergraph_BP_EmotesRoom(int32_t EntryPoint); // Function BP_EmotesRoom.BP_EmotesRoom_C.ExecuteUbergraph_BP_EmotesRoom
}; 



