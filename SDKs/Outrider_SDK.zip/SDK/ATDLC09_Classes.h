#pragma once 
#include <ATDLC09_Structs.h>
 
 
 
// BlueprintGeneratedClass ATDLC09.ATDLC09_C
// Size: 0x28(Inherited: 0x28) 
struct UATDLC09_C : public UMadSkillDataObject
{

	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function ATDLC09.ATDLC09_C.GetPrimaryExtraData
}; 



