#pragma once 
#include <ANDLC09_Structs.h>
 
 
 
// BlueprintGeneratedClass ANDLC09.ANDLC09_C
// Size: 0x28(Inherited: 0x28) 
struct UANDLC09_C : public UMadSkillDataObject
{

	float GetSecondaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function ANDLC09.ANDLC09_C.GetSecondaryExtraData
	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function ANDLC09.ANDLC09_C.GetPrimaryExtraData
}; 



