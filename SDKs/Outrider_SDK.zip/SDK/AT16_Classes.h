#pragma once 
#include <AT16_Structs.h>
 
 
 
// BlueprintGeneratedClass AT16.AT16_C
// Size: 0x28(Inherited: 0x28) 
struct UAT16_C : public UMadSkillDataObject
{

	float GetPrimaryExtraData(struct AMadBaseCharacter* MadInstigatorCharacter, int32_t ItemLevel); // Function AT16.AT16_C.GetPrimaryExtraData
}; 



