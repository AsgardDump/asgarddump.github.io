#pragma once 
#include <BP_Enemy_Minigun_Vanquisher_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Enemy_Minigun_Vanquisher.BP_Enemy_Minigun_Vanquisher_C
// Size: 0x2158(Inherited: 0x2150) 
struct ABP_Enemy_Minigun_Vanquisher_C : public AMadMinigunModded
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x2150(0x8)

	void ReceiveBeginPlay(); // Function BP_Enemy_Minigun_Vanquisher.BP_Enemy_Minigun_Vanquisher_C.ReceiveBeginPlay
	void ExecuteUbergraph_BP_Enemy_Minigun_Vanquisher(int32_t EntryPoint); // Function BP_Enemy_Minigun_Vanquisher.BP_Enemy_Minigun_Vanquisher_C.ExecuteUbergraph_BP_Enemy_Minigun_Vanquisher
}; 



