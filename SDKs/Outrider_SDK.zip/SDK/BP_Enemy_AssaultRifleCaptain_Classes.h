#pragma once 
#include <BP_Enemy_AssaultRifleCaptain_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Enemy_AssaultRifleCaptain.BP_Enemy_AssaultRifleCaptain_C
// Size: 0x1F90(Inherited: 0x1F90) 
struct ABP_Enemy_AssaultRifleCaptain_C : public AMadAssaultWeapon
{

}; 



