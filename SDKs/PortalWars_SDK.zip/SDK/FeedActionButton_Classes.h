#pragma once 
#include <FeedActionButton_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass FeedActionButton.FeedActionButton_C
// Size: 0x6A0(Inherited: 0x688) 
struct UFeedActionButton_C : public UPortalWarsButtonWidget
{
	struct UImage* Background;  // 0x688(0x8)
	struct UImage* GamepadKeyImage;  // 0x690(0x8)
	struct UImage* Image_143;  // 0x698(0x8)

}; 



