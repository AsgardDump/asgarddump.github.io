#pragma once 
#include <NameTag_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass NameTag.NameTag_C
// Size: 0x268(Inherited: 0x268) 
struct UNameTag_C : public UPortalWarsNameTagWidget
{

}; 



