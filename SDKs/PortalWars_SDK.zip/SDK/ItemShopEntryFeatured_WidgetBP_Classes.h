#pragma once 
#include <ItemShopEntryFeatured_WidgetBP_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass ItemShopEntryFeatured_WidgetBP.ItemShopEntryFeatured_WidgetBP_C
// Size: 0xA68(Inherited: 0xA38) 
struct UItemShopEntryFeatured_WidgetBP_C : public UPortalWarsItemShopEntry
{
	struct UDiscountWidget_C* DiscountWidget;  // 0xA38(0x8)
	struct UImage* GamepadKeyImage;  // 0xA40(0x8)
	struct UImage* Image_2;  // 0xA48(0x8)
	struct UImage* Image_3;  // 0xA50(0x8)
	struct UPriceWidgetVertical_C* PriceWidgetVertical;  // 0xA58(0x8)
	struct UImage* Shadow;  // 0xA60(0x8)

}; 



