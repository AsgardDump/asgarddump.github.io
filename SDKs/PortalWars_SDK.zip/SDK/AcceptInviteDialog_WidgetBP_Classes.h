#pragma once 
#include <AcceptInviteDialog_WidgetBP_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass AcceptInviteDialog_WidgetBP.AcceptInviteDialog_WidgetBP_C
// Size: 0x870(Inherited: 0x860) 
struct UAcceptInviteDialog_WidgetBP_C : public UPortalWarsDialogWidget
{
	struct UImage* BG;  // 0x860(0x8)
	struct UThrobber* Throbber_1;  // 0x868(0x8)

}; 



