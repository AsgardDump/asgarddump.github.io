#pragma once 
#include <BattlePassEntry_WidgetBP_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass BattlePassEntry_WidgetBP.BattlePassEntry_WidgetBP_C
// Size: 0xBF0(Inherited: 0xBA0) 
struct UBattlePassEntry_WidgetBP_C : public UPortalWarsBattlePassEntryWidget
{
	struct UImage* Background;  // 0xBA0(0x8)
	struct UBackgroundBlur* BackgroundBlur_66;  // 0xBA8(0x8)
	struct UImage* CompleteImage;  // 0xBB0(0x8)
	struct UImage* Image_3;  // 0xBB8(0x8)
	struct UImage* Image_130;  // 0xBC0(0x8)
	struct UImage* Image_407;  // 0xBC8(0x8)
	struct UImage* Line;  // 0xBD0(0x8)
	struct UImage* LockedIcon;  // 0xBD8(0x8)
	struct UImage* NormalButtonBG;  // 0xBE0(0x8)
	struct UImage* SelectedButtonBG;  // 0xBE8(0x8)

}; 



