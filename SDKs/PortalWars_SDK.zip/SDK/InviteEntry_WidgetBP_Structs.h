#pragma once 
#include "SDK.h" 
 
 
// Function InviteEntry_WidgetBP.InviteEntry_WidgetBP_C.ExecuteUbergraph_InviteEntry_WidgetBP
// Size: 0x4(Inherited: 0x0) 
struct FExecuteUbergraph_InviteEntry_WidgetBP
{
	int32_t EntryPoint;  // 0x0(0x4)

}; 
