#pragma once 
#include <MeleeHitCamShake_Structs.h>
 
 
 
// BlueprintGeneratedClass MeleeHitCamShake.MeleeHitCamShake_C
// Size: 0x1B0(Inherited: 0x1B0) 
struct UMeleeHitCamShake_C : public UMatineeCameraShake
{

}; 



