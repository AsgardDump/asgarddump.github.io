#pragma once 
#include <InviteNotificationEntry_WidgetBP_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass InviteNotificationEntry_WidgetBP.InviteNotificationEntry_WidgetBP_C
// Size: 0xB28(Inherited: 0xB00) 
struct UInviteNotificationEntry_WidgetBP_C : public UPortalWarsInviteEntryWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0xB00(0x8)
	struct UWidgetAnimation* OpenAnimation;  // 0xB08(0x8)
	struct UImage* Image;  // 0xB10(0x8)
	struct UImage* Image_2;  // 0xB18(0x8)
	struct UImage* Image_141;  // 0xB20(0x8)

	void Construct(); // Function InviteNotificationEntry_WidgetBP.InviteNotificationEntry_WidgetBP_C.Construct
	void ExecuteUbergraph_InviteNotificationEntry_WidgetBP(int32_t EntryPoint); // Function InviteNotificationEntry_WidgetBP.InviteNotificationEntry_WidgetBP_C.ExecuteUbergraph_InviteNotificationEntry_WidgetBP
}; 



