#pragma once 
#include <ChallengeInspectEntry_WidgetBP_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass ChallengeInspectEntry_WidgetBP.ChallengeInspectEntry_WidgetBP_C
// Size: 0xD50(Inherited: 0xD28) 
struct UChallengeInspectEntry_WidgetBP_C : public UPortalWarsChallengeEntryWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0xD28(0x8)
	struct UWidgetAnimation* OnSelectedAnim;  // 0xD30(0x8)
	struct UWidgetSwitcher* BackgroundSwitcher;  // 0xD38(0x8)
	struct UImage* NormalButtonBG;  // 0xD40(0x8)
	struct UImage* SelectedButtonBG;  // 0xD48(0x8)

	void RefreshEntry_BP(); // Function ChallengeInspectEntry_WidgetBP.ChallengeInspectEntry_WidgetBP_C.RefreshEntry_BP
	void ExecuteUbergraph_ChallengeInspectEntry_WidgetBP(int32_t EntryPoint); // Function ChallengeInspectEntry_WidgetBP.ChallengeInspectEntry_WidgetBP_C.ExecuteUbergraph_ChallengeInspectEntry_WidgetBP
}; 



