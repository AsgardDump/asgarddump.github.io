#pragma once 
#include <DropIndicator_WidgetBP_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass DropIndicator_WidgetBP.DropIndicator_WidgetBP_C
// Size: 0x278(Inherited: 0x270) 
struct UDropIndicator_WidgetBP_C : public UPortalWarsDropIndicatorWidget
{
	struct UImage* Graphic;  // 0x270(0x8)

}; 



