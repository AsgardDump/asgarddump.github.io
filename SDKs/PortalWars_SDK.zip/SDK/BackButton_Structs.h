#pragma once 
#include "SDK.h" 
 
 
// Function BackButton.BackButton_C.ExecuteUbergraph_BackButton
// Size: 0x59(Inherited: 0x0) 
struct FExecuteUbergraph_BackButton
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FSlateColor K2Node_MakeStruct_SlateColor;  // 0x8(0x28)
	struct FSlateColor K2Node_MakeStruct_SlateColor_2;  // 0x30(0x28)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool K2Node_Event_IsDesignTime : 1;  // 0x58(0x1)

}; 
// Function BackButton.BackButton_C.PreConstruct
// Size: 0x1(Inherited: 0x1) 
struct FPreConstruct : public FPreConstruct
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool IsDesignTime : 1;  // 0x0(0x1)

}; 
// Function BackButton.BackButton_C.Set Label
// Size: 0x18(Inherited: 0x0) 
struct FSet Label
{
	struct FText Label;  // 0x0(0x18)

}; 
