#pragma once 
#include <Dialog_EscapeMenu_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass Dialog_EscapeMenu.Dialog_EscapeMenu_C
// Size: 0x988(Inherited: 0x968) 
struct UDialog_EscapeMenu_C : public UPortalWarsEscapeMenuWidget
{
	struct UImage* Image_124;  // 0x968(0x8)
	struct UMenuBackground_C* MenuBackground;  // 0x970(0x8)
	struct USafeZone* SafeZone_1;  // 0x978(0x8)
	struct UWBP_Footer_C* WBP_Footer;  // 0x980(0x8)

}; 



