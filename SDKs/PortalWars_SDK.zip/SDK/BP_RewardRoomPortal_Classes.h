#pragma once 
#include <BP_RewardRoomPortal_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_RewardRoomPortal.BP_RewardRoomPortal_C
// Size: 0x26C(Inherited: 0x220) 
struct ABP_RewardRoomPortal_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct UStaticMeshComponent* SM_RewardPortal;  // 0x228(0x8)
	struct UNiagaraComponent* NS_RewardPortal_Opening;  // 0x230(0x8)
	struct UNiagaraComponent* NS_RewardPortal_Idle;  // 0x238(0x8)
	struct UNiagaraComponent* NS_RewardPortal_Closing;  // 0x240(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x248(0x8)
	float PortalOppeningTimeline_PortalOppeningState_43D8381E48D068F7781A51B4428E0358;  // 0x250(0x4)
	char ETimelineDirection PortalOppeningTimeline__Direction_43D8381E48D068F7781A51B4428E0358;  // 0x254(0x1)
	char pad_597[3];  // 0x255(0x3)
	struct UTimelineComponent* PortalOppeningTimeline;  // 0x258(0x8)
	char pad_608_1 : 7;  // 0x260(0x1)
	bool bIsPortalOpened : 1;  // 0x260(0x1)
	char pad_609_1 : 7;  // 0x261(0x1)
	bool bIsPortalBusy : 1;  // 0x261(0x1)
	char pad_610[2];  // 0x262(0x2)
	float OpeningTime;  // 0x264(0x4)
	float ClosingTime;  // 0x268(0x4)

	void PortalOppeningTimeline__FinishedFunc(); // Function BP_RewardRoomPortal.BP_RewardRoomPortal_C.PortalOppeningTimeline__FinishedFunc
	void PortalOppeningTimeline__UpdateFunc(); // Function BP_RewardRoomPortal.BP_RewardRoomPortal_C.PortalOppeningTimeline__UpdateFunc
	void OpenPortal(); // Function BP_RewardRoomPortal.BP_RewardRoomPortal_C.OpenPortal
	void ClosePortal(); // Function BP_RewardRoomPortal.BP_RewardRoomPortal_C.ClosePortal
	void ReceiveBeginPlay(); // Function BP_RewardRoomPortal.BP_RewardRoomPortal_C.ReceiveBeginPlay
	void ExecuteUbergraph_BP_RewardRoomPortal(int32_t EntryPoint); // Function BP_RewardRoomPortal.BP_RewardRoomPortal_C.ExecuteUbergraph_BP_RewardRoomPortal
}; 



