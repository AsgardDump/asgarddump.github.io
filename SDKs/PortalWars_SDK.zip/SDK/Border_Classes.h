#pragma once 
#include <Border_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass Border.Border_C
// Size: 0x58B(Inherited: 0x520) 
struct UBorder_C : public UPortalWarsUserWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x520(0x8)
	struct UBackgroundBlur* BackgroundBlur_66;  // 0x528(0x8)
	struct UImage* black;  // 0x530(0x8)
	struct UImage* Border;  // 0x538(0x8)
	struct UImage* Border_Black;  // 0x540(0x8)
	struct UImage* Border_Small;  // 0x548(0x8)
	struct UImage* FocusColor;  // 0x550(0x8)
	struct UImage* GraphicLine;  // 0x558(0x8)
	struct FLinearColor Color;  // 0x560(0x10)
	uint8_t  SetBlurVisibity;  // 0x570(0x1)
	char pad_1393[7];  // 0x571(0x7)
	struct UMaterialInstanceDynamic* DMI_Border;  // 0x578(0x8)
	float Value;  // 0x580(0x4)
	float GraphicLineTranslation;  // 0x584(0x4)
	uint8_t  GraphicLineVisibility;  // 0x588(0x1)
	uint8_t  SetFocusColor;  // 0x589(0x1)
	uint8_t  SetSmallBorderVisibility;  // 0x58A(0x1)

	void SetMaterial(); // Function Border.Border_C.SetMaterial
	void PreConstruct(bool IsDesignTime); // Function Border.Border_C.PreConstruct
	void ExecuteUbergraph_Border(int32_t EntryPoint); // Function Border.Border_C.ExecuteUbergraph_Border
}; 



