#pragma once 
#include <Fists_DmgType_Structs.h>
 
 
 
// BlueprintGeneratedClass Fists_DmgType.Fists_DmgType_C
// Size: 0x60(Inherited: 0x60) 
struct UFists_DmgType_C : public UPortalWarsMeleeDmgType
{

}; 



