#pragma once 
#include <CareerProgress_WidgetBP_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass CareerProgress_WidgetBP.CareerProgress_WidgetBP_C
// Size: 0x6B0(Inherited: 0x688) 
struct UCareerProgress_WidgetBP_C : public UPortalWarsCareerProgressWidget
{
	struct UImage* Image;  // 0x688(0x8)
	struct UImage* Image_2;  // 0x690(0x8)
	struct UImage* Image_3;  // 0x698(0x8)
	struct UImage* Image_171;  // 0x6A0(0x8)
	struct UImage* Image_520;  // 0x6A8(0x8)

}; 



