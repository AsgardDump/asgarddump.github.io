#pragma once 
#include "SDK.h" 
 
 
// Function BattlePassPurchaseDialog_WidgetBP.BattlePassPurchaseDialog_WidgetBP_C.ExecuteUbergraph_BattlePassPurchaseDialog_WidgetBP
// Size: 0x4(Inherited: 0x0) 
struct FExecuteUbergraph_BattlePassPurchaseDialog_WidgetBP
{
	int32_t EntryPoint;  // 0x0(0x4)

}; 
