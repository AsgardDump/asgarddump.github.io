#pragma once 
#include <FriendRequestNotificationEntry_WidgetBP_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass FriendRequestNotificationEntry_WidgetBP.FriendRequestNotificationEntry_WidgetBP_C
// Size: 0xA00(Inherited: 0x9E0) 
struct UFriendRequestNotificationEntry_WidgetBP_C : public UPortalWarsFriendRequestEntry
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x9E0(0x8)
	struct UWidgetAnimation* OpenAnimation;  // 0x9E8(0x8)
	struct UImage* Image;  // 0x9F0(0x8)
	struct UImage* Image_141;  // 0x9F8(0x8)

	void Construct(); // Function FriendRequestNotificationEntry_WidgetBP.FriendRequestNotificationEntry_WidgetBP_C.Construct
	void ExecuteUbergraph_FriendRequestNotificationEntry_WidgetBP(int32_t EntryPoint); // Function FriendRequestNotificationEntry_WidgetBP.FriendRequestNotificationEntry_WidgetBP_C.ExecuteUbergraph_FriendRequestNotificationEntry_WidgetBP
}; 



