#pragma once 
#include <ButtonBase2_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass ButtonBase2.ButtonBase2_C
// Size: 0xB1C(Inherited: 0x688) 
struct UButtonBase2_C : public UPortalWarsButtonWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x688(0x8)
	struct USizeBox* BigSizeBox;  // 0x690(0x8)
	struct UImage* ButtonIcon;  // 0x698(0x8)
	struct UImage* GamepadKeyImage;  // 0x6A0(0x8)
	struct USizeBox* GamepadSizeBox;  // 0x6A8(0x8)
	struct UHorizontalBox* HorizontalBox_1;  // 0x6B0(0x8)
	struct USizeBox* IconSizeBox;  // 0x6B8(0x8)
	struct USizeBox* SmallSizeBox;  // 0x6C0(0x8)
	struct USpacer* Spacer_132;  // 0x6C8(0x8)
	struct UTextBlock* SubtitleText;  // 0x6D0(0x8)
	struct FButtonStyle ButtonStyle;  // 0x6D8(0x278)
	struct FSlateFontInfo TitleFont;  // 0x950(0x58)
	struct FLinearColor TitleColor;  // 0x9A8(0x10)
	struct FLinearColor TitleShadowColor;  // 0x9B8(0x10)
	struct FVector2D TitleShadowOffset;  // 0x9C8(0x8)
	struct FText Subtitle;  // 0x9D0(0x18)
	struct FSlateFontInfo SubtitleFont;  // 0x9E8(0x58)
	struct FLinearColor SubtitleColor;  // 0xA40(0x10)
	struct FLinearColor SubtitleShadowColor;  // 0xA50(0x10)
	struct FVector2D SubtitleShadowOffset;  // 0xA60(0x8)
	char pad_2664_1 : 7;  // 0xA68(0x1)
	bool ShowIcon : 1;  // 0xA68(0x1)
	char pad_2665[7];  // 0xA69(0x7)
	struct FSlateBrush Icon;  // 0xA70(0x88)
	struct FVector2D IconSize;  // 0xAF8(0x8)
	struct FMargin InternalPadding;  // 0xB00(0x10)
	struct FVector2D SpacerSize;  // 0xB10(0x8)
	float TrueSizePercent;  // 0xB18(0x4)

	void PreConstruct(bool IsDesignTime); // Function ButtonBase2.ButtonBase2_C.PreConstruct
	void ExecuteUbergraph_ButtonBase2(int32_t EntryPoint); // Function ButtonBase2.ButtonBase2_C.ExecuteUbergraph_ButtonBase2
}; 



