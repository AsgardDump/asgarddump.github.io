#pragma once 
#include <InviteEntry_WidgetBP_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass InviteEntry_WidgetBP.InviteEntry_WidgetBP_C
// Size: 0xB20(Inherited: 0xB00) 
struct UInviteEntry_WidgetBP_C : public UPortalWarsInviteEntryWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0xB00(0x8)
	struct UImage* BG;  // 0xB08(0x8)
	struct UImage* Image_181;  // 0xB10(0x8)
	struct UImage* SelectedBG;  // 0xB18(0x8)

	void Construct(); // Function InviteEntry_WidgetBP.InviteEntry_WidgetBP_C.Construct
	void ExecuteUbergraph_InviteEntry_WidgetBP(int32_t EntryPoint); // Function InviteEntry_WidgetBP.InviteEntry_WidgetBP_C.ExecuteUbergraph_InviteEntry_WidgetBP
}; 



