#pragma once 
#include <CustomScrollHorizontal_WidgetBP_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass CustomScrollHorizontal_WidgetBP.CustomScrollHorizontal_WidgetBP_C
// Size: 0x628(Inherited: 0x628) 
struct UCustomScrollHorizontal_WidgetBP_C : public UPortalWarsCustomScrollWidget
{

}; 



