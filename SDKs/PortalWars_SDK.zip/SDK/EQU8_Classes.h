#pragma once 
#include <EQU8_Structs.h>
 
 
 
// Class EQU8.EQU8Channel
// Size: 0x78(Inherited: 0x68) 
struct UEQU8Channel : public UChannel
{
	char pad_104[16];  // 0x68(0x10)

}; 



