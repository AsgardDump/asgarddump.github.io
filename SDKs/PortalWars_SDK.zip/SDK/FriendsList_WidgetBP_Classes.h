#pragma once 
#include <FriendsList_WidgetBP_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass FriendsList_WidgetBP.FriendsList_WidgetBP_C
// Size: 0x818(Inherited: 0x800) 
struct UFriendsList_WidgetBP_C : public UPortalWarsFriendsListWidget
{
	struct UFriendsListSub_WidgetBP_C* FriendsMenu;  // 0x800(0x8)
	struct UFriendsListSub_WidgetBP_C* PlatformFriendsMenu;  // 0x808(0x8)
	struct USafeZone* SafeZone_1;  // 0x810(0x8)

}; 



