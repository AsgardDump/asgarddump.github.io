#pragma once 
#include <InspectItem_WidgetBP_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass InspectItem_WidgetBP.InspectItem_WidgetBP_C
// Size: 0x2E0(Inherited: 0x2C0) 
struct UInspectItem_WidgetBP_C : public UPortalWarsInspectItemWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x2C0(0x8)
	struct UOverlay* PlayerCard;  // 0x2C8(0x8)
	struct FVector2D Scale;  // 0x2D0(0x8)
	struct FVector2D Translation;  // 0x2D8(0x8)

	void UpdateTransform(struct FVector2D Scale, struct FVector2D Translation, float Transform Angle, struct FVector2D PlayerCardTranslation); // Function InspectItem_WidgetBP.InspectItem_WidgetBP_C.UpdateTransform
	void PreConstruct(bool IsDesignTime); // Function InspectItem_WidgetBP.InspectItem_WidgetBP_C.PreConstruct
	void ExecuteUbergraph_InspectItem_WidgetBP(int32_t EntryPoint); // Function InspectItem_WidgetBP.InspectItem_WidgetBP_C.ExecuteUbergraph_InspectItem_WidgetBP
}; 



