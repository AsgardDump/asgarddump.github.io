#pragma once 
#include <BP_DialogLibraryFrontEnd_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_DialogLibraryFrontEnd.BP_DialogLibraryFrontEnd_C
// Size: 0xB8(Inherited: 0xB8) 
struct UBP_DialogLibraryFrontEnd_C : public UBP_DialogLibraryBase_C
{

}; 



