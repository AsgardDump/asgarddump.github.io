#pragma once 
#include "SDK.h" 
 
 
// Function ButtonBase.ButtonBase_C.ExecuteUbergraph_ButtonBase
// Size: 0x31(Inherited: 0x0) 
struct FExecuteUbergraph_ButtonBase
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Temp_bool_Variable : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct UWBP_GenericButton_C* K2Node_DynamicCast_AsWBP_Generic_Button;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x10(0x1)
	uint8_t  Temp_byte_Variable;  // 0x11(0x1)
	uint8_t  Temp_byte_Variable_2;  // 0x12(0x1)
	char pad_19_1 : 7;  // 0x13(0x1)
	bool K2Node_Event_IsDesignTime : 1;  // 0x13(0x1)
	uint8_t  K2Node_Select_Default;  // 0x14(0x1)
	char pad_21[3];  // 0x15(0x3)
	float CallFunc_BreakVector2D_X;  // 0x18(0x4)
	float CallFunc_BreakVector2D_Y;  // 0x1C(0x4)
	struct UPortalWarsUIInputAction* CallFunc_GetClickInputAction_ReturnValue;  // 0x20(0x8)
	struct UWBP_GenericButton_C* K2Node_DynamicCast_AsWBP_Generic_Button_2;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x30(0x1)

}; 
// Function ButtonBase.ButtonBase_C.PreConstruct
// Size: 0x1(Inherited: 0x1) 
struct FPreConstruct : public FPreConstruct
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool IsDesignTime : 1;  // 0x0(0x1)

}; 
