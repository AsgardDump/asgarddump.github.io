#pragma once 
#include <ChunkInstall_WidgetBP_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass ChunkInstall_WidgetBP.ChunkInstall_WidgetBP_C
// Size: 0x540(Inherited: 0x530) 
struct UChunkInstall_WidgetBP_C : public UPortalWarsChunkInstallWidget
{
	struct UImage* Image_141;  // 0x530(0x8)
	struct UImage* Image_248;  // 0x538(0x8)

}; 



