#pragma once 
#include <FullLootSequence_Structs.h>
 
 
 
// BlueprintGeneratedClass FullLootSequence.SequenceDirector_C
// Size: 0x40(Inherited: 0x38) 
struct USequenceDirector_C : public ULevelSequenceDirector
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x38(0x8)

	void SequenceEvent__ENTRYPOINTSequenceDirector_2(struct APortalWarsMainMenuCharacter_BP_C* PortalWarsMainMenuCharacter_BP); // Function FullLootSequence.SequenceDirector_C.SequenceEvent__ENTRYPOINTSequenceDirector_2
	void SequenceEvent__ENTRYPOINTSequenceDirector_1(struct APortalWarsMainMenuCharacter_BP_C* PortalWarsMainMenuCharacter_BP); // Function FullLootSequence.SequenceDirector_C.SequenceEvent__ENTRYPOINTSequenceDirector_1
	void PortalWarsMainMenuCharacter_BP_Event_1(struct APortalWarsMainMenuCharacter_BP_C* PortalWarsMainMenuCharacter_BP); // Function FullLootSequence.SequenceDirector_C.PortalWarsMainMenuCharacter_BP_Event_1
	void ExecuteUbergraph_SequenceDirector(int32_t EntryPoint); // Function FullLootSequence.SequenceDirector_C.ExecuteUbergraph_SequenceDirector
}; 



