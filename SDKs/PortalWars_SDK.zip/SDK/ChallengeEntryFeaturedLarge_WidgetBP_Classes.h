#pragma once 
#include <ChallengeEntryFeaturedLarge_WidgetBP_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass ChallengeEntryFeaturedLarge_WidgetBP.ChallengeEntryFeaturedLarge_WidgetBP_C
// Size: 0xD40(Inherited: 0xD28) 
struct UChallengeEntryFeaturedLarge_WidgetBP_C : public UPortalWarsChallengeEntryWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0xD28(0x8)
	struct UBorder_C* Border;  // 0xD30(0x8)
	struct UImage* RewardImage_2;  // 0xD38(0x8)

	void Construct(); // Function ChallengeEntryFeaturedLarge_WidgetBP.ChallengeEntryFeaturedLarge_WidgetBP_C.Construct
	void ExecuteUbergraph_ChallengeEntryFeaturedLarge_WidgetBP(int32_t EntryPoint); // Function ChallengeEntryFeaturedLarge_WidgetBP.ChallengeEntryFeaturedLarge_WidgetBP_C.ExecuteUbergraph_ChallengeEntryFeaturedLarge_WidgetBP
}; 



