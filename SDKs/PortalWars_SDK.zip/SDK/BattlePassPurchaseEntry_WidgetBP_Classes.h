#pragma once 
#include <BattlePassPurchaseEntry_WidgetBP_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass BattlePassPurchaseEntry_WidgetBP.BattlePassPurchaseEntry_WidgetBP_C
// Size: 0xBB0(Inherited: 0xBA0) 
struct UBattlePassPurchaseEntry_WidgetBP_C : public UPortalWarsBattlePassEntryWidget
{
	struct UImage* NormalButtonBG;  // 0xBA0(0x8)
	struct UImage* PremiumIndicator;  // 0xBA8(0x8)

}; 



