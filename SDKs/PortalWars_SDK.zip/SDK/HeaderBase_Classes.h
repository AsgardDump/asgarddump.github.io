#pragma once 
#include <HeaderBase_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass HeaderBase.HeaderBase_C
// Size: 0x420(Inherited: 0x260) 
struct UHeaderBase_C : public UUserWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x260(0x8)
	struct UTextBlock* TitleText;  // 0x268(0x8)
	struct FSlateBrush Background;  // 0x270(0x88)
	struct FText Title;  // 0x2F8(0x18)
	struct FSlateFontInfo TitleFont;  // 0x310(0x58)
	struct FLinearColor TitleColor;  // 0x368(0x10)
	char pad_888_1 : 7;  // 0x378(0x1)
	bool ShowIcon : 1;  // 0x378(0x1)
	char pad_889[7];  // 0x379(0x7)
	struct FSlateBrush Icon;  // 0x380(0x88)
	struct FVector2D IconSize;  // 0x408(0x8)
	struct FMargin InternalPadding;  // 0x410(0x10)

	void PreConstruct(bool IsDesignTime); // Function HeaderBase.HeaderBase_C.PreConstruct
	void ExecuteUbergraph_HeaderBase(int32_t EntryPoint); // Function HeaderBase.HeaderBase_C.ExecuteUbergraph_HeaderBase
}; 



