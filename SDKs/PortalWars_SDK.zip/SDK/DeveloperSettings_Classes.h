#pragma once 
#include <DeveloperSettings_Structs.h>
 
 
 
// Class DeveloperSettings.DeveloperSettings
// Size: 0x38(Inherited: 0x28) 
struct UDeveloperSettings : public UObject
{
	char pad_40[16];  // 0x28(0x10)

}; 



// Class DeveloperSettings.DeveloperSettingsBackedByCVars
// Size: 0x38(Inherited: 0x38) 
struct UDeveloperSettingsBackedByCVars : public UDeveloperSettings
{

}; 



