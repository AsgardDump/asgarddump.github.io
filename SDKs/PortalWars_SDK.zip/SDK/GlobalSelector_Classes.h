#pragma once 
#include <GlobalSelector_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass GlobalSelector.GlobalSelector_C
// Size: 0x640(Inherited: 0x638) 
struct UGlobalSelector_C : public UPortalWarsGlobalCarouselWidget
{
	struct UImage* Image_101;  // 0x638(0x8)

}; 



