#pragma once 
#include <Career_WidgetBP_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass Career_WidgetBP.Career_WidgetBP_C
// Size: 0x850(Inherited: 0x830) 
struct UCareer_WidgetBP_C : public UPortalWarsCareerWidget
{
	struct UMenuBackground_C* MenuBackground;  // 0x830(0x8)
	struct USafeZone* SafeZone_1;  // 0x838(0x8)
	struct UWBP_Footer_C* WBP_Footer;  // 0x840(0x8)
	struct UWBP_PageHeader_C* WBP_PageHeader;  // 0x848(0x8)

}; 



