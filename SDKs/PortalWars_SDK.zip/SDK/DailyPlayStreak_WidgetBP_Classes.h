#pragma once 
#include <DailyPlayStreak_WidgetBP_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass DailyPlayStreak_WidgetBP.DailyPlayStreak_WidgetBP_C
// Size: 0x8F0(Inherited: 0x8B0) 
struct UDailyPlayStreak_WidgetBP_C : public UPortalWarsDailyPlayStreakWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x8B0(0x8)
	struct UImage* Image;  // 0x8B8(0x8)
	struct UImage* Image_141;  // 0x8C0(0x8)
	struct UPlayStreakReward_WidgetBP_C* PlayStreakReward_WidgetBP;  // 0x8C8(0x8)
	struct UPlayStreakReward_WidgetBP_C* PlayStreakReward_WidgetBP_241;  // 0x8D0(0x8)
	struct UPlayStreakReward_WidgetBP_C* PlayStreakReward_WidgetBP_454;  // 0x8D8(0x8)
	struct UPlayStreakReward_WidgetBP_C* PlayStreakReward_WidgetBP_690;  // 0x8E0(0x8)
	struct UPlayStreakReward_WidgetBP_C* PlayStreakReward_WidgetBP_974;  // 0x8E8(0x8)

	void Construct(); // Function DailyPlayStreak_WidgetBP.DailyPlayStreak_WidgetBP_C.Construct
	void ExecuteUbergraph_DailyPlayStreak_WidgetBP(int32_t EntryPoint); // Function DailyPlayStreak_WidgetBP.DailyPlayStreak_WidgetBP_C.ExecuteUbergraph_DailyPlayStreak_WidgetBP
}; 



