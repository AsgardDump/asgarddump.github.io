#pragma once 
#include <BackButton_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass BackButton.BackButton_C
// Size: 0x6B0(Inherited: 0x688) 
struct UBackButton_C : public UPortalWarsButtonWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x688(0x8)
	struct UImage* GamepadKeyImage;  // 0x690(0x8)
	struct FText Label;  // 0x698(0x18)

	void Set Label(struct FText Label); // Function BackButton.BackButton_C.Set Label
	void BndEvt__Button_K2Node_ComponentBoundEvent_0_OnButtonHoverEvent__DelegateSignature(); // Function BackButton.BackButton_C.BndEvt__Button_K2Node_ComponentBoundEvent_0_OnButtonHoverEvent__DelegateSignature
	void BndEvt__Button_K2Node_ComponentBoundEvent_1_OnButtonHoverEvent__DelegateSignature(); // Function BackButton.BackButton_C.BndEvt__Button_K2Node_ComponentBoundEvent_1_OnButtonHoverEvent__DelegateSignature
	void PreConstruct(bool IsDesignTime); // Function BackButton.BackButton_C.PreConstruct
	void ExecuteUbergraph_BackButton(int32_t EntryPoint); // Function BackButton.BackButton_C.ExecuteUbergraph_BackButton
}; 



