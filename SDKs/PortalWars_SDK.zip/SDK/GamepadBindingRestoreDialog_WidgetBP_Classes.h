#pragma once 
#include <GamepadBindingRestoreDialog_WidgetBP_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass GamepadBindingRestoreDialog_WidgetBP.GamepadBindingRestoreDialog_WidgetBP_C
// Size: 0x8C0(Inherited: 0x880) 
struct UGamepadBindingRestoreDialog_WidgetBP_C : public UPortalWarsGamepadBindingRestoreDialogWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x880(0x8)
	struct UDialogBackground_C* DialogBackground;  // 0x888(0x8)
	struct UImage* Image;  // 0x890(0x8)
	struct UImage* Image_2;  // 0x898(0x8)
	struct UImage* Image_53;  // 0x8A0(0x8)
	struct UImage* Image_176;  // 0x8A8(0x8)
	struct UImage* Image_299;  // 0x8B0(0x8)
	struct UImage* Image_405;  // 0x8B8(0x8)

	void Construct(); // Function GamepadBindingRestoreDialog_WidgetBP.GamepadBindingRestoreDialog_WidgetBP_C.Construct
	void ExecuteUbergraph_GamepadBindingRestoreDialog_WidgetBP(int32_t EntryPoint); // Function GamepadBindingRestoreDialog_WidgetBP.GamepadBindingRestoreDialog_WidgetBP_C.ExecuteUbergraph_GamepadBindingRestoreDialog_WidgetBP
}; 



