#pragma once 
#include "SDK.h" 
 
 
// Function CommonLoadingScreen.LoadingProcessTask.CreateLoadingScreenProcessTask
// Size: 0x20(Inherited: 0x0) 
struct FCreateLoadingScreenProcessTask
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct FString ShowLoadingScreenReason;  // 0x8(0x10)
	struct ULoadingProcessTask* ReturnValue;  // 0x18(0x8)

}; 
// Function CommonLoadingScreen.LoadingProcessTask.SetShowLoadingScreenReason
// Size: 0x10(Inherited: 0x0) 
struct FSetShowLoadingScreenReason
{
	struct FString InReason;  // 0x0(0x10)

}; 
// Function CommonLoadingScreen.LoadingScreenManager.GetDebugReasonForShowingOrHidingLoadingScreen
// Size: 0x10(Inherited: 0x0) 
struct FGetDebugReasonForShowingOrHidingLoadingScreen
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
