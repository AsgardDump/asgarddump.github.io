#pragma once 
#include <DiscountWidget_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass DiscountWidget.DiscountWidget_C
// Size: 0x290(Inherited: 0x288) 
struct UDiscountWidget_C : public UPortalWarsPriceWidget
{
	struct UImage* Image_79;  // 0x288(0x8)

}; 



