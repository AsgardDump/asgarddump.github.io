#pragma once 
#include "SDK.h" 
 
 
// Function CustomGameFilters_WidgetBP.CustomGameFilters_WidgetBP_C.ExecuteUbergraph_CustomGameFilters_WidgetBP
// Size: 0x4(Inherited: 0x0) 
struct FExecuteUbergraph_CustomGameFilters_WidgetBP
{
	int32_t EntryPoint;  // 0x0(0x4)

}; 
