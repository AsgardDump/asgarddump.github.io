#pragma once 
#include <EMPGrenade_BP_Structs.h>
 
 
 
// BlueprintGeneratedClass EMPGrenade_BP.EMPGrenade_BP_C
// Size: 0x2F0(Inherited: 0x2F0) 
struct AEMPGrenade_BP_C : public AEMPExplosiveProjectile
{

}; 



