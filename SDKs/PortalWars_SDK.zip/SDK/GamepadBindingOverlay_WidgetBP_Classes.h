#pragma once 
#include <GamepadBindingOverlay_WidgetBP_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass GamepadBindingOverlay_WidgetBP.GamepadBindingOverlay_WidgetBP_C
// Size: 0x8D0(Inherited: 0x8A8) 
struct UGamepadBindingOverlay_WidgetBP_C : public UPortalWarsGamepadBindingOverlayWidget
{
	struct UDialogBackground_C* DialogBackground;  // 0x8A8(0x8)
	struct UImage* Image_53;  // 0x8B0(0x8)
	struct UImage* Image_176;  // 0x8B8(0x8)
	struct UImage* Image_299;  // 0x8C0(0x8)
	struct USafeZone* SafeZone_1;  // 0x8C8(0x8)

}; 



