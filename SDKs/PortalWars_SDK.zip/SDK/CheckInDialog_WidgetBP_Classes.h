#pragma once 
#include <CheckInDialog_WidgetBP_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass CheckInDialog_WidgetBP.CheckInDialog_WidgetBP_C
// Size: 0x988(Inherited: 0x968) 
struct UCheckInDialog_WidgetBP_C : public UPortalWarsCheckInDialogWidget
{
	struct UImage* Image_1;  // 0x968(0x8)
	struct UImage* Image_2;  // 0x970(0x8)
	struct UPurchaseDialogBackground_C* PurchaseDialogBackground;  // 0x978(0x8)
	struct UThrobber* Throbber_1;  // 0x980(0x8)

}; 



