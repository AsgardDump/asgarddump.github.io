#pragma once 
#include <ClaimChallengeIndicator_WidgetBP_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass ClaimChallengeIndicator_WidgetBP.ClaimChallengeIndicator_WidgetBP_C
// Size: 0x2AD(Inherited: 0x278) 
struct UClaimChallengeIndicator_WidgetBP_C : public UPortalWarsClaimChallengeIndicatorWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x278(0x8)
	struct UOverlay* BigIndicator;  // 0x280(0x8)
	struct UImage* Image_2;  // 0x288(0x8)
	struct UImage* Image_81;  // 0x290(0x8)
	struct UImage* Star;  // 0x298(0x8)
	struct UImage* StarShadow;  // 0x2A0(0x8)
	float ShowCompleted;  // 0x2A8(0x4)
	char pad_684_1 : 7;  // 0x2AC(0x1)
	bool Hide Number : 1;  // 0x2AC(0x1)

	void PreConstruct(bool IsDesignTime); // Function ClaimChallengeIndicator_WidgetBP.ClaimChallengeIndicator_WidgetBP_C.PreConstruct
	void Construct(); // Function ClaimChallengeIndicator_WidgetBP.ClaimChallengeIndicator_WidgetBP_C.Construct
	void ExecuteUbergraph_ClaimChallengeIndicator_WidgetBP(int32_t EntryPoint); // Function ClaimChallengeIndicator_WidgetBP.ClaimChallengeIndicator_WidgetBP_C.ExecuteUbergraph_ClaimChallengeIndicator_WidgetBP
}; 



