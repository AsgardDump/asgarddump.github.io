#pragma once 
#include "SDK.h" 
 
 
// Function Dialog_Message.Dialog_Message_C.ExecuteUbergraph_Dialog_Message
// Size: 0x4(Inherited: 0x0) 
struct FExecuteUbergraph_Dialog_Message
{
	int32_t EntryPoint;  // 0x0(0x4)

}; 
