#pragma once 
#include <ChallengesWeapons_WidgetBP_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass ChallengesWeapons_WidgetBP.ChallengesWeapons_WidgetBP_C
// Size: 0x968(Inherited: 0x910) 
struct UChallengesWeapons_WidgetBP_C : public UPortalWarsChallengesSubWidget
{
	struct UChallengeEntryFeatured_WidgetBP_C* ChallengeEntryFeatured_WidgetBP;  // 0x910(0x8)
	struct UChallengeEntryMedium_WidgetBP_C* ChallengeEntryMedium_WidgetBP;  // 0x918(0x8)
	struct UChallengeEntryMedium_WidgetBP_C* ChallengeEntryMedium_WidgetBP_2;  // 0x920(0x8)
	struct UChallengeEntryMedium_WidgetBP_C* ChallengeEntryMedium_WidgetBP_3;  // 0x928(0x8)
	struct UChallengeEntryMedium_WidgetBP_C* ChallengeEntryMedium_WidgetBP_4;  // 0x930(0x8)
	struct UChallengeEntryMedium_WidgetBP_C* ChallengeEntryMedium_WidgetBP_5;  // 0x938(0x8)
	struct UChallengeEntryMedium_WidgetBP_C* ChallengeEntryMedium_WidgetBP_131;  // 0x940(0x8)
	struct UMenuBackground_C* MenuBackground;  // 0x948(0x8)
	struct USafeZone* SafeZone_1;  // 0x950(0x8)
	struct UWBP_Footer_C* WBP_Footer;  // 0x958(0x8)
	struct UWBP_PageHeader_C* WBP_PageHeader;  // 0x960(0x8)

}; 



