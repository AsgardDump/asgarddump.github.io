#pragma once 
#include <MovieRenderPipelineSettings_Structs.h>
 
 
 
// Class MovieRenderPipelineSettings.MoviePipelineBurnInSetting
// Size: 0xA0(Inherited: 0x48) 
struct UMoviePipelineBurnInSetting : public UMoviePipelineRenderPass
{
	struct FSoftClassPath BurnInClass;  // 0x48(0x18)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool bCompositeOntoFinalImage : 1;  // 0x60(0x1)
	char pad_97[47];  // 0x61(0x2F)
	struct UTextureRenderTarget2D* RenderTarget;  // 0x90(0x8)
	struct UMoviePipelineBurnInWidget* BurnInWidgetInstance;  // 0x98(0x8)

}; 



// Class MovieRenderPipelineSettings.MoviePipelineBurnInWidget
// Size: 0x260(Inherited: 0x260) 
struct UMoviePipelineBurnInWidget : public UUserWidget
{

	void OnOutputFrameStarted(struct UMoviePipeline* ForPipeline); // Function MovieRenderPipelineSettings.MoviePipelineBurnInWidget.OnOutputFrameStarted
}; 



// Class MovieRenderPipelineSettings.MoviePipelineConsoleVariableSetting
// Size: 0xC8(Inherited: 0x48) 
struct UMoviePipelineConsoleVariableSetting : public UMoviePipelineSetting
{
	struct TMap<struct FString, float> ConsoleVariables;  // 0x48(0x50)
	struct TArray<struct FString> StartConsoleCommands;  // 0x98(0x10)
	struct TArray<struct FString> EndConsoleCommands;  // 0xA8(0x10)
	char pad_184[16];  // 0xB8(0x10)

}; 



// Class MovieRenderPipelineSettings.MoviePipelineWidgetRenderer
// Size: 0x68(Inherited: 0x48) 
struct UMoviePipelineWidgetRenderer : public UMoviePipelineRenderPass
{
	char pad_72_1 : 7;  // 0x48(0x1)
	bool bCompositeOntoFinalImage : 1;  // 0x48(0x1)
	char pad_73[23];  // 0x49(0x17)
	struct UTextureRenderTarget2D* RenderTarget;  // 0x60(0x8)

}; 



