#pragma once 
#include <ChallengePanel_WidgetBP_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass ChallengePanel_WidgetBP.ChallengePanel_WidgetBP_C
// Size: 0x5A8(Inherited: 0x568) 
struct UChallengePanel_WidgetBP_C : public UPortalWarsChallengePanelWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x568(0x8)
	struct UWBP_ButtonPrompt_C* ButtonPrompt;  // 0x570(0x8)
	struct UChallengePanelEntry_WidgetBP_C* ChallengePanelEntry_WidgetBP;  // 0x578(0x8)
	struct UChallengePanelEntry_WidgetBP_C* ChallengePanelEntry_WidgetBP_2;  // 0x580(0x8)
	struct UChallengePanelEntry_WidgetBP_C* ChallengePanelEntry_WidgetBP_3;  // 0x588(0x8)
	struct UClaimChallengeIndicator_WidgetBP_C* ClaimIndicator;  // 0x590(0x8)
	struct UClaimChallengeIndicator_WidgetBP_C* ClaimIndicator_2;  // 0x598(0x8)
	struct UImage* Line;  // 0x5A0(0x8)

	void Construct(); // Function ChallengePanel_WidgetBP.ChallengePanel_WidgetBP_C.Construct
	void ExecuteUbergraph_ChallengePanel_WidgetBP(int32_t EntryPoint); // Function ChallengePanel_WidgetBP.ChallengePanel_WidgetBP_C.ExecuteUbergraph_ChallengePanel_WidgetBP
}; 



