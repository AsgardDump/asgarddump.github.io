#pragma once 
#include <ChallengeEntryFeatured_WidgetBP_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass ChallengeEntryFeatured_WidgetBP.ChallengeEntryFeatured_WidgetBP_C
// Size: 0xD38(Inherited: 0xD28) 
struct UChallengeEntryFeatured_WidgetBP_C : public UPortalWarsChallengeEntryWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0xD28(0x8)
	struct UImage* RewardImage_2;  // 0xD30(0x8)

	void Construct(); // Function ChallengeEntryFeatured_WidgetBP.ChallengeEntryFeatured_WidgetBP_C.Construct
	void ExecuteUbergraph_ChallengeEntryFeatured_WidgetBP(int32_t EntryPoint); // Function ChallengeEntryFeatured_WidgetBP.ChallengeEntryFeatured_WidgetBP_C.ExecuteUbergraph_ChallengeEntryFeatured_WidgetBP
}; 



