#pragma once 
#include <EquipButton_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass EquipButton.EquipButton_C
// Size: 0x6F1(Inherited: 0x6F1) 
struct UEquipButton_C : public UMenuButtonBase_C
{

}; 



