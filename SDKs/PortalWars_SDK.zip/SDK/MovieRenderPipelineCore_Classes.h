#pragma once 
#include <MovieRenderPipelineCore_Structs.h>
 
 
 
// Class MovieRenderPipelineCore.MoviePipeline
// Size: 0x2E0(Inherited: 0x28) 
struct UMoviePipeline : public UObject
{
	struct FMulticastInlineDelegate OnMoviePipelineFinishedDelegate;  // 0x28(0x10)
	struct FMulticastInlineDelegate OnMoviePipelineWorkFinishedDelegate;  // 0x38(0x10)
	struct FMulticastInlineDelegate OnMoviePipelineShotWorkFinishedDelegate;  // 0x48(0x10)
	struct UMoviePipelineCustomTimeStep* CustomTimeStep;  // 0x58(0x8)
	char pad_96[16];  // 0x60(0x10)
	struct UEngineCustomTimeStep* CachedPrevCustomTimeStep;  // 0x70(0x8)
	struct ULevelSequence* TargetSequence;  // 0x78(0x8)
	struct ALevelSequenceActor* LevelSequenceActor;  // 0x80(0x8)
	struct UMovieRenderDebugWidget* DebugWidget;  // 0x88(0x8)
	struct UTexture* PreviewTexture;  // 0x90(0x8)
	char pad_152[520];  // 0x98(0x208)
	UMovieRenderDebugWidget* DebugWidgetClass;  // 0x2A0(0x8)
	struct UMoviePipelineExecutorJob* CurrentJob;  // 0x2A8(0x8)
	char pad_688[48];  // 0x2B0(0x30)

	void Shutdown(bool bError); // Function MovieRenderPipelineCore.MoviePipeline.Shutdown
	void RequestShutdown(bool bIsError); // Function MovieRenderPipelineCore.MoviePipeline.RequestShutdown
	void OnMoviePipelineFinishedImpl(); // Function MovieRenderPipelineCore.MoviePipeline.OnMoviePipelineFinishedImpl
	bool IsShutdownRequested(); // Function MovieRenderPipelineCore.MoviePipeline.IsShutdownRequested
	void Initialize(struct UMoviePipelineExecutorJob* InJob); // Function MovieRenderPipelineCore.MoviePipeline.Initialize
	struct UTexture* GetPreviewTexture(); // Function MovieRenderPipelineCore.MoviePipeline.GetPreviewTexture
	struct UMoviePipelineMasterConfig* GetPipelineMasterConfig(); // Function MovieRenderPipelineCore.MoviePipeline.GetPipelineMasterConfig
}; 



// Class MovieRenderPipelineCore.MoviePipelineAntiAliasingSetting
// Size: 0x68(Inherited: 0x48) 
struct UMoviePipelineAntiAliasingSetting : public UMoviePipelineSetting
{
	int32_t SpatialSampleCount;  // 0x48(0x4)
	int32_t TemporalSampleCount;  // 0x4C(0x4)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool bOverrideAntiAliasing : 1;  // 0x50(0x1)
	char EAntiAliasingMethod AntiAliasingMethod;  // 0x51(0x1)
	char pad_82[2];  // 0x52(0x2)
	int32_t RenderWarmUpCount;  // 0x54(0x4)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool bUseCameraCutForWarmUp : 1;  // 0x58(0x1)
	char pad_89[3];  // 0x59(0x3)
	int32_t EngineWarmUpCount;  // 0x5C(0x4)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool bRenderWarmUpFrames : 1;  // 0x60(0x1)
	char pad_97[7];  // 0x61(0x7)

}; 



// Class MovieRenderPipelineCore.MoviePipelineInProcessExecutor
// Size: 0x168(Inherited: 0x130) 
struct UMoviePipelineInProcessExecutor : public UMoviePipelineLinearExecutorBase
{
	char pad_304_1 : 7;  // 0x130(0x1)
	bool bUseCurrentLevel : 1;  // 0x130(0x1)
	char pad_305[55];  // 0x131(0x37)

}; 



// Class MovieRenderPipelineCore.MoviePipelineCustomTimeStep
// Size: 0x30(Inherited: 0x28) 
struct UMoviePipelineCustomTimeStep : public UEngineCustomTimeStep
{
	char pad_40[8];  // 0x28(0x8)

}; 



// Class MovieRenderPipelineCore.MoviePipelineExecutorBase
// Size: 0x108(Inherited: 0x28) 
struct UMoviePipelineExecutorBase : public UObject
{
	struct FMulticastInlineDelegate OnExecutorFinishedDelegate;  // 0x28(0x10)
	char pad_56[24];  // 0x38(0x18)
	struct FMulticastInlineDelegate OnExecutorErroredDelegate;  // 0x50(0x10)
	char pad_96[32];  // 0x60(0x20)
	struct FMulticastInlineDelegate SocketMessageRecievedDelegate;  // 0x80(0x10)
	struct FMulticastInlineDelegate HTTPResponseRecievedDelegate;  // 0x90(0x10)
	UMovieRenderDebugWidget* DebugWidgetClass;  // 0xA0(0x8)
	struct FString UserData;  // 0xA8(0x10)
	UMoviePipeline* TargetPipelineClass;  // 0xB8(0x8)
	char pad_192[72];  // 0xC0(0x48)

	void SetStatusProgress(float InProgress); // Function MovieRenderPipelineCore.MoviePipelineExecutorBase.SetStatusProgress
	void SetStatusMessage(struct FString InStatus); // Function MovieRenderPipelineCore.MoviePipelineExecutorBase.SetStatusMessage
	void SetMoviePipelineClass(UObject* InPipelineClass); // Function MovieRenderPipelineCore.MoviePipelineExecutorBase.SetMoviePipelineClass
	bool SendSocketMessage(struct FString InMessage); // Function MovieRenderPipelineCore.MoviePipelineExecutorBase.SendSocketMessage
	int32_t SendHTTPRequest(struct FString InURL, struct FString InVerb, struct FString InMessage, struct TMap<struct FString, struct FString>& InHeaders); // Function MovieRenderPipelineCore.MoviePipelineExecutorBase.SendHTTPRequest
	void OnExecutorFinishedImpl(); // Function MovieRenderPipelineCore.MoviePipelineExecutorBase.OnExecutorFinishedImpl
	void OnExecutorErroredImpl(struct UMoviePipeline* ErroredPipeline, bool bFatal, struct FText ErrorReason); // Function MovieRenderPipelineCore.MoviePipelineExecutorBase.OnExecutorErroredImpl
	void OnBeginFrame(); // Function MovieRenderPipelineCore.MoviePipelineExecutorBase.OnBeginFrame
	bool IsSocketConnected(); // Function MovieRenderPipelineCore.MoviePipelineExecutorBase.IsSocketConnected
	bool IsRendering(); // Function MovieRenderPipelineCore.MoviePipelineExecutorBase.IsRendering
	float GetStatusProgress(); // Function MovieRenderPipelineCore.MoviePipelineExecutorBase.GetStatusProgress
	struct FString GetStatusMessage(); // Function MovieRenderPipelineCore.MoviePipelineExecutorBase.GetStatusMessage
	void Execute(struct UMoviePipelineQueue* InPipelineQueue); // Function MovieRenderPipelineCore.MoviePipelineExecutorBase.Execute
	void DisconnectSocket(); // Function MovieRenderPipelineCore.MoviePipelineExecutorBase.DisconnectSocket
	bool ConnectSocket(struct FString InHostName, int32_t InPort); // Function MovieRenderPipelineCore.MoviePipelineExecutorBase.ConnectSocket
	void CancelCurrentJob(); // Function MovieRenderPipelineCore.MoviePipelineExecutorBase.CancelCurrentJob
	void CancelAllJobs(); // Function MovieRenderPipelineCore.MoviePipelineExecutorBase.CancelAllJobs
}; 



// Class MovieRenderPipelineCore.MoviePipelineSetting
// Size: 0x48(Inherited: 0x28) 
struct UMoviePipelineSetting : public UObject
{
	struct TWeakObjectPtr<UMoviePipeline> CachedPipeline;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool bEnabled : 1;  // 0x30(0x1)
	char pad_49[23];  // 0x31(0x17)

	void BuildNewProcessCommandLine(struct FString& InOutUnrealURLParams, struct FString& InOutCommandLineArgs); // Function MovieRenderPipelineCore.MoviePipelineSetting.BuildNewProcessCommandLine
}; 



// Class MovieRenderPipelineCore.MoviePipelineHighResSetting
// Size: 0x60(Inherited: 0x48) 
struct UMoviePipelineHighResSetting : public UMoviePipelineSetting
{
	int32_t TileCount;  // 0x48(0x4)
	float TextureSharpnessBias;  // 0x4C(0x4)
	float OverlapRatio;  // 0x50(0x4)
	char pad_84_1 : 7;  // 0x54(0x1)
	bool bOverrideSubSurfaceScattering : 1;  // 0x54(0x1)
	char pad_85[3];  // 0x55(0x3)
	int32_t BurleySampleCount;  // 0x58(0x4)
	char pad_92[4];  // 0x5C(0x4)

}; 



// Class MovieRenderPipelineCore.MoviePipelineDebugSettings
// Size: 0x58(Inherited: 0x48) 
struct UMoviePipelineDebugSettings : public UMoviePipelineSetting
{
	char pad_72_1 : 7;  // 0x48(0x1)
	bool bWriteAllSamples : 1;  // 0x48(0x1)
	char pad_73_1 : 7;  // 0x49(0x1)
	bool bCaptureFramesWithRenderDoc : 1;  // 0x49(0x1)
	char pad_74[2];  // 0x4A(0x2)
	int32_t CaptureFrame;  // 0x4C(0x4)
	char pad_80[8];  // 0x50(0x8)

}; 



// Class MovieRenderPipelineCore.MoviePipelineBlueprintLibrary
// Size: 0x28(Inherited: 0x28) 
struct UMoviePipelineBlueprintLibrary : public UBlueprintFunctionLibrary
{

	void UpdateJobShotListFromSequence(struct ULevelSequence* InSequence, struct UMoviePipelineExecutorJob* InJob, bool& bShotsChanged); // Function MovieRenderPipelineCore.MoviePipelineBlueprintLibrary.UpdateJobShotListFromSequence
	int32_t ResolveVersionNumber(struct FMoviePipelineFilenameResolveParams InParams); // Function MovieRenderPipelineCore.MoviePipelineBlueprintLibrary.ResolveVersionNumber
	void ResolveFilenameFormatArguments(struct FString InFormatString, struct FMoviePipelineFilenameResolveParams& InParams, struct FString& OutFinalPath, struct FMoviePipelineFormatArgs& OutMergedFormatArgs); // Function MovieRenderPipelineCore.MoviePipelineBlueprintLibrary.ResolveFilenameFormatArguments
	uint8_t  GetPipelineState(struct UMoviePipeline* InPipeline); // Function MovieRenderPipelineCore.MoviePipelineBlueprintLibrary.GetPipelineState
	void GetOverallSegmentCounts(struct UMoviePipeline* InMoviePipeline, int32_t& OutCurrentIndex, int32_t& OutTotalCount); // Function MovieRenderPipelineCore.MoviePipelineBlueprintLibrary.GetOverallSegmentCounts
	void GetOverallOutputFrames(struct UMoviePipeline* InMoviePipeline, int32_t& OutCurrentIndex, int32_t& OutTotalCount); // Function MovieRenderPipelineCore.MoviePipelineBlueprintLibrary.GetOverallOutputFrames
	struct FTimecode GetMasterTimecode(struct UMoviePipeline* InMoviePipeline); // Function MovieRenderPipelineCore.MoviePipelineBlueprintLibrary.GetMasterTimecode
	struct FFrameNumber GetMasterFrameNumber(struct UMoviePipeline* InMoviePipeline); // Function MovieRenderPipelineCore.MoviePipelineBlueprintLibrary.GetMasterFrameNumber
	struct FString GetMapPackageName(struct UMoviePipelineExecutorJob* InJob); // Function MovieRenderPipelineCore.MoviePipelineBlueprintLibrary.GetMapPackageName
	struct FText GetJobName(struct UMoviePipeline* InMoviePipeline); // Function MovieRenderPipelineCore.MoviePipelineBlueprintLibrary.GetJobName
	struct FDateTime GetJobInitializationTime(struct UMoviePipeline* InMoviePipeline); // Function MovieRenderPipelineCore.MoviePipelineBlueprintLibrary.GetJobInitializationTime
	struct FText GetJobAuthor(struct UMoviePipeline* InMoviePipeline); // Function MovieRenderPipelineCore.MoviePipelineBlueprintLibrary.GetJobAuthor
	bool GetEstimatedTimeRemaining(struct UMoviePipeline* InPipeline, struct FTimespan& OutEstimate); // Function MovieRenderPipelineCore.MoviePipelineBlueprintLibrary.GetEstimatedTimeRemaining
	struct FIntPoint GetEffectiveOutputResolution(struct UMoviePipelineMasterConfig* InMasterConfig, struct UMoviePipelineExecutorShot* InPipelineExecutorShot); // Function MovieRenderPipelineCore.MoviePipelineBlueprintLibrary.GetEffectiveOutputResolution
	struct FTimecode GetCurrentShotTimecode(struct UMoviePipeline* InMoviePipeline); // Function MovieRenderPipelineCore.MoviePipelineBlueprintLibrary.GetCurrentShotTimecode
	struct FFrameNumber GetCurrentShotFrameNumber(struct UMoviePipeline* InMoviePipeline); // Function MovieRenderPipelineCore.MoviePipelineBlueprintLibrary.GetCurrentShotFrameNumber
	struct FMoviePipelineSegmentWorkMetrics GetCurrentSegmentWorkMetrics(struct UMoviePipeline* InMoviePipeline); // Function MovieRenderPipelineCore.MoviePipelineBlueprintLibrary.GetCurrentSegmentWorkMetrics
	uint8_t  GetCurrentSegmentState(struct UMoviePipeline* InMoviePipeline); // Function MovieRenderPipelineCore.MoviePipelineBlueprintLibrary.GetCurrentSegmentState
	void GetCurrentSegmentName(struct UMoviePipeline* InMoviePipeline, struct FText& OutOuterName, struct FText& OutInnerName); // Function MovieRenderPipelineCore.MoviePipelineBlueprintLibrary.GetCurrentSegmentName
	float GetCurrentFocusDistance(struct UMoviePipeline* InMoviePipeline); // Function MovieRenderPipelineCore.MoviePipelineBlueprintLibrary.GetCurrentFocusDistance
	float GetCurrentFocalLength(struct UMoviePipeline* InMoviePipeline); // Function MovieRenderPipelineCore.MoviePipelineBlueprintLibrary.GetCurrentFocalLength
	float GetCurrentAperture(struct UMoviePipeline* InMoviePipeline); // Function MovieRenderPipelineCore.MoviePipelineBlueprintLibrary.GetCurrentAperture
	float GetCompletionPercentage(struct UMoviePipeline* InPipeline); // Function MovieRenderPipelineCore.MoviePipelineBlueprintLibrary.GetCompletionPercentage
	struct UMoviePipelineSetting* FindOrGetDefaultSettingForShot(UMoviePipelineSetting* InSettingType, struct UMoviePipelineMasterConfig* InMasterConfig, struct UMoviePipelineExecutorShot* InShot); // Function MovieRenderPipelineCore.MoviePipelineBlueprintLibrary.FindOrGetDefaultSettingForShot
	struct UMovieSceneSequence* DuplicateSequence(struct UObject* Outer, struct UMovieSceneSequence* InSequence); // Function MovieRenderPipelineCore.MoviePipelineBlueprintLibrary.DuplicateSequence
}; 



// Class MovieRenderPipelineCore.MoviePipelineRenderPass
// Size: 0x48(Inherited: 0x48) 
struct UMoviePipelineRenderPass : public UMoviePipelineSetting
{

}; 



// Class MovieRenderPipelineCore.MoviePipelineCameraSetting
// Size: 0x50(Inherited: 0x48) 
struct UMoviePipelineCameraSetting : public UMoviePipelineSetting
{
	uint8_t  ShutterTiming;  // 0x48(0x1)
	char pad_73[3];  // 0x49(0x3)
	float OverscanPercentage;  // 0x4C(0x4)

}; 



// Class MovieRenderPipelineCore.MoviePipelineCommandLineEncoder
// Size: 0x88(Inherited: 0x48) 
struct UMoviePipelineCommandLineEncoder : public UMoviePipelineSetting
{
	struct FString FileNameFormatOverride;  // 0x48(0x10)
	uint8_t  Quality;  // 0x58(0x1)
	char pad_89[7];  // 0x59(0x7)
	struct FString AdditionalCommandLineArgs;  // 0x60(0x10)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool bDeleteSourceFiles : 1;  // 0x70(0x1)
	char pad_113_1 : 7;  // 0x71(0x1)
	bool bSkipEncodeOnRenderCanceled : 1;  // 0x71(0x1)
	char pad_114[22];  // 0x72(0x16)

}; 



// Class MovieRenderPipelineCore.MoviePipelineColorSetting
// Size: 0xB0(Inherited: 0x48) 
struct UMoviePipelineColorSetting : public UMoviePipelineSetting
{
	struct FOpenColorIODisplayConfiguration OCIOConfiguration;  // 0x48(0x60)
	char pad_168_1 : 7;  // 0xA8(0x1)
	bool bDisableToneCurve : 1;  // 0xA8(0x1)
	char pad_169[7];  // 0xA9(0x7)

}; 



// Class MovieRenderPipelineCore.MoviePipelineCommandLineEncoderSettings
// Size: 0x100(Inherited: 0x38) 
struct UMoviePipelineCommandLineEncoderSettings : public UDeveloperSettings
{
	struct FString ExecutablePath;  // 0x38(0x10)
	struct FText CodecHelpText;  // 0x48(0x18)
	struct FString VideoCodec;  // 0x60(0x10)
	struct FString AudioCodec;  // 0x70(0x10)
	struct FString OutputFileExtension;  // 0x80(0x10)
	struct FString CommandLineFormat;  // 0x90(0x10)
	struct FString VideoInputStringFormat;  // 0xA0(0x10)
	struct FString AudioInputStringFormat;  // 0xB0(0x10)
	struct FString EncodeSettings_Low;  // 0xC0(0x10)
	struct FString EncodeSettings_Med;  // 0xD0(0x10)
	struct FString EncodeSettings_High;  // 0xE0(0x10)
	struct FString EncodeSettings_Epic;  // 0xF0(0x10)

}; 



// Class MovieRenderPipelineCore.MoviePipelineConfigBase
// Size: 0x50(Inherited: 0x28) 
struct UMoviePipelineConfigBase : public UObject
{
	struct FString DisplayName;  // 0x28(0x10)
	struct TArray<struct UMoviePipelineSetting*> Settings;  // 0x38(0x10)
	char pad_72[8];  // 0x48(0x8)

	void RemoveSetting(struct UMoviePipelineSetting* InSetting); // Function MovieRenderPipelineCore.MoviePipelineConfigBase.RemoveSetting
	struct TArray<struct UMoviePipelineSetting*> GetUserSettings(); // Function MovieRenderPipelineCore.MoviePipelineConfigBase.GetUserSettings
	struct TArray<struct UMoviePipelineSetting*> FindSettingsByClass(UMoviePipelineSetting* InClass, bool bIncludeDisabledSettings); // Function MovieRenderPipelineCore.MoviePipelineConfigBase.FindSettingsByClass
	struct UMoviePipelineSetting* FindSettingByClass(UMoviePipelineSetting* InClass, bool bIncludeDisabledSettings); // Function MovieRenderPipelineCore.MoviePipelineConfigBase.FindSettingByClass
	struct UMoviePipelineSetting* FindOrAddSettingByClass(UMoviePipelineSetting* InClass, bool bIncludeDisabledSettings); // Function MovieRenderPipelineCore.MoviePipelineConfigBase.FindOrAddSettingByClass
	void CopyFrom(struct UMoviePipelineConfigBase* InConfig); // Function MovieRenderPipelineCore.MoviePipelineConfigBase.CopyFrom
}; 



// Class MovieRenderPipelineCore.MoviePipelineOutputBase
// Size: 0x48(Inherited: 0x48) 
struct UMoviePipelineOutputBase : public UMoviePipelineSetting
{

}; 



// Class MovieRenderPipelineCore.MoviePipelineFCPXMLExporter
// Size: 0x80(Inherited: 0x48) 
struct UMoviePipelineFCPXMLExporter : public UMoviePipelineOutputBase
{
	char pad_72[8];  // 0x48(0x8)
	struct FString FileNameFormatOverride;  // 0x50(0x10)
	uint8_t  DataSource;  // 0x60(0x1)
	char pad_97[31];  // 0x61(0x1F)

}; 



// Class MovieRenderPipelineCore.MoviePipelineGameMode
// Size: 0x2C0(Inherited: 0x2C0) 
struct AMoviePipelineGameMode : public AGameModeBase
{

}; 



// Class MovieRenderPipelineCore.MoviePipelineGameOverrideSetting
// Size: 0x108(Inherited: 0x48) 
struct UMoviePipelineGameOverrideSetting : public UMoviePipelineSetting
{
	AGameModeBase* GameModeOverride;  // 0x48(0x8)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool bCinematicQualitySettings : 1;  // 0x50(0x1)
	uint8_t  TextureStreaming;  // 0x51(0x1)
	char pad_82_1 : 7;  // 0x52(0x1)
	bool bUseLODZero : 1;  // 0x52(0x1)
	char pad_83_1 : 7;  // 0x53(0x1)
	bool bDisableHLODs : 1;  // 0x53(0x1)
	char pad_84_1 : 7;  // 0x54(0x1)
	bool bUseHighQualityShadows : 1;  // 0x54(0x1)
	char pad_85[3];  // 0x55(0x3)
	int32_t ShadowDistanceScale;  // 0x58(0x4)
	float ShadowRadiusThreshold;  // 0x5C(0x4)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool bOverrideViewDistanceScale : 1;  // 0x60(0x1)
	char pad_97[3];  // 0x61(0x3)
	int32_t ViewDistanceScale;  // 0x64(0x4)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool bFlushGrassStreaming : 1;  // 0x68(0x1)
	char pad_105[159];  // 0x69(0x9F)

}; 



// Class MovieRenderPipelineCore.MoviePipelineViewFamilySetting
// Size: 0x48(Inherited: 0x48) 
struct UMoviePipelineViewFamilySetting : public UMoviePipelineSetting
{

}; 



// Class MovieRenderPipelineCore.MoviePipelineLinearExecutorBase
// Size: 0x130(Inherited: 0x108) 
struct UMoviePipelineLinearExecutorBase : public UMoviePipelineExecutorBase
{
	struct UMoviePipelineQueue* Queue;  // 0x108(0x8)
	struct UMoviePipeline* ActiveMoviePipeline;  // 0x110(0x8)
	char pad_280[24];  // 0x118(0x18)

}; 



// Class MovieRenderPipelineCore.MoviePipelineInProcessExecutorSettings
// Size: 0x68(Inherited: 0x38) 
struct UMoviePipelineInProcessExecutorSettings : public UDeveloperSettings
{
	char pad_56_1 : 7;  // 0x38(0x1)
	bool bCloseEditor : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct FString AdditionalCommandLineArguments;  // 0x40(0x10)
	struct FString InheritedCommandLineArguments;  // 0x50(0x10)
	int32_t InitialDelayFrameCount;  // 0x60(0x4)
	char pad_100[4];  // 0x64(0x4)

}; 



// Class MovieRenderPipelineCore.MoviePipelineMasterConfig
// Size: 0xB8(Inherited: 0x50) 
struct UMoviePipelineMasterConfig : public UMoviePipelineConfigBase
{
	struct TMap<struct FString, struct UMoviePipelineShotConfig*> PerShotConfigMapping;  // 0x50(0x50)
	struct UMoviePipelineOutputSetting* OutputSetting;  // 0xA0(0x8)
	struct TArray<struct UMoviePipelineSetting*> TransientSettings;  // 0xA8(0x10)

	void InitializeTransientSettings(); // Function MovieRenderPipelineCore.MoviePipelineMasterConfig.InitializeTransientSettings
	struct TArray<struct UMoviePipelineSetting*> GetTransientSettings(); // Function MovieRenderPipelineCore.MoviePipelineMasterConfig.GetTransientSettings
	struct FFrameRate GetEffectiveFrameRate(struct ULevelSequence* InSequence); // Function MovieRenderPipelineCore.MoviePipelineMasterConfig.GetEffectiveFrameRate
	struct TArray<struct UMoviePipelineSetting*> GetAllSettings(bool bIncludeDisabledSettings, bool bIncludeTransientSettings); // Function MovieRenderPipelineCore.MoviePipelineMasterConfig.GetAllSettings
}; 



// Class MovieRenderPipelineCore.MoviePipelineOutputSetting
// Size: 0xB0(Inherited: 0x48) 
struct UMoviePipelineOutputSetting : public UMoviePipelineSetting
{
	struct FDirectoryPath OutputDirectory;  // 0x48(0x10)
	struct FString FileNameFormat;  // 0x58(0x10)
	struct FIntPoint OutputResolution;  // 0x68(0x8)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool bUseCustomFrameRate : 1;  // 0x70(0x1)
	char pad_113[3];  // 0x71(0x3)
	struct FFrameRate OutputFrameRate;  // 0x74(0x8)
	char pad_124[4];  // 0x7C(0x4)
	char pad_128_1 : 7;  // 0x80(0x1)
	bool bOverrideExistingOutput : 1;  // 0x80(0x1)
	char pad_129[3];  // 0x81(0x3)
	int32_t HandleFrameCount;  // 0x84(0x4)
	int32_t OutputFrameStep;  // 0x88(0x4)
	char pad_140_1 : 7;  // 0x8C(0x1)
	bool bUseCustomPlaybackRange : 1;  // 0x8C(0x1)
	char pad_141[3];  // 0x8D(0x3)
	int32_t CustomStartFrame;  // 0x90(0x4)
	int32_t CustomEndFrame;  // 0x94(0x4)
	int32_t VersionNumber;  // 0x98(0x4)
	char pad_156_1 : 7;  // 0x9C(0x1)
	bool bAutoVersion : 1;  // 0x9C(0x1)
	char pad_157[3];  // 0x9D(0x3)
	int32_t ZeroPadFrameNumbers;  // 0xA0(0x4)
	int32_t FrameNumberOffset;  // 0xA4(0x4)
	char pad_168_1 : 7;  // 0xA8(0x1)
	bool bFlushDiskWritesPerShot : 1;  // 0xA8(0x1)
	char pad_169[7];  // 0xA9(0x7)

}; 



// Class MovieRenderPipelineCore.MoviePipelinePythonHostExecutor
// Size: 0x120(Inherited: 0x108) 
struct UMoviePipelinePythonHostExecutor : public UMoviePipelineExecutorBase
{
	UMoviePipelinePythonHostExecutor* ExecutorClass;  // 0x108(0x8)
	struct UMoviePipelineQueue* PipelineQueue;  // 0x110(0x8)
	struct UWorld* LastLoadedWorld;  // 0x118(0x8)

	void OnMapLoad(struct UWorld* InWorld); // Function MovieRenderPipelineCore.MoviePipelinePythonHostExecutor.OnMapLoad
	struct UWorld* GetLastLoadedWorld(); // Function MovieRenderPipelineCore.MoviePipelinePythonHostExecutor.GetLastLoadedWorld
	void ExecuteDelayed(struct UMoviePipelineQueue* InPipelineQueue); // Function MovieRenderPipelineCore.MoviePipelinePythonHostExecutor.ExecuteDelayed
}; 



// Class MovieRenderPipelineCore.MoviePipelineExecutorShot
// Size: 0x130(Inherited: 0x28) 
struct UMoviePipelineExecutorShot : public UObject
{
	char pad_40_1 : 7;  // 0x28(0x1)
	bool bEnabled : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct FString OuterName;  // 0x30(0x10)
	struct FString InnerName;  // 0x40(0x10)
	char pad_80[152];  // 0x50(0x98)
	float Progress;  // 0xE8(0x4)
	char pad_236[4];  // 0xEC(0x4)
	struct FString StatusMessage;  // 0xF0(0x10)
	struct UMoviePipelineShotConfig* ShotOverrideConfig;  // 0x100(0x8)
	struct TSoftObjectPtr<UMoviePipelineShotConfig> ShotOverridePresetOrigin;  // 0x108(0x28)

	bool ShouldRender(); // Function MovieRenderPipelineCore.MoviePipelineExecutorShot.ShouldRender
	void SetStatusProgress(float InProgress); // Function MovieRenderPipelineCore.MoviePipelineExecutorShot.SetStatusProgress
	void SetStatusMessage(struct FString InStatus); // Function MovieRenderPipelineCore.MoviePipelineExecutorShot.SetStatusMessage
	void SetShotOverridePresetOrigin(struct UMoviePipelineShotConfig* InPreset); // Function MovieRenderPipelineCore.MoviePipelineExecutorShot.SetShotOverridePresetOrigin
	void SetShotOverrideConfiguration(struct UMoviePipelineShotConfig* InPreset); // Function MovieRenderPipelineCore.MoviePipelineExecutorShot.SetShotOverrideConfiguration
	float GetStatusProgress(); // Function MovieRenderPipelineCore.MoviePipelineExecutorShot.GetStatusProgress
	struct FString GetStatusMessage(); // Function MovieRenderPipelineCore.MoviePipelineExecutorShot.GetStatusMessage
	struct UMoviePipelineShotConfig* GetShotOverridePresetOrigin(); // Function MovieRenderPipelineCore.MoviePipelineExecutorShot.GetShotOverridePresetOrigin
	struct UMoviePipelineShotConfig* GetShotOverrideConfiguration(); // Function MovieRenderPipelineCore.MoviePipelineExecutorShot.GetShotOverrideConfiguration
	struct UMoviePipelineShotConfig* AllocateNewShotOverrideConfig(UMoviePipelineShotConfig* InConfigType); // Function MovieRenderPipelineCore.MoviePipelineExecutorShot.AllocateNewShotOverrideConfig
}; 



// Class MovieRenderPipelineCore.MoviePipelineExecutorJob
// Size: 0xE0(Inherited: 0x28) 
struct UMoviePipelineExecutorJob : public UObject
{
	struct FString JobName;  // 0x28(0x10)
	struct FSoftObjectPath Sequence;  // 0x38(0x18)
	struct FSoftObjectPath Map;  // 0x50(0x18)
	struct FString Author;  // 0x68(0x10)
	struct TArray<struct UMoviePipelineExecutorShot*> ShotInfo;  // 0x78(0x10)
	struct FString UserData;  // 0x88(0x10)
	struct FString StatusMessage;  // 0x98(0x10)
	float StatusProgress;  // 0xA8(0x4)
	char pad_172_1 : 7;  // 0xAC(0x1)
	bool bIsConsumed : 1;  // 0xAC(0x1)
	char pad_173[3];  // 0xAD(0x3)
	struct UMoviePipelineMasterConfig* Configuration;  // 0xB0(0x8)
	struct TSoftObjectPtr<UMoviePipelineMasterConfig> PresetOrigin;  // 0xB8(0x28)

	void SetStatusProgress(float InProgress); // Function MovieRenderPipelineCore.MoviePipelineExecutorJob.SetStatusProgress
	void SetStatusMessage(struct FString InStatus); // Function MovieRenderPipelineCore.MoviePipelineExecutorJob.SetStatusMessage
	void SetSequence(struct FSoftObjectPath InSequence); // Function MovieRenderPipelineCore.MoviePipelineExecutorJob.SetSequence
	void SetPresetOrigin(struct UMoviePipelineMasterConfig* InPreset); // Function MovieRenderPipelineCore.MoviePipelineExecutorJob.SetPresetOrigin
	void SetConsumed(bool bInConsumed); // Function MovieRenderPipelineCore.MoviePipelineExecutorJob.SetConsumed
	void SetConfiguration(struct UMoviePipelineMasterConfig* InPreset); // Function MovieRenderPipelineCore.MoviePipelineExecutorJob.SetConfiguration
	void OnDuplicated(); // Function MovieRenderPipelineCore.MoviePipelineExecutorJob.OnDuplicated
	bool IsConsumed(); // Function MovieRenderPipelineCore.MoviePipelineExecutorJob.IsConsumed
	float GetStatusProgress(); // Function MovieRenderPipelineCore.MoviePipelineExecutorJob.GetStatusProgress
	struct FString GetStatusMessage(); // Function MovieRenderPipelineCore.MoviePipelineExecutorJob.GetStatusMessage
	struct UMoviePipelineMasterConfig* GetPresetOrigin(); // Function MovieRenderPipelineCore.MoviePipelineExecutorJob.GetPresetOrigin
	struct UMoviePipelineMasterConfig* GetConfiguration(); // Function MovieRenderPipelineCore.MoviePipelineExecutorJob.GetConfiguration
}; 



// Class MovieRenderPipelineCore.MoviePipelineQueue
// Size: 0x40(Inherited: 0x28) 
struct UMoviePipelineQueue : public UObject
{
	struct TArray<struct UMoviePipelineExecutorJob*> Jobs;  // 0x28(0x10)
	char pad_56[8];  // 0x38(0x8)

	struct TArray<struct UMoviePipelineExecutorJob*> GetJobs(); // Function MovieRenderPipelineCore.MoviePipelineQueue.GetJobs
	struct UMoviePipelineExecutorJob* DuplicateJob(struct UMoviePipelineExecutorJob* InJob); // Function MovieRenderPipelineCore.MoviePipelineQueue.DuplicateJob
	void DeleteJob(struct UMoviePipelineExecutorJob* InJob); // Function MovieRenderPipelineCore.MoviePipelineQueue.DeleteJob
	void CopyFrom(struct UMoviePipelineQueue* InQueue); // Function MovieRenderPipelineCore.MoviePipelineQueue.CopyFrom
	struct UMoviePipelineExecutorJob* AllocateNewJob(UMoviePipelineExecutorJob* InJobType); // Function MovieRenderPipelineCore.MoviePipelineQueue.AllocateNewJob
}; 



// Class MovieRenderPipelineCore.MoviePipelineVideoOutputBase
// Size: 0x88(Inherited: 0x48) 
struct UMoviePipelineVideoOutputBase : public UMoviePipelineOutputBase
{
	char pad_72[64];  // 0x48(0x40)

}; 



// Class MovieRenderPipelineCore.MoviePipelineQueueEngineSubsystem
// Size: 0x40(Inherited: 0x30) 
struct UMoviePipelineQueueEngineSubsystem : public UEngineSubsystem
{
	struct UMoviePipelineExecutorBase* ActiveExecutor;  // 0x30(0x8)
	struct UMoviePipelineQueue* CurrentQueue;  // 0x38(0x8)

	void RenderQueueWithExecutorInstance(struct UMoviePipelineExecutorBase* InExecutor); // Function MovieRenderPipelineCore.MoviePipelineQueueEngineSubsystem.RenderQueueWithExecutorInstance
	struct UMoviePipelineExecutorBase* RenderQueueWithExecutor(UMoviePipelineExecutorBase* InExecutorType); // Function MovieRenderPipelineCore.MoviePipelineQueueEngineSubsystem.RenderQueueWithExecutor
	bool IsRendering(); // Function MovieRenderPipelineCore.MoviePipelineQueueEngineSubsystem.IsRendering
	struct UMoviePipelineQueue* GetQueue(); // Function MovieRenderPipelineCore.MoviePipelineQueueEngineSubsystem.GetQueue
	struct UMoviePipelineExecutorBase* GetActiveExecutor(); // Function MovieRenderPipelineCore.MoviePipelineQueueEngineSubsystem.GetActiveExecutor
}; 



// Class MovieRenderPipelineCore.MoviePipelineShotConfig
// Size: 0x50(Inherited: 0x50) 
struct UMoviePipelineShotConfig : public UMoviePipelineConfigBase
{

}; 



// Class MovieRenderPipelineCore.MovieRenderDebugWidget
// Size: 0x260(Inherited: 0x260) 
struct UMovieRenderDebugWidget : public UUserWidget
{

	void OnInitializedForPipeline(struct UMoviePipeline* ForPipeline); // Function MovieRenderPipelineCore.MovieRenderDebugWidget.OnInitializedForPipeline
}; 



