#pragma once 
#include <CheckInBigReward_WidgetBP_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass CheckInBigReward_WidgetBP.CheckInBigReward_WidgetBP_C
// Size: 0xB88(Inherited: 0xB50) 
struct UCheckInBigReward_WidgetBP_C : public UPortalWarsCheckInRewardWidget
{
	struct UImage* Image_268;  // 0xB50(0x8)
	struct UImage* Image_459;  // 0xB58(0x8)
	struct UImage* RewardBG;  // 0xB60(0x8)
	struct UImage* RewardCompletedBG;  // 0xB68(0x8)
	struct UImage* RewardImage_2;  // 0xB70(0x8)
	struct UImage* RewardMissesdBG;  // 0xB78(0x8)
	struct UImage* Shadow;  // 0xB80(0x8)

}; 



