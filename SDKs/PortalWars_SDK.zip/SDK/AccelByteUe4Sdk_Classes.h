#pragma once 
#include <AccelByteUe4Sdk_Structs.h>
 
 
 
// Class AccelByteUe4Sdk.AccelByteBlueprintsAchievement
// Size: 0x28(Inherited: 0x28) 
struct UAccelByteBlueprintsAchievement : public UBlueprintFunctionLibrary
{

	void UnlockAchievement(struct FString AchievementCode, struct FDelegate& OnSuccess, struct FDelegate& OnError); // Function AccelByteUe4Sdk.AccelByteBlueprintsAchievement.UnlockAchievement
	void QueryUserAchievementsSuccess__DelegateSignature(struct FAccelByteModelsPaginatedUserAchievement& Result); // DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsAchievement.QueryUserAchievementsSuccess__DelegateSignature
	void QueryUserAchievements(uint8_t & SortBy, struct FDelegate& OnSuccess, struct FDelegate& OnError, int32_t& Offset, int32_t& Limit); // Function AccelByteUe4Sdk.AccelByteBlueprintsAchievement.QueryUserAchievements
	void QueryAchievementsSuccess__DelegateSignature(struct FAccelByteModelsPaginatedPublicAchievement& Result); // DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsAchievement.QueryAchievementsSuccess__DelegateSignature
	void QueryAchievements(struct FString Language, uint8_t & SortBy, struct FDelegate& OnSuccess, struct FDelegate& OnError, int32_t& Offset, int32_t& Limit); // Function AccelByteUe4Sdk.AccelByteBlueprintsAchievement.QueryAchievements
	void GetAchievementSuccess__DelegateSignature(struct FAccelByteModelsMultiLanguageAchievement& Result); // DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsAchievement.GetAchievementSuccess__DelegateSignature
	void GetAchievement(struct FString AchievementCode, struct FDelegate& OnSuccess, struct FDelegate& OnError); // Function AccelByteUe4Sdk.AccelByteBlueprintsAchievement.GetAchievement
}; 



// Class AccelByteUe4Sdk.AccelByteBlueprintsItem
// Size: 0x28(Inherited: 0x28) 
struct UAccelByteBlueprintsItem : public UBlueprintFunctionLibrary
{

	void SearchItemSuccess__DelegateSignature(struct FAccelByteModelsItemPagingSlicedResult& Result); // DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsItem.SearchItemSuccess__DelegateSignature
	void SearchItem(struct FString Language, struct FString Keyword, int32_t Page, int32_t Size, struct FString Region, struct FDelegate& OnSuccess, struct FDelegate& OnError); // Function AccelByteUe4Sdk.AccelByteBlueprintsItem.SearchItem
	void GetItemsByCriteriaSuccess__DelegateSignature(struct FAccelByteModelsItemPagingSlicedResult& Result); // DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsItem.GetItemsByCriteriaSuccess__DelegateSignature
	void GetItemsByCriteria(struct FAccelByteModelsItemCriteria& ItemCriteria, int32_t& Offset, int32_t& Limit, struct FDelegate& OnSuccess, struct FDelegate& OnError); // Function AccelByteUe4Sdk.AccelByteBlueprintsItem.GetItemsByCriteria
	void GetItemByIdSuccess__DelegateSignature(struct FAccelByteModelsPopulatedItemInfo& Result); // DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsItem.GetItemByIdSuccess__DelegateSignature
	void GetItemById(struct FString ItemId, struct FString Region, struct FString Language, struct FDelegate& OnSuccess, struct FDelegate& OnError); // Function AccelByteUe4Sdk.AccelByteBlueprintsItem.GetItemById
	void GetItemByAppIdSuccess__DelegateSignature(struct FAccelByteModelsItemInfo& Result); // DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsItem.GetItemByAppIdSuccess__DelegateSignature
	void GetItemByAppId(struct FString AppId, struct FString Region, struct FString Language, struct FDelegate& OnSuccess, struct FDelegate& OnError); // Function AccelByteUe4Sdk.AccelByteBlueprintsItem.GetItemByAppId
	void BlueprintErrorHandler__DelegateSignature(int32_t ErrorCode, struct FString ErrorMessage); // DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsItem.BlueprintErrorHandler__DelegateSignature
}; 



// Class AccelByteUe4Sdk.AccelByteBlueprintsCurrency
// Size: 0x28(Inherited: 0x28) 
struct UAccelByteBlueprintsCurrency : public UBlueprintFunctionLibrary
{

	void GetCurrencyListSuccess__DelegateSignature(struct TArray<struct FAccelByteModelsCurrencyList>& Result); // DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsCurrency.GetCurrencyListSuccess__DelegateSignature
	void GetCurrencyList(struct FString Namespace, struct FDelegate& OnSuccess, struct FDelegate& OnError); // Function AccelByteUe4Sdk.AccelByteBlueprintsCurrency.GetCurrencyList
	void BlueprintErrorHandler__DelegateSignature(int32_t ErrorCode, struct FString ErrorMessage); // DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsCurrency.BlueprintErrorHandler__DelegateSignature
}; 



// Class AccelByteUe4Sdk.AccelByteBlueprintsCategory
// Size: 0x28(Inherited: 0x28) 
struct UAccelByteBlueprintsCategory : public UBlueprintFunctionLibrary
{

	void GetRootCategoriesSuccess__DelegateSignature(struct TArray<struct FAccelByteModelsCategoryInfo>& Result); // DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsCategory.GetRootCategoriesSuccess__DelegateSignature
	void GetRootCategories(struct FString Language, struct FDelegate& OnSuccess, struct FDelegate& OnError); // Function AccelByteUe4Sdk.AccelByteBlueprintsCategory.GetRootCategories
	void GetDescendantCategoriesSuccess__DelegateSignature(struct TArray<struct FAccelByteModelsCategoryInfo>& Result); // DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsCategory.GetDescendantCategoriesSuccess__DelegateSignature
	void GetDescendantCategories(struct FString Language, struct FString CategoryPath, struct FDelegate& OnSuccess, struct FDelegate& OnError); // Function AccelByteUe4Sdk.AccelByteBlueprintsCategory.GetDescendantCategories
	void GetChildCategoriesSuccess__DelegateSignature(struct TArray<struct FAccelByteModelsCategoryInfo>& Result); // DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsCategory.GetChildCategoriesSuccess__DelegateSignature
	void GetChildCategories(struct FString Language, struct FString CategoryPath, struct FDelegate& OnSuccess, struct FDelegate& OnError); // Function AccelByteUe4Sdk.AccelByteBlueprintsCategory.GetChildCategories
	void GetCategorySuccess__DelegateSignature(struct FAccelByteModelsCategoryInfo& Result); // DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsCategory.GetCategorySuccess__DelegateSignature
	void GetCategory(struct FString ParentPath, struct FString Language, struct FDelegate& OnSuccess, struct FDelegate& OnError); // Function AccelByteUe4Sdk.AccelByteBlueprintsCategory.GetCategory
	void BlueprintErrorHandler__DelegateSignature(int32_t ErrorCode, struct FString ErrorMessage); // DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsCategory.BlueprintErrorHandler__DelegateSignature
}; 



// Class AccelByteUe4Sdk.AccelByteBlueprintsCredentials
// Size: 0x28(Inherited: 0x28) 
struct UAccelByteBlueprintsCredentials : public UBlueprintFunctionLibrary
{

	struct FString GetUserSessionId(); // Function AccelByteUe4Sdk.AccelByteBlueprintsCredentials.GetUserSessionId
	struct FString GetUserNamespace(); // Function AccelByteUe4Sdk.AccelByteBlueprintsCredentials.GetUserNamespace
	struct FString GetUserId(); // Function AccelByteUe4Sdk.AccelByteBlueprintsCredentials.GetUserId
	struct FString GetUserEmailAddress(); // Function AccelByteUe4Sdk.AccelByteBlueprintsCredentials.GetUserEmailAddress
	struct FString GetUserDisplayName(); // Function AccelByteUe4Sdk.AccelByteBlueprintsCredentials.GetUserDisplayName
}; 



// Class AccelByteUe4Sdk.AccelByteBlueprintsCloudStorage
// Size: 0x28(Inherited: 0x28) 
struct UAccelByteBlueprintsCloudStorage : public UBlueprintFunctionLibrary
{

	void UpdateSlotSuccess__DelegateSignature(struct FAccelByteModelsSlot& Result); // DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsCloudStorage.UpdateSlotSuccess__DelegateSignature
	void UpdateSlotMetadataSuccess__DelegateSignature(struct FAccelByteModelsSlot& Result); // DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsCloudStorage.UpdateSlotMetadataSuccess__DelegateSignature
	void UpdateSlotMetadata(struct FString SlotId, struct FString Filename, struct TArray<struct FString>& Tags, struct FString Label, struct FString CustomAttribute, struct FDelegate& OnSuccess, struct FDelegate& OnError); // Function AccelByteUe4Sdk.AccelByteBlueprintsCloudStorage.UpdateSlotMetadata
	void UpdateSlot(struct FString SlotId, struct FString Filename, struct TArray<char>& Data, struct TArray<struct FString>& Tags, struct FString Label, struct FString CustomAttribute, struct FDelegate& OnSuccess, struct FDelegate& OnError); // Function AccelByteUe4Sdk.AccelByteBlueprintsCloudStorage.UpdateSlot
	void GetSlotSuccess__DelegateSignature(struct TArray<char>& Result); // DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsCloudStorage.GetSlotSuccess__DelegateSignature
	void GetSlot(struct FString SlotId, struct FDelegate& OnSuccess, struct FDelegate& OnError); // Function AccelByteUe4Sdk.AccelByteBlueprintsCloudStorage.GetSlot
	void GetAllSlotsSuccess__DelegateSignature(struct TArray<struct FAccelByteModelsSlot>& Result); // DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsCloudStorage.GetAllSlotsSuccess__DelegateSignature
	void GetAllSlots(struct FDelegate& OnSuccess, struct FDelegate& OnError); // Function AccelByteUe4Sdk.AccelByteBlueprintsCloudStorage.GetAllSlots
	void DeleteSlotSuccees__DelegateSignature(); // DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsCloudStorage.DeleteSlotSuccees__DelegateSignature
	void DeleteSlot(struct FString SlotId, struct FDelegate& OnSuccess, struct FDelegate& OnError); // Function AccelByteUe4Sdk.AccelByteBlueprintsCloudStorage.DeleteSlot
	void CreateSlotsSuccess__DelegateSignature(struct FAccelByteModelsSlot& Result); // DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsCloudStorage.CreateSlotsSuccess__DelegateSignature
	void CreateSlot(struct TArray<char>& Data, struct FString Filename, struct TArray<struct FString>& Tags, struct FString Label, struct FString CustomAttribute, struct FDelegate& OnSuccess, struct FDelegate& OnError); // Function AccelByteUe4Sdk.AccelByteBlueprintsCloudStorage.CreateSlot
	void BlueprintErrorHandler__DelegateSignature(int32_t ErrorCode, struct FString ErrorMessage); // DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsCloudStorage.BlueprintErrorHandler__DelegateSignature
}; 



// Class AccelByteUe4Sdk.AccelByteBlueprintsGameProfile
// Size: 0x28(Inherited: 0x28) 
struct UAccelByteBlueprintsGameProfile : public UBlueprintFunctionLibrary
{

	void UpdateGameProfileSuccess__DelegateSignature(struct FAccelByteModelsGameProfile& Result); // DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsGameProfile.UpdateGameProfileSuccess__DelegateSignature
	void UpdateGameProfileAttributeSuccess__DelegateSignature(struct FAccelByteModelsGameProfile& Result); // DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsGameProfile.UpdateGameProfileAttributeSuccess__DelegateSignature
	void UpdateGameProfileAttribute(struct FString profileId, struct FAccelByteModelsGameProfileAttribute& Attribute, struct FDelegate& OnSuccess, struct FDelegate& OnError); // Function AccelByteUe4Sdk.AccelByteBlueprintsGameProfile.UpdateGameProfileAttribute
	void UpdateGameProfile(struct FString profileId, struct FAccelByteModelsGameProfileRequest& GameProfileRequest, struct FDelegate& OnSuccess, struct FDelegate& OnError); // Function AccelByteUe4Sdk.AccelByteBlueprintsGameProfile.UpdateGameProfile
	void GetGameProfileSuccess__DelegateSignature(struct FAccelByteModelsGameProfile& Result); // DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsGameProfile.GetGameProfileSuccess__DelegateSignature
	void GetGameProfileAttributeSuccess__DelegateSignature(struct FAccelByteModelsGameProfileAttribute& Result); // DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsGameProfile.GetGameProfileAttributeSuccess__DelegateSignature
	void GetGameProfileAttribute(struct FString profileId, struct FString AttributeName, struct FDelegate& OnSuccess, struct FDelegate& OnError); // Function AccelByteUe4Sdk.AccelByteBlueprintsGameProfile.GetGameProfileAttribute
	void GetGameProfile(struct FString profileId, struct FDelegate& OnSuccess, struct FDelegate& OnError); // Function AccelByteUe4Sdk.AccelByteBlueprintsGameProfile.GetGameProfile
	void GetAllGameProfilesSuccess__DelegateSignature(struct TArray<struct FAccelByteModelsGameProfile>& Result); // DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsGameProfile.GetAllGameProfilesSuccess__DelegateSignature
	void GetAllGameProfiles(struct FDelegate& OnSuccess, struct FDelegate& OnError); // Function AccelByteUe4Sdk.AccelByteBlueprintsGameProfile.GetAllGameProfiles
	void DeleteGameProfileSuccess__DelegateSignature(); // DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsGameProfile.DeleteGameProfileSuccess__DelegateSignature
	void DeleteGameProfile(struct FString profileId, struct FDelegate& OnSuccess, struct FDelegate& OnError); // Function AccelByteUe4Sdk.AccelByteBlueprintsGameProfile.DeleteGameProfile
	void CreateGameProfileSuccess__DelegateSignature(struct FAccelByteModelsGameProfile& Result); // DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsGameProfile.CreateGameProfileSuccess__DelegateSignature
	void CreateGameProfile(struct FAccelByteModelsGameProfileRequest& GameProfileRequest, struct FDelegate& OnSuccess, struct FDelegate& OnError); // Function AccelByteUe4Sdk.AccelByteBlueprintsGameProfile.CreateGameProfile
	void BlueprintErrorHandler__DelegateSignature(int32_t ErrorCode, struct FString ErrorMessage); // DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsGameProfile.BlueprintErrorHandler__DelegateSignature
	void BatchGetPublicGameProfilesSuccess__DelegateSignature(struct TArray<struct FAccelByteModelsPublicGameProfile>& Result); // DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsGameProfile.BatchGetPublicGameProfilesSuccess__DelegateSignature
	void BatchGetPublicGameProfiles(struct TArray<struct FString> UserIds, struct FDelegate& OnSuccess, struct FDelegate& OnError); // Function AccelByteUe4Sdk.AccelByteBlueprintsGameProfile.BatchGetPublicGameProfiles
}; 



// Class AccelByteUe4Sdk.BPUser
// Size: 0x28(Inherited: 0x28) 
struct UBPUser : public UBlueprintFunctionLibrary
{

	void Verify(struct FString VerificationCode, struct FDelegate& OnSuccess, struct FDelegate& OnError); // Function AccelByteUe4Sdk.BPUser.Verify
	void UpgradeAndVerify(struct FString Username, struct FString Password, struct FString VerificationCode, struct FDelegate& OnSuccess, struct FDelegate& OnError); // Function AccelByteUe4Sdk.BPUser.UpgradeAndVerify
	void Upgrade(struct FString Username, struct FString Password, struct FDelegate& OnSuccess, struct FDelegate& OnError); // Function AccelByteUe4Sdk.BPUser.Upgrade
	void UnlinkOtherPlatform(uint8_t  PlatformType, struct FDelegate& OnSuccess, struct FDelegate& OnError); // Function AccelByteUe4Sdk.BPUser.UnlinkOtherPlatform
	void SendVerificationCode(struct FDelegate& OnSuccess, struct FDelegate& OnError); // Function AccelByteUe4Sdk.BPUser.SendVerificationCode
	void SendUpgradeVerificationCode(struct FString Email, struct FDelegate& OnSuccess, struct FDelegate& OnError); // Function AccelByteUe4Sdk.BPUser.SendUpgradeVerificationCode
	void SendResetPasswordCode(struct FString Username, struct FDelegate& OnSuccess, struct FDelegate& OnError); // Function AccelByteUe4Sdk.BPUser.SendResetPasswordCode
	void ResetPassword(struct FString VerificationCode, struct FString Username, struct FString NewPassword, struct FDelegate& OnSuccess, struct FDelegate& OnError); // Function AccelByteUe4Sdk.BPUser.ResetPassword
	void Register(struct FString Username, struct FString Password, struct FString DisplayName, struct FString Country, struct FString DateOfBirth, struct FDelegate& OnSuccess, struct FDelegate& OnError); // Function AccelByteUe4Sdk.BPUser.Register
	void Logout(struct FDelegate& OnSuccess, struct FDelegate& OnError); // Function AccelByteUe4Sdk.BPUser.Logout
	void LoginWithUsername(struct FString Username, struct FString Password, struct FDelegate& OnSuccess, struct FDelegate& OnError); // Function AccelByteUe4Sdk.BPUser.LoginWithUsername
	void LoginWithOtherPlatform(uint8_t  PlatformType, struct FString Token, struct FDelegate& OnSuccess, struct FDelegate& OnError); // Function AccelByteUe4Sdk.BPUser.LoginWithOtherPlatform
	void LoginWithDeviceId(struct FDelegate& OnSuccess, struct FDelegate& OnError); // Function AccelByteUe4Sdk.BPUser.LoginWithDeviceId
	void LinkOtherPlatform(uint8_t  PlatformType, struct FString Ticket, struct FDelegate& OnSuccess, struct FDelegate& OnError); // Function AccelByteUe4Sdk.BPUser.LinkOtherPlatform
	void GetUserEligibleToPlay(struct FDelegate& OnSuccess, struct FDelegate& OnError); // Function AccelByteUe4Sdk.BPUser.GetUserEligibleToPlay
	void GetPlatformLinks(struct FDelegate& OnSuccess, struct FDelegate& OnError); // Function AccelByteUe4Sdk.BPUser.GetPlatformLinks
	void ForgetAllCredentials(); // Function AccelByteUe4Sdk.BPUser.ForgetAllCredentials
}; 



// Class AccelByteUe4Sdk.AccelByteSettingsProd
// Size: 0x1C0(Inherited: 0x1C0) 
struct UAccelByteSettingsProd : public UAccelByteSettings
{

}; 



// Class AccelByteUe4Sdk.AccelByteBlueprintsEntitlement
// Size: 0x28(Inherited: 0x28) 
struct UAccelByteBlueprintsEntitlement : public UBlueprintFunctionLibrary
{

	void QueryUserEntitlementSuccess__DelegateSignature(struct FAccelByteModelsEntitlementPagingSlicedResult& Result); // DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsEntitlement.QueryUserEntitlementSuccess__DelegateSignature
	void QueryUserEntitlementsMany(struct FString EntitlementName, struct TArray<struct FString>& ItemIds, int32_t Page, int32_t Size, struct FDelegate& OnSuccess, struct FDelegate& OnError, uint8_t  EntitlementClass, uint8_t  AppType); // Function AccelByteUe4Sdk.AccelByteBlueprintsEntitlement.QueryUserEntitlementsMany
	void QueryUserEntitlements(struct FString EntitlementName, struct FString ItemId, int32_t Page, int32_t Size, struct FDelegate& OnSuccess, struct FDelegate& OnError, uint8_t  EntitlementClass, uint8_t  AppType); // Function AccelByteUe4Sdk.AccelByteBlueprintsEntitlement.QueryUserEntitlements
	void BlueprintErrorHandler__DelegateSignature(int32_t ErrorCode, struct FString ErrorMessage); // DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsEntitlement.BlueprintErrorHandler__DelegateSignature
}; 



// Class AccelByteUe4Sdk.AccelByteBlueprintsLobby
// Size: 0x28(Inherited: 0x28) 
struct UAccelByteBlueprintsLobby : public UBlueprintFunctionLibrary
{

	void UserPresenceNotice__DelegateSignature(struct FAccelByteModelsUsersPresenceNotice& Result); // DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsLobby.UserPresenceNotice__DelegateSignature
	void UnfriendResponseDelegate__DelegateSignature(struct FAccelByteModelsUnfriendResponse& Result); // DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsLobby.UnfriendResponseDelegate__DelegateSignature
	void Unfriend(struct FString UserId); // Function AccelByteUe4Sdk.AccelByteBlueprintsLobby.Unfriend
	void UnbindDelegates(); // Function AccelByteUe4Sdk.AccelByteBlueprintsLobby.UnbindDelegates
	void SetUserPresenceResponseDelegate(struct FDelegate OnUserPresenceResponse); // Function AccelByteUe4Sdk.AccelByteBlueprintsLobby.SetUserPresenceResponseDelegate
	void SetUserPresenceResponse__DelegateSignature(struct FAccelByteModelsSetOnlineUsersResponse& Result); // DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsLobby.SetUserPresenceResponse__DelegateSignature
	void SetUnfriendResponseDelegate(struct FDelegate OnUnfriendResponse); // Function AccelByteUe4Sdk.AccelByteBlueprintsLobby.SetUnfriendResponseDelegate
	void SetStartMatchmakingResponseDelegate(struct FDelegate OnMatchmakingStart); // Function AccelByteUe4Sdk.AccelByteBlueprintsLobby.SetStartMatchmakingResponseDelegate
	void SetRequestFriendResponseDelegate(struct FDelegate OnRequestFriendsResponseDelegate); // Function AccelByteUe4Sdk.AccelByteBlueprintsLobby.SetRequestFriendResponseDelegate
	void SetRematchmakingNotifDelegate(struct FDelegate OnRematchmakingNotice); // Function AccelByteUe4Sdk.AccelByteBlueprintsLobby.SetRematchmakingNotifDelegate
	void SetRejectFriendResponseDelegate(struct FDelegate OnRejectFriendsResponse); // Function AccelByteUe4Sdk.AccelByteBlueprintsLobby.SetRejectFriendResponseDelegate
	void SetReadyConsentResponseDelegate(struct FDelegate OnReadyConsentResponse); // Function AccelByteUe4Sdk.AccelByteBlueprintsLobby.SetReadyConsentResponseDelegate
	void SetReadyConsentNotifDelegate(struct FDelegate OnReadyConsentNotice); // Function AccelByteUe4Sdk.AccelByteBlueprintsLobby.SetReadyConsentNotifDelegate
	void SetPrivateMessageResponseDelegate(struct FDelegate OnPrivateMessageResponse); // Function AccelByteUe4Sdk.AccelByteBlueprintsLobby.SetPrivateMessageResponseDelegate
	void SetPresenceStatus(uint8_t  State, struct FString Activity); // Function AccelByteUe4Sdk.AccelByteBlueprintsLobby.SetPresenceStatus
	void SetPartyMessageResponseDelegate(struct FDelegate OnPartyMessageResponse); // Function AccelByteUe4Sdk.AccelByteBlueprintsLobby.SetPartyMessageResponseDelegate
	void SetMatchmakingNotifDelegate(struct FDelegate OnMatchmakingNotice); // Function AccelByteUe4Sdk.AccelByteBlueprintsLobby.SetMatchmakingNotifDelegate
	void SetLoadFriendsListResponseDelegate(struct FDelegate OnLoadFriendListResponse); // Function AccelByteUe4Sdk.AccelByteBlueprintsLobby.SetLoadFriendsListResponseDelegate
	void SetListOutgoingFriendsResponseDelegate(struct FDelegate OnListOutgoingFriendsResponse); // Function AccelByteUe4Sdk.AccelByteBlueprintsLobby.SetListOutgoingFriendsResponseDelegate
	void SetListIncomingFriendsResponseDelegate(struct FDelegate OnListIncomingFriendsResponse); // Function AccelByteUe4Sdk.AccelByteBlueprintsLobby.SetListIncomingFriendsResponseDelegate
	void SetLeavePartyResponseDelegate(struct FDelegate OnLeavePartyResponse); // Function AccelByteUe4Sdk.AccelByteBlueprintsLobby.SetLeavePartyResponseDelegate
	void SetInvitePartyResponseDelegate(struct FDelegate OnInvitePartyResponse); // Function AccelByteUe4Sdk.AccelByteBlueprintsLobby.SetInvitePartyResponseDelegate
	void SetInvitePartyKickMemberResponseDelegate(struct FDelegate OnInvitePartyKickMemberResponse); // Function AccelByteUe4Sdk.AccelByteBlueprintsLobby.SetInvitePartyKickMemberResponseDelegate
	void SetInvitePartyJoinResponseDelegate(struct FDelegate OnInvitePartyJoinResponse); // Function AccelByteUe4Sdk.AccelByteBlueprintsLobby.SetInvitePartyJoinResponseDelegate
	void SetInfoPartyResponseDelegate(struct FDelegate OnInfoPartyResponse); // Function AccelByteUe4Sdk.AccelByteBlueprintsLobby.SetInfoPartyResponseDelegate
	void SetGetFriendshipStatusResponseDelegate(struct FDelegate OnGetFriendshipStatusResponse); // Function AccelByteUe4Sdk.AccelByteBlueprintsLobby.SetGetFriendshipStatusResponseDelegate
	void SetGetAllUserPresenceResponseDelegate(struct FDelegate OnGetAllUserPresenceResponse); // Function AccelByteUe4Sdk.AccelByteBlueprintsLobby.SetGetAllUserPresenceResponseDelegate
	void SetDsNotifDelegate(struct FDelegate OnDsNotice); // Function AccelByteUe4Sdk.AccelByteBlueprintsLobby.SetDsNotifDelegate
	void SetCreatePartyResponseDelegate(struct FDelegate OnCreatePartyResponse); // Function AccelByteUe4Sdk.AccelByteBlueprintsLobby.SetCreatePartyResponseDelegate
	void SetCancelMatchmakingResponseDelegate(struct FDelegate OnMatchmakingCancel); // Function AccelByteUe4Sdk.AccelByteBlueprintsLobby.SetCancelMatchmakingResponseDelegate
	void SetCancelFriendRequestResponseDelegate(struct FDelegate OnCancelFriendsResponse); // Function AccelByteUe4Sdk.AccelByteBlueprintsLobby.SetCancelFriendRequestResponseDelegate
	void SetAcceptFriendResponseDelegate(struct FDelegate OnAcceptFriendsResponse); // Function AccelByteUe4Sdk.AccelByteBlueprintsLobby.SetAcceptFriendResponseDelegate
	void SendStartMatchmaking(struct FString GameMode); // Function AccelByteUe4Sdk.AccelByteBlueprintsLobby.SendStartMatchmaking
	void SendReadyConsentRequest(struct FString MatchID); // Function AccelByteUe4Sdk.AccelByteBlueprintsLobby.SendReadyConsentRequest
	void SendPrivateMessage(struct FString UserId, struct FString Message); // Function AccelByteUe4Sdk.AccelByteBlueprintsLobby.SendPrivateMessage
	void SendPing(); // Function AccelByteUe4Sdk.AccelByteBlueprintsLobby.SendPing
	void SendPartyMessage(struct FString Message); // Function AccelByteUe4Sdk.AccelByteBlueprintsLobby.SendPartyMessage
	void SendLeavePartyRequest(); // Function AccelByteUe4Sdk.AccelByteBlueprintsLobby.SendLeavePartyRequest
	void SendKickPartyMemberRequest(struct FString UserId); // Function AccelByteUe4Sdk.AccelByteBlueprintsLobby.SendKickPartyMemberRequest
	void SendInviteToPartyRequest(struct FString UserId); // Function AccelByteUe4Sdk.AccelByteBlueprintsLobby.SendInviteToPartyRequest
	void SendInfoPartyRequest(); // Function AccelByteUe4Sdk.AccelByteBlueprintsLobby.SendInfoPartyRequest
	void SendGetOnlineUsersRequest(); // Function AccelByteUe4Sdk.AccelByteBlueprintsLobby.SendGetOnlineUsersRequest
	void SendCreatePartyRequest(); // Function AccelByteUe4Sdk.AccelByteBlueprintsLobby.SendCreatePartyRequest
	void SendCancelMatchmaking(struct FString GameMode); // Function AccelByteUe4Sdk.AccelByteBlueprintsLobby.SendCancelMatchmaking
	void SendAcceptInvitationRequest(struct FString PartyId, struct FString InvitationToken); // Function AccelByteUe4Sdk.AccelByteBlueprintsLobby.SendAcceptInvitationRequest
	void RequestFriendsResponseDelegate__DelegateSignature(struct FAccelByteModelsRequestFriendsResponse& Result); // DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsLobby.RequestFriendsResponseDelegate__DelegateSignature
	void RequestFriend(struct FString UserId); // Function AccelByteUe4Sdk.AccelByteBlueprintsLobby.RequestFriend
	void RematchmakingNotice__DelegateSignature(struct FAccelByteModelsRematchmakingNotice& Result); // DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsLobby.RematchmakingNotice__DelegateSignature
	void RejectFriendsResponseDelegate__DelegateSignature(struct FAccelByteModelsRejectFriendsResponse& Result); // DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsLobby.RejectFriendsResponseDelegate__DelegateSignature
	void RejectFriend(struct FString UserId); // Function AccelByteUe4Sdk.AccelByteBlueprintsLobby.RejectFriend
	void ReadyConsentResponse__DelegateSignature(struct FAccelByteModelsReadyConsentRequest& Result); // DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsLobby.ReadyConsentResponse__DelegateSignature
	void ReadyConsentNotice__DelegateSignature(struct FAccelByteModelsReadyConsentNotice& Result); // DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsLobby.ReadyConsentNotice__DelegateSignature
	void PrivateMessageResponse__DelegateSignature(struct FAccelByteModelsPersonalMessageResponse& Result); // DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsLobby.PrivateMessageResponse__DelegateSignature
	void PrivateMessageNotice__DelegateSignature(struct FAccelByteModelsPersonalMessageNotice& Result); // DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsLobby.PrivateMessageNotice__DelegateSignature
	void PartyMessageResponse__DelegateSignature(struct FAccelByteModelsPartyMessageResponse& Result); // DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsLobby.PartyMessageResponse__DelegateSignature
	void PartyMessageNotice__DelegateSignature(struct FAccelByteModelsPartyMessageNotice& Result); // DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsLobby.PartyMessageNotice__DelegateSignature
	void NotificationMessage__DelegateSignature(struct FAccelByteModelsNotificationMessage& Result); // DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsLobby.NotificationMessage__DelegateSignature
	void MatchmakingResponse__DelegateSignature(struct FAccelByteModelsMatchmakingResponse& Result); // DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsLobby.MatchmakingResponse__DelegateSignature
	void MatchmakingNotice__DelegateSignature(struct FAccelByteModelsMatchmakingNotice& Result); // DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsLobby.MatchmakingNotice__DelegateSignature
	void LoadFriendsList(); // Function AccelByteUe4Sdk.AccelByteBlueprintsLobby.LoadFriendsList
	void LoadFriendListResponseDelegate__DelegateSignature(struct FAccelByteModelsLoadFriendListResponse& Result); // DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsLobby.LoadFriendListResponseDelegate__DelegateSignature
	void ListOutgoingFriendsResponseDelegate__DelegateSignature(struct FAccelByteModelsListOutgoingFriendsResponse& Result); // DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsLobby.ListOutgoingFriendsResponseDelegate__DelegateSignature
	void ListOutgoingFriends(); // Function AccelByteUe4Sdk.AccelByteBlueprintsLobby.ListOutgoingFriends
	void ListIncomingFriendsResponseDelegate__DelegateSignature(struct FAccelByteModelsListIncomingFriendsResponse& Result); // DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsLobby.ListIncomingFriendsResponseDelegate__DelegateSignature
	void ListIncomingFriends(); // Function AccelByteUe4Sdk.AccelByteBlueprintsLobby.ListIncomingFriends
	void LeavePartyResponse__DelegateSignature(struct FAccelByteModelsLeavePartyResponse& Result); // DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsLobby.LeavePartyResponse__DelegateSignature
	void LeavePartyNotice__DelegateSignature(struct FAccelByteModelsLeavePartyNotice& Result); // DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsLobby.LeavePartyNotice__DelegateSignature
	bool IsConnected(); // Function AccelByteUe4Sdk.AccelByteBlueprintsLobby.IsConnected
	void InvitePartyResponse__DelegateSignature(struct FAccelByteModelsPartyInviteResponse& Result); // DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsLobby.InvitePartyResponse__DelegateSignature
	void InvitePartyKickMemberResponse__DelegateSignature(struct FAccelByteModelsKickPartyMemberResponse& Result); // DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsLobby.InvitePartyKickMemberResponse__DelegateSignature
	void InvitePartyKickedNotice__DelegateSignature(struct FAccelByteModelsGotKickedFromPartyNotice& Result); // DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsLobby.InvitePartyKickedNotice__DelegateSignature
	void InvitePartyJoinResponse__DelegateSignature(struct FAccelByteModelsPartyJoinReponse& Result); // DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsLobby.InvitePartyJoinResponse__DelegateSignature
	void InvitePartyJoinNotice__DelegateSignature(struct FAccelByteModelsPartyJoinNotice& Result); // DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsLobby.InvitePartyJoinNotice__DelegateSignature
	void InvitePartyInvitationNotice__DelegateSignature(struct FAccelByteModelsInvitationNotice& Result); // DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsLobby.InvitePartyInvitationNotice__DelegateSignature
	void InvitePartyGetInvitedNotice__DelegateSignature(struct FAccelByteModelsPartyGetInvitedNotice& Result); // DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsLobby.InvitePartyGetInvitedNotice__DelegateSignature
	void InfoPartyResponse__DelegateSignature(struct FAccelByteModelsInfoPartyResponse& Result); // DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsLobby.InfoPartyResponse__DelegateSignature
	void IncomingFriendNotif__DelegateSignature(struct FAccelByteModelsRequestFriendsNotif& Result); // DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsLobby.IncomingFriendNotif__DelegateSignature
	void GetFriendshipStatusResponseDelegate__DelegateSignature(struct FAccelByteModelsGetFriendshipStatusResponse& Result); // DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsLobby.GetFriendshipStatusResponseDelegate__DelegateSignature
	void GetFriendshipStatus(struct FString UserId); // Function AccelByteUe4Sdk.AccelByteBlueprintsLobby.GetFriendshipStatus
	void GetAllFriendsStatusResponse__DelegateSignature(struct FAccelByteModelsGetOnlineUsersResponse& Result); // DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsLobby.GetAllFriendsStatusResponse__DelegateSignature
	void GetAllAsyncNotification(); // Function AccelByteUe4Sdk.AccelByteBlueprintsLobby.GetAllAsyncNotification
	void FriendAcceptFriendRequestNotif__DelegateSignature(struct FAccelByteModelsAcceptFriendsNotif& Result); // DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsLobby.FriendAcceptFriendRequestNotif__DelegateSignature
	void DsNotice__DelegateSignature(struct FAccelByteModelsDsNotice& Result); // DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsLobby.DsNotice__DelegateSignature
	void Disconnect(); // Function AccelByteUe4Sdk.AccelByteBlueprintsLobby.Disconnect
	void CreatePartyResponse__DelegateSignature(struct FAccelByteModelsCreatePartyResponse& Result); // DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsLobby.CreatePartyResponse__DelegateSignature
	void ConnectSuccess__DelegateSignature(); // DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsLobby.ConnectSuccess__DelegateSignature
	void ConnectionClosed__DelegateSignature(int32_t StatusCode, struct FString Reason, bool WasClean); // DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsLobby.ConnectionClosed__DelegateSignature
	void Connect(); // Function AccelByteUe4Sdk.AccelByteBlueprintsLobby.Connect
	void CancelFriendsResponseDelegate__DelegateSignature(struct FAccelByteModelsCancelFriendsResponse& Result); // DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsLobby.CancelFriendsResponseDelegate__DelegateSignature
	void CancelFriendRequest(struct FString UserId); // Function AccelByteUe4Sdk.AccelByteBlueprintsLobby.CancelFriendRequest
	void BlueprintErrorHandler__DelegateSignature(int32_t ErrorCode, struct FString ErrorMessage); // DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsLobby.BlueprintErrorHandler__DelegateSignature
	void BindEvent(struct FDelegate& OnConnectSuccess, struct FDelegate& OnConnectError, struct FDelegate& OnConnectionClosed, struct FDelegate& OnLeavePartyNotice, struct FDelegate& OnInvitePartyInvitationNotice, struct FDelegate& OnInvitePartyGetInvitedNotice, struct FDelegate& OnInvitePartyJoinNotice, struct FDelegate& OnInvitePartyKickedNotice, struct FDelegate& OnPrivateMessageNotice, struct FDelegate& OnPartyMessageNotice, struct FDelegate& OnUserPresenceNotice, struct FDelegate& OnNotificationMessage, struct FDelegate& OnMatchmakingNotice, struct FDelegate& OnReadyConsentNotice, struct FDelegate& OnRematchmakingNotice, struct FDelegate& OnDsNotice, struct FDelegate& OnAcceptFriendsNotifDelegate, struct FDelegate& OnRequestFriendsNotifDelegate, struct FDelegate& OnParsingError); // Function AccelByteUe4Sdk.AccelByteBlueprintsLobby.BindEvent
	void AcceptFriendsResponseDelegate__DelegateSignature(struct FAccelByteModelsAcceptFriendsResponse& Result); // DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsLobby.AcceptFriendsResponseDelegate__DelegateSignature
	void AcceptFriend(struct FString UserId); // Function AccelByteUe4Sdk.AccelByteBlueprintsLobby.AcceptFriend
}; 



// Class AccelByteUe4Sdk.AccelByteBlueprintsOrder
// Size: 0x28(Inherited: 0x28) 
struct UAccelByteBlueprintsOrder : public UBlueprintFunctionLibrary
{

	void GetUserOrderSuccess__DelegateSignature(struct FAccelByteModelsOrderInfo& Result); // DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsOrder.GetUserOrderSuccess__DelegateSignature
	void GetUserOrdersSuccess__DelegateSignature(struct FAccelByteModelsPagedOrderInfo& Result); // DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsOrder.GetUserOrdersSuccess__DelegateSignature
	void GetUserOrders(int32_t Page, int32_t Size, struct FDelegate& OnSuccess, struct FDelegate& OnError); // Function AccelByteUe4Sdk.AccelByteBlueprintsOrder.GetUserOrders
	void GetUserOrderHistorySuccess__DelegateSignature(struct TArray<struct FAccelByteModelsOrderHistoryInfo>& Result); // DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsOrder.GetUserOrderHistorySuccess__DelegateSignature
	void GetUserOrderHistory(struct FString OrderNo, struct FDelegate& OnSuccess, struct FDelegate& OnError); // Function AccelByteUe4Sdk.AccelByteBlueprintsOrder.GetUserOrderHistory
	void GetUserOrder(struct FString OrderNo, struct FDelegate& OnSuccess, struct FDelegate& OnError); // Function AccelByteUe4Sdk.AccelByteBlueprintsOrder.GetUserOrder
	void CreateNewOrderSuccess__DelegateSignature(struct FAccelByteModelsOrderInfo& Result); // DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsOrder.CreateNewOrderSuccess__DelegateSignature
	void CreateNewOrder(struct FAccelByteModelsOrderCreate& OrderCreate, struct FDelegate& OnSuccess, struct FDelegate& OnError); // Function AccelByteUe4Sdk.AccelByteBlueprintsOrder.CreateNewOrder
	void CancelOrderSuccess__DelegateSignature(struct FAccelByteModelsOrderInfo& Result); // DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsOrder.CancelOrderSuccess__DelegateSignature
	void CancelOrder(struct FString OrderNo, struct FDelegate& OnSuccess, struct FDelegate& OnError); // Function AccelByteUe4Sdk.AccelByteBlueprintsOrder.CancelOrder
	void BlueprintErrorHandler__DelegateSignature(int32_t ErrorCode, struct FString ErrorMessage); // DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsOrder.BlueprintErrorHandler__DelegateSignature
}; 



// Class AccelByteUe4Sdk.AccelByteBlueprintsReward
// Size: 0x28(Inherited: 0x28) 
struct UAccelByteBlueprintsReward : public UBlueprintFunctionLibrary
{

	void QueryRewardsSuccess__DelegateSignature(struct FAccelByteModelsQueryReward& Result); // DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsReward.QueryRewardsSuccess__DelegateSignature
	void QueryRewards(struct FString EventTopic, int32_t Offset, int32_t Limit, uint8_t & SortBy, struct FDelegate& OnSuccess, struct FDelegate& OnError); // Function AccelByteUe4Sdk.AccelByteBlueprintsReward.QueryRewards
	void GetRewardByRewardIdSuccess__DelegateSignature(struct FAccelByteModelsRewardInfo& Result); // DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsReward.GetRewardByRewardIdSuccess__DelegateSignature
	void GetRewardByRewardId(struct FString RewardId, struct FDelegate& OnSuccess, struct FDelegate& OnError); // Function AccelByteUe4Sdk.AccelByteBlueprintsReward.GetRewardByRewardId
	void GetRewardByRewardCodeSuccess__DelegateSignature(struct FAccelByteModelsRewardInfo& Result); // DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsReward.GetRewardByRewardCodeSuccess__DelegateSignature
	void GetRewardByRewardCode(struct FString RewardCode, struct FDelegate& OnSuccess, struct FDelegate& OnError); // Function AccelByteUe4Sdk.AccelByteBlueprintsReward.GetRewardByRewardCode
	void BlueprintErrorHandler__DelegateSignature(int32_t ErrorCode, struct FString ErrorMessage); // DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsReward.BlueprintErrorHandler__DelegateSignature
}; 



// Class AccelByteUe4Sdk.AccelByteBlueprintsServerCredentials
// Size: 0x28(Inherited: 0x28) 
struct UAccelByteBlueprintsServerCredentials : public UBlueprintFunctionLibrary
{

	struct FString GetMatchId(); // Function AccelByteUe4Sdk.AccelByteBlueprintsServerCredentials.GetMatchId
	struct FString GetClientNamespace(); // Function AccelByteUe4Sdk.AccelByteBlueprintsServerCredentials.GetClientNamespace
	struct FString GetClientAccessToken(); // Function AccelByteUe4Sdk.AccelByteBlueprintsServerCredentials.GetClientAccessToken
}; 



// Class AccelByteUe4Sdk.AccelByteServerSettings
// Size: 0x180(Inherited: 0x28) 
struct UAccelByteServerSettings : public UObject
{
	char pad_40_1 : 7;  // 0x28(0x1)
	bool ForceEnableSettings : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct FString ClientId;  // 0x30(0x10)
	struct FString ClientSecret;  // 0x40(0x10)
	struct FString Namespace;  // 0x50(0x10)
	struct FString PublisherNamespace;  // 0x60(0x10)
	struct FString RedirectURI;  // 0x70(0x10)
	struct FString BaseUrl;  // 0x80(0x10)
	struct FString IamServerUrl;  // 0x90(0x10)
	struct FString DSMControllerServerUrl;  // 0xA0(0x10)
	struct FString StatisticServerUrl;  // 0xB0(0x10)
	struct FString PlatformServerUrl;  // 0xC0(0x10)
	struct FString QosManagerServerUrl;  // 0xD0(0x10)
	struct FString GameTelemetryServerUrl;  // 0xE0(0x10)
	struct FString AchievementServerUrl;  // 0xF0(0x10)
	struct FString MatchmakingServerUrl;  // 0x100(0x10)
	struct FString LobbyServerUrl;  // 0x110(0x10)
	struct FString CloudSaveServerUrl;  // 0x120(0x10)
	struct FString SeasonPassServerUrl;  // 0x130(0x10)
	struct FString SessionBrowserServerUrl;  // 0x140(0x10)
	struct FString DSHubServerUrl;  // 0x150(0x10)
	struct FString SessionManagerServerUrl;  // 0x160(0x10)
	struct FString UGCServerUrl;  // 0x170(0x10)

}; 



// Class AccelByteUe4Sdk.AccelByteBlueprintsServerSettings
// Size: 0x28(Inherited: 0x28) 
struct UAccelByteBlueprintsServerSettings : public UBlueprintFunctionLibrary
{

	void SetUGCServerUrl(struct FString UGCServerUrl); // Function AccelByteUe4Sdk.AccelByteBlueprintsServerSettings.SetUGCServerUrl
	void SetStatisticServerUrl(struct FString StatisticServerUrl); // Function AccelByteUe4Sdk.AccelByteBlueprintsServerSettings.SetStatisticServerUrl
	void SetSessionManagerServerUrl(struct FString SessionManagerServerUrl); // Function AccelByteUe4Sdk.AccelByteBlueprintsServerSettings.SetSessionManagerServerUrl
	void SetSessionBrowserServerUrl(struct FString CloudServerUrl); // Function AccelByteUe4Sdk.AccelByteBlueprintsServerSettings.SetSessionBrowserServerUrl
	void SetSeasonPassServerUrl(struct FString CloudServerUrl); // Function AccelByteUe4Sdk.AccelByteBlueprintsServerSettings.SetSeasonPassServerUrl
	void SetQosManagerServerUrl(struct FString PlatformServerUrl); // Function AccelByteUe4Sdk.AccelByteBlueprintsServerSettings.SetQosManagerServerUrl
	void SetPublisherNamespace(struct FString PublisherNamespace); // Function AccelByteUe4Sdk.AccelByteBlueprintsServerSettings.SetPublisherNamespace
	void SetPlatformServerUrl(struct FString PlatformServerUrl); // Function AccelByteUe4Sdk.AccelByteBlueprintsServerSettings.SetPlatformServerUrl
	void SetNamespace(struct FString Namespace); // Function AccelByteUe4Sdk.AccelByteBlueprintsServerSettings.SetNamespace
	void SetMatchmakingServerUrl(struct FString AchievementServerUrl); // Function AccelByteUe4Sdk.AccelByteBlueprintsServerSettings.SetMatchmakingServerUrl
	void SetLobbyServerUrl(struct FString LobbyServerUrl); // Function AccelByteUe4Sdk.AccelByteBlueprintsServerSettings.SetLobbyServerUrl
	void SetIamServerUrl(struct FString IamServerUrl); // Function AccelByteUe4Sdk.AccelByteBlueprintsServerSettings.SetIamServerUrl
	void SetGameTelemetryServerUrl(struct FString GameTelemetryServerUrl); // Function AccelByteUe4Sdk.AccelByteBlueprintsServerSettings.SetGameTelemetryServerUrl
	void SetDSMControllerServerUrl(struct FString DSMControllerServerUrl); // Function AccelByteUe4Sdk.AccelByteBlueprintsServerSettings.SetDSMControllerServerUrl
	void SetDSHubServerUrl(struct FString DSHubServerUrl); // Function AccelByteUe4Sdk.AccelByteBlueprintsServerSettings.SetDSHubServerUrl
	void SetCloudSaveServerUrl(struct FString CloudServerUrl); // Function AccelByteUe4Sdk.AccelByteBlueprintsServerSettings.SetCloudSaveServerUrl
	void SetClientSecret(struct FString ClientSecret); // Function AccelByteUe4Sdk.AccelByteBlueprintsServerSettings.SetClientSecret
	void SetClientId(struct FString ClientId); // Function AccelByteUe4Sdk.AccelByteBlueprintsServerSettings.SetClientId
	void SetAchievementServerUrl(struct FString AchievementServerUrl); // Function AccelByteUe4Sdk.AccelByteBlueprintsServerSettings.SetAchievementServerUrl
	void ResetSettings(uint8_t  Environment); // Function AccelByteUe4Sdk.AccelByteBlueprintsServerSettings.ResetSettings
	struct FString GetUGCServerUrl(); // Function AccelByteUe4Sdk.AccelByteBlueprintsServerSettings.GetUGCServerUrl
	struct FString GetStatisticServerUrl(); // Function AccelByteUe4Sdk.AccelByteBlueprintsServerSettings.GetStatisticServerUrl
	struct FString GetSessionManagerServerUrl(); // Function AccelByteUe4Sdk.AccelByteBlueprintsServerSettings.GetSessionManagerServerUrl
	struct FString GetSessionBrowserServerUrl(); // Function AccelByteUe4Sdk.AccelByteBlueprintsServerSettings.GetSessionBrowserServerUrl
	struct FString GetSeasonPassServerUrl(); // Function AccelByteUe4Sdk.AccelByteBlueprintsServerSettings.GetSeasonPassServerUrl
	struct FString GetQosManagerServerUrl(); // Function AccelByteUe4Sdk.AccelByteBlueprintsServerSettings.GetQosManagerServerUrl
	struct FString GetPublisherNamespace(); // Function AccelByteUe4Sdk.AccelByteBlueprintsServerSettings.GetPublisherNamespace
	struct FString GetPlatformServerUrl(); // Function AccelByteUe4Sdk.AccelByteBlueprintsServerSettings.GetPlatformServerUrl
	struct FString GetNamespace(); // Function AccelByteUe4Sdk.AccelByteBlueprintsServerSettings.GetNamespace
	struct FString GetMatchmakingServerUrl(); // Function AccelByteUe4Sdk.AccelByteBlueprintsServerSettings.GetMatchmakingServerUrl
	struct FString GetLobbyServerUrl(); // Function AccelByteUe4Sdk.AccelByteBlueprintsServerSettings.GetLobbyServerUrl
	struct FString GetIamServerUrl(); // Function AccelByteUe4Sdk.AccelByteBlueprintsServerSettings.GetIamServerUrl
	struct FString GetGameTelemetryServerUrl(); // Function AccelByteUe4Sdk.AccelByteBlueprintsServerSettings.GetGameTelemetryServerUrl
	struct FString GetDSMControllerServerUrl(); // Function AccelByteUe4Sdk.AccelByteBlueprintsServerSettings.GetDSMControllerServerUrl
	struct FString GetDSHubServerUrl(); // Function AccelByteUe4Sdk.AccelByteBlueprintsServerSettings.GetDSHubServerUrl
	struct FString GetCloudSaveServerUrl(); // Function AccelByteUe4Sdk.AccelByteBlueprintsServerSettings.GetCloudSaveServerUrl
	struct FString GetClientSecret(); // Function AccelByteUe4Sdk.AccelByteBlueprintsServerSettings.GetClientSecret
	struct FString GetClientId(); // Function AccelByteUe4Sdk.AccelByteBlueprintsServerSettings.GetClientId
	struct FString GetAchievementServerUrl(); // Function AccelByteUe4Sdk.AccelByteBlueprintsServerSettings.GetAchievementServerUrl
}; 



// Class AccelByteUe4Sdk.AccelByteBlueprintsStatistic
// Size: 0x28(Inherited: 0x28) 
struct UAccelByteBlueprintsStatistic : public UBlueprintFunctionLibrary
{

	void IncrementUserStatItems(struct TArray<struct FAccelByteModelsBulkStatItemInc>& Data, struct FDelegate& OnSuccess, struct FDelegate& OnError); // Function AccelByteUe4Sdk.AccelByteBlueprintsStatistic.IncrementUserStatItems
	void GetUserStatItemsSuccess__DelegateSignature(struct FAccelByteModelsUserStatItemPagingSlicedResult& Result); // DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsStatistic.GetUserStatItemsSuccess__DelegateSignature
	void GetUserStatItems(struct TArray<struct FString>& StatCodes, struct TArray<struct FString>& Tags, struct FDelegate& OnSuccess, struct FDelegate& OnError); // Function AccelByteUe4Sdk.AccelByteBlueprintsStatistic.GetUserStatItems
	void GetAllUserStatItemsSuccess__DelegateSignature(struct FAccelByteModelsUserStatItemPagingSlicedResult& Result); // DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsStatistic.GetAllUserStatItemsSuccess__DelegateSignature
	void GetAllUserStatItems(struct FDelegate& OnSuccess, struct FDelegate& OnError); // Function AccelByteUe4Sdk.AccelByteBlueprintsStatistic.GetAllUserStatItems
	void CreateUserStatItemsSuccess__DelegateSignature(struct TArray<struct FAccelByteModelsBulkStatItemOperationResult>& Result); // DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsStatistic.CreateUserStatItemsSuccess__DelegateSignature
	void CreateUserStatItems(struct TArray<struct FString>& StatCodes, struct FDelegate& OnSuccess, struct FDelegate& OnError); // Function AccelByteUe4Sdk.AccelByteBlueprintsStatistic.CreateUserStatItems
	void BulkAddUserStatItemValueSuccess__DelegateSignature(struct TArray<struct FAccelByteModelsBulkStatItemOperationResult>& Result); // DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsStatistic.BulkAddUserStatItemValueSuccess__DelegateSignature
	void BlueprintErrorHandler__DelegateSignature(int32_t ErrorCode, struct FString ErrorMessage); // DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsStatistic.BlueprintErrorHandler__DelegateSignature
}; 



// Class AccelByteUe4Sdk.AccelByteSettingsCert
// Size: 0x1C0(Inherited: 0x1C0) 
struct UAccelByteSettingsCert : public UAccelByteSettings
{

}; 



// Class AccelByteUe4Sdk.AccelByteSettings
// Size: 0x1C0(Inherited: 0x28) 
struct UAccelByteSettings : public UObject
{
	struct FString ClientId;  // 0x28(0x10)
	struct FString ClientSecret;  // 0x38(0x10)
	struct FString Namespace;  // 0x48(0x10)
	struct FString PublisherNamespace;  // 0x58(0x10)
	struct FString RedirectURI;  // 0x68(0x10)
	struct FString BaseUrl;  // 0x78(0x10)
	struct FString IamServerUrl;  // 0x88(0x10)
	struct FString PlatformServerUrl;  // 0x98(0x10)
	struct FString LobbyServerUrl;  // 0xA8(0x10)
	struct FString CloudStorageServerUrl;  // 0xB8(0x10)
	struct FString BasicServerUrl;  // 0xC8(0x10)
	struct FString GameProfileServerUrl;  // 0xD8(0x10)
	struct FString StatisticServerUrl;  // 0xE8(0x10)
	struct FString QosManagerServerUrl;  // 0xF8(0x10)
	struct FString LeaderboardServerUrl;  // 0x108(0x10)
	struct FString CloudSaveServerUrl;  // 0x118(0x10)
	struct FString GameTelemetryServerUrl;  // 0x128(0x10)
	struct FString AgreementServerUrl;  // 0x138(0x10)
	struct FString AchievementServerUrl;  // 0x148(0x10)
	struct FString SessionBrowserServerUrl;  // 0x158(0x10)
	struct FString TurnManagerServerUrl;  // 0x168(0x10)
	struct FString UGCServerUrl;  // 0x178(0x10)
	struct FString ReportingServerUrl;  // 0x188(0x10)
	struct FString SessionManagerServerUrl;  // 0x198(0x10)
	struct FString AppId;  // 0x1A8(0x10)
	float GeneralTimeout;  // 0x1B8(0x4)
	char pad_444[4];  // 0x1BC(0x4)

}; 



// Class AccelByteUe4Sdk.AccelByteSettingsDev
// Size: 0x1C0(Inherited: 0x1C0) 
struct UAccelByteSettingsDev : public UAccelByteSettings
{

}; 



// Class AccelByteUe4Sdk.AccelByteBlueprintsSettings
// Size: 0x28(Inherited: 0x28) 
struct UAccelByteBlueprintsSettings : public UBlueprintFunctionLibrary
{

	void SetUGCServerUrl(struct FString UGCServerUrl); // Function AccelByteUe4Sdk.AccelByteBlueprintsSettings.SetUGCServerUrl
	void SetTurnManagerServerUrl(struct FString TurnManagerServerUrl); // Function AccelByteUe4Sdk.AccelByteBlueprintsSettings.SetTurnManagerServerUrl
	void SetStatisticServerUrl(struct FString StatisticServerUrl); // Function AccelByteUe4Sdk.AccelByteBlueprintsSettings.SetStatisticServerUrl
	void SetSessionManagerServerUrl(struct FString SessionManagerServerUrl); // Function AccelByteUe4Sdk.AccelByteBlueprintsSettings.SetSessionManagerServerUrl
	void SetSessionBrowserServerUrl(struct FString SessionBrowserServerUrl); // Function AccelByteUe4Sdk.AccelByteBlueprintsSettings.SetSessionBrowserServerUrl
	void SetSeasonPassServerUrl(struct FString SeasonPassServerUrl); // Function AccelByteUe4Sdk.AccelByteBlueprintsSettings.SetSeasonPassServerUrl
	void SetReportingServerUrl(struct FString ReportingServerUrl); // Function AccelByteUe4Sdk.AccelByteBlueprintsSettings.SetReportingServerUrl
	void SetQosManagerServerUrl(struct FString QosManagerServerUrl); // Function AccelByteUe4Sdk.AccelByteBlueprintsSettings.SetQosManagerServerUrl
	void SetPublisherNamespace(struct FString PublisherNamespace); // Function AccelByteUe4Sdk.AccelByteBlueprintsSettings.SetPublisherNamespace
	void SetPlatformServerUrl(struct FString PlatformServerUrl); // Function AccelByteUe4Sdk.AccelByteBlueprintsSettings.SetPlatformServerUrl
	void SetNamespace(struct FString Namespace); // Function AccelByteUe4Sdk.AccelByteBlueprintsSettings.SetNamespace
	void SetLobbyServerUrl(struct FString LobbyServerUrl); // Function AccelByteUe4Sdk.AccelByteBlueprintsSettings.SetLobbyServerUrl
	void SetLeaderboardServerUrl(struct FString LeaderboardServerUrl); // Function AccelByteUe4Sdk.AccelByteBlueprintsSettings.SetLeaderboardServerUrl
	void SetIamServerUrl(struct FString IamServerUrl); // Function AccelByteUe4Sdk.AccelByteBlueprintsSettings.SetIamServerUrl
	void SetGeneralTimeout(float Timeout); // Function AccelByteUe4Sdk.AccelByteBlueprintsSettings.SetGeneralTimeout
	void SetGameTelemetryServerUrl(struct FString GameTelemetryServerUrl); // Function AccelByteUe4Sdk.AccelByteBlueprintsSettings.SetGameTelemetryServerUrl
	void SetGameProfileServerUrl(struct FString GameProfileServerUrl); // Function AccelByteUe4Sdk.AccelByteBlueprintsSettings.SetGameProfileServerUrl
	void SetCloudStorageServerUrl(struct FString CloudStorageServerUrl); // Function AccelByteUe4Sdk.AccelByteBlueprintsSettings.SetCloudStorageServerUrl
	void SetCloudSaveServerUrl(struct FString CloudSaveServerUrl); // Function AccelByteUe4Sdk.AccelByteBlueprintsSettings.SetCloudSaveServerUrl
	void SetClientSecret(struct FString ClientSecret); // Function AccelByteUe4Sdk.AccelByteBlueprintsSettings.SetClientSecret
	void SetClientId(struct FString ClientId); // Function AccelByteUe4Sdk.AccelByteBlueprintsSettings.SetClientId
	void SetBasicServerUrl(struct FString BasicServerUrl); // Function AccelByteUe4Sdk.AccelByteBlueprintsSettings.SetBasicServerUrl
	void SetAppId(struct FString AppId); // Function AccelByteUe4Sdk.AccelByteBlueprintsSettings.SetAppId
	void SetAchievementServerUrl(struct FString CloudSaveServerUrl); // Function AccelByteUe4Sdk.AccelByteBlueprintsSettings.SetAchievementServerUrl
	void ResetSettings(uint8_t  Environment); // Function AccelByteUe4Sdk.AccelByteBlueprintsSettings.ResetSettings
	struct FString GetUGCServerUrl(); // Function AccelByteUe4Sdk.AccelByteBlueprintsSettings.GetUGCServerUrl
	struct FString GetTurnManagerServerUrl(); // Function AccelByteUe4Sdk.AccelByteBlueprintsSettings.GetTurnManagerServerUrl
	struct FString GetStatisticServerUrl(); // Function AccelByteUe4Sdk.AccelByteBlueprintsSettings.GetStatisticServerUrl
	struct FString GetSessionManagerServerUrl(); // Function AccelByteUe4Sdk.AccelByteBlueprintsSettings.GetSessionManagerServerUrl
	struct FString GetSessionBrowserServerUrl(); // Function AccelByteUe4Sdk.AccelByteBlueprintsSettings.GetSessionBrowserServerUrl
	struct FString GetReportingServerUrl(); // Function AccelByteUe4Sdk.AccelByteBlueprintsSettings.GetReportingServerUrl
	struct FString GetQosManagerServerUrl(); // Function AccelByteUe4Sdk.AccelByteBlueprintsSettings.GetQosManagerServerUrl
	struct FString GetPublisherNamespace(); // Function AccelByteUe4Sdk.AccelByteBlueprintsSettings.GetPublisherNamespace
	struct FString GetPlatformServerUrl(); // Function AccelByteUe4Sdk.AccelByteBlueprintsSettings.GetPlatformServerUrl
	struct FString GetNamespace(); // Function AccelByteUe4Sdk.AccelByteBlueprintsSettings.GetNamespace
	struct FString GetLobbyServerUrl(); // Function AccelByteUe4Sdk.AccelByteBlueprintsSettings.GetLobbyServerUrl
	struct FString GetLeaderboardServerUrl(); // Function AccelByteUe4Sdk.AccelByteBlueprintsSettings.GetLeaderboardServerUrl
	struct FString GetIamServerUrl(); // Function AccelByteUe4Sdk.AccelByteBlueprintsSettings.GetIamServerUrl
	float GetGeneralTimeout(); // Function AccelByteUe4Sdk.AccelByteBlueprintsSettings.GetGeneralTimeout
	struct FString GetGameTelemetryServerUrl(); // Function AccelByteUe4Sdk.AccelByteBlueprintsSettings.GetGameTelemetryServerUrl
	struct FString GetGameProfileServerUrl(); // Function AccelByteUe4Sdk.AccelByteBlueprintsSettings.GetGameProfileServerUrl
	struct FString GetCloudStorageServerUrl(); // Function AccelByteUe4Sdk.AccelByteBlueprintsSettings.GetCloudStorageServerUrl
	struct FString GetCloudSaveServerUrl(); // Function AccelByteUe4Sdk.AccelByteBlueprintsSettings.GetCloudSaveServerUrl
	struct FString GetClientSecret(); // Function AccelByteUe4Sdk.AccelByteBlueprintsSettings.GetClientSecret
	struct FString GetClientId(); // Function AccelByteUe4Sdk.AccelByteBlueprintsSettings.GetClientId
	struct FString GetBasicServerUrl(); // Function AccelByteUe4Sdk.AccelByteBlueprintsSettings.GetBasicServerUrl
	struct FString GetAppId(); // Function AccelByteUe4Sdk.AccelByteBlueprintsSettings.GetAppId
	struct FString GetAchievementServerUrl(); // Function AccelByteUe4Sdk.AccelByteBlueprintsSettings.GetAchievementServerUrl
}; 



// Class AccelByteUe4Sdk.AccelByteBlueprintsUserProfile
// Size: 0x28(Inherited: 0x28) 
struct UAccelByteBlueprintsUserProfile : public UBlueprintFunctionLibrary
{

	void UpdateUserProfileSuccess__DelegateSignature(struct FAccelByteModelsUserProfileInfo& Result); // DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsUserProfile.UpdateUserProfileSuccess__DelegateSignature
	void UpdateUserProfile(struct FAccelByteModelsUserProfileUpdateRequest& ProfileUpdateRequest, struct FDelegate& OnSuccess, struct FDelegate& OnError); // Function AccelByteUe4Sdk.AccelByteBlueprintsUserProfile.UpdateUserProfile
	void GetUserProfileSuccess__DelegateSignature(struct FAccelByteModelsUserProfileInfo& Result); // DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsUserProfile.GetUserProfileSuccess__DelegateSignature
	void GetUserProfile(struct FDelegate& OnSuccess, struct FDelegate& OnError); // Function AccelByteUe4Sdk.AccelByteBlueprintsUserProfile.GetUserProfile
	void CreateUserProfileSuccess__DelegateSignature(struct FAccelByteModelsUserProfileInfo& Result); // DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsUserProfile.CreateUserProfileSuccess__DelegateSignature
	void CreateUserProfile(struct FAccelByteModelsUserProfileCreateRequest& ProfileCreateRequest, struct FDelegate& OnSuccess, struct FDelegate& OnError); // Function AccelByteUe4Sdk.AccelByteBlueprintsUserProfile.CreateUserProfile
	void BlueprintErrorHandler__DelegateSignature(int32_t ErrorCode, struct FString ErrorMessage); // DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsUserProfile.BlueprintErrorHandler__DelegateSignature
}; 



// Class AccelByteUe4Sdk.AccelByteBlueprintsWallet
// Size: 0x28(Inherited: 0x28) 
struct UAccelByteBlueprintsWallet : public UBlueprintFunctionLibrary
{

	void GetWalletInfoByCurrencyCode(struct FString CurrencyCode, struct FDelegate& OnSuccess, struct FDelegate& OnError); // Function AccelByteUe4Sdk.AccelByteBlueprintsWallet.GetWalletInfoByCurrencyCode
	void GetWalletByCurrencyCodeSuccess__DelegateSignature(struct FAccelByteModelsWalletInfo& Result); // DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsWallet.GetWalletByCurrencyCodeSuccess__DelegateSignature
	void BlueprintErrorHandler__DelegateSignature(int32_t ErrorCode, struct FString ErrorMessage); // DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsWallet.BlueprintErrorHandler__DelegateSignature
}; 



