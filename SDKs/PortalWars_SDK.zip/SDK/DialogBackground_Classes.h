#pragma once 
#include <DialogBackground_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass DialogBackground.DialogBackground_C
// Size: 0x270(Inherited: 0x260) 
struct UDialogBackground_C : public UUserWidget
{
	struct UBackgroundBlur* BackgroundBlur_1;  // 0x260(0x8)
	struct UImage* BlurBackground;  // 0x268(0x8)

	void SetComponentVisibility(struct UWidget* Widget, bool Visible); // Function DialogBackground.DialogBackground_C.SetComponentVisibility
}; 



