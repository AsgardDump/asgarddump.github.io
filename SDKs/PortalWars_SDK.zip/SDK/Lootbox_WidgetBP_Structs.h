#pragma once 
#include "SDK.h" 
 
 
// Function Lootbox_WidgetBP.Lootbox_WidgetBP_C.ExecuteUbergraph_Lootbox_WidgetBP
// Size: 0x4(Inherited: 0x0) 
struct FExecuteUbergraph_Lootbox_WidgetBP
{
	int32_t EntryPoint;  // 0x0(0x4)

}; 
