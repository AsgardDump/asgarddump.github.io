#pragma once 
#include <ControllerSelectSettings_WidgetBP_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass ControllerSelectSettings_WidgetBP.ControllerSelectSettings_WidgetBP_C
// Size: 0x970(Inherited: 0x950) 
struct UControllerSelectSettings_WidgetBP_C : public UPortalWarsGamepadSelectWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x950(0x8)
	struct UMenuBackground_C* MenuBackground;  // 0x958(0x8)
	struct USafeZone* SafeZone_1;  // 0x960(0x8)
	struct UWBP_Footer_C* WBP_Footer;  // 0x968(0x8)

	void Construct(); // Function ControllerSelectSettings_WidgetBP.ControllerSelectSettings_WidgetBP_C.Construct
	void ExecuteUbergraph_ControllerSelectSettings_WidgetBP(int32_t EntryPoint); // Function ControllerSelectSettings_WidgetBP.ControllerSelectSettings_WidgetBP_C.ExecuteUbergraph_ControllerSelectSettings_WidgetBP
}; 



