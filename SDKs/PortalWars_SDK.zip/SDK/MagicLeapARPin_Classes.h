#pragma once 
#include <MagicLeapARPin_Structs.h>
 
 
 
// Class MagicLeapARPin.MagicLeapARPinSettings
// Size: 0x40(Inherited: 0x28) 
struct UMagicLeapARPinSettings : public UObject
{
	float UpdateCheckFrequency;  // 0x28(0x4)
	struct FMagicLeapARPinState OnUpdatedEventTriggerDelta;  // 0x2C(0x14)

}; 



// Class MagicLeapARPin.MagicLeapARPinRenderer
// Size: 0x288(Inherited: 0x220) 
struct AMagicLeapARPinRenderer : public AActor
{
	char pad_544_1 : 7;  // 0x220(0x1)
	bool bInfoActorsVisibilityOverride : 1;  // 0x220(0x1)
	char pad_545[7];  // 0x221(0x7)
	struct TMap<struct FGuid, struct AMagicLeapARPinInfoActorBase*> AllInfoActors;  // 0x228(0x50)
	char pad_632[8];  // 0x278(0x8)
	AMagicLeapARPinInfoActorBase* ClassToSpawn;  // 0x280(0x8)

	void SetVisibilityOverride(bool InVisibilityOverride); // Function MagicLeapARPin.MagicLeapARPinRenderer.SetVisibilityOverride
}; 



// Class MagicLeapARPin.MagicLeapARPinComponent
// Size: 0x3B0(Inherited: 0x200) 
struct UMagicLeapARPinComponent : public USceneComponent
{
	struct FString ObjectUID;  // 0x1F8(0x10)
	int32_t UserIndex;  // 0x208(0x4)
	uint8_t  AutoPinType;  // 0x20C(0x1)
	char pad_533_1 : 7;  // 0x215(0x1)
	bool bShouldPinActor : 1;  // 0x20D(0x1)
	UMagicLeapARPinSaveGame* PinDataClass;  // 0x210(0x8)
	struct TSet<uint8_t > SearchPinTypes;  // 0x218(0x50)
	struct USphereComponent* SearchVolume;  // 0x268(0x8)
	struct FMulticastInlineDelegate OnPersistentEntityPinned;  // 0x270(0x10)
	struct FMulticastInlineDelegate OnPersistentEntityPinLost;  // 0x280(0x10)
	struct FMulticastInlineDelegate OnPinDataLoadAttemptCompleted;  // 0x290(0x10)
	struct FGuid PinnedCFUID;  // 0x2A0(0x10)
	struct USceneComponent* PinnedSceneComponent;  // 0x2B0(0x8)
	struct UMagicLeapARPinSaveGame* PinData;  // 0x2B8(0x8)
	char pad_710[234];  // 0x2C6(0xEA)

	void UnPin(); // Function MagicLeapARPin.MagicLeapARPinComponent.UnPin
	struct UMagicLeapARPinSaveGame* TryGetPinData(UMagicLeapARPinSaveGame* InPinDataClass, bool& OutPinDataValid); // Function MagicLeapARPin.MagicLeapARPinComponent.TryGetPinData
	bool PinToRestoredOrSyncedID(); // Function MagicLeapARPin.MagicLeapARPinComponent.PinToRestoredOrSyncedID
	bool PinToID(struct FGuid& PinId); // Function MagicLeapARPin.MagicLeapARPinComponent.PinToID
	void PinToBestFit(); // Function MagicLeapARPin.MagicLeapARPinComponent.PinToBestFit
	bool PinSceneComponent(struct USceneComponent* ComponentToPin); // Function MagicLeapARPin.MagicLeapARPinComponent.PinSceneComponent
	bool PinRestoredOrSynced(); // Function MagicLeapARPin.MagicLeapARPinComponent.PinRestoredOrSynced
	bool PinActor(struct AActor* ActorToPin); // Function MagicLeapARPin.MagicLeapARPinComponent.PinActor
	void PersistentEntityPinned__DelegateSignature(bool bRestoredOrSynced); // DelegateFunction MagicLeapARPin.MagicLeapARPinComponent.PersistentEntityPinned__DelegateSignature
	void PersistentEntityPinLost__DelegateSignature(); // DelegateFunction MagicLeapARPin.MagicLeapARPinComponent.PersistentEntityPinLost__DelegateSignature
	void MagicLeapARPinDataLoadAttemptCompleted__DelegateSignature(bool bDataRestored); // DelegateFunction MagicLeapARPin.MagicLeapARPinComponent.MagicLeapARPinDataLoadAttemptCompleted__DelegateSignature
	bool IsPinned(); // Function MagicLeapARPin.MagicLeapARPinComponent.IsPinned
	bool GetPinState(struct FMagicLeapARPinState& State); // Function MagicLeapARPin.MagicLeapARPinComponent.GetPinState
	bool GetPinnedPinID(struct FGuid& PinId); // Function MagicLeapARPin.MagicLeapARPinComponent.GetPinnedPinID
	struct UMagicLeapARPinSaveGame* GetPinData(UMagicLeapARPinSaveGame* PinDataClass); // Function MagicLeapARPin.MagicLeapARPinComponent.GetPinData
	void AttemptPinDataRestorationAsync(); // Function MagicLeapARPin.MagicLeapARPinComponent.AttemptPinDataRestorationAsync
	bool AttemptPinDataRestoration(); // Function MagicLeapARPin.MagicLeapARPinComponent.AttemptPinDataRestoration
}; 



// Class MagicLeapARPin.MagicLeapARPinInfoActorBase
// Size: 0x238(Inherited: 0x220) 
struct AMagicLeapARPinInfoActorBase : public AActor
{
	struct FGuid PinId;  // 0x220(0x10)
	char pad_560_1 : 7;  // 0x230(0x1)
	bool bVisibilityOverride : 1;  // 0x230(0x1)
	char pad_561[7];  // 0x231(0x7)

	void OnUpdateARPinState(); // Function MagicLeapARPin.MagicLeapARPinInfoActorBase.OnUpdateARPinState
}; 



// Class MagicLeapARPin.MagicLeapARPinFunctionLibrary
// Size: 0x28(Inherited: 0x28) 
struct UMagicLeapARPinFunctionLibrary : public UBlueprintFunctionLibrary
{

	void UnBindToOnMagicLeapContentBindingFoundDelegate(struct FDelegate& Delegate); // Function MagicLeapARPin.MagicLeapARPinFunctionLibrary.UnBindToOnMagicLeapContentBindingFoundDelegate
	void UnBindToOnMagicLeapARPinUpdatedDelegate(struct FDelegate& Delegate); // Function MagicLeapARPin.MagicLeapARPinFunctionLibrary.UnBindToOnMagicLeapARPinUpdatedDelegate
	uint8_t  SetGlobalQueryFilter(struct FMagicLeapARPinQuery& InGlobalFilter); // Function MagicLeapARPin.MagicLeapARPinFunctionLibrary.SetGlobalQueryFilter
	void SetContentBindingSaveGameUserIndex(int32_t UserIndex); // Function MagicLeapARPin.MagicLeapARPinFunctionLibrary.SetContentBindingSaveGameUserIndex
	uint8_t  QueryARPins(struct FMagicLeapARPinQuery& Query, struct TArray<struct FGuid>& Pins); // Function MagicLeapARPin.MagicLeapARPinFunctionLibrary.QueryARPins
	bool ParseStringToARPinId(struct FString PinIdString, struct FGuid& ARPinId); // Function MagicLeapARPin.MagicLeapARPinFunctionLibrary.ParseStringToARPinId
	bool IsTrackerValid(); // Function MagicLeapARPin.MagicLeapARPinFunctionLibrary.IsTrackerValid
	uint8_t  GetNumAvailableARPins(int32_t& Count); // Function MagicLeapARPin.MagicLeapARPinFunctionLibrary.GetNumAvailableARPins
	uint8_t  GetGlobalQueryFilter(struct FMagicLeapARPinQuery& CurrentGlobalFilter); // Function MagicLeapARPin.MagicLeapARPinFunctionLibrary.GetGlobalQueryFilter
	int32_t GetContentBindingSaveGameUserIndex(); // Function MagicLeapARPin.MagicLeapARPinFunctionLibrary.GetContentBindingSaveGameUserIndex
	uint8_t  GetClosestARPin(struct FVector& SearchPoint, struct FGuid& PinId); // Function MagicLeapARPin.MagicLeapARPinFunctionLibrary.GetClosestARPin
	uint8_t  GetAvailableARPins(int32_t NumRequested, struct TArray<struct FGuid>& Pins); // Function MagicLeapARPin.MagicLeapARPinFunctionLibrary.GetAvailableARPins
	struct FString GetARPinStateToString(struct FMagicLeapARPinState& State); // Function MagicLeapARPin.MagicLeapARPinFunctionLibrary.GetARPinStateToString
	uint8_t  GetARPinState(struct FGuid& PinId, struct FMagicLeapARPinState& State); // Function MagicLeapARPin.MagicLeapARPinFunctionLibrary.GetARPinState
	bool GetARPinPositionAndOrientation_TrackingSpace(struct FGuid& PinId, struct FVector& Position, struct FRotator& Orientation, bool& PinFoundInEnvironment); // Function MagicLeapARPin.MagicLeapARPinFunctionLibrary.GetARPinPositionAndOrientation_TrackingSpace
	bool GetARPinPositionAndOrientation(struct FGuid& PinId, struct FVector& Position, struct FRotator& Orientation, bool& PinFoundInEnvironment); // Function MagicLeapARPin.MagicLeapARPinFunctionLibrary.GetARPinPositionAndOrientation
	uint8_t  DestroyTracker(); // Function MagicLeapARPin.MagicLeapARPinFunctionLibrary.DestroyTracker
	uint8_t  CreateTracker(); // Function MagicLeapARPin.MagicLeapARPinFunctionLibrary.CreateTracker
	void BindToOnMagicLeapContentBindingFoundDelegate(struct FDelegate& Delegate); // Function MagicLeapARPin.MagicLeapARPinFunctionLibrary.BindToOnMagicLeapContentBindingFoundDelegate
	void BindToOnMagicLeapARPinUpdatedDelegate(struct FDelegate& Delegate); // Function MagicLeapARPin.MagicLeapARPinFunctionLibrary.BindToOnMagicLeapARPinUpdatedDelegate
	struct FString ARPinIdToString(struct FGuid& ARPinId); // Function MagicLeapARPin.MagicLeapARPinFunctionLibrary.ARPinIdToString
}; 



// Class MagicLeapARPin.MagicLeapARPinSaveGame
// Size: 0xB0(Inherited: 0x28) 
struct UMagicLeapARPinSaveGame : public USaveGame
{
	struct FGuid PinnedID;  // 0x28(0x10)
	char pad_56[8];  // 0x38(0x8)
	struct FTransform ComponentWorldTransform;  // 0x40(0x30)
	struct FTransform PinTransform;  // 0x70(0x30)
	char pad_160_1 : 7;  // 0xA0(0x1)
	bool bShouldPinActor : 1;  // 0xA0(0x1)
	char pad_161[15];  // 0xA1(0xF)

}; 



// Class MagicLeapARPin.MagicLeapARPinContentBindings
// Size: 0x78(Inherited: 0x28) 
struct UMagicLeapARPinContentBindings : public USaveGame
{
	struct TMap<struct FGuid, struct FMagicLeapARPinObjectIdList> AllContentBindings;  // 0x28(0x50)

}; 



