#pragma once 
#include <BattlePassPurchaseDialog_WidgetBP_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass BattlePassPurchaseDialog_WidgetBP.BattlePassPurchaseDialog_WidgetBP_C
// Size: 0x930(Inherited: 0x8E8) 
struct UBattlePassPurchaseDialog_WidgetBP_C : public UPortalWarsBPPurchaseDialogWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x8E8(0x8)
	struct UImage* BG;  // 0x8F0(0x8)
	struct UImage* Image;  // 0x8F8(0x8)
	struct UImage* Image_2;  // 0x900(0x8)
	struct UImage* Image_142;  // 0x908(0x8)
	struct UWBP_PageHeader_C* PageHeader;  // 0x910(0x8)
	struct USafeZone* SafeZone_1;  // 0x918(0x8)
	struct UThrobber* Throbber_1;  // 0x920(0x8)
	struct UWBP_Footer_C* WBP_Footer;  // 0x928(0x8)

	void Construct(); // Function BattlePassPurchaseDialog_WidgetBP.BattlePassPurchaseDialog_WidgetBP_C.Construct
	void ExecuteUbergraph_BattlePassPurchaseDialog_WidgetBP(int32_t EntryPoint); // Function BattlePassPurchaseDialog_WidgetBP.BattlePassPurchaseDialog_WidgetBP_C.ExecuteUbergraph_BattlePassPurchaseDialog_WidgetBP
}; 



