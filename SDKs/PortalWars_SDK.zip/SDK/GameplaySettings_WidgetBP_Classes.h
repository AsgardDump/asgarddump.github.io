#pragma once 
#include <GameplaySettings_WidgetBP_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass GameplaySettings_WidgetBP.GameplaySettings_WidgetBP_C
// Size: 0x8F0(Inherited: 0x8C0) 
struct UGameplaySettings_WidgetBP_C : public UPortalWarsGameplaySettingsWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x8C0(0x8)
	struct UMenuBackground_C* MenuBackground;  // 0x8C8(0x8)
	struct USafeZone* SafeZone_1;  // 0x8D0(0x8)
	struct USettingsSectionHeader_C* SettingsSectionHeader;  // 0x8D8(0x8)
	struct USettingsSectionHeader_C* SettingsSectionHeader_152;  // 0x8E0(0x8)
	struct UWBP_Footer_C* WBP_Footer;  // 0x8E8(0x8)

	void Construct(); // Function GameplaySettings_WidgetBP.GameplaySettings_WidgetBP_C.Construct
	void ExecuteUbergraph_GameplaySettings_WidgetBP(int32_t EntryPoint); // Function GameplaySettings_WidgetBP.GameplaySettings_WidgetBP_C.ExecuteUbergraph_GameplaySettings_WidgetBP
}; 



