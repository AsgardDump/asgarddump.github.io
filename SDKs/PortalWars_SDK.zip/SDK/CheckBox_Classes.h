#pragma once 
#include <CheckBox_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass CheckBox.CheckBox_C
// Size: 0x5F0(Inherited: 0x5E8) 
struct UCheckBox_C : public UPortalWarsCheckBoxWidget
{
	struct UImage* Image_101;  // 0x5E8(0x8)

}; 



