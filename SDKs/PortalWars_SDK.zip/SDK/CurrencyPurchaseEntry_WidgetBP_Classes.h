#pragma once 
#include <CurrencyPurchaseEntry_WidgetBP_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass CurrencyPurchaseEntry_WidgetBP.CurrencyPurchaseEntry_WidgetBP_C
// Size: 0x838(Inherited: 0x818) 
struct UCurrencyPurchaseEntry_WidgetBP_C : public UPortalWarsCurrencyStoreEntry
{
	struct UImage* CurrencyIcon;  // 0x818(0x8)
	struct UDiscountWidget_C* DiscountWidget;  // 0x820(0x8)
	struct UImage* Image_77;  // 0x828(0x8)
	struct UImage* Image_132;  // 0x830(0x8)

}; 



