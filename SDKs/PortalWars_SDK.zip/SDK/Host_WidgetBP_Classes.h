#pragma once 
#include <Host_WidgetBP_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass Host_WidgetBP.Host_WidgetBP_C
// Size: 0x888(Inherited: 0x860) 
struct UHost_WidgetBP_C : public UPortalWarsHostMenuWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x860(0x8)
	struct UImage* Image_124;  // 0x868(0x8)
	struct UMenuBackground_C* MenuBackground;  // 0x870(0x8)
	struct USafeZone* SafeZone_1;  // 0x878(0x8)
	struct UWBP_Footer_C* WBP_Footer;  // 0x880(0x8)

	void Construct(); // Function Host_WidgetBP.Host_WidgetBP_C.Construct
	void ExecuteUbergraph_Host_WidgetBP(int32_t EntryPoint); // Function Host_WidgetBP.Host_WidgetBP_C.ExecuteUbergraph_Host_WidgetBP
}; 



