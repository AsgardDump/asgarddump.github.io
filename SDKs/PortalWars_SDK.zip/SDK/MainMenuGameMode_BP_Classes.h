#pragma once 
#include <MainMenuGameMode_BP_Structs.h>
 
 
 
// BlueprintGeneratedClass MainMenuGameMode_BP.MainMenuGameMode_BP_C
// Size: 0x2C8(Inherited: 0x2C0) 
struct AMainMenuGameMode_BP_C : public AMainMenuGameMode
{
	struct USceneComponent* DefaultSceneRoot;  // 0x2C0(0x8)

}; 



