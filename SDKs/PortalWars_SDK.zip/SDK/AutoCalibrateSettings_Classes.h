#pragma once 
#include <AutoCalibrateSettings_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass AutoCalibrateSettings.AutoCalibrateSettings_C
// Size: 0x870(Inherited: 0x860) 
struct UAutoCalibrateSettings_C : public UPortalWarsAutoSettingsWidget
{
	struct UImage* BG;  // 0x860(0x8)
	struct UThrobber* Throbber_1;  // 0x868(0x8)

}; 



