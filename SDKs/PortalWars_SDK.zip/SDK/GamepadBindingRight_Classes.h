#pragma once 
#include <GamepadBindingRight_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass GamepadBindingRight.GamepadBindingRight_C
// Size: 0x600(Inherited: 0x5F0) 
struct UGamepadBindingRight_C : public UPortalWarsGamepadBindingWidget
{
	struct UImage* ButtonIcon;  // 0x5F0(0x8)
	struct UImage* Image_101;  // 0x5F8(0x8)

}; 



