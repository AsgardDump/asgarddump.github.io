#pragma once 
#include <AccelByteCustomization_Structs.h>
 
 
 
// Class AccelByteCustomization.AccelByteBlueprintsCustomizationSettings
// Size: 0x28(Inherited: 0x28) 
struct UAccelByteBlueprintsCustomizationSettings : public UBlueprintFunctionLibrary
{

	void SetUGCServerUrl(struct FString ServerUrl); // Function AccelByteCustomization.AccelByteBlueprintsCustomizationSettings.SetUGCServerUrl
	void SetSplitgateServerUrl(struct FString InSplitgateServerUrl); // Function AccelByteCustomization.AccelByteBlueprintsCustomizationSettings.SetSplitgateServerUrl
	void SetSocialServerUrl(struct FString InSocialServerUrl); // Function AccelByteCustomization.AccelByteBlueprintsCustomizationSettings.SetSocialServerUrl
	void SetReportServerUrl(struct FString ReportServerUrl); // Function AccelByteCustomization.AccelByteBlueprintsCustomizationSettings.SetReportServerUrl
	void SetReferralCodeServerUrl(struct FString ServerUrl); // Function AccelByteCustomization.AccelByteBlueprintsCustomizationSettings.SetReferralCodeServerUrl
	void SetProgressionServerUrl(struct FString ProgressionServerUrl); // Function AccelByteCustomization.AccelByteBlueprintsCustomizationSettings.SetProgressionServerUrl
	void SetPlatformShopServerUrl(struct FString PlatformShopServerUrl); // Function AccelByteCustomization.AccelByteBlueprintsCustomizationSettings.SetPlatformShopServerUrl
	void SetMatchmakingServerUrl(struct FString MatchmakingServerUrl); // Function AccelByteCustomization.AccelByteBlueprintsCustomizationSettings.SetMatchmakingServerUrl
	void SetLockerServerUrl(struct FString LockerServerUrl); // Function AccelByteCustomization.AccelByteBlueprintsCustomizationSettings.SetLockerServerUrl
	void SetGamePlaylistServerUrl(struct FString ServerUrl); // Function AccelByteCustomization.AccelByteBlueprintsCustomizationSettings.SetGamePlaylistServerUrl
	void SetDropServerUrl(struct FString DropServerUrl); // Function AccelByteCustomization.AccelByteBlueprintsCustomizationSettings.SetDropServerUrl
	void SetDailyPlayStreakServerUrl(struct FString DailyPlayStreakServerUrl); // Function AccelByteCustomization.AccelByteBlueprintsCustomizationSettings.SetDailyPlayStreakServerUrl
	void SetDailyCheckInServerUrl(struct FString SplitgateServerUrl); // Function AccelByteCustomization.AccelByteBlueprintsCustomizationSettings.SetDailyCheckInServerUrl
	void SetChallengeServerUrl(struct FString ChallengeServerUrl); // Function AccelByteCustomization.AccelByteBlueprintsCustomizationSettings.SetChallengeServerUrl
	void SetBasicServerUrl(struct FString BasicServerUrl); // Function AccelByteCustomization.AccelByteBlueprintsCustomizationSettings.SetBasicServerUrl
	void SetBadgeServerUrl(struct FString ServerUrl); // Function AccelByteCustomization.AccelByteBlueprintsCustomizationSettings.SetBadgeServerUrl
	void SetAchievementServerUrl(struct FString AchievementServerUrl); // Function AccelByteCustomization.AccelByteBlueprintsCustomizationSettings.SetAchievementServerUrl
	struct FString GetUGCServerUrl(); // Function AccelByteCustomization.AccelByteBlueprintsCustomizationSettings.GetUGCServerUrl
	struct FString GetSplitgateServerUrl(); // Function AccelByteCustomization.AccelByteBlueprintsCustomizationSettings.GetSplitgateServerUrl
	struct FString GetSocialServerUrl(); // Function AccelByteCustomization.AccelByteBlueprintsCustomizationSettings.GetSocialServerUrl
	struct FString GetReportServerUrl(); // Function AccelByteCustomization.AccelByteBlueprintsCustomizationSettings.GetReportServerUrl
	struct FString GetReferralCodeServerUrl(); // Function AccelByteCustomization.AccelByteBlueprintsCustomizationSettings.GetReferralCodeServerUrl
	struct FString GetProgressionServerUrl(); // Function AccelByteCustomization.AccelByteBlueprintsCustomizationSettings.GetProgressionServerUrl
	struct FString GetPlatformShopServerUrl(); // Function AccelByteCustomization.AccelByteBlueprintsCustomizationSettings.GetPlatformShopServerUrl
	struct FString GetMatchmakingServerUrl(); // Function AccelByteCustomization.AccelByteBlueprintsCustomizationSettings.GetMatchmakingServerUrl
	struct FString GetLockerServerUrl(); // Function AccelByteCustomization.AccelByteBlueprintsCustomizationSettings.GetLockerServerUrl
	struct FString GetGamePlaylistServerUrl(); // Function AccelByteCustomization.AccelByteBlueprintsCustomizationSettings.GetGamePlaylistServerUrl
	struct FString GetDropServerUrl(); // Function AccelByteCustomization.AccelByteBlueprintsCustomizationSettings.GetDropServerUrl
	struct FString GetDailyPlayStreakServerUrl(); // Function AccelByteCustomization.AccelByteBlueprintsCustomizationSettings.GetDailyPlayStreakServerUrl
	struct FString GetDailyCheckInServerUrl(); // Function AccelByteCustomization.AccelByteBlueprintsCustomizationSettings.GetDailyCheckInServerUrl
	struct FString GetChallengeServerUrl(); // Function AccelByteCustomization.AccelByteBlueprintsCustomizationSettings.GetChallengeServerUrl
	struct FString GetBasicServerUrl(); // Function AccelByteCustomization.AccelByteBlueprintsCustomizationSettings.GetBasicServerUrl
	struct FString GetBadgeServerUrl(); // Function AccelByteCustomization.AccelByteBlueprintsCustomizationSettings.GetBadgeServerUrl
	struct FString GetAchievementServerUrl(); // Function AccelByteCustomization.AccelByteBlueprintsCustomizationSettings.GetAchievementServerUrl
}; 



// Class AccelByteCustomization.AccelByteCustomizationServerSettings
// Size: 0x48(Inherited: 0x28) 
struct UAccelByteCustomizationServerSettings : public UObject
{
	struct FString ProgressionServerUrl;  // 0x28(0x10)
	struct FString BasicServerUrl;  // 0x38(0x10)

}; 



// Class AccelByteCustomization.AccelByteCustomizationSettings
// Size: 0x118(Inherited: 0x28) 
struct UAccelByteCustomizationSettings : public UObject
{
	struct FString LockerServerUrl;  // 0x28(0x10)
	struct FString DropServerUrl;  // 0x38(0x10)
	struct FString PlatformShopServerUrl;  // 0x48(0x10)
	struct FString BasicServerUrl;  // 0x58(0x10)
	struct FString ReportServerUrl;  // 0x68(0x10)
	struct FString MatchmakingServerUrl;  // 0x78(0x10)
	struct FString ProgressionServerUrl;  // 0x88(0x10)
	struct FString UserStatsServerUrl;  // 0x98(0x10)
	struct FString DailyCheckInServerUrl;  // 0xA8(0x10)
	struct FString DailyPlayStreakServerUrl;  // 0xB8(0x10)
	struct FString AchievementServerUrl;  // 0xC8(0x10)
	struct FString GamePlaylistServerUrl;  // 0xD8(0x10)
	struct FString ReferralCodeServerUrl;  // 0xE8(0x10)
	struct FString VivoxUrl;  // 0xF8(0x10)
	struct FString UGCServerUrl;  // 0x108(0x10)

}; 



// Class AccelByteCustomization.AccelByteBlueprintsCustomizationServerSettings
// Size: 0x28(Inherited: 0x28) 
struct UAccelByteBlueprintsCustomizationServerSettings : public UBlueprintFunctionLibrary
{

	void SetProgressionServerUrl(struct FString ProgressionServerUrl); // Function AccelByteCustomization.AccelByteBlueprintsCustomizationServerSettings.SetProgressionServerUrl
	void SetBasicServerUrl(struct FString InBasicServerUrl); // Function AccelByteCustomization.AccelByteBlueprintsCustomizationServerSettings.SetBasicServerUrl
	struct FString GetProgressionServerUrl(); // Function AccelByteCustomization.AccelByteBlueprintsCustomizationServerSettings.GetProgressionServerUrl
	struct FString GetBasicServerUrl(); // Function AccelByteCustomization.AccelByteBlueprintsCustomizationServerSettings.GetBasicServerUrl
}; 



// Class AccelByteCustomization.AccelByteCustomizationSettingsDev
// Size: 0x118(Inherited: 0x118) 
struct UAccelByteCustomizationSettingsDev : public UAccelByteCustomizationSettings
{

}; 



// Class AccelByteCustomization.AccelByteCustomizationSettingsCert
// Size: 0x118(Inherited: 0x118) 
struct UAccelByteCustomizationSettingsCert : public UAccelByteCustomizationSettings
{

}; 



// Class AccelByteCustomization.AccelByteCustomizationSettingsProd
// Size: 0x118(Inherited: 0x118) 
struct UAccelByteCustomizationSettingsProd : public UAccelByteCustomizationSettings
{

}; 



