#pragma once 
#include <BattlePassPanel_WidgetBP_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass BattlePassPanel_WidgetBP.BattlePassPanel_WidgetBP_C
// Size: 0x760(Inherited: 0x748) 
struct UBattlePassPanel_WidgetBP_C : public UPortalWarsBattlePassPanelWidget
{
	struct UImage* Line;  // 0x748(0x8)
	struct UImage* Shield;  // 0x750(0x8)
	struct UWBP_ButtonPrompt_C* WBP_ButtonPrompt;  // 0x758(0x8)

}; 



