#pragma once 
#include <Lootbox_WidgetBP_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass Lootbox_WidgetBP.Lootbox_WidgetBP_C
// Size: 0xAE0(Inherited: 0xA58) 
struct ULootbox_WidgetBP_C : public UPortalWarsLootboxWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0xA58(0x8)
	struct UDropIndicator_WidgetBP_C* DropIndicator_WidgetBP;  // 0xA60(0x8)
	struct UBackgroundBlur* DuplicateDimmer;  // 0xA68(0x8)
	struct UImage* DuplicateRarityIcon;  // 0xA70(0x8)
	struct UVerticalBox* DuplicateSplitcoinBox;  // 0xA78(0x8)
	struct URichTextBlock* DuplicateTitle;  // 0xA80(0x8)
	struct UWidgetSwitcher* DuplicateTitleSwitcher;  // 0xA88(0x8)
	struct UVerticalBox* DuplicateXPBox;  // 0xA90(0x8)
	struct URichTextBlock* Equipped-Text;  // 0xA98(0x8)
	struct UImage* Image_109;  // 0xAA0(0x8)
	struct USafeZone* SafeZone_1;  // 0xAA8(0x8)
	struct UImage* SplitcoinImage;  // 0xAB0(0x8)
	struct URichTextBlock* SplitcoinRewardTextBlock;  // 0xAB8(0x8)
	struct UWBP_Footer_C* WBP_Footer;  // 0xAC0(0x8)
	struct UWBP_PageHeader_C* WBP_PageHeader;  // 0xAC8(0x8)
	struct UImage* XpImage;  // 0xAD0(0x8)
	struct URichTextBlock* XpRewardTextBlock;  // 0xAD8(0x8)

	void Construct(); // Function Lootbox_WidgetBP.Lootbox_WidgetBP_C.Construct
	void ExecuteUbergraph_Lootbox_WidgetBP(int32_t EntryPoint); // Function Lootbox_WidgetBP.Lootbox_WidgetBP_C.ExecuteUbergraph_Lootbox_WidgetBP
}; 



