#pragma once 
#include <MainMenuPlayerController_BP_Structs.h>
 
 
 
// BlueprintGeneratedClass MainMenuPlayerController_BP.MainMenuPlayerController_BP_C
// Size: 0x680(Inherited: 0x680) 
struct AMainMenuPlayerController_BP_C : public AMainMenuPlayerController
{

}; 



