#pragma once 
#include "SDK.h" 
 
 
// Function LightRedButtonBase.LightRedButtonBase_C.ExecuteUbergraph_LightRedButtonBase
// Size: 0x9(Inherited: 0x0) 
struct FExecuteUbergraph_LightRedButtonBase
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Temp_bool_Variable : 1;  // 0x4(0x1)
	uint8_t  Temp_byte_Variable;  // 0x5(0x1)
	uint8_t  Temp_byte_Variable_2;  // 0x6(0x1)
	char pad_7_1 : 7;  // 0x7(0x1)
	bool K2Node_Event_IsDesignTime : 1;  // 0x7(0x1)
	uint8_t  K2Node_Select_Default;  // 0x8(0x1)

}; 
// Function LightRedButtonBase.LightRedButtonBase_C.PreConstruct
// Size: 0x1(Inherited: 0x1) 
struct FPreConstruct : public FPreConstruct
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool IsDesignTime : 1;  // 0x0(0x1)

}; 
