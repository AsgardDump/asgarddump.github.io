#pragma once 
#include <LootFinishSequence_Structs.h>
 
 
 
// BlueprintGeneratedClass LootFinishSequence.SequenceDirector_C
// Size: 0x40(Inherited: 0x38) 
struct USequenceDirector_C : public ULevelSequenceDirector
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x38(0x8)

	void SequenceEvent__ENTRYPOINTSequenceDirector_4(struct ABP_RewardRoomPortal_C* BP_RewardRoomPortal_Top); // Function LootFinishSequence.SequenceDirector_C.SequenceEvent__ENTRYPOINTSequenceDirector_4
	void SequenceEvent__ENTRYPOINTSequenceDirector_3(struct ABP_RewardRoomPortal_C* BP_RewardRoomPortal_Top); // Function LootFinishSequence.SequenceDirector_C.SequenceEvent__ENTRYPOINTSequenceDirector_3
	void SequenceEvent__ENTRYPOINTSequenceDirector_2(struct ABP_RewardRoomPortal_C* BP_RewardRoomPortal_Bot); // Function LootFinishSequence.SequenceDirector_C.SequenceEvent__ENTRYPOINTSequenceDirector_2
	void SequenceEvent__ENTRYPOINTSequenceDirector_1(struct ABP_RewardRoomPortal_C* BP_RewardRoomPortal_Bot); // Function LootFinishSequence.SequenceDirector_C.SequenceEvent__ENTRYPOINTSequenceDirector_1
	void BP_RewardRoomPortal_Bot_Event_1(struct ABP_RewardRoomPortal_C* BP_RewardRoomPortal_Bot); // Function LootFinishSequence.SequenceDirector_C.BP_RewardRoomPortal_Bot_Event_1
	void BP_RewardRoomPortal_Top_Event_1(struct ABP_RewardRoomPortal_C* BP_RewardRoomPortal_Top); // Function LootFinishSequence.SequenceDirector_C.BP_RewardRoomPortal_Top_Event_1
	void BP_RewardRoomPortal_Bot_Event_2(struct ABP_RewardRoomPortal_C* BP_RewardRoomPortal_Bot); // Function LootFinishSequence.SequenceDirector_C.BP_RewardRoomPortal_Bot_Event_2
	void BP_RewardRoomPortal_Top_Event_2(struct ABP_RewardRoomPortal_C* BP_RewardRoomPortal_Top); // Function LootFinishSequence.SequenceDirector_C.BP_RewardRoomPortal_Top_Event_2
	void ExecuteUbergraph_SequenceDirector(int32_t EntryPoint); // Function LootFinishSequence.SequenceDirector_C.ExecuteUbergraph_SequenceDirector
}; 



