#pragma once 
#include "SDK.h" 
 
 
// Function FriendRequestEntry_WidgetBP.FriendRequestEntry_WidgetBP_C.ExecuteUbergraph_FriendRequestEntry_WidgetBP
// Size: 0x4(Inherited: 0x0) 
struct FExecuteUbergraph_FriendRequestEntry_WidgetBP
{
	int32_t EntryPoint;  // 0x0(0x4)

}; 
