#pragma once 
#include "SDK.h" 
 
 
// Function GamepadBindingRestoreDialog_WidgetBP.GamepadBindingRestoreDialog_WidgetBP_C.ExecuteUbergraph_GamepadBindingRestoreDialog_WidgetBP
// Size: 0x4(Inherited: 0x0) 
struct FExecuteUbergraph_GamepadBindingRestoreDialog_WidgetBP
{
	int32_t EntryPoint;  // 0x0(0x4)

}; 
