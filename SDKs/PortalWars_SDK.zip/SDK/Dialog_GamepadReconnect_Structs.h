#pragma once 
#include "SDK.h" 
 
 
// Function Dialog_GamepadReconnect.Dialog_GamepadReconnect_C.ExecuteUbergraph_Dialog_GamepadReconnect
// Size: 0x4(Inherited: 0x0) 
struct FExecuteUbergraph_Dialog_GamepadReconnect
{
	int32_t EntryPoint;  // 0x0(0x4)

}; 
