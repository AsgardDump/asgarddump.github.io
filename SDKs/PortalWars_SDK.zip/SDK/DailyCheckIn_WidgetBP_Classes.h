#pragma once 
#include <DailyCheckIn_WidgetBP_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass DailyCheckIn_WidgetBP.DailyCheckIn_WidgetBP_C
// Size: 0x8E8(Inherited: 0x8A8) 
struct UDailyCheckIn_WidgetBP_C : public UPortalWarsDailyCheckInWidget
{
	struct UCheckInReward_WidgetBP_C* Day1Reward;  // 0x8A8(0x8)
	struct UCheckInReward_WidgetBP_C* Day2Reward;  // 0x8B0(0x8)
	struct UCheckInReward_WidgetBP_C* Day3Reward;  // 0x8B8(0x8)
	struct UCheckInReward_WidgetBP_C* Day4Reward;  // 0x8C0(0x8)
	struct UCheckInReward_WidgetBP_C* Day5Reward;  // 0x8C8(0x8)
	struct UCheckInReward_WidgetBP_C* Day6Reward;  // 0x8D0(0x8)
	struct UImage* Image;  // 0x8D8(0x8)
	struct UImage* Image_101;  // 0x8E0(0x8)

}; 



