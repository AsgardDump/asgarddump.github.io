#pragma once 
#include <BattlePassRedeemableButton_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass BattlePassRedeemableButton.BattlePassRedeemableButton_C
// Size: 0x8C0(Inherited: 0x850) 
struct UBattlePassRedeemableButton_C : public UPortalWarsBPRedeemableButton
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x850(0x8)
	struct UWidgetAnimation* PurchaseConfirmedAnim;  // 0x858(0x8)
	struct UTextBlock* ArenaPassText;  // 0x860(0x8)
	struct URichTextBlock* HoldToBuyLabel;  // 0x868(0x8)
	struct UWBP_HoldButton_C* PurchaseButton;  // 0x870(0x8)
	struct URichTextBlock* Purchased;  // 0x878(0x8)
	struct UImage* Purchased_BG;  // 0x880(0x8)
	struct UOverlay* PurchasingBox;  // 0x888(0x8)
	struct UImage* SplitcoinIcon;  // 0x890(0x8)
	struct UWBP_StorePrice_C* StorePrice;  // 0x898(0x8)
	struct UThrobber* Throbber_69;  // 0x8A0(0x8)
	struct FText DescriptionText;  // 0x8A8(0x18)

	struct UWidget* GetDefaultWidgetToFocus(); // Function BattlePassRedeemableButton.BattlePassRedeemableButton_C.GetDefaultWidgetToFocus
	void PreConstruct(bool IsDesignTime); // Function BattlePassRedeemableButton.BattlePassRedeemableButton_C.PreConstruct
	void Construct(); // Function BattlePassRedeemableButton.BattlePassRedeemableButton_C.Construct
	void BndEvt__BattlePassRedeemableButton_PurchaseButton_K2Node_ComponentBoundEvent_0_OnGenericButtonClicked__DelegateSignature(); // Function BattlePassRedeemableButton.BattlePassRedeemableButton_C.BndEvt__BattlePassRedeemableButton_PurchaseButton_K2Node_ComponentBoundEvent_0_OnGenericButtonClicked__DelegateSignature
	void ExecuteUbergraph_BattlePassRedeemableButton(int32_t EntryPoint); // Function BattlePassRedeemableButton.BattlePassRedeemableButton_C.ExecuteUbergraph_BattlePassRedeemableButton
}; 



