#pragma once 
#include "SDK.h" 
 
 
// ScriptStruct MovieRenderPipelineRenderPasses.MoviePipelinePostProcessPass
// Size: 0x30(Inherited: 0x0) 
struct FMoviePipelinePostProcessPass
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bEnabled : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct TSoftObjectPtr<UMaterialInterface> Material;  // 0x8(0x28)

}; 
