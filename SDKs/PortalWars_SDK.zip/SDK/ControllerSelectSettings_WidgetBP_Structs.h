#pragma once 
#include "SDK.h" 
 
 
// Function ControllerSelectSettings_WidgetBP.ControllerSelectSettings_WidgetBP_C.ExecuteUbergraph_ControllerSelectSettings_WidgetBP
// Size: 0x4(Inherited: 0x0) 
struct FExecuteUbergraph_ControllerSelectSettings_WidgetBP
{
	int32_t EntryPoint;  // 0x0(0x4)

}; 
