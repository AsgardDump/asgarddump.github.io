#pragma once 
#include "SDK.h" 
 
 
// DelegateFunction DiscordRpc.DiscordConnected__DelegateSignature
// Size: 0x40(Inherited: 0x0) 
struct FDiscordConnected__DelegateSignature
{
	struct FDiscordUserData joinRequest;  // 0x0(0x40)

}; 
// ScriptStruct DiscordRpc.DiscordUserData
// Size: 0x40(Inherited: 0x0) 
struct FDiscordUserData
{
	struct FString UserId;  // 0x0(0x10)
	struct FString Username;  // 0x10(0x10)
	struct FString discriminator;  // 0x20(0x10)
	struct FString avatar;  // 0x30(0x10)

}; 
// DelegateFunction DiscordRpc.DiscordSpectate__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDiscordSpectate__DelegateSignature
{
	struct FString spectateSecret;  // 0x0(0x10)

}; 
// DelegateFunction DiscordRpc.DiscordDisconnected__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FDiscordDisconnected__DelegateSignature
{
	int32_t ErrorCode;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FString ErrorMessage;  // 0x8(0x10)

}; 
// DelegateFunction DiscordRpc.DiscordErrored__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FDiscordErrored__DelegateSignature
{
	int32_t ErrorCode;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FString ErrorMessage;  // 0x8(0x10)

}; 
// ScriptStruct DiscordRpc.DiscordRichPresence
// Size: 0xB8(Inherited: 0x0) 
struct FDiscordRichPresence
{
	struct FString State;  // 0x0(0x10)
	struct FString Details;  // 0x10(0x10)
	int32_t startTimestamp;  // 0x20(0x4)
	int32_t endTimestamp;  // 0x24(0x4)
	struct FString largeImageKey;  // 0x28(0x10)
	struct FString largeImageText;  // 0x38(0x10)
	struct FString smallImageKey;  // 0x48(0x10)
	struct FString smallImageText;  // 0x58(0x10)
	struct FString PartyId;  // 0x68(0x10)
	int32_t partySize;  // 0x78(0x4)
	int32_t partyMax;  // 0x7C(0x4)
	struct FString matchSecret;  // 0x80(0x10)
	struct FString joinSecret;  // 0x90(0x10)
	struct FString spectateSecret;  // 0xA0(0x10)
	char pad_176_1 : 7;  // 0xB0(0x1)
	bool Instance : 1;  // 0xB0(0x1)
	char pad_177[7];  // 0xB1(0x7)

}; 
// DelegateFunction DiscordRpc.DiscordJoin__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FDiscordJoin__DelegateSignature
{
	struct FString joinSecret;  // 0x0(0x10)

}; 
// DelegateFunction DiscordRpc.DiscordJoinRequest__DelegateSignature
// Size: 0x40(Inherited: 0x0) 
struct FDiscordJoinRequest__DelegateSignature
{
	struct FDiscordUserData joinRequest;  // 0x0(0x40)

}; 
// Function DiscordRpc.DiscordRpc.Initialize
// Size: 0x28(Inherited: 0x0) 
struct FInitialize
{
	struct FString applicationId;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool autoRegister : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct FString optionalSteamId;  // 0x18(0x10)

}; 
// Function DiscordRpc.DiscordRpc.Respond
// Size: 0x18(Inherited: 0x0) 
struct FRespond
{
	struct FString UserId;  // 0x0(0x10)
	int32_t Reply;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)

}; 
