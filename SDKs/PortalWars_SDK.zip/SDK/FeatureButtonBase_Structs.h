#pragma once 
#include "SDK.h" 
 
 
// Function FeatureButtonBase.FeatureButtonBase_C.ExecuteUbergraph_FeatureButtonBase
// Size: 0x44(Inherited: 0x0) 
struct FExecuteUbergraph_FeatureButtonBase
{
	int32_t EntryPoint;  // 0x0(0x4)
	uint8_t  Temp_byte_Variable;  // 0x4(0x1)
	uint8_t  Temp_byte_Variable_2;  // 0x5(0x1)
	char EHorizontalAlignment Temp_byte_Variable_3;  // 0x6(0x1)
	char ETextJustify Temp_byte_Variable_4;  // 0x7(0x1)
	char ETextJustify Temp_byte_Variable_5;  // 0x8(0x1)
	char ETextJustify Temp_byte_Variable_6;  // 0x9(0x1)
	char ETextJustify Temp_byte_Variable_7;  // 0xA(0x1)
	char EHorizontalAlignment Temp_byte_Variable_8;  // 0xB(0x1)
	int32_t Temp_int_Variable;  // 0xC(0x4)
	int32_t Temp_int_Variable_2;  // 0x10(0x4)
	int32_t Temp_int_Variable_3;  // 0x14(0x4)
	int32_t Temp_int_Variable_4;  // 0x18(0x4)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool K2Node_Event_IsDesignTime : 1;  // 0x1C(0x1)
	char pad_29[3];  // 0x1D(0x3)
	struct UScaleBoxSlot* CallFunc_SlotAsScaleBoxSlot_ReturnValue;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool Temp_bool_Variable : 1;  // 0x28(0x1)
	char ETextJustify K2Node_Select_Default;  // 0x29(0x1)
	uint8_t  K2Node_Select_Default_2;  // 0x2A(0x1)
	char pad_43[5];  // 0x2B(0x5)
	struct UScaleBoxSlot* CallFunc_SlotAsScaleBoxSlot_ReturnValue_2;  // 0x30(0x8)
	struct UScaleBoxSlot* CallFunc_SlotAsScaleBoxSlot_ReturnValue_3;  // 0x38(0x8)
	int32_t K2Node_Select_Default_3;  // 0x40(0x4)

}; 
// Function FeatureButtonBase.FeatureButtonBase_C.PreConstruct
// Size: 0x1(Inherited: 0x1) 
struct FPreConstruct : public FPreConstruct
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool IsDesignTime : 1;  // 0x0(0x1)

}; 
