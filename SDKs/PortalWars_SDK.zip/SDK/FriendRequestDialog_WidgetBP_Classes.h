#pragma once 
#include <FriendRequestDialog_WidgetBP_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass FriendRequestDialog_WidgetBP.FriendRequestDialog_WidgetBP_C
// Size: 0x8F0(Inherited: 0x8E0) 
struct UFriendRequestDialog_WidgetBP_C : public UPortalWarsFriendRequestDialog
{
	struct UImage* BG;  // 0x8E0(0x8)
	struct UThrobber* Throbber_1;  // 0x8E8(0x8)

}; 



