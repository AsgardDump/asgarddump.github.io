#pragma once 
#include "SDK.h" 
 
 
// Function ChallengeInspectEntry_WidgetBP.ChallengeInspectEntry_WidgetBP_C.ExecuteUbergraph_ChallengeInspectEntry_WidgetBP
// Size: 0xD(Inherited: 0x0) 
struct FExecuteUbergraph_ChallengeInspectEntry_WidgetBP
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Temp_bool_Variable : 1;  // 0x4(0x1)
	uint8_t  Temp_byte_Variable;  // 0x5(0x1)
	uint8_t  Temp_byte_Variable_2;  // 0x6(0x1)
	char pad_7[1];  // 0x7(0x1)
	int32_t CallFunc_Conv_BoolToInt_ReturnValue;  // 0x8(0x4)
	uint8_t  K2Node_Select_Default;  // 0xC(0x1)

}; 
