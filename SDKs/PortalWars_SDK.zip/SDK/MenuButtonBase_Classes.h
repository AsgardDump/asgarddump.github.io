#pragma once 
#include <MenuButtonBase_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass MenuButtonBase.MenuButtonBase_C
// Size: 0x6F1(Inherited: 0x688) 
struct UMenuButtonBase_C : public UPortalWarsButtonWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x688(0x8)
	struct UImage* ButtonIcon;  // 0x690(0x8)
	struct UImage* GamepadKeyImage;  // 0x698(0x8)
	struct UWBP_GenericButton_C* WBP_GenericButton;  // 0x6A0(0x8)
	struct FLinearColor ButtonColor;  // 0x6A8(0x10)
	struct FLinearColor IconColor;  // 0x6B8(0x10)
	struct FLinearColor HoveredIconColor;  // 0x6C8(0x10)
	struct FLinearColor HoveredButtonColor;  // 0x6D8(0x10)
	struct UTexture2D* Icon;  // 0x6E8(0x8)
	char pad_1776_1 : 7;  // 0x6F0(0x1)
	bool ShowBtnBackgroundx : 1;  // 0x6F0(0x1)

	void PreConstruct(bool IsDesignTime); // Function MenuButtonBase.MenuButtonBase_C.PreConstruct
	void BndEvt__Button_K2Node_ComponentBoundEvent_0_OnButtonHoverEvent__DelegateSignature(); // Function MenuButtonBase.MenuButtonBase_C.BndEvt__Button_K2Node_ComponentBoundEvent_0_OnButtonHoverEvent__DelegateSignature
	void BndEvt__Button_K2Node_ComponentBoundEvent_1_OnButtonHoverEvent__DelegateSignature(); // Function MenuButtonBase.MenuButtonBase_C.BndEvt__Button_K2Node_ComponentBoundEvent_1_OnButtonHoverEvent__DelegateSignature
	void ExecuteUbergraph_MenuButtonBase(int32_t EntryPoint); // Function MenuButtonBase.MenuButtonBase_C.ExecuteUbergraph_MenuButtonBase
}; 



