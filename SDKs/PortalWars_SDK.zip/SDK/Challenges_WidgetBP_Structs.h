#pragma once 
#include "SDK.h" 
 
 
// Function Challenges_WidgetBP.Challenges_WidgetBP_C.PreConstruct
// Size: 0x1(Inherited: 0x1) 
struct FPreConstruct : public FPreConstruct
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool IsDesignTime : 1;  // 0x0(0x1)

}; 
// Function Challenges_WidgetBP.Challenges_WidgetBP_C.ExecuteUbergraph_Challenges_WidgetBP
// Size: 0x41(Inherited: 0x0) 
struct FExecuteUbergraph_Challenges_WidgetBP
{
	int32_t EntryPoint;  // 0x0(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x4(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x8(0x4)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool K2Node_Event_IsDesignTime : 1;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)
	int32_t Temp_int_Array_Index_Variable;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct TArray<struct UWidget*> CallFunc_GetAllChildren_ReturnValue;  // 0x18(0x10)
	struct UWidget* CallFunc_Array_Get_Item;  // 0x28(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x30(0x4)
	char pad_52[4];  // 0x34(0x4)
	struct UWrapBoxSlot* CallFunc_SlotAsWrapBoxSlot_ReturnValue;  // 0x38(0x8)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x40(0x1)

}; 
