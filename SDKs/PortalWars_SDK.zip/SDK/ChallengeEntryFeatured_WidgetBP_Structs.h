#pragma once 
#include "SDK.h" 
 
 
// Function ChallengeEntryFeatured_WidgetBP.ChallengeEntryFeatured_WidgetBP_C.ExecuteUbergraph_ChallengeEntryFeatured_WidgetBP
// Size: 0x4(Inherited: 0x0) 
struct FExecuteUbergraph_ChallengeEntryFeatured_WidgetBP
{
	int32_t EntryPoint;  // 0x0(0x4)

}; 
