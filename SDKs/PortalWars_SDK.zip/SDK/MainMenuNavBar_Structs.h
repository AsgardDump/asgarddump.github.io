#pragma once 
#include "SDK.h" 
 
 
// Function MainMenuNavBar.MainMenuNavBar_C.SetComponentVisbility
// Size: 0xD(Inherited: 0x0) 
struct FSetComponentVisbility
{
	struct UWidget* Target;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Visible : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool Temp_bool_Variable : 1;  // 0x9(0x1)
	uint8_t  Temp_byte_Variable;  // 0xA(0x1)
	uint8_t  Temp_byte_Variable_2;  // 0xB(0x1)
	uint8_t  K2Node_Select_Default;  // 0xC(0x1)

}; 
// Function MainMenuNavBar.MainMenuNavBar_C.ExecuteUbergraph_MainMenuNavBar
// Size: 0x4(Inherited: 0x0) 
struct FExecuteUbergraph_MainMenuNavBar
{
	int32_t EntryPoint;  // 0x0(0x4)

}; 
