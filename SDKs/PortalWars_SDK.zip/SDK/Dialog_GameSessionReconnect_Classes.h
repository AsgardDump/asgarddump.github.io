#pragma once 
#include <Dialog_GameSessionReconnect_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass Dialog_GameSessionReconnect.Dialog_GameSessionReconnect_C
// Size: 0x8E8(Inherited: 0x8A0) 
struct UDialog_GameSessionReconnect_C : public UPortalWarsGameSessionReconnectDialog
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x8A0(0x8)
	struct UDialogBackground_C* DialogBackground;  // 0x8A8(0x8)
	struct UImage* Image;  // 0x8B0(0x8)
	struct UImage* Image_2;  // 0x8B8(0x8)
	struct UImage* Image_53;  // 0x8C0(0x8)
	struct UImage* Image_176;  // 0x8C8(0x8)
	struct UImage* Image_299;  // 0x8D0(0x8)
	struct UImage* Image_405;  // 0x8D8(0x8)
	struct UThrobber* Throbber_1;  // 0x8E0(0x8)

	void Construct(); // Function Dialog_GameSessionReconnect.Dialog_GameSessionReconnect_C.Construct
	void ExecuteUbergraph_Dialog_GameSessionReconnect(int32_t EntryPoint); // Function Dialog_GameSessionReconnect.Dialog_GameSessionReconnect_C.ExecuteUbergraph_Dialog_GameSessionReconnect
}; 



