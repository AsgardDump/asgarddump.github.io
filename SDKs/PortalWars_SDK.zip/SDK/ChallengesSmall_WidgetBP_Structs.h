#pragma once 
#include "SDK.h" 
 
 
// Function ChallengesSmall_WidgetBP.ChallengesSmall_WidgetBP_C.ExecuteUbergraph_ChallengesSmall_WidgetBP
// Size: 0x4(Inherited: 0x0) 
struct FExecuteUbergraph_ChallengesSmall_WidgetBP
{
	int32_t EntryPoint;  // 0x0(0x4)

}; 
