#pragma once 
#include <CancelButton_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass CancelButton.CancelButton_C
// Size: 0x6D8(Inherited: 0x6B8) 
struct UCancelButton_C : public UPortalWarsCancelButtonWidget
{
	struct UCircularThrobber* CircularThrobber_170;  // 0x6B8(0x8)
	struct UImage* GamepadKeyImage;  // 0x6C0(0x8)
	struct UHorizontalBox* StatusBox;  // 0x6C8(0x8)
	struct UWBP_GenericButton_C* WBP_GenericButton;  // 0x6D0(0x8)

}; 



