#pragma once 
#include <MainMenuHUD_BP_Structs.h>
 
 
 
// BlueprintGeneratedClass MainMenuHUD_BP.MainMenuHUD_BP_C
// Size: 0x5E0(Inherited: 0x5D0) 
struct AMainMenuHUD_BP_C : public APortalWarsMainMenuHUD
{
	struct UBP_DialogLibraryFrontEnd_C* BP_DialogLibraryFrontEnd;  // 0x5D0(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x5D8(0x8)

}; 



