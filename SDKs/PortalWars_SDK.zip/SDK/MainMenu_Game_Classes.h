#pragma once 
#include <MainMenu_Game_Structs.h>
 
 
 
// BlueprintGeneratedClass MainMenu_Game.MainMenu_Game_C
// Size: 0x228(Inherited: 0x228) 
struct AMainMenu_Game_C : public ALevelScriptActor
{

}; 



