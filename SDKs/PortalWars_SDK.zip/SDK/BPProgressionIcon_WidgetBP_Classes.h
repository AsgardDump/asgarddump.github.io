#pragma once 
#include <BPProgressionIcon_WidgetBP_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass BPProgressionIcon_WidgetBP.BPProgressionIcon_WidgetBP_C
// Size: 0x56C(Inherited: 0x558) 
struct UBPProgressionIcon_WidgetBP_C : public UPortalWarsProgressionIconWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x558(0x8)
	struct USizeBox* SizeBox_2;  // 0x560(0x8)
	float HeightOverride;  // 0x568(0x4)

	void PreConstruct(bool IsDesignTime); // Function BPProgressionIcon_WidgetBP.BPProgressionIcon_WidgetBP_C.PreConstruct
	void Construct(); // Function BPProgressionIcon_WidgetBP.BPProgressionIcon_WidgetBP_C.Construct
	void ExecuteUbergraph_BPProgressionIcon_WidgetBP(int32_t EntryPoint); // Function BPProgressionIcon_WidgetBP.BPProgressionIcon_WidgetBP_C.ExecuteUbergraph_BPProgressionIcon_WidgetBP
}; 



