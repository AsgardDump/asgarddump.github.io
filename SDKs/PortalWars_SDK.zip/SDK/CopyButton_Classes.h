#pragma once 
#include <CopyButton_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass CopyButton.CopyButton_C
// Size: 0x6A0(Inherited: 0x698) 
struct UCopyButton_C : public UPortalWarsCopyButtonWidget
{
	struct UImage* GamepadKeyImage;  // 0x698(0x8)

}; 



