#pragma once 
#include <ImgMediaEngine_Structs.h>
 
 
 
// Class ImgMediaEngine.ImgMediaPlaybackComponent
// Size: 0xD8(Inherited: 0xB0) 
struct UImgMediaPlaybackComponent : public UActorComponent
{
	float Width;  // 0xB0(0x4)
	float LODBias;  // 0xB4(0x4)
	char pad_184[32];  // 0xB8(0x20)

}; 



