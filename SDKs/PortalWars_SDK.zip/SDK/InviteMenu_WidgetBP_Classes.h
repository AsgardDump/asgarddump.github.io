#pragma once 
#include <InviteMenu_WidgetBP_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass InviteMenu_WidgetBP.InviteMenu_WidgetBP_C
// Size: 0x840(Inherited: 0x818) 
struct UInviteMenu_WidgetBP_C : public UPortalWarsInviteMenuWidget
{
	struct UImage* Image;  // 0x818(0x8)
	struct UImage* Image_2;  // 0x820(0x8)
	struct UMenuBackground_C* MenuBackground;  // 0x828(0x8)
	struct USafeZone* SafeZone_1;  // 0x830(0x8)
	struct UWBP_Footer_C* WBP_Footer;  // 0x838(0x8)

}; 



