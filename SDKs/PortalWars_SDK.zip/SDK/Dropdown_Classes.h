#pragma once 
#include <Dropdown_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass Dropdown.Dropdown_C
// Size: 0x608(Inherited: 0x600) 
struct UDropdown_C : public UPortalWarsDropdownWidget
{
	struct UImage* Image_101;  // 0x600(0x8)

}; 



