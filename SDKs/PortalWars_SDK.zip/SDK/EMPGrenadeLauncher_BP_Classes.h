#pragma once 
#include <EMPGrenadeLauncher_BP_Structs.h>
 
 
 
// BlueprintGeneratedClass EMPGrenadeLauncher_BP.EMPGrenadeLauncher_BP_C
// Size: 0x778(Inherited: 0x778) 
struct AEMPGrenadeLauncher_BP_C : public AGrenadeLauncher
{

}; 



