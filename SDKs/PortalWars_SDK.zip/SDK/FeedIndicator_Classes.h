#pragma once 
#include <FeedIndicator_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass FeedIndicator.FeedIndicator_C
// Size: 0x268(Inherited: 0x260) 
struct UFeedIndicator_C : public UUserWidget
{
	struct UImage* Image_66;  // 0x260(0x8)

}; 



