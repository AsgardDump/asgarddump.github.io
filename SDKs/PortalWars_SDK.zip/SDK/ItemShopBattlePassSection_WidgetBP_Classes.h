#pragma once 
#include <ItemShopBattlePassSection_WidgetBP_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass ItemShopBattlePassSection_WidgetBP.ItemShopBattlePassSection_WidgetBP_C
// Size: 0x610(Inherited: 0x608) 
struct UItemShopBattlePassSection_WidgetBP_C : public UPortalWarsItemShopSectionWidget
{
	struct UItemShopBattlePassEntry_WidgetBP_C* ItemShopBattlePassEntry_WidgetBP;  // 0x608(0x8)

	struct UWidget* GetDefaultWidgetToFocus(); // Function ItemShopBattlePassSection_WidgetBP.ItemShopBattlePassSection_WidgetBP_C.GetDefaultWidgetToFocus
}; 



