#pragma once 
#include "SDK.h" 
 
 
// Function BattlePass_WidgetBP.BattlePass_WidgetBP_C.ExecuteUbergraph_BattlePass_WidgetBP
// Size: 0x4(Inherited: 0x0) 
struct FExecuteUbergraph_BattlePass_WidgetBP
{
	int32_t EntryPoint;  // 0x0(0x4)

}; 
