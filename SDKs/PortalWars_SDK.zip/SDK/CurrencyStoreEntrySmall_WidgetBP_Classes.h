#pragma once 
#include <CurrencyStoreEntrySmall_WidgetBP_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass CurrencyStoreEntrySmall_WidgetBP.CurrencyStoreEntrySmall_WidgetBP_C
// Size: 0x830(Inherited: 0x818) 
struct UCurrencyStoreEntrySmall_WidgetBP_C : public UPortalWarsCurrencyStoreEntry
{
	struct UImage* GamepadKeyImage;  // 0x818(0x8)
	struct UWBP_StorePriceList_C* PriceList;  // 0x820(0x8)
	struct UImage* SplitcoinIcon;  // 0x828(0x8)

}; 



