#pragma once 
#include "SDK.h" 
 
 
// Function ItemShopBattlePassSection_WidgetBP.ItemShopBattlePassSection_WidgetBP_C.GetDefaultWidgetToFocus
// Size: 0x8(Inherited: 0x8) 
struct FGetDefaultWidgetToFocus : public FGetDefaultWidgetToFocus
{
	struct UWidget* ReturnValue;  // 0x0(0x8)

}; 
