#pragma once 
#include <ChallengeEntryWeaponFeatured_WidgetBP_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass ChallengeEntryWeaponFeatured_WidgetBP.ChallengeEntryWeaponFeatured_WidgetBP_C
// Size: 0xD38(Inherited: 0xD28) 
struct UChallengeEntryWeaponFeatured_WidgetBP_C : public UPortalWarsChallengeEntryWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0xD28(0x8)
	struct UImage* RewardImage_2;  // 0xD30(0x8)

	void Construct(); // Function ChallengeEntryWeaponFeatured_WidgetBP.ChallengeEntryWeaponFeatured_WidgetBP_C.Construct
	void ExecuteUbergraph_ChallengeEntryWeaponFeatured_WidgetBP(int32_t EntryPoint); // Function ChallengeEntryWeaponFeatured_WidgetBP.ChallengeEntryWeaponFeatured_WidgetBP_C.ExecuteUbergraph_ChallengeEntryWeaponFeatured_WidgetBP
}; 



