#pragma once 
#include "SDK.h" 
 
 
// Function LimitedTimeOfferDialog_WidgetBP.LimitedTimeOfferDialog_WidgetBP_C.ExecuteUbergraph_LimitedTimeOfferDialog_WidgetBP
// Size: 0x4(Inherited: 0x0) 
struct FExecuteUbergraph_LimitedTimeOfferDialog_WidgetBP
{
	int32_t EntryPoint;  // 0x0(0x4)

}; 
