#pragma once 
#include "SDK.h" 
 
 
// Function ChallengeInspect_WidgetBP.ChallengeInspect_WidgetBP_C.ExecuteUbergraph_ChallengeInspect_WidgetBP
// Size: 0x4(Inherited: 0x0) 
struct FExecuteUbergraph_ChallengeInspect_WidgetBP
{
	int32_t EntryPoint;  // 0x0(0x4)

}; 
