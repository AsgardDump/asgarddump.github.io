#pragma once 
#include <MDFastBinding_Structs.h>
 
 
 
// Class MDFastBinding.MDFastBindingValue_StaticFunction
// Size: 0x138(Inherited: 0x130) 
struct UMDFastBindingValue_StaticFunction : public UMDFastBindingValue_Function
{
	UObject* FunctionOwnerClass;  // 0x130(0x8)

}; 



// Class MDFastBinding.MDFastBindingContainer
// Size: 0x38(Inherited: 0x28) 
struct UMDFastBindingContainer : public UObject
{
	struct TArray<struct UMDFastBindingInstance*> Bindings;  // 0x28(0x10)

}; 



// Class MDFastBinding.MDFastBindingUserWidget
// Size: 0x268(Inherited: 0x260) 
struct UMDFastBindingUserWidget : public UUserWidget
{
	struct UMDFastBindingContainer* Bindings;  // 0x260(0x8)

}; 



// Class MDFastBinding.MDFastBindingDestination_Function
// Size: 0x128(Inherited: 0x58) 
struct UMDFastBindingDestination_Function : public UMDFastBindingDestinationBase
{
	struct FMDFastBindingFunctionWrapper Function;  // 0x58(0xC0)
	struct UObject* ObjectProperty;  // 0x118(0x8)
	char pad_288_1 : 7;  // 0x120(0x1)
	bool bNeedsUpdate : 1;  // 0x120(0x1)
	char pad_289[7];  // 0x121(0x7)

}; 



// Class MDFastBinding.MDFastBindingObject
// Size: 0x50(Inherited: 0x28) 
struct UMDFastBindingObject : public UObject
{
	struct TArray<struct FMDFastBindingItem> BindingItems;  // 0x28(0x10)
	int32_t ExtendablePinListCount;  // 0x38(0x4)
	uint8_t  UpdateType;  // 0x3C(0x4)
	char pad_64[16];  // 0x40(0x10)

}; 



// Class MDFastBinding.MDFastBindingInstance
// Size: 0x30(Inherited: 0x28) 
struct UMDFastBindingInstance : public UObject
{
	struct UMDFastBindingDestinationBase* BindingDestination;  // 0x28(0x8)

}; 



// Class MDFastBinding.MDFastBindingDestinationBase
// Size: 0x58(Inherited: 0x50) 
struct UMDFastBindingDestinationBase : public UMDFastBindingObject
{
	char pad_80_1 : 7;  // 0x50(0x1)
	bool bHasEverUpdated : 1;  // 0x50(0x1)
	char pad_81[7];  // 0x51(0x7)

}; 



// Class MDFastBinding.MDFastBindingDestination_Property
// Size: 0x118(Inherited: 0x58) 
struct UMDFastBindingDestination_Property : public UMDFastBindingDestinationBase
{
	struct FMDFastBindingFieldPath PropertyPath;  // 0x58(0xB0)
	struct UObject* ObjectProperty;  // 0x108(0x8)
	char pad_272_1 : 7;  // 0x110(0x1)
	bool bNeedsUpdate : 1;  // 0x110(0x1)
	char pad_273[7];  // 0x111(0x7)

}; 



// Class MDFastBinding.MDFastBindingValueBase
// Size: 0x60(Inherited: 0x50) 
struct UMDFastBindingValueBase : public UMDFastBindingObject
{
	char pad_80[16];  // 0x50(0x10)

}; 



// Class MDFastBinding.MDFastBindingValue_CastObject
// Size: 0x78(Inherited: 0x60) 
struct UMDFastBindingValue_CastObject : public UMDFastBindingValueBase
{
	UObject* ObjectClass;  // 0x60(0x8)
	struct UObject* ResultObject;  // 0x68(0x8)
	char pad_112[8];  // 0x70(0x8)

}; 



// Class MDFastBinding.MDFastBindingValue_ContainerLength
// Size: 0x70(Inherited: 0x60) 
struct UMDFastBindingValue_ContainerLength : public UMDFastBindingValueBase
{
	int32_t OutputValue;  // 0x60(0x4)
	char pad_100[12];  // 0x64(0xC)

}; 



// Class MDFastBinding.MDFastBindingValue_FormatText
// Size: 0x108(Inherited: 0x60) 
struct UMDFastBindingValue_FormatText : public UMDFastBindingValueBase
{
	struct FText FormatText;  // 0x60(0x18)
	char pad_120[16];  // 0x78(0x10)
	struct FText OutputValue;  // 0x88(0x18)
	struct TArray<struct FName> Arguments;  // 0xA0(0x10)
	char pad_176[88];  // 0xB0(0x58)

}; 



// Class MDFastBinding.MDFastBindingValue_Function
// Size: 0x130(Inherited: 0x60) 
struct UMDFastBindingValue_Function : public UMDFastBindingValueBase
{
	struct FMDFastBindingFunctionWrapper Function;  // 0x60(0xC0)
	struct UObject* ObjectProperty;  // 0x120(0x8)
	char pad_296_1 : 7;  // 0x128(0x1)
	bool bAddPathRootBindingItem : 1;  // 0x128(0x1)
	char pad_297_1 : 7;  // 0x129(0x1)
	bool bNeedsUpdate : 1;  // 0x129(0x1)
	char pad_298[6];  // 0x12A(0x6)

}; 



// Class MDFastBinding.MDFastBindingValue_Property
// Size: 0x118(Inherited: 0x60) 
struct UMDFastBindingValue_Property : public UMDFastBindingValueBase
{
	struct FMDFastBindingFieldPath PropertyPath;  // 0x60(0xB0)
	struct UObject* ObjectProperty;  // 0x110(0x8)

}; 



// Class MDFastBinding.MDFastBindingValue_Select
// Size: 0xD8(Inherited: 0x60) 
struct UMDFastBindingValue_Select : public UMDFastBindingValueBase
{
	char pad_96[120];  // 0x60(0x78)

}; 



