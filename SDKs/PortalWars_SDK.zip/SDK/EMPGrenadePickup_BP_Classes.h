#pragma once 
#include <EMPGrenadePickup_BP_Structs.h>
 
 
 
// BlueprintGeneratedClass EMPGrenadePickup_BP.EMPGrenadePickup_BP_C
// Size: 0x270(Inherited: 0x270) 
struct AEMPGrenadePickup_BP_C : public APortalWarsGrenadePickup
{

}; 



