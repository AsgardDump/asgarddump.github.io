#pragma once 
#include <Dialog_Message_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass Dialog_Message.Dialog_Message_C
// Size: 0x8B8(Inherited: 0x878) 
struct UDialog_Message_C : public UPortalWarsMessageDialogWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x878(0x8)
	struct UDialogBackground_C* DialogBackground;  // 0x880(0x8)
	struct UImage* Image;  // 0x888(0x8)
	struct UImage* Image_2;  // 0x890(0x8)
	struct UImage* Image_53;  // 0x898(0x8)
	struct UImage* Image_176;  // 0x8A0(0x8)
	struct UImage* Image_299;  // 0x8A8(0x8)
	struct UImage* Image_405;  // 0x8B0(0x8)

	void Construct(); // Function Dialog_Message.Dialog_Message_C.Construct
	void ExecuteUbergraph_Dialog_Message(int32_t EntryPoint); // Function Dialog_Message.Dialog_Message_C.ExecuteUbergraph_Dialog_Message
}; 



