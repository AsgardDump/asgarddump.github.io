#pragma once 
#include <CurrencyPurchaseDialog_WidgetBP_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass CurrencyPurchaseDialog_WidgetBP.CurrencyPurchaseDialog_WidgetBP_C
// Size: 0x9F0(Inherited: 0x9A8) 
struct UCurrencyPurchaseDialog_WidgetBP_C : public UPortalWarsCurrencyPurchaseDialog
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x9A8(0x8)
	struct UImage* Image;  // 0x9B0(0x8)
	struct UImage* Image_1;  // 0x9B8(0x8)
	struct UImage* Line;  // 0x9C0(0x8)
	struct UMenuBackground_C* MenuBackground;  // 0x9C8(0x8)
	struct UWBP_PageHeader_C* PageHeader;  // 0x9D0(0x8)
	struct USafeZone* SafeZone_1;  // 0x9D8(0x8)
	struct UThrobber* Throbber;  // 0x9E0(0x8)
	struct UWBP_Footer_C* WBP_Footer;  // 0x9E8(0x8)

	void Construct(); // Function CurrencyPurchaseDialog_WidgetBP.CurrencyPurchaseDialog_WidgetBP_C.Construct
	void ExecuteUbergraph_CurrencyPurchaseDialog_WidgetBP(int32_t EntryPoint); // Function CurrencyPurchaseDialog_WidgetBP.CurrencyPurchaseDialog_WidgetBP_C.ExecuteUbergraph_CurrencyPurchaseDialog_WidgetBP
}; 



