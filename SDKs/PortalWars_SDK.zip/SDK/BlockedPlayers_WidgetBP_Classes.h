#pragma once 
#include <BlockedPlayers_WidgetBP_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass BlockedPlayers_WidgetBP.BlockedPlayers_WidgetBP_C
// Size: 0x8B8(Inherited: 0x888) 
struct UBlockedPlayers_WidgetBP_C : public UPortalWarsBlockedPlayersWidget
{
	struct UImage* Image_84;  // 0x888(0x8)
	struct UImage* Image_97;  // 0x890(0x8)
	struct UMenuBackground_C* MenuBackground;  // 0x898(0x8)
	struct USafeZone* SafeZone_1;  // 0x8A0(0x8)
	struct UThrobber* Throbber_2;  // 0x8A8(0x8)
	struct UWBP_Footer_C* WBP_Footer;  // 0x8B0(0x8)

}; 



