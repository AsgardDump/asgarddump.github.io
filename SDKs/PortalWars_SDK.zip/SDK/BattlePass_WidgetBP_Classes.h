#pragma once 
#include <BattlePass_WidgetBP_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass BattlePass_WidgetBP.BattlePass_WidgetBP_C
// Size: 0xA70(Inherited: 0xA28) 
struct UBattlePass_WidgetBP_C : public UPortalWarsBattlePassWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0xA28(0x8)
	struct UTextBlock* EndlessBPTextBlock;  // 0xA30(0x8)
	struct URichTextBlock* Equipped-Text;  // 0xA38(0x8)
	struct UImage* Image_109;  // 0xA40(0x8)
	struct UImage* Image_120;  // 0xA48(0x8)
	struct UMenuBackground_C* MenuBackground;  // 0xA50(0x8)
	struct USafeZone* SafeZone_1;  // 0xA58(0x8)
	struct UWBP_Footer_C* WBP_Footer;  // 0xA60(0x8)
	struct UWBP_PageHeader_C* WBP_PageHeader;  // 0xA68(0x8)

	void Construct(); // Function BattlePass_WidgetBP.BattlePass_WidgetBP_C.Construct
	void ExecuteUbergraph_BattlePass_WidgetBP(int32_t EntryPoint); // Function BattlePass_WidgetBP.BattlePass_WidgetBP_C.ExecuteUbergraph_BattlePass_WidgetBP
}; 



