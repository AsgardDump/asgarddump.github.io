#pragma once 
#include <MainMenu_Structs.h>
 
 
 
// BlueprintGeneratedClass MainMenu.MainMenu_C
// Size: 0x228(Inherited: 0x228) 
struct AMainMenu_C : public ALevelScriptActor
{

}; 



