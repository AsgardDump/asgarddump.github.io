#pragma once 
#include "SDK.h" 
 
 
// Function FullLootSequence.SequenceDirector_C.SequenceEvent__ENTRYPOINTSequenceDirector_2
// Size: 0x8(Inherited: 0x0) 
struct FSequenceEvent__ENTRYPOINTSequenceDirector_2
{
	struct APortalWarsMainMenuCharacter_BP_C* PortalWarsMainMenuCharacter_BP;  // 0x0(0x8)

}; 
// Function FullLootSequence.SequenceDirector_C.ExecuteUbergraph_SequenceDirector
// Size: 0x1C(Inherited: 0x0) 
struct FExecuteUbergraph_SequenceDirector
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct APortalWarsMainMenuCharacter_BP_C* K2Node_CustomEvent_PortalWarsMainMenuCharacter_BP;  // 0x8(0x8)
	struct UAnimInstance* CallFunc_GetAnimInstance_ReturnValue;  // 0x10(0x8)
	float CallFunc_Montage_Play_ReturnValue;  // 0x18(0x4)

}; 
// Function FullLootSequence.SequenceDirector_C.PortalWarsMainMenuCharacter_BP_Event_1
// Size: 0x8(Inherited: 0x0) 
struct FPortalWarsMainMenuCharacter_BP_Event_1
{
	struct APortalWarsMainMenuCharacter_BP_C* PortalWarsMainMenuCharacter_BP;  // 0x0(0x8)

}; 
// Function FullLootSequence.SequenceDirector_C.SequenceEvent__ENTRYPOINTSequenceDirector_1
// Size: 0x8(Inherited: 0x0) 
struct FSequenceEvent__ENTRYPOINTSequenceDirector_1
{
	struct APortalWarsMainMenuCharacter_BP_C* PortalWarsMainMenuCharacter_BP;  // 0x0(0x8)

}; 
