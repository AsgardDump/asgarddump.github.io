#pragma once 
#include <ChallengePanelEntry_WidgetBP_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass ChallengePanelEntry_WidgetBP.ChallengePanelEntry_WidgetBP_C
// Size: 0xDA9(Inherited: 0xD28) 
struct UChallengePanelEntry_WidgetBP_C : public UPortalWarsChallengeEntryWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0xD28(0x8)
	struct UImage* ChallengeBG;  // 0xD30(0x8)
	struct UImage* ChallengeCompletedBG;  // 0xD38(0x8)
	struct UImage* ChallengePremiumBG;  // 0xD40(0x8)
	struct UImage* Image;  // 0xD48(0x8)
	struct UImage* Image_93;  // 0xD50(0x8)
	struct UImage* Image_94;  // 0xD58(0x8)
	struct UImage* Image_116;  // 0xD60(0x8)
	struct UImage* Line;  // 0xD68(0x8)
	struct UImage* Line_2;  // 0xD70(0x8)
	struct UReward_WidgetBP_C* Reward_WidgetBP;  // 0xD78(0x8)
	struct FSlateColor In Color and Opacity;  // 0xD80(0x28)
	char pad_3496_1 : 7;  // 0xDA8(0x1)
	bool ShowTopLine : 1;  // 0xDA8(0x1)

	void SetComponentVisibility(struct UWidget* Target, bool Visibility); // Function ChallengePanelEntry_WidgetBP.ChallengePanelEntry_WidgetBP_C.SetComponentVisibility
	void PreConstruct(bool IsDesignTime); // Function ChallengePanelEntry_WidgetBP.ChallengePanelEntry_WidgetBP_C.PreConstruct
	void Construct(); // Function ChallengePanelEntry_WidgetBP.ChallengePanelEntry_WidgetBP_C.Construct
	void ExecuteUbergraph_ChallengePanelEntry_WidgetBP(int32_t EntryPoint); // Function ChallengePanelEntry_WidgetBP.ChallengePanelEntry_WidgetBP_C.ExecuteUbergraph_ChallengePanelEntry_WidgetBP
}; 



