#pragma once 
#include <CheckInReward_WidgetBP_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass CheckInReward_WidgetBP.CheckInReward_WidgetBP_C
// Size: 0xB88(Inherited: 0xB50) 
struct UCheckInReward_WidgetBP_C : public UPortalWarsCheckInRewardWidget
{
	struct UImage* Image_268;  // 0xB50(0x8)
	struct UImage* Image_459;  // 0xB58(0x8)
	struct UImage* RewardBG;  // 0xB60(0x8)
	struct UImage* RewardCompletedBG;  // 0xB68(0x8)
	struct UImage* RewardImage_2;  // 0xB70(0x8)
	struct UImage* RewardMissedBG;  // 0xB78(0x8)
	struct UImage* Shadow;  // 0xB80(0x8)

}; 



