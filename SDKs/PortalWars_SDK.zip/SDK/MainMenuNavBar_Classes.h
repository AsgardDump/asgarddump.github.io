#pragma once 
#include <MainMenuNavBar_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass MainMenuNavBar.MainMenuNavBar_C
// Size: 0x681(Inherited: 0x660) 
struct UMainMenuNavBar_C : public UPortalWarsNavBarWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x660(0x8)
	struct UImage* BG;  // 0x668(0x8)
	struct UPlayerCard_WidgetBP_C* PlayerCard;  // 0x670(0x8)
	struct UPlayerWallet_WidgetBP_C* PlayerWallet;  // 0x678(0x8)
	char pad_1664_1 : 7;  // 0x680(0x1)
	bool ShowNavBarBg : 1;  // 0x680(0x1)

	void SetComponentVisbility(struct UWidget* Target, bool Visible); // Function MainMenuNavBar.MainMenuNavBar_C.SetComponentVisbility
	void Construct(); // Function MainMenuNavBar.MainMenuNavBar_C.Construct
	void ExecuteUbergraph_MainMenuNavBar(int32_t EntryPoint); // Function MainMenuNavBar.MainMenuNavBar_C.ExecuteUbergraph_MainMenuNavBar
}; 



