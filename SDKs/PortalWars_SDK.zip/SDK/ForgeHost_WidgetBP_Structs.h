#pragma once 
#include "SDK.h" 
 
 
// Function ForgeHost_WidgetBP.ForgeHost_WidgetBP_C.ExecuteUbergraph_ForgeHost_WidgetBP
// Size: 0x4(Inherited: 0x0) 
struct FExecuteUbergraph_ForgeHost_WidgetBP
{
	int32_t EntryPoint;  // 0x0(0x4)

}; 
