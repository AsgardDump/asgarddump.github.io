#pragma once 
#include <ChallengesSmall_WidgetBP_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass ChallengesSmall_WidgetBP.ChallengesSmall_WidgetBP_C
// Size: 0x9A0(Inherited: 0x910) 
struct UChallengesSmall_WidgetBP_C : public UPortalWarsChallengesSubWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x910(0x8)
	struct UChallengeEntryFeaturedLarge_WidgetBP_C* ChallengeEntryFeaturedLarge_WidgetBP;  // 0x918(0x8)
	struct UChallengeEntrySmall_WidgetBP_C* ChallengeEntrySmall_WidgetBP;  // 0x920(0x8)
	struct UChallengeEntrySmall_WidgetBP_C* ChallengeEntrySmall_WidgetBP_2;  // 0x928(0x8)
	struct UChallengeEntrySmall_WidgetBP_C* ChallengeEntrySmall_WidgetBP_3;  // 0x930(0x8)
	struct UChallengeEntrySmall_WidgetBP_C* ChallengeEntrySmall_WidgetBP_4;  // 0x938(0x8)
	struct UChallengeEntrySmall_WidgetBP_C* ChallengeEntrySmall_WidgetBP_5;  // 0x940(0x8)
	struct UChallengeEntrySmall_WidgetBP_C* ChallengeEntrySmall_WidgetBP_6;  // 0x948(0x8)
	struct UChallengeEntrySmall_WidgetBP_C* ChallengeEntrySmall_WidgetBP_7;  // 0x950(0x8)
	struct UChallengeEntrySmall_WidgetBP_C* ChallengeEntrySmall_WidgetBP_8;  // 0x958(0x8)
	struct UChallengeEntrySmall_WidgetBP_C* ChallengeEntrySmall_WidgetBP_9;  // 0x960(0x8)
	struct UChallengeEntrySmall_WidgetBP_C* ChallengeEntrySmall_WidgetBP_10;  // 0x968(0x8)
	struct UHeaderBase_C* HeaderBase;  // 0x970(0x8)
	struct UHeaderBase_C* HeaderBase_2;  // 0x978(0x8)
	struct UMenuBackground_C* MenuBackground;  // 0x980(0x8)
	struct USafeZone* SafeZone_1;  // 0x988(0x8)
	struct UWBP_Footer_C* WBP_Footer;  // 0x990(0x8)
	struct UWBP_PageHeader_C* WBP_PageHeader;  // 0x998(0x8)

	void Construct(); // Function ChallengesSmall_WidgetBP.ChallengesSmall_WidgetBP_C.Construct
	void ExecuteUbergraph_ChallengesSmall_WidgetBP(int32_t EntryPoint); // Function ChallengesSmall_WidgetBP.ChallengesSmall_WidgetBP_C.ExecuteUbergraph_ChallengesSmall_WidgetBP
}; 



