#pragma once 
#include <InviteManager_BP_Structs.h>
 
 
 
// BlueprintGeneratedClass InviteManager_BP.InviteManager_BP_C
// Size: 0x238(Inherited: 0x238) 
struct UInviteManager_BP_C : public UPortalWarsInviteManager
{

}; 



