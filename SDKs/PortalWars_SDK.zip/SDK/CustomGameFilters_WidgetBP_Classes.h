#pragma once 
#include <CustomGameFilters_WidgetBP_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass CustomGameFilters_WidgetBP.CustomGameFilters_WidgetBP_C
// Size: 0x970(Inherited: 0x938) 
struct UCustomGameFilters_WidgetBP_C : public UPortalWarsCustomGameFiltersWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x938(0x8)
	struct UImage* Image_124;  // 0x940(0x8)
	struct UImage* LeftPanelBG;  // 0x948(0x8)
	struct UScaleBox* LeftPanelRoot;  // 0x950(0x8)
	struct UMenuBackground_C* MenuBackground;  // 0x958(0x8)
	struct USafeZone* SafeZone_1;  // 0x960(0x8)
	struct UWBP_Footer_C* WBP_Footer;  // 0x968(0x8)

	void Construct(); // Function CustomGameFilters_WidgetBP.CustomGameFilters_WidgetBP_C.Construct
	void ExecuteUbergraph_CustomGameFilters_WidgetBP(int32_t EntryPoint); // Function CustomGameFilters_WidgetBP.CustomGameFilters_WidgetBP_C.ExecuteUbergraph_CustomGameFilters_WidgetBP
}; 



