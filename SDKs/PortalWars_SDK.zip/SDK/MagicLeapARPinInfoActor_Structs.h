#pragma once 
#include "SDK.h" 
 
 
// Function MagicLeapARPinInfoActor.MagicLeapARPinInfoActor_C.ExecuteUbergraph_MagicLeapARPinInfoActor
// Size: 0x2D8(Inherited: 0x0) 
struct FExecuteUbergraph_MagicLeapARPinInfoActor
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct APlayerCameraManager* CallFunc_GetPlayerCameraManager_ReturnValue;  // 0x8(0x8)
	struct FVector CallFunc_GetCameraLocation_ReturnValue;  // 0x10(0xC)
	struct FRotator CallFunc_K2_GetComponentRotation_ReturnValue;  // 0x1C(0xC)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue;  // 0x28(0xC)
	struct FRotator CallFunc_FindLookAtRotation_ReturnValue;  // 0x34(0xC)
	struct FVector CallFunc_GetARPinPositionAndOrientation_Position;  // 0x40(0xC)
	struct FRotator CallFunc_GetARPinPositionAndOrientation_Orientation;  // 0x4C(0xC)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool CallFunc_GetARPinPositionAndOrientation_PinFoundInEnvironment : 1;  // 0x58(0x1)
	char pad_89_1 : 7;  // 0x59(0x1)
	bool CallFunc_GetARPinPositionAndOrientation_ReturnValue : 1;  // 0x59(0x1)
	char pad_90[2];  // 0x5A(0x2)
	struct FHitResult CallFunc_K2_SetWorldLocationAndRotation_SweepHitResult;  // 0x5C(0x88)
	struct FHitResult CallFunc_K2_SetWorldLocation_SweepHitResult;  // 0xE4(0x88)
	float K2Node_Event_DeltaSeconds;  // 0x16C(0x4)
	struct FRotator CallFunc_RInterpTo_ReturnValue;  // 0x170(0xC)
	char pad_380[4];  // 0x17C(0x4)
	struct FString CallFunc_ARPinIdToString_ReturnValue;  // 0x180(0x10)
	float CallFunc_BreakRotator_Roll;  // 0x190(0x4)
	float CallFunc_BreakRotator_Pitch;  // 0x194(0x4)
	float CallFunc_BreakRotator_Yaw;  // 0x198(0x4)
	char pad_412[4];  // 0x19C(0x4)
	struct FText CallFunc_Conv_StringToText_ReturnValue;  // 0x1A0(0x18)
	struct FRotator CallFunc_MakeRotator_ReturnValue;  // 0x1B8(0xC)
	struct FHitResult CallFunc_K2_SetWorldRotation_SweepHitResult;  // 0x1C4(0x88)
	struct FMagicLeapARPinState CallFunc_GetARPinState_State;  // 0x24C(0x14)
	uint8_t  CallFunc_GetARPinState_ReturnValue;  // 0x260(0x1)
	char pad_609_1 : 7;  // 0x261(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // 0x261(0x1)
	char pad_610[6];  // 0x262(0x6)
	struct FString CallFunc_GetEnumeratorUserFriendlyName_ReturnValue;  // 0x268(0x10)
	struct FText CallFunc_Conv_FloatToText_ReturnValue;  // 0x278(0x18)
	struct FText CallFunc_Conv_StringToText_ReturnValue_2;  // 0x290(0x18)
	struct FText CallFunc_Conv_FloatToText_ReturnValue_2;  // 0x2A8(0x18)
	struct FText CallFunc_Conv_FloatToText_ReturnValue_3;  // 0x2C0(0x18)

}; 
// Function MagicLeapARPinInfoActor.MagicLeapARPinInfoActor_C.ReceiveTick
// Size: 0x4(Inherited: 0x4) 
struct FReceiveTick : public FReceiveTick
{
	float DeltaSeconds;  // 0x0(0x4)

}; 
// Function MagicLeapARPinInfoActor.MagicLeapARPinInfoActor_C.UserConstructionScript
// Size: 0x18(Inherited: 0x0) 
struct FUserConstructionScript : public FUserConstructionScript
{
	struct UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue;  // 0x0(0x8)
	struct UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue_2;  // 0x8(0x8)
	struct UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue_3;  // 0x10(0x8)

}; 
