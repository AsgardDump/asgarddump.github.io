#pragma once 
#include <AudioSettings_WidgetBP_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass AudioSettings_WidgetBP.AudioSettings_WidgetBP_C
// Size: 0x900(Inherited: 0x8D0) 
struct UAudioSettings_WidgetBP_C : public UPortalWarsAudioSettingsWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x8D0(0x8)
	struct UMenuBackground_C* MenuBackground;  // 0x8D8(0x8)
	struct USafeZone* SafeZone_1;  // 0x8E0(0x8)
	struct USettingsSectionHeader_C* VoiceHeader;  // 0x8E8(0x8)
	struct UWarningText_C* WarningText;  // 0x8F0(0x8)
	struct UWBP_Footer_C* WBP_Footer;  // 0x8F8(0x8)

	void Construct(); // Function AudioSettings_WidgetBP.AudioSettings_WidgetBP_C.Construct
	void ExecuteUbergraph_AudioSettings_WidgetBP(int32_t EntryPoint); // Function AudioSettings_WidgetBP.AudioSettings_WidgetBP_C.ExecuteUbergraph_AudioSettings_WidgetBP
}; 



