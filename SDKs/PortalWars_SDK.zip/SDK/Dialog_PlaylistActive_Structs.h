#pragma once 
#include "SDK.h" 
 
 
// Function Dialog_PlaylistActive.Dialog_PlaylistActive_C.ExecuteUbergraph_Dialog_PlaylistActive
// Size: 0x4(Inherited: 0x0) 
struct FExecuteUbergraph_Dialog_PlaylistActive
{
	int32_t EntryPoint;  // 0x0(0x4)

}; 
