#pragma once 
#include "SDK.h" 
 
 
// Function LootFinishSequence.SequenceDirector_C.ExecuteUbergraph_SequenceDirector
// Size: 0x28(Inherited: 0x0) 
struct FExecuteUbergraph_SequenceDirector
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct ABP_RewardRoomPortal_C* K2Node_CustomEvent_BP_RewardRoomPortal_Top;  // 0x8(0x8)
	struct ABP_RewardRoomPortal_C* K2Node_CustomEvent_BP_RewardRoomPortal_Bot_2;  // 0x10(0x8)
	struct ABP_RewardRoomPortal_C* K2Node_CustomEvent_BP_RewardRoomPortal_Top_2;  // 0x18(0x8)
	struct ABP_RewardRoomPortal_C* K2Node_CustomEvent_BP_RewardRoomPortal_Bot;  // 0x20(0x8)

}; 
// Function LootFinishSequence.SequenceDirector_C.SequenceEvent__ENTRYPOINTSequenceDirector_2
// Size: 0x8(Inherited: 0x0) 
struct FSequenceEvent__ENTRYPOINTSequenceDirector_2
{
	struct ABP_RewardRoomPortal_C* BP_RewardRoomPortal_Bot;  // 0x0(0x8)

}; 
// Function LootFinishSequence.SequenceDirector_C.BP_RewardRoomPortal_Top_Event_2
// Size: 0x8(Inherited: 0x0) 
struct FBP_RewardRoomPortal_Top_Event_2
{
	struct ABP_RewardRoomPortal_C* BP_RewardRoomPortal_Top;  // 0x0(0x8)

}; 
// Function LootFinishSequence.SequenceDirector_C.BP_RewardRoomPortal_Bot_Event_2
// Size: 0x8(Inherited: 0x0) 
struct FBP_RewardRoomPortal_Bot_Event_2
{
	struct ABP_RewardRoomPortal_C* BP_RewardRoomPortal_Bot;  // 0x0(0x8)

}; 
// Function LootFinishSequence.SequenceDirector_C.BP_RewardRoomPortal_Top_Event_1
// Size: 0x8(Inherited: 0x0) 
struct FBP_RewardRoomPortal_Top_Event_1
{
	struct ABP_RewardRoomPortal_C* BP_RewardRoomPortal_Top;  // 0x0(0x8)

}; 
// Function LootFinishSequence.SequenceDirector_C.BP_RewardRoomPortal_Bot_Event_1
// Size: 0x8(Inherited: 0x0) 
struct FBP_RewardRoomPortal_Bot_Event_1
{
	struct ABP_RewardRoomPortal_C* BP_RewardRoomPortal_Bot;  // 0x0(0x8)

}; 
// Function LootFinishSequence.SequenceDirector_C.SequenceEvent__ENTRYPOINTSequenceDirector_3
// Size: 0x8(Inherited: 0x0) 
struct FSequenceEvent__ENTRYPOINTSequenceDirector_3
{
	struct ABP_RewardRoomPortal_C* BP_RewardRoomPortal_Top;  // 0x0(0x8)

}; 
// Function LootFinishSequence.SequenceDirector_C.SequenceEvent__ENTRYPOINTSequenceDirector_1
// Size: 0x8(Inherited: 0x0) 
struct FSequenceEvent__ENTRYPOINTSequenceDirector_1
{
	struct ABP_RewardRoomPortal_C* BP_RewardRoomPortal_Bot;  // 0x0(0x8)

}; 
// Function LootFinishSequence.SequenceDirector_C.SequenceEvent__ENTRYPOINTSequenceDirector_4
// Size: 0x8(Inherited: 0x0) 
struct FSequenceEvent__ENTRYPOINTSequenceDirector_4
{
	struct ABP_RewardRoomPortal_C* BP_RewardRoomPortal_Top;  // 0x0(0x8)

}; 
