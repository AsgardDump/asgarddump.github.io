#pragma once 
#include "SDK.h" 
 
 
// Function Host_WidgetBP.Host_WidgetBP_C.ExecuteUbergraph_Host_WidgetBP
// Size: 0x4(Inherited: 0x0) 
struct FExecuteUbergraph_Host_WidgetBP
{
	int32_t EntryPoint;  // 0x0(0x4)

}; 
