#pragma once 
#include "SDK.h" 
 
 
// Function ChallengePanelEntry_WidgetBP.ChallengePanelEntry_WidgetBP_C.ExecuteUbergraph_ChallengePanelEntry_WidgetBP
// Size: 0x5B(Inherited: 0x0) 
struct FExecuteUbergraph_ChallengePanelEntry_WidgetBP
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FSlateColor K2Node_MakeStruct_SlateColor;  // 0x8(0x28)
	struct FSlateColor K2Node_MakeStruct_SlateColor_2;  // 0x30(0x28)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool K2Node_Event_IsDesignTime : 1;  // 0x58(0x1)
	char pad_89_1 : 7;  // 0x59(0x1)
	bool CallFunc_IsCompleted_ReturnValue : 1;  // 0x59(0x1)
	char pad_90_1 : 7;  // 0x5A(0x1)
	bool CallFunc_IsPremium_ReturnValue : 1;  // 0x5A(0x1)

}; 
// Function ChallengePanelEntry_WidgetBP.ChallengePanelEntry_WidgetBP_C.SetComponentVisibility
// Size: 0xD(Inherited: 0x0) 
struct FSetComponentVisibility
{
	struct UWidget* Target;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Visibility : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool Temp_bool_Variable : 1;  // 0x9(0x1)
	uint8_t  Temp_byte_Variable;  // 0xA(0x1)
	uint8_t  Temp_byte_Variable_2;  // 0xB(0x1)
	uint8_t  K2Node_Select_Default;  // 0xC(0x1)

}; 
// Function ChallengePanelEntry_WidgetBP.ChallengePanelEntry_WidgetBP_C.PreConstruct
// Size: 0x1(Inherited: 0x1) 
struct FPreConstruct : public FPreConstruct
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool IsDesignTime : 1;  // 0x0(0x1)

}; 
