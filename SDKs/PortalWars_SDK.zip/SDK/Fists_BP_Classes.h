#pragma once 
#include <Fists_BP_Structs.h>
 
 
 
// BlueprintGeneratedClass Fists_BP.Fists_BP_C
// Size: 0x720(Inherited: 0x720) 
struct AFists_BP_C : public AFists
{

}; 



