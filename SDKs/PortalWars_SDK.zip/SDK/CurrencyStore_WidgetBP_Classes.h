#pragma once 
#include <CurrencyStore_WidgetBP_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass CurrencyStore_WidgetBP.CurrencyStore_WidgetBP_C
// Size: 0x6D0(Inherited: 0x690) 
struct UCurrencyStore_WidgetBP_C : public UPortalWarsCurrencyStoreWidget
{
	struct UWidgetAnimation* FadeInAnimation;  // 0x690(0x8)
	struct UCircularThrobber* CircularThrobber_102;  // 0x698(0x8)
	struct UCurrencyStoreEntrySmall_WidgetBP_C* Entry100;  // 0x6A0(0x8)
	struct UCurrencyStoreEntrySmall_WidgetBP_C* Entry1000;  // 0x6A8(0x8)
	struct UCurrencyStoreEntryMedium_WidgetBP_C* Entry10000;  // 0x6B0(0x8)
	struct UCurrencyStoreEntryMedium_WidgetBP_C* Entry2500;  // 0x6B8(0x8)
	struct UCurrencyStoreEntrySmall_WidgetBP_C* Entry500;  // 0x6C0(0x8)
	struct UCurrencyStoreEntryMedium_WidgetBP_C* Entry6000;  // 0x6C8(0x8)

}; 



