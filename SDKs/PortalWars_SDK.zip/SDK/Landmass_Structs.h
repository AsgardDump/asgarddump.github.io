#pragma once 
#include "SDK.h" 
 
 
// ScriptStruct Landmass.BrushEffectCurves
// Size: 0x20(Inherited: 0x0) 
struct FBrushEffectCurves
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bUseCurveChannel : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct UCurveFloat* ElevationCurveAsset;  // 0x8(0x8)
	float ChannelEdgeOffset;  // 0x10(0x4)
	float ChannelDepth;  // 0x14(0x4)
	float CurveRampWidth;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)

}; 
// ScriptStruct Landmass.LandmassBrushEffectsList
// Size: 0x60(Inherited: 0x0) 
struct FLandmassBrushEffectsList
{
	struct FBrushEffectBlurring Blurring;  // 0x0(0x8)
	struct FBrushEffectCurlNoise CurlNoise;  // 0x8(0x10)
	struct FBrushEffectDisplacement Displacement;  // 0x18(0x28)
	struct FBrushEffectSmoothBlending SmoothBlending;  // 0x40(0x8)
	struct FBrushEffectTerracing Terracing;  // 0x48(0x14)
	char pad_92[4];  // 0x5C(0x4)

}; 
// ScriptStruct Landmass.LandmassFalloffSettings
// Size: 0x14(Inherited: 0x0) 
struct FLandmassFalloffSettings
{
	uint8_t  FalloffMode;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	float FalloffAngle;  // 0x4(0x4)
	float FalloffWidth;  // 0x8(0x4)
	float EdgeOffset;  // 0xC(0x4)
	float ZOffset;  // 0x10(0x4)

}; 
// ScriptStruct Landmass.BrushEffectTerracing
// Size: 0x14(Inherited: 0x0) 
struct FBrushEffectTerracing
{
	float TerraceAlpha;  // 0x0(0x4)
	float TerraceSpacing;  // 0x4(0x4)
	float TerraceSmoothness;  // 0x8(0x4)
	float MaskLength;  // 0xC(0x4)
	float MaskStartOffset;  // 0x10(0x4)

}; 
// ScriptStruct Landmass.BrushEffectDisplacement
// Size: 0x28(Inherited: 0x0) 
struct FBrushEffectDisplacement
{
	float DisplacementHeight;  // 0x0(0x4)
	float DisplacementTiling;  // 0x4(0x4)
	struct UTexture2D* Texture;  // 0x8(0x8)
	float Midpoint;  // 0x10(0x4)
	struct FLinearColor Channel;  // 0x14(0x10)
	float WeightmapInfluence;  // 0x24(0x4)

}; 
// ScriptStruct Landmass.BrushEffectSmoothBlending
// Size: 0x8(Inherited: 0x0) 
struct FBrushEffectSmoothBlending
{
	float InnerSmoothDistance;  // 0x0(0x4)
	float OuterSmoothDistance;  // 0x4(0x4)

}; 
// ScriptStruct Landmass.BrushEffectCurlNoise
// Size: 0x10(Inherited: 0x0) 
struct FBrushEffectCurlNoise
{
	float Curl1Amount;  // 0x0(0x4)
	float Curl2Amount;  // 0x4(0x4)
	float Curl1Tiling;  // 0x8(0x4)
	float Curl2Tiling;  // 0xC(0x4)

}; 
// ScriptStruct Landmass.BrushEffectBlurring
// Size: 0x8(Inherited: 0x0) 
struct FBrushEffectBlurring
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bBlurShape : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	int32_t Radius;  // 0x4(0x4)

}; 
// ScriptStruct Landmass.LandmassTerrainCarvingSettings
// Size: 0x80(Inherited: 0x0) 
struct FLandmassTerrainCarvingSettings
{
	uint8_t  BlendMode;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool bInvertShape : 1;  // 0x1(0x1)
	char pad_2[2];  // 0x2(0x2)
	struct FLandmassFalloffSettings FalloffSettings;  // 0x4(0x14)
	struct FLandmassBrushEffectsList Effects;  // 0x18(0x60)
	int32_t Priority;  // 0x78(0x4)
	char pad_124[4];  // 0x7C(0x4)

}; 
