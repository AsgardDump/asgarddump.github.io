#pragma once 
#include <NavBarRightButton_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass NavBarRightButton.NavBarRightButton_C
// Size: 0x690(Inherited: 0x688) 
struct UNavBarRightButton_C : public UPortalWarsButtonWidget
{
	struct UImage* GamepadKeyImage;  // 0x688(0x8)

}; 



