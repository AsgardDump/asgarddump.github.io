#pragma once 
#include <ForgeHost_WidgetBP_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass ForgeHost_WidgetBP.ForgeHost_WidgetBP_C
// Size: 0x898(Inherited: 0x870) 
struct UForgeHost_WidgetBP_C : public UPortalWarsForgeHostMenuWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x870(0x8)
	struct UImage* Image_124;  // 0x878(0x8)
	struct UMenuBackground_C* MenuBackground;  // 0x880(0x8)
	struct USafeZone* SafeZone_1;  // 0x888(0x8)
	struct UWBP_Footer_C* WBP_Footer;  // 0x890(0x8)

	void Construct(); // Function ForgeHost_WidgetBP.ForgeHost_WidgetBP_C.Construct
	void ExecuteUbergraph_ForgeHost_WidgetBP(int32_t EntryPoint); // Function ForgeHost_WidgetBP.ForgeHost_WidgetBP_C.ExecuteUbergraph_ForgeHost_WidgetBP
}; 



