#pragma once 
#include <MapSelector_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass MapSelector.MapSelector_C
// Size: 0x640(Inherited: 0x638) 
struct UMapSelector_C : public UPortalWarsGlobalCarouselWidget
{
	struct UImage* Image_101;  // 0x638(0x8)

}; 



