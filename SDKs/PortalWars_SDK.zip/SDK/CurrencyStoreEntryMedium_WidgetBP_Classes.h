#pragma once 
#include <CurrencyStoreEntryMedium_WidgetBP_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass CurrencyStoreEntryMedium_WidgetBP.CurrencyStoreEntryMedium_WidgetBP_C
// Size: 0x830(Inherited: 0x818) 
struct UCurrencyStoreEntryMedium_WidgetBP_C : public UPortalWarsCurrencyStoreEntry
{
	struct UImage* GamepadKeyImage;  // 0x818(0x8)
	struct UWBP_StorePriceList_C* PriceList;  // 0x820(0x8)
	struct UImage* SplitcoinIcon;  // 0x828(0x8)

}; 



