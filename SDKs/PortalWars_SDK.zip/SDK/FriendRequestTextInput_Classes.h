#pragma once 
#include <FriendRequestTextInput_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass FriendRequestTextInput.FriendRequestTextInput_C
// Size: 0x620(Inherited: 0x610) 
struct UFriendRequestTextInput_C : public UPortalWarsTextInputWidget
{
	struct UImage* Image_63;  // 0x610(0x8)
	struct UImage* Image_101;  // 0x618(0x8)

}; 



