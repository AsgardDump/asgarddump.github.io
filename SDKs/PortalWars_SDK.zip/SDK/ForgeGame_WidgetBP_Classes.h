#pragma once 
#include <ForgeGame_WidgetBP_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass ForgeGame_WidgetBP.ForgeGame_WidgetBP_C
// Size: 0x820(Inherited: 0x818) 
struct UForgeGame_WidgetBP_C : public UPortalWarsForgeGameWidget
{
	struct UErrorMenu_C* ErrorMenu;  // 0x818(0x8)

}; 



