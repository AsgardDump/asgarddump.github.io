#pragma once 
#include <JoinServerDialog_WidgetBP_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass JoinServerDialog_WidgetBP.JoinServerDialog_WidgetBP_C
// Size: 0x8B8(Inherited: 0x8A0) 
struct UJoinServerDialog_WidgetBP_C : public UPortalWarsJoinServerDialogWidget
{
	struct UPurchaseDialogBackground_C* PurchaseDialogBackground;  // 0x8A0(0x8)
	struct USafeZone* SafeZone_1;  // 0x8A8(0x8)
	struct UWBP_Footer_C* WBP_Footer;  // 0x8B0(0x8)

}; 



