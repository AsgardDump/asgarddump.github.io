#pragma once 
#include <BattlePassPanelRewardEntry_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass BattlePassPanelRewardEntry.BattlePassPanelRewardEntry_C
// Size: 0xB00(Inherited: 0xB00) 
struct UBattlePassPanelRewardEntry_C : public UPortalWarsRewardEntryWidget
{

}; 



