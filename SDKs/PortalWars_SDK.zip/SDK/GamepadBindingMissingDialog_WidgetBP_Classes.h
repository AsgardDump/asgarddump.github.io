#pragma once 
#include <GamepadBindingMissingDialog_WidgetBP_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass GamepadBindingMissingDialog_WidgetBP.GamepadBindingMissingDialog_WidgetBP_C
// Size: 0x8D0(Inherited: 0x890) 
struct UGamepadBindingMissingDialog_WidgetBP_C : public UPortalWarsGamepadBindingMissingDialogWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x890(0x8)
	struct UDialogBackground_C* DialogBackground;  // 0x898(0x8)
	struct UImage* Image;  // 0x8A0(0x8)
	struct UImage* Image_2;  // 0x8A8(0x8)
	struct UImage* Image_53;  // 0x8B0(0x8)
	struct UImage* Image_176;  // 0x8B8(0x8)
	struct UImage* Image_299;  // 0x8C0(0x8)
	struct UImage* Image_405;  // 0x8C8(0x8)

	void Construct(); // Function GamepadBindingMissingDialog_WidgetBP.GamepadBindingMissingDialog_WidgetBP_C.Construct
	void ExecuteUbergraph_GamepadBindingMissingDialog_WidgetBP(int32_t EntryPoint); // Function GamepadBindingMissingDialog_WidgetBP.GamepadBindingMissingDialog_WidgetBP_C.ExecuteUbergraph_GamepadBindingMissingDialog_WidgetBP
}; 



