#pragma once 
#include <ChallengeButtonGeneric_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass ChallengeButtonGeneric.ChallengeButtonGeneric_C
// Size: 0x770(Inherited: 0x740) 
struct UChallengeButtonGeneric_C : public UPortalWarsChallengeButtonWidget
{
	struct UImage* Image;  // 0x740(0x8)
	struct UImage* Image_2;  // 0x748(0x8)
	struct UImage* Image_139;  // 0x750(0x8)
	struct UImage* Image_292;  // 0x758(0x8)
	struct UImage* Image_379;  // 0x760(0x8)
	struct UWBP_NewIndicator_C* WBP_NewIndicator;  // 0x768(0x8)

}; 



