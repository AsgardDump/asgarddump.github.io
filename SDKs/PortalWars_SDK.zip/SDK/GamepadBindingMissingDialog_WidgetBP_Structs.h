#pragma once 
#include "SDK.h" 
 
 
// Function GamepadBindingMissingDialog_WidgetBP.GamepadBindingMissingDialog_WidgetBP_C.ExecuteUbergraph_GamepadBindingMissingDialog_WidgetBP
// Size: 0x4(Inherited: 0x0) 
struct FExecuteUbergraph_GamepadBindingMissingDialog_WidgetBP
{
	int32_t EntryPoint;  // 0x0(0x4)

}; 
