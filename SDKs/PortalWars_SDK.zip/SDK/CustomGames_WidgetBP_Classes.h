#pragma once 
#include <CustomGames_WidgetBP_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass CustomGames_WidgetBP.CustomGames_WidgetBP_C
// Size: 0x820(Inherited: 0x818) 
struct UCustomGames_WidgetBP_C : public UPortalWarsCustomGameWidget
{
	struct UErrorMenu_C* ErrorMenu;  // 0x818(0x8)

}; 



