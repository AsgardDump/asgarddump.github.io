#pragma once 
#include <ErrorMenu_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass ErrorMenu.ErrorMenu_C
// Size: 0x838(Inherited: 0x800) 
struct UErrorMenu_C : public UPortalWarsMenuWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x800(0x8)
	struct UTextBlock* ErrorText;  // 0x808(0x8)
	struct UMenuBackground_C* MenuBackground;  // 0x810(0x8)
	struct USafeZone* SafeZone_1;  // 0x818(0x8)
	struct FText Text;  // 0x820(0x18)

	void PreConstruct(bool IsDesignTime); // Function ErrorMenu.ErrorMenu_C.PreConstruct
	void ExecuteUbergraph_ErrorMenu(int32_t EntryPoint); // Function ErrorMenu.ErrorMenu_C.ExecuteUbergraph_ErrorMenu
}; 



