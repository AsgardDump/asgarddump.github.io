#pragma once 
#include <BP_DialogLibraryBase_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_DialogLibraryBase.BP_DialogLibraryBase_C
// Size: 0xB8(Inherited: 0xB8) 
struct UBP_DialogLibraryBase_C : public UPortalWarsDialogLibraryComponent
{

}; 



