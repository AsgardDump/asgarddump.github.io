#pragma once 
#include "SDK.h" 
 
 
// Function Dialog_GameSessionReconnect.Dialog_GameSessionReconnect_C.ExecuteUbergraph_Dialog_GameSessionReconnect
// Size: 0x4(Inherited: 0x0) 
struct FExecuteUbergraph_Dialog_GameSessionReconnect
{
	int32_t EntryPoint;  // 0x0(0x4)

}; 
