#pragma once 
#include <MainMenu_Inspect_Structs.h>
 
 
 
// BlueprintGeneratedClass MainMenu_Inspect.MainMenu_Inspect_C
// Size: 0x228(Inherited: 0x228) 
struct AMainMenu_Inspect_C : public ALevelScriptActor
{

}; 



