#pragma once 
#include "SDK.h" 
 
 
// Function MovieRenderPipelineSettings.MoviePipelineBurnInWidget.OnOutputFrameStarted
// Size: 0x8(Inherited: 0x0) 
struct FOnOutputFrameStarted
{
	struct UMoviePipeline* ForPipeline;  // 0x0(0x8)

}; 
