#pragma once 
#include <MKBSettings_WidgetBP_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass MKBSettings_WidgetBP.MKBSettings_WidgetBP_C
// Size: 0x8D8(Inherited: 0x8B8) 
struct UMKBSettings_WidgetBP_C : public UPortalWarsMKBSettingsWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x8B8(0x8)
	struct UMenuBackground_C* MenuBackground;  // 0x8C0(0x8)
	struct USafeZone* SafeZone_1;  // 0x8C8(0x8)
	struct UWBP_Footer_C* WBP_Footer;  // 0x8D0(0x8)

	void Construct(); // Function MKBSettings_WidgetBP.MKBSettings_WidgetBP_C.Construct
	void ExecuteUbergraph_MKBSettings_WidgetBP(int32_t EntryPoint); // Function MKBSettings_WidgetBP.MKBSettings_WidgetBP_C.ExecuteUbergraph_MKBSettings_WidgetBP
}; 



