#pragma once 
#include <MeleeCamShake_Structs.h>
 
 
 
// BlueprintGeneratedClass MeleeCamShake.MeleeCamShake_C
// Size: 0x1B0(Inherited: 0x1B0) 
struct UMeleeCamShake_C : public UMatineeCameraShake
{

}; 



