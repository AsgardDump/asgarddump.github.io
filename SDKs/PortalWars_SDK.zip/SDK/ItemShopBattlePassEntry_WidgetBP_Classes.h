#pragma once 
#include <ItemShopBattlePassEntry_WidgetBP_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass ItemShopBattlePassEntry_WidgetBP.ItemShopBattlePassEntry_WidgetBP_C
// Size: 0x890(Inherited: 0x850) 
struct UItemShopBattlePassEntry_WidgetBP_C : public UPortalWarsBPRedeemableButton
{
	struct UImage* GamepadKeyImage;  // 0x850(0x8)
	struct UImage* Image_2;  // 0x858(0x8)
	struct UWidgetSwitcher* OwnedSwitcher;  // 0x860(0x8)
	struct UWBP_StorePriceList_C* PriceList;  // 0x868(0x8)
	struct UImage* RarityBG;  // 0x870(0x8)
	struct UImage* RarityBorder;  // 0x878(0x8)
	struct UImage* RarityIcon;  // 0x880(0x8)
	struct UImage* RarityScrim;  // 0x888(0x8)

}; 



