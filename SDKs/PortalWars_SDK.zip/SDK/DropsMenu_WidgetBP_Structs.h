#pragma once 
#include "SDK.h" 
 
 
// Function DropsMenu_WidgetBP.DropsMenu_WidgetBP_C.ExecuteUbergraph_DropsMenu_WidgetBP
// Size: 0x4(Inherited: 0x0) 
struct FExecuteUbergraph_DropsMenu_WidgetBP
{
	int32_t EntryPoint;  // 0x0(0x4)

}; 
