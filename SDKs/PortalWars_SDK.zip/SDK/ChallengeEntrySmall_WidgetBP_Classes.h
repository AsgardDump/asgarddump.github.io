#pragma once 
#include <ChallengeEntrySmall_WidgetBP_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass ChallengeEntrySmall_WidgetBP.ChallengeEntrySmall_WidgetBP_C
// Size: 0xD90(Inherited: 0xD28) 
struct UChallengeEntrySmall_WidgetBP_C : public UPortalWarsChallengeEntryWidget
{
	struct UBorder_C* Border;  // 0xD28(0x8)
	struct UBorder_C* Border_2;  // 0xD30(0x8)
	struct UImage* ChallengeBG;  // 0xD38(0x8)
	struct UImage* ChallengeCompletedBG;  // 0xD40(0x8)
	struct UImage* ChallengePremiumBG;  // 0xD48(0x8)
	struct UImage* Image;  // 0xD50(0x8)
	struct UImage* Image_2;  // 0xD58(0x8)
	struct UImage* Image_3;  // 0xD60(0x8)
	struct UImage* Image_83;  // 0xD68(0x8)
	struct UImage* Image_94;  // 0xD70(0x8)
	struct UImage* Image_116;  // 0xD78(0x8)
	struct UReward_WidgetBP_C* Reward_WidgetBP;  // 0xD80(0x8)
	struct UReward_WidgetBP_C* Reward_WidgetBP_2;  // 0xD88(0x8)

}; 



