#pragma once 
#include <LimitedTimeOfferDialog_WidgetBP_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass LimitedTimeOfferDialog_WidgetBP.LimitedTimeOfferDialog_WidgetBP_C
// Size: 0x8B8(Inherited: 0x8A0) 
struct ULimitedTimeOfferDialog_WidgetBP_C : public UPortalWarsLimitedTimeOfferDialogWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x8A0(0x8)
	struct UImage* Image_105;  // 0x8A8(0x8)
	struct UImage* Image_157;  // 0x8B0(0x8)

	void Construct(); // Function LimitedTimeOfferDialog_WidgetBP.LimitedTimeOfferDialog_WidgetBP_C.Construct
	void ExecuteUbergraph_LimitedTimeOfferDialog_WidgetBP(int32_t EntryPoint); // Function LimitedTimeOfferDialog_WidgetBP.LimitedTimeOfferDialog_WidgetBP_C.ExecuteUbergraph_LimitedTimeOfferDialog_WidgetBP
}; 



