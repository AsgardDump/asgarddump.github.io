#pragma once 
#include <IntroMediaSoundActor_BP_Structs.h>
 
 
 
// BlueprintGeneratedClass IntroMediaSoundActor_BP.IntroMediaSoundActor_BP_C
// Size: 0x230(Inherited: 0x230) 
struct AIntroMediaSoundActor_BP_C : public APortalWarsMediaSoundActor
{

}; 



