#pragma once 
#include <AlertButton_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass AlertButton.AlertButton_C
// Size: 0x6B8(Inherited: 0x688) 
struct UAlertButton_C : public UPortalWarsButtonWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x688(0x8)
	struct UImage* ButtonIcon;  // 0x690(0x8)
	struct UImage* GamepadKeyImage;  // 0x698(0x8)
	struct USizeBox* Icon-Root;  // 0x6A0(0x8)
	char pad_1704_1 : 7;  // 0x6A8(0x1)
	bool ShowIcon : 1;  // 0x6A8(0x1)
	char pad_1705[7];  // 0x6A9(0x7)
	struct UTexture2D* Icon;  // 0x6B0(0x8)

	void PreConstruct(bool IsDesignTime); // Function AlertButton.AlertButton_C.PreConstruct
	void ExecuteUbergraph_AlertButton(int32_t EntryPoint); // Function AlertButton.AlertButton_C.ExecuteUbergraph_AlertButton
}; 



