#pragma once 
#include <AccelByteNetworkUtilities_Structs.h>
 
 
 
// Class AccelByteNetworkUtilities.IpConnectionAccelByte
// Size: 0x1C50(Inherited: 0x1C48) 
struct UIpConnectionAccelByte : public UIpConnection
{
	char pad_7240[8];  // 0x1C48(0x8)

}; 



// Class AccelByteNetworkUtilities.IpNetDriverAccelByte
// Size: 0x7D8(Inherited: 0x7D0) 
struct UIpNetDriverAccelByte : public UIpNetDriver
{
	char pad_2000[8];  // 0x7D0(0x8)

}; 



