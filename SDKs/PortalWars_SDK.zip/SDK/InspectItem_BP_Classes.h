#pragma once 
#include <InspectItem_BP_Structs.h>
 
 
 
// BlueprintGeneratedClass InspectItem_BP.InspectItem_BP_C
// Size: 0x4A8(Inherited: 0x480) 
struct AInspectItem_BP_C : public APreviewItem
{
	struct UStaticMeshComponent* PortalFrame;  // 0x480(0x8)
	struct USpotLightComponent* SecondaryKeyLight1;  // 0x488(0x8)
	struct USpotLightComponent* MainKeyLight;  // 0x490(0x8)
	struct UPointLightComponent* PointLight2;  // 0x498(0x8)
	struct UPointLightComponent* PointLight;  // 0x4A0(0x8)

}; 



