#pragma once 
#include <BattlePassPurchaseButton_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass BattlePassPurchaseButton.BattlePassPurchaseButton_C
// Size: 0x8A9(Inherited: 0x850) 
struct UBattlePassPurchaseButton_C : public UPortalWarsBPRedeemableButton
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x850(0x8)
	struct UImage* Background;  // 0x858(0x8)
	struct UImage* ButtonIcon;  // 0x860(0x8)
	struct UImage* GamepadKeyImage;  // 0x868(0x8)
	struct USizeBox* GamepadSizeBox;  // 0x870(0x8)
	struct UImage* Graphic;  // 0x878(0x8)
	struct UHorizontalBox* HorizontalBox_1;  // 0x880(0x8)
	struct USizeBox* IconSizeBox;  // 0x888(0x8)
	struct UImage* Image;  // 0x890(0x8)
	struct UHorizontalBox* Price;  // 0x898(0x8)
	struct URichTextBlock* RichTextBlock;  // 0x8A0(0x8)
	char pad_2216_1 : 7;  // 0x8A8(0x1)
	bool ShowPrice : 1;  // 0x8A8(0x1)

	void SetComponentVisibility(struct UWidget* Target, bool IsVisible); // Function BattlePassPurchaseButton.BattlePassPurchaseButton_C.SetComponentVisibility
	void PreConstruct(bool IsDesignTime); // Function BattlePassPurchaseButton.BattlePassPurchaseButton_C.PreConstruct
	void Construct(); // Function BattlePassPurchaseButton.BattlePassPurchaseButton_C.Construct
	void ExecuteUbergraph_BattlePassPurchaseButton(int32_t EntryPoint); // Function BattlePassPurchaseButton.BattlePassPurchaseButton_C.ExecuteUbergraph_BattlePassPurchaseButton
}; 



