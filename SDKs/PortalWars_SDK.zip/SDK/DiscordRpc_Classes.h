#pragma once 
#include <DiscordRpc_Structs.h>
 
 
 
// Class DiscordRpc.DiscordRpc
// Size: 0x148(Inherited: 0x28) 
struct UDiscordRpc : public UObject
{
	char pad_40_1 : 7;  // 0x28(0x1)
	bool IsConnected : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct FMulticastInlineDelegate OnConnected;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnDisconnected;  // 0x40(0x10)
	struct FMulticastInlineDelegate OnErrored;  // 0x50(0x10)
	struct FMulticastInlineDelegate OnJoin;  // 0x60(0x10)
	struct FMulticastInlineDelegate OnSpectate;  // 0x70(0x10)
	struct FMulticastInlineDelegate OnJoinRequest;  // 0x80(0x10)
	struct FDiscordRichPresence RichPresence;  // 0x90(0xB8)

	void UpdatePresence(); // Function DiscordRpc.DiscordRpc.UpdatePresence
	void Shutdown(); // Function DiscordRpc.DiscordRpc.Shutdown
	void RunCallbacks(); // Function DiscordRpc.DiscordRpc.RunCallbacks
	void Respond(struct FString UserId, int32_t Reply); // Function DiscordRpc.DiscordRpc.Respond
	void Initialize(struct FString applicationId, bool autoRegister, struct FString optionalSteamId); // Function DiscordRpc.DiscordRpc.Initialize
	void ClearPresence(); // Function DiscordRpc.DiscordRpc.ClearPresence
}; 



