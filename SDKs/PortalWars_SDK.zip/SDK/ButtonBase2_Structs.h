#pragma once 
#include "SDK.h" 
 
 
// Function ButtonBase2.ButtonBase2_C.ExecuteUbergraph_ButtonBase2
// Size: 0x88(Inherited: 0x0) 
struct FExecuteUbergraph_ButtonBase2
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Temp_bool_Variable : 1;  // 0x4(0x1)
	uint8_t  Temp_byte_Variable;  // 0x5(0x1)
	uint8_t  Temp_byte_Variable_2;  // 0x6(0x1)
	char pad_7[1];  // 0x7(0x1)
	float CallFunc_BreakVector2D_X;  // 0x8(0x4)
	float CallFunc_BreakVector2D_Y;  // 0xC(0x4)
	uint8_t  K2Node_Select_Default;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool K2Node_Event_IsDesignTime : 1;  // 0x11(0x1)
	char pad_18[2];  // 0x12(0x2)
	float CallFunc_BreakVector2D_X_2;  // 0x14(0x4)
	float CallFunc_BreakVector2D_Y_2;  // 0x18(0x4)
	float CallFunc_BreakVector2D_X_3;  // 0x1C(0x4)
	float CallFunc_BreakVector2D_Y_3;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)
	struct FSlateColor K2Node_MakeStruct_SlateColor;  // 0x28(0x28)
	struct FVector2D CallFunc_Multiply_Vector2DFloat_ReturnValue;  // 0x50(0x8)
	float CallFunc_BreakVector2D_X_4;  // 0x58(0x4)
	float CallFunc_BreakVector2D_Y_4;  // 0x5C(0x4)
	struct FSlateColor K2Node_MakeStruct_SlateColor_2;  // 0x60(0x28)

}; 
// Function ButtonBase2.ButtonBase2_C.PreConstruct
// Size: 0x1(Inherited: 0x1) 
struct FPreConstruct : public FPreConstruct
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool IsDesignTime : 1;  // 0x0(0x1)

}; 
