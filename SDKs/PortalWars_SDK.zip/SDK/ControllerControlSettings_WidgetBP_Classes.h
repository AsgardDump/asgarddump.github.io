#pragma once 
#include <ControllerControlSettings_WidgetBP_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass ControllerControlSettings_WidgetBP.ControllerControlSettings_WidgetBP_C
// Size: 0x888(Inherited: 0x880) 
struct UControllerControlSettings_WidgetBP_C : public UPortalWarsControlSettingsWidget
{
	struct USafeZone* SafeZone_1;  // 0x880(0x8)

}; 



