#pragma once 
#include <ChallengesLarge_WidgetBP_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass ChallengesLarge_WidgetBP.ChallengesLarge_WidgetBP_C
// Size: 0x950(Inherited: 0x910) 
struct UChallengesLarge_WidgetBP_C : public UPortalWarsChallengesSubWidget
{
	struct UChallengeEntryFeatured_WidgetBP_C* ChallengeEntryFeatured_WidgetBP;  // 0x910(0x8)
	struct UChallengeEntryLarge_WidgetBP_C* ChallengeEntryLarge_WidgetBP;  // 0x918(0x8)
	struct UChallengeEntryLarge_WidgetBP_C* ChallengeEntryLarge_WidgetBP_104;  // 0x920(0x8)
	struct UChallengeEntryLarge_WidgetBP_C* ChallengeEntryLarge_WidgetBP_181;  // 0x928(0x8)
	struct UMenuBackground_C* MenuBackground;  // 0x930(0x8)
	struct UWBP_PageHeader_C* PageHeader;  // 0x938(0x8)
	struct USafeZone* SafeZone_1;  // 0x940(0x8)
	struct UWBP_Footer_C* WBP_Footer;  // 0x948(0x8)

}; 



