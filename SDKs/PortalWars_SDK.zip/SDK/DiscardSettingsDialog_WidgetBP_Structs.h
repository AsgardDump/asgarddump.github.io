#pragma once 
#include "SDK.h" 
 
 
// Function DiscardSettingsDialog_WidgetBP.DiscardSettingsDialog_WidgetBP_C.ExecuteUbergraph_DiscardSettingsDialog_WidgetBP
// Size: 0x4(Inherited: 0x0) 
struct FExecuteUbergraph_DiscardSettingsDialog_WidgetBP
{
	int32_t EntryPoint;  // 0x0(0x4)

}; 
