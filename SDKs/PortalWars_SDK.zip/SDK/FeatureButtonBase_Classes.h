#pragma once 
#include <FeatureButtonBase_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass FeatureButtonBase.FeatureButtonBase_C
// Size: 0x7B9(Inherited: 0x6E8) 
struct UFeatureButtonBase_C : public UPortalWarsEntryWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x6E8(0x8)
	struct UImage* DisplayImage;  // 0x6F0(0x8)
	struct UImage* IconImage;  // 0x6F8(0x8)
	struct UImage* Image_2;  // 0x700(0x8)
	struct UImage* Image_3;  // 0x708(0x8)
	struct UImage* Image_97;  // 0x710(0x8)
	struct UImage* Image_202;  // 0x718(0x8)
	struct UImage* Image_229;  // 0x720(0x8)
	struct UImage* Image_345;  // 0x728(0x8)
	struct UImage* Image_462;  // 0x730(0x8)
	struct UImage* Image_1441;  // 0x738(0x8)
	struct UImage* Image_1559;  // 0x740(0x8)
	struct UImage* PlayIcon;  // 0x748(0x8)
	struct UWidgetSwitcher* ScrimSwitcher;  // 0x750(0x8)
	struct UOverlay* SelectedIndicator;  // 0x758(0x8)
	struct UWidgetSwitcher* SelectedSwitcher;  // 0x760(0x8)
	struct UWidgetSwitcher* SelectedSwitcher2;  // 0x768(0x8)
	struct UImage* Shadow;  // 0x770(0x8)
	struct UTextBlock* SubtextText;  // 0x778(0x8)
	struct UTextBlock* TitleText2;  // 0x780(0x8)
	struct UTexture2D* MainImage;  // 0x788(0x8)
	struct UTexture2D* Icon;  // 0x790(0x8)
	char pad_1944_1 : 7;  // 0x798(0x1)
	bool ShowSubText : 1;  // 0x798(0x1)
	char pad_1945[7];  // 0x799(0x7)
	struct FText SubText;  // 0x7A0(0x18)
	char EHorizontalAlignment HorizontalAlignment;  // 0x7B8(0x1)

	void PreConstruct(bool IsDesignTime); // Function FeatureButtonBase.FeatureButtonBase_C.PreConstruct
	void UpdateAlignment(); // Function FeatureButtonBase.FeatureButtonBase_C.UpdateAlignment
	void ExecuteUbergraph_FeatureButtonBase(int32_t EntryPoint); // Function FeatureButtonBase.FeatureButtonBase_C.ExecuteUbergraph_FeatureButtonBase
}; 



