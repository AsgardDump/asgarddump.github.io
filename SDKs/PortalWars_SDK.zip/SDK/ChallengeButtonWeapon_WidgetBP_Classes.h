#pragma once 
#include <ChallengeButtonWeapon_WidgetBP_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass ChallengeButtonWeapon_WidgetBP.ChallengeButtonWeapon_WidgetBP_C
// Size: 0x758(Inherited: 0x740) 
struct UChallengeButtonWeapon_WidgetBP_C : public UPortalWarsChallengeButtonWidget
{
	struct UImage* Image;  // 0x740(0x8)
	struct UImage* Image_292;  // 0x748(0x8)
	struct UWBP_NewIndicator_C* WBP_NewIndicator;  // 0x750(0x8)

}; 



