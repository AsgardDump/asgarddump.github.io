#pragma once 
#include <Leaderboard_WidgetBP_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass Leaderboard_WidgetBP.Leaderboard_WidgetBP_C
// Size: 0x5A0(Inherited: 0x570) 
struct ULeaderboard_WidgetBP_C : public UPortalWarsLeaderboardWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x570(0x8)
	struct UCircularThrobber* CircularThrobber_169;  // 0x578(0x8)
	struct UTextBlock* ValueText;  // 0x580(0x8)
	struct FText Value;  // 0x588(0x18)

	void PreConstruct(bool IsDesignTime); // Function Leaderboard_WidgetBP.Leaderboard_WidgetBP_C.PreConstruct
	void ExecuteUbergraph_Leaderboard_WidgetBP(int32_t EntryPoint); // Function Leaderboard_WidgetBP.Leaderboard_WidgetBP_C.ExecuteUbergraph_Leaderboard_WidgetBP
}; 



