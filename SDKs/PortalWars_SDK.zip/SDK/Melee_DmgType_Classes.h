#pragma once 
#include <Melee_DmgType_Structs.h>
 
 
 
// BlueprintGeneratedClass Melee_DmgType.Melee_DmgType_C
// Size: 0x60(Inherited: 0x60) 
struct UMelee_DmgType_C : public UPortalWarsMeleeDmgType
{

}; 



