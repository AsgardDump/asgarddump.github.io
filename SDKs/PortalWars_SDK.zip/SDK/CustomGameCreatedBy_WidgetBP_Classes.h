#pragma once 
#include <CustomGameCreatedBy_WidgetBP_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass CustomGameCreatedBy_WidgetBP.CustomGameCreatedBy_WidgetBP_C
// Size: 0x940(Inherited: 0x940) 
struct UCustomGameCreatedBy_WidgetBP_C : public UPortalWarsPlayerEntryWidget
{

}; 



