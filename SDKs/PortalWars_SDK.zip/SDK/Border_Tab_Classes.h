#pragma once 
#include <Border_Tab_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass Border_Tab.Border_Tab_C
// Size: 0x583(Inherited: 0x520) 
struct UBorder_Tab_C : public UPortalWarsUserWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x520(0x8)
	struct UBackgroundBlur* BackgroundBlur_66;  // 0x528(0x8)
	struct UImage* black;  // 0x530(0x8)
	struct UImage* Border;  // 0x538(0x8)
	struct UImage* Border_Small;  // 0x540(0x8)
	struct UImage* FocusColor;  // 0x548(0x8)
	struct UImage* GraphicLine;  // 0x550(0x8)
	struct FLinearColor Color;  // 0x558(0x10)
	uint8_t  SetBlurVisibity;  // 0x568(0x1)
	char pad_1385[7];  // 0x569(0x7)
	struct UMaterialInstanceDynamic* DMI_Border;  // 0x570(0x8)
	float Value;  // 0x578(0x4)
	float GraphicLineTranslation;  // 0x57C(0x4)
	uint8_t  GraphicLineVisibility;  // 0x580(0x1)
	uint8_t  SetFocusColor;  // 0x581(0x1)
	uint8_t  SetSmallBorderVisibility;  // 0x582(0x1)

	void SetMaterial(); // Function Border_Tab.Border_Tab_C.SetMaterial
	void PreConstruct(bool IsDesignTime); // Function Border_Tab.Border_Tab_C.PreConstruct
	void ExecuteUbergraph_Border_Tab(int32_t EntryPoint); // Function Border_Tab.Border_Tab_C.ExecuteUbergraph_Border_Tab
}; 



