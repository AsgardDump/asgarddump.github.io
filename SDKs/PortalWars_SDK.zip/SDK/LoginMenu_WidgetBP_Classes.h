#pragma once 
#include <LoginMenu_WidgetBP_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass LoginMenu_WidgetBP.LoginMenu_WidgetBP_C
// Size: 0x860(Inherited: 0x838) 
struct ULoginMenu_WidgetBP_C : public UPortalWarsLoginMenuWidget
{
	struct UImage* BG;  // 0x838(0x8)
	struct UImage* Logo;  // 0x840(0x8)
	struct USafeZone* SafeZone_1;  // 0x848(0x8)
	struct UThrobber* Throbber;  // 0x850(0x8)
	struct UThrobber* Throbber_1;  // 0x858(0x8)

}; 



