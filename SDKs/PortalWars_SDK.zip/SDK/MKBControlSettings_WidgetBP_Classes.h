#pragma once 
#include <MKBControlSettings_WidgetBP_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass MKBControlSettings_WidgetBP.MKBControlSettings_WidgetBP_C
// Size: 0x888(Inherited: 0x880) 
struct UMKBControlSettings_WidgetBP_C : public UPortalWarsControlSettingsWidget
{
	struct USafeZone* SafeZone_1;  // 0x880(0x8)

}; 



