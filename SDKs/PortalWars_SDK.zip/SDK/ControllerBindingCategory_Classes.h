#pragma once 
#include <ControllerBindingCategory_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass ControllerBindingCategory.ControllerBindingCategory_C
// Size: 0x268(Inherited: 0x268) 
struct UControllerBindingCategory_C : public UPortalWarsGamepadBindingCategoryWidget
{

}; 



