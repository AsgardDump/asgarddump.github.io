#pragma once 
#include <MovieRenderPipelineRenderPasses_Structs.h>
 
 
 
// Class MovieRenderPipelineRenderPasses.MoviePipelineDeferredPassBase
// Size: 0x170(Inherited: 0xC8) 
struct UMoviePipelineDeferredPassBase : public UMoviePipelineImagePassBase
{
	char pad_200_1 : 7;  // 0xC8(0x1)
	bool bAccumulatorIncludesAlpha : 1;  // 0xC8(0x1)
	char pad_201_1 : 7;  // 0xC9(0x1)
	bool bDisableMultisampleEffects : 1;  // 0xC9(0x1)
	char pad_202_1 : 7;  // 0xCA(0x1)
	bool bUse32BitPostProcessMaterials : 1;  // 0xCA(0x1)
	char pad_203[5];  // 0xCB(0x5)
	struct TArray<struct FMoviePipelinePostProcessPass> AdditionalPostProcessMaterials;  // 0xD0(0x10)
	char pad_224_1 : 7;  // 0xE0(0x1)
	bool bAddDefaultLayer : 1;  // 0xE0(0x1)
	char pad_225[7];  // 0xE1(0x7)
	struct TArray<struct FActorLayer> StencilLayers;  // 0xE8(0x10)
	struct TArray<struct UMaterialInterface*> ActivePostProcessMaterials;  // 0xF8(0x10)
	struct UMaterialInterface* StencilLayerMaterial;  // 0x108(0x8)
	struct TArray<struct UTextureRenderTarget2D*> TileRenderTargets;  // 0x110(0x10)
	char pad_288[80];  // 0x120(0x50)

}; 



// Class MovieRenderPipelineRenderPasses.MoviePipelineImageSequenceOutputBase
// Size: 0x68(Inherited: 0x48) 
struct UMoviePipelineImageSequenceOutputBase : public UMoviePipelineOutputBase
{
	char pad_72[32];  // 0x48(0x20)

}; 



// Class MovieRenderPipelineRenderPasses.MoviePipelineImagePassBase
// Size: 0xC8(Inherited: 0x48) 
struct UMoviePipelineImagePassBase : public UMoviePipelineRenderPass
{
	char pad_72[128];  // 0x48(0x80)

}; 



// Class MovieRenderPipelineRenderPasses.MoviePipelineDeferredPass_ReflectionsOnly
// Size: 0x170(Inherited: 0x170) 
struct UMoviePipelineDeferredPass_ReflectionsOnly : public UMoviePipelineDeferredPassBase
{

}; 



// Class MovieRenderPipelineRenderPasses.MoviePipelineDeferredPass_Unlit
// Size: 0x170(Inherited: 0x170) 
struct UMoviePipelineDeferredPass_Unlit : public UMoviePipelineDeferredPassBase
{

}; 



// Class MovieRenderPipelineRenderPasses.MoviePipelineDeferredPass_DetailLighting
// Size: 0x170(Inherited: 0x170) 
struct UMoviePipelineDeferredPass_DetailLighting : public UMoviePipelineDeferredPassBase
{

}; 



// Class MovieRenderPipelineRenderPasses.MoviePipelineDeferredPass_PathTracer
// Size: 0x170(Inherited: 0x170) 
struct UMoviePipelineDeferredPass_PathTracer : public UMoviePipelineDeferredPassBase
{

}; 



// Class MovieRenderPipelineRenderPasses.MoviePipelineDeferredPass_LightingOnly
// Size: 0x170(Inherited: 0x170) 
struct UMoviePipelineDeferredPass_LightingOnly : public UMoviePipelineDeferredPassBase
{

}; 



// Class MovieRenderPipelineRenderPasses.MoviePipelineImageSequenceOutput_EXR
// Size: 0x70(Inherited: 0x68) 
struct UMoviePipelineImageSequenceOutput_EXR : public UMoviePipelineImageSequenceOutputBase
{
	uint8_t  Compression;  // 0x68(0x1)
	char pad_105_1 : 7;  // 0x69(0x1)
	bool bMultilayer : 1;  // 0x69(0x1)
	char pad_106[6];  // 0x6A(0x6)

}; 



// Class MovieRenderPipelineRenderPasses.MoviePipelineImageSequenceOutput_BMP
// Size: 0x68(Inherited: 0x68) 
struct UMoviePipelineImageSequenceOutput_BMP : public UMoviePipelineImageSequenceOutputBase
{

}; 



// Class MovieRenderPipelineRenderPasses.MoviePipelineImageSequenceOutput_PNG
// Size: 0x68(Inherited: 0x68) 
struct UMoviePipelineImageSequenceOutput_PNG : public UMoviePipelineImageSequenceOutputBase
{

}; 



// Class MovieRenderPipelineRenderPasses.MoviePipelineImageSequenceOutput_JPG
// Size: 0x68(Inherited: 0x68) 
struct UMoviePipelineImageSequenceOutput_JPG : public UMoviePipelineImageSequenceOutputBase
{

}; 



// Class MovieRenderPipelineRenderPasses.MoviePipelineWaveOutput
// Size: 0xB8(Inherited: 0x48) 
struct UMoviePipelineWaveOutput : public UMoviePipelineOutputBase
{
	struct FString FileNameFormatOverride;  // 0x48(0x10)
	char pad_88[96];  // 0x58(0x60)

}; 



