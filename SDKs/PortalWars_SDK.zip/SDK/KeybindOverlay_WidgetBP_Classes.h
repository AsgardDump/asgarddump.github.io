#pragma once 
#include <KeybindOverlay_WidgetBP_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass KeybindOverlay_WidgetBP.KeybindOverlay_WidgetBP_C
// Size: 0x880(Inherited: 0x878) 
struct UKeybindOverlay_WidgetBP_C : public UPortalWarsKeybindOverlayWidget
{
	struct UDialogBackground_C* DialogBackground;  // 0x878(0x8)

}; 



