#pragma once 
#include <KeybindEntry_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass KeybindEntry.KeybindEntry_C
// Size: 0x6E0(Inherited: 0x6D8) 
struct UKeybindEntry_C : public UPortalWarsKeybindWidget
{
	struct UImage* Image_101;  // 0x6D8(0x8)

}; 



