#pragma once 
#include <LimitedTimeOfferSection_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass LimitedTimeOfferSection.LimitedTimeOfferSection_C
// Size: 0x608(Inherited: 0x608) 
struct ULimitedTimeOfferSection_C : public UPortalWarsItemShopSectionWidget
{

}; 



