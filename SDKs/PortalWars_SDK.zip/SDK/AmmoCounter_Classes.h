#pragma once 
#include <AmmoCounter_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass AmmoCounter.AmmoCounter_C
// Size: 0x278(Inherited: 0x278) 
struct UAmmoCounter_C : public UPortalWarsAmmoCounterWidget
{

}; 



