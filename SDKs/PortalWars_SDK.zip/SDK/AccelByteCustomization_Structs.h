#pragma once 
#include "SDK.h" 
 
 
// ScriptStruct AccelByteCustomization.AccelByteModelsUserUnlockedAchievements
// Size: 0x10(Inherited: 0x0) 
struct FAccelByteModelsUserUnlockedAchievements
{
	struct TArray<int32_t> Ids;  // 0x0(0x10)

}; 
// ScriptStruct AccelByteCustomization.AccelByteModelsUserStats
// Size: 0x70(Inherited: 0x0) 
struct FAccelByteModelsUserStats
{
	struct FAccelByteModelsTotalStats overall;  // 0x0(0x5C)
	char pad_92[4];  // 0x5C(0x4)
	struct TArray<struct FAccelByteModelsSeasonStats> Seasons;  // 0x60(0x10)

}; 
// ScriptStruct AccelByteCustomization.AccelByteBadgeNextTierProgressModel
// Size: 0xC(Inherited: 0x0) 
struct FAccelByteBadgeNextTierProgressModel
{
	int32_t Tier;  // 0x0(0x4)
	int32_t Target;  // 0x4(0x4)
	int32_t Progress;  // 0x8(0x4)

}; 
// ScriptStruct AccelByteCustomization.AccelBytePartyAllBadgeProgressUpdate
// Size: 0x10(Inherited: 0x0) 
struct FAccelBytePartyAllBadgeProgressUpdate
{
	struct TArray<struct FAccelByteGetUserAllBadgeProgressResponse> Data;  // 0x0(0x10)

}; 
// ScriptStruct AccelByteCustomization.AccelByteModelsRankArray
// Size: 0x10(Inherited: 0x0) 
struct FAccelByteModelsRankArray
{
	struct TArray<struct FAccelByteModelsRank> Data;  // 0x0(0x10)

}; 
// ScriptStruct AccelByteCustomization.AccelByteModelsDeletedSessionNotif
// Size: 0x108(Inherited: 0x0) 
struct FAccelByteModelsDeletedSessionNotif
{
	struct FDateTime CreatedAt;  // 0x0(0x8)
	struct TArray<struct FJsonObjectWrapper> Users;  // 0x8(0x10)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool IsCustomGame : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct FJsonObjectWrapper GameSession;  // 0x20(0x20)
	struct FAccelByteModelsMatchSession MatchSession;  // 0x40(0xB8)
	struct FDateTime MatchStarted;  // 0xF8(0x8)
	struct FDateTime MatchEnded;  // 0x100(0x8)

}; 
// ScriptStruct AccelByteCustomization.AccelByteModelsUserLimitedTimeOfferView
// Size: 0x70(Inherited: 0x0) 
struct FAccelByteModelsUserLimitedTimeOfferView
{
	struct FString Title;  // 0x0(0x10)
	struct FString Description;  // 0x10(0x10)
	struct FString LongDescription;  // 0x20(0x10)
	struct FString ViewId;  // 0x30(0x10)
	struct FString Namespace;  // 0x40(0x10)
	struct FString Name;  // 0x50(0x10)
	struct TArray<struct FAccelByteModelsUserLimitedSection> Section;  // 0x60(0x10)

}; 
// ScriptStruct AccelByteCustomization.AccelByteModelsClientLogsMetaData
// Size: 0x50(Inherited: 0x0) 
struct FAccelByteModelsClientLogsMetaData
{
	struct TMap<struct FString, struct FString> MetaData;  // 0x0(0x50)

}; 
// ScriptStruct AccelByteCustomization.AccelByteGetUserAllBadgeProgressResponse
// Size: 0x60(Inherited: 0x0) 
struct FAccelByteGetUserAllBadgeProgressResponse
{
	struct FString UserId;  // 0x0(0x10)
	struct TMap<struct FName, struct FAccelByteBadgeProgressModel> BadgeProgress;  // 0x10(0x50)

}; 
// ScriptStruct AccelByteCustomization.AccelByteModelsChallengeInfo
// Size: 0xB0(Inherited: 0x0) 
struct FAccelByteModelsChallengeInfo
{
	int32_t ID;  // 0x0(0x4)
	int32_t GroupId;  // 0x4(0x4)
	struct TArray<struct FString> ExcludedPlaylists;  // 0x8(0x10)
	struct FText DisplayName;  // 0x18(0x18)
	int64_t TargetValue;  // 0x30(0x8)
	struct FAccelByteModelsPlatformReward Reward;  // 0x38(0x60)
	struct FString StatType;  // 0x98(0x10)
	char pad_168_1 : 7;  // 0xA8(0x1)
	bool IsPremium : 1;  // 0xA8(0x1)
	char pad_169[7];  // 0xA9(0x7)

}; 
// ScriptStruct AccelByteCustomization.AccelByteBadgeProgressModel
// Size: 0x28(Inherited: 0x0) 
struct FAccelByteBadgeProgressModel
{
	struct FAccelByteBadgeModel Badge;  // 0x0(0x18)
	int32_t CurrentTier;  // 0x18(0x4)
	struct FAccelByteBadgeNextTierProgressModel NextTierProgress;  // 0x1C(0xC)

}; 
// ScriptStruct AccelByteCustomization.AccelByteBadgeModel
// Size: 0x18(Inherited: 0x0) 
struct FAccelByteBadgeModel
{
	struct TArray<int32_t> TierTargets;  // 0x0(0x10)
	uint8_t  Visibility;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)

}; 
// ScriptStruct AccelByteCustomization.AccelByteRaceCourseTime
// Size: 0x18(Inherited: 0x0) 
struct FAccelByteRaceCourseTime
{
	struct FString Map;  // 0x0(0x10)
	uint8_t  Difficulty;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)
	int32_t TimeMs;  // 0x14(0x4)

}; 
// ScriptStruct AccelByteCustomization.AccelByteModelsActionUnbanRequest
// Size: 0x20(Inherited: 0x0) 
struct FAccelByteModelsActionUnbanRequest
{
	struct TArray<struct FString> UserIds;  // 0x0(0x10)
	struct FString Comment;  // 0x10(0x10)

}; 
// ScriptStruct AccelByteCustomization.AccelBytePlaylistState
// Size: 0x70(Inherited: 0x0) 
struct FAccelBytePlaylistState
{
	int32_t MinProgressionLevel;  // 0x0(0x4)
	int32_t XpBoostPercentage;  // 0x4(0x4)
	int64_t StartAtMs;  // 0x8(0x8)
	int64_t EndAtMs;  // 0x10(0x8)
	struct FText Title;  // 0x18(0x18)
	struct FString ImageUrl;  // 0x30(0x10)
	int32_t MaxPartySize;  // 0x40(0x4)
	char pad_68[4];  // 0x44(0x4)
	struct FString MatchmakingName;  // 0x48(0x10)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool IsActive : 1;  // 0x58(0x1)
	char pad_89_1 : 7;  // 0x59(0x1)
	bool IsCrossplayRequired : 1;  // 0x59(0x1)
	char pad_90_1 : 7;  // 0x5A(0x1)
	bool IsFeatured : 1;  // 0x5A(0x1)
	char pad_91_1 : 7;  // 0x5B(0x1)
	bool IsRanked : 1;  // 0x5B(0x1)
	char pad_92_1 : 7;  // 0x5C(0x1)
	bool IsWaitingArea : 1;  // 0x5C(0x1)
	char pad_93_1 : 7;  // 0x5D(0x1)
	bool IsEligibleForHalfBotGames : 1;  // 0x5D(0x1)
	char pad_94[2];  // 0x5E(0x2)
	struct TArray<struct FAccelByteGameModeConfig> GameModes;  // 0x60(0x10)

}; 
// ScriptStruct AccelByteCustomization.AccelByteModelsMatchmakingAlliance
// Size: 0x10(Inherited: 0x0) 
struct FAccelByteModelsMatchmakingAlliance
{
	int32_t MinNumber;  // 0x0(0x4)
	int32_t MaxNumber;  // 0x4(0x4)
	int32_t PlayerMinNumber;  // 0x8(0x4)
	int32_t PlayerMaxNumber;  // 0xC(0x4)

}; 
// ScriptStruct AccelByteCustomization.AccelByteModelsPlayStationDLCSync
// Size: 0x4(Inherited: 0x0) 
struct FAccelByteModelsPlayStationDLCSync
{
	int32_t ServiceLabel;  // 0x0(0x4)

}; 
// ScriptStruct AccelByteCustomization.AccelByteModelsActionBanRequest
// Size: 0x28(Inherited: 0x0) 
struct FAccelByteModelsActionBanRequest
{
	struct TArray<struct FString> UserIds;  // 0x0(0x10)
	int32_t ActionId;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct FString Comment;  // 0x18(0x10)

}; 
// ScriptStruct AccelByteCustomization.AccelByteModelsChallengeTypeMap
// Size: 0x50(Inherited: 0x0) 
struct FAccelByteModelsChallengeTypeMap
{
	struct TArray<struct FAccelByteModelsChallengeInfo> daily;  // 0x0(0x10)
	struct TArray<struct FAccelByteModelsChallengeInfo> weekly;  // 0x10(0x10)
	struct TArray<struct FAccelByteModelsChallengeInfo> Season;  // 0x20(0x10)
	struct TArray<struct FAccelByteModelsChallengeInfo> Weapon;  // 0x30(0x10)
	struct TArray<struct FAccelByteModelsChallengeFeatured> Featured;  // 0x40(0x10)

}; 
// ScriptStruct AccelByteCustomization.AccelByteModelsChallengeFeatured
// Size: 0x20(Inherited: 0x0) 
struct FAccelByteModelsChallengeFeatured
{
	struct FDateTime StartsAt;  // 0x0(0x8)
	struct FDateTime EndsAt;  // 0x8(0x8)
	struct TArray<struct FAccelByteModelsChallengeInfo> Challenges;  // 0x10(0x10)

}; 
// ScriptStruct AccelByteCustomization.AccelByteModelsPlatformReward
// Size: 0x60(Inherited: 0x0) 
struct FAccelByteModelsPlatformReward
{
	uint8_t  Type;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FAccelByteModelsPlatformRewardItem Item;  // 0x8(0x30)
	struct FAccelByteModelsPlatformRewardCurrency Currency;  // 0x38(0x20)
	int32_t Quantity;  // 0x58(0x4)
	char pad_92[4];  // 0x5C(0x4)

}; 
// ScriptStruct AccelByteCustomization.AccelByteModelsPlatformRewardCurrency
// Size: 0x20(Inherited: 0x0) 
struct FAccelByteModelsPlatformRewardCurrency
{
	struct FString Namespace;  // 0x0(0x10)
	struct FString CurrencyCode;  // 0x10(0x10)

}; 
// ScriptStruct AccelByteCustomization.AccelByteModelsCompositeUserId
// Size: 0x30(Inherited: 0x0) 
struct FAccelByteModelsCompositeUserId
{
	struct FString UserId;  // 0x0(0x10)
	struct FString Platform;  // 0x10(0x10)
	struct FString PlatformId;  // 0x20(0x10)

}; 
// Function AccelByteCustomization.AccelByteBlueprintsCustomizationSettings.SetChallengeServerUrl
// Size: 0x10(Inherited: 0x0) 
struct FSetChallengeServerUrl
{
	struct FString ChallengeServerUrl;  // 0x0(0x10)

}; 
// ScriptStruct AccelByteCustomization.AccelByteModelsMatchmakingMatchOptions
// Size: 0x20(Inherited: 0x0) 
struct FAccelByteModelsMatchmakingMatchOptions
{
	struct FString Type;  // 0x0(0x10)
	struct TArray<struct FAccelByteModelsMatchmakingMatchOption> Options;  // 0x10(0x10)

}; 
// Function AccelByteCustomization.AccelByteBlueprintsCustomizationSettings.GetDailyPlayStreakServerUrl
// Size: 0x10(Inherited: 0x0) 
struct FGetDailyPlayStreakServerUrl
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// ScriptStruct AccelByteCustomization.AccelByteModelsMatchmakingSubGameMode
// Size: 0x20(Inherited: 0x0) 
struct FAccelByteModelsMatchmakingSubGameMode
{
	struct FString Name;  // 0x0(0x10)
	struct FAccelByteModelsMatchmakingSubGameModeAlliance Alliance;  // 0x10(0x10)

}; 
// ScriptStruct AccelByteCustomization.AccelByteModelsPlatformRewardItem
// Size: 0x30(Inherited: 0x0) 
struct FAccelByteModelsPlatformRewardItem
{
	struct FString ItemType;  // 0x0(0x10)
	struct FString ItemId;  // 0x10(0x10)
	struct FString ItemSku;  // 0x20(0x10)

}; 
// ScriptStruct AccelByteCustomization.AccelByteModelsActiveSectionsOptionalParams
// Size: 0x20(Inherited: 0x0) 
struct FAccelByteModelsActiveSectionsOptionalParams
{
	struct FString StoreId;  // 0x0(0x10)
	struct FDateTime Start;  // 0x10(0x8)
	struct FDateTime End;  // 0x18(0x8)

}; 
// ScriptStruct AccelByteCustomization.AccelByteLeaderboardUpdateEvent
// Size: 0x38(Inherited: 0x0) 
struct FAccelByteLeaderboardUpdateEvent
{
	struct TArray<struct FAccelByteModelsLeaderboardsUser> Leaders;  // 0x0(0x10)
	struct FString Category;  // 0x10(0x10)
	struct FString Platform;  // 0x20(0x10)
	uint8_t  Type;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)

}; 
// ScriptStruct AccelByteCustomization.AccelByteModelsClaimRewardRequest
// Size: 0x8(Inherited: 0x0) 
struct FAccelByteModelsClaimRewardRequest
{
	uint8_t  ChallengeType;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	int32_t ChallengeId;  // 0x4(0x4)

}; 
// ScriptStruct AccelByteCustomization.AccelByteModelsUserChallengeInfo
// Size: 0x50(Inherited: 0x0) 
struct FAccelByteModelsUserChallengeInfo
{
	struct TArray<struct FAccelByteModelsCurrentUserChallengeInfo> daily;  // 0x0(0x10)
	struct TArray<struct FAccelByteModelsCurrentUserChallengeInfo> weekly;  // 0x10(0x10)
	struct TArray<struct FAccelByteModelsCurrentUserChallengeInfo> Season;  // 0x20(0x10)
	struct TArray<struct FAccelByteModelsCurrentUserChallengeInfo> Weapon;  // 0x30(0x10)
	struct TArray<struct FAccelByteModelsCurrentUserChallengeInfo> Featured;  // 0x40(0x10)

}; 
// ScriptStruct AccelByteCustomization.AccelByteModelsLeaderboardsUser
// Size: 0x48(Inherited: 0x0) 
struct FAccelByteModelsLeaderboardsUser
{
	struct FAccelByteModelsCompositeUserId CompositeUserId;  // 0x0(0x30)
	int64_t Value;  // 0x30(0x8)
	struct FString DisplayName;  // 0x38(0x10)

}; 
// ScriptStruct AccelByteCustomization.AccelByteModelsCurrentUserChallengeInfo
// Size: 0x20(Inherited: 0x0) 
struct FAccelByteModelsCurrentUserChallengeInfo
{
	int32_t ChallengeId;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	int64_t currentValue;  // 0x8(0x8)
	struct FString ChallengeStatus;  // 0x10(0x10)

}; 
// ScriptStruct AccelByteCustomization.AccelByteModelsDailyPlayStreakEntry
// Size: 0x30(Inherited: 0x0) 
struct FAccelByteModelsDailyPlayStreakEntry
{
	struct FString UserId;  // 0x0(0x10)
	int32_t Value;  // 0x10(0x4)
	int32_t XpBoostPercentage;  // 0x14(0x4)
	int32_t PreviousValue;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	int64_t PreviousValueExpiresAtMs;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool HasPlayedToday : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)

}; 
// ScriptStruct AccelByteCustomization.AccelByteModelsMatchmakingSubGameModeAlliance
// Size: 0x10(Inherited: 0x0) 
struct FAccelByteModelsMatchmakingSubGameModeAlliance
{
	int32_t min_number;  // 0x0(0x4)
	int32_t max_number;  // 0x4(0x4)
	int32_t player_min_number;  // 0x8(0x4)
	int32_t player_max_number;  // 0xC(0x4)

}; 
// ScriptStruct AccelByteCustomization.AccelByteRaceCourseRecords
// Size: 0x70(Inherited: 0x0) 
struct FAccelByteRaceCourseRecords
{
	struct FString UserId;  // 0x0(0x10)
	struct FString Platform;  // 0x10(0x10)
	struct TMap<struct FString, struct FJsonObjectWrapper> BestTimes;  // 0x20(0x50)

}; 
// ScriptStruct AccelByteCustomization.AccelByteModelsUserDrop
// Size: 0x28(Inherited: 0x0) 
struct FAccelByteModelsUserDrop
{
	struct FString Namespace;  // 0x0(0x10)
	struct FString UserId;  // 0x10(0x10)
	int32_t Count;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)

}; 
// Function AccelByteCustomization.AccelByteBlueprintsCustomizationSettings.GetDailyCheckInServerUrl
// Size: 0x10(Inherited: 0x0) 
struct FGetDailyCheckInServerUrl
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// ScriptStruct AccelByteCustomization.AccelByteModelsChallengeStateMap
// Size: 0x80(Inherited: 0x0) 
struct FAccelByteModelsChallengeStateMap
{
	struct FAccelByteModelsChallengeState daily;  // 0x0(0x20)
	struct FAccelByteModelsChallengeState weekly;  // 0x20(0x20)
	struct FAccelByteModelsChallengeState Season;  // 0x40(0x20)
	struct FAccelByteModelsChallengeState Featured;  // 0x60(0x20)

}; 
// ScriptStruct AccelByteCustomization.AccelByteModelsChallengeState
// Size: 0x20(Inherited: 0x0) 
struct FAccelByteModelsChallengeState
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool IsActive : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	int32_t CurrentPhase;  // 0x4(0x4)
	int64_t ExpirationTimeMs;  // 0x8(0x8)
	struct TArray<int32_t> ChallengeIds;  // 0x10(0x10)

}; 
// ScriptStruct AccelByteCustomization.AccelByteModelsMatchmakingChannel
// Size: 0x100(Inherited: 0x0) 
struct FAccelByteModelsMatchmakingChannel
{
	struct FString Namespace;  // 0x0(0x10)
	struct FString Deployment;  // 0x10(0x10)
	struct FString Description;  // 0x20(0x10)
	struct FString GameMode;  // 0x30(0x10)
	struct FString Slug;  // 0x40(0x10)
	struct FString UpdatedAt;  // 0x50(0x10)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool Joinable : 1;  // 0x60(0x1)
	char pad_97_1 : 7;  // 0x61(0x1)
	bool use_sub_gamemode : 1;  // 0x61(0x1)
	char pad_98_1 : 7;  // 0x62(0x1)
	bool socialMatchmaking : 1;  // 0x62(0x1)
	char pad_99[1];  // 0x63(0x1)
	int32_t max_delay_ms;  // 0x64(0x4)
	int32_t FindMatchTimeoutSeconds;  // 0x68(0x4)
	int32_t SessionQueueTimeoutSeconds;  // 0x6C(0x4)
	struct FAccelByteModelsMatchmakingRuleSet RuleSet;  // 0x70(0x90)

}; 
// ScriptStruct AccelByteCustomization.AccelByteModelsMatchmakingRuleSet
// Size: 0x90(Inherited: 0x0) 
struct FAccelByteModelsMatchmakingRuleSet
{
	struct FAccelByteModelsMatchmakingAlliance Alliance;  // 0x0(0x10)
	struct FAccelByteModelsMatchmakingMatchOptions MatchOptions;  // 0x10(0x20)
	struct TArray<struct FAccelByteModelsMatchmakingMatchingRule> MatchingRules;  // 0x30(0x10)
	struct TMap<struct FString, struct FAccelByteModelsMatchmakingSubGameMode> sub_game_modes;  // 0x40(0x50)

}; 
// ScriptStruct AccelByteCustomization.AccelByteModelsXboxDLCSync
// Size: 0x10(Inherited: 0x0) 
struct FAccelByteModelsXboxDLCSync
{
	struct FString XstsToken;  // 0x0(0x10)

}; 
// ScriptStruct AccelByteCustomization.AccelByteModelsMatchmakingMatchingRule
// Size: 0x28(Inherited: 0x0) 
struct FAccelByteModelsMatchmakingMatchingRule
{
	struct FString Attribute;  // 0x0(0x10)
	struct FString Criteria;  // 0x10(0x10)
	int32_t Reference;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)

}; 
// ScriptStruct AccelByteCustomization.AccelByteModelsDailyPlayStreakResponse
// Size: 0x20(Inherited: 0x0) 
struct FAccelByteModelsDailyPlayStreakResponse
{
	int32_t Value;  // 0x0(0x4)
	int32_t XpBoostPercentage;  // 0x4(0x4)
	int32_t PreviousValue;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	int64_t PreviousValueExpiresAtMs;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool HasPlayedToday : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)

}; 
// ScriptStruct AccelByteCustomization.AccelByteModelsMatchmakingMatchOption
// Size: 0x18(Inherited: 0x0) 
struct FAccelByteModelsMatchmakingMatchOption
{
	struct FString Name;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool multi_value : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// ScriptStruct AccelByteCustomization.AccelByteModelsSectionInfo
// Size: 0xE8(Inherited: 0x0) 
struct FAccelByteModelsSectionInfo
{
	struct FString Title;  // 0x0(0x10)
	struct FString Description;  // 0x10(0x10)
	struct FString LongDescription;  // 0x20(0x10)
	struct FString SectionId;  // 0x30(0x10)
	struct FString Namespace;  // 0x40(0x10)
	struct FString ViewId;  // 0x50(0x10)
	struct FString Name;  // 0x60(0x10)
	struct FString Type;  // 0x70(0x10)
	char pad_128_1 : 7;  // 0x80(0x1)
	bool Active : 1;  // 0x80(0x1)
	char pad_129[3];  // 0x81(0x3)
	int32_t DisplayOrder;  // 0x84(0x4)
	struct FDateTime StartDate;  // 0x88(0x8)
	struct FDateTime EndDate;  // 0x90(0x8)
	struct TArray<struct FString> ItemIds;  // 0x98(0x10)
	struct TArray<struct FAccelByteModelsItemInfo> Items;  // 0xA8(0x10)
	struct FDateTime CreatedAt;  // 0xB8(0x8)
	struct FDateTime UpdatedAt;  // 0xC0(0x8)
	struct FJsonObjectWrapper LocalExt;  // 0xC8(0x20)

}; 
// ScriptStruct AccelByteCustomization.AccelByteModelsCustomGameSessionInfo
// Size: 0x58(Inherited: 0x0) 
struct FAccelByteModelsCustomGameSessionInfo
{
	struct FString FromEncodedCompositeId;  // 0x0(0x10)
	struct FString FromDisplayName;  // 0x10(0x10)
	struct FString SessionId;  // 0x20(0x10)
	struct FString Password;  // 0x30(0x10)
	struct FString ServerIp;  // 0x40(0x10)
	int32_t ServerPort;  // 0x50(0x4)
	char pad_84[4];  // 0x54(0x4)

}; 
// ScriptStruct AccelByteCustomization.AccelByteModelsUserCustomizations
// Size: 0xC0(Inherited: 0x0) 
struct FAccelByteModelsUserCustomizations
{
	struct FString Namespace;  // 0x0(0x10)
	struct FString UserId;  // 0x10(0x10)
	char pad_32[160];  // 0x20(0xA0)

}; 
// ScriptStruct AccelByteCustomization.AccelByteRaceCourseUpdate
// Size: 0x38(Inherited: 0x0) 
struct FAccelByteRaceCourseUpdate
{
	struct FString Platform;  // 0x0(0x10)
	struct FString PlatformUserId;  // 0x10(0x10)
	struct FString Map;  // 0x20(0x10)
	int32_t TimeMs;  // 0x30(0x4)
	uint8_t  Difficulty;  // 0x34(0x1)
	char pad_53[3];  // 0x35(0x3)

}; 
// ScriptStruct AccelByteCustomization.AccelByteModelsDailyCheckInResponse
// Size: 0x20(Inherited: 0x0) 
struct FAccelByteModelsDailyCheckInResponse
{
	int32_t DayOfWeek;  // 0x0(0x4)
	int32_t DaysClaimedCount;  // 0x4(0x4)
	int32_t DaysMissedCount;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	int64_t WeekStartsAtMs;  // 0x10(0x8)
	int64_t WeekExpiresAtMs;  // 0x18(0x8)

}; 
// ScriptStruct AccelByteCustomization.AccelByteModelsPlaylistContainer
// Size: 0x80(Inherited: 0x0) 
struct FAccelByteModelsPlaylistContainer
{
	struct FString Name;  // 0x0(0x10)
	struct FAccelBytePlaylistState State;  // 0x10(0x70)

}; 
// ScriptStruct AccelByteCustomization.AccelByteModelsDailyPlayStreakForPartyUpdate
// Size: 0x10(Inherited: 0x0) 
struct FAccelByteModelsDailyPlayStreakForPartyUpdate
{
	struct TArray<struct FAccelByteModelsDailyPlayStreakEntry> Data;  // 0x0(0x10)

}; 
// ScriptStruct AccelByteCustomization.AccelByteSyncAmazonEntitlementData
// Size: 0x18(Inherited: 0x0) 
struct FAccelByteSyncAmazonEntitlementData
{
	struct FString ItemSku;  // 0x0(0x10)
	uint8_t  iapOrderStatus;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// ScriptStruct AccelByteCustomization.AccelByteModelsGamePlaylist
// Size: 0x30(Inherited: 0x0) 
struct FAccelByteModelsGamePlaylist
{
	int32_t MinProgressionLevel;  // 0x0(0x4)
	int32_t XpBoostPercentage;  // 0x4(0x4)
	int64_t StartAtMs;  // 0x8(0x8)
	int64_t EndAtMs;  // 0x10(0x8)
	int32_t MinNumGameModesToSelect;  // 0x18(0x4)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool IsActive : 1;  // 0x1C(0x1)
	char pad_29_1 : 7;  // 0x1D(0x1)
	bool IsCrossplayRequired : 1;  // 0x1D(0x1)
	char pad_30[2];  // 0x1E(0x2)
	struct TArray<struct FAccelByteModelsGameMode> GameModes;  // 0x20(0x10)

}; 
// ScriptStruct AccelByteCustomization.AccelByteModelsGameMode
// Size: 0x30(Inherited: 0x0) 
struct FAccelByteModelsGameMode
{
	struct FString GameMode;  // 0x0(0x10)
	int32_t MaxPartySize;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct FString Type;  // 0x18(0x10)
	int32_t MinProgressionLevel;  // 0x28(0x4)
	char pad_44[4];  // 0x2C(0x4)

}; 
// ScriptStruct AccelByteCustomization.AccelByteModelsViewInfo
// Size: 0x98(Inherited: 0x0) 
struct FAccelByteModelsViewInfo
{
	struct FString Title;  // 0x0(0x10)
	struct FString Description;  // 0x10(0x10)
	struct FString LongDescription;  // 0x20(0x10)
	struct FString ViewId;  // 0x30(0x10)
	struct FString Namespace;  // 0x40(0x10)
	struct FString Name;  // 0x50(0x10)
	int32_t DisplayOrder;  // 0x60(0x4)
	char pad_100[4];  // 0x64(0x4)
	struct FDateTime CreatedAt;  // 0x68(0x8)
	struct FDateTime UpdatedAt;  // 0x70(0x8)
	struct FJsonObjectWrapper LocalExt;  // 0x78(0x20)

}; 
// ScriptStruct AccelByteCustomization.AccelByteGameModeConfig
// Size: 0x10(Inherited: 0x0) 
struct FAccelByteGameModeConfig
{
	struct FString GameMode;  // 0x0(0x10)

}; 
// ScriptStruct AccelByteCustomization.AccelByteModelsLeaderboardsFriend
// Size: 0x28(Inherited: 0x0) 
struct FAccelByteModelsLeaderboardsFriend
{
	struct FString UserId;  // 0x0(0x10)
	struct FString Platform;  // 0x10(0x10)
	int64_t Value;  // 0x20(0x8)

}; 
// ScriptStruct AccelByteCustomization.AccelByteModelsDropOpenResult
// Size: 0x20(Inherited: 0x0) 
struct FAccelByteModelsDropOpenResult
{
	struct TArray<struct FCustomizationId> Customizations;  // 0x0(0x10)
	int32_t DropCount;  // 0x10(0x4)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool Duplicate : 1;  // 0x14(0x1)
	char pad_21[3];  // 0x15(0x3)
	struct FAccelByteModelsDropDuplicateReward DuplicateReward;  // 0x18(0x8)

}; 
// ScriptStruct AccelByteCustomization.AccelByteModelsDropDuplicateReward
// Size: 0x8(Inherited: 0x0) 
struct FAccelByteModelsDropDuplicateReward
{
	int32_t Splitcoin;  // 0x0(0x4)
	int32_t XP;  // 0x4(0x4)

}; 
// ScriptStruct AccelByteCustomization.AccelByteModelsProfileSubmissionExtension
// Size: 0x70(Inherited: 0x0) 
struct FAccelByteModelsProfileSubmissionExtension
{
	struct FString FirstName;  // 0x0(0x10)
	struct FString LastName;  // 0x10(0x10)
	struct FString Language;  // 0x20(0x10)
	struct FString TimeZone;  // 0x30(0x10)
	struct FString avatarUrl;  // 0x40(0x10)
	struct FString AvatarSmallUrl;  // 0x50(0x10)
	struct FString AvatarLargeUrl;  // 0x60(0x10)

}; 
// ScriptStruct AccelByteCustomization.AccelByteModelsUserLimitedSection
// Size: 0xA0(Inherited: 0x0) 
struct FAccelByteModelsUserLimitedSection
{
	struct FString Title;  // 0x0(0x10)
	struct FString Description;  // 0x10(0x10)
	struct FString LongDescription;  // 0x20(0x10)
	struct FString SectionId;  // 0x30(0x10)
	struct FString Namespace;  // 0x40(0x10)
	struct FString Name;  // 0x50(0x10)
	struct FDateTime StartDate;  // 0x60(0x8)
	struct FDateTime EndDate;  // 0x68(0x8)
	struct TArray<struct FAccelByteModelsLimitedTimeItemInfo> Items;  // 0x70(0x10)
	struct FJsonObjectWrapper LocalExt;  // 0x80(0x20)

}; 
// ScriptStruct AccelByteCustomization.AccelByteModelsLimitedTimeItemInfo
// Size: 0x250(Inherited: 0x220) 
struct FAccelByteModelsLimitedTimeItemInfo : public FAccelByteModelsItemInfo
{
	struct FString PurchaseId;  // 0x220(0x10)
	struct FJsonObjectWrapper PlatformProductIdMap;  // 0x230(0x20)

}; 
// ScriptStruct AccelByteCustomization.AccelByteItemAvailability
// Size: 0x20(Inherited: 0x0) 
struct FAccelByteItemAvailability
{
	struct FString Availability;  // 0x0(0x10)
	struct FString AvailabilityInfo;  // 0x10(0x10)

}; 
// ScriptStruct AccelByteCustomization.AccelByteModelsUserLegacyProgressionNotificationInfo
// Size: 0xC(Inherited: 0x0) 
struct FAccelByteModelsUserLegacyProgressionNotificationInfo
{
	int32_t DeprecatedLevel;  // 0x0(0x4)
	int32_t ProTier;  // 0x4(0x4)
	int32_t ProLevel;  // 0x8(0x4)

}; 
// ScriptStruct AccelByteCustomization.AccelByteModelsUserProgression
// Size: 0x40(Inherited: 0x0) 
struct FAccelByteModelsUserProgression
{
	struct FString Namespace;  // 0x0(0x10)
	struct FString UserId;  // 0x10(0x10)
	int32_t Level;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)
	int64_t CurrentExp;  // 0x28(0x8)
	int64_t RequiredExp;  // 0x30(0x8)
	int32_t ProTier;  // 0x38(0x4)
	int32_t ProLevel;  // 0x3C(0x4)

}; 
// Function AccelByteCustomization.AccelByteBlueprintsCustomizationSettings.GetSocialServerUrl
// Size: 0x10(Inherited: 0x0) 
struct FGetSocialServerUrl
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// ScriptStruct AccelByteCustomization.AccelByteModelsPlacementGamesNeeded
// Size: 0xC(Inherited: 0x0) 
struct FAccelByteModelsPlacementGamesNeeded
{
	int32_t RANKED_TEAM_HARDCORE;  // 0x0(0x4)
	int32_t RANKED_TEAM_TAKEDOWN;  // 0x4(0x4)
	int32_t UNRANKED;  // 0x8(0x4)

}; 
// ScriptStruct AccelByteCustomization.AccelByteModelsRank
// Size: 0x20(Inherited: 0x0) 
struct FAccelByteModelsRank
{
	struct FString RankType;  // 0x0(0x10)
	int32_t RankXP;  // 0x10(0x4)
	int32_t RankLevel;  // 0x14(0x4)
	int32_t PlacementGamesPlayedCount;  // 0x18(0x4)
	int32_t PlacementGamesPlayedTotal;  // 0x1C(0x4)

}; 
// ScriptStruct AccelByteCustomization.AccelByteModelsForgeMapRequest
// Size: 0x60(Inherited: 0x0) 
struct FAccelByteModelsForgeMapRequest
{
	struct FString MapID;  // 0x0(0x10)
	struct FDateTime Timestamp;  // 0x10(0x8)
	struct FString SharingCode;  // 0x18(0x10)
	struct FString Name;  // 0x28(0x10)
	struct FText DisplayName;  // 0x38(0x18)
	struct TArray<struct FForgeInteractableSaveData> InteractablesSaveData;  // 0x50(0x10)

}; 
// ScriptStruct AccelByteCustomization.AccelByteModelsReferralPassConfig
// Size: 0x40(Inherited: 0x0) 
struct FAccelByteModelsReferralPassConfig
{
	struct FString Namespace;  // 0x0(0x10)
	struct FString SeasonName;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool HasData : 1;  // 0x20(0x1)
	char pad_33[3];  // 0x21(0x3)
	int32_t RefereeProgressionLevelThreshold;  // 0x24(0x4)
	int32_t MaxProgressionLevel;  // 0x28(0x4)
	int32_t MaxReferralPassLevel;  // 0x2C(0x4)
	struct TArray<struct FAccelByteModelsReferralPassConfigData> Data;  // 0x30(0x10)

}; 
// ScriptStruct AccelByteCustomization.AccelByteModelsBaseStats
// Size: 0x5C(Inherited: 0x0) 
struct FAccelByteModelsBaseStats
{
	int32_t GamesPlayed;  // 0x0(0x4)
	int32_t GamesWon;  // 0x4(0x4)
	int32_t Kills;  // 0x8(0x4)
	int32_t Assists;  // 0xC(0x4)
	int32_t Deaths;  // 0x10(0x4)
	int32_t Suicides;  // 0x14(0x4)
	int32_t Teabags;  // 0x18(0x4)
	int32_t MeleeKills;  // 0x1C(0x4)
	int32_t PortalKills;  // 0x20(0x4)
	int32_t KillsThruPortal;  // 0x24(0x4)
	int32_t DamageDealt;  // 0x28(0x4)
	int32_t DoubleKills;  // 0x2C(0x4)
	int32_t TripleKills;  // 0x30(0x4)
	int32_t QuadKills;  // 0x34(0x4)
	int32_t QuintKills;  // 0x38(0x4)
	int32_t SexKills;  // 0x3C(0x4)
	int32_t Killstreak1;  // 0x40(0x4)
	int32_t Killstreak2;  // 0x44(0x4)
	int32_t Killstreak3;  // 0x48(0x4)
	int32_t Killstreak4;  // 0x4C(0x4)
	int32_t Killstreak5;  // 0x50(0x4)
	int32_t Killstreak6;  // 0x54(0x4)
	int32_t EmoteCount;  // 0x58(0x4)

}; 
// ScriptStruct AccelByteCustomization.AccelByteModelsReferralPassConfigData
// Size: 0x18(Inherited: 0x0) 
struct FAccelByteModelsReferralPassConfigData
{
	int32_t ID;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct TArray<struct FAccelByteModelsPlatformReward> Rewards;  // 0x8(0x10)

}; 
// ScriptStruct AccelByteCustomization.AccelByteModelsReferee
// Size: 0x50(Inherited: 0x0) 
struct FAccelByteModelsReferee
{
	struct FString Namespace;  // 0x0(0x10)
	struct FString UserId;  // 0x10(0x10)
	struct FString SeasonNameReferred;  // 0x20(0x10)
	struct FString ReferrerUserId;  // 0x30(0x10)
	struct FString ReachedThresholdAt;  // 0x40(0x10)

}; 
// ScriptStruct AccelByteCustomization.AccelByteModelsReferralPass
// Size: 0x48(Inherited: 0x0) 
struct FAccelByteModelsReferralPass
{
	struct FString Namespace;  // 0x0(0x10)
	struct FString UserId;  // 0x10(0x10)
	struct FString SeasonName;  // 0x20(0x10)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CanBeReferred : 1;  // 0x30(0x1)
	char pad_49[3];  // 0x31(0x3)
	int32_t PassLevel;  // 0x34(0x4)
	struct FString ReferrerId;  // 0x38(0x10)

}; 
// ScriptStruct AccelByteCustomization.AccelByteModelsUserActiveSessionServer
// Size: 0x68(Inherited: 0x0) 
struct FAccelByteModelsUserActiveSessionServer
{
	struct FString Pod_name;  // 0x0(0x10)
	struct FString Ip;  // 0x10(0x10)
	int32_t Port;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)
	struct FJsonObjectWrapper Ports;  // 0x28(0x20)
	struct FString Status;  // 0x48(0x10)
	struct FString Region;  // 0x58(0x10)

}; 
// ScriptStruct AccelByteCustomization.AccelByteModelsReferrerRequest
// Size: 0x10(Inherited: 0x0) 
struct FAccelByteModelsReferrerRequest
{
	struct FString ReferrerId;  // 0x0(0x10)

}; 
// ScriptStruct AccelByteCustomization.AccelByteModelsReportUser
// Size: 0x50(Inherited: 0x0) 
struct FAccelByteModelsReportUser
{
	struct FString UserId;  // 0x0(0x10)
	struct FString Category;  // 0x10(0x10)
	struct FString Subcategory;  // 0x20(0x10)
	struct FString Description;  // 0x30(0x10)
	struct FString GameSessionId;  // 0x40(0x10)

}; 
// ScriptStruct AccelByteCustomization.AccelByteModelsSeasonReward
// Size: 0x8(Inherited: 0x0) 
struct FAccelByteModelsSeasonReward
{
	int32_t Level;  // 0x0(0x4)
	int32_t WinCount;  // 0x4(0x4)

}; 
// ScriptStruct AccelByteCustomization.AccelByteModelsSessionManagerRecentPlayerGetResult
// Size: 0x10(Inherited: 0x0) 
struct FAccelByteModelsSessionManagerRecentPlayerGetResult
{
	struct TArray<struct FAccelByteModelsSessionManagerRecentPlayerData> Data;  // 0x0(0x10)

}; 
// ScriptStruct AccelByteCustomization.AccelByteModelsSessionManagerRecentPlayerData
// Size: 0x20(Inherited: 0x0) 
struct FAccelByteModelsSessionManagerRecentPlayerData
{
	struct FString Other_id;  // 0x0(0x10)
	struct FString Other_display_name;  // 0x10(0x10)

}; 
// ScriptStruct AccelByteCustomization.AccelByteModelsTicketIdRemovedNotif
// Size: 0x18(Inherited: 0x0) 
struct FAccelByteModelsTicketIdRemovedNotif
{
	struct FString Ticket_id;  // 0x0(0x10)
	int32_t Error_Code;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)

}; 
// ScriptStruct AccelByteCustomization.AccelByteModelsMatchSession
// Size: 0xB8(Inherited: 0x0) 
struct FAccelByteModelsMatchSession
{
	struct FString Namespace;  // 0x0(0x10)
	struct FString Channel;  // 0x10(0x10)
	struct FString Game_mode;  // 0x20(0x10)
	struct FString Deployment;  // 0x30(0x10)
	struct FString State;  // 0x40(0x10)
	struct FString Status;  // 0x50(0x10)
	struct FString Server_name;  // 0x60(0x10)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool Joinable : 1;  // 0x70(0x1)
	char pad_113[7];  // 0x71(0x7)
	struct FString Match_id;  // 0x78(0x10)
	struct TArray<struct FAccelByteModelsMatchingAlly> Matching_allies;  // 0x88(0x10)
	struct FJsonObjectWrapper Party_attributes;  // 0x98(0x20)

}; 
// ScriptStruct AccelByteCustomization.AccelByteModelsUserActiveSession
// Size: 0x120(Inherited: 0x0) 
struct FAccelByteModelsUserActiveSession
{
	struct FAccelByteModelsUserActiveSessionServer Server;  // 0x0(0x68)
	struct FAccelByteModelsMatchSession Match_session;  // 0x68(0xB8)

}; 
// Function AccelByteCustomization.AccelByteBlueprintsCustomizationSettings.GetProgressionServerUrl
// Size: 0x10(Inherited: 0x0) 
struct FGetProgressionServerUrl
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// ScriptStruct AccelByteCustomization.AccelByteModelsRejectMatchRequest
// Size: 0x20(Inherited: 0x0) 
struct FAccelByteModelsRejectMatchRequest
{
	struct FString Match_id;  // 0x0(0x10)
	struct FString Ticket_id;  // 0x10(0x10)

}; 
// ScriptStruct AccelByteCustomization.AccelByteModelsStartMatchRequest
// Size: 0x10(Inherited: 0x0) 
struct FAccelByteModelsStartMatchRequest
{
	struct FString Playlist;  // 0x0(0x10)

}; 
// ScriptStruct AccelByteCustomization.AccelByteModelsCustomGameInviteRequest
// Size: 0x20(Inherited: 0x0) 
struct FAccelByteModelsCustomGameInviteRequest
{
	struct FString InviteeID;  // 0x0(0x10)
	struct FString Message;  // 0x10(0x10)

}; 
// ScriptStruct AccelByteCustomization.PartySessionConfigArgs
// Size: 0x60(Inherited: 0x0) 
struct FPartySessionConfigArgs
{
	struct FString PartySessionID;  // 0x0(0x10)
	struct FString PlatformSessionID;  // 0x10(0x10)
	struct FString Ip;  // 0x20(0x10)
	int32_t Port;  // 0x30(0x4)
	char pad_52[4];  // 0x34(0x4)
	struct FString EncryptionKey;  // 0x38(0x10)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool IsCrossplay : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)
	struct FString UserStatusId;  // 0x50(0x10)

}; 
// ScriptStruct AccelByteCustomization.AccelByteModelsNativePlatformSessionNotif
// Size: 0x40(Inherited: 0x0) 
struct FAccelByteModelsNativePlatformSessionNotif
{
	struct FString Platform_Name;  // 0x0(0x10)
	struct FString Platform_Session_Id;  // 0x10(0x10)
	struct FString Namespace;  // 0x20(0x10)
	struct FString Session_type;  // 0x30(0x10)

}; 
// ScriptStruct AccelByteCustomization.AccelByteModelsSessionManagerJoinSessionRequest
// Size: 0x48(Inherited: 0x0) 
struct FAccelByteModelsSessionManagerJoinSessionRequest
{
	struct FString User_id;  // 0x0(0x10)
	struct FString Platform;  // 0x10(0x10)
	struct FString Platform_id;  // 0x20(0x10)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool Is_spectator : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)
	struct FString Password;  // 0x38(0x10)

}; 
// ScriptStruct AccelByteCustomization.AccelByteModelsSessionManagerRegisterPlayerRequest
// Size: 0x38(Inherited: 0x0) 
struct FAccelByteModelsSessionManagerRegisterPlayerRequest
{
	struct FString User_id;  // 0x0(0x10)
	struct FString Platform;  // 0x10(0x10)
	struct FString Platform_id;  // 0x20(0x10)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool Is_spectator : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)

}; 
// ScriptStruct AccelByteCustomization.AccelByteModelsSessionManagerCreateCustomGameRequest
// Size: 0x118(Inherited: 0x0) 
struct FAccelByteModelsSessionManagerCreateCustomGameRequest
{
	struct FString Namespace;  // 0x0(0x10)
	struct FString Username;  // 0x10(0x10)
	struct FString User_id;  // 0x20(0x10)
	struct FString Platform;  // 0x30(0x10)
	struct FString Platform_id;  // 0x40(0x10)
	struct FString Game_version;  // 0x50(0x10)
	struct FString Session_type;  // 0x60(0x10)
	struct FAccelByteModelsSessionManagerGameSetting Game_session_setting;  // 0x70(0x68)
	struct FAccelByteModelsSessionManagerServerRequest Server;  // 0xD8(0x40)

}; 
// ScriptStruct AccelByteCustomization.AccelByteModelsSessionManagerServerRequest
// Size: 0x40(Inherited: 0x0) 
struct FAccelByteModelsSessionManagerServerRequest
{
	struct FString Server_name;  // 0x0(0x10)
	struct FString Client_version;  // 0x10(0x10)
	struct FString Region;  // 0x20(0x10)
	struct FString Deployment;  // 0x30(0x10)

}; 
// ScriptStruct AccelByteCustomization.AccelByteModelsSessionManagerGameSetting
// Size: 0x68(Inherited: 0x0) 
struct FAccelByteModelsSessionManagerGameSetting
{
	struct FString Mode;  // 0x0(0x10)
	struct FString Map_name;  // 0x10(0x10)
	int32_t Num_bot;  // 0x20(0x4)
	int32_t Max_player;  // 0x24(0x4)
	int32_t Current_player;  // 0x28(0x4)
	int32_t Max_internal_player;  // 0x2C(0x4)
	int32_t Current_internal_player;  // 0x30(0x4)
	char pad_52_1 : 7;  // 0x34(0x1)
	bool Allow_join_in_progress : 1;  // 0x34(0x1)
	char pad_53[3];  // 0x35(0x3)
	struct FString Password;  // 0x38(0x10)
	struct FJsonObjectWrapper Settings;  // 0x48(0x20)

}; 
// ScriptStruct AccelByteCustomization.AccelByteModelsDeleteForgeMapRequest
// Size: 0x10(Inherited: 0x0) 
struct FAccelByteModelsDeleteForgeMapRequest
{
	struct FString MapID;  // 0x0(0x10)

}; 
// Function AccelByteCustomization.AccelByteBlueprintsCustomizationSettings.SetBadgeServerUrl
// Size: 0x10(Inherited: 0x0) 
struct FSetBadgeServerUrl
{
	struct FString ServerUrl;  // 0x0(0x10)

}; 
// ScriptStruct AccelByteCustomization.AccelByteModelsUpdateForgeMapResponse
// Size: 0x20(Inherited: 0x0) 
struct FAccelByteModelsUpdateForgeMapResponse
{
	struct FString MapID;  // 0x0(0x10)
	struct FString SharingCode;  // 0x10(0x10)

}; 
// ScriptStruct AccelByteCustomization.AccelByteModelsUpdateForgeMapRequest
// Size: 0x60(Inherited: 0x0) 
struct FAccelByteModelsUpdateForgeMapRequest
{
	struct FAccelByteModelsForgeMapRequest Map;  // 0x0(0x60)

}; 
// ScriptStruct AccelByteCustomization.AccelByteModelsGetForgeMapResponse_Client
// Size: 0x78(Inherited: 0x0) 
struct FAccelByteModelsGetForgeMapResponse_Client
{
	struct FString MapID;  // 0x0(0x10)
	struct FForgeMap Map;  // 0x10(0x68)

}; 
// ScriptStruct AccelByteCustomization.AccelByteModelsGetForgeMapResponse
// Size: 0x60(Inherited: 0x0) 
struct FAccelByteModelsGetForgeMapResponse
{
	struct FAccelByteModelsForgeMapResponse Map;  // 0x0(0x60)

}; 
// ScriptStruct AccelByteCustomization.AccelByteModelsForgeMapResponse
// Size: 0x60(Inherited: 0x0) 
struct FAccelByteModelsForgeMapResponse
{
	struct FString MapID;  // 0x0(0x10)
	struct FDateTime Timestamp;  // 0x10(0x8)
	struct FString SharingCode;  // 0x18(0x10)
	struct FString Name;  // 0x28(0x10)
	struct FText DisplayName;  // 0x38(0x18)
	struct TArray<struct FForgeInteractableSaveData> InteractablesSaveData;  // 0x50(0x10)

}; 
// ScriptStruct AccelByteCustomization.AccelByteModelsGetForgeMapRequest
// Size: 0x10(Inherited: 0x0) 
struct FAccelByteModelsGetForgeMapRequest
{
	struct FString SharingCode;  // 0x0(0x10)

}; 
// ScriptStruct AccelByteCustomization.AccelByteModelsGetForgeMapsMetaDataRequest
// Size: 0x10(Inherited: 0x0) 
struct FAccelByteModelsGetForgeMapsMetaDataRequest
{
	struct FString SharingCodesCSV;  // 0x0(0x10)

}; 
// ScriptStruct AccelByteCustomization.AccelByteModelsGetForgeMapsResponse_Client
// Size: 0x50(Inherited: 0x0) 
struct FAccelByteModelsGetForgeMapsResponse_Client
{
	struct TMap<struct FString, struct FForgeMap> Maps;  // 0x0(0x50)

}; 
// ScriptStruct AccelByteCustomization.AccelByteModelsGetForgeMapsResponse
// Size: 0x10(Inherited: 0x0) 
struct FAccelByteModelsGetForgeMapsResponse
{
	struct TArray<struct FAccelByteModelsForgeMapMetaDataResponse> Map_MetaData;  // 0x0(0x10)

}; 
// ScriptStruct AccelByteCustomization.AccelByteModelsForgeMapMetaDataResponse
// Size: 0x50(Inherited: 0x0) 
struct FAccelByteModelsForgeMapMetaDataResponse
{
	struct FString MapID;  // 0x0(0x10)
	struct FDateTime Timestamp;  // 0x10(0x8)
	struct FString SharingCode;  // 0x18(0x10)
	struct FString Name;  // 0x28(0x10)
	struct FText DisplayName;  // 0x38(0x18)

}; 
// ScriptStruct AccelByteCustomization.AccelByteModelsStreamStatus
// Size: 0x40(Inherited: 0x0) 
struct FAccelByteModelsStreamStatus
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool IsLive : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FText ActionTitle;  // 0x8(0x18)
	struct FString ActionValue;  // 0x20(0x10)
	struct FString ImageUrl;  // 0x30(0x10)

}; 
// ScriptStruct AccelByteCustomization.AccelByteModelsPublicUserProfileExtension
// Size: 0x70(Inherited: 0x0) 
struct FAccelByteModelsPublicUserProfileExtension
{
	struct FString Namespace;  // 0x0(0x10)
	struct FString UserId;  // 0x10(0x10)
	struct FString TimeZone;  // 0x20(0x10)
	struct FString avatarUrl;  // 0x30(0x10)
	struct FString AvatarSmallUrl;  // 0x40(0x10)
	struct FString AvatarLargeUrl;  // 0x50(0x10)
	struct FString PublicId;  // 0x60(0x10)

}; 
// ScriptStruct AccelByteCustomization.AccelByteModelsPrivateUserProfileExtension
// Size: 0xC0(Inherited: 0x70) 
struct FAccelByteModelsPrivateUserProfileExtension : public FAccelByteModelsPublicUserProfileExtension
{
	struct FString FirstName;  // 0x70(0x10)
	struct FString LastName;  // 0x80(0x10)
	struct FString Language;  // 0x90(0x10)
	struct FString Status;  // 0xA0(0x10)
	struct FString ReferralId;  // 0xB0(0x10)

}; 
// ScriptStruct AccelByteCustomization.AccelByteModelsBulkUserStatsRequest
// Size: 0x10(Inherited: 0x0) 
struct FAccelByteModelsBulkUserStatsRequest
{
	struct TArray<struct FString> UserIds;  // 0x0(0x10)

}; 
// ScriptStruct AccelByteCustomization.AccelByteModelsUserStatsForPartyUpdate
// Size: 0x10(Inherited: 0x0) 
struct FAccelByteModelsUserStatsForPartyUpdate
{
	struct TArray<struct FAccelByteModelsUserStatsEntry> Data;  // 0x0(0x10)

}; 
// ScriptStruct AccelByteCustomization.AccelByteModelsUserStatsEntry
// Size: 0x70(Inherited: 0x0) 
struct FAccelByteModelsUserStatsEntry
{
	struct FString UserId;  // 0x0(0x10)
	struct FAccelByteModelsBaseStats UserStats;  // 0x10(0x5C)
	char pad_108[4];  // 0x6C(0x4)

}; 
// ScriptStruct AccelByteCustomization.AccelByteModelsSeasonStats
// Size: 0xD8(Inherited: 0x0) 
struct FAccelByteModelsSeasonStats
{
	struct FString SeasonName;  // 0x0(0x10)
	struct FAccelByteModelsTotalStats overall;  // 0x10(0x5C)
	struct FAccelByteModelsBaseStats TotalStats;  // 0x6C(0x5C)
	struct TArray<struct FAccelByteModelsPlaylistStats> Playlists;  // 0xC8(0x10)

}; 
// ScriptStruct AccelByteCustomization.AccelByteModelsPlaylistStats
// Size: 0x70(Inherited: 0x0) 
struct FAccelByteModelsPlaylistStats
{
	struct FString PlaylistType;  // 0x0(0x10)
	struct FAccelByteModelsBaseStats PlaylistStats;  // 0x10(0x5C)
	char pad_108[4];  // 0x6C(0x4)

}; 
// ScriptStruct AccelByteCustomization.AccelByteModelsTotalStats
// Size: 0x5C(Inherited: 0x0) 
struct FAccelByteModelsTotalStats
{
	struct FAccelByteModelsBaseStats TotalStats;  // 0x0(0x5C)

}; 
// ScriptStruct AccelByteCustomization.AccelByteVivoxTokenResponse
// Size: 0x20(Inherited: 0x0) 
struct FAccelByteVivoxTokenResponse
{
	struct FString AccessToken;  // 0x0(0x10)
	struct FString Uri;  // 0x10(0x10)

}; 
// ScriptStruct AccelByteCustomization.AccelByteVivoxTokenRequest
// Size: 0x40(Inherited: 0x0) 
struct FAccelByteVivoxTokenRequest
{
	struct FString Type;  // 0x0(0x10)
	struct FString Username;  // 0x10(0x10)
	struct FString ChannelId;  // 0x20(0x10)
	struct FString ChannelType;  // 0x30(0x10)

}; 
// Function AccelByteCustomization.AccelByteBlueprintsCustomizationSettings.GetBasicServerUrl
// Size: 0x10(Inherited: 0x0) 
struct FGetBasicServerUrl
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// Function AccelByteCustomization.AccelByteBlueprintsCustomizationSettings.SetBasicServerUrl
// Size: 0x10(Inherited: 0x0) 
struct FSetBasicServerUrl
{
	struct FString BasicServerUrl;  // 0x0(0x10)

}; 
// Function AccelByteCustomization.AccelByteBlueprintsCustomizationSettings.SetProgressionServerUrl
// Size: 0x10(Inherited: 0x0) 
struct FSetProgressionServerUrl
{
	struct FString ProgressionServerUrl;  // 0x0(0x10)

}; 
// Function AccelByteCustomization.AccelByteBlueprintsCustomizationSettings.GetAchievementServerUrl
// Size: 0x10(Inherited: 0x0) 
struct FGetAchievementServerUrl
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// Function AccelByteCustomization.AccelByteBlueprintsCustomizationSettings.GetBadgeServerUrl
// Size: 0x10(Inherited: 0x0) 
struct FGetBadgeServerUrl
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// Function AccelByteCustomization.AccelByteBlueprintsCustomizationSettings.SetDailyPlayStreakServerUrl
// Size: 0x10(Inherited: 0x0) 
struct FSetDailyPlayStreakServerUrl
{
	struct FString DailyPlayStreakServerUrl;  // 0x0(0x10)

}; 
// Function AccelByteCustomization.AccelByteBlueprintsCustomizationSettings.GetChallengeServerUrl
// Size: 0x10(Inherited: 0x0) 
struct FGetChallengeServerUrl
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// Function AccelByteCustomization.AccelByteBlueprintsCustomizationSettings.GetDropServerUrl
// Size: 0x10(Inherited: 0x0) 
struct FGetDropServerUrl
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// Function AccelByteCustomization.AccelByteBlueprintsCustomizationSettings.GetGamePlaylistServerUrl
// Size: 0x10(Inherited: 0x0) 
struct FGetGamePlaylistServerUrl
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// Function AccelByteCustomization.AccelByteBlueprintsCustomizationSettings.GetLockerServerUrl
// Size: 0x10(Inherited: 0x0) 
struct FGetLockerServerUrl
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// Function AccelByteCustomization.AccelByteBlueprintsCustomizationSettings.GetMatchmakingServerUrl
// Size: 0x10(Inherited: 0x0) 
struct FGetMatchmakingServerUrl
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// Function AccelByteCustomization.AccelByteBlueprintsCustomizationSettings.GetPlatformShopServerUrl
// Size: 0x10(Inherited: 0x0) 
struct FGetPlatformShopServerUrl
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// Function AccelByteCustomization.AccelByteBlueprintsCustomizationSettings.GetReferralCodeServerUrl
// Size: 0x10(Inherited: 0x0) 
struct FGetReferralCodeServerUrl
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// Function AccelByteCustomization.AccelByteBlueprintsCustomizationSettings.GetReportServerUrl
// Size: 0x10(Inherited: 0x0) 
struct FGetReportServerUrl
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// Function AccelByteCustomization.AccelByteBlueprintsCustomizationSettings.GetSplitgateServerUrl
// Size: 0x10(Inherited: 0x0) 
struct FGetSplitgateServerUrl
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// Function AccelByteCustomization.AccelByteBlueprintsCustomizationSettings.GetUGCServerUrl
// Size: 0x10(Inherited: 0x0) 
struct FGetUGCServerUrl
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// Function AccelByteCustomization.AccelByteBlueprintsCustomizationSettings.SetAchievementServerUrl
// Size: 0x10(Inherited: 0x0) 
struct FSetAchievementServerUrl
{
	struct FString AchievementServerUrl;  // 0x0(0x10)

}; 
// Function AccelByteCustomization.AccelByteBlueprintsCustomizationSettings.SetDailyCheckInServerUrl
// Size: 0x10(Inherited: 0x0) 
struct FSetDailyCheckInServerUrl
{
	struct FString SplitgateServerUrl;  // 0x0(0x10)

}; 
// Function AccelByteCustomization.AccelByteBlueprintsCustomizationSettings.SetDropServerUrl
// Size: 0x10(Inherited: 0x0) 
struct FSetDropServerUrl
{
	struct FString DropServerUrl;  // 0x0(0x10)

}; 
// Function AccelByteCustomization.AccelByteBlueprintsCustomizationSettings.SetGamePlaylistServerUrl
// Size: 0x10(Inherited: 0x0) 
struct FSetGamePlaylistServerUrl
{
	struct FString ServerUrl;  // 0x0(0x10)

}; 
// Function AccelByteCustomization.AccelByteBlueprintsCustomizationSettings.SetLockerServerUrl
// Size: 0x10(Inherited: 0x0) 
struct FSetLockerServerUrl
{
	struct FString LockerServerUrl;  // 0x0(0x10)

}; 
// Function AccelByteCustomization.AccelByteBlueprintsCustomizationSettings.SetMatchmakingServerUrl
// Size: 0x10(Inherited: 0x0) 
struct FSetMatchmakingServerUrl
{
	struct FString MatchmakingServerUrl;  // 0x0(0x10)

}; 
// Function AccelByteCustomization.AccelByteBlueprintsCustomizationSettings.SetPlatformShopServerUrl
// Size: 0x10(Inherited: 0x0) 
struct FSetPlatformShopServerUrl
{
	struct FString PlatformShopServerUrl;  // 0x0(0x10)

}; 
// Function AccelByteCustomization.AccelByteBlueprintsCustomizationSettings.SetReferralCodeServerUrl
// Size: 0x10(Inherited: 0x0) 
struct FSetReferralCodeServerUrl
{
	struct FString ServerUrl;  // 0x0(0x10)

}; 
// Function AccelByteCustomization.AccelByteBlueprintsCustomizationSettings.SetReportServerUrl
// Size: 0x10(Inherited: 0x0) 
struct FSetReportServerUrl
{
	struct FString ReportServerUrl;  // 0x0(0x10)

}; 
// Function AccelByteCustomization.AccelByteBlueprintsCustomizationSettings.SetSocialServerUrl
// Size: 0x10(Inherited: 0x0) 
struct FSetSocialServerUrl
{
	struct FString InSocialServerUrl;  // 0x0(0x10)

}; 
// Function AccelByteCustomization.AccelByteBlueprintsCustomizationSettings.SetSplitgateServerUrl
// Size: 0x10(Inherited: 0x0) 
struct FSetSplitgateServerUrl
{
	struct FString InSplitgateServerUrl;  // 0x0(0x10)

}; 
// Function AccelByteCustomization.AccelByteBlueprintsCustomizationSettings.SetUGCServerUrl
// Size: 0x10(Inherited: 0x0) 
struct FSetUGCServerUrl
{
	struct FString ServerUrl;  // 0x0(0x10)

}; 
