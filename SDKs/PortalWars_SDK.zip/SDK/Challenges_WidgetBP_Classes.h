#pragma once 
#include <Challenges_WidgetBP_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass Challenges_WidgetBP.Challenges_WidgetBP_C
// Size: 0x968(Inherited: 0x8B8) 
struct UChallenges_WidgetBP_C : public UPortalWarsChallengesWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x8B8(0x8)
	struct UCareerProgress_WidgetBP_C* CareerProgress_WidgetBP;  // 0x8C0(0x8)
	struct UChallengeButtonGeneric_C* ChallengeButtonGeneric;  // 0x8C8(0x8)
	struct UChallengeButtonGeneric_C* ChallengeButtonGeneric_2;  // 0x8D0(0x8)
	struct UChallengeButtonGeneric_C* ChallengeButtonGeneric_3;  // 0x8D8(0x8)
	struct UChallengeButtonWeapon_WidgetBP_C* ChallengeButtonWeapon_WidgetBP;  // 0x8E0(0x8)
	struct UChallengeButtonWeapon_WidgetBP_C* ChallengeButtonWeapon_WidgetBP_2;  // 0x8E8(0x8)
	struct UChallengeButtonWeapon_WidgetBP_C* ChallengeButtonWeapon_WidgetBP_3;  // 0x8F0(0x8)
	struct UChallengeButtonWeapon_WidgetBP_C* ChallengeButtonWeapon_WidgetBP_4;  // 0x8F8(0x8)
	struct UChallengeButtonWeapon_WidgetBP_C* ChallengeButtonWeapon_WidgetBP_5;  // 0x900(0x8)
	struct UChallengeButtonWeapon_WidgetBP_C* ChallengeButtonWeapon_WidgetBP_6;  // 0x908(0x8)
	struct UChallengeButtonWeapon_WidgetBP_C* ChallengeButtonWeapon_WidgetBP_7;  // 0x910(0x8)
	struct UChallengeButtonWeapon_WidgetBP_C* ChallengeButtonWeapon_WidgetBP_8;  // 0x918(0x8)
	struct UChallengeButtonWeapon_WidgetBP_C* ChallengeButtonWeapon_WidgetBP_9;  // 0x920(0x8)
	struct UChallengeButtonWeapon_WidgetBP_C* ChallengeButtonWeapon_WidgetBP_11;  // 0x928(0x8)
	struct UChallengeButtonWeapon_WidgetBP_C* ChallengeButtonWeapon_WidgetBP_12;  // 0x930(0x8)
	struct UWrapBox* ChallengesWrapBox;  // 0x938(0x8)
	struct UMenuBackground_C* MenuBackground;  // 0x940(0x8)
	struct USafeZone* SafeZone_1;  // 0x948(0x8)
	struct UWBP_Footer_C* WBP_Footer;  // 0x950(0x8)
	struct UWBP_PageHeader_C* WBP_PageHeader;  // 0x958(0x8)
	struct UWrapBox* WeaponWrapBox;  // 0x960(0x8)

	void PreConstruct(bool IsDesignTime); // Function Challenges_WidgetBP.Challenges_WidgetBP_C.PreConstruct
	void Construct(); // Function Challenges_WidgetBP.Challenges_WidgetBP_C.Construct
	void ExecuteUbergraph_Challenges_WidgetBP(int32_t EntryPoint); // Function Challenges_WidgetBP.Challenges_WidgetBP_C.ExecuteUbergraph_Challenges_WidgetBP
}; 



