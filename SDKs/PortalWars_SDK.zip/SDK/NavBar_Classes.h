#pragma once 
#include <NavBar_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass NavBar.NavBar_C
// Size: 0x668(Inherited: 0x660) 
struct UNavBar_C : public UPortalWarsNavBarWidget
{
	struct UImage* BG;  // 0x660(0x8)

}; 



