#pragma once 
#include "SDK.h" 
 
 
// Function Leaderboard_WidgetBP.Leaderboard_WidgetBP_C.ExecuteUbergraph_Leaderboard_WidgetBP
// Size: 0x5(Inherited: 0x0) 
struct FExecuteUbergraph_Leaderboard_WidgetBP
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool K2Node_Event_IsDesignTime : 1;  // 0x4(0x1)

}; 
// Function Leaderboard_WidgetBP.Leaderboard_WidgetBP_C.PreConstruct
// Size: 0x1(Inherited: 0x1) 
struct FPreConstruct : public FPreConstruct
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool IsDesignTime : 1;  // 0x0(0x1)

}; 
