#pragma once 
#include "SDK.h" 
 
 
// Function ChallengeEntryWeaponFeatured_WidgetBP.ChallengeEntryWeaponFeatured_WidgetBP_C.ExecuteUbergraph_ChallengeEntryWeaponFeatured_WidgetBP
// Size: 0x4(Inherited: 0x0) 
struct FExecuteUbergraph_ChallengeEntryWeaponFeatured_WidgetBP
{
	int32_t EntryPoint;  // 0x0(0x4)

}; 
