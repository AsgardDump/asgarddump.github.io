#pragma once 
#include "SDK.h" 
 
 
// Function BP_RewardRoomPortal.BP_RewardRoomPortal_C.ExecuteUbergraph_BP_RewardRoomPortal
// Size: 0x18(Inherited: 0x0) 
struct FExecuteUbergraph_BP_RewardRoomPortal
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	float CallFunc_FMax_ReturnValue;  // 0x8(0x4)
	float CallFunc_FMax_ReturnValue_2;  // 0xC(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x10(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue_2;  // 0x14(0x4)

}; 
