#pragma once 
#include <ChallengeEntryWeapon_WidgetBP_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass ChallengeEntryWeapon_WidgetBP.ChallengeEntryWeapon_WidgetBP_C
// Size: 0xD68(Inherited: 0xD28) 
struct UChallengeEntryWeapon_WidgetBP_C : public UPortalWarsChallengeEntryWidget
{
	struct UImage* ChallengeBG;  // 0xD28(0x8)
	struct UImage* ChallengeCompletedBG;  // 0xD30(0x8)
	struct UImage* ChallengePremiumBG;  // 0xD38(0x8)
	struct UImage* Image_94;  // 0xD40(0x8)
	struct UImage* Image_116;  // 0xD48(0x8)
	struct UImage* Image_287;  // 0xD50(0x8)
	struct UReward_WidgetBP_C* Reward_WidgetBP;  // 0xD58(0x8)
	struct UReward_WidgetBP_C* Reward_WidgetBP_2;  // 0xD60(0x8)

}; 



