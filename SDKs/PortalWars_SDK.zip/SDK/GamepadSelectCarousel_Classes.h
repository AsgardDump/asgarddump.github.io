#pragma once 
#include <GamepadSelectCarousel_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass GamepadSelectCarousel.GamepadSelectCarousel_C
// Size: 0x648(Inherited: 0x640) 
struct UGamepadSelectCarousel_C : public UPortalWarsTextCarouselWidget
{
	struct UImage* Image_101;  // 0x640(0x8)

}; 



