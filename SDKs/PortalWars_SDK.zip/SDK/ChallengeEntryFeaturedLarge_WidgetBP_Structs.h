#pragma once 
#include "SDK.h" 
 
 
// Function ChallengeEntryFeaturedLarge_WidgetBP.ChallengeEntryFeaturedLarge_WidgetBP_C.ExecuteUbergraph_ChallengeEntryFeaturedLarge_WidgetBP
// Size: 0x59(Inherited: 0x0) 
struct FExecuteUbergraph_ChallengeEntryFeaturedLarge_WidgetBP
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FSlateColor K2Node_MakeStruct_SlateColor;  // 0x8(0x28)
	struct FSlateColor K2Node_MakeStruct_SlateColor_2;  // 0x30(0x28)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool CallFunc_IsCompleted_ReturnValue : 1;  // 0x58(0x1)

}; 
