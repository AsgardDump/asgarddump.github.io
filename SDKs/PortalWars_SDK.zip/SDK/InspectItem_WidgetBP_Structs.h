#pragma once 
#include "SDK.h" 
 
 
// Function InspectItem_WidgetBP.InspectItem_WidgetBP_C.ExecuteUbergraph_InspectItem_WidgetBP
// Size: 0x5(Inherited: 0x0) 
struct FExecuteUbergraph_InspectItem_WidgetBP
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool K2Node_Event_IsDesignTime : 1;  // 0x4(0x1)

}; 
// Function InspectItem_WidgetBP.InspectItem_WidgetBP_C.PreConstruct
// Size: 0x1(Inherited: 0x1) 
struct FPreConstruct : public FPreConstruct
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool IsDesignTime : 1;  // 0x0(0x1)

}; 
// Function InspectItem_WidgetBP.InspectItem_WidgetBP_C.UpdateTransform
// Size: 0x38(Inherited: 0x0) 
struct FUpdateTransform
{
	struct FVector2D Scale;  // 0x0(0x8)
	struct FVector2D Translation;  // 0x8(0x8)
	float Transform Angle;  // 0x10(0x4)
	struct FVector2D PlayerCardTranslation;  // 0x14(0x8)
	struct FWidgetTransform K2Node_MakeStruct_WidgetTransform;  // 0x1C(0x1C)

}; 
