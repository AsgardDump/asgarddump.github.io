#pragma once 
#include "SDK.h" 
 
 
// Function DailyPlayStreak_WidgetBP.DailyPlayStreak_WidgetBP_C.ExecuteUbergraph_DailyPlayStreak_WidgetBP
// Size: 0x4(Inherited: 0x0) 
struct FExecuteUbergraph_DailyPlayStreak_WidgetBP
{
	int32_t EntryPoint;  // 0x0(0x4)

}; 
