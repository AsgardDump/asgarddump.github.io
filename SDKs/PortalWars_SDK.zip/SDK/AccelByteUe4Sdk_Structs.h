#pragma once 
#include "SDK.h" 
 
 
// DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsAchievement.GetAchievementSuccess__DelegateSignature
// Size: 0x130(Inherited: 0x0) 
struct FGetAchievementSuccess__DelegateSignature
{
	struct FAccelByteModelsMultiLanguageAchievement Result;  // 0x0(0x130)

}; 
// ScriptStruct AccelByteUe4Sdk.ResetPasswordRequest
// Size: 0x30(Inherited: 0x0) 
struct FResetPasswordRequest
{
	struct FString Code;  // 0x0(0x10)
	struct FString EmailAddress;  // 0x10(0x10)
	struct FString NewPassword;  // 0x20(0x10)

}; 
// DelegateFunction AccelByteUe4Sdk.DErrorHandler__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FDErrorHandler__DelegateSignature
{
	int32_t ErrorCode;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FString ErrorMessage;  // 0x8(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsRematchmakingNotice
// Size: 0x4(Inherited: 0x0) 
struct FAccelByteModelsRematchmakingNotice
{
	int32_t BanDuration;  // 0x0(0x4)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsSettings.GetGameProfileServerUrl
// Size: 0x10(Inherited: 0x0) 
struct FGetGameProfileServerUrl
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsGameProfile.GetGameProfileAttribute
// Size: 0x40(Inherited: 0x0) 
struct FGetGameProfileAttribute
{
	struct FString profileId;  // 0x0(0x10)
	struct FString AttributeName;  // 0x10(0x10)
	struct FDelegate OnSuccess;  // 0x20(0x10)
	struct FDelegate OnError;  // 0x30(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.RegisterRequestv3
// Size: 0x80(Inherited: 0x0) 
struct FRegisterRequestv3
{
	struct TArray<struct FAcceptedPolicies> AcceptedPolicies;  // 0x0(0x10)
	struct FString AuthType;  // 0x10(0x10)
	struct FString DisplayName;  // 0x20(0x10)
	struct FString EmailAddress;  // 0x30(0x10)
	struct FString Username;  // 0x40(0x10)
	struct FString Password;  // 0x50(0x10)
	struct FString Country;  // 0x60(0x10)
	struct FString DateOfBirth;  // 0x70(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsPaginatedPublicAchievement
// Size: 0x50(Inherited: 0x0) 
struct FAccelByteModelsPaginatedPublicAchievement
{
	struct TArray<struct FAccelByteModelsPublicAchievement> Data;  // 0x0(0x10)
	struct FAccelByteModelsPaging Paging;  // 0x10(0x40)

}; 
// DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsCloudStorage.CreateSlotsSuccess__DelegateSignature
// Size: 0xD0(Inherited: 0x0) 
struct FCreateSlotsSuccess__DelegateSignature
{
	struct FAccelByteModelsSlot Result;  // 0x0(0xD0)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsAchievement.GetAchievement
// Size: 0x30(Inherited: 0x0) 
struct FGetAchievement
{
	struct FString AchievementCode;  // 0x0(0x10)
	struct FDelegate OnSuccess;  // 0x10(0x10)
	struct FDelegate OnError;  // 0x20(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsMatchmakingBannedUsersContainer
// Size: 0x10(Inherited: 0x0) 
struct FAccelByteModelsMatchmakingBannedUsersContainer
{
	struct TArray<struct FAccelByteModelsMatchmakingBannedUser> Data;  // 0x0(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsEntitlementPagingSlicedResult
// Size: 0x50(Inherited: 0x0) 
struct FAccelByteModelsEntitlementPagingSlicedResult
{
	struct TArray<struct FAccelByteModelsEntitlementInfo> Data;  // 0x0(0x10)
	struct FAccelByteModelsPaging Paging;  // 0x10(0x40)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsBulkFriendsRequest
// Size: 0x10(Inherited: 0x0) 
struct FAccelByteModelsBulkFriendsRequest
{
	struct TArray<struct FString> FriendIds;  // 0x0(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsUserProfileInfo
// Size: 0xB0(Inherited: 0x0) 
struct FAccelByteModelsUserProfileInfo
{
	struct FString UserId;  // 0x0(0x10)
	struct FString Namespace;  // 0x10(0x10)
	struct FString FirstName;  // 0x20(0x10)
	struct FString LastName;  // 0x30(0x10)
	struct FString AvatarSmallUrl;  // 0x40(0x10)
	struct FString avatarUrl;  // 0x50(0x10)
	struct FString AvatarLargeUrl;  // 0x60(0x10)
	struct FString Status;  // 0x70(0x10)
	struct FString Language;  // 0x80(0x10)
	struct FString TimeZone;  // 0x90(0x10)
	struct FString DateOfBirth;  // 0xA0(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsMultiLanguageAchievement
// Size: 0x130(Inherited: 0x0) 
struct FAccelByteModelsMultiLanguageAchievement
{
	struct FString AchievementCode;  // 0x0(0x10)
	struct FString Namespace;  // 0x10(0x10)
	struct TMap<struct FString, struct FString> Name;  // 0x20(0x50)
	struct TMap<struct FString, struct FString> Description;  // 0x70(0x50)
	struct TArray<struct FAccelByteModelsAchievementIcon> LockedIcons;  // 0xC0(0x10)
	struct TArray<struct FAccelByteModelsAchievementIcon> UnlockedIcons;  // 0xD0(0x10)
	char pad_224_1 : 7;  // 0xE0(0x1)
	bool Hidden : 1;  // 0xE0(0x1)
	char pad_225[3];  // 0xE1(0x3)
	int32_t ListOrder;  // 0xE4(0x4)
	struct TArray<struct FString> Tags;  // 0xE8(0x10)
	char pad_248_1 : 7;  // 0xF8(0x1)
	bool Incremental : 1;  // 0xF8(0x1)
	char pad_249[3];  // 0xF9(0x3)
	float GoalValue;  // 0xFC(0x4)
	struct FString StatCode;  // 0x100(0x10)
	struct FString CreatedAt;  // 0x110(0x10)
	struct FString UpdatedAt;  // 0x120(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsPartyData
// Size: 0x78(Inherited: 0x0) 
struct FAccelByteModelsPartyData
{
	struct FJsonObjectWrapper Custom_attribute;  // 0x0(0x20)
	struct TArray<struct FString> Invitees;  // 0x20(0x10)
	struct FString Leader;  // 0x30(0x10)
	struct TArray<struct FString> Members;  // 0x40(0x10)
	struct FString Namespace;  // 0x50(0x10)
	struct FString PartyId;  // 0x60(0x10)
	char pad_112[8];  // 0x70(0x8)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsAchievement.QueryAchievements
// Size: 0x40(Inherited: 0x0) 
struct FQueryAchievements
{
	struct FString Language;  // 0x0(0x10)
	uint8_t  SortBy;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)
	struct FDelegate OnSuccess;  // 0x14(0x10)
	struct FDelegate OnError;  // 0x24(0x10)
	int32_t Offset;  // 0x34(0x4)
	int32_t Limit;  // 0x38(0x4)
	char pad_60[4];  // 0x3C(0x4)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsPaginatedRecordsKey
// Size: 0x50(Inherited: 0x0) 
struct FAccelByteModelsPaginatedRecordsKey
{
	struct TArray<struct FString> Data;  // 0x0(0x10)
	struct FAccelByteModelsPaging Paging;  // 0x10(0x40)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsBulkUserStatItemInc
// Size: 0x28(Inherited: 0x0) 
struct FAccelByteModelsBulkUserStatItemInc
{
	float inc;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FString UserId;  // 0x8(0x10)
	struct FString StatCode;  // 0x18(0x10)

}; 
// DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsWallet.BlueprintErrorHandler__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FBlueprintErrorHandler__DelegateSignature
{
	int32_t ErrorCode;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FString ErrorMessage;  // 0x8(0x10)

}; 
// DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsCloudStorage.GetSlotSuccess__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FGetSlotSuccess__DelegateSignature
{
	struct TArray<char> Result;  // 0x0(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsReportingSubmitData
// Size: 0xA8(Inherited: 0x0) 
struct FAccelByteModelsReportingSubmitData
{
	struct TMap<struct FString, struct FString> AdditionalInfo;  // 0x0(0x50)
	uint8_t  Category;  // 0x50(0x1)
	char pad_81[7];  // 0x51(0x7)
	struct FString Comment;  // 0x58(0x10)
	struct FString ObjectID;  // 0x68(0x10)
	struct FString ObjectType;  // 0x78(0x10)
	struct FString Reason;  // 0x88(0x10)
	struct FString UserId;  // 0x98(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsUGCTagResponse
// Size: 0x30(Inherited: 0x0) 
struct FAccelByteModelsUGCTagResponse
{
	struct FString ID;  // 0x0(0x10)
	struct FString Namespace;  // 0x10(0x10)
	struct FString Tag;  // 0x20(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsTurnServerList
// Size: 0x10(Inherited: 0x0) 
struct FAccelByteModelsTurnServerList
{
	struct TArray<struct FAccelByteModelsTurnServer> Servers;  // 0x0(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsCategory.GetRootCategories
// Size: 0x30(Inherited: 0x0) 
struct FGetRootCategories
{
	struct FString Language;  // 0x0(0x10)
	struct FDelegate OnSuccess;  // 0x10(0x10)
	struct FDelegate OnError;  // 0x20(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsAchievementIcon
// Size: 0x20(Inherited: 0x0) 
struct FAccelByteModelsAchievementIcon
{
	struct FString URL;  // 0x0(0x10)
	struct FString Slug;  // 0x10(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsReward.GetRewardByRewardId
// Size: 0x30(Inherited: 0x0) 
struct FGetRewardByRewardId
{
	struct FString RewardId;  // 0x0(0x10)
	struct FDelegate OnSuccess;  // 0x10(0x10)
	struct FDelegate OnError;  // 0x20(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsUserAchievement
// Size: 0x88(Inherited: 0x0) 
struct FAccelByteModelsUserAchievement
{
	struct FString ID;  // 0x0(0x10)
	struct TMap<struct FString, struct FString> Name;  // 0x10(0x50)
	struct FString AchievementCode;  // 0x60(0x10)
	struct FString AchievedAt;  // 0x70(0x10)
	float LatestValue;  // 0x80(0x4)
	int32_t Status;  // 0x84(0x4)

}; 
// DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsAchievement.QueryAchievementsSuccess__DelegateSignature
// Size: 0x50(Inherited: 0x0) 
struct FQueryAchievementsSuccess__DelegateSignature
{
	struct FAccelByteModelsPaginatedPublicAchievement Result;  // 0x0(0x50)

}; 
// DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsCategory.GetChildCategoriesSuccess__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FGetChildCategoriesSuccess__DelegateSignature
{
	struct TArray<struct FAccelByteModelsCategoryInfo> Result;  // 0x0(0x10)

}; 
// Function AccelByteUe4Sdk.BPUser.Upgrade
// Size: 0x40(Inherited: 0x0) 
struct FUpgrade
{
	struct FString Username;  // 0x0(0x10)
	struct FString Password;  // 0x10(0x10)
	struct FDelegate OnSuccess;  // 0x20(0x10)
	struct FDelegate OnError;  // 0x30(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsPaging
// Size: 0x40(Inherited: 0x0) 
struct FAccelByteModelsPaging
{
	struct FString First;  // 0x0(0x10)
	struct FString Last;  // 0x10(0x10)
	struct FString Next;  // 0x20(0x10)
	struct FString Previous;  // 0x30(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsPublicAchievement
// Size: 0xB0(Inherited: 0x0) 
struct FAccelByteModelsPublicAchievement
{
	struct FString AchievementCode;  // 0x0(0x10)
	struct FString Namespace;  // 0x10(0x10)
	struct FString Name;  // 0x20(0x10)
	struct FString Description;  // 0x30(0x10)
	struct TArray<struct FAccelByteModelsAchievementIcon> LockedIcons;  // 0x40(0x10)
	struct TArray<struct FAccelByteModelsAchievementIcon> UnlockedIcons;  // 0x50(0x10)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool Hidden : 1;  // 0x60(0x1)
	char pad_97[3];  // 0x61(0x3)
	int32_t ListOrder;  // 0x64(0x4)
	struct TArray<struct FString> Tags;  // 0x68(0x10)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool Incremental : 1;  // 0x78(0x1)
	char pad_121[3];  // 0x79(0x3)
	float GoalValue;  // 0x7C(0x4)
	struct FString StatCode;  // 0x80(0x10)
	struct FString CreatedAt;  // 0x90(0x10)
	struct FString UpdatedAt;  // 0xA0(0x10)

}; 
// DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsCloudStorage.UpdateSlotSuccess__DelegateSignature
// Size: 0xD0(Inherited: 0x0) 
struct FUpdateSlotSuccess__DelegateSignature
{
	struct FAccelByteModelsSlot Result;  // 0x0(0xD0)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsSessionBrowserAddPlayerResponse
// Size: 0x1(Inherited: 0x0) 
struct FAccelByteModelsSessionBrowserAddPlayerResponse
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Status : 1;  // 0x0(0x1)

}; 
// DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsLobby.LeavePartyResponse__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FLeavePartyResponse__DelegateSignature
{
	struct FAccelByteModelsLeavePartyResponse Result;  // 0x0(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsCategory.GetDescendantCategories
// Size: 0x40(Inherited: 0x0) 
struct FGetDescendantCategories
{
	struct FString Language;  // 0x0(0x10)
	struct FString CategoryPath;  // 0x10(0x10)
	struct FDelegate OnSuccess;  // 0x20(0x10)
	struct FDelegate OnError;  // 0x30(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsSettings.GetUGCServerUrl
// Size: 0x10(Inherited: 0x0) 
struct FGetUGCServerUrl
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsAchievement.QueryUserAchievements
// Size: 0x2C(Inherited: 0x0) 
struct FQueryUserAchievements
{
	uint8_t  SortBy;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	struct FDelegate OnSuccess;  // 0x4(0x10)
	struct FDelegate OnError;  // 0x14(0x10)
	int32_t Offset;  // 0x24(0x4)
	int32_t Limit;  // 0x28(0x4)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsAchievement.UnlockAchievement
// Size: 0x30(Inherited: 0x0) 
struct FUnlockAchievement
{
	struct FString AchievementCode;  // 0x0(0x10)
	struct FDelegate OnSuccess;  // 0x10(0x10)
	struct FDelegate OnError;  // 0x20(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsGameProfile.CreateGameProfile
// Size: 0xB0(Inherited: 0x0) 
struct FCreateGameProfile
{
	struct FAccelByteModelsGameProfileRequest GameProfileRequest;  // 0x0(0x90)
	struct FDelegate OnSuccess;  // 0x90(0x10)
	struct FDelegate OnError;  // 0xA0(0x10)

}; 
// DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsCategory.GetDescendantCategoriesSuccess__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FGetDescendantCategoriesSuccess__DelegateSignature
{
	struct TArray<struct FAccelByteModelsCategoryInfo> Result;  // 0x0(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsServerInfo
// Size: 0xE8(Inherited: 0x0) 
struct FAccelByteModelsServerInfo
{
	struct FString Pod_name;  // 0x0(0x10)
	struct FString Image_version;  // 0x10(0x10)
	struct FString Namespace;  // 0x20(0x10)
	struct FString Ip;  // 0x30(0x10)
	struct TArray<struct FString> Alternate_ips;  // 0x40(0x10)
	int32_t Port;  // 0x50(0x4)
	char pad_84[4];  // 0x54(0x4)
	struct TMap<struct FString, int32_t> Ports;  // 0x58(0x50)
	struct FString Provider;  // 0xA8(0x10)
	struct FString Game_version;  // 0xB8(0x10)
	struct FString Status;  // 0xC8(0x10)
	struct FString Last_update;  // 0xD8(0x10)

}; 
// DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsAchievement.QueryUserAchievementsSuccess__DelegateSignature
// Size: 0x60(Inherited: 0x0) 
struct FQueryUserAchievementsSuccess__DelegateSignature
{
	struct FAccelByteModelsPaginatedUserAchievement Result;  // 0x0(0x60)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsEntitlement.QueryUserEntitlements
// Size: 0x50(Inherited: 0x0) 
struct FQueryUserEntitlements
{
	struct FString EntitlementName;  // 0x0(0x10)
	struct FString ItemId;  // 0x10(0x10)
	int32_t Page;  // 0x20(0x4)
	int32_t Size;  // 0x24(0x4)
	struct FDelegate OnSuccess;  // 0x28(0x10)
	struct FDelegate OnError;  // 0x38(0x10)
	uint8_t  EntitlementClass;  // 0x48(0x1)
	uint8_t  AppType;  // 0x49(0x1)
	char pad_74[6];  // 0x4A(0x6)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsCurrencyList
// Size: 0x98(Inherited: 0x0) 
struct FAccelByteModelsCurrencyList
{
	struct FString CurrencyCode;  // 0x0(0x10)
	struct TMap<struct FString, struct FString> LocalizationDescriptions;  // 0x10(0x50)
	struct FString CurrencySymbol;  // 0x60(0x10)
	struct FString Namespace;  // 0x70(0x10)
	uint8_t  CurrencyType;  // 0x80(0x1)
	char pad_129[3];  // 0x81(0x3)
	int32_t Decimals;  // 0x84(0x4)
	struct FDateTime CreatedAt;  // 0x88(0x8)
	struct FDateTime UpdateAt;  // 0x90(0x8)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsOrder.GetUserOrderHistory
// Size: 0x30(Inherited: 0x0) 
struct FGetUserOrderHistory
{
	struct FString OrderNo;  // 0x0(0x10)
	struct FDelegate OnSuccess;  // 0x10(0x10)
	struct FDelegate OnError;  // 0x20(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsPaginatedUserAchievement
// Size: 0x60(Inherited: 0x0) 
struct FAccelByteModelsPaginatedUserAchievement
{
	struct FAccelByteModelsCountInfo CountInfo;  // 0x0(0xC)
	char pad_12[4];  // 0xC(0x4)
	struct TArray<struct FAccelByteModelsUserAchievement> Data;  // 0x10(0x10)
	struct FAccelByteModelsPaging Paging;  // 0x20(0x40)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsGameProfile.GetGameProfile
// Size: 0x30(Inherited: 0x0) 
struct FGetGameProfile
{
	struct FString profileId;  // 0x0(0x10)
	struct FDelegate OnSuccess;  // 0x10(0x10)
	struct FDelegate OnError;  // 0x20(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsLobby.RequestFriend
// Size: 0x10(Inherited: 0x0) 
struct FRequestFriend
{
	struct FString UserId;  // 0x0(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsLobby.SetGetAllUserPresenceResponseDelegate
// Size: 0x10(Inherited: 0x0) 
struct FSetGetAllUserPresenceResponseDelegate
{
	struct FDelegate OnGetAllUserPresenceResponse;  // 0x0(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsCountInfo
// Size: 0xC(Inherited: 0x0) 
struct FAccelByteModelsCountInfo
{
	int32_t NumberOfAchievements;  // 0x0(0x4)
	int32_t NumberOfHiddenAchievements;  // 0x4(0x4)
	int32_t NumberOfVisibleAchievements;  // 0x8(0x4)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsGameProfileRequest
// Size: 0x90(Inherited: 0x0) 
struct FAccelByteModelsGameProfileRequest
{
	struct TMap<struct FString, struct FString> attributes;  // 0x0(0x50)
	struct FString avatarUrl;  // 0x50(0x10)
	struct FString Label;  // 0x60(0x10)
	struct FString ProfileName;  // 0x70(0x10)
	struct TArray<struct FString> Tags;  // 0x80(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsPolicyVersionWithLocalizedVersionObject
// Size: 0x70(Inherited: 0x0) 
struct FAccelByteModelsPolicyVersionWithLocalizedVersionObject
{
	struct FString ID;  // 0x0(0x10)
	struct FDateTime CreatedAt;  // 0x10(0x8)
	struct FDateTime UpdatedAt;  // 0x18(0x8)
	struct FString DisplayVersion;  // 0x20(0x10)
	struct FString Description;  // 0x30(0x10)
	struct FString Status;  // 0x40(0x10)
	struct FDateTime PublishedDate;  // 0x50(0x8)
	struct TArray<struct FAccelByteModelsLocalizedPolicyVersionObject> LocalizedPolicyVersions;  // 0x58(0x10)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool IsCommitted : 1;  // 0x68(0x1)
	char pad_105_1 : 7;  // 0x69(0x1)
	bool IsCrucial : 1;  // 0x69(0x1)
	char pad_106_1 : 7;  // 0x6A(0x1)
	bool IsInEffect : 1;  // 0x6A(0x1)
	char pad_107[5];  // 0x6B(0x5)

}; 
// DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsCategory.GetRootCategoriesSuccess__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FGetRootCategoriesSuccess__DelegateSignature
{
	struct TArray<struct FAccelByteModelsCategoryInfo> Result;  // 0x0(0x10)

}; 
// DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsReward.GetRewardByRewardIdSuccess__DelegateSignature
// Size: 0x78(Inherited: 0x0) 
struct FGetRewardByRewardIdSuccess__DelegateSignature
{
	struct FAccelByteModelsRewardInfo Result;  // 0x0(0x78)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsCategory.GetCategory
// Size: 0x40(Inherited: 0x0) 
struct FGetCategory
{
	struct FString ParentPath;  // 0x0(0x10)
	struct FString Language;  // 0x10(0x10)
	struct FDelegate OnSuccess;  // 0x20(0x10)
	struct FDelegate OnError;  // 0x30(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsServerCredentials.GetClientNamespace
// Size: 0x10(Inherited: 0x0) 
struct FGetClientNamespace
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsCategoryInfo
// Size: 0x58(Inherited: 0x0) 
struct FAccelByteModelsCategoryInfo
{
	struct FString Namespace;  // 0x0(0x10)
	struct FString ParentCategoryPath;  // 0x10(0x10)
	struct FString CategoryPath;  // 0x20(0x10)
	struct FDateTime CreatedAt;  // 0x30(0x8)
	struct FDateTime UpdatedAt;  // 0x38(0x8)
	struct FString DisplayName;  // 0x40(0x10)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool Root : 1;  // 0x50(0x1)
	char pad_81[7];  // 0x51(0x7)

}; 
// DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsCategory.GetCategorySuccess__DelegateSignature
// Size: 0x58(Inherited: 0x0) 
struct FGetCategorySuccess__DelegateSignature
{
	struct FAccelByteModelsCategoryInfo Result;  // 0x0(0x58)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsSettings.GetCloudSaveServerUrl
// Size: 0x10(Inherited: 0x0) 
struct FGetCloudSaveServerUrl
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsLobbyBaseResponse
// Size: 0x10(Inherited: 0x0) 
struct FAccelByteModelsLobbyBaseResponse
{
	struct FString Code;  // 0x0(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsItemRegionDataItem
// Size: 0x68(Inherited: 0x0) 
struct FAccelByteModelsItemRegionDataItem
{
	int32_t Price;  // 0x0(0x4)
	int32_t DiscountPercentage;  // 0x4(0x4)
	int32_t DiscountAmount;  // 0x8(0x4)
	int32_t DiscountedPrice;  // 0xC(0x4)
	struct FString CurrencyCode;  // 0x10(0x10)
	uint8_t  CurrencyType;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct FString CurrencyNamespace;  // 0x28(0x10)
	struct FString TrialPrice;  // 0x38(0x10)
	struct FDateTime PurchaseAt;  // 0x48(0x8)
	struct FDateTime ExpireAt;  // 0x50(0x8)
	struct FDateTime DiscountPurchaseAt;  // 0x58(0x8)
	struct FDateTime DiscountExpireAt;  // 0x60(0x8)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsCategory.GetChildCategories
// Size: 0x40(Inherited: 0x0) 
struct FGetChildCategories
{
	struct FString Language;  // 0x0(0x10)
	struct FString CategoryPath;  // 0x10(0x10)
	struct FDelegate OnSuccess;  // 0x20(0x10)
	struct FDelegate OnError;  // 0x30(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsKickNotice
// Size: 0x30(Inherited: 0x0) 
struct FAccelByteModelsKickNotice
{
	struct FString LeaderId;  // 0x0(0x10)
	struct FString UserId;  // 0x10(0x10)
	struct FString PartyId;  // 0x20(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsCloudStorage.CreateSlot
// Size: 0x70(Inherited: 0x0) 
struct FCreateSlot
{
	struct TArray<char> Data;  // 0x0(0x10)
	struct FString Filename;  // 0x10(0x10)
	struct TArray<struct FString> Tags;  // 0x20(0x10)
	struct FString Label;  // 0x30(0x10)
	struct FString CustomAttribute;  // 0x40(0x10)
	struct FDelegate OnSuccess;  // 0x50(0x10)
	struct FDelegate OnError;  // 0x60(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsEntitlement.QueryUserEntitlementsMany
// Size: 0x50(Inherited: 0x0) 
struct FQueryUserEntitlementsMany
{
	struct FString EntitlementName;  // 0x0(0x10)
	struct TArray<struct FString> ItemIds;  // 0x10(0x10)
	int32_t Page;  // 0x20(0x4)
	int32_t Size;  // 0x24(0x4)
	struct FDelegate OnSuccess;  // 0x28(0x10)
	struct FDelegate OnError;  // 0x38(0x10)
	uint8_t  EntitlementClass;  // 0x48(0x1)
	uint8_t  AppType;  // 0x49(0x1)
	char pad_74[6];  // 0x4A(0x6)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsFulFillCodeRequest
// Size: 0x30(Inherited: 0x0) 
struct FAccelByteModelsFulFillCodeRequest
{
	struct FString Code;  // 0x0(0x10)
	struct FString Region;  // 0x10(0x10)
	struct FString Language;  // 0x20(0x10)

}; 
// DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsEntitlement.QueryUserEntitlementSuccess__DelegateSignature
// Size: 0x50(Inherited: 0x0) 
struct FQueryUserEntitlementSuccess__DelegateSignature
{
	struct FAccelByteModelsEntitlementPagingSlicedResult Result;  // 0x0(0x50)

}; 
// DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsCloudStorage.GetAllSlotsSuccess__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FGetAllSlotsSuccess__DelegateSignature
{
	struct TArray<struct FAccelByteModelsSlot> Result;  // 0x0(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsSettings.SetCloudSaveServerUrl
// Size: 0x10(Inherited: 0x0) 
struct FSetCloudSaveServerUrl
{
	struct FString CloudSaveServerUrl;  // 0x0(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsSlot
// Size: 0xD0(Inherited: 0x0) 
struct FAccelByteModelsSlot
{
	struct FString Checksum;  // 0x0(0x10)
	struct FString CustomAttribute;  // 0x10(0x10)
	struct FDateTime DateAccessed;  // 0x20(0x8)
	struct FDateTime DateCreated;  // 0x28(0x8)
	struct FDateTime DateModified;  // 0x30(0x8)
	struct FString Label;  // 0x38(0x10)
	struct FString MimeType;  // 0x48(0x10)
	struct FString Namespace;  // 0x58(0x10)
	struct FString OriginalName;  // 0x68(0x10)
	struct FString SlotId;  // 0x78(0x10)
	struct FString Status;  // 0x88(0x10)
	struct FString StoredName;  // 0x98(0x10)
	struct TArray<struct FString> Tags;  // 0xA8(0x10)
	struct FString UserId;  // 0xB8(0x10)
	int32_t Size;  // 0xC8(0x4)
	char pad_204[4];  // 0xCC(0x4)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsEntitlementInfo
// Size: 0x270(Inherited: 0x0) 
struct FAccelByteModelsEntitlementInfo
{
	struct FString ID;  // 0x0(0x10)
	struct FString Namespace;  // 0x10(0x10)
	uint8_t  Clazz;  // 0x20(0x1)
	uint8_t  Type;  // 0x21(0x1)
	uint8_t  Status;  // 0x22(0x1)
	char pad_35[5];  // 0x23(0x5)
	struct FString AppId;  // 0x28(0x10)
	uint8_t  AppType;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct FString Sku;  // 0x40(0x10)
	struct FString UserId;  // 0x50(0x10)
	struct FString ItemId;  // 0x60(0x10)
	struct FString GrantedCode;  // 0x70(0x10)
	struct FString ItemNamespace;  // 0x80(0x10)
	struct FString Name;  // 0x90(0x10)
	int32_t UseCount;  // 0xA0(0x4)
	int32_t Quantity;  // 0xA4(0x4)
	uint8_t  Source;  // 0xA8(0x1)
	char pad_169[3];  // 0xA9(0x3)
	int32_t DistributedQuantity;  // 0xAC(0x4)
	struct FString TargetNamespace;  // 0xB0(0x10)
	struct FAccelByteModelsEntitlementItemSnapshot ItemSnapshot;  // 0xC0(0x178)
	struct FString StartDate;  // 0x238(0x10)
	struct FString EndDate;  // 0x248(0x10)
	struct FDateTime GrantedAt;  // 0x258(0x8)
	struct FDateTime CreatedAt;  // 0x260(0x8)
	struct FDateTime UpdatedAt;  // 0x268(0x8)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsCloudStorage.DeleteSlot
// Size: 0x30(Inherited: 0x0) 
struct FDeleteSlot
{
	struct FString SlotId;  // 0x0(0x10)
	struct FDelegate OnSuccess;  // 0x10(0x10)
	struct FDelegate OnError;  // 0x20(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsPublicUserProfileInfo
// Size: 0x60(Inherited: 0x0) 
struct FAccelByteModelsPublicUserProfileInfo
{
	struct FString UserId;  // 0x0(0x10)
	struct FString Namespace;  // 0x10(0x10)
	struct FString AvatarSmallUrl;  // 0x20(0x10)
	struct FString avatarUrl;  // 0x30(0x10)
	struct FString AvatarLargeUrl;  // 0x40(0x10)
	struct FString TimeZone;  // 0x50(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsCloudStorage.GetAllSlots
// Size: 0x20(Inherited: 0x0) 
struct FGetAllSlots
{
	struct FDelegate OnSuccess;  // 0x0(0x10)
	struct FDelegate OnError;  // 0x10(0x10)

}; 
// Function AccelByteUe4Sdk.BPUser.SendUpgradeVerificationCode
// Size: 0x30(Inherited: 0x0) 
struct FSendUpgradeVerificationCode
{
	struct FString Email;  // 0x0(0x10)
	struct FDelegate OnSuccess;  // 0x10(0x10)
	struct FDelegate OnError;  // 0x20(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsUnblockPlayerResponse
// Size: 0x10(Inherited: 0x0) 
struct FAccelByteModelsUnblockPlayerResponse
{
	struct FString Code;  // 0x0(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsCloudStorage.GetSlot
// Size: 0x30(Inherited: 0x0) 
struct FGetSlot
{
	struct FString SlotId;  // 0x0(0x10)
	struct FDelegate OnSuccess;  // 0x10(0x10)
	struct FDelegate OnError;  // 0x20(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsCloudStorage.UpdateSlot
// Size: 0x80(Inherited: 0x0) 
struct FUpdateSlot
{
	struct FString SlotId;  // 0x0(0x10)
	struct FString Filename;  // 0x10(0x10)
	struct TArray<char> Data;  // 0x20(0x10)
	struct TArray<struct FString> Tags;  // 0x30(0x10)
	struct FString Label;  // 0x40(0x10)
	struct FString CustomAttribute;  // 0x50(0x10)
	struct FDelegate OnSuccess;  // 0x60(0x10)
	struct FDelegate OnError;  // 0x70(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsCloudStorage.UpdateSlotMetadata
// Size: 0x70(Inherited: 0x0) 
struct FUpdateSlotMetadata
{
	struct FString SlotId;  // 0x0(0x10)
	struct FString Filename;  // 0x10(0x10)
	struct TArray<struct FString> Tags;  // 0x20(0x10)
	struct FString Label;  // 0x30(0x10)
	struct FString CustomAttribute;  // 0x40(0x10)
	struct FDelegate OnSuccess;  // 0x50(0x10)
	struct FDelegate OnError;  // 0x60(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsStatistic.GetAllUserStatItems
// Size: 0x20(Inherited: 0x0) 
struct FGetAllUserStatItems
{
	struct FDelegate OnSuccess;  // 0x0(0x10)
	struct FDelegate OnError;  // 0x10(0x10)

}; 
// DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsCloudStorage.UpdateSlotMetadataSuccess__DelegateSignature
// Size: 0xD0(Inherited: 0x0) 
struct FUpdateSlotMetadataSuccess__DelegateSignature
{
	struct FAccelByteModelsSlot Result;  // 0x0(0xD0)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsGameProfile.BatchGetPublicGameProfiles
// Size: 0x30(Inherited: 0x0) 
struct FBatchGetPublicGameProfiles
{
	struct TArray<struct FString> UserIds;  // 0x0(0x10)
	struct FDelegate OnSuccess;  // 0x10(0x10)
	struct FDelegate OnError;  // 0x20(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsRefreshTokenResponse
// Size: 0x10(Inherited: 0x0) 
struct FAccelByteModelsRefreshTokenResponse
{
	struct FString Code;  // 0x0(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsSeasonPassReward
// Size: 0xB8(Inherited: 0x0) 
struct FAccelByteModelsSeasonPassReward
{
	struct FString Namespace;  // 0x0(0x10)
	struct FString SeasonId;  // 0x10(0x10)
	struct FString Code;  // 0x20(0x10)
	uint8_t  Type;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)
	struct FString ItemId;  // 0x38(0x10)
	struct FString ItemName;  // 0x48(0x10)
	struct FString ItemSku;  // 0x58(0x10)
	int32_t Quantity;  // 0x68(0x4)
	char pad_108[4];  // 0x6C(0x4)
	struct FAccelByteModelsItemImage Image;  // 0x70(0x48)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsCurrency.GetCurrencyList
// Size: 0x30(Inherited: 0x0) 
struct FGetCurrencyList
{
	struct FString Namespace;  // 0x0(0x10)
	struct FDelegate OnSuccess;  // 0x10(0x10)
	struct FDelegate OnError;  // 0x20(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsPopulatedItemInfo
// Size: 0x1E8(Inherited: 0x0) 
struct FAccelByteModelsPopulatedItemInfo
{
	struct FString Title;  // 0x0(0x10)
	struct FString Description;  // 0x10(0x10)
	struct FString LongDescription;  // 0x20(0x10)
	struct FString ItemId;  // 0x30(0x10)
	struct FString AppId;  // 0x40(0x10)
	struct FString AppType;  // 0x50(0x10)
	struct FString BaseAppId;  // 0x60(0x10)
	struct FString Sku;  // 0x70(0x10)
	struct FString Namespace;  // 0x80(0x10)
	struct FString Name;  // 0x90(0x10)
	uint8_t  EntitlementType;  // 0xA0(0x1)
	char pad_161[3];  // 0xA1(0x3)
	int32_t UseCount;  // 0xA4(0x4)
	char pad_168_1 : 7;  // 0xA8(0x1)
	bool Stackable : 1;  // 0xA8(0x1)
	char pad_169[7];  // 0xA9(0x7)
	struct FString CategoryPath;  // 0xB0(0x10)
	uint8_t  Status;  // 0xC0(0x1)
	uint8_t  ItemType;  // 0xC1(0x1)
	char pad_194[6];  // 0xC2(0x6)
	struct FString TargetNamespace;  // 0xC8(0x10)
	struct FString TargetCurrencyCode;  // 0xD8(0x10)
	struct FString TargetItemId;  // 0xE8(0x10)
	struct TArray<struct FAccelByteModelsItemImage> Images;  // 0xF8(0x10)
	struct FString ThumbnailUrl;  // 0x108(0x10)
	struct TArray<struct FAccelByteModelsItemRegionDataItem> RegionData;  // 0x118(0x10)
	struct TArray<struct FString> ItemIds;  // 0x128(0x10)
	struct TArray<struct FString> Tags;  // 0x138(0x10)
	struct TArray<struct FString> Features;  // 0x148(0x10)
	int32_t MaxCountPerUser;  // 0x158(0x4)
	int32_t MaxCount;  // 0x15C(0x4)
	struct FString Clazz;  // 0x160(0x10)
	struct FString BoothName;  // 0x170(0x10)
	int32_t DisplayOrder;  // 0x180(0x4)
	char pad_388[4];  // 0x184(0x4)
	struct FString Ext;  // 0x188(0x10)
	struct FString Region;  // 0x198(0x10)
	struct FString Language;  // 0x1A8(0x10)
	struct FDateTime CreatedAt;  // 0x1B8(0x8)
	struct FDateTime UpdatedAt;  // 0x1C0(0x8)
	struct TArray<struct FAccelByteModelsItemInfo> Items;  // 0x1C8(0x10)
	struct FString LocalExt;  // 0x1D8(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsPartySendNotifResponse
// Size: 0x10(Inherited: 0x0) 
struct FAccelByteModelsPartySendNotifResponse
{
	struct FString Code;  // 0x0(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsSeasonTierRewardAsJsonObject
// Size: 0x140(Inherited: 0x0) 
struct FAccelByteModelsSeasonTierRewardAsJsonObject
{
	struct FString Title;  // 0x0(0x10)
	struct FString Description;  // 0x10(0x10)
	struct FString ID;  // 0x20(0x10)
	struct FString Namespace;  // 0x30(0x10)
	struct FString Name;  // 0x40(0x10)
	struct FDateTime Start;  // 0x50(0x8)
	struct FDateTime End;  // 0x58(0x8)
	struct FString TierItemId;  // 0x60(0x10)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool AutoClaim : 1;  // 0x70(0x1)
	char pad_113[7];  // 0x71(0x7)
	struct TArray<struct FAccelByteModelsItemImage> Images;  // 0x78(0x10)
	struct TArray<struct FString> PassCodes;  // 0x88(0x10)
	uint8_t  Status;  // 0x98(0x1)
	char pad_153[7];  // 0x99(0x7)
	struct FDateTime PublishedAt;  // 0xA0(0x8)
	struct FString Language;  // 0xA8(0x10)
	struct FDateTime CreatedAt;  // 0xB8(0x8)
	struct FDateTime UpdatedAt;  // 0xC0(0x8)
	struct TArray<struct FAccelByteModelsSeasonPass> Passes;  // 0xC8(0x10)
	struct TMap<struct FString, struct FAccelByteModelsSeasonPassReward> Rewards;  // 0xD8(0x50)
	struct TArray<struct FAccelByteModelsSeasonPassTierJsonObject> Tiers;  // 0x128(0x10)
	char pad_312_1 : 7;  // 0x138(0x1)
	bool endless : 1;  // 0x138(0x1)
	char pad_313[3];  // 0x139(0x3)
	int32_t EndlessLevelsPerDrop;  // 0x13C(0x4)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsSettings.SetSessionManagerServerUrl
// Size: 0x10(Inherited: 0x0) 
struct FSetSessionManagerServerUrl
{
	struct FString SessionManagerServerUrl;  // 0x0(0x10)

}; 
// DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsGameProfile.BatchGetPublicGameProfilesSuccess__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FBatchGetPublicGameProfilesSuccess__DelegateSignature
{
	struct TArray<struct FAccelByteModelsPublicGameProfile> Result;  // 0x0(0x10)

}; 
// DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsLobby.InvitePartyGetInvitedNotice__DelegateSignature
// Size: 0x30(Inherited: 0x0) 
struct FInvitePartyGetInvitedNotice__DelegateSignature
{
	struct FAccelByteModelsPartyGetInvitedNotice Result;  // 0x0(0x30)

}; 
// DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsCurrency.GetCurrencyListSuccess__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FGetCurrencyListSuccess__DelegateSignature
{
	struct TArray<struct FAccelByteModelsCurrencyList> Result;  // 0x0(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsEntitlementItemSnapshot
// Size: 0x178(Inherited: 0x0) 
struct FAccelByteModelsEntitlementItemSnapshot
{
	struct FString ItemId;  // 0x0(0x10)
	struct FString AppId;  // 0x10(0x10)
	uint8_t  AppType;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct FString BaseAppId;  // 0x28(0x10)
	struct FString Sku;  // 0x38(0x10)
	struct FString Namespace;  // 0x48(0x10)
	struct FString Name;  // 0x58(0x10)
	uint8_t  EntitlementType;  // 0x68(0x1)
	char pad_105[3];  // 0x69(0x3)
	int32_t UseCount;  // 0x6C(0x4)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool Stackable : 1;  // 0x70(0x1)
	uint8_t  ItemType;  // 0x71(0x1)
	char pad_114[6];  // 0x72(0x6)
	struct FString ThumbnailUrl;  // 0x78(0x10)
	struct FString TargetNamespace;  // 0x88(0x10)
	struct FString TargetCurrencyCode;  // 0x98(0x10)
	struct FString TargetItemId;  // 0xA8(0x10)
	struct FString Title;  // 0xB8(0x10)
	struct FAccelByteModelsItemRegionDataItem RegionDataItem;  // 0xC8(0x68)
	struct TArray<struct FString> ItemIds;  // 0x130(0x10)
	int32_t MaxCountPerUser;  // 0x140(0x4)
	int32_t MaxCount;  // 0x144(0x4)
	struct FString BoothName;  // 0x148(0x10)
	struct FString Region;  // 0x158(0x10)
	struct FString Language;  // 0x168(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsPublicGameProfile
// Size: 0x20(Inherited: 0x0) 
struct FAccelByteModelsPublicGameProfile
{
	struct TArray<struct FAccelByteModelsPublicGameProfileInfo> gameProfiles;  // 0x0(0x10)
	struct FString UserId;  // 0x10(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.UpgradeUserRequest
// Size: 0x18(Inherited: 0x0) 
struct FUpgradeUserRequest
{
	struct FString Temporary_session_id;  // 0x0(0x10)
	int32_t Expires_in;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsSetSessionAttributesResponse
// Size: 0x10(Inherited: 0x0) 
struct FAccelByteModelsSetSessionAttributesResponse
{
	struct FString Code;  // 0x0(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.JwkSet
// Size: 0x10(Inherited: 0x0) 
struct FJwkSet
{
	struct TArray<struct FJsonObjectWrapper> keys;  // 0x0(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsSettings.SetQosManagerServerUrl
// Size: 0x10(Inherited: 0x0) 
struct FSetQosManagerServerUrl
{
	struct FString QosManagerServerUrl;  // 0x0(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsPublicGameProfileInfo
// Size: 0x40(Inherited: 0x0) 
struct FAccelByteModelsPublicGameProfileInfo
{
	struct FString profileId;  // 0x0(0x10)
	struct FString Namespace;  // 0x10(0x10)
	struct FString ProfileName;  // 0x20(0x10)
	struct FString avatarUrl;  // 0x30(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsSettings.GetGameTelemetryServerUrl
// Size: 0x10(Inherited: 0x0) 
struct FGetGameTelemetryServerUrl
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsGameProfile.CreateGameProfileSuccess__DelegateSignature
// Size: 0xC0(Inherited: 0x0) 
struct FCreateGameProfileSuccess__DelegateSignature
{
	struct FAccelByteModelsGameProfile Result;  // 0x0(0xC0)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsInvitationNotice
// Size: 0x20(Inherited: 0x0) 
struct FAccelByteModelsInvitationNotice
{
	struct FString InviterID;  // 0x0(0x10)
	struct FString InviteeID;  // 0x10(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsPartyDataUpdateStringRequest
// Size: 0x30(Inherited: 0x0) 
struct FAccelByteModelsPartyDataUpdateStringRequest
{
	struct FString UpdatedAt;  // 0x0(0x10)
	struct FJsonObjectWrapper Custom_attribute;  // 0x10(0x20)

}; 
// DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsGameProfile.GetGameProfileAttributeSuccess__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FGetGameProfileAttributeSuccess__DelegateSignature
{
	struct FAccelByteModelsGameProfileAttribute Result;  // 0x0(0x20)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsGameProfile
// Size: 0xC0(Inherited: 0x0) 
struct FAccelByteModelsGameProfile
{
	struct FString profileId;  // 0x0(0x10)
	struct FString UserId;  // 0x10(0x10)
	struct FString Namespace;  // 0x20(0x10)
	struct FString ProfileName;  // 0x30(0x10)
	struct FString avatarUrl;  // 0x40(0x10)
	struct FString Label;  // 0x50(0x10)
	struct TArray<struct FString> Tags;  // 0x60(0x10)
	struct TMap<struct FString, struct FString> attributes;  // 0x70(0x50)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsOrderInfoPaymentUrl
// Size: 0x50(Inherited: 0x0) 
struct FAccelByteModelsOrderInfoPaymentUrl
{
	struct FString PaymentProvider;  // 0x0(0x10)
	struct FString PaymentUrl;  // 0x10(0x10)
	struct FString PaymentToken;  // 0x20(0x10)
	struct FString ReturnUrl;  // 0x30(0x10)
	struct FString PaymentType;  // 0x40(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsUnblockPlayerNotif
// Size: 0x20(Inherited: 0x0) 
struct FAccelByteModelsUnblockPlayerNotif
{
	struct FString UserId;  // 0x0(0x10)
	struct FString UnblockedUserId;  // 0x10(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsRewardCondition
// Size: 0x40(Inherited: 0x0) 
struct FAccelByteModelsRewardCondition
{
	struct FString ConditionName;  // 0x0(0x10)
	struct FString Condition;  // 0x10(0x10)
	struct FString EventName;  // 0x20(0x10)
	struct TArray<struct FAccelByteModelsRewardItem> RewardItems;  // 0x30(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsLobbyType
// Size: 0x10(Inherited: 0x0) 
struct FAccelByteModelsLobbyType
{
	struct FString Type;  // 0x0(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsSettings.SetSessionBrowserServerUrl
// Size: 0x10(Inherited: 0x0) 
struct FSetSessionBrowserServerUrl
{
	struct FString SessionBrowserServerUrl;  // 0x0(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsGameProfile.DeleteGameProfile
// Size: 0x30(Inherited: 0x0) 
struct FDeleteGameProfile
{
	struct FString profileId;  // 0x0(0x10)
	struct FDelegate OnSuccess;  // 0x10(0x10)
	struct FDelegate OnError;  // 0x20(0x10)

}; 
// DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsGameProfile.GetGameProfileSuccess__DelegateSignature
// Size: 0xC0(Inherited: 0x0) 
struct FGetGameProfileSuccess__DelegateSignature
{
	struct FAccelByteModelsGameProfile Result;  // 0x0(0xC0)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsGameProfile.GetAllGameProfiles
// Size: 0x20(Inherited: 0x0) 
struct FGetAllGameProfiles
{
	struct FDelegate OnSuccess;  // 0x0(0x10)
	struct FDelegate OnError;  // 0x10(0x10)

}; 
// DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsGameProfile.GetAllGameProfilesSuccess__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FGetAllGameProfilesSuccess__DelegateSignature
{
	struct TArray<struct FAccelByteModelsGameProfile> Result;  // 0x0(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsSessionBrowserRecentPlayerGetResult
// Size: 0x10(Inherited: 0x0) 
struct FAccelByteModelsSessionBrowserRecentPlayerGetResult
{
	struct TArray<struct FAccelByteModelsSessionBrowserRecentPlayerData> Data;  // 0x0(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.LinkPlatformAccountRequest
// Size: 0x20(Inherited: 0x0) 
struct FLinkPlatformAccountRequest
{
	struct FString PlatformId;  // 0x0(0x10)
	struct FString PlatformUserId;  // 0x10(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsGameProfileAttribute
// Size: 0x20(Inherited: 0x0) 
struct FAccelByteModelsGameProfileAttribute
{
	struct FString Name;  // 0x0(0x10)
	struct FString Value;  // 0x10(0x10)

}; 
// DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsLobby.IncomingFriendNotif__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FIncomingFriendNotif__DelegateSignature
{
	struct FAccelByteModelsRequestFriendsNotif Result;  // 0x0(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsGameProfile.UpdateGameProfile
// Size: 0xC0(Inherited: 0x0) 
struct FUpdateGameProfile
{
	struct FString profileId;  // 0x0(0x10)
	struct FAccelByteModelsGameProfileRequest GameProfileRequest;  // 0x10(0x90)
	struct FDelegate OnSuccess;  // 0xA0(0x10)
	struct FDelegate OnError;  // 0xB0(0x10)

}; 
// DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsGameProfile.UpdateGameProfileSuccess__DelegateSignature
// Size: 0xC0(Inherited: 0x0) 
struct FUpdateGameProfileSuccess__DelegateSignature
{
	struct FAccelByteModelsGameProfile Result;  // 0x0(0xC0)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsSettings.GetSessionBrowserServerUrl
// Size: 0x10(Inherited: 0x0) 
struct FGetSessionBrowserServerUrl
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsGameProfile.UpdateGameProfileAttribute
// Size: 0x50(Inherited: 0x0) 
struct FUpdateGameProfileAttribute
{
	struct FString profileId;  // 0x0(0x10)
	struct FAccelByteModelsGameProfileAttribute Attribute;  // 0x10(0x20)
	struct FDelegate OnSuccess;  // 0x30(0x10)
	struct FDelegate OnError;  // 0x40(0x10)

}; 
// DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsWallet.GetWalletByCurrencyCodeSuccess__DelegateSignature
// Size: 0x70(Inherited: 0x0) 
struct FGetWalletByCurrencyCodeSuccess__DelegateSignature
{
	struct FAccelByteModelsWalletInfo Result;  // 0x0(0x70)

}; 
// DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsGameProfile.UpdateGameProfileAttributeSuccess__DelegateSignature
// Size: 0xC0(Inherited: 0x0) 
struct FUpdateGameProfileAttributeSuccess__DelegateSignature
{
	struct FAccelByteModelsGameProfile Result;  // 0x0(0xC0)

}; 
// DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsReward.QueryRewardsSuccess__DelegateSignature
// Size: 0x30(Inherited: 0x0) 
struct FQueryRewardsSuccess__DelegateSignature
{
	struct FAccelByteModelsQueryReward Result;  // 0x0(0x30)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsItem.GetItemByAppId
// Size: 0x50(Inherited: 0x0) 
struct FGetItemByAppId
{
	struct FString AppId;  // 0x0(0x10)
	struct FString Region;  // 0x10(0x10)
	struct FString Language;  // 0x20(0x10)
	struct FDelegate OnSuccess;  // 0x30(0x10)
	struct FDelegate OnError;  // 0x40(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsSetOnlineUsersResponse
// Size: 0x10(Inherited: 0x0) 
struct FAccelByteModelsSetOnlineUsersResponse
{
	struct FString Code;  // 0x0(0x10)

}; 
// DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsItem.GetItemByAppIdSuccess__DelegateSignature
// Size: 0x220(Inherited: 0x0) 
struct FGetItemByAppIdSuccess__DelegateSignature
{
	struct FAccelByteModelsItemInfo Result;  // 0x0(0x220)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsItemInfo
// Size: 0x220(Inherited: 0x0) 
struct FAccelByteModelsItemInfo
{
	struct FString Title;  // 0x0(0x10)
	struct FString Description;  // 0x10(0x10)
	struct FString LongDescription;  // 0x20(0x10)
	struct FString ItemId;  // 0x30(0x10)
	struct FString AppId;  // 0x40(0x10)
	uint8_t  AppType;  // 0x50(0x1)
	uint8_t  SeasonType;  // 0x51(0x1)
	char pad_82[6];  // 0x52(0x6)
	struct FString BaseAppId;  // 0x58(0x10)
	struct FString Sku;  // 0x68(0x10)
	struct FString Namespace;  // 0x78(0x10)
	struct FString Name;  // 0x88(0x10)
	uint8_t  EntitlementType;  // 0x98(0x1)
	char pad_153[3];  // 0x99(0x3)
	int32_t UseCount;  // 0x9C(0x4)
	char pad_160_1 : 7;  // 0xA0(0x1)
	bool Stackable : 1;  // 0xA0(0x1)
	char pad_161[7];  // 0xA1(0x7)
	struct FString CategoryPath;  // 0xA8(0x10)
	uint8_t  Status;  // 0xB8(0x1)
	char pad_185_1 : 7;  // 0xB9(0x1)
	bool Listable : 1;  // 0xB9(0x1)
	char pad_186_1 : 7;  // 0xBA(0x1)
	bool Purchasable : 1;  // 0xBA(0x1)
	uint8_t  ItemType;  // 0xBB(0x1)
	char pad_188[4];  // 0xBC(0x4)
	struct FString TargetNamespace;  // 0xC0(0x10)
	struct FString TargetCurrencyCode;  // 0xD0(0x10)
	struct FString TargetItemId;  // 0xE0(0x10)
	struct TArray<struct FAccelByteModelsItemImage> Images;  // 0xF0(0x10)
	struct FString ThumbnailUrl;  // 0x100(0x10)
	struct TArray<struct FAccelByteModelsItemRegionDataItem> RegionData;  // 0x110(0x10)
	struct FAccelByteModelsItemRecurring Recurring;  // 0x120(0x20)
	struct TArray<struct FString> ItemIds;  // 0x140(0x10)
	struct TArray<struct FString> BoundItemIds;  // 0x150(0x10)
	struct TArray<struct FString> Tags;  // 0x160(0x10)
	struct TArray<struct FString> Features;  // 0x170(0x10)
	int32_t MaxCountPerUser;  // 0x180(0x4)
	int32_t MaxCount;  // 0x184(0x4)
	struct FString Clazz;  // 0x188(0x10)
	struct FString BoothName;  // 0x198(0x10)
	int32_t DisplayOrder;  // 0x1A8(0x4)
	char pad_428[4];  // 0x1AC(0x4)
	struct FJsonObjectWrapper Ext;  // 0x1B0(0x20)
	struct FString Region;  // 0x1D0(0x10)
	struct FString Language;  // 0x1E0(0x10)
	struct FDateTime CreatedAt;  // 0x1F0(0x8)
	struct FDateTime UpdatedAt;  // 0x1F8(0x8)
	struct FString LocalExt;  // 0x200(0x10)
	struct FString Rarity;  // 0x210(0x10)

}; 
// DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsLobby.ReadyConsentNotice__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FReadyConsentNotice__DelegateSignature
{
	struct FAccelByteModelsReadyConsentNotice Result;  // 0x0(0x20)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsNotificationMessage
// Size: 0x58(Inherited: 0x0) 
struct FAccelByteModelsNotificationMessage
{
	struct FString ID;  // 0x0(0x10)
	struct FString From;  // 0x10(0x10)
	struct FString To;  // 0x20(0x10)
	struct FString Topic;  // 0x30(0x10)
	struct FString Payload;  // 0x40(0x10)
	struct FDateTime SentAt;  // 0x50(0x8)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsItemRecurring
// Size: 0x20(Inherited: 0x0) 
struct FAccelByteModelsItemRecurring
{
	struct FString Cycle;  // 0x0(0x10)
	int32_t FixedFreeDays;  // 0x10(0x4)
	int32_t FixedTrialCycles;  // 0x14(0x4)
	int32_t GraceDays;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsItemImage
// Size: 0x48(Inherited: 0x0) 
struct FAccelByteModelsItemImage
{
	struct FString As;  // 0x0(0x10)
	struct FString Caption;  // 0x10(0x10)
	int32_t Height;  // 0x20(0x4)
	int32_t Width;  // 0x24(0x4)
	struct FString ImageUrl;  // 0x28(0x10)
	struct FString SmallImageUrl;  // 0x38(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsItem.GetItemById
// Size: 0x50(Inherited: 0x0) 
struct FGetItemById
{
	struct FString ItemId;  // 0x0(0x10)
	struct FString Region;  // 0x10(0x10)
	struct FString Language;  // 0x20(0x10)
	struct FDelegate OnSuccess;  // 0x30(0x10)
	struct FDelegate OnError;  // 0x40(0x10)

}; 
// DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsItem.GetItemByIdSuccess__DelegateSignature
// Size: 0x1E8(Inherited: 0x0) 
struct FGetItemByIdSuccess__DelegateSignature
{
	struct FAccelByteModelsPopulatedItemInfo Result;  // 0x0(0x1E8)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsLobby.SetPartyMessageResponseDelegate
// Size: 0x10(Inherited: 0x0) 
struct FSetPartyMessageResponseDelegate
{
	struct FDelegate OnPartyMessageResponse;  // 0x0(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsWallet.GetWalletInfoByCurrencyCode
// Size: 0x30(Inherited: 0x0) 
struct FGetWalletInfoByCurrencyCode
{
	struct FString CurrencyCode;  // 0x0(0x10)
	struct FDelegate OnSuccess;  // 0x10(0x10)
	struct FDelegate OnError;  // 0x20(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsItem.GetItemsByCriteria
// Size: 0xA0(Inherited: 0x0) 
struct FGetItemsByCriteria
{
	struct FAccelByteModelsItemCriteria ItemCriteria;  // 0x0(0x78)
	int32_t Offset;  // 0x78(0x4)
	int32_t Limit;  // 0x7C(0x4)
	struct FDelegate OnSuccess;  // 0x80(0x10)
	struct FDelegate OnError;  // 0x90(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsPartyJoinReponse
// Size: 0x60(Inherited: 0x0) 
struct FAccelByteModelsPartyJoinReponse
{
	struct FString Code;  // 0x0(0x10)
	struct FString PartyId;  // 0x10(0x10)
	struct FString LeaderId;  // 0x20(0x10)
	struct TArray<struct FString> Members;  // 0x30(0x10)
	struct TArray<struct FString> Invitees;  // 0x40(0x10)
	struct FString InvitationToken;  // 0x50(0x10)

}; 
// DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsItem.GetItemsByCriteriaSuccess__DelegateSignature
// Size: 0x50(Inherited: 0x0) 
struct FGetItemsByCriteriaSuccess__DelegateSignature
{
	struct FAccelByteModelsItemPagingSlicedResult Result;  // 0x0(0x50)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsItemPagingSlicedResult
// Size: 0x50(Inherited: 0x0) 
struct FAccelByteModelsItemPagingSlicedResult
{
	struct TArray<struct FAccelByteModelsItemInfo> Data;  // 0x0(0x10)
	struct FAccelByteModelsPaging Paging;  // 0x10(0x40)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsItemCriteria
// Size: 0x78(Inherited: 0x0) 
struct FAccelByteModelsItemCriteria
{
	uint8_t  ItemType;  // 0x0(0x1)
	uint8_t  AppType;  // 0x1(0x1)
	char pad_2[6];  // 0x2(0x6)
	struct FString Region;  // 0x8(0x10)
	struct FString Language;  // 0x18(0x10)
	struct FString CategoryPath;  // 0x28(0x10)
	struct FString BaseAppId;  // 0x38(0x10)
	struct TArray<struct FString> Tags;  // 0x48(0x10)
	struct TArray<struct FString> Features;  // 0x58(0x10)
	struct FString SortBy;  // 0x68(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsItem.SearchItem
// Size: 0x58(Inherited: 0x0) 
struct FSearchItem
{
	struct FString Language;  // 0x0(0x10)
	struct FString Keyword;  // 0x10(0x10)
	int32_t Page;  // 0x20(0x4)
	int32_t Size;  // 0x24(0x4)
	struct FString Region;  // 0x28(0x10)
	struct FDelegate OnSuccess;  // 0x38(0x10)
	struct FDelegate OnError;  // 0x48(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.Oauth2Session
// Size: 0x28(Inherited: 0x0) 
struct FOauth2Session
{
	struct FString Session_id;  // 0x0(0x10)
	int32_t Expires_in;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct FString Refresh_id;  // 0x18(0x10)

}; 
// DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsItem.SearchItemSuccess__DelegateSignature
// Size: 0x50(Inherited: 0x0) 
struct FSearchItemSuccess__DelegateSignature
{
	struct FAccelByteModelsItemPagingSlicedResult Result;  // 0x0(0x50)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsInfoPartyResponse
// Size: 0x60(Inherited: 0x0) 
struct FAccelByteModelsInfoPartyResponse
{
	struct FString Code;  // 0x0(0x10)
	struct FString PartyId;  // 0x10(0x10)
	struct FString LeaderId;  // 0x20(0x10)
	struct TArray<struct FString> Members;  // 0x30(0x10)
	struct TArray<struct FString> Invitees;  // 0x40(0x10)
	struct FString InvitationToken;  // 0x50(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsLobby.AcceptFriend
// Size: 0x10(Inherited: 0x0) 
struct FAcceptFriend
{
	struct FString UserId;  // 0x0(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsLobby.SetCreatePartyResponseDelegate
// Size: 0x10(Inherited: 0x0) 
struct FSetCreatePartyResponseDelegate
{
	struct FDelegate OnCreatePartyResponse;  // 0x0(0x10)

}; 
// DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsLobby.AcceptFriendsResponseDelegate__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FAcceptFriendsResponseDelegate__DelegateSignature
{
	struct FAccelByteModelsAcceptFriendsResponse Result;  // 0x0(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsServerSettings.SetDSMControllerServerUrl
// Size: 0x10(Inherited: 0x0) 
struct FSetDSMControllerServerUrl
{
	struct FString DSMControllerServerUrl;  // 0x0(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsUnfriendResponse
// Size: 0x10(Inherited: 0x0) 
struct FAccelByteModelsUnfriendResponse
{
	struct FString Code;  // 0x0(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsAcceptFriendsResponse
// Size: 0x10(Inherited: 0x0) 
struct FAccelByteModelsAcceptFriendsResponse
{
	struct FString Code;  // 0x0(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsLobby.BindEvent
// Size: 0x130(Inherited: 0x0) 
struct FBindEvent
{
	struct FDelegate OnConnectSuccess;  // 0x0(0x10)
	struct FDelegate OnConnectError;  // 0x10(0x10)
	struct FDelegate OnConnectionClosed;  // 0x20(0x10)
	struct FDelegate OnLeavePartyNotice;  // 0x30(0x10)
	struct FDelegate OnInvitePartyInvitationNotice;  // 0x40(0x10)
	struct FDelegate OnInvitePartyGetInvitedNotice;  // 0x50(0x10)
	struct FDelegate OnInvitePartyJoinNotice;  // 0x60(0x10)
	struct FDelegate OnInvitePartyKickedNotice;  // 0x70(0x10)
	struct FDelegate OnPrivateMessageNotice;  // 0x80(0x10)
	struct FDelegate OnPartyMessageNotice;  // 0x90(0x10)
	struct FDelegate OnUserPresenceNotice;  // 0xA0(0x10)
	struct FDelegate OnNotificationMessage;  // 0xB0(0x10)
	struct FDelegate OnMatchmakingNotice;  // 0xC0(0x10)
	struct FDelegate OnReadyConsentNotice;  // 0xD0(0x10)
	struct FDelegate OnRematchmakingNotice;  // 0xE0(0x10)
	struct FDelegate OnDsNotice;  // 0xF0(0x10)
	struct FDelegate OnAcceptFriendsNotifDelegate;  // 0x100(0x10)
	struct FDelegate OnRequestFriendsNotifDelegate;  // 0x110(0x10)
	struct FDelegate OnParsingError;  // 0x120(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsRetrieveUserEligibilitiesResponse
// Size: 0xA8(Inherited: 0x0) 
struct FAccelByteModelsRetrieveUserEligibilitiesResponse
{
	struct FString ReadableId;  // 0x0(0x10)
	struct FString PolicyName;  // 0x10(0x10)
	struct FString PolicyType;  // 0x20(0x10)
	struct FString Namespace;  // 0x30(0x10)
	struct FString CountryCode;  // 0x40(0x10)
	struct FString CountryGrupCode;  // 0x50(0x10)
	struct TArray<struct FString> BaseUrls;  // 0x60(0x10)
	struct TArray<struct FAccelByteModelsPolicyVersionWithLocalizedVersionObject> PolicyVersions;  // 0x70(0x10)
	struct FString Description;  // 0x80(0x10)
	struct FString PolicyId;  // 0x90(0x10)
	char pad_160_1 : 7;  // 0xA0(0x1)
	bool IsMandatory : 1;  // 0xA0(0x1)
	char pad_161_1 : 7;  // 0xA1(0x1)
	bool IsAccepted : 1;  // 0xA1(0x1)
	char pad_162[6];  // 0xA2(0x6)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsPartyDataUpdateRequest
// Size: 0x28(Inherited: 0x0) 
struct FAccelByteModelsPartyDataUpdateRequest
{
	char pad_0[8];  // 0x0(0x8)
	struct FJsonObjectWrapper Custom_attribute;  // 0x8(0x20)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsRequestFriendsNotif
// Size: 0x10(Inherited: 0x0) 
struct FAccelByteModelsRequestFriendsNotif
{
	struct FString friendId;  // 0x0(0x10)

}; 
// DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsLobby.FriendAcceptFriendRequestNotif__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FFriendAcceptFriendRequestNotif__DelegateSignature
{
	struct FAccelByteModelsAcceptFriendsNotif Result;  // 0x0(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsAcceptFriendsNotif
// Size: 0x10(Inherited: 0x0) 
struct FAccelByteModelsAcceptFriendsNotif
{
	struct FString friendId;  // 0x0(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsLeavePartyNotice
// Size: 0x20(Inherited: 0x0) 
struct FAccelByteModelsLeavePartyNotice
{
	struct FString UserId;  // 0x0(0x10)
	struct FString LeaderId;  // 0x10(0x10)

}; 
// DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsUserProfile.GetUserProfileSuccess__DelegateSignature
// Size: 0xB0(Inherited: 0x0) 
struct FGetUserProfileSuccess__DelegateSignature
{
	struct FAccelByteModelsUserProfileInfo Result;  // 0x0(0xB0)

}; 
// DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsLobby.DsNotice__DelegateSignature
// Size: 0xE8(Inherited: 0x0) 
struct FDsNotice__DelegateSignature
{
	struct FAccelByteModelsDsNotice Result;  // 0x0(0xE8)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsUGCTypesPagingResponse
// Size: 0x50(Inherited: 0x0) 
struct FAccelByteModelsUGCTypesPagingResponse
{
	struct TArray<struct FAccelByteModelsUGCTypeResponse> Data;  // 0x0(0x10)
	struct FAccelByteModelsPaging Paging;  // 0x10(0x40)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsDsNotice
// Size: 0xE8(Inherited: 0x0) 
struct FAccelByteModelsDsNotice
{
	struct FString Status;  // 0x0(0x10)
	struct FString MatchID;  // 0x10(0x10)
	struct FString PodName;  // 0x20(0x10)
	struct FString Ip;  // 0x30(0x10)
	int32_t Port;  // 0x40(0x4)
	char pad_68[4];  // 0x44(0x4)
	struct FString Message;  // 0x48(0x10)
	struct FString IsOK;  // 0x58(0x10)
	struct FString Region;  // 0x68(0x10)
	struct TMap<struct FString, int32_t> Ports;  // 0x78(0x50)
	struct FString CustomAttribute;  // 0xC8(0x10)
	struct TArray<struct FAccelByteModelsTicketId> Tickets;  // 0xD8(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsSeason
// Size: 0x50(Inherited: 0x0) 
struct FAccelByteModelsSeason
{
	struct FString ID;  // 0x0(0x10)
	struct FString Namespace;  // 0x10(0x10)
	struct FString Name;  // 0x20(0x10)
	struct FDateTime Start;  // 0x30(0x8)
	struct FDateTime End;  // 0x38(0x8)
	uint8_t  Status;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)
	struct FDateTime PublishedAt;  // 0x48(0x8)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsTicketId
// Size: 0x30(Inherited: 0x0) 
struct FAccelByteModelsTicketId
{
	struct FString TicketId;  // 0x0(0x10)
	struct TArray<struct FString> UserIds;  // 0x10(0x10)
	struct FString PartyId;  // 0x20(0x10)

}; 
// DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsLobby.RematchmakingNotice__DelegateSignature
// Size: 0x4(Inherited: 0x0) 
struct FRematchmakingNotice__DelegateSignature
{
	struct FAccelByteModelsRematchmakingNotice Result;  // 0x0(0x4)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsReadyConsentNotice
// Size: 0x20(Inherited: 0x0) 
struct FAccelByteModelsReadyConsentNotice
{
	struct FString MatchID;  // 0x0(0x10)
	struct FString UserId;  // 0x10(0x10)

}; 
// DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsLobby.MatchmakingNotice__DelegateSignature
// Size: 0x28(Inherited: 0x0) 
struct FMatchmakingNotice__DelegateSignature
{
	struct FAccelByteModelsMatchmakingNotice Result;  // 0x0(0x28)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsPartyJoinNotice
// Size: 0x10(Inherited: 0x0) 
struct FAccelByteModelsPartyJoinNotice
{
	struct FString UserId;  // 0x0(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsEncryptionKey
// Size: 0x10(Inherited: 0x0) 
struct FAccelByteModelsEncryptionKey
{
	struct FString EncryptionKey;  // 0x0(0x10)

}; 
// Function AccelByteUe4Sdk.BPUser.GetPlatformLinks
// Size: 0x20(Inherited: 0x0) 
struct FGetPlatformLinks
{
	struct FDelegate OnSuccess;  // 0x0(0x10)
	struct FDelegate OnError;  // 0x10(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsMatchmakingNotice
// Size: 0x28(Inherited: 0x0) 
struct FAccelByteModelsMatchmakingNotice
{
	struct FString MatchID;  // 0x0(0x10)
	uint8_t  Status;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct FString TicketId;  // 0x18(0x10)

}; 
// DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsLobby.NotificationMessage__DelegateSignature
// Size: 0x58(Inherited: 0x0) 
struct FNotificationMessage__DelegateSignature
{
	struct FAccelByteModelsNotificationMessage Result;  // 0x0(0x58)

}; 
// DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsLobby.UserPresenceNotice__DelegateSignature
// Size: 0x30(Inherited: 0x0) 
struct FUserPresenceNotice__DelegateSignature
{
	struct FAccelByteModelsUsersPresenceNotice Result;  // 0x0(0x30)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsUsersPresenceNotice
// Size: 0x30(Inherited: 0x0) 
struct FAccelByteModelsUsersPresenceNotice
{
	struct FString UserId;  // 0x0(0x10)
	struct FString Availability;  // 0x10(0x10)
	struct FString Activity;  // 0x20(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsSessionBrowserAddPlayerRequest
// Size: 0x18(Inherited: 0x0) 
struct FAccelByteModelsSessionBrowserAddPlayerRequest
{
	struct FString User_id;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool As_spectator : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsLobby.PartyMessageNotice__DelegateSignature
// Size: 0x50(Inherited: 0x0) 
struct FPartyMessageNotice__DelegateSignature
{
	struct FAccelByteModelsPartyMessageNotice Result;  // 0x0(0x50)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsPartyMessageNotice
// Size: 0x50(Inherited: 0x0) 
struct FAccelByteModelsPartyMessageNotice
{
	struct FString ID;  // 0x0(0x10)
	struct FString From;  // 0x10(0x10)
	struct FString To;  // 0x20(0x10)
	struct FString Payload;  // 0x30(0x10)
	struct FString ReceivedAt;  // 0x40(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsSettings.SetIamServerUrl
// Size: 0x10(Inherited: 0x0) 
struct FSetIamServerUrl
{
	struct FString IamServerUrl;  // 0x0(0x10)

}; 
// DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsLobby.PrivateMessageNotice__DelegateSignature
// Size: 0x50(Inherited: 0x0) 
struct FPrivateMessageNotice__DelegateSignature
{
	struct FAccelByteModelsPersonalMessageNotice Result;  // 0x0(0x50)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsPersonalMessageNotice
// Size: 0x50(Inherited: 0x0) 
struct FAccelByteModelsPersonalMessageNotice
{
	struct FString ID;  // 0x0(0x10)
	struct FString From;  // 0x10(0x10)
	struct FString To;  // 0x20(0x10)
	struct FString Payload;  // 0x30(0x10)
	struct FString ReceivedAt;  // 0x40(0x10)

}; 
// DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsLobby.InvitePartyKickedNotice__DelegateSignature
// Size: 0x30(Inherited: 0x0) 
struct FInvitePartyKickedNotice__DelegateSignature
{
	struct FAccelByteModelsGotKickedFromPartyNotice Result;  // 0x0(0x30)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsSettings.SetUGCServerUrl
// Size: 0x10(Inherited: 0x0) 
struct FSetUGCServerUrl
{
	struct FString UGCServerUrl;  // 0x0(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsGotKickedFromPartyNotice
// Size: 0x30(Inherited: 0x0) 
struct FAccelByteModelsGotKickedFromPartyNotice
{
	struct FString LeaderId;  // 0x0(0x10)
	struct FString UserId;  // 0x10(0x10)
	struct FString PartyId;  // 0x20(0x10)

}; 
// DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsLobby.InvitePartyJoinNotice__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FInvitePartyJoinNotice__DelegateSignature
{
	struct FAccelByteModelsPartyJoinNotice Result;  // 0x0(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsReadyConsentRequest
// Size: 0x20(Inherited: 0x0) 
struct FAccelByteModelsReadyConsentRequest
{
	struct FString Code;  // 0x0(0x10)
	struct FString MatchID;  // 0x10(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsFreeFormNotificationRequest
// Size: 0x20(Inherited: 0x0) 
struct FAccelByteModelsFreeFormNotificationRequest
{
	struct FString Topic;  // 0x0(0x10)
	struct FString Message;  // 0x10(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsSettings.SetStatisticServerUrl
// Size: 0x10(Inherited: 0x0) 
struct FSetStatisticServerUrl
{
	struct FString StatisticServerUrl;  // 0x0(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsPartyGetInvitedNotice
// Size: 0x30(Inherited: 0x0) 
struct FAccelByteModelsPartyGetInvitedNotice
{
	struct FString From;  // 0x0(0x10)
	struct FString PartyId;  // 0x10(0x10)
	struct FString InvitationToken;  // 0x20(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsSettings.GetPlatformServerUrl
// Size: 0x10(Inherited: 0x0) 
struct FGetPlatformServerUrl
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsLobby.InvitePartyInvitationNotice__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FInvitePartyInvitationNotice__DelegateSignature
{
	struct FAccelByteModelsInvitationNotice Result;  // 0x0(0x20)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsPersonalMessageResponse
// Size: 0x10(Inherited: 0x0) 
struct FAccelByteModelsPersonalMessageResponse
{
	struct FString Code;  // 0x0(0x10)

}; 
// DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsLobby.LeavePartyNotice__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FLeavePartyNotice__DelegateSignature
{
	struct FAccelByteModelsLeavePartyNotice Result;  // 0x0(0x20)

}; 
// DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsLobby.ConnectionClosed__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FConnectionClosed__DelegateSignature
{
	int32_t StatusCode;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FString Reason;  // 0x8(0x10)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool WasClean : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsSeasonClaimRewardResponse
// Size: 0xA0(Inherited: 0x0) 
struct FAccelByteModelsSeasonClaimRewardResponse
{
	char pad_0[160];  // 0x0(0xA0)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsLobby.CancelFriendRequest
// Size: 0x10(Inherited: 0x0) 
struct FCancelFriendRequest
{
	struct FString UserId;  // 0x0(0x10)

}; 
// DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsLobby.CancelFriendsResponseDelegate__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FCancelFriendsResponseDelegate__DelegateSignature
{
	struct FAccelByteModelsCancelFriendsResponse Result;  // 0x0(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsBulkRevokeEntitlements
// Size: 0x4(Inherited: 0x0) 
struct FAccelByteModelsBulkRevokeEntitlements
{
	int32_t Affected;  // 0x0(0x4)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsPartyNotif
// Size: 0x30(Inherited: 0x0) 
struct FAccelByteModelsPartyNotif
{
	struct FString Sender;  // 0x0(0x10)
	struct FString Topic;  // 0x10(0x10)
	struct FString Payload;  // 0x20(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsCancelFriendsResponse
// Size: 0x10(Inherited: 0x0) 
struct FAccelByteModelsCancelFriendsResponse
{
	struct FString Code;  // 0x0(0x10)

}; 
// DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsOrder.GetUserOrdersSuccess__DelegateSignature
// Size: 0x50(Inherited: 0x0) 
struct FGetUserOrdersSuccess__DelegateSignature
{
	struct FAccelByteModelsPagedOrderInfo Result;  // 0x0(0x50)

}; 
// DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsLobby.CreatePartyResponse__DelegateSignature
// Size: 0x70(Inherited: 0x0) 
struct FCreatePartyResponse__DelegateSignature
{
	struct FAccelByteModelsCreatePartyResponse Result;  // 0x0(0x70)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsCreatePartyResponse
// Size: 0x70(Inherited: 0x0) 
struct FAccelByteModelsCreatePartyResponse
{
	struct FString Code;  // 0x0(0x10)
	struct FString PartyId;  // 0x10(0x10)
	struct FString LeaderId;  // 0x20(0x10)
	struct TArray<struct FString> Members;  // 0x30(0x10)
	struct TArray<struct FString> Invitees;  // 0x40(0x10)
	struct FString InvitationToken;  // 0x50(0x10)
	struct FString PartyCode;  // 0x60(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsGetSessionAttributeResponse
// Size: 0x20(Inherited: 0x0) 
struct FAccelByteModelsGetSessionAttributeResponse
{
	struct FString Key;  // 0x0(0x10)
	struct FString Value;  // 0x10(0x10)

}; 
// DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsLobby.PartyMessageResponse__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FPartyMessageResponse__DelegateSignature
{
	struct FAccelByteModelsPartyMessageResponse Result;  // 0x0(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsLobby.GetFriendshipStatus
// Size: 0x10(Inherited: 0x0) 
struct FGetFriendshipStatus
{
	struct FString UserId;  // 0x0(0x10)

}; 
// DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsLobby.GetAllFriendsStatusResponse__DelegateSignature
// Size: 0x70(Inherited: 0x0) 
struct FGetAllFriendsStatusResponse__DelegateSignature
{
	struct FAccelByteModelsGetOnlineUsersResponse Result;  // 0x0(0x70)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsGetOnlineUsersResponse
// Size: 0x70(Inherited: 0x0) 
struct FAccelByteModelsGetOnlineUsersResponse
{
	struct FString Code;  // 0x0(0x10)
	struct FString Type;  // 0x10(0x10)
	struct FString ID;  // 0x20(0x10)
	struct TArray<struct FString> friendsId;  // 0x30(0x10)
	struct TArray<struct FString> Availability;  // 0x40(0x10)
	struct TArray<struct FString> Activity;  // 0x50(0x10)
	struct TArray<struct FString> lastSeenAt;  // 0x60(0x10)

}; 
// DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsLobby.GetFriendshipStatusResponseDelegate__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FGetFriendshipStatusResponseDelegate__DelegateSignature
{
	struct FAccelByteModelsGetFriendshipStatusResponse Result;  // 0x0(0x18)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsGetFriendshipStatusResponse
// Size: 0x18(Inherited: 0x0) 
struct FAccelByteModelsGetFriendshipStatusResponse
{
	struct FString Code;  // 0x0(0x10)
	uint8_t  friendshipStatus;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsUGCTagsPagingResponse
// Size: 0x50(Inherited: 0x0) 
struct FAccelByteModelsUGCTagsPagingResponse
{
	struct TArray<struct FAccelByteModelsUGCTagResponse> Data;  // 0x0(0x10)
	struct FAccelByteModelsPaging Paging;  // 0x10(0x40)

}; 
// DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsLobby.InfoPartyResponse__DelegateSignature
// Size: 0x60(Inherited: 0x0) 
struct FInfoPartyResponse__DelegateSignature
{
	struct FAccelByteModelsInfoPartyResponse Result;  // 0x0(0x60)

}; 
// DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsLobby.InvitePartyJoinResponse__DelegateSignature
// Size: 0x60(Inherited: 0x0) 
struct FInvitePartyJoinResponse__DelegateSignature
{
	struct FAccelByteModelsPartyJoinReponse Result;  // 0x0(0x60)

}; 
// DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsLobby.InvitePartyKickMemberResponse__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FInvitePartyKickMemberResponse__DelegateSignature
{
	struct FAccelByteModelsKickPartyMemberResponse Result;  // 0x0(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsLobby.SetLoadFriendsListResponseDelegate
// Size: 0x10(Inherited: 0x0) 
struct FSetLoadFriendsListResponseDelegate
{
	struct FDelegate OnLoadFriendListResponse;  // 0x0(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsKickPartyMemberResponse
// Size: 0x10(Inherited: 0x0) 
struct FAccelByteModelsKickPartyMemberResponse
{
	struct FString Code;  // 0x0(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsSettings.GetLeaderboardServerUrl
// Size: 0x10(Inherited: 0x0) 
struct FGetLeaderboardServerUrl
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsSettings.GetClientSecret
// Size: 0x10(Inherited: 0x0) 
struct FGetClientSecret
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsLobby.InvitePartyResponse__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FInvitePartyResponse__DelegateSignature
{
	struct FAccelByteModelsPartyInviteResponse Result;  // 0x0(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsPartyInviteResponse
// Size: 0x10(Inherited: 0x0) 
struct FAccelByteModelsPartyInviteResponse
{
	struct FString Code;  // 0x0(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsLobby.IsConnected
// Size: 0x1(Inherited: 0x0) 
struct FIsConnected
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsLeavePartyResponse
// Size: 0x10(Inherited: 0x0) 
struct FAccelByteModelsLeavePartyResponse
{
	struct FString Code;  // 0x0(0x10)

}; 
// DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsLobby.ListIncomingFriendsResponseDelegate__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FListIncomingFriendsResponseDelegate__DelegateSignature
{
	struct FAccelByteModelsListIncomingFriendsResponse Result;  // 0x0(0x20)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsListIncomingFriendsResponse
// Size: 0x20(Inherited: 0x0) 
struct FAccelByteModelsListIncomingFriendsResponse
{
	struct FString Code;  // 0x0(0x10)
	struct TArray<struct FString> friendsId;  // 0x10(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.RegisterResponse
// Size: 0x80(Inherited: 0x0) 
struct FRegisterResponse
{
	struct FString Namespace;  // 0x0(0x10)
	struct FString UserId;  // 0x10(0x10)
	struct FString AuthType;  // 0x20(0x10)
	struct FString DisplayName;  // 0x30(0x10)
	struct FString EmailAddress;  // 0x40(0x10)
	struct FString Country;  // 0x50(0x10)
	struct FString DateOfBirth;  // 0x60(0x10)
	struct FString Username;  // 0x70(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsLobby.SendStartMatchmaking
// Size: 0x10(Inherited: 0x0) 
struct FSendStartMatchmaking
{
	struct FString GameMode;  // 0x0(0x10)

}; 
// DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsLobby.ListOutgoingFriendsResponseDelegate__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FListOutgoingFriendsResponseDelegate__DelegateSignature
{
	struct FAccelByteModelsListOutgoingFriendsResponse Result;  // 0x0(0x20)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsLobby.SendReadyConsentRequest
// Size: 0x10(Inherited: 0x0) 
struct FSendReadyConsentRequest
{
	struct FString MatchID;  // 0x0(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsListOutgoingFriendsResponse
// Size: 0x20(Inherited: 0x0) 
struct FAccelByteModelsListOutgoingFriendsResponse
{
	struct FString Code;  // 0x0(0x10)
	struct TArray<struct FString> friendsId;  // 0x10(0x10)

}; 
// DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsLobby.LoadFriendListResponseDelegate__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FLoadFriendListResponseDelegate__DelegateSignature
{
	struct FAccelByteModelsLoadFriendListResponse Result;  // 0x0(0x20)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsLoadFriendListResponse
// Size: 0x20(Inherited: 0x0) 
struct FAccelByteModelsLoadFriendListResponse
{
	struct FString Code;  // 0x0(0x10)
	struct TArray<struct FString> friendsId;  // 0x10(0x10)

}; 
// DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsLobby.MatchmakingResponse__DelegateSignature
// Size: 0x30(Inherited: 0x0) 
struct FMatchmakingResponse__DelegateSignature
{
	struct FAccelByteModelsMatchmakingResponse Result;  // 0x0(0x30)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsMatchmakingResponse
// Size: 0x30(Inherited: 0x0) 
struct FAccelByteModelsMatchmakingResponse
{
	struct FString Code;  // 0x0(0x10)
	struct FString TicketId;  // 0x10(0x10)
	struct FString BannedUsers;  // 0x20(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsPartyMessageResponse
// Size: 0x10(Inherited: 0x0) 
struct FAccelByteModelsPartyMessageResponse
{
	struct FString Code;  // 0x0(0x10)

}; 
// DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsLobby.PrivateMessageResponse__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FPrivateMessageResponse__DelegateSignature
{
	struct FAccelByteModelsPersonalMessageResponse Result;  // 0x0(0x10)

}; 
// DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsLobby.ReadyConsentResponse__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FReadyConsentResponse__DelegateSignature
{
	struct FAccelByteModelsReadyConsentRequest Result;  // 0x0(0x20)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsLobby.RejectFriend
// Size: 0x10(Inherited: 0x0) 
struct FRejectFriend
{
	struct FString UserId;  // 0x0(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsSetSessionAttributeRequest
// Size: 0x50(Inherited: 0x0) 
struct FAccelByteModelsSetSessionAttributeRequest
{
	struct TMap<struct FString, struct FString> attributes;  // 0x0(0x50)

}; 
// DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsLobby.RejectFriendsResponseDelegate__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FRejectFriendsResponseDelegate__DelegateSignature
{
	struct FAccelByteModelsRejectFriendsResponse Result;  // 0x0(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsUGCChannelResponse
// Size: 0x40(Inherited: 0x0) 
struct FAccelByteModelsUGCChannelResponse
{
	struct FString ID;  // 0x0(0x10)
	struct FString Name;  // 0x10(0x10)
	struct FString Namespace;  // 0x20(0x10)
	struct FString UserId;  // 0x30(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsRejectFriendsResponse
// Size: 0x10(Inherited: 0x0) 
struct FAccelByteModelsRejectFriendsResponse
{
	struct FString Code;  // 0x0(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsUpdateMetadataRequest
// Size: 0x30(Inherited: 0x0) 
struct FAccelByteModelsUpdateMetadataRequest
{
	struct FString Label;  // 0x0(0x10)
	struct TArray<struct FString> Tags;  // 0x10(0x10)
	struct FString CustomAttribute;  // 0x20(0x10)

}; 
// DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsLobby.RequestFriendsResponseDelegate__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FRequestFriendsResponseDelegate__DelegateSignature
{
	struct FAccelByteModelsRequestFriendsResponse Result;  // 0x0(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsRewardInfo
// Size: 0x78(Inherited: 0x0) 
struct FAccelByteModelsRewardInfo
{
	struct FString RewardId;  // 0x0(0x10)
	struct FString Namespace;  // 0x10(0x10)
	struct FString RewardCode;  // 0x20(0x10)
	struct FString Description;  // 0x30(0x10)
	struct FString EventTopic;  // 0x40(0x10)
	struct TArray<struct FAccelByteModelsRewardCondition> RewardConditions;  // 0x50(0x10)
	int32_t MaxAwarded;  // 0x60(0x4)
	int32_t MaxAwardedPerUser;  // 0x64(0x4)
	struct FDateTime CreatedAt;  // 0x68(0x8)
	struct FDateTime UpdatedAt;  // 0x70(0x8)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsRequestFriendsResponse
// Size: 0x10(Inherited: 0x0) 
struct FAccelByteModelsRequestFriendsResponse
{
	struct FString Code;  // 0x0(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsLobby.SendAcceptInvitationRequest
// Size: 0x20(Inherited: 0x0) 
struct FSendAcceptInvitationRequest
{
	struct FString PartyId;  // 0x0(0x10)
	struct FString InvitationToken;  // 0x10(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsSettings.GetCloudStorageServerUrl
// Size: 0x10(Inherited: 0x0) 
struct FGetCloudStorageServerUrl
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsLobby.SendCancelMatchmaking
// Size: 0x10(Inherited: 0x0) 
struct FSendCancelMatchmaking
{
	struct FString GameMode;  // 0x0(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsSeasonPass
// Size: 0xA8(Inherited: 0x0) 
struct FAccelByteModelsSeasonPass
{
	struct FString Title;  // 0x0(0x10)
	struct FString Description;  // 0x10(0x10)
	struct FString SeasonId;  // 0x20(0x10)
	struct FString Code;  // 0x30(0x10)
	struct FString Namespace;  // 0x40(0x10)
	struct FString DisplayOrder;  // 0x50(0x10)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool AutoEnroll : 1;  // 0x60(0x1)
	char pad_97[7];  // 0x61(0x7)
	struct FString PassItemId;  // 0x68(0x10)
	struct TArray<struct FAccelByteModelsItemImage> Images;  // 0x78(0x10)
	struct FString Language;  // 0x88(0x10)
	struct FDateTime CreatedAt;  // 0x98(0x8)
	struct FDateTime UpdatedAt;  // 0xA0(0x8)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsLobby.SendInviteToPartyRequest
// Size: 0x10(Inherited: 0x0) 
struct FSendInviteToPartyRequest
{
	struct FString UserId;  // 0x0(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsLobby.SendKickPartyMemberRequest
// Size: 0x10(Inherited: 0x0) 
struct FSendKickPartyMemberRequest
{
	struct FString UserId;  // 0x0(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsQueryReward
// Size: 0x30(Inherited: 0x0) 
struct FAccelByteModelsQueryReward
{
	struct TArray<struct FAccelByteModelsRewardInfo> Data;  // 0x0(0x10)
	struct FAccelByteModelsQueryRewardPaging Paging;  // 0x10(0x20)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsLobby.SendPartyMessage
// Size: 0x10(Inherited: 0x0) 
struct FSendPartyMessage
{
	struct FString Message;  // 0x0(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsLobby.SendPrivateMessage
// Size: 0x20(Inherited: 0x0) 
struct FSendPrivateMessage
{
	struct FString UserId;  // 0x0(0x10)
	struct FString Message;  // 0x10(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsLobby.SetAcceptFriendResponseDelegate
// Size: 0x10(Inherited: 0x0) 
struct FSetAcceptFriendResponseDelegate
{
	struct FDelegate OnAcceptFriendsResponse;  // 0x0(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsLobby.SetCancelFriendRequestResponseDelegate
// Size: 0x10(Inherited: 0x0) 
struct FSetCancelFriendRequestResponseDelegate
{
	struct FDelegate OnCancelFriendsResponse;  // 0x0(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsLobby.SetCancelMatchmakingResponseDelegate
// Size: 0x10(Inherited: 0x0) 
struct FSetCancelMatchmakingResponseDelegate
{
	struct FDelegate OnMatchmakingCancel;  // 0x0(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsLobby.SetDsNotifDelegate
// Size: 0x10(Inherited: 0x0) 
struct FSetDsNotifDelegate
{
	struct FDelegate OnDsNotice;  // 0x0(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.PagedPublicUsersInfo
// Size: 0x50(Inherited: 0x0) 
struct FPagedPublicUsersInfo
{
	struct TArray<struct FPublicUserInfo> Data;  // 0x0(0x10)
	struct FAccelByteModelsPaging Paging;  // 0x10(0x40)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsLobby.SetGetFriendshipStatusResponseDelegate
// Size: 0x10(Inherited: 0x0) 
struct FSetGetFriendshipStatusResponseDelegate
{
	struct FDelegate OnGetFriendshipStatusResponse;  // 0x0(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsLobby.SetInfoPartyResponseDelegate
// Size: 0x10(Inherited: 0x0) 
struct FSetInfoPartyResponseDelegate
{
	struct FDelegate OnInfoPartyResponse;  // 0x0(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsReward.QueryRewards
// Size: 0x40(Inherited: 0x0) 
struct FQueryRewards
{
	struct FString EventTopic;  // 0x0(0x10)
	int32_t Offset;  // 0x10(0x4)
	int32_t Limit;  // 0x14(0x4)
	uint8_t  SortBy;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)
	struct FDelegate OnSuccess;  // 0x1C(0x10)
	struct FDelegate OnError;  // 0x2C(0x10)
	char pad_60[4];  // 0x3C(0x4)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsMatchmakingBannedUser
// Size: 0x18(Inherited: 0x0) 
struct FAccelByteModelsMatchmakingBannedUser
{
	struct FString UserId;  // 0x0(0x10)
	int64_t Expiry;  // 0x10(0x8)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsLobby.SetInvitePartyJoinResponseDelegate
// Size: 0x10(Inherited: 0x0) 
struct FSetInvitePartyJoinResponseDelegate
{
	struct FDelegate OnInvitePartyJoinResponse;  // 0x0(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsChannelMessageResponse
// Size: 0x20(Inherited: 0x0) 
struct FAccelByteModelsChannelMessageResponse
{
	struct FString Code;  // 0x0(0x10)
	struct FString Message;  // 0x10(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsLobby.SetInvitePartyKickMemberResponseDelegate
// Size: 0x10(Inherited: 0x0) 
struct FSetInvitePartyKickMemberResponseDelegate
{
	struct FDelegate OnInvitePartyKickMemberResponse;  // 0x0(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsLobby.SetInvitePartyResponseDelegate
// Size: 0x10(Inherited: 0x0) 
struct FSetInvitePartyResponseDelegate
{
	struct FDelegate OnInvitePartyResponse;  // 0x0(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsLobby.SetLeavePartyResponseDelegate
// Size: 0x10(Inherited: 0x0) 
struct FSetLeavePartyResponseDelegate
{
	struct FDelegate OnLeavePartyResponse;  // 0x0(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsLobby.SetListIncomingFriendsResponseDelegate
// Size: 0x10(Inherited: 0x0) 
struct FSetListIncomingFriendsResponseDelegate
{
	struct FDelegate OnListIncomingFriendsResponse;  // 0x0(0x10)

}; 
// Function AccelByteUe4Sdk.BPUser.SendResetPasswordCode
// Size: 0x30(Inherited: 0x0) 
struct FSendResetPasswordCode
{
	struct FString Username;  // 0x0(0x10)
	struct FDelegate OnSuccess;  // 0x10(0x10)
	struct FDelegate OnError;  // 0x20(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsLobby.SetListOutgoingFriendsResponseDelegate
// Size: 0x10(Inherited: 0x0) 
struct FSetListOutgoingFriendsResponseDelegate
{
	struct FDelegate OnListOutgoingFriendsResponse;  // 0x0(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsLobby.SetMatchmakingNotifDelegate
// Size: 0x10(Inherited: 0x0) 
struct FSetMatchmakingNotifDelegate
{
	struct FDelegate OnMatchmakingNotice;  // 0x0(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.PagedUserOtherPlatformInfo
// Size: 0x58(Inherited: 0x0) 
struct FPagedUserOtherPlatformInfo
{
	struct TArray<struct FUserOtherPlatformInfo> Data;  // 0x0(0x10)
	struct FAccelByteModelsPaging Paging;  // 0x10(0x40)
	int32_t TotalData;  // 0x50(0x4)
	char pad_84[4];  // 0x54(0x4)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsLobby.SetPresenceStatus
// Size: 0x18(Inherited: 0x0) 
struct FSetPresenceStatus
{
	uint8_t  State;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FString Activity;  // 0x8(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.Oauth2TokenBan
// Size: 0x18(Inherited: 0x0) 
struct FOauth2TokenBan
{
	struct FString Ban;  // 0x0(0x10)
	struct FDateTime EndDate;  // 0x10(0x8)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsSettings.SetClientId
// Size: 0x10(Inherited: 0x0) 
struct FSetClientId
{
	struct FString ClientId;  // 0x0(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsLobby.SetPrivateMessageResponseDelegate
// Size: 0x10(Inherited: 0x0) 
struct FSetPrivateMessageResponseDelegate
{
	struct FDelegate OnPrivateMessageResponse;  // 0x0(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsLobby.SetReadyConsentNotifDelegate
// Size: 0x10(Inherited: 0x0) 
struct FSetReadyConsentNotifDelegate
{
	struct FDelegate OnReadyConsentNotice;  // 0x0(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsOrderCreate
// Size: 0x60(Inherited: 0x0) 
struct FAccelByteModelsOrderCreate
{
	struct FString ItemId;  // 0x0(0x10)
	int32_t Quantity;  // 0x10(0x4)
	int32_t Price;  // 0x14(0x4)
	int32_t DiscountedPrice;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct FString CurrencyCode;  // 0x20(0x10)
	struct FString Region;  // 0x30(0x10)
	struct FString Language;  // 0x40(0x10)
	struct FString ReturnUrl;  // 0x50(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsLobby.SetReadyConsentResponseDelegate
// Size: 0x10(Inherited: 0x0) 
struct FSetReadyConsentResponseDelegate
{
	struct FDelegate OnReadyConsentResponse;  // 0x0(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsLobby.SetRejectFriendResponseDelegate
// Size: 0x10(Inherited: 0x0) 
struct FSetRejectFriendResponseDelegate
{
	struct FDelegate OnRejectFriendsResponse;  // 0x0(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsReasonGroupsResponse
// Size: 0x50(Inherited: 0x0) 
struct FAccelByteModelsReasonGroupsResponse
{
	struct TArray<struct FAccelByteModelsReasonGroupsItem> Data;  // 0x0(0x10)
	struct FAccelByteModelsPaging Paging;  // 0x10(0x40)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsLobby.SetRematchmakingNotifDelegate
// Size: 0x10(Inherited: 0x0) 
struct FSetRematchmakingNotifDelegate
{
	struct FDelegate OnRematchmakingNotice;  // 0x0(0x10)

}; 
// DelegateFunction AccelByteUe4Sdk.DPlatformLinksHandler__DelegateSignature
// Size: 0x50(Inherited: 0x0) 
struct FDPlatformLinksHandler__DelegateSignature
{
	struct FPagedPlatformLinks PlatformLinks;  // 0x0(0x50)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsListBlockerResponse
// Size: 0x10(Inherited: 0x0) 
struct FAccelByteModelsListBlockerResponse
{
	struct TArray<struct FBlockerData> Data;  // 0x0(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsLobby.SetRequestFriendResponseDelegate
// Size: 0x10(Inherited: 0x0) 
struct FSetRequestFriendResponseDelegate
{
	struct FDelegate OnRequestFriendsResponseDelegate;  // 0x0(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsLobby.SetStartMatchmakingResponseDelegate
// Size: 0x10(Inherited: 0x0) 
struct FSetStartMatchmakingResponseDelegate
{
	struct FDelegate OnMatchmakingStart;  // 0x0(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsLobby.SetUnfriendResponseDelegate
// Size: 0x10(Inherited: 0x0) 
struct FSetUnfriendResponseDelegate
{
	struct FDelegate OnUnfriendResponse;  // 0x0(0x10)

}; 
// DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsLobby.UnfriendResponseDelegate__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FUnfriendResponseDelegate__DelegateSignature
{
	struct FAccelByteModelsUnfriendResponse Result;  // 0x0(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsSettings.GetAppId
// Size: 0x10(Inherited: 0x0) 
struct FGetAppId
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsLobby.SetUserPresenceResponse__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FSetUserPresenceResponse__DelegateSignature
{
	struct FAccelByteModelsSetOnlineUsersResponse Result;  // 0x0(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsSessionBrowserGameSetting
// Size: 0x68(Inherited: 0x0) 
struct FAccelByteModelsSessionBrowserGameSetting
{
	struct FString Mode;  // 0x0(0x10)
	struct FString Map_name;  // 0x10(0x10)
	int32_t Num_bot;  // 0x20(0x4)
	int32_t Max_player;  // 0x24(0x4)
	int32_t Current_player;  // 0x28(0x4)
	int32_t Max_internal_player;  // 0x2C(0x4)
	int32_t Current_internal_player;  // 0x30(0x4)
	char pad_52_1 : 7;  // 0x34(0x1)
	bool Allow_join_in_progress : 1;  // 0x34(0x1)
	char pad_53[3];  // 0x35(0x3)
	struct FString Password;  // 0x38(0x10)
	struct FJsonObjectWrapper Settings;  // 0x48(0x20)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsLobby.SetUserPresenceResponseDelegate
// Size: 0x10(Inherited: 0x0) 
struct FSetUserPresenceResponseDelegate
{
	struct FDelegate OnUserPresenceResponse;  // 0x0(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsCredentials.GetUserDisplayName
// Size: 0x10(Inherited: 0x0) 
struct FGetUserDisplayName
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsGetAllSessionAttributesResponse
// Size: 0x30(Inherited: 0x0) 
struct FAccelByteModelsGetAllSessionAttributesResponse
{
	struct FString Code;  // 0x0(0x10)
	struct FJsonObjectWrapper attributes;  // 0x10(0x20)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsLobby.Unfriend
// Size: 0x10(Inherited: 0x0) 
struct FUnfriend
{
	struct FString UserId;  // 0x0(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsPartyGetCodeResponse
// Size: 0x20(Inherited: 0x0) 
struct FAccelByteModelsPartyGetCodeResponse
{
	struct FString PartyCode;  // 0x0(0x10)
	struct FString Code;  // 0x10(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsOrder.CancelOrder
// Size: 0x30(Inherited: 0x0) 
struct FCancelOrder
{
	struct FString OrderNo;  // 0x0(0x10)
	struct FDelegate OnSuccess;  // 0x10(0x10)
	struct FDelegate OnError;  // 0x20(0x10)

}; 
// DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsOrder.CancelOrderSuccess__DelegateSignature
// Size: 0x2B0(Inherited: 0x0) 
struct FCancelOrderSuccess__DelegateSignature
{
	struct FAccelByteModelsOrderInfo Result;  // 0x0(0x2B0)

}; 
// ScriptStruct AccelByteUe4Sdk.RegisterRequest
// Size: 0x60(Inherited: 0x0) 
struct FRegisterRequest
{
	struct FString AuthType;  // 0x0(0x10)
	struct FString DisplayName;  // 0x10(0x10)
	struct FString EmailAddress;  // 0x20(0x10)
	struct FString Password;  // 0x30(0x10)
	struct FString Country;  // 0x40(0x10)
	struct FString DateOfBirth;  // 0x50(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsOrderInfo
// Size: 0x2B0(Inherited: 0x0) 
struct FAccelByteModelsOrderInfo
{
	struct FString OrderNo;  // 0x0(0x10)
	struct FString PaymentOrderNo;  // 0x10(0x10)
	struct FString Namespace;  // 0x20(0x10)
	struct FString UserId;  // 0x30(0x10)
	struct FString ItemId;  // 0x40(0x10)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool Sandbox : 1;  // 0x50(0x1)
	char pad_81[3];  // 0x51(0x3)
	int32_t Quantity;  // 0x54(0x4)
	int32_t Price;  // 0x58(0x4)
	int32_t DiscountedPrice;  // 0x5C(0x4)
	int32_t Vat;  // 0x60(0x4)
	int32_t SalesTax;  // 0x64(0x4)
	int32_t PaymentProviderFee;  // 0x68(0x4)
	int32_t PaymentMethodFee;  // 0x6C(0x4)
	struct FAccelByteModelsOrderCurrencySummary Currency;  // 0x70(0x40)
	struct FString PaymentStationUrl;  // 0xB0(0x10)
	struct FAccelByteModelsEntitlementItemSnapshot ItemSnapshot;  // 0xC0(0x178)
	struct FString Region;  // 0x238(0x10)
	struct FString Language;  // 0x248(0x10)
	uint8_t  Status;  // 0x258(0x1)
	char pad_601[7];  // 0x259(0x7)
	struct FString StatusReason;  // 0x260(0x10)
	struct FDateTime CreatedTime;  // 0x270(0x8)
	struct FDateTime ChargedTime;  // 0x278(0x8)
	struct FDateTime FulfilledTime;  // 0x280(0x8)
	struct FDateTime RefundedTime;  // 0x288(0x8)
	struct FDateTime ChargebackTime;  // 0x290(0x8)
	struct FDateTime ChargebackReversedTime;  // 0x298(0x8)
	struct FDateTime CreatedAt;  // 0x2A0(0x8)
	struct FDateTime UpdatedAt;  // 0x2A8(0x8)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsOrderCurrencySummary
// Size: 0x40(Inherited: 0x0) 
struct FAccelByteModelsOrderCurrencySummary
{
	struct FString CurrencyCode;  // 0x0(0x10)
	struct FString CurrencySymbol;  // 0x10(0x10)
	uint8_t  CurrencyType;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct FString Namespace;  // 0x28(0x10)
	int32_t Decimals;  // 0x38(0x4)
	char pad_60[4];  // 0x3C(0x4)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsMatchingAlly
// Size: 0x10(Inherited: 0x0) 
struct FAccelByteModelsMatchingAlly
{
	struct TArray<struct FAccelByteModelsMatchingParty> Matching_parties;  // 0x0(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsOrder.CreateNewOrder
// Size: 0x80(Inherited: 0x0) 
struct FCreateNewOrder
{
	struct FAccelByteModelsOrderCreate OrderCreate;  // 0x0(0x60)
	struct FDelegate OnSuccess;  // 0x60(0x10)
	struct FDelegate OnError;  // 0x70(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.JsonWebTokenResponse
// Size: 0x20(Inherited: 0x0) 
struct FJsonWebTokenResponse
{
	struct FString Jwt_token;  // 0x0(0x10)
	struct FString Session_id;  // 0x10(0x10)

}; 
// DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsOrder.CreateNewOrderSuccess__DelegateSignature
// Size: 0x2B0(Inherited: 0x0) 
struct FCreateNewOrderSuccess__DelegateSignature
{
	struct FAccelByteModelsOrderInfo Result;  // 0x0(0x2B0)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsReasonGroupsItem
// Size: 0x20(Inherited: 0x0) 
struct FAccelByteModelsReasonGroupsItem
{
	struct FString ID;  // 0x0(0x10)
	struct FString Title;  // 0x10(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsSessionBrowserCreateRequest
// Size: 0xA8(Inherited: 0x0) 
struct FAccelByteModelsSessionBrowserCreateRequest
{
	struct FString Namespace;  // 0x0(0x10)
	struct FString Session_type;  // 0x10(0x10)
	struct FString Username;  // 0x20(0x10)
	struct FString Game_version;  // 0x30(0x10)
	struct FAccelByteModelsSessionBrowserGameSetting Game_session_setting;  // 0x40(0x68)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsOrder.GetUserOrder
// Size: 0x30(Inherited: 0x0) 
struct FGetUserOrder
{
	struct FString OrderNo;  // 0x0(0x10)
	struct FDelegate OnSuccess;  // 0x10(0x10)
	struct FDelegate OnError;  // 0x20(0x10)

}; 
// DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsOrder.GetUserOrderSuccess__DelegateSignature
// Size: 0x2B0(Inherited: 0x0) 
struct FGetUserOrderSuccess__DelegateSignature
{
	struct FAccelByteModelsOrderInfo Result;  // 0x0(0x2B0)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsBulkUserStatusNotif
// Size: 0x20(Inherited: 0x0) 
struct FAccelByteModelsBulkUserStatusNotif
{
	struct TArray<struct FAccelByteModelsUserStatusNotif> Data;  // 0x0(0x10)
	int32_t Online;  // 0x10(0x4)
	int32_t Busy;  // 0x14(0x4)
	int32_t Invisible;  // 0x18(0x4)
	int32_t Offline;  // 0x1C(0x4)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsUserSeasonInfoWithoutReward
// Size: 0xD0(Inherited: 0x0) 
struct FAccelByteModelsUserSeasonInfoWithoutReward
{
	struct FString ID;  // 0x0(0x10)
	struct FString Namespace;  // 0x10(0x10)
	struct FString UserId;  // 0x20(0x10)
	struct FString SeasonId;  // 0x30(0x10)
	struct FDateTime EnrolledAt;  // 0x40(0x8)
	struct TArray<struct FString> EnrolledPasses;  // 0x48(0x10)
	int32_t CurrentTierIndex;  // 0x58(0x4)
	int32_t LastTierIndex;  // 0x5C(0x4)
	int32_t RequiredExp;  // 0x60(0x4)
	int32_t CurrentExp;  // 0x64(0x4)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool Cleared : 1;  // 0x68(0x1)
	char pad_105[7];  // 0x69(0x7)
	struct FAccelByteModelsSeason Season;  // 0x70(0x50)
	struct FDateTime CreatedAt;  // 0xC0(0x8)
	struct FDateTime UpdatedAt;  // 0xC8(0x8)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsSessionBrowserServer
// Size: 0x68(Inherited: 0x0) 
struct FAccelByteModelsSessionBrowserServer
{
	struct FString Ip;  // 0x0(0x10)
	int32_t Port;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct FString Region;  // 0x18(0x10)
	struct FString Status;  // 0x28(0x10)
	struct FString Pod_name;  // 0x38(0x10)
	struct FString Deployment;  // 0x48(0x10)
	struct FString Game_version;  // 0x58(0x10)

}; 
// DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsOrder.GetUserOrderHistorySuccess__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FGetUserOrderHistorySuccess__DelegateSignature
{
	struct TArray<struct FAccelByteModelsOrderHistoryInfo> Result;  // 0x0(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsSessionBrowserUpdateRequest
// Size: 0x8(Inherited: 0x0) 
struct FAccelByteModelsSessionBrowserUpdateRequest
{
	int32_t Game_current_player;  // 0x0(0x4)
	int32_t Game_max_player;  // 0x4(0x4)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsOrderHistoryInfo
// Size: 0x70(Inherited: 0x0) 
struct FAccelByteModelsOrderHistoryInfo
{
	struct FString OrderNo;  // 0x0(0x10)
	struct FString Operator;  // 0x10(0x10)
	struct FString Action;  // 0x20(0x10)
	struct FString Reason;  // 0x30(0x10)
	struct FString Namespace;  // 0x40(0x10)
	struct FString UserId;  // 0x50(0x10)
	struct FDateTime CreatedAt;  // 0x60(0x8)
	struct FDateTime UpdatedAt;  // 0x68(0x8)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsUserBannedNotification
// Size: 0x40(Inherited: 0x0) 
struct FAccelByteModelsUserBannedNotification
{
	struct FString UserId;  // 0x0(0x10)
	struct FString Namespace;  // 0x10(0x10)
	uint8_t  Ban;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct FString EndDate;  // 0x28(0x10)
	uint8_t  Reason;  // 0x38(0x1)
	char pad_57_1 : 7;  // 0x39(0x1)
	bool Enable : 1;  // 0x39(0x1)
	char pad_58[6];  // 0x3A(0x6)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsOrder.GetUserOrders
// Size: 0x28(Inherited: 0x0) 
struct FGetUserOrders
{
	int32_t Page;  // 0x0(0x4)
	int32_t Size;  // 0x4(0x4)
	struct FDelegate OnSuccess;  // 0x8(0x10)
	struct FDelegate OnError;  // 0x18(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsPagedOrderInfo
// Size: 0x50(Inherited: 0x0) 
struct FAccelByteModelsPagedOrderInfo
{
	struct TArray<struct FAccelByteModelsOrderInfo> Data;  // 0x0(0x10)
	struct FAccelByteModelsPaging Paging;  // 0x10(0x40)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsReward.GetRewardByRewardCode
// Size: 0x30(Inherited: 0x0) 
struct FGetRewardByRewardCode
{
	struct FString RewardCode;  // 0x0(0x10)
	struct FDelegate OnSuccess;  // 0x10(0x10)
	struct FDelegate OnError;  // 0x20(0x10)

}; 
// DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsReward.GetRewardByRewardCodeSuccess__DelegateSignature
// Size: 0x78(Inherited: 0x0) 
struct FGetRewardByRewardCodeSuccess__DelegateSignature
{
	struct FAccelByteModelsRewardInfo Result;  // 0x0(0x78)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsQosServerList
// Size: 0x10(Inherited: 0x0) 
struct FAccelByteModelsQosServerList
{
	struct TArray<struct FAccelByteModelsQosServer> Servers;  // 0x0(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsRewardItem
// Size: 0x18(Inherited: 0x0) 
struct FAccelByteModelsRewardItem
{
	struct FString ItemId;  // 0x0(0x10)
	int32_t Quantity;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsEntitlementSummary
// Size: 0x70(Inherited: 0x0) 
struct FAccelByteModelsEntitlementSummary
{
	struct FString ID;  // 0x0(0x10)
	struct FString ItemId;  // 0x10(0x10)
	struct FString Namespace;  // 0x20(0x10)
	struct FString UserId;  // 0x30(0x10)
	uint8_t  Clazz;  // 0x40(0x1)
	uint8_t  Type;  // 0x41(0x1)
	char pad_66_1 : 7;  // 0x42(0x1)
	bool Stackable : 1;  // 0x42(0x1)
	char pad_67[1];  // 0x43(0x1)
	int32_t StackedUseCount;  // 0x44(0x4)
	int32_t StackedQuantity;  // 0x48(0x4)
	char pad_76[4];  // 0x4C(0x4)
	struct FString CreatedAt;  // 0x50(0x10)
	struct FString GrantedCode;  // 0x60(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccountLinkedPlatform
// Size: 0x20(Inherited: 0x0) 
struct FAccountLinkedPlatform
{
	struct FString Namespace;  // 0x0(0x10)
	struct FString PlatformUserId;  // 0x10(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsQueryRewardPaging
// Size: 0x20(Inherited: 0x0) 
struct FAccelByteModelsQueryRewardPaging
{
	struct FString Previous;  // 0x0(0x10)
	struct FString Next;  // 0x10(0x10)

}; 
// DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsStatistic.BulkAddUserStatItemValueSuccess__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FBulkAddUserStatItemValueSuccess__DelegateSignature
{
	struct TArray<struct FAccelByteModelsBulkStatItemOperationResult> Result;  // 0x0(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsBulkStatItemOperationResult
// Size: 0x68(Inherited: 0x0) 
struct FAccelByteModelsBulkStatItemOperationResult
{
	struct TMap<struct FString, struct FString> Details;  // 0x0(0x50)
	struct FString StatCode;  // 0x50(0x10)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool Success : 1;  // 0x60(0x1)
	char pad_97[7];  // 0x61(0x7)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsReasonItem
// Size: 0x20(Inherited: 0x0) 
struct FAccelByteModelsReasonItem
{
	struct FString Title;  // 0x0(0x10)
	struct FString Description;  // 0x10(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsStatistic.CreateUserStatItems
// Size: 0x30(Inherited: 0x0) 
struct FCreateUserStatItems
{
	struct TArray<struct FString> StatCodes;  // 0x0(0x10)
	struct FDelegate OnSuccess;  // 0x10(0x10)
	struct FDelegate OnError;  // 0x20(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsUser
// Size: 0x10(Inherited: 0x0) 
struct FAccelByteModelsUser
{
	struct FString User_id;  // 0x0(0x10)

}; 
// DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsStatistic.CreateUserStatItemsSuccess__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FCreateUserStatItemsSuccess__DelegateSignature
{
	struct TArray<struct FAccelByteModelsBulkStatItemOperationResult> Result;  // 0x0(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsSettings.SetPublisherNamespace
// Size: 0x10(Inherited: 0x0) 
struct FSetPublisherNamespace
{
	struct FString PublisherNamespace;  // 0x0(0x10)

}; 
// DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsStatistic.GetAllUserStatItemsSuccess__DelegateSignature
// Size: 0x50(Inherited: 0x0) 
struct FGetAllUserStatItemsSuccess__DelegateSignature
{
	struct FAccelByteModelsUserStatItemPagingSlicedResult Result;  // 0x0(0x50)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsUserStatItemPagingSlicedResult
// Size: 0x50(Inherited: 0x0) 
struct FAccelByteModelsUserStatItemPagingSlicedResult
{
	struct TArray<struct FAccelByteModelsUserStatItemInfo> Data;  // 0x0(0x10)
	struct FAccelByteModelsPaging Paging;  // 0x10(0x40)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsStatistic.IncrementUserStatItems
// Size: 0x30(Inherited: 0x0) 
struct FIncrementUserStatItems
{
	struct TArray<struct FAccelByteModelsBulkStatItemInc> Data;  // 0x0(0x10)
	struct FDelegate OnSuccess;  // 0x10(0x10)
	struct FDelegate OnError;  // 0x20(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsUserStatItemInfo
// Size: 0x78(Inherited: 0x0) 
struct FAccelByteModelsUserStatItemInfo
{
	struct FString CreatedAt;  // 0x0(0x10)
	struct FString Namespace;  // 0x10(0x10)
	struct FString UserId;  // 0x20(0x10)
	struct FString StatCode;  // 0x30(0x10)
	struct FString StatName;  // 0x40(0x10)
	struct TArray<struct FString> Tags;  // 0x50(0x10)
	struct FString UpdatedAt;  // 0x60(0x10)
	float Value;  // 0x70(0x4)
	char pad_116[4];  // 0x74(0x4)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsStatistic.GetUserStatItems
// Size: 0x40(Inherited: 0x0) 
struct FGetUserStatItems
{
	struct TArray<struct FString> StatCodes;  // 0x0(0x10)
	struct TArray<struct FString> Tags;  // 0x10(0x10)
	struct FDelegate OnSuccess;  // 0x20(0x10)
	struct FDelegate OnError;  // 0x30(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsSettings.SetLeaderboardServerUrl
// Size: 0x10(Inherited: 0x0) 
struct FSetLeaderboardServerUrl
{
	struct FString LeaderboardServerUrl;  // 0x0(0x10)

}; 
// DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsStatistic.GetUserStatItemsSuccess__DelegateSignature
// Size: 0x50(Inherited: 0x0) 
struct FGetUserStatItemsSuccess__DelegateSignature
{
	struct FAccelByteModelsUserStatItemPagingSlicedResult Result;  // 0x0(0x50)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsBulkStatItemInc
// Size: 0x18(Inherited: 0x0) 
struct FAccelByteModelsBulkStatItemInc
{
	float inc;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FString StatCode;  // 0x8(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsSessionBrowserRecentPlayerData
// Size: 0x20(Inherited: 0x0) 
struct FAccelByteModelsSessionBrowserRecentPlayerData
{
	struct FString Other_id;  // 0x0(0x10)
	struct FString Other_display_name;  // 0x10(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsUGCCreatorState
// Size: 0x18(Inherited: 0x0) 
struct FAccelByteModelsUGCCreatorState
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool State : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FString UserId;  // 0x8(0x10)

}; 
// DelegateFunction AccelByteUe4Sdk.DUserDataHandler__DelegateSignature
// Size: 0xE0(Inherited: 0x0) 
struct FDUserDataHandler__DelegateSignature
{
	struct FAccountUserData Result;  // 0x0(0xE0)

}; 
// ScriptStruct AccelByteUe4Sdk.AccountUserData
// Size: 0xE0(Inherited: 0x0) 
struct FAccountUserData
{
	struct FString AuthType;  // 0x0(0x10)
	struct TArray<struct FBan> Bans;  // 0x10(0x10)
	struct FString CreatedAt;  // 0x20(0x10)
	struct FString DisplayName;  // 0x30(0x10)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool EmailVerified : 1;  // 0x40(0x1)
	char pad_65_1 : 7;  // 0x41(0x1)
	bool Enabled : 1;  // 0x41(0x1)
	char pad_66[6];  // 0x42(0x6)
	struct FString LastEnabledChangedTime;  // 0x48(0x10)
	struct FString LoginId;  // 0x58(0x10)
	struct FString Namespace;  // 0x68(0x10)
	struct TArray<struct FPermission> Permissions;  // 0x78(0x10)
	char pad_136_1 : 7;  // 0x88(0x1)
	bool PhoneVerified : 1;  // 0x88(0x1)
	char pad_137[7];  // 0x89(0x7)
	struct FString PlatformId;  // 0x90(0x10)
	struct FString PlatformUserId;  // 0xA0(0x10)
	struct TArray<struct FString> Roles;  // 0xB0(0x10)
	struct FString UserId;  // 0xC0(0x10)
	struct FString Username;  // 0xD0(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.Permission
// Size: 0x40(Inherited: 0x0) 
struct FPermission
{
	int32_t Action;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FString Resource;  // 0x8(0x10)
	int32_t SchedAction;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct FString SchedCron;  // 0x20(0x10)
	struct TArray<struct FString> SchedRange;  // 0x30(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.Ban
// Size: 0x30(Inherited: 0x0) 
struct FBan
{
	struct FString Ban;  // 0x0(0x10)
	struct FString BanId;  // 0x10(0x10)
	struct FString EndDate;  // 0x20(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsSettings.SetClientSecret
// Size: 0x10(Inherited: 0x0) 
struct FSetClientSecret
{
	struct FString ClientSecret;  // 0x0(0x10)

}; 
// DelegateFunction AccelByteUe4Sdk.DUserRegisterHandler__DelegateSignature
// Size: 0x80(Inherited: 0x0) 
struct FDUserRegisterHandler__DelegateSignature
{
	struct FRegisterResponse Result;  // 0x0(0x80)

}; 
// ScriptStruct AccelByteUe4Sdk.PagedPlatformLinks
// Size: 0x50(Inherited: 0x0) 
struct FPagedPlatformLinks
{
	struct TArray<struct FPlatformLink> Data;  // 0x0(0x10)
	struct FAccelByteModelsPaging Paging;  // 0x10(0x40)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsSettings.GetAchievementServerUrl
// Size: 0x10(Inherited: 0x0) 
struct FGetAchievementServerUrl
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.PlatformLink
// Size: 0x90(Inherited: 0x0) 
struct FPlatformLink
{
	struct FString DisplayName;  // 0x0(0x10)
	struct FString EmailAddress;  // 0x10(0x10)
	struct FString LinkedAt;  // 0x20(0x10)
	struct FString Namespace;  // 0x30(0x10)
	struct FString OriginNamespace;  // 0x40(0x10)
	struct FString PlatformId;  // 0x50(0x10)
	struct FString PlatformUserId;  // 0x60(0x10)
	struct FString UserId;  // 0x70(0x10)
	struct FString AccountGroup;  // 0x80(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsPartyRejectNotice
// Size: 0x30(Inherited: 0x0) 
struct FAccelByteModelsPartyRejectNotice
{
	struct FString PartyId;  // 0x0(0x10)
	struct FString LeaderId;  // 0x10(0x10)
	struct FString UserId;  // 0x20(0x10)

}; 
// DelegateFunction AccelByteUe4Sdk.DUserEligiblePlayHandler__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FDUserEligiblePlayHandler__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Result : 1;  // 0x0(0x1)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsUserProfile.CreateUserProfile
// Size: 0xA0(Inherited: 0x0) 
struct FCreateUserProfile
{
	struct FAccelByteModelsUserProfileCreateRequest ProfileCreateRequest;  // 0x0(0x80)
	struct FDelegate OnSuccess;  // 0x80(0x10)
	struct FDelegate OnError;  // 0x90(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.BulkPlatformUserIdResponse
// Size: 0x10(Inherited: 0x0) 
struct FBulkPlatformUserIdResponse
{
	struct TArray<struct FPlatformUserIdMap> UserIdPlatforms;  // 0x0(0x10)

}; 
// DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsUserProfile.CreateUserProfileSuccess__DelegateSignature
// Size: 0xB0(Inherited: 0x0) 
struct FCreateUserProfileSuccess__DelegateSignature
{
	struct FAccelByteModelsUserProfileInfo Result;  // 0x0(0xB0)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsUserProfileCreateRequest
// Size: 0x80(Inherited: 0x0) 
struct FAccelByteModelsUserProfileCreateRequest
{
	struct FString FirstName;  // 0x0(0x10)
	struct FString LastName;  // 0x10(0x10)
	struct FString Language;  // 0x20(0x10)
	struct FString AvatarSmallUrl;  // 0x30(0x10)
	struct FString avatarUrl;  // 0x40(0x10)
	struct FString AvatarLargeUrl;  // 0x50(0x10)
	struct FString TimeZone;  // 0x60(0x10)
	struct FString DateOfBirth;  // 0x70(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsUserProfile.GetUserProfile
// Size: 0x20(Inherited: 0x0) 
struct FGetUserProfile
{
	struct FDelegate OnSuccess;  // 0x0(0x10)
	struct FDelegate OnError;  // 0x10(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsSettings.GetTurnManagerServerUrl
// Size: 0x10(Inherited: 0x0) 
struct FGetTurnManagerServerUrl
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsCreditUserWalletRequest
// Size: 0x18(Inherited: 0x0) 
struct FAccelByteModelsCreditUserWalletRequest
{
	int32_t Amount;  // 0x0(0x4)
	uint8_t  Source;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct FString Reason;  // 0x8(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsUserProfile.UpdateUserProfile
// Size: 0xA0(Inherited: 0x0) 
struct FUpdateUserProfile
{
	struct FAccelByteModelsUserProfileUpdateRequest ProfileUpdateRequest;  // 0x0(0x80)
	struct FDelegate OnSuccess;  // 0x80(0x10)
	struct FDelegate OnError;  // 0x90(0x10)

}; 
// DelegateFunction AccelByteUe4Sdk.AccelByteBlueprintsUserProfile.UpdateUserProfileSuccess__DelegateSignature
// Size: 0xB0(Inherited: 0x0) 
struct FUpdateUserProfileSuccess__DelegateSignature
{
	struct FAccelByteModelsUserProfileInfo Result;  // 0x0(0xB0)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsUGCRequest
// Size: 0x60(Inherited: 0x0) 
struct FAccelByteModelsUGCRequest
{
	struct FString FileExtension;  // 0x0(0x10)
	struct FString Name;  // 0x10(0x10)
	struct FString Preview;  // 0x20(0x10)
	struct FString Type;  // 0x30(0x10)
	struct FString Subtype;  // 0x40(0x10)
	struct TArray<struct FString> Tags;  // 0x50(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsSettings.GetQosManagerServerUrl
// Size: 0x10(Inherited: 0x0) 
struct FGetQosManagerServerUrl
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsUserProfileUpdateRequest
// Size: 0x80(Inherited: 0x0) 
struct FAccelByteModelsUserProfileUpdateRequest
{
	struct FString FirstName;  // 0x0(0x10)
	struct FString LastName;  // 0x10(0x10)
	struct FString AvatarSmallUrl;  // 0x20(0x10)
	struct FString avatarUrl;  // 0x30(0x10)
	struct FString AvatarLargeUrl;  // 0x40(0x10)
	struct FString Language;  // 0x50(0x10)
	struct FString TimeZone;  // 0x60(0x10)
	struct FString DateOfBirth;  // 0x70(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.BasicUserInfo
// Size: 0x50(Inherited: 0x0) 
struct FBasicUserInfo
{
	struct FString avatarUrl;  // 0x0(0x10)
	struct FString DisplayName;  // 0x10(0x10)
	struct FString UserId;  // 0x20(0x10)
	struct FJsonObjectWrapper PlatformUserIds;  // 0x30(0x20)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsWalletInfo
// Size: 0x70(Inherited: 0x0) 
struct FAccelByteModelsWalletInfo
{
	struct FString ID;  // 0x0(0x10)
	struct FString Namespace;  // 0x10(0x10)
	struct FString UserId;  // 0x20(0x10)
	struct FString CurrencyCode;  // 0x30(0x10)
	struct FString CurrencySymbol;  // 0x40(0x10)
	int64_t Balance;  // 0x50(0x8)
	struct FDateTime CreatedAt;  // 0x58(0x8)
	struct FDateTime UpdatedAt;  // 0x60(0x8)
	uint8_t  Status;  // 0x68(0x1)
	char pad_105[7];  // 0x69(0x7)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsLocalizedPolicyVersionObject
// Size: 0x90(Inherited: 0x0) 
struct FAccelByteModelsLocalizedPolicyVersionObject
{
	struct FString ID;  // 0x0(0x10)
	struct FDateTime CreatedAt;  // 0x10(0x8)
	struct FDateTime UpdatedAt;  // 0x18(0x8)
	struct FString LocaleCode;  // 0x20(0x10)
	struct FString ContentType;  // 0x30(0x10)
	struct FString AttachmentLocation;  // 0x40(0x10)
	struct FString AttachmentVersionIdentifier;  // 0x50(0x10)
	struct FString Description;  // 0x60(0x10)
	struct FString Status;  // 0x70(0x10)
	struct FDateTime PublishedDate;  // 0x80(0x8)
	char pad_136_1 : 7;  // 0x88(0x1)
	bool IsDefaultSelection : 1;  // 0x88(0x1)
	char pad_137[7];  // 0x89(0x7)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsPublicPolicy
// Size: 0xC0(Inherited: 0x0) 
struct FAccelByteModelsPublicPolicy
{
	struct FString ID;  // 0x0(0x10)
	struct FDateTime CreatedAt;  // 0x10(0x8)
	struct FDateTime UpdatedAt;  // 0x18(0x8)
	struct FString ReadableId;  // 0x20(0x10)
	struct FString PolicyName;  // 0x30(0x10)
	struct FString PolicyType;  // 0x40(0x10)
	struct FString Namespace;  // 0x50(0x10)
	struct FString CountryCode;  // 0x60(0x10)
	struct FString CountryGroupCode;  // 0x70(0x10)
	struct TArray<struct FString> BaseUrls;  // 0x80(0x10)
	char pad_144_1 : 7;  // 0x90(0x1)
	bool ShouldNotifyOnUpdate : 1;  // 0x90(0x1)
	char pad_145[7];  // 0x91(0x7)
	struct TArray<struct FAccelByteModelsPolicyVersionWithLocalizedVersionObject> PolicyVersions;  // 0x98(0x10)
	struct FString Description;  // 0xA8(0x10)
	char pad_184_1 : 7;  // 0xB8(0x1)
	bool IsMandatory : 1;  // 0xB8(0x1)
	char pad_185_1 : 7;  // 0xB9(0x1)
	bool IsDefaultOpted : 1;  // 0xB9(0x1)
	char pad_186_1 : 7;  // 0xBA(0x1)
	bool IsDefaultSelection : 1;  // 0xBA(0x1)
	char pad_187[5];  // 0xBB(0x5)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsAcceptAgreementResponse
// Size: 0x1(Inherited: 0x0) 
struct FAccelByteModelsAcceptAgreementResponse
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Proceed : 1;  // 0x0(0x1)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsAcceptAgreementRequest
// Size: 0x38(Inherited: 0x0) 
struct FAccelByteModelsAcceptAgreementRequest
{
	struct FString LocalizedPolicyVersionId;  // 0x0(0x10)
	struct FString PolicyVersionId;  // 0x10(0x10)
	struct FString PolicyId;  // 0x20(0x10)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool IsAccepted : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsUserPoint
// Size: 0x18(Inherited: 0x0) 
struct FAccelByteModelsUserPoint
{
	float Point;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FString UserId;  // 0x8(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsLobbySessionId
// Size: 0x10(Inherited: 0x0) 
struct FAccelByteModelsLobbySessionId
{
	struct FString LobbySessionID;  // 0x0(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsDSHubMessage
// Size: 0x30(Inherited: 0x0) 
struct FAccelByteModelsDSHubMessage
{
	struct FString Topic;  // 0x0(0x10)
	struct FJsonObjectWrapper Payload;  // 0x10(0x20)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsServerSessionResponse
// Size: 0x10(Inherited: 0x0) 
struct FAccelByteModelsServerSessionResponse
{
	struct FString Session_id;  // 0x0(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.Oauth2Token
// Size: 0xB8(Inherited: 0x0) 
struct FOauth2Token
{
	struct FString Access_token;  // 0x0(0x10)
	struct FString Refresh_token;  // 0x10(0x10)
	struct FString Token_type;  // 0x20(0x10)
	float Expires_in;  // 0x30(0x4)
	char pad_52_1 : 7;  // 0x34(0x1)
	bool Is_comply : 1;  // 0x34(0x1)
	char pad_53[3];  // 0x35(0x3)
	struct TArray<struct FOauth2TokenPermission> Permissions;  // 0x38(0x10)
	struct TArray<struct FString> Roles;  // 0x48(0x10)
	struct TArray<struct FOauth2TokenBan> Bans;  // 0x58(0x10)
	struct FString User_id;  // 0x68(0x10)
	struct FString Display_name;  // 0x78(0x10)
	struct FString Namespace;  // 0x88(0x10)
	struct FString Platform_id;  // 0x98(0x10)
	struct FString Platform_user_id;  // 0xA8(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsRegisterServerRequest
// Size: 0xC8(Inherited: 0x0) 
struct FAccelByteModelsRegisterServerRequest
{
	struct FString Game_version;  // 0x0(0x10)
	struct FString Ip;  // 0x10(0x10)
	struct FString Pod_name;  // 0x20(0x10)
	int32_t Port;  // 0x30(0x4)
	char pad_52[4];  // 0x34(0x4)
	struct FString Provider;  // 0x38(0x10)
	struct FString Allocation_id;  // 0x48(0x10)
	struct FString Public_Ip;  // 0x58(0x10)
	struct TMap<struct FString, struct FString> Ports;  // 0x68(0x50)
	struct FString Custom_attribute;  // 0xB8(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsDSMClient
// Size: 0x40(Inherited: 0x0) 
struct FAccelByteModelsDSMClient
{
	struct FString Host_address;  // 0x0(0x10)
	struct FString Region;  // 0x10(0x10)
	struct FString Provider;  // 0x20(0x10)
	struct FString Status;  // 0x30(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsMatchRequest
// Size: 0x40(Inherited: 0x0) 
struct FAccelByteModelsMatchRequest
{
	struct FString Session_id;  // 0x0(0x10)
	struct FString Namespace;  // 0x10(0x10)
	struct FString Game_mode;  // 0x20(0x10)
	struct TArray<struct FAccelByteModelsMatchingAlly> Matching_allies;  // 0x30(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsSettings.GetPublisherNamespace
// Size: 0x10(Inherited: 0x0) 
struct FGetPublisherNamespace
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsMatchingParty
// Size: 0x50(Inherited: 0x0) 
struct FAccelByteModelsMatchingParty
{
	struct FString Party_id;  // 0x0(0x10)
	struct FString Ticket_id;  // 0x10(0x10)
	struct TArray<struct FAccelByteModelsUser> Party_members;  // 0x20(0x10)
	struct FJsonObjectWrapper Party_attributes;  // 0x30(0x20)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsReportingSubmitResponse
// Size: 0x78(Inherited: 0x0) 
struct FAccelByteModelsReportingSubmitResponse
{
	uint8_t  Category;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FString Namespace;  // 0x8(0x10)
	struct FString ObjectID;  // 0x18(0x10)
	struct FString ObjectType;  // 0x28(0x10)
	struct FString Status;  // 0x38(0x10)
	struct FString TicketId;  // 0x48(0x10)
	struct FString UpdateAt;  // 0x58(0x10)
	struct FString UserId;  // 0x68(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsDeregisterLocalServerRequest
// Size: 0x10(Inherited: 0x0) 
struct FAccelByteModelsDeregisterLocalServerRequest
{
	struct FString Name;  // 0x0(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsUGCResponse
// Size: 0xE0(Inherited: 0x0) 
struct FAccelByteModelsUGCResponse
{
	struct FString ChannelId;  // 0x0(0x10)
	struct FDateTime CreatedTime;  // 0x10(0x8)
	struct FString CreatorName;  // 0x18(0x10)
	struct FString FileExtension;  // 0x28(0x10)
	struct FString ID;  // 0x38(0x10)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool IsOfficial : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)
	struct FString Name;  // 0x50(0x10)
	struct FString Namespace;  // 0x60(0x10)
	struct TArray<struct FAccelByteModelsUGCPayloadUrl> PayloadUrl;  // 0x70(0x10)
	struct FString Preview;  // 0x80(0x10)
	struct FString ShareCode;  // 0x90(0x10)
	struct FString Subtype;  // 0xA0(0x10)
	struct TArray<struct FString> Tags;  // 0xB0(0x10)
	struct FString Type;  // 0xC0(0x10)
	struct FString UserId;  // 0xD0(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsShutdownServerRequest
// Size: 0x28(Inherited: 0x0) 
struct FAccelByteModelsShutdownServerRequest
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Kill_me : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FString Pod_name;  // 0x8(0x10)
	struct FString Session_id;  // 0x18(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsEntitlementOwnership
// Size: 0x10(Inherited: 0x0) 
struct FAccelByteModelsEntitlementOwnership
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Owned : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FDateTime EndDate;  // 0x8(0x8)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsRegisterLocalServerRequest
// Size: 0x28(Inherited: 0x0) 
struct FAccelByteModelsRegisterLocalServerRequest
{
	struct FString Ip;  // 0x0(0x10)
	struct FString Name;  // 0x10(0x10)
	int32_t Port;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsTicketStatusResponse
// Size: 0x18(Inherited: 0x0) 
struct FAccelByteModelsTicketStatusResponse
{
	struct FString Code;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool isInMatchmaking : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsFulfillmentResult
// Size: 0x80(Inherited: 0x0) 
struct FAccelByteModelsFulfillmentResult
{
	struct FString Namespace;  // 0x0(0x10)
	struct FString UserId;  // 0x10(0x10)
	struct TArray<struct FAccelByteModelsEntitlementSummary> EntitlementSummaries;  // 0x20(0x10)
	struct TArray<struct FAccelByteModelsCreditSummary> CreditSummaries;  // 0x30(0x10)
	struct FJsonObjectWrapper SubscriptionSummaries;  // 0x40(0x20)
	struct FJsonObjectWrapper Customizations;  // 0x60(0x20)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsCreditSummary
// Size: 0x38(Inherited: 0x0) 
struct FAccelByteModelsCreditSummary
{
	struct FString WalletId;  // 0x0(0x10)
	struct FString Namespace;  // 0x10(0x10)
	struct FString UserId;  // 0x20(0x10)
	int32_t Amount;  // 0x30(0x4)
	char pad_52[4];  // 0x34(0x4)

}; 
// ScriptStruct AccelByteUe4Sdk.AcceptedPolicies
// Size: 0x38(Inherited: 0x0) 
struct FAcceptedPolicies
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool IsAccepted : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FString LocalizedPolicyVersionId;  // 0x8(0x10)
	struct FString PolicyVersionId;  // 0x18(0x10)
	struct FString PolicyId;  // 0x28(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsFulfillmentRequest
// Size: 0x50(Inherited: 0x0) 
struct FAccelByteModelsFulfillmentRequest
{
	struct FString ItemId;  // 0x0(0x10)
	int32_t Quantity;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct FString OrderNo;  // 0x18(0x10)
	uint8_t  Source;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct FString Region;  // 0x30(0x10)
	struct FString Language;  // 0x40(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsDebitUserWalletRequest
// Size: 0x18(Inherited: 0x0) 
struct FAccelByteModelsDebitUserWalletRequest
{
	int32_t Amount;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FString Reason;  // 0x8(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsStatItemIncResult
// Size: 0x4(Inherited: 0x0) 
struct FAccelByteModelsStatItemIncResult
{
	float currentValue;  // 0x0(0x4)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsOrderInfoTransaction
// Size: 0x110(Inherited: 0x0) 
struct FAccelByteModelsOrderInfoTransaction
{
	struct FString TransactionId;  // 0x0(0x10)
	int32_t Amount;  // 0x10(0x4)
	int32_t Vat;  // 0x14(0x4)
	int32_t SalesTax;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct FAccelByteModelsOrderCurrencySummary Currency;  // 0x20(0x40)
	struct FString Type;  // 0x60(0x10)
	struct FString Status;  // 0x70(0x10)
	struct FString Provider;  // 0x80(0x10)
	int32_t PaymentProviderFee;  // 0x90(0x4)
	char pad_148[4];  // 0x94(0x4)
	struct FString PaymentMethod;  // 0x98(0x10)
	int32_t PaymentMethodFee;  // 0xA8(0x4)
	char pad_172[4];  // 0xAC(0x4)
	struct FString MerchantId;  // 0xB0(0x10)
	struct FString ExternalTransactionId;  // 0xC0(0x10)
	struct FString ExternalStatusCode;  // 0xD0(0x10)
	struct FString ExternalMessage;  // 0xE0(0x10)
	struct FString TransactionStartTime;  // 0xF0(0x10)
	struct FString TransactionEndTime;  // 0x100(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsTwitchDropEntitlement
// Size: 0x10(Inherited: 0x0) 
struct FAccelByteModelsTwitchDropEntitlement
{
	struct FString GameId;  // 0x0(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsUserRanking
// Size: 0x8(Inherited: 0x0) 
struct FAccelByteModelsUserRanking
{
	float Point;  // 0x0(0x4)
	int32_t rank;  // 0x4(0x4)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsPlatformSyncMobileGoogle
// Size: 0x68(Inherited: 0x0) 
struct FAccelByteModelsPlatformSyncMobileGoogle
{
	struct FString OrderId;  // 0x0(0x10)
	struct FString PackageName;  // 0x10(0x10)
	struct FString ProductId;  // 0x20(0x10)
	int64_t PurchaseTime;  // 0x30(0x8)
	struct FString PurchaseToken;  // 0x38(0x10)
	struct FString Region;  // 0x48(0x10)
	struct FString Language;  // 0x58(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsPlatformSyncMobileApple
// Size: 0x58(Inherited: 0x0) 
struct FAccelByteModelsPlatformSyncMobileApple
{
	struct FString ProductId;  // 0x0(0x10)
	struct FString TransactionId;  // 0x10(0x10)
	struct FString ReceiptData;  // 0x20(0x10)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool ExcludeOldTransactions : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)
	struct FString Region;  // 0x38(0x10)
	struct FString Language;  // 0x48(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsSettings.GetSessionManagerServerUrl
// Size: 0x10(Inherited: 0x0) 
struct FGetSessionManagerServerUrl
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsDistributionReceiver
// Size: 0x70(Inherited: 0x0) 
struct FAccelByteModelsDistributionReceiver
{
	struct FString UserId;  // 0x0(0x10)
	struct FString Namespace;  // 0x10(0x10)
	struct FString ExtUserId;  // 0x20(0x10)
	struct FAccelByteModelsAttributes attributes;  // 0x30(0x40)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsAttributes
// Size: 0x40(Inherited: 0x0) 
struct FAccelByteModelsAttributes
{
	struct FString ServerId;  // 0x0(0x10)
	struct FString ServerName;  // 0x10(0x10)
	struct FString CharacterId;  // 0x20(0x10)
	struct FString CharacterName;  // 0x30(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsDistributionAttributes
// Size: 0x40(Inherited: 0x0) 
struct FAccelByteModelsDistributionAttributes
{
	struct FAccelByteModelsAttributes attributes;  // 0x0(0x40)

}; 
// ScriptStruct AccelByteUe4Sdk.Oauth2TokenPermission
// Size: 0x18(Inherited: 0x0) 
struct FOauth2TokenPermission
{
	struct FString Resource;  // 0x0(0x10)
	int32_t Action;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsStackableEntitlementInfo
// Size: 0x280(Inherited: 0x0) 
struct FAccelByteModelsStackableEntitlementInfo
{
	struct FString ID;  // 0x0(0x10)
	struct FString Namespace;  // 0x10(0x10)
	uint8_t  Clazz;  // 0x20(0x1)
	uint8_t  Type;  // 0x21(0x1)
	uint8_t  Status;  // 0x22(0x1)
	char pad_35[5];  // 0x23(0x5)
	struct FString AppId;  // 0x28(0x10)
	uint8_t  AppType;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct FString Sku;  // 0x40(0x10)
	struct FString UserId;  // 0x50(0x10)
	struct FString ItemId;  // 0x60(0x10)
	struct FString GrantedCode;  // 0x70(0x10)
	struct FString ItemNamespace;  // 0x80(0x10)
	struct FString Name;  // 0x90(0x10)
	int32_t UseCount;  // 0xA0(0x4)
	int32_t Quantity;  // 0xA4(0x4)
	uint8_t  Source;  // 0xA8(0x1)
	char pad_169[3];  // 0xA9(0x3)
	int32_t DistributedQuantity;  // 0xAC(0x4)
	struct FString TargetNamespace;  // 0xB0(0x10)
	struct FAccelByteModelsEntitlementItemSnapshot ItemSnapshot;  // 0xC0(0x178)
	struct FString StartDate;  // 0x238(0x10)
	struct FString EndDate;  // 0x248(0x10)
	char pad_600_1 : 7;  // 0x258(0x1)
	bool Stackable : 1;  // 0x258(0x1)
	char pad_601[7];  // 0x259(0x7)
	struct FDateTime GrantedAt;  // 0x260(0x8)
	struct FDateTime CreatedAt;  // 0x268(0x8)
	struct FDateTime UpdatedAt;  // 0x270(0x8)
	int32_t StackedUseCount;  // 0x278(0x4)
	int32_t StackedQuantity;  // 0x27C(0x4)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsEntitlementGrant
// Size: 0x58(Inherited: 0x0) 
struct FAccelByteModelsEntitlementGrant
{
	struct FString ItemId;  // 0x0(0x10)
	struct FString GrantedCode;  // 0x10(0x10)
	struct FString ItemNamespace;  // 0x20(0x10)
	int32_t Quantity;  // 0x30(0x4)
	uint8_t  Source;  // 0x34(0x1)
	char pad_53[3];  // 0x35(0x3)
	struct FString Region;  // 0x38(0x10)
	struct FString Language;  // 0x48(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsConsumeUserEntitlementRequest
// Size: 0x4(Inherited: 0x0) 
struct FAccelByteModelsConsumeUserEntitlementRequest
{
	int32_t UseCount;  // 0x0(0x4)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsSettings.SetGeneralTimeout
// Size: 0x4(Inherited: 0x0) 
struct FSetGeneralTimeout
{
	float Timeout;  // 0x0(0x4)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsEntitlementSyncBase
// Size: 0x80(Inherited: 0x0) 
struct FAccelByteModelsEntitlementSyncBase
{
	struct FString ProductId;  // 0x0(0x10)
	int32_t Price;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct FString CurrencyCode;  // 0x18(0x10)
	struct FString XstsToken;  // 0x28(0x10)
	int32_t ServiceLabel;  // 0x38(0x4)
	char pad_60[4];  // 0x3C(0x4)
	struct FString CreatorCode;  // 0x40(0x10)
	struct FString CreatorId;  // 0x50(0x10)
	struct FString PlayerName;  // 0x60(0x10)
	struct FString ProductName;  // 0x70(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteErrorInfo
// Size: 0x40(Inherited: 0x0) 
struct FAccelByteErrorInfo
{
	int32_t NumericErrorCode;  // 0x0(0x4)
	int32_t ErrorCode;  // 0x4(0x4)
	int32_t Code;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct FString ErrorMessage;  // 0x10(0x10)
	struct FString Message;  // 0x20(0x10)
	struct FString Error;  // 0x30(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsFeedStatus
// Size: 0x90(Inherited: 0x0) 
struct FAccelByteModelsFeedStatus
{
	struct FDateTime StartAt;  // 0x0(0x8)
	struct FDateTime EndAt;  // 0x8(0x8)
	struct FText Title;  // 0x10(0x18)
	struct FText Description;  // 0x28(0x18)
	struct FString ImageUrl;  // 0x40(0x10)
	struct FString ActionType;  // 0x50(0x10)
	struct FText ActionTitle;  // 0x60(0x18)
	struct FString ActionValue;  // 0x78(0x10)
	char pad_136_1 : 7;  // 0x88(0x1)
	bool Draft : 1;  // 0x88(0x1)
	char pad_137[7];  // 0x89(0x7)

}; 
// ScriptStruct AccelByteUe4Sdk.SimpleUserData
// Size: 0x40(Inherited: 0x0) 
struct FSimpleUserData
{
	struct FString Namespace;  // 0x0(0x10)
	struct FString UserId;  // 0x10(0x10)
	struct FString DisplayName;  // 0x20(0x10)
	struct FString Username;  // 0x30(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.Time
// Size: 0x8(Inherited: 0x0) 
struct FTime
{
	struct FDateTime CurrentTime;  // 0x0(0x8)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsSettings.SetNamespace
// Size: 0x10(Inherited: 0x0) 
struct FSetNamespace
{
	struct FString Namespace;  // 0x0(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsUserRankingData
// Size: 0x38(Inherited: 0x0) 
struct FAccelByteModelsUserRankingData
{
	struct FAccelByteModelsUserRanking allTime;  // 0x0(0x8)
	struct FAccelByteModelsUserRanking current;  // 0x8(0x8)
	struct FAccelByteModelsUserRanking daily;  // 0x10(0x8)
	struct FAccelByteModelsUserRanking monthly;  // 0x18(0x8)
	struct FAccelByteModelsUserRanking weekly;  // 0x20(0x8)
	struct FString UserId;  // 0x28(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsLeaderboardRankingResult
// Size: 0x50(Inherited: 0x0) 
struct FAccelByteModelsLeaderboardRankingResult
{
	struct TArray<struct FAccelByteModelsUserPoint> Data;  // 0x0(0x10)
	struct FAccelByteModelsPaging Paging;  // 0x10(0x40)

}; 
// ScriptStruct AccelByteUe4Sdk.LobbyMessages
// Size: 0x20(Inherited: 0x0) 
struct FLobbyMessages
{
	struct FString Code;  // 0x0(0x10)
	struct FString CodeName;  // 0x10(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.BlockerData
// Size: 0x10(Inherited: 0x0) 
struct FBlockerData
{
	struct FString UserId;  // 0x0(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsListBlockedUserResponse
// Size: 0x10(Inherited: 0x0) 
struct FAccelByteModelsListBlockedUserResponse
{
	struct TArray<struct FBlockedData> Data;  // 0x0(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.BlockedData
// Size: 0x10(Inherited: 0x0) 
struct FBlockedData
{
	struct FString BlockedUserId;  // 0x0(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsSettings.SetTurnManagerServerUrl
// Size: 0x10(Inherited: 0x0) 
struct FSetTurnManagerServerUrl
{
	struct FString TurnManagerServerUrl;  // 0x0(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsBlockPlayerNotif
// Size: 0x20(Inherited: 0x0) 
struct FAccelByteModelsBlockPlayerNotif
{
	struct FString UserId;  // 0x0(0x10)
	struct FString BlockedUserId;  // 0x10(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsSeasonPassTierJsonObject
// Size: 0x38(Inherited: 0x0) 
struct FAccelByteModelsSeasonPassTierJsonObject
{
	struct FString ID;  // 0x0(0x10)
	int32_t RequiredExp;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct FJsonObjectWrapper Rewards;  // 0x18(0x20)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsBlockPlayerResponse
// Size: 0x10(Inherited: 0x0) 
struct FAccelByteModelsBlockPlayerResponse
{
	struct FString Code;  // 0x0(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsGetSessionAttributeAllResponse
// Size: 0x50(Inherited: 0x0) 
struct FAccelByteModelsGetSessionAttributeAllResponse
{
	struct TMap<struct FString, struct FString> attributes;  // 0x0(0x50)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsGetSessionAttributesResponse
// Size: 0x20(Inherited: 0x0) 
struct FAccelByteModelsGetSessionAttributesResponse
{
	struct FString Code;  // 0x0(0x10)
	struct FString Value;  // 0x10(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsActivePartiesData
// Size: 0x50(Inherited: 0x0) 
struct FAccelByteModelsActivePartiesData
{
	struct TArray<struct FAccelByteModelsPartyDataNotif> Data;  // 0x0(0x10)
	struct FAccelByteModelsPaging Paging;  // 0x10(0x40)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsPartyDataNotif
// Size: 0x80(Inherited: 0x0) 
struct FAccelByteModelsPartyDataNotif
{
	struct FString PartyId;  // 0x0(0x10)
	struct FString Namespace;  // 0x10(0x10)
	struct FString Leader;  // 0x20(0x10)
	struct TArray<struct FString> Members;  // 0x30(0x10)
	struct TArray<struct FString> Invitees;  // 0x40(0x10)
	struct FJsonObjectWrapper Custom_attribute;  // 0x50(0x20)
	struct FString UpdatedAt;  // 0x70(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsUserStatusNotif
// Size: 0x48(Inherited: 0x0) 
struct FAccelByteModelsUserStatusNotif
{
	struct FString UserId;  // 0x0(0x10)
	uint8_t  Availability;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct FString Activity;  // 0x18(0x10)
	struct FString Namespace;  // 0x28(0x10)
	struct FString lastSeenAt;  // 0x38(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsSettings.GetReportingServerUrl
// Size: 0x10(Inherited: 0x0) 
struct FGetReportingServerUrl
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsRejectFriendsNotif
// Size: 0x10(Inherited: 0x0) 
struct FAccelByteModelsRejectFriendsNotif
{
	struct FString UserId;  // 0x0(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsCancelFriendsNotif
// Size: 0x10(Inherited: 0x0) 
struct FAccelByteModelsCancelFriendsNotif
{
	struct FString UserId;  // 0x0(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsUnfriendNotif
// Size: 0x10(Inherited: 0x0) 
struct FAccelByteModelsUnfriendNotif
{
	struct FString friendId;  // 0x0(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsAddUserIntoSessionRequest
// Size: 0x20(Inherited: 0x0) 
struct FAccelByteModelsAddUserIntoSessionRequest
{
	struct FString User_id;  // 0x0(0x10)
	struct FString Party_id;  // 0x10(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsGetFriendshipStatusStringResponse
// Size: 0x20(Inherited: 0x0) 
struct FAccelByteModelsGetFriendshipStatusStringResponse
{
	struct FString Code;  // 0x0(0x10)
	struct FString friendshipStatus;  // 0x10(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsUserSeasonInfoClaimRewardAsJsonObject
// Size: 0x170(Inherited: 0x0) 
struct FAccelByteModelsUserSeasonInfoClaimRewardAsJsonObject
{
	struct FString ID;  // 0x0(0x10)
	struct FString Namespace;  // 0x10(0x10)
	struct FString UserId;  // 0x20(0x10)
	struct FString SeasonId;  // 0x30(0x10)
	struct FDateTime EnrolledAt;  // 0x40(0x8)
	struct TArray<struct FString> EnrolledPasses;  // 0x48(0x10)
	int32_t CurrentTierIndex;  // 0x58(0x4)
	int32_t LastTierIndex;  // 0x5C(0x4)
	int32_t RequiredExp;  // 0x60(0x4)
	int32_t CurrentExp;  // 0x64(0x4)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool Cleared : 1;  // 0x68(0x1)
	char pad_105[7];  // 0x69(0x7)
	struct FAccelByteModelsSeason Season;  // 0x70(0x50)
	struct TMap<int32_t, struct FJsonObjectWrapper> ToClaimRewards;  // 0xC0(0x50)
	struct TMap<int32_t, struct FJsonObjectWrapper> ClaimingRewards;  // 0x110(0x50)
	struct FDateTime CreatedAt;  // 0x160(0x8)
	struct FDateTime UpdatedAt;  // 0x168(0x8)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsDisconnectNotif
// Size: 0x20(Inherited: 0x0) 
struct FAccelByteModelsDisconnectNotif
{
	struct FString Code;  // 0x0(0x10)
	struct FString Message;  // 0x10(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsServerSettings.GetSeasonPassServerUrl
// Size: 0x10(Inherited: 0x0) 
struct FGetSeasonPassServerUrl
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsChannelMessageNotice
// Size: 0x40(Inherited: 0x0) 
struct FAccelByteModelsChannelMessageNotice
{
	struct FString From;  // 0x0(0x10)
	struct FString ChannelSlug;  // 0x10(0x10)
	struct FString Payload;  // 0x20(0x10)
	struct FString SentAt;  // 0x30(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsChannelMessageRequest
// Size: 0x20(Inherited: 0x0) 
struct FAccelByteModelsChannelMessageRequest
{
	struct FString ChannelSlug;  // 0x0(0x10)
	struct FString Payload;  // 0x10(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsSeasonInfo
// Size: 0x140(Inherited: 0x0) 
struct FAccelByteModelsSeasonInfo
{
	struct FString Title;  // 0x0(0x10)
	struct FString Description;  // 0x10(0x10)
	struct FString ID;  // 0x20(0x10)
	struct FString Namespace;  // 0x30(0x10)
	struct FString Name;  // 0x40(0x10)
	struct FDateTime Start;  // 0x50(0x8)
	struct FDateTime End;  // 0x58(0x8)
	struct FString TierItemId;  // 0x60(0x10)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool AutoClaim : 1;  // 0x70(0x1)
	char pad_113[7];  // 0x71(0x7)
	struct TArray<struct FAccelByteModelsItemImage> Images;  // 0x78(0x10)
	struct TArray<struct FString> PassCodes;  // 0x88(0x10)
	uint8_t  Status;  // 0x98(0x1)
	char pad_153[7];  // 0x99(0x7)
	struct FDateTime PublishedAt;  // 0xA0(0x8)
	struct FString Language;  // 0xA8(0x10)
	struct FDateTime CreatedAt;  // 0xB8(0x8)
	struct FDateTime UpdatedAt;  // 0xC0(0x8)
	struct TArray<struct FAccelByteModelsSeasonPass> Passes;  // 0xC8(0x10)
	struct TMap<struct FString, struct FAccelByteModelsSeasonPassReward> Rewards;  // 0xD8(0x50)
	struct TArray<struct FAccelByteModelsSeasonPassTier> Tiers;  // 0x128(0x10)
	char pad_312_1 : 7;  // 0x138(0x1)
	bool endless : 1;  // 0x138(0x1)
	char pad_313[3];  // 0x139(0x3)
	int32_t EndlessLevelsPerDrop;  // 0x13C(0x4)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsSettings.SetAchievementServerUrl
// Size: 0x10(Inherited: 0x0) 
struct FSetAchievementServerUrl
{
	struct FString CloudSaveServerUrl;  // 0x0(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsDataPartyResponse
// Size: 0xB0(Inherited: 0x0) 
struct FAccelByteModelsDataPartyResponse
{
	struct TMap<struct FString, struct FString> Custom_attribute;  // 0x0(0x50)
	struct FString UpdatedAt;  // 0x50(0x10)
	struct FString PartyId;  // 0x60(0x10)
	struct FString LeaderId;  // 0x70(0x10)
	struct TArray<struct FString> Members;  // 0x80(0x10)
	struct TArray<struct FString> Invitees;  // 0x90(0x10)
	struct FString InvitationToken;  // 0xA0(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsSettings.GetIamServerUrl
// Size: 0x10(Inherited: 0x0) 
struct FGetIamServerUrl
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsJoinDefaultChannelResponse
// Size: 0x10(Inherited: 0x0) 
struct FAccelByteModelsJoinDefaultChannelResponse
{
	struct FString ChannelSlug;  // 0x0(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsPartyDeleteCodeResponse
// Size: 0x10(Inherited: 0x0) 
struct FAccelByteModelsPartyDeleteCodeResponse
{
	struct FString Code;  // 0x0(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsPartyPromoteLeaderResponse
// Size: 0x60(Inherited: 0x0) 
struct FAccelByteModelsPartyPromoteLeaderResponse
{
	struct FString PartyId;  // 0x0(0x10)
	struct FString LeaderId;  // 0x10(0x10)
	struct TArray<struct FString> Members;  // 0x20(0x10)
	struct TArray<struct FString> Invitees;  // 0x30(0x10)
	struct FString InvitationToken;  // 0x40(0x10)
	struct FString Code;  // 0x50(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsCredentials.GetUserSessionId
// Size: 0x10(Inherited: 0x0) 
struct FGetUserSessionId
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsSettings.SetSeasonPassServerUrl
// Size: 0x10(Inherited: 0x0) 
struct FSetSeasonPassServerUrl
{
	struct FString SeasonPassServerUrl;  // 0x0(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.RegisterRequestv2
// Size: 0x70(Inherited: 0x0) 
struct FRegisterRequestv2
{
	struct FString AuthType;  // 0x0(0x10)
	struct FString DisplayName;  // 0x10(0x10)
	struct FString EmailAddress;  // 0x20(0x10)
	struct FString Password;  // 0x30(0x10)
	struct FString Country;  // 0x40(0x10)
	struct FString DateOfBirth;  // 0x50(0x10)
	struct FString Username;  // 0x60(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsPartyGenerateCodeResponse
// Size: 0x20(Inherited: 0x0) 
struct FAccelByteModelsPartyGenerateCodeResponse
{
	struct FString PartyCode;  // 0x0(0x10)
	struct FString Code;  // 0x10(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsPartyRejectResponse
// Size: 0x20(Inherited: 0x0) 
struct FAccelByteModelsPartyRejectResponse
{
	struct FString Code;  // 0x0(0x10)
	struct FString PartyId;  // 0x10(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsDequeueRequest
// Size: 0x10(Inherited: 0x0) 
struct FAccelByteModelsDequeueRequest
{
	struct FString Match_id;  // 0x0(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsSessionBrowserGetResult
// Size: 0x50(Inherited: 0x0) 
struct FAccelByteModelsSessionBrowserGetResult
{
	struct TArray<struct FAccelByteModelsSessionBrowserData> Sessions;  // 0x0(0x10)
	struct FAccelByteModelsPaging pagination;  // 0x10(0x40)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsMatchmakingResult
// Size: 0xC8(Inherited: 0x0) 
struct FAccelByteModelsMatchmakingResult
{
	struct FString Channel;  // 0x0(0x10)
	struct FString Client_version;  // 0x10(0x10)
	struct FString Game_mode;  // 0x20(0x10)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool Joinable : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)
	struct FString Match_id;  // 0x38(0x10)
	struct TArray<struct FAccelByteModelsMatchingAlly> Matching_allies;  // 0x48(0x10)
	struct FString Namespace;  // 0x58(0x10)
	struct FJsonObjectWrapper Party_attributes;  // 0x68(0x20)
	struct FString Party_id;  // 0x88(0x10)
	int32_t Queued_at;  // 0x98(0x4)
	char pad_156[4];  // 0x9C(0x4)
	struct FString Region;  // 0xA0(0x10)
	struct FString Server_name;  // 0xB0(0x10)
	uint8_t  Status;  // 0xC0(0x1)
	char pad_193[7];  // 0xC1(0x7)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsQosServer
// Size: 0x48(Inherited: 0x0) 
struct FAccelByteModelsQosServer
{
	struct FString Ip;  // 0x0(0x10)
	int32_t Port;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct FString Region;  // 0x18(0x10)
	struct FString Status;  // 0x28(0x10)
	struct FString Last_update;  // 0x38(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsReasonsResponse
// Size: 0x50(Inherited: 0x0) 
struct FAccelByteModelsReasonsResponse
{
	struct TArray<struct FAccelByteModelsReasonItem> Data;  // 0x0(0x10)
	struct FAccelByteModelsPaging Paging;  // 0x10(0x40)

}; 
// Function AccelByteUe4Sdk.BPUser.LoginWithOtherPlatform
// Size: 0x38(Inherited: 0x0) 
struct FLoginWithOtherPlatform
{
	uint8_t  PlatformType;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FString Token;  // 0x8(0x10)
	struct FDelegate OnSuccess;  // 0x18(0x10)
	struct FDelegate OnError;  // 0x28(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsSeasonClaimRewardResponseJsonWrapper
// Size: 0xA0(Inherited: 0x0) 
struct FAccelByteModelsSeasonClaimRewardResponseJsonWrapper
{
	struct TMap<int32_t, struct FJsonObjectWrapper> ToClaimRewards;  // 0x0(0x50)
	struct TMap<int32_t, struct FJsonObjectWrapper> ClaimingRewards;  // 0x50(0x50)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsSeasonClaimRewardRequest
// Size: 0x28(Inherited: 0x0) 
struct FAccelByteModelsSeasonClaimRewardRequest
{
	struct FString PassCode;  // 0x0(0x10)
	int32_t TierIndex;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct FString RewardCode;  // 0x18(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsUserSeasonInfo
// Size: 0x170(Inherited: 0x0) 
struct FAccelByteModelsUserSeasonInfo
{
	struct FString ID;  // 0x0(0x10)
	struct FString Namespace;  // 0x10(0x10)
	struct FString UserId;  // 0x20(0x10)
	struct FString SeasonId;  // 0x30(0x10)
	struct FDateTime EnrolledAt;  // 0x40(0x8)
	struct TArray<struct FString> EnrolledPasses;  // 0x48(0x10)
	int32_t CurrentTierIndex;  // 0x58(0x4)
	int32_t LastTierIndex;  // 0x5C(0x4)
	int32_t RequiredExp;  // 0x60(0x4)
	int32_t CurrentExp;  // 0x64(0x4)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool Cleared : 1;  // 0x68(0x1)
	char pad_105[7];  // 0x69(0x7)
	struct FAccelByteModelsSeason Season;  // 0x70(0x50)
	char pad_192[160];  // 0xC0(0xA0)
	struct FDateTime CreatedAt;  // 0x160(0x8)
	struct FDateTime UpdatedAt;  // 0x168(0x8)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsSeasonPassTier
// Size: 0x68(Inherited: 0x0) 
struct FAccelByteModelsSeasonPassTier
{
	struct FString ID;  // 0x0(0x10)
	int32_t RequiredExp;  // 0x10(0x4)
	char pad_20[84];  // 0x14(0x54)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteSeasonPassExcessStrategy
// Size: 0x20(Inherited: 0x0) 
struct FAccelByteSeasonPassExcessStrategy
{
	uint8_t  Method;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FString Currency;  // 0x8(0x10)
	int32_t PercentPerExp;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsSessionBrowserJoinSessionRequest
// Size: 0x10(Inherited: 0x0) 
struct FAccelByteModelsSessionBrowserJoinSessionRequest
{
	struct FString Password;  // 0x0(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsSessionBrowserData
// Size: 0x138(Inherited: 0x0) 
struct FAccelByteModelsSessionBrowserData
{
	struct FString Session_id;  // 0x0(0x10)
	struct FString Namespace;  // 0x10(0x10)
	struct FString User_id;  // 0x20(0x10)
	struct FString Username;  // 0x30(0x10)
	struct FString Session_type;  // 0x40(0x10)
	struct FString Game_version;  // 0x50(0x10)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool Joinable : 1;  // 0x60(0x1)
	char pad_97[7];  // 0x61(0x7)
	struct FAccelByteModelsSessionBrowserGameSetting Game_session_setting;  // 0x68(0x68)
	struct FAccelByteModelsSessionBrowserServer Server;  // 0xD0(0x68)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsBulkStatItemCreate
// Size: 0x10(Inherited: 0x0) 
struct FAccelByteModelsBulkStatItemCreate
{
	struct FString StatCode;  // 0x0(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsStatInfo
// Size: 0x88(Inherited: 0x0) 
struct FAccelByteModelsStatInfo
{
	struct FString CreatedAt;  // 0x0(0x10)
	float DefaultValue;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct FString Description;  // 0x18(0x10)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool IncrementOnly : 1;  // 0x28(0x1)
	char pad_41[3];  // 0x29(0x3)
	float Maximum;  // 0x2C(0x4)
	float Minimum;  // 0x30(0x4)
	char pad_52[4];  // 0x34(0x4)
	struct FString Name;  // 0x38(0x10)
	struct FString Namespace;  // 0x48(0x10)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool SetAsGlobal : 1;  // 0x58(0x1)
	uint8_t  SetBy;  // 0x59(0x1)
	char pad_90[6];  // 0x5A(0x6)
	struct FString StatCode;  // 0x60(0x10)
	uint8_t  Status;  // 0x70(0x1)
	char pad_113[7];  // 0x71(0x7)
	struct FString UpdatedAt;  // 0x78(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsTurnServer
// Size: 0x50(Inherited: 0x0) 
struct FAccelByteModelsTurnServer
{
	struct FString Ip;  // 0x0(0x10)
	int32_t Port;  // 0x10(0x4)
	int32_t Qos_port;  // 0x14(0x4)
	struct FString Region;  // 0x18(0x10)
	struct FString Status;  // 0x28(0x10)
	struct FString Last_update;  // 0x38(0x10)
	int64_t Current_time;  // 0x48(0x8)

}; 
// ScriptStruct AccelByteUe4Sdk.UserOtherPlatformInfo
// Size: 0x168(Inherited: 0x0) 
struct FUserOtherPlatformInfo
{
	struct FString AuthType;  // 0x0(0x10)
	struct TArray<struct FBan> Bans;  // 0x10(0x10)
	struct FString Country;  // 0x20(0x10)
	struct FString CreatedAt;  // 0x30(0x10)
	struct FString DateOfBirth;  // 0x40(0x10)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool DeletionStatus : 1;  // 0x50(0x1)
	char pad_81[7];  // 0x51(0x7)
	struct FString DisplayName;  // 0x58(0x10)
	struct FString EmailAddress;  // 0x68(0x10)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool EmailVerified : 1;  // 0x78(0x1)
	char pad_121_1 : 7;  // 0x79(0x1)
	bool Enabled : 1;  // 0x79(0x1)
	char pad_122[6];  // 0x7A(0x6)
	struct FString LastDateOfBirthChangedTime;  // 0x80(0x10)
	struct FString LastEnabledChangedTime;  // 0x90(0x10)
	struct FString Namespace;  // 0xA0(0x10)
	struct TArray<struct FNamespaceRole> NamespaceRoles;  // 0xB0(0x10)
	struct FString NewEmailAddress;  // 0xC0(0x10)
	struct FString OldEmailAddress;  // 0xD0(0x10)
	struct TArray<struct FPermission> Permissions;  // 0xE0(0x10)
	struct FString PhoneNumber;  // 0xF0(0x10)
	char pad_256_1 : 7;  // 0x100(0x1)
	bool PhoneVerified : 1;  // 0x100(0x1)
	char pad_257[7];  // 0x101(0x7)
	struct FString PlatformDisplayName;  // 0x108(0x10)
	struct FString PlatformId;  // 0x118(0x10)
	struct FString PlatformUserId;  // 0x128(0x10)
	struct TArray<struct FString> Roles;  // 0x138(0x10)
	struct FString UserId;  // 0x148(0x10)
	struct FString Username;  // 0x158(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsUGCPreview
// Size: 0x10(Inherited: 0x0) 
struct FAccelByteModelsUGCPreview
{
	struct FString Preview;  // 0x0(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsUGCChannelsPagingResponse
// Size: 0x50(Inherited: 0x0) 
struct FAccelByteModelsUGCChannelsPagingResponse
{
	struct TArray<struct FAccelByteModelsUGCChannelResponse> Data;  // 0x0(0x10)
	struct FAccelByteModelsPaging Paging;  // 0x10(0x40)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsUGCTypeResponse
// Size: 0x40(Inherited: 0x0) 
struct FAccelByteModelsUGCTypeResponse
{
	struct FString ID;  // 0x0(0x10)
	struct FString Namespace;  // 0x10(0x10)
	struct TArray<struct FString> Subtype;  // 0x20(0x10)
	struct FString Type;  // 0x30(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.PlatformUserIdMap
// Size: 0x20(Inherited: 0x0) 
struct FPlatformUserIdMap
{
	struct FString UserId;  // 0x0(0x10)
	struct FString PlatformUserId;  // 0x10(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsUGCContentResponse
// Size: 0x118(Inherited: 0x0) 
struct FAccelByteModelsUGCContentResponse
{
	struct FString ChannelId;  // 0x0(0x10)
	struct FDateTime CreatedTime;  // 0x10(0x8)
	struct FAccelByteModelsUGCCreatorState CreatorFollowState;  // 0x18(0x18)
	struct FString CreatorName;  // 0x30(0x10)
	int32_t DownloadCount;  // 0x40(0x4)
	char pad_68[4];  // 0x44(0x4)
	struct FString FileExtension;  // 0x48(0x10)
	struct FString ID;  // 0x58(0x10)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool IsOfficial : 1;  // 0x68(0x1)
	char pad_105[3];  // 0x69(0x3)
	int32_t LikeCount;  // 0x6C(0x4)
	struct FAccelByteModelsUGCCreatorState LikeState;  // 0x70(0x18)
	struct FString Name;  // 0x88(0x10)
	struct FString Namespace;  // 0x98(0x10)
	struct FString Payload;  // 0xA8(0x10)
	struct TArray<struct FAccelByteModelsUGCPayloadUrl> PayloadUrl;  // 0xB8(0x10)
	struct FString ShareCode;  // 0xC8(0x10)
	struct FString Subtype;  // 0xD8(0x10)
	struct TArray<struct FString> Tags;  // 0xE8(0x10)
	struct FString Type;  // 0xF8(0x10)
	struct FString UserId;  // 0x108(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsUGCPayloadUrl
// Size: 0x20(Inherited: 0x0) 
struct FAccelByteModelsUGCPayloadUrl
{
	struct FString Source;  // 0x0(0x10)
	struct FString URL;  // 0x10(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsServerSettings.SetMatchmakingServerUrl
// Size: 0x10(Inherited: 0x0) 
struct FSetMatchmakingServerUrl
{
	struct FString AchievementServerUrl;  // 0x0(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsSettings.SetCloudStorageServerUrl
// Size: 0x10(Inherited: 0x0) 
struct FSetCloudStorageServerUrl
{
	struct FString CloudStorageServerUrl;  // 0x0(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.NamespaceRole
// Size: 0x20(Inherited: 0x0) 
struct FNamespaceRole
{
	struct FString Namespace;  // 0x0(0x10)
	struct FString RoleId;  // 0x10(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.BulkGetBasicUserInfoResponse
// Size: 0x10(Inherited: 0x0) 
struct FBulkGetBasicUserInfoResponse
{
	struct TArray<struct FBasicUserInfo> Data;  // 0x0(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.ListBulkUserInfoRequest
// Size: 0x10(Inherited: 0x0) 
struct FListBulkUserInfoRequest
{
	struct TArray<struct FString> UserIds;  // 0x0(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.UpdateEmailRequest
// Size: 0x20(Inherited: 0x0) 
struct FUpdateEmailRequest
{
	struct FString Code;  // 0x0(0x10)
	struct FString EmailAddress;  // 0x10(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccountLinkConflictMessageVariables
// Size: 0x20(Inherited: 0x0) 
struct FAccountLinkConflictMessageVariables
{
	struct FString PlatformUserId;  // 0x0(0x10)
	struct TArray<struct FAccountLinkPublisherAccount> PublisherAccounts;  // 0x10(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccountLinkPublisherAccount
// Size: 0x30(Inherited: 0x0) 
struct FAccountLinkPublisherAccount
{
	struct FString UserId;  // 0x0(0x10)
	struct FString Namespace;  // 0x10(0x10)
	struct TArray<struct FAccountLinkedPlatform> LinkedPlatforms;  // 0x20(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.CountryInfo
// Size: 0x40(Inherited: 0x0) 
struct FCountryInfo
{
	struct FString CountryCode;  // 0x0(0x10)
	struct FString CountryName;  // 0x10(0x10)
	struct FString State;  // 0x20(0x10)
	struct FString City;  // 0x30(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsCredentials.GetUserId
// Size: 0x10(Inherited: 0x0) 
struct FGetUserId
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.BulkPlatformUserIdRequest
// Size: 0x10(Inherited: 0x0) 
struct FBulkPlatformUserIdRequest
{
	struct TArray<struct FString> PlatformUserIds;  // 0x0(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.PublicUserInfo
// Size: 0x50(Inherited: 0x0) 
struct FPublicUserInfo
{
	struct FString CreatedAt;  // 0x0(0x10)
	struct FString DisplayName;  // 0x10(0x10)
	struct FString Namespace;  // 0x20(0x10)
	struct FString UserId;  // 0x30(0x10)
	struct FString Username;  // 0x40(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.UpgradeAndVerifyRequest
// Size: 0x30(Inherited: 0x0) 
struct FUpgradeAndVerifyRequest
{
	struct FString Code;  // 0x0(0x10)
	struct FString Password;  // 0x10(0x10)
	struct FString LoginId;  // 0x20(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.VerificationCodeRequest
// Size: 0x28(Inherited: 0x0) 
struct FVerificationCodeRequest
{
	uint8_t  Context;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FString LanguageTag;  // 0x8(0x10)
	struct FString EmailAddress;  // 0x18(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.UserUpdateRequest
// Size: 0x60(Inherited: 0x0) 
struct FUserUpdateRequest
{
	struct FString Country;  // 0x0(0x10)
	struct FString DateOfBirth;  // 0x10(0x10)
	struct FString DisplayName;  // 0x20(0x10)
	struct FString EmailAddress;  // 0x30(0x10)
	struct FString LanguageTag;  // 0x40(0x10)
	struct FString Username;  // 0x50(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.AccelByteModelsPubIp
// Size: 0x10(Inherited: 0x0) 
struct FAccelByteModelsPubIp
{
	struct FString Ip;  // 0x0(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsServerCredentials.GetClientAccessToken
// Size: 0x10(Inherited: 0x0) 
struct FGetClientAccessToken
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// Function AccelByteUe4Sdk.BPUser.UnlinkOtherPlatform
// Size: 0x24(Inherited: 0x0) 
struct FUnlinkOtherPlatform
{
	uint8_t  PlatformType;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	struct FDelegate OnSuccess;  // 0x4(0x10)
	struct FDelegate OnError;  // 0x14(0x10)

}; 
// ScriptStruct AccelByteUe4Sdk.VersionInfo
// Size: 0x40(Inherited: 0x0) 
struct FVersionInfo
{
	struct FString Name;  // 0x0(0x10)
	struct FString Version;  // 0x10(0x10)
	struct FString GitHash;  // 0x20(0x10)
	struct FString Realm;  // 0x30(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsCredentials.GetUserNamespace
// Size: 0x10(Inherited: 0x0) 
struct FGetUserNamespace
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsCredentials.GetUserEmailAddress
// Size: 0x10(Inherited: 0x0) 
struct FGetUserEmailAddress
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsServerCredentials.GetMatchId
// Size: 0x10(Inherited: 0x0) 
struct FGetMatchId
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsSettings.GetClientId
// Size: 0x10(Inherited: 0x0) 
struct FGetClientId
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsServerSettings.GetDSHubServerUrl
// Size: 0x10(Inherited: 0x0) 
struct FGetDSHubServerUrl
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsServerSettings.GetDSMControllerServerUrl
// Size: 0x10(Inherited: 0x0) 
struct FGetDSMControllerServerUrl
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsSettings.GetLobbyServerUrl
// Size: 0x10(Inherited: 0x0) 
struct FGetLobbyServerUrl
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsServerSettings.GetMatchmakingServerUrl
// Size: 0x10(Inherited: 0x0) 
struct FGetMatchmakingServerUrl
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsSettings.GetNamespace
// Size: 0x10(Inherited: 0x0) 
struct FGetNamespace
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsSettings.GetStatisticServerUrl
// Size: 0x10(Inherited: 0x0) 
struct FGetStatisticServerUrl
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsSettings.ResetSettings
// Size: 0x1(Inherited: 0x0) 
struct FResetSettings
{
	uint8_t  Environment;  // 0x0(0x1)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsServerSettings.SetDSHubServerUrl
// Size: 0x10(Inherited: 0x0) 
struct FSetDSHubServerUrl
{
	struct FString DSHubServerUrl;  // 0x0(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsSettings.SetGameTelemetryServerUrl
// Size: 0x10(Inherited: 0x0) 
struct FSetGameTelemetryServerUrl
{
	struct FString GameTelemetryServerUrl;  // 0x0(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsSettings.SetLobbyServerUrl
// Size: 0x10(Inherited: 0x0) 
struct FSetLobbyServerUrl
{
	struct FString LobbyServerUrl;  // 0x0(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsSettings.SetPlatformServerUrl
// Size: 0x10(Inherited: 0x0) 
struct FSetPlatformServerUrl
{
	struct FString PlatformServerUrl;  // 0x0(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsSettings.GetBasicServerUrl
// Size: 0x10(Inherited: 0x0) 
struct FGetBasicServerUrl
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsSettings.GetGeneralTimeout
// Size: 0x4(Inherited: 0x0) 
struct FGetGeneralTimeout
{
	float ReturnValue;  // 0x0(0x4)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsSettings.SetAppId
// Size: 0x10(Inherited: 0x0) 
struct FSetAppId
{
	struct FString AppId;  // 0x0(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsSettings.SetBasicServerUrl
// Size: 0x10(Inherited: 0x0) 
struct FSetBasicServerUrl
{
	struct FString BasicServerUrl;  // 0x0(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsSettings.SetGameProfileServerUrl
// Size: 0x10(Inherited: 0x0) 
struct FSetGameProfileServerUrl
{
	struct FString GameProfileServerUrl;  // 0x0(0x10)

}; 
// Function AccelByteUe4Sdk.AccelByteBlueprintsSettings.SetReportingServerUrl
// Size: 0x10(Inherited: 0x0) 
struct FSetReportingServerUrl
{
	struct FString ReportingServerUrl;  // 0x0(0x10)

}; 
// Function AccelByteUe4Sdk.BPUser.GetUserEligibleToPlay
// Size: 0x20(Inherited: 0x0) 
struct FGetUserEligibleToPlay
{
	struct FDelegate OnSuccess;  // 0x0(0x10)
	struct FDelegate OnError;  // 0x10(0x10)

}; 
// Function AccelByteUe4Sdk.BPUser.LinkOtherPlatform
// Size: 0x38(Inherited: 0x0) 
struct FLinkOtherPlatform
{
	uint8_t  PlatformType;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FString Ticket;  // 0x8(0x10)
	struct FDelegate OnSuccess;  // 0x18(0x10)
	struct FDelegate OnError;  // 0x28(0x10)

}; 
// Function AccelByteUe4Sdk.BPUser.LoginWithDeviceId
// Size: 0x20(Inherited: 0x0) 
struct FLoginWithDeviceId
{
	struct FDelegate OnSuccess;  // 0x0(0x10)
	struct FDelegate OnError;  // 0x10(0x10)

}; 
// Function AccelByteUe4Sdk.BPUser.LoginWithUsername
// Size: 0x40(Inherited: 0x0) 
struct FLoginWithUsername
{
	struct FString Username;  // 0x0(0x10)
	struct FString Password;  // 0x10(0x10)
	struct FDelegate OnSuccess;  // 0x20(0x10)
	struct FDelegate OnError;  // 0x30(0x10)

}; 
// Function AccelByteUe4Sdk.BPUser.Logout
// Size: 0x20(Inherited: 0x0) 
struct FLogout
{
	struct FDelegate OnSuccess;  // 0x0(0x10)
	struct FDelegate OnError;  // 0x10(0x10)

}; 
// Function AccelByteUe4Sdk.BPUser.Register
// Size: 0x70(Inherited: 0x0) 
struct FRegister
{
	struct FString Username;  // 0x0(0x10)
	struct FString Password;  // 0x10(0x10)
	struct FString DisplayName;  // 0x20(0x10)
	struct FString Country;  // 0x30(0x10)
	struct FString DateOfBirth;  // 0x40(0x10)
	struct FDelegate OnSuccess;  // 0x50(0x10)
	struct FDelegate OnError;  // 0x60(0x10)

}; 
// Function AccelByteUe4Sdk.BPUser.ResetPassword
// Size: 0x50(Inherited: 0x0) 
struct FResetPassword
{
	struct FString VerificationCode;  // 0x0(0x10)
	struct FString Username;  // 0x10(0x10)
	struct FString NewPassword;  // 0x20(0x10)
	struct FDelegate OnSuccess;  // 0x30(0x10)
	struct FDelegate OnError;  // 0x40(0x10)

}; 
// Function AccelByteUe4Sdk.BPUser.SendVerificationCode
// Size: 0x20(Inherited: 0x0) 
struct FSendVerificationCode
{
	struct FDelegate OnSuccess;  // 0x0(0x10)
	struct FDelegate OnError;  // 0x10(0x10)

}; 
// Function AccelByteUe4Sdk.BPUser.UpgradeAndVerify
// Size: 0x50(Inherited: 0x0) 
struct FUpgradeAndVerify
{
	struct FString Username;  // 0x0(0x10)
	struct FString Password;  // 0x10(0x10)
	struct FString VerificationCode;  // 0x20(0x10)
	struct FDelegate OnSuccess;  // 0x30(0x10)
	struct FDelegate OnError;  // 0x40(0x10)

}; 
// Function AccelByteUe4Sdk.BPUser.Verify
// Size: 0x30(Inherited: 0x0) 
struct FVerify
{
	struct FString VerificationCode;  // 0x0(0x10)
	struct FDelegate OnSuccess;  // 0x10(0x10)
	struct FDelegate OnError;  // 0x20(0x10)

}; 
