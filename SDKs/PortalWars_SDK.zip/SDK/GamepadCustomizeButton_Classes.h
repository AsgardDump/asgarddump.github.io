#pragma once 
#include <GamepadCustomizeButton_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass GamepadCustomizeButton.GamepadCustomizeButton_C
// Size: 0x5A0(Inherited: 0x598) 
struct UGamepadCustomizeButton_C : public UPortalWarsGamepadBindingCustomizeButtonWidget
{
	struct UImage* Image_101;  // 0x598(0x8)

}; 



