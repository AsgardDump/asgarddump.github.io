#pragma once 
#include <FriendsListSub_WidgetBP_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass FriendsListSub_WidgetBP.FriendsListSub_WidgetBP_C
// Size: 0x8F0(Inherited: 0x8A0) 
struct UFriendsListSub_WidgetBP_C : public UPortalWarsFriendsListSubWidget
{
	struct UImage* Image;  // 0x8A0(0x8)
	struct UImage* Image_2;  // 0x8A8(0x8)
	struct UImage* Image_3;  // 0x8B0(0x8)
	struct UImage* Image_4;  // 0x8B8(0x8)
	struct UImage* Image_84;  // 0x8C0(0x8)
	struct UImage* Image_97;  // 0x8C8(0x8)
	struct UMenuBackground_C* MenuBackground;  // 0x8D0(0x8)
	struct USafeZone* SafeZone_1;  // 0x8D8(0x8)
	struct UThrobber* Throbber_2;  // 0x8E0(0x8)
	struct UWBP_Footer_C* WBP_Footer;  // 0x8E8(0x8)

}; 



