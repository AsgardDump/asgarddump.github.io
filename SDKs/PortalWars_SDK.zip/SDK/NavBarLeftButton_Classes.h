#pragma once 
#include <NavBarLeftButton_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass NavBarLeftButton.NavBarLeftButton_C
// Size: 0x690(Inherited: 0x688) 
struct UNavBarLeftButton_C : public UPortalWarsButtonWidget
{
	struct UImage* GamepadKeyImage;  // 0x688(0x8)

}; 



