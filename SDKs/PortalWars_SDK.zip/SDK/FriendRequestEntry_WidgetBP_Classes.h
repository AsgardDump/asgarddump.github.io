#pragma once 
#include <FriendRequestEntry_WidgetBP_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass FriendRequestEntry_WidgetBP.FriendRequestEntry_WidgetBP_C
// Size: 0xA00(Inherited: 0x9E0) 
struct UFriendRequestEntry_WidgetBP_C : public UPortalWarsFriendRequestEntry
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x9E0(0x8)
	struct UImage* BG;  // 0x9E8(0x8)
	struct UImage* Image_181;  // 0x9F0(0x8)
	struct UImage* SelectedBG;  // 0x9F8(0x8)

	void Construct(); // Function FriendRequestEntry_WidgetBP.FriendRequestEntry_WidgetBP_C.Construct
	void ExecuteUbergraph_FriendRequestEntry_WidgetBP(int32_t EntryPoint); // Function FriendRequestEntry_WidgetBP.FriendRequestEntry_WidgetBP_C.ExecuteUbergraph_FriendRequestEntry_WidgetBP
}; 



