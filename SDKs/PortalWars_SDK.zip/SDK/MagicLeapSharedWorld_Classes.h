#pragma once 
#include <MagicLeapSharedWorld_Structs.h>
 
 
 
// Class MagicLeapSharedWorld.MagicLeapSharedWorldGameMode
// Size: 0x3D8(Inherited: 0x308) 
struct AMagicLeapSharedWorldGameMode : public AGameMode
{
	struct FMagicLeapSharedWorldSharedData SharedWorldData;  // 0x308(0x10)
	struct FMulticastInlineDelegate OnNewLocalDataFromClients;  // 0x318(0x10)
	float PinSelectionConfidenceThreshold;  // 0x328(0x4)
	char pad_812[164];  // 0x32C(0xA4)
	struct AMagicLeapSharedWorldPlayerController* ChosenOne;  // 0x3D0(0x8)

	bool SendSharedWorldDataToClients(); // Function MagicLeapSharedWorld.MagicLeapSharedWorldGameMode.SendSharedWorldDataToClients
	void SelectChosenOne(); // Function MagicLeapSharedWorld.MagicLeapSharedWorldGameMode.SelectChosenOne
	void MagicLeapOnNewLocalDataFromClients__DelegateSignature(); // DelegateFunction MagicLeapSharedWorld.MagicLeapSharedWorldGameMode.MagicLeapOnNewLocalDataFromClients__DelegateSignature
	void DetermineSharedWorldData(struct FMagicLeapSharedWorldSharedData& NewSharedWorldData); // Function MagicLeapSharedWorld.MagicLeapSharedWorldGameMode.DetermineSharedWorldData
}; 



// Class MagicLeapSharedWorld.MagicLeapSharedWorldGameState
// Size: 0x2D0(Inherited: 0x290) 
struct AMagicLeapSharedWorldGameState : public AGameState
{
	struct FMagicLeapSharedWorldSharedData SharedWorldData;  // 0x290(0x10)
	struct FMagicLeapSharedWorldAlignmentTransforms AlignmentTransforms;  // 0x2A0(0x10)
	struct FMulticastInlineDelegate OnSharedWorldDataUpdated;  // 0x2B0(0x10)
	struct FMulticastInlineDelegate OnAlignmentTransformsUpdated;  // 0x2C0(0x10)

	void OnReplicate_SharedWorldData(); // Function MagicLeapSharedWorld.MagicLeapSharedWorldGameState.OnReplicate_SharedWorldData
	void OnReplicate_AlignmentTransforms(); // Function MagicLeapSharedWorld.MagicLeapSharedWorldGameState.OnReplicate_AlignmentTransforms
	void MagicLeapSharedWorldEvent__DelegateSignature(); // DelegateFunction MagicLeapSharedWorld.MagicLeapSharedWorldGameState.MagicLeapSharedWorldEvent__DelegateSignature
	struct FTransform CalculateXRCameraRootTransform(); // Function MagicLeapSharedWorld.MagicLeapSharedWorldGameState.CalculateXRCameraRootTransform
}; 



// Class MagicLeapSharedWorld.MagicLeapSharedWorldPlayerController
// Size: 0x588(Inherited: 0x570) 
struct AMagicLeapSharedWorldPlayerController : public APlayerController
{
	char pad_1392[24];  // 0x570(0x18)

	void ServerSetLocalWorldData(struct FMagicLeapSharedWorldLocalData LocalWorldReplicationData); // Function MagicLeapSharedWorld.MagicLeapSharedWorldPlayerController.ServerSetLocalWorldData
	void ServerSetAlignmentTransforms(struct FMagicLeapSharedWorldAlignmentTransforms InAlignmentTransforms); // Function MagicLeapSharedWorld.MagicLeapSharedWorldPlayerController.ServerSetAlignmentTransforms
	bool IsChosenOne(); // Function MagicLeapSharedWorld.MagicLeapSharedWorldPlayerController.IsChosenOne
	void ClientSetChosenOne(bool bChosenOne); // Function MagicLeapSharedWorld.MagicLeapSharedWorldPlayerController.ClientSetChosenOne
	void ClientMarkReadyForSendingLocalData(); // Function MagicLeapSharedWorld.MagicLeapSharedWorldPlayerController.ClientMarkReadyForSendingLocalData
	bool CanSendLocalDataToServer(); // Function MagicLeapSharedWorld.MagicLeapSharedWorldPlayerController.CanSendLocalDataToServer
}; 



