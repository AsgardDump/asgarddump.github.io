#pragma once 
#include <ColorblindTestImage_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass ColorblindTestImage.ColorblindTestImage_C
// Size: 0x268(Inherited: 0x260) 
struct UColorblindTestImage_C : public UUserWidget
{
	struct UImage* BackgroundImage;  // 0x260(0x8)

}; 



