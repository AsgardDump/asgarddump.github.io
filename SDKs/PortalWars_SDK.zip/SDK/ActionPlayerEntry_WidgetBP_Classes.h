#pragma once 
#include <ActionPlayerEntry_WidgetBP_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass ActionPlayerEntry_WidgetBP.ActionPlayerEntry_WidgetBP_C
// Size: 0x950(Inherited: 0x940) 
struct UActionPlayerEntry_WidgetBP_C : public UPortalWarsPlayerEntryWidget
{
	struct UImage* Image_181;  // 0x940(0x8)
	struct UImage* MuteIndicator;  // 0x948(0x8)

}; 



