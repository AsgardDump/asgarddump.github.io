#pragma once 
#include "SDK.h" 
 
 
// Function FPPAnimBlueprint.FPPAnimBlueprint_C.ExecuteUbergraph_FPPAnimBlueprint
// Size: 0x4(Inherited: 0x0) 
struct FExecuteUbergraph_FPPAnimBlueprint
{
	int32_t EntryPoint;  // 0x0(0x4)

}; 
// Function FPPAnimBlueprint.FPPAnimBlueprint_C.AnimGraph
// Size: 0x10(Inherited: 0x0) 
struct FAnimGraph
{
	struct FPoseLink AnimGraph;  // 0x0(0x10)

}; 
