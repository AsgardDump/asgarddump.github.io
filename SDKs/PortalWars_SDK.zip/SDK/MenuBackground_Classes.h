#pragma once 
#include <MenuBackground_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass MenuBackground.MenuBackground_C
// Size: 0x3D0(Inherited: 0x260) 
struct UMenuBackground_C : public UUserWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x260(0x8)
	struct UBackgroundBlur* BackgroundBlur_1;  // 0x268(0x8)
	struct UBackgroundBlur* BackgroundBlur_2;  // 0x270(0x8)
	struct UOverlay* BgV2;  // 0x278(0x8)
	struct UImage* BlueSpotlight;  // 0x280(0x8)
	struct UScaleBox* BlueSpotlightRoot;  // 0x288(0x8)
	struct UImage* BlurBackground;  // 0x290(0x8)
	struct UBackgroundBlur* BottomCornerGraphic;  // 0x298(0x8)
	struct UImage* DynamicBackground;  // 0x2A0(0x8)
	struct UImage* Flare;  // 0x2A8(0x8)
	struct UImage* Flare_2;  // 0x2B0(0x8)
	struct UImage* Glow;  // 0x2B8(0x8)
	struct UImage* GoldSpotlight;  // 0x2C0(0x8)
	struct UScaleBox* GoldSpotlightRoot;  // 0x2C8(0x8)
	struct UImage* Image_206;  // 0x2D0(0x8)
	struct UImage* LeftPanelBG;  // 0x2D8(0x8)
	struct UScaleBox* LeftPanelRoot;  // 0x2E0(0x8)
	struct UImage* Logo;  // 0x2E8(0x8)
	struct UScaleBox* LogoRoot;  // 0x2F0(0x8)
	struct UImage* MidTrianglesScrim;  // 0x2F8(0x8)
	struct UScaleBox* MidTrianglesScrimRoot;  // 0x300(0x8)
	struct UImage* Noise;  // 0x308(0x8)
	struct USafeZone* SafeZone;  // 0x310(0x8)
	struct UImage* Smoke;  // 0x318(0x8)
	struct UImage* StaticBackground;  // 0x320(0x8)
	struct UBackgroundBlur* TopCornerGraphic;  // 0x328(0x8)
	struct UImage* TopTrianglesScrim;  // 0x330(0x8)
	struct UScaleBox* TopTrianglesScrimRoot;  // 0x338(0x8)
	struct UImage* White;  // 0x340(0x8)
	struct UImage* White_2;  // 0x348(0x8)
	struct UImage* WhiteGlowGradient;  // 0x350(0x8)
	struct UImage* WhiteGlowGradient2;  // 0x358(0x8)
	struct UTexture2D* BackgroundImage;  // 0x360(0x8)
	char pad_872_1 : 7;  // 0x368(0x1)
	bool ShowStaticBackground : 1;  // 0x368(0x1)
	char pad_873_1 : 7;  // 0x369(0x1)
	bool ShowBlurBackground : 1;  // 0x369(0x1)
	char pad_874_1 : 7;  // 0x36A(0x1)
	bool ShowLeftPanelBG : 1;  // 0x36A(0x1)
	char pad_875_1 : 7;  // 0x36B(0x1)
	bool ShowGoldSpotlight : 1;  // 0x36B(0x1)
	char pad_876_1 : 7;  // 0x36C(0x1)
	bool ShowBlueSpotlight : 1;  // 0x36C(0x1)
	char pad_877_1 : 7;  // 0x36D(0x1)
	bool ShowTopTrianglesScrim : 1;  // 0x36D(0x1)
	char pad_878_1 : 7;  // 0x36E(0x1)
	bool ShowMidTrianglesScrim : 1;  // 0x36E(0x1)
	char pad_879_1 : 7;  // 0x36F(0x1)
	bool ShowLogo : 1;  // 0x36F(0x1)
	char pad_880_1 : 7;  // 0x370(0x1)
	bool ShowBottomBlur : 1;  // 0x370(0x1)
	char pad_881_1 : 7;  // 0x371(0x1)
	bool ShowBGV2 : 1;  // 0x371(0x1)
	char pad_882_1 : 7;  // 0x372(0x1)
	bool ShowSpotLight : 1;  // 0x372(0x1)
	char pad_883_1 : 7;  // 0x373(0x1)
	bool ShowNoise : 1;  // 0x373(0x1)
	char pad_884_1 : 7;  // 0x374(0x1)
	bool ShowBottomGlow : 1;  // 0x374(0x1)
	char pad_885_1 : 7;  // 0x375(0x1)
	bool ShowCornerGraphics : 1;  // 0x375(0x1)
	char pad_886_1 : 7;  // 0x376(0x1)
	bool ShowPageFlare : 1;  // 0x376(0x1)
	char pad_887_1 : 7;  // 0x377(0x1)
	bool ShowSmoke : 1;  // 0x377(0x1)
	struct UMaterialInstanceDynamic* DMI Background;  // 0x378(0x8)
	struct FLinearColor BGColor1;  // 0x380(0x10)
	struct FLinearColor BGColor2;  // 0x390(0x10)
	float Density;  // 0x3A0(0x4)
	float Intensity;  // 0x3A4(0x4)
	float Radius;  // 0x3A8(0x4)
	float UV;  // 0x3AC(0x4)
	struct FLinearColor CenterPosition;  // 0x3B0(0x10)
	struct UMaterialInstanceDynamic* DMI Noise;  // 0x3C0(0x8)
	float DustIntensity;  // 0x3C8(0x4)
	float SmokeIntensity;  // 0x3CC(0x4)

	void SetBackgroundColor(struct FLinearColor Color1, struct FLinearColor Color2); // Function MenuBackground.MenuBackground_C.SetBackgroundColor
	void Set Material(); // Function MenuBackground.MenuBackground_C.Set Material
	void Set Background(); // Function MenuBackground.MenuBackground_C.Set Background
	void SetComponentVisbility(struct UWidget* Widget, bool Visible); // Function MenuBackground.MenuBackground_C.SetComponentVisbility
	void PreConstruct(bool IsDesignTime); // Function MenuBackground.MenuBackground_C.PreConstruct
	void RefreshWidget(); // Function MenuBackground.MenuBackground_C.RefreshWidget
	void ExecuteUbergraph_MenuBackground(int32_t EntryPoint); // Function MenuBackground.MenuBackground_C.ExecuteUbergraph_MenuBackground
}; 



