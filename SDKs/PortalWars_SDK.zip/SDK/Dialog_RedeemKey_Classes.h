#pragma once 
#include <Dialog_RedeemKey_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass Dialog_RedeemKey.Dialog_RedeemKey_C
// Size: 0x8E0(Inherited: 0x8A0) 
struct UDialog_RedeemKey_C : public UPortalWarsRedeemKeyDialogWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x8A0(0x8)
	struct UImage* Image_2;  // 0x8A8(0x8)
	struct UImage* Image_63;  // 0x8B0(0x8)
	struct UImage* Line;  // 0x8B8(0x8)
	struct UPurchaseDialogBackground_C* PurchaseDialogBackground;  // 0x8C0(0x8)
	struct USafeZone* SafeZone_1;  // 0x8C8(0x8)
	struct UThrobber* Throbber_1;  // 0x8D0(0x8)
	struct UWBP_Footer_C* WBP_Footer;  // 0x8D8(0x8)

	void Construct(); // Function Dialog_RedeemKey.Dialog_RedeemKey_C.Construct
	void ExecuteUbergraph_Dialog_RedeemKey(int32_t EntryPoint); // Function Dialog_RedeemKey.Dialog_RedeemKey_C.ExecuteUbergraph_Dialog_RedeemKey
}; 



