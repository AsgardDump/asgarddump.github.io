#pragma once 
#include "SDK.h" 
 
 
// Function AddFriends_WidgetBP.AddFriends_WidgetBP_C.ExecuteUbergraph_AddFriends_WidgetBP
// Size: 0x4(Inherited: 0x0) 
struct FExecuteUbergraph_AddFriends_WidgetBP
{
	int32_t EntryPoint;  // 0x0(0x4)

}; 
