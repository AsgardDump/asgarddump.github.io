#pragma once 
#include "SDK.h" 
 
 
// ScriptStruct MDFastBinding.MDFastBindingFieldPath
// Size: 0xB0(Inherited: 0x0) 
struct FMDFastBindingFieldPath
{
	char pad_0[40];  // 0x0(0x28)
	struct TArray<struct FName> FieldPath;  // 0x28(0x10)
	struct TArray<struct FMDFastBindingMemberReference> FieldPathMembers;  // 0x38(0x10)
	char pad_72[104];  // 0x48(0x68)

}; 
// ScriptStruct MDFastBinding.MDFastBindingFunctionWrapper
// Size: 0xC0(Inherited: 0x0) 
struct FMDFastBindingFunctionWrapper
{
	char pad_0[80];  // 0x0(0x50)
	struct FName FunctionName;  // 0x50(0x8)
	struct FMDFastBindingMemberReference FunctionMember;  // 0x58(0x40)
	struct UFunction* FunctionPtr;  // 0x98(0x8)
	char pad_160[32];  // 0xA0(0x20)

}; 
// ScriptStruct MDFastBinding.MDFastBindingMemberReference
// Size: 0x40(Inherited: 0x38) 
struct FMDFastBindingMemberReference : public FMemberReference
{
	char pad_56_1 : 7;  // 0x38(0x1)
	bool bIsFunction : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)

}; 
// ScriptStruct MDFastBinding.MDFastBindingItem
// Size: 0xA8(Inherited: 0x0) 
struct FMDFastBindingItem
{
	struct FName ItemName;  // 0x0(0x8)
	struct UMDFastBindingValueBase* Value;  // 0x8(0x8)
	struct FString DefaultString;  // 0x10(0x10)
	struct FText DefaultText;  // 0x20(0x18)
	struct UObject* DefaultObject;  // 0x38(0x8)
	int32_t ExtendablePinListIndex;  // 0x40(0x4)
	struct FName ExtendablePinListNameBase;  // 0x44(0x8)
	char pad_76[84];  // 0x4C(0x54)
	char pad_160_1 : 7;  // 0xA0(0x1)
	bool bHasRetrievedDefaultValue : 1;  // 0xA0(0x1)
	char pad_161[7];  // 0xA1(0x7)

}; 
