#pragma once 
#include <ColorPicker_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass ColorPicker.ColorPicker_C
// Size: 0x618(Inherited: 0x608) 
struct UColorPicker_C : public UPortalWarsColorPickerWidget
{
	struct UImage* Image_101;  // 0x608(0x8)
	struct UImage* PreviewImage;  // 0x610(0x8)

}; 



