#pragma once 
#include <ControllerBindingAction_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass ControllerBindingAction.ControllerBindingAction_C
// Size: 0x5E0(Inherited: 0x5E0) 
struct UControllerBindingAction_C : public UPortalWarsGamepadBindingActionWidget
{

}; 



