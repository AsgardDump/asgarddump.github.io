#pragma once 
#include <ButtonBase_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass ButtonBase.ButtonBase_C
// Size: 0x790(Inherited: 0x688) 
struct UButtonBase_C : public UPortalWarsButtonWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x688(0x8)
	struct UImage* ButtonIcon;  // 0x690(0x8)
	struct UHorizontalBox* HorizontalBox_1;  // 0x698(0x8)
	struct USizeBox* IconSizeBox;  // 0x6A0(0x8)
	char pad_1704_1 : 7;  // 0x6A8(0x1)
	bool ShowIcon : 1;  // 0x6A8(0x1)
	char pad_1705[7];  // 0x6A9(0x7)
	struct FSlateBrush Icon;  // 0x6B0(0x88)
	struct FVector2D IconSize;  // 0x738(0x8)
	struct FText Label Name;  // 0x740(0x18)
	char EHorizontalAlignment Label Horizontal Alignment;  // 0x758(0x1)
	char pad_1881[3];  // 0x759(0x3)
	struct FLinearColor Graphic Color;  // 0x75C(0x10)
	char pad_1900[4];  // 0x76C(0x4)
	struct UMaterialInterface* Background Material;  // 0x770(0x8)
	struct FLinearColor Focus Border Color;  // 0x778(0x10)
	struct UWBP_GenericButton_C* UnderlyingButton;  // 0x788(0x8)

	void PreConstruct(bool IsDesignTime); // Function ButtonBase.ButtonBase_C.PreConstruct
	void Construct(); // Function ButtonBase.ButtonBase_C.Construct
	void ExecuteUbergraph_ButtonBase(int32_t EntryPoint); // Function ButtonBase.ButtonBase_C.ExecuteUbergraph_ButtonBase
}; 



