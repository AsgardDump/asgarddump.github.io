#pragma once 
#include <Dialog_GamepadReconnect_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass Dialog_GamepadReconnect.Dialog_GamepadReconnect_C
// Size: 0x8A0(Inherited: 0x860) 
struct UDialog_GamepadReconnect_C : public UPortalWarsGamepadReconnectWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x860(0x8)
	struct UDialogBackground_C* DialogBackground;  // 0x868(0x8)
	struct UImage* Image;  // 0x870(0x8)
	struct UImage* Image_2;  // 0x878(0x8)
	struct UImage* Image_53;  // 0x880(0x8)
	struct UImage* Image_176;  // 0x888(0x8)
	struct UImage* Image_299;  // 0x890(0x8)
	struct UImage* Image_405;  // 0x898(0x8)

	void Construct(); // Function Dialog_GamepadReconnect.Dialog_GamepadReconnect_C.Construct
	void ExecuteUbergraph_Dialog_GamepadReconnect(int32_t EntryPoint); // Function Dialog_GamepadReconnect.Dialog_GamepadReconnect_C.ExecuteUbergraph_Dialog_GamepadReconnect
}; 



