#pragma once 
#include <DiscardSettingsDialog_WidgetBP_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass DiscardSettingsDialog_WidgetBP.DiscardSettingsDialog_WidgetBP_C
// Size: 0x8B8(Inherited: 0x878) 
struct UDiscardSettingsDialog_WidgetBP_C : public UPortalWarsDiscardSettingsDialog
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x878(0x8)
	struct UDialogBackground_C* DialogBackground;  // 0x880(0x8)
	struct UImage* Image;  // 0x888(0x8)
	struct UImage* Image_2;  // 0x890(0x8)
	struct UImage* Image_53;  // 0x898(0x8)
	struct UImage* Image_176;  // 0x8A0(0x8)
	struct UImage* Image_299;  // 0x8A8(0x8)
	struct UImage* Image_405;  // 0x8B0(0x8)

	void Construct(); // Function DiscardSettingsDialog_WidgetBP.DiscardSettingsDialog_WidgetBP_C.Construct
	void ExecuteUbergraph_DiscardSettingsDialog_WidgetBP(int32_t EntryPoint); // Function DiscardSettingsDialog_WidgetBP.DiscardSettingsDialog_WidgetBP_C.ExecuteUbergraph_DiscardSettingsDialog_WidgetBP
}; 



