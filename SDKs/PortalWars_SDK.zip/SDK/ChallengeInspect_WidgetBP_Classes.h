#pragma once 
#include <ChallengeInspect_WidgetBP_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass ChallengeInspect_WidgetBP.ChallengeInspect_WidgetBP_C
// Size: 0x9E8(Inherited: 0x9A8) 
struct UChallengeInspect_WidgetBP_C : public UPortalWarsChallengesInspectWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x9A8(0x8)
	struct URichTextBlock* Equipped;  // 0x9B0(0x8)
	struct UOverlay* EquippedBox;  // 0x9B8(0x8)
	struct UImage* EquippedIcon;  // 0x9C0(0x8)
	struct UWBP_Footer_C* Footer;  // 0x9C8(0x8)
	struct UHeaderBase_C* HeaderBase;  // 0x9D0(0x8)
	struct UMenuBackground_C* MenuBackground;  // 0x9D8(0x8)
	struct UWBP_PageHeader_C* WBP_PageHeader;  // 0x9E0(0x8)

	void Construct(); // Function ChallengeInspect_WidgetBP.ChallengeInspect_WidgetBP_C.Construct
	void ExecuteUbergraph_ChallengeInspect_WidgetBP(int32_t EntryPoint); // Function ChallengeInspect_WidgetBP.ChallengeInspect_WidgetBP_C.ExecuteUbergraph_ChallengeInspect_WidgetBP
}; 



