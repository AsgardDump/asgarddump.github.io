#pragma once 
#include <CrosshairSelect_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass CrosshairSelect.CrosshairSelect_C
// Size: 0x608(Inherited: 0x600) 
struct UCrosshairSelect_C : public UPortalWarsCrosshairSelectWidget
{
	struct UImage* Image_101;  // 0x600(0x8)

}; 



