#pragma once 
#include <FPPAnimBlueprint_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass FPPAnimBlueprint.FPPAnimBlueprint_C
// Size: 0x1908(Inherited: 0x520) 
struct UFPPAnimBlueprint_C : public UPortalWarsAnimInstanceV2
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x520(0x8)
	struct FAnimNode_Root AnimGraphNode_Root;  // 0x528(0x30)
	struct FAnimNode_Slot AnimGraphNode_Slot_2;  // 0x558(0x48)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_6;  // 0x5A0(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_5;  // 0x5C8(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_4;  // 0x5F0(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_3;  // 0x618(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_2;  // 0x640(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult;  // 0x668(0x28)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_4;  // 0x690(0x80)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_4;  // 0x710(0x30)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_3;  // 0x740(0x80)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_3;  // 0x7C0(0x30)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_2;  // 0x7F0(0x80)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_2;  // 0x870(0x30)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer;  // 0x8A0(0x80)
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool_2;  // 0x920(0xA0)
	struct FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer_5;  // 0x9C0(0xE8)
	struct FAnimNode_StateResult AnimGraphNode_StateResult;  // 0xAA8(0x30)
	struct FAnimNode_StateMachine AnimGraphNode_StateMachine;  // 0xAD8(0xB0)
	struct FAnimNode_Slot AnimGraphNode_Slot;  // 0xB88(0x48)
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose_3;  // 0xBD0(0x158)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_6;  // 0xD28(0x28)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_5;  // 0xD50(0x28)
	struct FAnimNode_LayeredBoneBlend AnimGraphNode_LayeredBoneBlend_2;  // 0xD78(0xC0)
	struct FAnimNode_LayeredBoneBlend AnimGraphNode_LayeredBoneBlend;  // 0xE38(0xC0)
	struct FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer_4;  // 0xEF8(0xE8)
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose_2;  // 0xFE0(0x158)
	struct FAnimNode_BlendListByEnum AnimGraphNode_BlendListByEnum;  // 0x1138(0xB0)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_4;  // 0x11E8(0x28)
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose;  // 0x1210(0x158)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_3;  // 0x1368(0x28)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_2;  // 0x1390(0x28)
	struct FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer_3;  // 0x13B8(0xE8)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose;  // 0x14A0(0x28)
	struct FAnimNode_MakeDynamicAdditive AnimGraphNode_MakeDynamicAdditive;  // 0x14C8(0x38)
	struct FAnimNode_ApplyMeshSpaceAdditive AnimGraphNode_ApplyMeshSpaceAdditive;  // 0x1500(0xD0)
	struct FAnimNode_TwoWayBlend AnimGraphNode_TwoWayBlend;  // 0x15D0(0xC8)
	struct FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer_2;  // 0x1698(0xE8)
	struct FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer;  // 0x1780(0xE8)
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool;  // 0x1868(0xA0)

	void AnimGraph(struct FPoseLink& AnimGraph); // Function FPPAnimBlueprint.FPPAnimBlueprint_C.AnimGraph
	void ExecuteUbergraph_FPPAnimBlueprint(int32_t EntryPoint); // Function FPPAnimBlueprint.FPPAnimBlueprint_C.ExecuteUbergraph_FPPAnimBlueprint
}; 



