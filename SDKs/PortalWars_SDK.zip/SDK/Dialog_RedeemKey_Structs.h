#pragma once 
#include "SDK.h" 
 
 
// Function Dialog_RedeemKey.Dialog_RedeemKey_C.ExecuteUbergraph_Dialog_RedeemKey
// Size: 0x4(Inherited: 0x0) 
struct FExecuteUbergraph_Dialog_RedeemKey
{
	int32_t EntryPoint;  // 0x0(0x4)

}; 
