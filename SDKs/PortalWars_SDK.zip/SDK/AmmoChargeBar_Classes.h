#pragma once 
#include <AmmoChargeBar_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass AmmoChargeBar.AmmoChargeBar_C
// Size: 0x278(Inherited: 0x278) 
struct UAmmoChargeBar_C : public UPortalWarsAmmoCounterWidget
{

}; 



