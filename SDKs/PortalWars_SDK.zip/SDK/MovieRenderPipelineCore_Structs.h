#pragma once 
#include "SDK.h" 
 
 
// Function MovieRenderPipelineCore.MoviePipelineExecutorJob.GetStatusMessage
// Size: 0x10(Inherited: 0x0) 
struct FGetStatusMessage
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// ScriptStruct MovieRenderPipelineCore.MoviePipelineShotOutputData
// Size: 0x58(Inherited: 0x0) 
struct FMoviePipelineShotOutputData
{
	struct TWeakObjectPtr<UMoviePipelineExecutorShot> Shot;  // 0x0(0x8)
	struct TMap<struct FMoviePipelinePassIdentifier, struct FMoviePipelineRenderPassOutputData> RenderPassData;  // 0x8(0x50)

}; 
// ScriptStruct MovieRenderPipelineCore.MoviePipelineSegmentWorkMetrics
// Size: 0x28(Inherited: 0x0) 
struct FMoviePipelineSegmentWorkMetrics
{
	struct FString SegmentName;  // 0x0(0x10)
	int32_t OutputFrameIndex;  // 0x10(0x4)
	int32_t TotalOutputFrameCount;  // 0x14(0x4)
	int32_t OutputSubSampleIndex;  // 0x18(0x4)
	int32_t TotalSubSampleCount;  // 0x1C(0x4)
	int32_t EngineWarmUpFrameIndex;  // 0x20(0x4)
	int32_t TotalEngineWarmUpFrameCount;  // 0x24(0x4)

}; 
// ScriptStruct MovieRenderPipelineCore.MoviePipelineOutputData
// Size: 0x28(Inherited: 0x0) 
struct FMoviePipelineOutputData
{
	struct UMoviePipeline* Pipeline;  // 0x0(0x8)
	struct UMoviePipelineExecutorJob* Job;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bSuccess : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct TArray<struct FMoviePipelineShotOutputData> ShotData;  // 0x18(0x10)

}; 
// DelegateFunction MovieRenderPipelineCore.MoviePipelineFinished__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FMoviePipelineFinished__DelegateSignature
{
	struct UMoviePipeline* MoviePipeline;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bFatalError : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function MovieRenderPipelineCore.MoviePipelineBlueprintLibrary.GetJobInitializationTime
// Size: 0x10(Inherited: 0x0) 
struct FGetJobInitializationTime
{
	struct UMoviePipeline* InMoviePipeline;  // 0x0(0x8)
	struct FDateTime ReturnValue;  // 0x8(0x8)

}; 
// DelegateFunction MovieRenderPipelineCore.OnMoviePipelineExecutorErrored__DelegateSignature
// Size: 0x30(Inherited: 0x0) 
struct FOnMoviePipelineExecutorErrored__DelegateSignature
{
	struct UMoviePipelineExecutorBase* PipelineExecutor;  // 0x0(0x8)
	struct UMoviePipeline* PipelineWithError;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bIsFatal : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct FText ErrorText;  // 0x18(0x18)

}; 
// DelegateFunction MovieRenderPipelineCore.MoviePipelineWorkFinished__DelegateSignature
// Size: 0x28(Inherited: 0x0) 
struct FMoviePipelineWorkFinished__DelegateSignature
{
	struct FMoviePipelineOutputData Results;  // 0x0(0x28)

}; 
// Function MovieRenderPipelineCore.MoviePipelineBlueprintLibrary.GetMasterFrameNumber
// Size: 0x10(Inherited: 0x0) 
struct FGetMasterFrameNumber
{
	struct UMoviePipeline* InMoviePipeline;  // 0x0(0x8)
	struct FFrameNumber ReturnValue;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)

}; 
// ScriptStruct MovieRenderPipelineCore.MoviePipelinePassIdentifier
// Size: 0x10(Inherited: 0x0) 
struct FMoviePipelinePassIdentifier
{
	struct FString Name;  // 0x0(0x10)

}; 
// Function MovieRenderPipelineCore.MoviePipelineConfigBase.FindSettingByClass
// Size: 0x18(Inherited: 0x0) 
struct FFindSettingByClass
{
	UMoviePipelineSetting* InClass;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bIncludeDisabledSettings : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct UMoviePipelineSetting* ReturnValue;  // 0x10(0x8)

}; 
// Function MovieRenderPipelineCore.MoviePipelineBlueprintLibrary.GetCurrentSegmentWorkMetrics
// Size: 0x30(Inherited: 0x0) 
struct FGetCurrentSegmentWorkMetrics
{
	struct UMoviePipeline* InMoviePipeline;  // 0x0(0x8)
	struct FMoviePipelineSegmentWorkMetrics ReturnValue;  // 0x8(0x28)

}; 
// Function MovieRenderPipelineCore.MoviePipelineQueue.DuplicateJob
// Size: 0x10(Inherited: 0x0) 
struct FDuplicateJob
{
	struct UMoviePipelineExecutorJob* InJob;  // 0x0(0x8)
	struct UMoviePipelineExecutorJob* ReturnValue;  // 0x8(0x8)

}; 
// ScriptStruct MovieRenderPipelineCore.MoviePipelineRenderPassOutputData
// Size: 0x10(Inherited: 0x0) 
struct FMoviePipelineRenderPassOutputData
{
	struct TArray<struct FString> FilePaths;  // 0x0(0x10)

}; 
// ScriptStruct MovieRenderPipelineCore.MoviePipelineFilenameResolveParams
// Size: 0x100(Inherited: 0x0) 
struct FMoviePipelineFilenameResolveParams
{
	int32_t FrameNumber;  // 0x0(0x4)
	int32_t FrameNumberShot;  // 0x4(0x4)
	int32_t FrameNumberRel;  // 0x8(0x4)
	int32_t FrameNumberShotRel;  // 0xC(0x4)
	struct FString CameraNameOverride;  // 0x10(0x10)
	struct FString ShotNameOverride;  // 0x20(0x10)
	int32_t ZeroPadFrameNumberCount;  // 0x30(0x4)
	char pad_52_1 : 7;  // 0x34(0x1)
	bool bForceRelativeFrameNumbers : 1;  // 0x34(0x1)
	char pad_53[3];  // 0x35(0x3)
	struct TMap<struct FString, struct FString> FileNameFormatOverrides;  // 0x38(0x50)
	struct TMap<struct FString, struct FString> FileMetadata;  // 0x88(0x50)
	struct FDateTime InitializationTime;  // 0xD8(0x8)
	int32_t InitializationVersion;  // 0xE0(0x4)
	char pad_228[4];  // 0xE4(0x4)
	struct UMoviePipelineExecutorJob* Job;  // 0xE8(0x8)
	struct UMoviePipelineExecutorShot* ShotOverride;  // 0xF0(0x8)
	int32_t AdditionalFrameNumberOffset;  // 0xF8(0x4)
	char pad_252[4];  // 0xFC(0x4)

}; 
// DelegateFunction MovieRenderPipelineCore.OnMoviePipelineExecutorFinished__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FOnMoviePipelineExecutorFinished__DelegateSignature
{
	struct UMoviePipelineExecutorBase* PipelineExecutor;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bSuccess : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// DelegateFunction MovieRenderPipelineCore.MoviePipelineSocketMessageRecieved__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FMoviePipelineSocketMessageRecieved__DelegateSignature
{
	struct FString Message;  // 0x0(0x10)

}; 
// Function MovieRenderPipelineCore.MoviePipelineBlueprintLibrary.GetCurrentSegmentName
// Size: 0x38(Inherited: 0x0) 
struct FGetCurrentSegmentName
{
	struct UMoviePipeline* InMoviePipeline;  // 0x0(0x8)
	struct FText OutOuterName;  // 0x8(0x18)
	struct FText OutInnerName;  // 0x20(0x18)

}; 
// DelegateFunction MovieRenderPipelineCore.MoviePipelineHttpResponseRecieved__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FMoviePipelineHttpResponseRecieved__DelegateSignature
{
	int32_t RequestIndex;  // 0x0(0x4)
	int32_t ResponseCode;  // 0x4(0x4)
	struct FString Message;  // 0x8(0x10)

}; 
// ScriptStruct MovieRenderPipelineCore.MoviePipelineFormatArgs
// Size: 0xA8(Inherited: 0x0) 
struct FMoviePipelineFormatArgs
{
	struct TMap<struct FString, struct FString> FilenameArguments;  // 0x0(0x50)
	struct TMap<struct FString, struct FString> FileMetadata;  // 0x50(0x50)
	struct UMoviePipelineExecutorJob* InJob;  // 0xA0(0x8)

}; 
// Function MovieRenderPipelineCore.MoviePipelineBlueprintLibrary.GetEstimatedTimeRemaining
// Size: 0x18(Inherited: 0x0) 
struct FGetEstimatedTimeRemaining
{
	struct UMoviePipeline* InPipeline;  // 0x0(0x8)
	struct FTimespan OutEstimate;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// ScriptStruct MovieRenderPipelineCore.MoviePipelineCameraCutInfo
// Size: 0x98(Inherited: 0x0) 
struct FMoviePipelineCameraCutInfo
{
	char pad_0[152];  // 0x0(0x98)

}; 
// Function MovieRenderPipelineCore.MoviePipeline.GetPipelineMasterConfig
// Size: 0x8(Inherited: 0x0) 
struct FGetPipelineMasterConfig
{
	struct UMoviePipelineMasterConfig* ReturnValue;  // 0x0(0x8)

}; 
// Function MovieRenderPipelineCore.MoviePipelineExecutorBase.Execute
// Size: 0x8(Inherited: 0x0) 
struct FExecute
{
	struct UMoviePipelineQueue* InPipelineQueue;  // 0x0(0x8)

}; 
// Function MovieRenderPipelineCore.MoviePipeline.GetPreviewTexture
// Size: 0x8(Inherited: 0x0) 
struct FGetPreviewTexture
{
	struct UTexture* ReturnValue;  // 0x0(0x8)

}; 
// Function MovieRenderPipelineCore.MoviePipeline.Initialize
// Size: 0x8(Inherited: 0x0) 
struct FInitialize
{
	struct UMoviePipelineExecutorJob* InJob;  // 0x0(0x8)

}; 
// Function MovieRenderPipelineCore.MoviePipeline.IsShutdownRequested
// Size: 0x1(Inherited: 0x0) 
struct FIsShutdownRequested
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function MovieRenderPipelineCore.MoviePipeline.RequestShutdown
// Size: 0x1(Inherited: 0x0) 
struct FRequestShutdown
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bIsError : 1;  // 0x0(0x1)

}; 
// Function MovieRenderPipelineCore.MoviePipelineExecutorBase.IsSocketConnected
// Size: 0x1(Inherited: 0x0) 
struct FIsSocketConnected
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function MovieRenderPipelineCore.MoviePipelineConfigBase.RemoveSetting
// Size: 0x8(Inherited: 0x0) 
struct FRemoveSetting
{
	struct UMoviePipelineSetting* InSetting;  // 0x0(0x8)

}; 
// Function MovieRenderPipelineCore.MoviePipelineSetting.BuildNewProcessCommandLine
// Size: 0x20(Inherited: 0x0) 
struct FBuildNewProcessCommandLine
{
	struct FString InOutUnrealURLParams;  // 0x0(0x10)
	struct FString InOutCommandLineArgs;  // 0x10(0x10)

}; 
// Function MovieRenderPipelineCore.MoviePipeline.Shutdown
// Size: 0x1(Inherited: 0x0) 
struct FShutdown
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bError : 1;  // 0x0(0x1)

}; 
// Function MovieRenderPipelineCore.MoviePipelineBlueprintLibrary.DuplicateSequence
// Size: 0x18(Inherited: 0x0) 
struct FDuplicateSequence
{
	struct UObject* Outer;  // 0x0(0x8)
	struct UMovieSceneSequence* InSequence;  // 0x8(0x8)
	struct UMovieSceneSequence* ReturnValue;  // 0x10(0x8)

}; 
// Function MovieRenderPipelineCore.MoviePipelineBlueprintLibrary.FindOrGetDefaultSettingForShot
// Size: 0x20(Inherited: 0x0) 
struct FFindOrGetDefaultSettingForShot
{
	UMoviePipelineSetting* InSettingType;  // 0x0(0x8)
	struct UMoviePipelineMasterConfig* InMasterConfig;  // 0x8(0x8)
	struct UMoviePipelineExecutorShot* InShot;  // 0x10(0x8)
	struct UMoviePipelineSetting* ReturnValue;  // 0x18(0x8)

}; 
// Function MovieRenderPipelineCore.MoviePipelineBlueprintLibrary.GetMasterTimecode
// Size: 0x20(Inherited: 0x0) 
struct FGetMasterTimecode
{
	struct UMoviePipeline* InMoviePipeline;  // 0x0(0x8)
	struct FTimecode ReturnValue;  // 0x8(0x14)
	char pad_28[4];  // 0x1C(0x4)

}; 
// Function MovieRenderPipelineCore.MoviePipelineBlueprintLibrary.GetCompletionPercentage
// Size: 0x10(Inherited: 0x0) 
struct FGetCompletionPercentage
{
	struct UMoviePipeline* InPipeline;  // 0x0(0x8)
	float ReturnValue;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)

}; 
// Function MovieRenderPipelineCore.MoviePipelineBlueprintLibrary.ResolveVersionNumber
// Size: 0x108(Inherited: 0x0) 
struct FResolveVersionNumber
{
	struct FMoviePipelineFilenameResolveParams InParams;  // 0x0(0x100)
	int32_t ReturnValue;  // 0x100(0x4)
	char pad_260[4];  // 0x104(0x4)

}; 
// Function MovieRenderPipelineCore.MoviePipelineBlueprintLibrary.GetCurrentAperture
// Size: 0x10(Inherited: 0x0) 
struct FGetCurrentAperture
{
	struct UMoviePipeline* InMoviePipeline;  // 0x0(0x8)
	float ReturnValue;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)

}; 
// Function MovieRenderPipelineCore.MoviePipelineBlueprintLibrary.GetCurrentFocalLength
// Size: 0x10(Inherited: 0x0) 
struct FGetCurrentFocalLength
{
	struct UMoviePipeline* InMoviePipeline;  // 0x0(0x8)
	float ReturnValue;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)

}; 
// Function MovieRenderPipelineCore.MoviePipelineConfigBase.FindOrAddSettingByClass
// Size: 0x18(Inherited: 0x0) 
struct FFindOrAddSettingByClass
{
	UMoviePipelineSetting* InClass;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bIncludeDisabledSettings : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct UMoviePipelineSetting* ReturnValue;  // 0x10(0x8)

}; 
// Function MovieRenderPipelineCore.MoviePipelineBlueprintLibrary.GetCurrentFocusDistance
// Size: 0x10(Inherited: 0x0) 
struct FGetCurrentFocusDistance
{
	struct UMoviePipeline* InMoviePipeline;  // 0x0(0x8)
	float ReturnValue;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)

}; 
// Function MovieRenderPipelineCore.MoviePipelineExecutorJob.GetStatusProgress
// Size: 0x4(Inherited: 0x0) 
struct FGetStatusProgress
{
	float ReturnValue;  // 0x0(0x4)

}; 
// Function MovieRenderPipelineCore.MoviePipelineBlueprintLibrary.GetCurrentSegmentState
// Size: 0x10(Inherited: 0x0) 
struct FGetCurrentSegmentState
{
	struct UMoviePipeline* InMoviePipeline;  // 0x0(0x8)
	uint8_t  ReturnValue;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function MovieRenderPipelineCore.MoviePipelineBlueprintLibrary.GetCurrentShotFrameNumber
// Size: 0x10(Inherited: 0x0) 
struct FGetCurrentShotFrameNumber
{
	struct UMoviePipeline* InMoviePipeline;  // 0x0(0x8)
	struct FFrameNumber ReturnValue;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)

}; 
// Function MovieRenderPipelineCore.MoviePipelineExecutorBase.ConnectSocket
// Size: 0x18(Inherited: 0x0) 
struct FConnectSocket
{
	struct FString InHostName;  // 0x0(0x10)
	int32_t InPort;  // 0x10(0x4)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool ReturnValue : 1;  // 0x14(0x1)
	char pad_21[3];  // 0x15(0x3)

}; 
// Function MovieRenderPipelineCore.MoviePipelineBlueprintLibrary.GetCurrentShotTimecode
// Size: 0x20(Inherited: 0x0) 
struct FGetCurrentShotTimecode
{
	struct UMoviePipeline* InMoviePipeline;  // 0x0(0x8)
	struct FTimecode ReturnValue;  // 0x8(0x14)
	char pad_28[4];  // 0x1C(0x4)

}; 
// Function MovieRenderPipelineCore.MoviePipelineBlueprintLibrary.GetEffectiveOutputResolution
// Size: 0x18(Inherited: 0x0) 
struct FGetEffectiveOutputResolution
{
	struct UMoviePipelineMasterConfig* InMasterConfig;  // 0x0(0x8)
	struct UMoviePipelineExecutorShot* InPipelineExecutorShot;  // 0x8(0x8)
	struct FIntPoint ReturnValue;  // 0x10(0x8)

}; 
// Function MovieRenderPipelineCore.MoviePipelineConfigBase.GetUserSettings
// Size: 0x10(Inherited: 0x0) 
struct FGetUserSettings
{
	struct TArray<struct UMoviePipelineSetting*> ReturnValue;  // 0x0(0x10)

}; 
// Function MovieRenderPipelineCore.MoviePipelineBlueprintLibrary.GetJobAuthor
// Size: 0x20(Inherited: 0x0) 
struct FGetJobAuthor
{
	struct UMoviePipeline* InMoviePipeline;  // 0x0(0x8)
	struct FText ReturnValue;  // 0x8(0x18)

}; 
// Function MovieRenderPipelineCore.MoviePipelineBlueprintLibrary.GetJobName
// Size: 0x20(Inherited: 0x0) 
struct FGetJobName
{
	struct UMoviePipeline* InMoviePipeline;  // 0x0(0x8)
	struct FText ReturnValue;  // 0x8(0x18)

}; 
// Function MovieRenderPipelineCore.MoviePipelineBlueprintLibrary.GetMapPackageName
// Size: 0x18(Inherited: 0x0) 
struct FGetMapPackageName
{
	struct UMoviePipelineExecutorJob* InJob;  // 0x0(0x8)
	struct FString ReturnValue;  // 0x8(0x10)

}; 
// Function MovieRenderPipelineCore.MoviePipelineBlueprintLibrary.GetOverallOutputFrames
// Size: 0x10(Inherited: 0x0) 
struct FGetOverallOutputFrames
{
	struct UMoviePipeline* InMoviePipeline;  // 0x0(0x8)
	int32_t OutCurrentIndex;  // 0x8(0x4)
	int32_t OutTotalCount;  // 0xC(0x4)

}; 
// Function MovieRenderPipelineCore.MoviePipelineExecutorBase.SendSocketMessage
// Size: 0x18(Inherited: 0x0) 
struct FSendSocketMessage
{
	struct FString InMessage;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function MovieRenderPipelineCore.MoviePipelineBlueprintLibrary.GetOverallSegmentCounts
// Size: 0x10(Inherited: 0x0) 
struct FGetOverallSegmentCounts
{
	struct UMoviePipeline* InMoviePipeline;  // 0x0(0x8)
	int32_t OutCurrentIndex;  // 0x8(0x4)
	int32_t OutTotalCount;  // 0xC(0x4)

}; 
// Function MovieRenderPipelineCore.MoviePipelineBlueprintLibrary.GetPipelineState
// Size: 0x10(Inherited: 0x0) 
struct FGetPipelineState
{
	struct UMoviePipeline* InPipeline;  // 0x0(0x8)
	uint8_t  ReturnValue;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function MovieRenderPipelineCore.MoviePipelineBlueprintLibrary.ResolveFilenameFormatArguments
// Size: 0x1C8(Inherited: 0x0) 
struct FResolveFilenameFormatArguments
{
	struct FString InFormatString;  // 0x0(0x10)
	struct FMoviePipelineFilenameResolveParams InParams;  // 0x10(0x100)
	struct FString OutFinalPath;  // 0x110(0x10)
	struct FMoviePipelineFormatArgs OutMergedFormatArgs;  // 0x120(0xA8)

}; 
// Function MovieRenderPipelineCore.MoviePipelineBlueprintLibrary.UpdateJobShotListFromSequence
// Size: 0x18(Inherited: 0x0) 
struct FUpdateJobShotListFromSequence
{
	struct ULevelSequence* InSequence;  // 0x0(0x8)
	struct UMoviePipelineExecutorJob* InJob;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bShotsChanged : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function MovieRenderPipelineCore.MoviePipelineQueue.CopyFrom
// Size: 0x8(Inherited: 0x0) 
struct FCopyFrom
{
	struct UMoviePipelineQueue* InQueue;  // 0x0(0x8)

}; 
// Function MovieRenderPipelineCore.MoviePipelineConfigBase.FindSettingsByClass
// Size: 0x20(Inherited: 0x0) 
struct FFindSettingsByClass
{
	UMoviePipelineSetting* InClass;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bIncludeDisabledSettings : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct TArray<struct UMoviePipelineSetting*> ReturnValue;  // 0x10(0x10)

}; 
// Function MovieRenderPipelineCore.MoviePipelineQueueEngineSubsystem.IsRendering
// Size: 0x1(Inherited: 0x0) 
struct FIsRendering
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function MovieRenderPipelineCore.MoviePipelineExecutorJob.SetStatusProgress
// Size: 0x4(Inherited: 0x0) 
struct FSetStatusProgress
{
	float InProgress;  // 0x0(0x4)

}; 
// Function MovieRenderPipelineCore.MoviePipelineExecutorBase.OnExecutorErroredImpl
// Size: 0x28(Inherited: 0x0) 
struct FOnExecutorErroredImpl
{
	struct UMoviePipeline* ErroredPipeline;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bFatal : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct FText ErrorReason;  // 0x10(0x18)

}; 
// Function MovieRenderPipelineCore.MoviePipelineExecutorBase.SendHTTPRequest
// Size: 0x88(Inherited: 0x0) 
struct FSendHTTPRequest
{
	struct FString InURL;  // 0x0(0x10)
	struct FString InVerb;  // 0x10(0x10)
	struct FString InMessage;  // 0x20(0x10)
	struct TMap<struct FString, struct FString> InHeaders;  // 0x30(0x50)
	int32_t ReturnValue;  // 0x80(0x4)
	char pad_132[4];  // 0x84(0x4)

}; 
// Function MovieRenderPipelineCore.MoviePipelineExecutorBase.SetMoviePipelineClass
// Size: 0x8(Inherited: 0x0) 
struct FSetMoviePipelineClass
{
	UObject* InPipelineClass;  // 0x0(0x8)

}; 
// Function MovieRenderPipelineCore.MoviePipelineExecutorJob.SetStatusMessage
// Size: 0x10(Inherited: 0x0) 
struct FSetStatusMessage
{
	struct FString InStatus;  // 0x0(0x10)

}; 
// Function MovieRenderPipelineCore.MoviePipelineMasterConfig.GetAllSettings
// Size: 0x18(Inherited: 0x0) 
struct FGetAllSettings
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bIncludeDisabledSettings : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool bIncludeTransientSettings : 1;  // 0x1(0x1)
	char pad_2[6];  // 0x2(0x6)
	struct TArray<struct UMoviePipelineSetting*> ReturnValue;  // 0x8(0x10)

}; 
// Function MovieRenderPipelineCore.MoviePipelineMasterConfig.GetEffectiveFrameRate
// Size: 0x10(Inherited: 0x0) 
struct FGetEffectiveFrameRate
{
	struct ULevelSequence* InSequence;  // 0x0(0x8)
	struct FFrameRate ReturnValue;  // 0x8(0x8)

}; 
// Function MovieRenderPipelineCore.MoviePipelineMasterConfig.GetTransientSettings
// Size: 0x10(Inherited: 0x0) 
struct FGetTransientSettings
{
	struct TArray<struct UMoviePipelineSetting*> ReturnValue;  // 0x0(0x10)

}; 
// Function MovieRenderPipelineCore.MoviePipelinePythonHostExecutor.ExecuteDelayed
// Size: 0x8(Inherited: 0x0) 
struct FExecuteDelayed
{
	struct UMoviePipelineQueue* InPipelineQueue;  // 0x0(0x8)

}; 
// Function MovieRenderPipelineCore.MoviePipelinePythonHostExecutor.GetLastLoadedWorld
// Size: 0x8(Inherited: 0x0) 
struct FGetLastLoadedWorld
{
	struct UWorld* ReturnValue;  // 0x0(0x8)

}; 
// Function MovieRenderPipelineCore.MoviePipelinePythonHostExecutor.OnMapLoad
// Size: 0x8(Inherited: 0x0) 
struct FOnMapLoad
{
	struct UWorld* InWorld;  // 0x0(0x8)

}; 
// Function MovieRenderPipelineCore.MoviePipelineExecutorShot.AllocateNewShotOverrideConfig
// Size: 0x10(Inherited: 0x0) 
struct FAllocateNewShotOverrideConfig
{
	UMoviePipelineShotConfig* InConfigType;  // 0x0(0x8)
	struct UMoviePipelineShotConfig* ReturnValue;  // 0x8(0x8)

}; 
// Function MovieRenderPipelineCore.MoviePipelineExecutorShot.GetShotOverrideConfiguration
// Size: 0x8(Inherited: 0x0) 
struct FGetShotOverrideConfiguration
{
	struct UMoviePipelineShotConfig* ReturnValue;  // 0x0(0x8)

}; 
// Function MovieRenderPipelineCore.MoviePipelineExecutorShot.GetShotOverridePresetOrigin
// Size: 0x8(Inherited: 0x0) 
struct FGetShotOverridePresetOrigin
{
	struct UMoviePipelineShotConfig* ReturnValue;  // 0x0(0x8)

}; 
// Function MovieRenderPipelineCore.MoviePipelineExecutorShot.SetShotOverrideConfiguration
// Size: 0x8(Inherited: 0x0) 
struct FSetShotOverrideConfiguration
{
	struct UMoviePipelineShotConfig* InPreset;  // 0x0(0x8)

}; 
// Function MovieRenderPipelineCore.MoviePipelineExecutorShot.SetShotOverridePresetOrigin
// Size: 0x8(Inherited: 0x0) 
struct FSetShotOverridePresetOrigin
{
	struct UMoviePipelineShotConfig* InPreset;  // 0x0(0x8)

}; 
// Function MovieRenderPipelineCore.MoviePipelineExecutorShot.ShouldRender
// Size: 0x1(Inherited: 0x0) 
struct FShouldRender
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function MovieRenderPipelineCore.MoviePipelineExecutorJob.GetConfiguration
// Size: 0x8(Inherited: 0x0) 
struct FGetConfiguration
{
	struct UMoviePipelineMasterConfig* ReturnValue;  // 0x0(0x8)

}; 
// Function MovieRenderPipelineCore.MoviePipelineExecutorJob.GetPresetOrigin
// Size: 0x8(Inherited: 0x0) 
struct FGetPresetOrigin
{
	struct UMoviePipelineMasterConfig* ReturnValue;  // 0x0(0x8)

}; 
// Function MovieRenderPipelineCore.MoviePipelineExecutorJob.IsConsumed
// Size: 0x1(Inherited: 0x0) 
struct FIsConsumed
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function MovieRenderPipelineCore.MoviePipelineExecutorJob.SetConfiguration
// Size: 0x8(Inherited: 0x0) 
struct FSetConfiguration
{
	struct UMoviePipelineMasterConfig* InPreset;  // 0x0(0x8)

}; 
// Function MovieRenderPipelineCore.MoviePipelineExecutorJob.SetConsumed
// Size: 0x1(Inherited: 0x0) 
struct FSetConsumed
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bInConsumed : 1;  // 0x0(0x1)

}; 
// Function MovieRenderPipelineCore.MoviePipelineExecutorJob.SetPresetOrigin
// Size: 0x8(Inherited: 0x0) 
struct FSetPresetOrigin
{
	struct UMoviePipelineMasterConfig* InPreset;  // 0x0(0x8)

}; 
// Function MovieRenderPipelineCore.MoviePipelineExecutorJob.SetSequence
// Size: 0x18(Inherited: 0x0) 
struct FSetSequence
{
	struct FSoftObjectPath InSequence;  // 0x0(0x18)

}; 
// Function MovieRenderPipelineCore.MoviePipelineQueue.AllocateNewJob
// Size: 0x10(Inherited: 0x0) 
struct FAllocateNewJob
{
	UMoviePipelineExecutorJob* InJobType;  // 0x0(0x8)
	struct UMoviePipelineExecutorJob* ReturnValue;  // 0x8(0x8)

}; 
// Function MovieRenderPipelineCore.MoviePipelineQueue.DeleteJob
// Size: 0x8(Inherited: 0x0) 
struct FDeleteJob
{
	struct UMoviePipelineExecutorJob* InJob;  // 0x0(0x8)

}; 
// Function MovieRenderPipelineCore.MoviePipelineQueue.GetJobs
// Size: 0x10(Inherited: 0x0) 
struct FGetJobs
{
	struct TArray<struct UMoviePipelineExecutorJob*> ReturnValue;  // 0x0(0x10)

}; 
// Function MovieRenderPipelineCore.MoviePipelineQueueEngineSubsystem.GetActiveExecutor
// Size: 0x8(Inherited: 0x0) 
struct FGetActiveExecutor
{
	struct UMoviePipelineExecutorBase* ReturnValue;  // 0x0(0x8)

}; 
// Function MovieRenderPipelineCore.MoviePipelineQueueEngineSubsystem.GetQueue
// Size: 0x8(Inherited: 0x0) 
struct FGetQueue
{
	struct UMoviePipelineQueue* ReturnValue;  // 0x0(0x8)

}; 
// Function MovieRenderPipelineCore.MoviePipelineQueueEngineSubsystem.RenderQueueWithExecutor
// Size: 0x10(Inherited: 0x0) 
struct FRenderQueueWithExecutor
{
	UMoviePipelineExecutorBase* InExecutorType;  // 0x0(0x8)
	struct UMoviePipelineExecutorBase* ReturnValue;  // 0x8(0x8)

}; 
// Function MovieRenderPipelineCore.MoviePipelineQueueEngineSubsystem.RenderQueueWithExecutorInstance
// Size: 0x8(Inherited: 0x0) 
struct FRenderQueueWithExecutorInstance
{
	struct UMoviePipelineExecutorBase* InExecutor;  // 0x0(0x8)

}; 
// Function MovieRenderPipelineCore.MovieRenderDebugWidget.OnInitializedForPipeline
// Size: 0x8(Inherited: 0x0) 
struct FOnInitializedForPipeline
{
	struct UMoviePipeline* ForPipeline;  // 0x0(0x8)

}; 
