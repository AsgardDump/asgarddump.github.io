#pragma once 
#include <DropsMenu_WidgetBP_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass DropsMenu_WidgetBP.DropsMenu_WidgetBP_C
// Size: 0x840(Inherited: 0x820) 
struct UDropsMenu_WidgetBP_C : public UPortalWarsDropsMenuWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x820(0x8)
	struct UImage* Image_81;  // 0x828(0x8)
	struct UImage* Image_89;  // 0x830(0x8)
	struct UImage* Image_101;  // 0x838(0x8)

	void Construct(); // Function DropsMenu_WidgetBP.DropsMenu_WidgetBP_C.Construct
	void ExecuteUbergraph_DropsMenu_WidgetBP(int32_t EntryPoint); // Function DropsMenu_WidgetBP.DropsMenu_WidgetBP_C.ExecuteUbergraph_DropsMenu_WidgetBP
}; 



