#include "SDK.h" 
 
 
void AActor::Set Intensity(){

	static UObject* p_Set Intensity = UObject::FindObject<UFunction>("Function BP_Flashlight_Demo.BP_Flashlight_Demo_C.Set Intensity");

	struct {
	} parms;


	ProcessEvent(p_Set Intensity, &parms);
}

void AActor::UserConstructionScript(){

	static UObject* p_UserConstructionScript = UObject::FindObject<UFunction>("Function BP_Flashlight_Demo.BP_Flashlight_Demo_C.UserConstructionScript");

	struct {
	} parms;


	ProcessEvent(p_UserConstructionScript, &parms);
}

void AActor::ReceiveBeginPlay(){

	static UObject* p_ReceiveBeginPlay = UObject::FindObject<UFunction>("Function BP_Flashlight_Demo.BP_Flashlight_Demo_C.ReceiveBeginPlay");

	struct {
	} parms;


	ProcessEvent(p_ReceiveBeginPlay, &parms);
}

void AActor::TurnOn(){

	static UObject* p_TurnOn = UObject::FindObject<UFunction>("Function BP_Flashlight_Demo.BP_Flashlight_Demo_C.TurnOn");

	struct {
	} parms;


	ProcessEvent(p_TurnOn, &parms);
}

void AActor::TurnOff(){

	static UObject* p_TurnOff = UObject::FindObject<UFunction>("Function BP_Flashlight_Demo.BP_Flashlight_Demo_C.TurnOff");

	struct {
	} parms;


	ProcessEvent(p_TurnOff, &parms);
}

void AActor::(){

	static UObject* p_ = UObject::FindObject<UFunction>("Function BP_Flashlight_Demo.BP_Flashlight_Demo_C.");

	struct {
	} parms;


	ProcessEvent(p_, &parms);
}

void AActor::ExecuteUbergraph_BP_Flashlight_Demo(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph_BP_Flashlight_Demo = UObject::FindObject<UFunction>("Function BP_Flashlight_Demo.BP_Flashlight_Demo_C.ExecuteUbergraph_BP_Flashlight_Demo");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph_BP_Flashlight_Demo, &parms);
}

