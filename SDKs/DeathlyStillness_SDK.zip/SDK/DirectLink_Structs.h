#pragma once 
#include "SDK.h" 
 
 
// ScriptStruct DirectLink.DirectLinkMsg_HaveListMessage
// Size: 0x40(Inherited: 0x0) 
struct FDirectLinkMsg_HaveListMessage
{
	int32_t SourceStreamPort;  // 0x0(0x4)
	int32_t SyncCycle;  // 0x4(0x4)
	int32_t MessageCode;  // 0x8(0x4)
	char Kind;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)
	struct TArray<char> Payload;  // 0x10(0x10)
	struct TArray<int32_t> NodeIds;  // 0x20(0x10)
	struct TArray<int32_t> Hashes;  // 0x30(0x10)

}; 
// ScriptStruct DirectLink.DirectLinkMsg_CloseStreamRequest
// Size: 0x4(Inherited: 0x0) 
struct FDirectLinkMsg_CloseStreamRequest
{
	int32_t RecipientStreamPort;  // 0x0(0x4)

}; 
// ScriptStruct DirectLink.DirectLinkMsg_DeltaMessage
// Size: 0x20(Inherited: 0x0) 
struct FDirectLinkMsg_DeltaMessage
{
	int32_t DestinationStreamPort;  // 0x0(0x4)
	int8_t BatchCode;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	int32_t MessageCode;  // 0x8(0x4)
	char Kind;  // 0xC(0x1)
	char pad_13_1 : 7;  // 0xD(0x1)
	bool CompressedPayload : 1;  // 0xD(0x1)
	char pad_14[2];  // 0xE(0x2)
	struct TArray<char> Payload;  // 0x10(0x10)

}; 
// ScriptStruct DirectLink.DirectLinkMsg_QueryEndpointState
// Size: 0x1(Inherited: 0x0) 
struct FDirectLinkMsg_QueryEndpointState
{
	char pad_0[1];  // 0x0(0x1)

}; 
// ScriptStruct DirectLink.DirectLinkMsg_OpenStreamAnswer
// Size: 0x20(Inherited: 0x0) 
struct FDirectLinkMsg_OpenStreamAnswer
{
	int32_t RecipientStreamPort;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool bAccepted : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct FString Error;  // 0x8(0x10)
	int32_t OpenedStreamPort;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)

}; 
// ScriptStruct DirectLink.DirectLinkMsg_OpenStreamRequest
// Size: 0x28(Inherited: 0x0) 
struct FDirectLinkMsg_OpenStreamRequest
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bRequestFromSource : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	int32_t RequestFromStreamPort;  // 0x4(0x4)
	struct FGuid SourceGuid;  // 0x8(0x10)
	struct FGuid DestinationGuid;  // 0x18(0x10)

}; 
// ScriptStruct DirectLink.NamedId
// Size: 0x28(Inherited: 0x0) 
struct FNamedId
{
	struct FString Name;  // 0x0(0x10)
	struct FGuid ID;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool bIsPublic : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// ScriptStruct DirectLink.DirectLinkMsg_EndpointState
// Size: 0x88(Inherited: 0x0) 
struct FDirectLinkMsg_EndpointState
{
	uint32_t StateRevision;  // 0x0(0x4)
	uint32_t MinProtocolVersion;  // 0x4(0x4)
	uint32_t ProtocolVersion;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct FString UEVersion;  // 0x10(0x10)
	struct FString ComputerName;  // 0x20(0x10)
	struct FString UserName;  // 0x30(0x10)
	uint32_t ProcessId;  // 0x40(0x4)
	char pad_68[4];  // 0x44(0x4)
	struct FString ExecutableName;  // 0x48(0x10)
	struct FString NiceName;  // 0x58(0x10)
	struct TArray<struct FNamedId> Destinations;  // 0x68(0x10)
	struct TArray<struct FNamedId> Sources;  // 0x78(0x10)

}; 
// ScriptStruct DirectLink.DirectLinkMsg_EndpointLifecycle
// Size: 0x8(Inherited: 0x0) 
struct FDirectLinkMsg_EndpointLifecycle
{
	char LifecycleState;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	uint32_t EndpointStateRevision;  // 0x4(0x4)

}; 
