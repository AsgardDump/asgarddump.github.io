#include "SDK.h" 
 
 
struct UAudioCapture* UBlueprintFunctionLibrary::CreateAudioCapture(){

	static UObject* p_CreateAudioCapture = UObject::FindObject<UFunction>("Function AudioCapture.AudioCaptureFunctionLibrary.CreateAudioCapture");

	struct {
		struct UAudioCapture* return_value;
	} parms;


	ProcessEvent(p_CreateAudioCapture, &parms);
	return parms.return_value;
}

void UAudioGenerator::StopCapturingAudio(){

	static UObject* p_StopCapturingAudio = UObject::FindObject<UFunction>("Function AudioCapture.AudioCapture.StopCapturingAudio");

	struct {
	} parms;


	ProcessEvent(p_StopCapturingAudio, &parms);
}

void UAudioGenerator::StartCapturingAudio(){

	static UObject* p_StartCapturingAudio = UObject::FindObject<UFunction>("Function AudioCapture.AudioCapture.StartCapturingAudio");

	struct {
	} parms;


	ProcessEvent(p_StartCapturingAudio, &parms);
}

bool UAudioGenerator::IsCapturingAudio(){

	static UObject* p_IsCapturingAudio = UObject::FindObject<UFunction>("Function AudioCapture.AudioCapture.IsCapturingAudio");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_IsCapturingAudio, &parms);
	return parms.return_value;
}

bool UAudioGenerator::GetAudioCaptureDeviceInfo(struct FAudioCaptureDeviceInfo& OutInfo){

	static UObject* p_GetAudioCaptureDeviceInfo = UObject::FindObject<UFunction>("Function AudioCapture.AudioCapture.GetAudioCaptureDeviceInfo");

	struct {
		struct FAudioCaptureDeviceInfo& OutInfo;
		bool return_value;
	} parms;

	parms.OutInfo = OutInfo;

	ProcessEvent(p_GetAudioCaptureDeviceInfo, &parms);
	return parms.return_value;
}

