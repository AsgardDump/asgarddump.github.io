#pragma once 
#include <HK416Reload_StartCS1_Structs.h>
 
 
 
// BlueprintGeneratedClass HK416Reload_StartCS1.HK416Reload_StartCS1_C
// Size: 0x1B0(Inherited: 0x1B0) 
struct UHK416Reload_StartCS1_C : public UMatineeCameraShake
{

}; 



