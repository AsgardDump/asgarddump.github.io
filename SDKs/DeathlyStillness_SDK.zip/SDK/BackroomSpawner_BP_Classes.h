#pragma once 
#include <BackroomSpawner_BP_Structs.h>
 
 
 
// BlueprintGeneratedClass BackroomSpawner_BP.BackroomSpawner_BP_C
// Size: 0x264(Inherited: 0x220) 
struct ABackroomSpawner_BP_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x228(0x8)
	int32_t ;  // 0x230(0x4)
	char pad_564[4];  // 0x234(0x4)
	struct TArray<struct AActor*> NewVar_1;  // 0x238(0x10)
	int32_t Index;  // 0x248(0x4)
	char pad_588[4];  // 0x24C(0x4)
	struct AActor* Get;  // 0x250(0x8)
	AActor* SpawnClass;  // 0x258(0x8)
	float Radius;  // 0x260(0x4)

	void ReceiveBeginPlay(); // Function BackroomSpawner_BP.BackroomSpawner_BP_C.ReceiveBeginPlay
	void (); // Function BackroomSpawner_BP.BackroomSpawner_BP_C.
	void ExecuteUbergraph_BackroomSpawner_BP(int32_t EntryPoint); // Function BackroomSpawner_BP.BackroomSpawner_BP_C.ExecuteUbergraph_BackroomSpawner_BP
}; 



