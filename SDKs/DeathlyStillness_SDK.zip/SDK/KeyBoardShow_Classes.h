#pragma once 
#include <KeyBoardShow_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass KeyBoardShow.KeyBoardShow_C
// Size: 0x290(Inherited: 0x260) 
struct UKeyBoardShow_C : public UUserWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x260(0x8)
	struct UWidgetAnimation* 1;  // 0x268(0x8)
	struct UKeyboardLayout_C* KeyboardLayout;  // 0x270(0x8)
	struct UTextBlock* TextBlock_93;  // 0x278(0x8)
	struct U* ;  // 0x280(0x8)
	struct APlayer_BP_C* PlayerRef;  // 0x288(0x8)

	void Construct(); // Function KeyBoardShow.KeyBoardShow_C.Construct
	void StartGame(); // Function KeyBoardShow.KeyBoardShow_C.StartGame
	void ExecuteUbergraph_KeyBoardShow(int32_t EntryPoint); // Function KeyBoardShow.KeyBoardShow_C.ExecuteUbergraph_KeyBoardShow
}; 



