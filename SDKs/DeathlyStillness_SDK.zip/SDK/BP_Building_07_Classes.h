#pragma once 
#include <BP_Building_07_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Building_07.BP_Building_07_C
// Size: 0x298(Inherited: 0x220) 
struct ABP_Building_07_C : public AActor
{
	struct UStaticMeshComponent* SM_Awning3;  // 0x220(0x8)
	struct UChildActorComponent* ChildActor2;  // 0x228(0x8)
	struct UChildActorComponent* ChildActor1;  // 0x230(0x8)
	struct UChildActorComponent* ChildActor;  // 0x238(0x8)
	struct UChildActorComponent* BP_ClothesRack;  // 0x240(0x8)
	struct UStaticMeshComponent* StaticMesh3;  // 0x248(0x8)
	struct UStaticMeshComponent* StaticMesh2;  // 0x250(0x8)
	struct UStaticMeshComponent* StaticMesh1;  // 0x258(0x8)
	struct UStaticMeshComponent* StaticMesh;  // 0x260(0x8)
	struct UStaticMeshComponent* SM_CurtainSmall;  // 0x268(0x8)
	struct UStaticMeshComponent* SM_Building_07_Door;  // 0x270(0x8)
	struct UStaticMeshComponent* SM_Building_07_Window;  // 0x278(0x8)
	struct UStaticMeshComponent* SM_Building_07_Columns;  // 0x280(0x8)
	struct UStaticMeshComponent* SM_Building_07;  // 0x288(0x8)
	struct USceneComponent* Scene;  // 0x290(0x8)

}; 



