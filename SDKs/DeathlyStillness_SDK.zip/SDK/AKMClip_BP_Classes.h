#pragma once 
#include <AKMClip_BP_Structs.h>
 
 
 
// BlueprintGeneratedClass AKMClip_BP.AKMClip_BP_C
// Size: 0x238(Inherited: 0x238) 
struct AAKMClip_BP_C : public AClip_Master_C
{

}; 



