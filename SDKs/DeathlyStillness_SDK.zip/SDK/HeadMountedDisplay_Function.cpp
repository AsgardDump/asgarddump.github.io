#include "SDK.h" 
 
 
void UBlueprintFunctionLibrary::ShowLoadingScreen(){

	static UObject* p_ShowLoadingScreen = UObject::FindObject<UFunction>("Function HeadMountedDisplay.XRLoadingScreenFunctionLibrary.ShowLoadingScreen");

	struct {
	} parms;


	ProcessEvent(p_ShowLoadingScreen, &parms);
}

void UBlueprintFunctionLibrary::SetLoadingScreen(struct UTexture* Texture, struct FVector2D Scale, struct FVector Offset, bool bShowLoadingMovie, bool bShowOnSet){

	static UObject* p_SetLoadingScreen = UObject::FindObject<UFunction>("Function HeadMountedDisplay.XRLoadingScreenFunctionLibrary.SetLoadingScreen");

	struct {
		struct UTexture* Texture;
		struct FVector2D Scale;
		struct FVector Offset;
		bool bShowLoadingMovie;
		bool bShowOnSet;
	} parms;

	parms.Texture = Texture;
	parms.Scale = Scale;
	parms.Offset = Offset;
	parms.bShowLoadingMovie = bShowLoadingMovie;
	parms.bShowOnSet = bShowOnSet;

	ProcessEvent(p_SetLoadingScreen, &parms);
}

void UBlueprintFunctionLibrary::HideLoadingScreen(){

	static UObject* p_HideLoadingScreen = UObject::FindObject<UFunction>("Function HeadMountedDisplay.XRLoadingScreenFunctionLibrary.HideLoadingScreen");

	struct {
	} parms;


	ProcessEvent(p_HideLoadingScreen, &parms);
}

void UBlueprintFunctionLibrary::ClearLoadingScreenSplashes(){

	static UObject* p_ClearLoadingScreenSplashes = UObject::FindObject<UFunction>("Function HeadMountedDisplay.XRLoadingScreenFunctionLibrary.ClearLoadingScreenSplashes");

	struct {
	} parms;


	ProcessEvent(p_ClearLoadingScreenSplashes, &parms);
}

void UBlueprintFunctionLibrary::AddLoadingScreenSplash(struct UTexture* Texture, struct FVector Translation, struct FRotator Rotation, struct FVector2D Size, struct FRotator DeltaRotation, bool bClearBeforeAdd){

	static UObject* p_AddLoadingScreenSplash = UObject::FindObject<UFunction>("Function HeadMountedDisplay.XRLoadingScreenFunctionLibrary.AddLoadingScreenSplash");

	struct {
		struct UTexture* Texture;
		struct FVector Translation;
		struct FRotator Rotation;
		struct FVector2D Size;
		struct FRotator DeltaRotation;
		bool bClearBeforeAdd;
	} parms;

	parms.Texture = Texture;
	parms.Translation = Translation;
	parms.Rotation = Rotation;
	parms.Size = Size;
	parms.DeltaRotation = DeltaRotation;
	parms.bClearBeforeAdd = bClearBeforeAdd;

	ProcessEvent(p_AddLoadingScreenSplash, &parms);
}

void UBlueprintFunctionLibrary::UpdateExternalTrackingHMDPosition(struct FTransform& ExternalTrackingTransform){

	static UObject* p_UpdateExternalTrackingHMDPosition = UObject::FindObject<UFunction>("Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.UpdateExternalTrackingHMDPosition");

	struct {
		struct FTransform& ExternalTrackingTransform;
	} parms;

	parms.ExternalTrackingTransform = ExternalTrackingTransform;

	ProcessEvent(p_UpdateExternalTrackingHMDPosition, &parms);
}

void UBlueprintFunctionLibrary::SetXRTimedInputActionDelegate(struct FName& ActionName, struct FDelegate& InDelegate){

	static UObject* p_SetXRTimedInputActionDelegate = UObject::FindObject<UFunction>("Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.SetXRTimedInputActionDelegate");

	struct {
		struct FName& ActionName;
		struct FDelegate& InDelegate;
	} parms;

	parms.ActionName = ActionName;
	parms.InDelegate = InDelegate;

	ProcessEvent(p_SetXRTimedInputActionDelegate, &parms);
}

void UBlueprintFunctionLibrary::SetXRDisconnectDelegate(struct FDelegate& InDisconnectedDelegate){

	static UObject* p_SetXRDisconnectDelegate = UObject::FindObject<UFunction>("Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.SetXRDisconnectDelegate");

	struct {
		struct FDelegate& InDisconnectedDelegate;
	} parms;

	parms.InDisconnectedDelegate = InDisconnectedDelegate;

	ProcessEvent(p_SetXRDisconnectDelegate, &parms);
}

void UBlueprintFunctionLibrary::SetWorldToMetersScale(struct UObject* WorldContext, float NewScale){

	static UObject* p_SetWorldToMetersScale = UObject::FindObject<UFunction>("Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.SetWorldToMetersScale");

	struct {
		struct UObject* WorldContext;
		float NewScale;
	} parms;

	parms.WorldContext = WorldContext;
	parms.NewScale = NewScale;

	ProcessEvent(p_SetWorldToMetersScale, &parms);
}

void UBlueprintFunctionLibrary::SetTrackingOrigin(char EHMDTrackingOrigin Origin){

	static UObject* p_SetTrackingOrigin = UObject::FindObject<UFunction>("Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.SetTrackingOrigin");

	struct {
		char EHMDTrackingOrigin Origin;
	} parms;

	parms.Origin = Origin;

	ProcessEvent(p_SetTrackingOrigin, &parms);
}

void UBlueprintFunctionLibrary::SetSpectatorScreenTexture(struct UTexture* InTexture){

	static UObject* p_SetSpectatorScreenTexture = UObject::FindObject<UFunction>("Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.SetSpectatorScreenTexture");

	struct {
		struct UTexture* InTexture;
	} parms;

	parms.InTexture = InTexture;

	ProcessEvent(p_SetSpectatorScreenTexture, &parms);
}

void UBlueprintFunctionLibrary::SetSpectatorScreenModeTexturePlusEyeLayout(struct FVector2D EyeRectMin, struct FVector2D EyeRectMax, struct FVector2D TextureRectMin, struct FVector2D TextureRectMax, bool bDrawEyeFirst, bool bClearBlack, bool bUseAlpha){

	static UObject* p_SetSpectatorScreenModeTexturePlusEyeLayout = UObject::FindObject<UFunction>("Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.SetSpectatorScreenModeTexturePlusEyeLayout");

	struct {
		struct FVector2D EyeRectMin;
		struct FVector2D EyeRectMax;
		struct FVector2D TextureRectMin;
		struct FVector2D TextureRectMax;
		bool bDrawEyeFirst;
		bool bClearBlack;
		bool bUseAlpha;
	} parms;

	parms.EyeRectMin = EyeRectMin;
	parms.EyeRectMax = EyeRectMax;
	parms.TextureRectMin = TextureRectMin;
	parms.TextureRectMax = TextureRectMax;
	parms.bDrawEyeFirst = bDrawEyeFirst;
	parms.bClearBlack = bClearBlack;
	parms.bUseAlpha = bUseAlpha;

	ProcessEvent(p_SetSpectatorScreenModeTexturePlusEyeLayout, &parms);
}

void UBlueprintFunctionLibrary::SetSpectatorScreenMode(uint8_t  Mode){

	static UObject* p_SetSpectatorScreenMode = UObject::FindObject<UFunction>("Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.SetSpectatorScreenMode");

	struct {
		uint8_t  Mode;
	} parms;

	parms.Mode = Mode;

	ProcessEvent(p_SetSpectatorScreenMode, &parms);
}

void UBlueprintFunctionLibrary::SetClippingPlanes(float Near, float Far){

	static UObject* p_SetClippingPlanes = UObject::FindObject<UFunction>("Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.SetClippingPlanes");

	struct {
		float Near;
		float Far;
	} parms;

	parms.Near = Near;
	parms.Far = Far;

	ProcessEvent(p_SetClippingPlanes, &parms);
}

void UBlueprintFunctionLibrary::ResetOrientationAndPosition(float Yaw, char EOrientPositionSelector Options){

	static UObject* p_ResetOrientationAndPosition = UObject::FindObject<UFunction>("Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.ResetOrientationAndPosition");

	struct {
		float Yaw;
		char EOrientPositionSelector Options;
	} parms;

	parms.Yaw = Yaw;
	parms.Options = Options;

	ProcessEvent(p_ResetOrientationAndPosition, &parms);
}

bool UBlueprintFunctionLibrary::IsSpectatorScreenModeControllable(){

	static UObject* p_IsSpectatorScreenModeControllable = UObject::FindObject<UFunction>("Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.IsSpectatorScreenModeControllable");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_IsSpectatorScreenModeControllable, &parms);
	return parms.return_value;
}

bool UBlueprintFunctionLibrary::IsInLowPersistenceMode(){

	static UObject* p_IsInLowPersistenceMode = UObject::FindObject<UFunction>("Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.IsInLowPersistenceMode");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_IsInLowPersistenceMode, &parms);
	return parms.return_value;
}

bool UBlueprintFunctionLibrary::IsHeadMountedDisplayEnabled(){

	static UObject* p_IsHeadMountedDisplayEnabled = UObject::FindObject<UFunction>("Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.IsHeadMountedDisplayEnabled");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_IsHeadMountedDisplayEnabled, &parms);
	return parms.return_value;
}

bool UBlueprintFunctionLibrary::IsHeadMountedDisplayConnected(){

	static UObject* p_IsHeadMountedDisplayConnected = UObject::FindObject<UFunction>("Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.IsHeadMountedDisplayConnected");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_IsHeadMountedDisplayConnected, &parms);
	return parms.return_value;
}

bool UBlueprintFunctionLibrary::IsDeviceTracking(struct FXRDeviceId& XRDeviceId){

	static UObject* p_IsDeviceTracking = UObject::FindObject<UFunction>("Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.IsDeviceTracking");

	struct {
		struct FXRDeviceId& XRDeviceId;
		bool return_value;
	} parms;

	parms.XRDeviceId = XRDeviceId;

	ProcessEvent(p_IsDeviceTracking, &parms);
	return parms.return_value;
}

bool UBlueprintFunctionLibrary::HasValidTrackingPosition(){

	static UObject* p_HasValidTrackingPosition = UObject::FindObject<UFunction>("Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.HasValidTrackingPosition");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_HasValidTrackingPosition, &parms);
	return parms.return_value;
}

int32_t UBlueprintFunctionLibrary::GetXRSystemFlags(){

	static UObject* p_GetXRSystemFlags = UObject::FindObject<UFunction>("Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.GetXRSystemFlags");

	struct {
		int32_t return_value;
	} parms;


	ProcessEvent(p_GetXRSystemFlags, &parms);
	return parms.return_value;
}

float UBlueprintFunctionLibrary::GetWorldToMetersScale(struct UObject* WorldContext){

	static UObject* p_GetWorldToMetersScale = UObject::FindObject<UFunction>("Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.GetWorldToMetersScale");

	struct {
		struct UObject* WorldContext;
		float return_value;
	} parms;

	parms.WorldContext = WorldContext;

	ProcessEvent(p_GetWorldToMetersScale, &parms);
	return parms.return_value;
}

void UBlueprintFunctionLibrary::GetVRFocusState(bool& bUseFocus, bool& bHasFocus){

	static UObject* p_GetVRFocusState = UObject::FindObject<UFunction>("Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.GetVRFocusState");

	struct {
		bool& bUseFocus;
		bool& bHasFocus;
	} parms;

	parms.bUseFocus = bUseFocus;
	parms.bHasFocus = bHasFocus;

	ProcessEvent(p_GetVRFocusState, &parms);
}

struct FString UBlueprintFunctionLibrary::GetVersionString(){

	static UObject* p_GetVersionString = UObject::FindObject<UFunction>("Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.GetVersionString");

	struct {
		struct FString return_value;
	} parms;


	ProcessEvent(p_GetVersionString, &parms);
	return parms.return_value;
}

struct FTransform UBlueprintFunctionLibrary::GetTrackingToWorldTransform(struct UObject* WorldContext){

	static UObject* p_GetTrackingToWorldTransform = UObject::FindObject<UFunction>("Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.GetTrackingToWorldTransform");

	struct {
		struct UObject* WorldContext;
		struct FTransform return_value;
	} parms;

	parms.WorldContext = WorldContext;

	ProcessEvent(p_GetTrackingToWorldTransform, &parms);
	return parms.return_value;
}

void UBlueprintFunctionLibrary::GetTrackingSensorParameters(struct FVector& Origin, struct FRotator& Rotation, float& LeftFOV, float& RightFOV, float& TopFOV, float& BottomFOV, float& Distance, float& NearPlane, float& FarPlane, bool& IsActive, int32_t Index){

	static UObject* p_GetTrackingSensorParameters = UObject::FindObject<UFunction>("Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.GetTrackingSensorParameters");

	struct {
		struct FVector& Origin;
		struct FRotator& Rotation;
		float& LeftFOV;
		float& RightFOV;
		float& TopFOV;
		float& BottomFOV;
		float& Distance;
		float& NearPlane;
		float& FarPlane;
		bool& IsActive;
		int32_t Index;
	} parms;

	parms.Origin = Origin;
	parms.Rotation = Rotation;
	parms.LeftFOV = LeftFOV;
	parms.RightFOV = RightFOV;
	parms.TopFOV = TopFOV;
	parms.BottomFOV = BottomFOV;
	parms.Distance = Distance;
	parms.NearPlane = NearPlane;
	parms.FarPlane = FarPlane;
	parms.IsActive = IsActive;
	parms.Index = Index;

	ProcessEvent(p_GetTrackingSensorParameters, &parms);
}

char EHMDTrackingOrigin UBlueprintFunctionLibrary::GetTrackingOrigin(){

	static UObject* p_GetTrackingOrigin = UObject::FindObject<UFunction>("Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.GetTrackingOrigin");

	struct {
		char EHMDTrackingOrigin return_value;
	} parms;


	ProcessEvent(p_GetTrackingOrigin, &parms);
	return parms.return_value;
}

float UBlueprintFunctionLibrary::GetScreenPercentage(){

	static UObject* p_GetScreenPercentage = UObject::FindObject<UFunction>("Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.GetScreenPercentage");

	struct {
		float return_value;
	} parms;


	ProcessEvent(p_GetScreenPercentage, &parms);
	return parms.return_value;
}

void UBlueprintFunctionLibrary::GetPositionalTrackingCameraParameters(struct FVector& CameraOrigin, struct FRotator& CameraRotation, float& HFOV, float& VFOV, float& CameraDistance, float& NearPlane, float& FarPlane){

	static UObject* p_GetPositionalTrackingCameraParameters = UObject::FindObject<UFunction>("Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.GetPositionalTrackingCameraParameters");

	struct {
		struct FVector& CameraOrigin;
		struct FRotator& CameraRotation;
		float& HFOV;
		float& VFOV;
		float& CameraDistance;
		float& NearPlane;
		float& FarPlane;
	} parms;

	parms.CameraOrigin = CameraOrigin;
	parms.CameraRotation = CameraRotation;
	parms.HFOV = HFOV;
	parms.VFOV = VFOV;
	parms.CameraDistance = CameraDistance;
	parms.NearPlane = NearPlane;
	parms.FarPlane = FarPlane;

	ProcessEvent(p_GetPositionalTrackingCameraParameters, &parms);
}

struct FVector2D UBlueprintFunctionLibrary::GetPlayAreaBounds(char EHMDTrackingOrigin Origin){

	static UObject* p_GetPlayAreaBounds = UObject::FindObject<UFunction>("Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.GetPlayAreaBounds");

	struct {
		char EHMDTrackingOrigin Origin;
		struct FVector2D return_value;
	} parms;

	parms.Origin = Origin;

	ProcessEvent(p_GetPlayAreaBounds, &parms);
	return parms.return_value;
}

float UBlueprintFunctionLibrary::GetPixelDensity(){

	static UObject* p_GetPixelDensity = UObject::FindObject<UFunction>("Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.GetPixelDensity");

	struct {
		float return_value;
	} parms;


	ProcessEvent(p_GetPixelDensity, &parms);
	return parms.return_value;
}

void UBlueprintFunctionLibrary::GetOrientationAndPosition(struct FRotator& DeviceRotation, struct FVector& DevicePosition){

	static UObject* p_GetOrientationAndPosition = UObject::FindObject<UFunction>("Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.GetOrientationAndPosition");

	struct {
		struct FRotator& DeviceRotation;
		struct FVector& DevicePosition;
	} parms;

	parms.DeviceRotation = DeviceRotation;
	parms.DevicePosition = DevicePosition;

	ProcessEvent(p_GetOrientationAndPosition, &parms);
}

int32_t UBlueprintFunctionLibrary::GetNumOfTrackingSensors(){

	static UObject* p_GetNumOfTrackingSensors = UObject::FindObject<UFunction>("Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.GetNumOfTrackingSensors");

	struct {
		int32_t return_value;
	} parms;


	ProcessEvent(p_GetNumOfTrackingSensors, &parms);
	return parms.return_value;
}

void UBlueprintFunctionLibrary::GetMotionControllerData(struct UObject* WorldContext, uint8_t  Hand, struct FXRMotionControllerData& MotionControllerData){

	static UObject* p_GetMotionControllerData = UObject::FindObject<UFunction>("Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.GetMotionControllerData");

	struct {
		struct UObject* WorldContext;
		uint8_t  Hand;
		struct FXRMotionControllerData& MotionControllerData;
	} parms;

	parms.WorldContext = WorldContext;
	parms.Hand = Hand;
	parms.MotionControllerData = MotionControllerData;

	ProcessEvent(p_GetMotionControllerData, &parms);
}

char EHMDWornState UBlueprintFunctionLibrary::GetHMDWornState(){

	static UObject* p_GetHMDWornState = UObject::FindObject<UFunction>("Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.GetHMDWornState");

	struct {
		char EHMDWornState return_value;
	} parms;


	ProcessEvent(p_GetHMDWornState, &parms);
	return parms.return_value;
}

struct FName UBlueprintFunctionLibrary::GetHMDDeviceName(){

	static UObject* p_GetHMDDeviceName = UObject::FindObject<UFunction>("Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.GetHMDDeviceName");

	struct {
		struct FName return_value;
	} parms;


	ProcessEvent(p_GetHMDDeviceName, &parms);
	return parms.return_value;
}

void UBlueprintFunctionLibrary::GetHMDData(struct UObject* WorldContext, struct FXRHMDData& HMDData){

	static UObject* p_GetHMDData = UObject::FindObject<UFunction>("Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.GetHMDData");

	struct {
		struct UObject* WorldContext;
		struct FXRHMDData& HMDData;
	} parms;

	parms.WorldContext = WorldContext;
	parms.HMDData = HMDData;

	ProcessEvent(p_GetHMDData, &parms);
}

void UBlueprintFunctionLibrary::GetDeviceWorldPose(struct UObject* WorldContext, struct FXRDeviceId& XRDeviceId, bool& bIsTracked, struct FRotator& Orientation, bool& bHasPositionalTracking, struct FVector& Position){

	static UObject* p_GetDeviceWorldPose = UObject::FindObject<UFunction>("Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.GetDeviceWorldPose");

	struct {
		struct UObject* WorldContext;
		struct FXRDeviceId& XRDeviceId;
		bool& bIsTracked;
		struct FRotator& Orientation;
		bool& bHasPositionalTracking;
		struct FVector& Position;
	} parms;

	parms.WorldContext = WorldContext;
	parms.XRDeviceId = XRDeviceId;
	parms.bIsTracked = bIsTracked;
	parms.Orientation = Orientation;
	parms.bHasPositionalTracking = bHasPositionalTracking;
	parms.Position = Position;

	ProcessEvent(p_GetDeviceWorldPose, &parms);
}

void UBlueprintFunctionLibrary::GetDevicePose(struct FXRDeviceId& XRDeviceId, bool& bIsTracked, struct FRotator& Orientation, bool& bHasPositionalTracking, struct FVector& Position){

	static UObject* p_GetDevicePose = UObject::FindObject<UFunction>("Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.GetDevicePose");

	struct {
		struct FXRDeviceId& XRDeviceId;
		bool& bIsTracked;
		struct FRotator& Orientation;
		bool& bHasPositionalTracking;
		struct FVector& Position;
	} parms;

	parms.XRDeviceId = XRDeviceId;
	parms.bIsTracked = bIsTracked;
	parms.Orientation = Orientation;
	parms.bHasPositionalTracking = bHasPositionalTracking;
	parms.Position = Position;

	ProcessEvent(p_GetDevicePose, &parms);
}

bool UBlueprintFunctionLibrary::GetControllerTransformForTime(struct UObject* WorldContext, int32_t ControllerIndex, struct FName MotionSource, struct FTimespan Time, bool& bTimeWasUsed, struct FRotator& Orientation, struct FVector& Position, bool& bProvidedLinearVelocity, struct FVector& LinearVelocity, bool& bProvidedAngularVelocity, struct FVector& AngularVelocityRadPerSec){

	static UObject* p_GetControllerTransformForTime = UObject::FindObject<UFunction>("Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.GetControllerTransformForTime");

	struct {
		struct UObject* WorldContext;
		int32_t ControllerIndex;
		struct FName MotionSource;
		struct FTimespan Time;
		bool& bTimeWasUsed;
		struct FRotator& Orientation;
		struct FVector& Position;
		bool& bProvidedLinearVelocity;
		struct FVector& LinearVelocity;
		bool& bProvidedAngularVelocity;
		struct FVector& AngularVelocityRadPerSec;
		bool return_value;
	} parms;

	parms.WorldContext = WorldContext;
	parms.ControllerIndex = ControllerIndex;
	parms.MotionSource = MotionSource;
	parms.Time = Time;
	parms.bTimeWasUsed = bTimeWasUsed;
	parms.Orientation = Orientation;
	parms.Position = Position;
	parms.bProvidedLinearVelocity = bProvidedLinearVelocity;
	parms.LinearVelocity = LinearVelocity;
	parms.bProvidedAngularVelocity = bProvidedAngularVelocity;
	parms.AngularVelocityRadPerSec = AngularVelocityRadPerSec;

	ProcessEvent(p_GetControllerTransformForTime, &parms);
	return parms.return_value;
}

struct TArray<struct FXRDeviceId> UBlueprintFunctionLibrary::EnumerateTrackedDevices(struct FName SystemId, uint8_t  DeviceType){

	static UObject* p_EnumerateTrackedDevices = UObject::FindObject<UFunction>("Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.EnumerateTrackedDevices");

	struct {
		struct FName SystemId;
		uint8_t  DeviceType;
		struct TArray<struct FXRDeviceId> return_value;
	} parms;

	parms.SystemId = SystemId;
	parms.DeviceType = DeviceType;

	ProcessEvent(p_EnumerateTrackedDevices, &parms);
	return parms.return_value;
}

void UBlueprintFunctionLibrary::EnableLowPersistenceMode(bool bEnable){

	static UObject* p_EnableLowPersistenceMode = UObject::FindObject<UFunction>("Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.EnableLowPersistenceMode");

	struct {
		bool bEnable;
	} parms;

	parms.bEnable = bEnable;

	ProcessEvent(p_EnableLowPersistenceMode, &parms);
}

bool UBlueprintFunctionLibrary::EnableHMD(bool bEnable){

	static UObject* p_EnableHMD = UObject::FindObject<UFunction>("Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.EnableHMD");

	struct {
		bool bEnable;
		bool return_value;
	} parms;

	parms.bEnable = bEnable;

	ProcessEvent(p_EnableHMD, &parms);
	return parms.return_value;
}

void UBlueprintFunctionLibrary::DisconnectRemoteXRDevice(){

	static UObject* p_DisconnectRemoteXRDevice = UObject::FindObject<UFunction>("Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.DisconnectRemoteXRDevice");

	struct {
	} parms;


	ProcessEvent(p_DisconnectRemoteXRDevice, &parms);
}

char EXRDeviceConnectionResult UBlueprintFunctionLibrary::ConnectRemoteXRDevice(struct FString IpAddress, int32_t BitRate){

	static UObject* p_ConnectRemoteXRDevice = UObject::FindObject<UFunction>("Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.ConnectRemoteXRDevice");

	struct {
		struct FString IpAddress;
		int32_t BitRate;
		char EXRDeviceConnectionResult return_value;
	} parms;

	parms.IpAddress = IpAddress;
	parms.BitRate = BitRate;

	ProcessEvent(p_ConnectRemoteXRDevice, &parms);
	return parms.return_value;
}

bool UBlueprintFunctionLibrary::ConfigureGestures(struct FXRGestureConfig& GestureConfig){

	static UObject* p_ConfigureGestures = UObject::FindObject<UFunction>("Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.ConfigureGestures");

	struct {
		struct FXRGestureConfig& GestureConfig;
		bool return_value;
	} parms;

	parms.GestureConfig = GestureConfig;

	ProcessEvent(p_ConfigureGestures, &parms);
	return parms.return_value;
}

void UBlueprintFunctionLibrary::ClearXRTimedInputActionDelegate(struct FName& ActionPath){

	static UObject* p_ClearXRTimedInputActionDelegate = UObject::FindObject<UFunction>("Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.ClearXRTimedInputActionDelegate");

	struct {
		struct FName& ActionPath;
	} parms;

	parms.ActionPath = ActionPath;

	ProcessEvent(p_ClearXRTimedInputActionDelegate, &parms);
}

void UBlueprintFunctionLibrary::CalibrateExternalTrackingToHMD(struct FTransform& ExternalTrackingTransform){

	static UObject* p_CalibrateExternalTrackingToHMD = UObject::FindObject<UFunction>("Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.CalibrateExternalTrackingToHMD");

	struct {
		struct FTransform& ExternalTrackingTransform;
	} parms;

	parms.ExternalTrackingTransform = ExternalTrackingTransform;

	ProcessEvent(p_CalibrateExternalTrackingToHMD, &parms);
}

void UBlueprintFunctionLibrary::BreakKey(struct FKey InKey, struct FString& InteractionProfile, uint8_t & Hand, struct FName& MotionSource, struct FString& Indentifier, struct FString& Component){

	static UObject* p_BreakKey = UObject::FindObject<UFunction>("Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.BreakKey");

	struct {
		struct FKey InKey;
		struct FString& InteractionProfile;
		uint8_t & Hand;
		struct FName& MotionSource;
		struct FString& Indentifier;
		struct FString& Component;
	} parms;

	parms.InKey = InKey;
	parms.InteractionProfile = InteractionProfile;
	parms.Hand = Hand;
	parms.MotionSource = MotionSource;
	parms.Indentifier = Indentifier;
	parms.Component = Component;

	ProcessEvent(p_BreakKey, &parms);
}

int32_t UBlueprintFunctionLibrary::Conv_HandKeypointToInt32(uint8_t  Input){

	static UObject* p_Conv_HandKeypointToInt32 = UObject::FindObject<UFunction>("Function HeadMountedDisplay.HandKeypointConversion.Conv_HandKeypointToInt32");

	struct {
		uint8_t  Input;
		int32_t return_value;
	} parms;

	parms.Input = Input;

	ProcessEvent(p_Conv_HandKeypointToInt32, &parms);
	return parms.return_value;
}

struct UAsyncTask_LoadXRDeviceVisComponent* UBlueprintAsyncActionBase::AddNamedDeviceVisualizationComponentAsync(struct AActor* Target, struct FName SystemName, struct FName DeviceName, bool bManualAttachment, struct FTransform& RelativeTransform, struct FXRDeviceId& XRDeviceId, struct UPrimitiveComponent*& NewComponent){

	static UObject* p_AddNamedDeviceVisualizationComponentAsync = UObject::FindObject<UFunction>("Function HeadMountedDisplay.AsyncTask_LoadXRDeviceVisComponent.AddNamedDeviceVisualizationComponentAsync");

	struct {
		struct AActor* Target;
		struct FName SystemName;
		struct FName DeviceName;
		bool bManualAttachment;
		struct FTransform& RelativeTransform;
		struct FXRDeviceId& XRDeviceId;
		struct UPrimitiveComponent*& NewComponent;
		struct UAsyncTask_LoadXRDeviceVisComponent* return_value;
	} parms;

	parms.Target = Target;
	parms.SystemName = SystemName;
	parms.DeviceName = DeviceName;
	parms.bManualAttachment = bManualAttachment;
	parms.RelativeTransform = RelativeTransform;
	parms.XRDeviceId = XRDeviceId;
	parms.NewComponent = NewComponent;

	ProcessEvent(p_AddNamedDeviceVisualizationComponentAsync, &parms);
	return parms.return_value;
}

struct UAsyncTask_LoadXRDeviceVisComponent* UBlueprintAsyncActionBase::AddDeviceVisualizationComponentAsync(struct AActor* Target, struct FXRDeviceId& XRDeviceId, bool bManualAttachment, struct FTransform& RelativeTransform, struct UPrimitiveComponent*& NewComponent){

	static UObject* p_AddDeviceVisualizationComponentAsync = UObject::FindObject<UFunction>("Function HeadMountedDisplay.AsyncTask_LoadXRDeviceVisComponent.AddDeviceVisualizationComponentAsync");

	struct {
		struct AActor* Target;
		struct FXRDeviceId& XRDeviceId;
		bool bManualAttachment;
		struct FTransform& RelativeTransform;
		struct UPrimitiveComponent*& NewComponent;
		struct UAsyncTask_LoadXRDeviceVisComponent* return_value;
	} parms;

	parms.Target = Target;
	parms.XRDeviceId = XRDeviceId;
	parms.bManualAttachment = bManualAttachment;
	parms.RelativeTransform = RelativeTransform;
	parms.NewComponent = NewComponent;

	ProcessEvent(p_AddDeviceVisualizationComponentAsync, &parms);
	return parms.return_value;
}

void UPrimitiveComponent::SetTrackingSource(uint8_t  NewSource){

	static UObject* p_SetTrackingSource = UObject::FindObject<UFunction>("Function HeadMountedDisplay.MotionControllerComponent.SetTrackingSource");

	struct {
		uint8_t  NewSource;
	} parms;

	parms.NewSource = NewSource;

	ProcessEvent(p_SetTrackingSource, &parms);
}

void UPrimitiveComponent::SetTrackingMotionSource(struct FName NewSource){

	static UObject* p_SetTrackingMotionSource = UObject::FindObject<UFunction>("Function HeadMountedDisplay.MotionControllerComponent.SetTrackingMotionSource");

	struct {
		struct FName NewSource;
	} parms;

	parms.NewSource = NewSource;

	ProcessEvent(p_SetTrackingMotionSource, &parms);
}

void UPrimitiveComponent::SetShowDeviceModel(bool bShowControllerModel){

	static UObject* p_SetShowDeviceModel = UObject::FindObject<UFunction>("Function HeadMountedDisplay.MotionControllerComponent.SetShowDeviceModel");

	struct {
		bool bShowControllerModel;
	} parms;

	parms.bShowControllerModel = bShowControllerModel;

	ProcessEvent(p_SetShowDeviceModel, &parms);
}

void UPrimitiveComponent::SetDisplayModelSource(struct FName NewDisplayModelSource){

	static UObject* p_SetDisplayModelSource = UObject::FindObject<UFunction>("Function HeadMountedDisplay.MotionControllerComponent.SetDisplayModelSource");

	struct {
		struct FName NewDisplayModelSource;
	} parms;

	parms.NewDisplayModelSource = NewDisplayModelSource;

	ProcessEvent(p_SetDisplayModelSource, &parms);
}

void UPrimitiveComponent::SetCustomDisplayMesh(struct UStaticMesh* NewDisplayMesh){

	static UObject* p_SetCustomDisplayMesh = UObject::FindObject<UFunction>("Function HeadMountedDisplay.MotionControllerComponent.SetCustomDisplayMesh");

	struct {
		struct UStaticMesh* NewDisplayMesh;
	} parms;

	parms.NewDisplayMesh = NewDisplayMesh;

	ProcessEvent(p_SetCustomDisplayMesh, &parms);
}

void UPrimitiveComponent::SetAssociatedPlayerIndex(int32_t NewPlayer){

	static UObject* p_SetAssociatedPlayerIndex = UObject::FindObject<UFunction>("Function HeadMountedDisplay.MotionControllerComponent.SetAssociatedPlayerIndex");

	struct {
		int32_t NewPlayer;
	} parms;

	parms.NewPlayer = NewPlayer;

	ProcessEvent(p_SetAssociatedPlayerIndex, &parms);
}

void UPrimitiveComponent::OnMotionControllerUpdated(){

	static UObject* p_OnMotionControllerUpdated = UObject::FindObject<UFunction>("Function HeadMountedDisplay.MotionControllerComponent.OnMotionControllerUpdated");

	struct {
	} parms;


	ProcessEvent(p_OnMotionControllerUpdated, &parms);
}

bool UPrimitiveComponent::IsTracked(){

	static UObject* p_IsTracked = UObject::FindObject<UFunction>("Function HeadMountedDisplay.MotionControllerComponent.IsTracked");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_IsTracked, &parms);
	return parms.return_value;
}

uint8_t  UPrimitiveComponent::GetTrackingSource(){

	static UObject* p_GetTrackingSource = UObject::FindObject<UFunction>("Function HeadMountedDisplay.MotionControllerComponent.GetTrackingSource");

	struct {
		uint8_t  return_value;
	} parms;


	ProcessEvent(p_GetTrackingSource, &parms);
	return parms.return_value;
}

float UPrimitiveComponent::GetParameterValue(struct FName InName, bool& bValueFound){

	static UObject* p_GetParameterValue = UObject::FindObject<UFunction>("Function HeadMountedDisplay.MotionControllerComponent.GetParameterValue");

	struct {
		struct FName InName;
		bool& bValueFound;
		float return_value;
	} parms;

	parms.InName = InName;
	parms.bValueFound = bValueFound;

	ProcessEvent(p_GetParameterValue, &parms);
	return parms.return_value;
}

struct FVector UPrimitiveComponent::GetHandJointPosition(int32_t jointIndex, bool& bValueFound){

	static UObject* p_GetHandJointPosition = UObject::FindObject<UFunction>("Function HeadMountedDisplay.MotionControllerComponent.GetHandJointPosition");

	struct {
		int32_t jointIndex;
		bool& bValueFound;
		struct FVector return_value;
	} parms;

	parms.jointIndex = jointIndex;
	parms.bValueFound = bValueFound;

	ProcessEvent(p_GetHandJointPosition, &parms);
	return parms.return_value;
}

struct UPrimitiveComponent* UBlueprintFunctionLibrary::AddNamedDeviceVisualizationComponentBlocking(struct AActor* Target, struct FName SystemName, struct FName DeviceName, bool bManualAttachment, struct FTransform& RelativeTransform, struct FXRDeviceId& XRDeviceId){

	static UObject* p_AddNamedDeviceVisualizationComponentBlocking = UObject::FindObject<UFunction>("Function HeadMountedDisplay.XRAssetFunctionLibrary.AddNamedDeviceVisualizationComponentBlocking");

	struct {
		struct AActor* Target;
		struct FName SystemName;
		struct FName DeviceName;
		bool bManualAttachment;
		struct FTransform& RelativeTransform;
		struct FXRDeviceId& XRDeviceId;
		struct UPrimitiveComponent* return_value;
	} parms;

	parms.Target = Target;
	parms.SystemName = SystemName;
	parms.DeviceName = DeviceName;
	parms.bManualAttachment = bManualAttachment;
	parms.RelativeTransform = RelativeTransform;
	parms.XRDeviceId = XRDeviceId;

	ProcessEvent(p_AddNamedDeviceVisualizationComponentBlocking, &parms);
	return parms.return_value;
}

struct UPrimitiveComponent* UBlueprintFunctionLibrary::AddDeviceVisualizationComponentBlocking(struct AActor* Target, struct FXRDeviceId& XRDeviceId, bool bManualAttachment, struct FTransform& RelativeTransform){

	static UObject* p_AddDeviceVisualizationComponentBlocking = UObject::FindObject<UFunction>("Function HeadMountedDisplay.XRAssetFunctionLibrary.AddDeviceVisualizationComponentBlocking");

	struct {
		struct AActor* Target;
		struct FXRDeviceId& XRDeviceId;
		bool bManualAttachment;
		struct FTransform& RelativeTransform;
		struct UPrimitiveComponent* return_value;
	} parms;

	parms.Target = Target;
	parms.XRDeviceId = XRDeviceId;
	parms.bManualAttachment = bManualAttachment;
	parms.RelativeTransform = RelativeTransform;

	ProcessEvent(p_AddDeviceVisualizationComponentBlocking, &parms);
	return parms.return_value;
}

void UBlueprintFunctionLibrary::SetIsControllerMotionTrackingEnabledByDefault(bool Enable){

	static UObject* p_SetIsControllerMotionTrackingEnabledByDefault = UObject::FindObject<UFunction>("Function HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary.SetIsControllerMotionTrackingEnabledByDefault");

	struct {
		bool Enable;
	} parms;

	parms.Enable = Enable;

	ProcessEvent(p_SetIsControllerMotionTrackingEnabledByDefault, &parms);
}

bool UBlueprintFunctionLibrary::IsMotionTrackingEnabledForSource(int32_t PlayerIndex, struct FName SourceName){

	static UObject* p_IsMotionTrackingEnabledForSource = UObject::FindObject<UFunction>("Function HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary.IsMotionTrackingEnabledForSource");

	struct {
		int32_t PlayerIndex;
		struct FName SourceName;
		bool return_value;
	} parms;

	parms.PlayerIndex = PlayerIndex;
	parms.SourceName = SourceName;

	ProcessEvent(p_IsMotionTrackingEnabledForSource, &parms);
	return parms.return_value;
}

bool UBlueprintFunctionLibrary::IsMotionTrackingEnabledForDevice(int32_t PlayerIndex, uint8_t  Hand){

	static UObject* p_IsMotionTrackingEnabledForDevice = UObject::FindObject<UFunction>("Function HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary.IsMotionTrackingEnabledForDevice");

	struct {
		int32_t PlayerIndex;
		uint8_t  Hand;
		bool return_value;
	} parms;

	parms.PlayerIndex = PlayerIndex;
	parms.Hand = Hand;

	ProcessEvent(p_IsMotionTrackingEnabledForDevice, &parms);
	return parms.return_value;
}

bool UBlueprintFunctionLibrary::IsMotionTrackingEnabledForComponent(struct UMotionControllerComponent* MotionControllerComponent){

	static UObject* p_IsMotionTrackingEnabledForComponent = UObject::FindObject<UFunction>("Function HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary.IsMotionTrackingEnabledForComponent");

	struct {
		struct UMotionControllerComponent* MotionControllerComponent;
		bool return_value;
	} parms;

	parms.MotionControllerComponent = MotionControllerComponent;

	ProcessEvent(p_IsMotionTrackingEnabledForComponent, &parms);
	return parms.return_value;
}

bool UBlueprintFunctionLibrary::IsMotionTrackedDeviceCountManagementNecessary(){

	static UObject* p_IsMotionTrackedDeviceCountManagementNecessary = UObject::FindObject<UFunction>("Function HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary.IsMotionTrackedDeviceCountManagementNecessary");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_IsMotionTrackedDeviceCountManagementNecessary, &parms);
	return parms.return_value;
}

bool UBlueprintFunctionLibrary::IsMotionSourceTracking(int32_t PlayerIndex, struct FName SourceName){

	static UObject* p_IsMotionSourceTracking = UObject::FindObject<UFunction>("Function HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary.IsMotionSourceTracking");

	struct {
		int32_t PlayerIndex;
		struct FName SourceName;
		bool return_value;
	} parms;

	parms.PlayerIndex = PlayerIndex;
	parms.SourceName = SourceName;

	ProcessEvent(p_IsMotionSourceTracking, &parms);
	return parms.return_value;
}

int32_t UBlueprintFunctionLibrary::GetMotionTrackingEnabledControllerCount(){

	static UObject* p_GetMotionTrackingEnabledControllerCount = UObject::FindObject<UFunction>("Function HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary.GetMotionTrackingEnabledControllerCount");

	struct {
		int32_t return_value;
	} parms;


	ProcessEvent(p_GetMotionTrackingEnabledControllerCount, &parms);
	return parms.return_value;
}

int32_t UBlueprintFunctionLibrary::GetMaximumMotionTrackedControllerCount(){

	static UObject* p_GetMaximumMotionTrackedControllerCount = UObject::FindObject<UFunction>("Function HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary.GetMaximumMotionTrackedControllerCount");

	struct {
		int32_t return_value;
	} parms;


	ProcessEvent(p_GetMaximumMotionTrackedControllerCount, &parms);
	return parms.return_value;
}

struct FName UBlueprintFunctionLibrary::GetActiveTrackingSystemName(){

	static UObject* p_GetActiveTrackingSystemName = UObject::FindObject<UFunction>("Function HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary.GetActiveTrackingSystemName");

	struct {
		struct FName return_value;
	} parms;


	ProcessEvent(p_GetActiveTrackingSystemName, &parms);
	return parms.return_value;
}

struct TArray<struct FName> UBlueprintFunctionLibrary::EnumerateMotionSources(){

	static UObject* p_EnumerateMotionSources = UObject::FindObject<UFunction>("Function HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary.EnumerateMotionSources");

	struct {
		struct TArray<struct FName> return_value;
	} parms;


	ProcessEvent(p_EnumerateMotionSources, &parms);
	return parms.return_value;
}

bool UBlueprintFunctionLibrary::EnableMotionTrackingOfSource(int32_t PlayerIndex, struct FName SourceName){

	static UObject* p_EnableMotionTrackingOfSource = UObject::FindObject<UFunction>("Function HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary.EnableMotionTrackingOfSource");

	struct {
		int32_t PlayerIndex;
		struct FName SourceName;
		bool return_value;
	} parms;

	parms.PlayerIndex = PlayerIndex;
	parms.SourceName = SourceName;

	ProcessEvent(p_EnableMotionTrackingOfSource, &parms);
	return parms.return_value;
}

bool UBlueprintFunctionLibrary::EnableMotionTrackingOfDevice(int32_t PlayerIndex, uint8_t  Hand){

	static UObject* p_EnableMotionTrackingOfDevice = UObject::FindObject<UFunction>("Function HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary.EnableMotionTrackingOfDevice");

	struct {
		int32_t PlayerIndex;
		uint8_t  Hand;
		bool return_value;
	} parms;

	parms.PlayerIndex = PlayerIndex;
	parms.Hand = Hand;

	ProcessEvent(p_EnableMotionTrackingOfDevice, &parms);
	return parms.return_value;
}

bool UBlueprintFunctionLibrary::EnableMotionTrackingForComponent(struct UMotionControllerComponent* MotionControllerComponent){

	static UObject* p_EnableMotionTrackingForComponent = UObject::FindObject<UFunction>("Function HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary.EnableMotionTrackingForComponent");

	struct {
		struct UMotionControllerComponent* MotionControllerComponent;
		bool return_value;
	} parms;

	parms.MotionControllerComponent = MotionControllerComponent;

	ProcessEvent(p_EnableMotionTrackingForComponent, &parms);
	return parms.return_value;
}

void UBlueprintFunctionLibrary::DisableMotionTrackingOfSource(int32_t PlayerIndex, struct FName SourceName){

	static UObject* p_DisableMotionTrackingOfSource = UObject::FindObject<UFunction>("Function HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary.DisableMotionTrackingOfSource");

	struct {
		int32_t PlayerIndex;
		struct FName SourceName;
	} parms;

	parms.PlayerIndex = PlayerIndex;
	parms.SourceName = SourceName;

	ProcessEvent(p_DisableMotionTrackingOfSource, &parms);
}

void UBlueprintFunctionLibrary::DisableMotionTrackingOfDevice(int32_t PlayerIndex, uint8_t  Hand){

	static UObject* p_DisableMotionTrackingOfDevice = UObject::FindObject<UFunction>("Function HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary.DisableMotionTrackingOfDevice");

	struct {
		int32_t PlayerIndex;
		uint8_t  Hand;
	} parms;

	parms.PlayerIndex = PlayerIndex;
	parms.Hand = Hand;

	ProcessEvent(p_DisableMotionTrackingOfDevice, &parms);
}

void UBlueprintFunctionLibrary::DisableMotionTrackingOfControllersForPlayer(int32_t PlayerIndex){

	static UObject* p_DisableMotionTrackingOfControllersForPlayer = UObject::FindObject<UFunction>("Function HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary.DisableMotionTrackingOfControllersForPlayer");

	struct {
		int32_t PlayerIndex;
	} parms;

	parms.PlayerIndex = PlayerIndex;

	ProcessEvent(p_DisableMotionTrackingOfControllersForPlayer, &parms);
}

void UBlueprintFunctionLibrary::DisableMotionTrackingOfAllControllers(){

	static UObject* p_DisableMotionTrackingOfAllControllers = UObject::FindObject<UFunction>("Function HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary.DisableMotionTrackingOfAllControllers");

	struct {
	} parms;


	ProcessEvent(p_DisableMotionTrackingOfAllControllers, &parms);
}

void UBlueprintFunctionLibrary::DisableMotionTrackingForComponent(struct UMotionControllerComponent* MotionControllerComponent){

	static UObject* p_DisableMotionTrackingForComponent = UObject::FindObject<UFunction>("Function HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary.DisableMotionTrackingForComponent");

	struct {
		struct UMotionControllerComponent* MotionControllerComponent;
	} parms;

	parms.MotionControllerComponent = MotionControllerComponent;

	ProcessEvent(p_DisableMotionTrackingForComponent, &parms);
}

