#include "SDK.h" 
 
 
void UObject::ExecuteUbergraph(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph = UObject::FindObject<UFunction>("Function CoreUObject.Object.ExecuteUbergraph");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph, &parms);
}

