#include "SDK.h" 
 
 
void UObject::OnMoveCompleted(struct FAIRequestID RequestID, char EPathFollowingResult MovementResult){

	static UObject* p_OnMoveCompleted = UObject::FindObject<UFunction>("Function AIModule.AIAsyncTaskBlueprintProxy.OnMoveCompleted");

	struct {
		struct FAIRequestID RequestID;
		char EPathFollowingResult MovementResult;
	} parms;

	parms.RequestID = RequestID;
	parms.MovementResult = MovementResult;

	ProcessEvent(p_OnMoveCompleted, &parms);
}

void UBlueprintFunctionLibrary::UnlockAIResourcesWithAnimation(struct UAnimInstance* AnimInstance, bool bUnlockMovement, bool UnlockAILogic){

	static UObject* p_UnlockAIResourcesWithAnimation = UObject::FindObject<UFunction>("Function AIModule.AIBlueprintHelperLibrary.UnlockAIResourcesWithAnimation");

	struct {
		struct UAnimInstance* AnimInstance;
		bool bUnlockMovement;
		bool UnlockAILogic;
	} parms;

	parms.AnimInstance = AnimInstance;
	parms.bUnlockMovement = bUnlockMovement;
	parms.UnlockAILogic = UnlockAILogic;

	ProcessEvent(p_UnlockAIResourcesWithAnimation, &parms);
}

struct APawn* UBlueprintFunctionLibrary::SpawnAIFromClass(struct UObject* WorldContextObject, APawn* PawnClass, struct UBehaviorTree* BehaviorTree, struct FVector Location, struct FRotator Rotation, bool bNoCollisionFail, struct AActor* Owner){

	static UObject* p_SpawnAIFromClass = UObject::FindObject<UFunction>("Function AIModule.AIBlueprintHelperLibrary.SpawnAIFromClass");

	struct {
		struct UObject* WorldContextObject;
		APawn* PawnClass;
		struct UBehaviorTree* BehaviorTree;
		struct FVector Location;
		struct FRotator Rotation;
		bool bNoCollisionFail;
		struct AActor* Owner;
		struct APawn* return_value;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.PawnClass = PawnClass;
	parms.BehaviorTree = BehaviorTree;
	parms.Location = Location;
	parms.Rotation = Rotation;
	parms.bNoCollisionFail = bNoCollisionFail;
	parms.Owner = Owner;

	ProcessEvent(p_SpawnAIFromClass, &parms);
	return parms.return_value;
}

void UBlueprintFunctionLibrary::SimpleMoveToLocation(struct AController* Controller, struct FVector& Goal){

	static UObject* p_SimpleMoveToLocation = UObject::FindObject<UFunction>("Function AIModule.AIBlueprintHelperLibrary.SimpleMoveToLocation");

	struct {
		struct AController* Controller;
		struct FVector& Goal;
	} parms;

	parms.Controller = Controller;
	parms.Goal = Goal;

	ProcessEvent(p_SimpleMoveToLocation, &parms);
}

void UBlueprintFunctionLibrary::SimpleMoveToActor(struct AController* Controller, struct AActor* Goal){

	static UObject* p_SimpleMoveToActor = UObject::FindObject<UFunction>("Function AIModule.AIBlueprintHelperLibrary.SimpleMoveToActor");

	struct {
		struct AController* Controller;
		struct AActor* Goal;
	} parms;

	parms.Controller = Controller;
	parms.Goal = Goal;

	ProcessEvent(p_SimpleMoveToActor, &parms);
}

void UBlueprintFunctionLibrary::SendAIMessage(struct APawn* Target, struct FName Message, struct UObject* MessageSource, bool bSuccess){

	static UObject* p_SendAIMessage = UObject::FindObject<UFunction>("Function AIModule.AIBlueprintHelperLibrary.SendAIMessage");

	struct {
		struct APawn* Target;
		struct FName Message;
		struct UObject* MessageSource;
		bool bSuccess;
	} parms;

	parms.Target = Target;
	parms.Message = Message;
	parms.MessageSource = MessageSource;
	parms.bSuccess = bSuccess;

	ProcessEvent(p_SendAIMessage, &parms);
}

void UBlueprintFunctionLibrary::LockAIResourcesWithAnimation(struct UAnimInstance* AnimInstance, bool bLockMovement, bool LockAILogic){

	static UObject* p_LockAIResourcesWithAnimation = UObject::FindObject<UFunction>("Function AIModule.AIBlueprintHelperLibrary.LockAIResourcesWithAnimation");

	struct {
		struct UAnimInstance* AnimInstance;
		bool bLockMovement;
		bool LockAILogic;
	} parms;

	parms.AnimInstance = AnimInstance;
	parms.bLockMovement = bLockMovement;
	parms.LockAILogic = LockAILogic;

	ProcessEvent(p_LockAIResourcesWithAnimation, &parms);
}

bool UBlueprintFunctionLibrary::IsValidAIRotation(struct FRotator Rotation){

	static UObject* p_IsValidAIRotation = UObject::FindObject<UFunction>("Function AIModule.AIBlueprintHelperLibrary.IsValidAIRotation");

	struct {
		struct FRotator Rotation;
		bool return_value;
	} parms;

	parms.Rotation = Rotation;

	ProcessEvent(p_IsValidAIRotation, &parms);
	return parms.return_value;
}

bool UBlueprintFunctionLibrary::IsValidAILocation(struct FVector Location){

	static UObject* p_IsValidAILocation = UObject::FindObject<UFunction>("Function AIModule.AIBlueprintHelperLibrary.IsValidAILocation");

	struct {
		struct FVector Location;
		bool return_value;
	} parms;

	parms.Location = Location;

	ProcessEvent(p_IsValidAILocation, &parms);
	return parms.return_value;
}

bool UBlueprintFunctionLibrary::IsValidAIDirection(struct FVector DirectionVector){

	static UObject* p_IsValidAIDirection = UObject::FindObject<UFunction>("Function AIModule.AIBlueprintHelperLibrary.IsValidAIDirection");

	struct {
		struct FVector DirectionVector;
		bool return_value;
	} parms;

	parms.DirectionVector = DirectionVector;

	ProcessEvent(p_IsValidAIDirection, &parms);
	return parms.return_value;
}

int32_t UBlueprintFunctionLibrary::GetNextNavLinkIndex(struct AController* Controller){

	static UObject* p_GetNextNavLinkIndex = UObject::FindObject<UFunction>("Function AIModule.AIBlueprintHelperLibrary.GetNextNavLinkIndex");

	struct {
		struct AController* Controller;
		int32_t return_value;
	} parms;

	parms.Controller = Controller;

	ProcessEvent(p_GetNextNavLinkIndex, &parms);
	return parms.return_value;
}

struct TArray<struct FVector> UBlueprintFunctionLibrary::GetCurrentPathPoints(struct AController* Controller){

	static UObject* p_GetCurrentPathPoints = UObject::FindObject<UFunction>("Function AIModule.AIBlueprintHelperLibrary.GetCurrentPathPoints");

	struct {
		struct AController* Controller;
		struct TArray<struct FVector> return_value;
	} parms;

	parms.Controller = Controller;

	ProcessEvent(p_GetCurrentPathPoints, &parms);
	return parms.return_value;
}

int32_t UBlueprintFunctionLibrary::GetCurrentPathIndex(struct AController* Controller){

	static UObject* p_GetCurrentPathIndex = UObject::FindObject<UFunction>("Function AIModule.AIBlueprintHelperLibrary.GetCurrentPathIndex");

	struct {
		struct AController* Controller;
		int32_t return_value;
	} parms;

	parms.Controller = Controller;

	ProcessEvent(p_GetCurrentPathIndex, &parms);
	return parms.return_value;
}

struct UNavigationPath* UBlueprintFunctionLibrary::GetCurrentPath(struct AController* Controller){

	static UObject* p_GetCurrentPath = UObject::FindObject<UFunction>("Function AIModule.AIBlueprintHelperLibrary.GetCurrentPath");

	struct {
		struct AController* Controller;
		struct UNavigationPath* return_value;
	} parms;

	parms.Controller = Controller;

	ProcessEvent(p_GetCurrentPath, &parms);
	return parms.return_value;
}

struct UBlackboardComponent* UBlueprintFunctionLibrary::GetBlackboard(struct AActor* Target){

	static UObject* p_GetBlackboard = UObject::FindObject<UFunction>("Function AIModule.AIBlueprintHelperLibrary.GetBlackboard");

	struct {
		struct AActor* Target;
		struct UBlackboardComponent* return_value;
	} parms;

	parms.Target = Target;

	ProcessEvent(p_GetBlackboard, &parms);
	return parms.return_value;
}

struct AAIController* UBlueprintFunctionLibrary::GetAIController(struct AActor* ControlledActor){

	static UObject* p_GetAIController = UObject::FindObject<UFunction>("Function AIModule.AIBlueprintHelperLibrary.GetAIController");

	struct {
		struct AActor* ControlledActor;
		struct AAIController* return_value;
	} parms;

	parms.ControlledActor = ControlledActor;

	ProcessEvent(p_GetAIController, &parms);
	return parms.return_value;
}

struct UAIAsyncTaskBlueprintProxy* UBlueprintFunctionLibrary::CreateMoveToProxyObject(struct UObject* WorldContextObject, struct APawn* Pawn, struct FVector Destination, struct AActor* TargetActor, float AcceptanceRadius, bool bStopOnOverlap){

	static UObject* p_CreateMoveToProxyObject = UObject::FindObject<UFunction>("Function AIModule.AIBlueprintHelperLibrary.CreateMoveToProxyObject");

	struct {
		struct UObject* WorldContextObject;
		struct APawn* Pawn;
		struct FVector Destination;
		struct AActor* TargetActor;
		float AcceptanceRadius;
		bool bStopOnOverlap;
		struct UAIAsyncTaskBlueprintProxy* return_value;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.Pawn = Pawn;
	parms.Destination = Destination;
	parms.TargetActor = TargetActor;
	parms.AcceptanceRadius = AcceptanceRadius;
	parms.bStopOnOverlap = bStopOnOverlap;

	ProcessEvent(p_CreateMoveToProxyObject, &parms);
	return parms.return_value;
}

bool AController::UseBlackboard(struct UBlackboardData* BlackboardAsset, struct UBlackboardComponent*& BlackboardComponent){

	static UObject* p_UseBlackboard = UObject::FindObject<UFunction>("Function AIModule.AIController.UseBlackboard");

	struct {
		struct UBlackboardData* BlackboardAsset;
		struct UBlackboardComponent*& BlackboardComponent;
		bool return_value;
	} parms;

	parms.BlackboardAsset = BlackboardAsset;
	parms.BlackboardComponent = BlackboardComponent;

	ProcessEvent(p_UseBlackboard, &parms);
	return parms.return_value;
}

void AController::UnclaimTaskResource(UGameplayTaskResource* ResourceClass){

	static UObject* p_UnclaimTaskResource = UObject::FindObject<UFunction>("Function AIModule.AIController.UnclaimTaskResource");

	struct {
		UGameplayTaskResource* ResourceClass;
	} parms;

	parms.ResourceClass = ResourceClass;

	ProcessEvent(p_UnclaimTaskResource, &parms);
}

void AController::SetPathFollowingComponent(struct UPathFollowingComponent* NewPFComponent){

	static UObject* p_SetPathFollowingComponent = UObject::FindObject<UFunction>("Function AIModule.AIController.SetPathFollowingComponent");

	struct {
		struct UPathFollowingComponent* NewPFComponent;
	} parms;

	parms.NewPFComponent = NewPFComponent;

	ProcessEvent(p_SetPathFollowingComponent, &parms);
}

void AController::SetMoveBlockDetection(bool bEnable){

	static UObject* p_SetMoveBlockDetection = UObject::FindObject<UFunction>("Function AIModule.AIController.SetMoveBlockDetection");

	struct {
		bool bEnable;
	} parms;

	parms.bEnable = bEnable;

	ProcessEvent(p_SetMoveBlockDetection, &parms);
}

bool AController::RunBehaviorTree(struct UBehaviorTree* BTAsset){

	static UObject* p_RunBehaviorTree = UObject::FindObject<UFunction>("Function AIModule.AIController.RunBehaviorTree");

	struct {
		struct UBehaviorTree* BTAsset;
		bool return_value;
	} parms;

	parms.BTAsset = BTAsset;

	ProcessEvent(p_RunBehaviorTree, &parms);
	return parms.return_value;
}

void AController::OnUsingBlackBoard(struct UBlackboardComponent* BlackboardComp, struct UBlackboardData* BlackboardAsset){

	static UObject* p_OnUsingBlackBoard = UObject::FindObject<UFunction>("Function AIModule.AIController.OnUsingBlackBoard");

	struct {
		struct UBlackboardComponent* BlackboardComp;
		struct UBlackboardData* BlackboardAsset;
	} parms;

	parms.BlackboardComp = BlackboardComp;
	parms.BlackboardAsset = BlackboardAsset;

	ProcessEvent(p_OnUsingBlackBoard, &parms);
}

void AController::OnGameplayTaskResourcesClaimed(struct FGameplayResourceSet NewlyClaimed, struct FGameplayResourceSet FreshlyReleased){

	static UObject* p_OnGameplayTaskResourcesClaimed = UObject::FindObject<UFunction>("Function AIModule.AIController.OnGameplayTaskResourcesClaimed");

	struct {
		struct FGameplayResourceSet NewlyClaimed;
		struct FGameplayResourceSet FreshlyReleased;
	} parms;

	parms.NewlyClaimed = NewlyClaimed;
	parms.FreshlyReleased = FreshlyReleased;

	ProcessEvent(p_OnGameplayTaskResourcesClaimed, &parms);
}

char EPathFollowingRequestResult AController::MoveToLocation(struct FVector& Dest, float AcceptanceRadius, bool bStopOnOverlap, bool bUsePathfinding, bool bProjectDestinationToNavigation, bool bCanStrafe, UNavigationQueryFilter* FilterClass, bool bAllowPartialPath){

	static UObject* p_MoveToLocation = UObject::FindObject<UFunction>("Function AIModule.AIController.MoveToLocation");

	struct {
		struct FVector& Dest;
		float AcceptanceRadius;
		bool bStopOnOverlap;
		bool bUsePathfinding;
		bool bProjectDestinationToNavigation;
		bool bCanStrafe;
		UNavigationQueryFilter* FilterClass;
		bool bAllowPartialPath;
		char EPathFollowingRequestResult return_value;
	} parms;

	parms.Dest = Dest;
	parms.AcceptanceRadius = AcceptanceRadius;
	parms.bStopOnOverlap = bStopOnOverlap;
	parms.bUsePathfinding = bUsePathfinding;
	parms.bProjectDestinationToNavigation = bProjectDestinationToNavigation;
	parms.bCanStrafe = bCanStrafe;
	parms.FilterClass = FilterClass;
	parms.bAllowPartialPath = bAllowPartialPath;

	ProcessEvent(p_MoveToLocation, &parms);
	return parms.return_value;
}

char EPathFollowingRequestResult AController::MoveToActor(struct AActor* Goal, float AcceptanceRadius, bool bStopOnOverlap, bool bUsePathfinding, bool bCanStrafe, UNavigationQueryFilter* FilterClass, bool bAllowPartialPath){

	static UObject* p_MoveToActor = UObject::FindObject<UFunction>("Function AIModule.AIController.MoveToActor");

	struct {
		struct AActor* Goal;
		float AcceptanceRadius;
		bool bStopOnOverlap;
		bool bUsePathfinding;
		bool bCanStrafe;
		UNavigationQueryFilter* FilterClass;
		bool bAllowPartialPath;
		char EPathFollowingRequestResult return_value;
	} parms;

	parms.Goal = Goal;
	parms.AcceptanceRadius = AcceptanceRadius;
	parms.bStopOnOverlap = bStopOnOverlap;
	parms.bUsePathfinding = bUsePathfinding;
	parms.bCanStrafe = bCanStrafe;
	parms.FilterClass = FilterClass;
	parms.bAllowPartialPath = bAllowPartialPath;

	ProcessEvent(p_MoveToActor, &parms);
	return parms.return_value;
}

void AController::K2_SetFocus(struct AActor* NewFocus){

	static UObject* p_K2_SetFocus = UObject::FindObject<UFunction>("Function AIModule.AIController.K2_SetFocus");

	struct {
		struct AActor* NewFocus;
	} parms;

	parms.NewFocus = NewFocus;

	ProcessEvent(p_K2_SetFocus, &parms);
}

void AController::K2_SetFocalPoint(struct FVector FP){

	static UObject* p_K2_SetFocalPoint = UObject::FindObject<UFunction>("Function AIModule.AIController.K2_SetFocalPoint");

	struct {
		struct FVector FP;
	} parms;

	parms.FP = FP;

	ProcessEvent(p_K2_SetFocalPoint, &parms);
}

void AController::K2_ClearFocus(){

	static UObject* p_K2_ClearFocus = UObject::FindObject<UFunction>("Function AIModule.AIController.K2_ClearFocus");

	struct {
	} parms;


	ProcessEvent(p_K2_ClearFocus, &parms);
}

bool AController::HasPartialPath(){

	static UObject* p_HasPartialPath = UObject::FindObject<UFunction>("Function AIModule.AIController.HasPartialPath");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_HasPartialPath, &parms);
	return parms.return_value;
}

struct UPathFollowingComponent* AController::GetPathFollowingComponent(){

	static UObject* p_GetPathFollowingComponent = UObject::FindObject<UFunction>("Function AIModule.AIController.GetPathFollowingComponent");

	struct {
		struct UPathFollowingComponent* return_value;
	} parms;


	ProcessEvent(p_GetPathFollowingComponent, &parms);
	return parms.return_value;
}

char EPathFollowingStatus AController::GetMoveStatus(){

	static UObject* p_GetMoveStatus = UObject::FindObject<UFunction>("Function AIModule.AIController.GetMoveStatus");

	struct {
		char EPathFollowingStatus return_value;
	} parms;


	ProcessEvent(p_GetMoveStatus, &parms);
	return parms.return_value;
}

struct FVector AController::GetImmediateMoveDestination(){

	static UObject* p_GetImmediateMoveDestination = UObject::FindObject<UFunction>("Function AIModule.AIController.GetImmediateMoveDestination");

	struct {
		struct FVector return_value;
	} parms;


	ProcessEvent(p_GetImmediateMoveDestination, &parms);
	return parms.return_value;
}

struct AActor* AController::GetFocusActor(){

	static UObject* p_GetFocusActor = UObject::FindObject<UFunction>("Function AIModule.AIController.GetFocusActor");

	struct {
		struct AActor* return_value;
	} parms;


	ProcessEvent(p_GetFocusActor, &parms);
	return parms.return_value;
}

struct FVector AController::GetFocalPointOnActor(struct AActor* Actor){

	static UObject* p_GetFocalPointOnActor = UObject::FindObject<UFunction>("Function AIModule.AIController.GetFocalPointOnActor");

	struct {
		struct AActor* Actor;
		struct FVector return_value;
	} parms;

	parms.Actor = Actor;

	ProcessEvent(p_GetFocalPointOnActor, &parms);
	return parms.return_value;
}

struct FVector AController::GetFocalPoint(){

	static UObject* p_GetFocalPoint = UObject::FindObject<UFunction>("Function AIModule.AIController.GetFocalPoint");

	struct {
		struct FVector return_value;
	} parms;


	ProcessEvent(p_GetFocalPoint, &parms);
	return parms.return_value;
}

struct UAIPerceptionComponent* AController::GetAIPerceptionComponent(){

	static UObject* p_GetAIPerceptionComponent = UObject::FindObject<UFunction>("Function AIModule.AIController.GetAIPerceptionComponent");

	struct {
		struct UAIPerceptionComponent* return_value;
	} parms;


	ProcessEvent(p_GetAIPerceptionComponent, &parms);
	return parms.return_value;
}

void AController::ClaimTaskResource(UGameplayTaskResource* ResourceClass){

	static UObject* p_ClaimTaskResource = UObject::FindObject<UFunction>("Function AIModule.AIController.ClaimTaskResource");

	struct {
		UGameplayTaskResource* ResourceClass;
	} parms;

	parms.ResourceClass = ResourceClass;

	ProcessEvent(p_ClaimTaskResource, &parms);
}

void UBTDecorator::ReceiveTickAI(struct AAIController* OwnerController, struct APawn* ControlledPawn, float DeltaSeconds){

	static UObject* p_ReceiveTickAI = UObject::FindObject<UFunction>("Function AIModule.BTDecorator_BlueprintBase.ReceiveTickAI");

	struct {
		struct AAIController* OwnerController;
		struct APawn* ControlledPawn;
		float DeltaSeconds;
	} parms;

	parms.OwnerController = OwnerController;
	parms.ControlledPawn = ControlledPawn;
	parms.DeltaSeconds = DeltaSeconds;

	ProcessEvent(p_ReceiveTickAI, &parms);
}

void UBTDecorator::ReceiveTick(struct AActor* OwnerActor, float DeltaSeconds){

	static UObject* p_ReceiveTick = UObject::FindObject<UFunction>("Function AIModule.BTDecorator_BlueprintBase.ReceiveTick");

	struct {
		struct AActor* OwnerActor;
		float DeltaSeconds;
	} parms;

	parms.OwnerActor = OwnerActor;
	parms.DeltaSeconds = DeltaSeconds;

	ProcessEvent(p_ReceiveTick, &parms);
}

void UBTDecorator::ReceiveObserverDeactivatedAI(struct AAIController* OwnerController, struct APawn* ControlledPawn){

	static UObject* p_ReceiveObserverDeactivatedAI = UObject::FindObject<UFunction>("Function AIModule.BTDecorator_BlueprintBase.ReceiveObserverDeactivatedAI");

	struct {
		struct AAIController* OwnerController;
		struct APawn* ControlledPawn;
	} parms;

	parms.OwnerController = OwnerController;
	parms.ControlledPawn = ControlledPawn;

	ProcessEvent(p_ReceiveObserverDeactivatedAI, &parms);
}

void UBTDecorator::ReceiveObserverDeactivated(struct AActor* OwnerActor){

	static UObject* p_ReceiveObserverDeactivated = UObject::FindObject<UFunction>("Function AIModule.BTDecorator_BlueprintBase.ReceiveObserverDeactivated");

	struct {
		struct AActor* OwnerActor;
	} parms;

	parms.OwnerActor = OwnerActor;

	ProcessEvent(p_ReceiveObserverDeactivated, &parms);
}

void UBTDecorator::ReceiveObserverActivatedAI(struct AAIController* OwnerController, struct APawn* ControlledPawn){

	static UObject* p_ReceiveObserverActivatedAI = UObject::FindObject<UFunction>("Function AIModule.BTDecorator_BlueprintBase.ReceiveObserverActivatedAI");

	struct {
		struct AAIController* OwnerController;
		struct APawn* ControlledPawn;
	} parms;

	parms.OwnerController = OwnerController;
	parms.ControlledPawn = ControlledPawn;

	ProcessEvent(p_ReceiveObserverActivatedAI, &parms);
}

void UBTDecorator::ReceiveObserverActivated(struct AActor* OwnerActor){

	static UObject* p_ReceiveObserverActivated = UObject::FindObject<UFunction>("Function AIModule.BTDecorator_BlueprintBase.ReceiveObserverActivated");

	struct {
		struct AActor* OwnerActor;
	} parms;

	parms.OwnerActor = OwnerActor;

	ProcessEvent(p_ReceiveObserverActivated, &parms);
}

void UBTDecorator::ReceiveExecutionStartAI(struct AAIController* OwnerController, struct APawn* ControlledPawn){

	static UObject* p_ReceiveExecutionStartAI = UObject::FindObject<UFunction>("Function AIModule.BTDecorator_BlueprintBase.ReceiveExecutionStartAI");

	struct {
		struct AAIController* OwnerController;
		struct APawn* ControlledPawn;
	} parms;

	parms.OwnerController = OwnerController;
	parms.ControlledPawn = ControlledPawn;

	ProcessEvent(p_ReceiveExecutionStartAI, &parms);
}

void UBTDecorator::ReceiveExecutionStart(struct AActor* OwnerActor){

	static UObject* p_ReceiveExecutionStart = UObject::FindObject<UFunction>("Function AIModule.BTDecorator_BlueprintBase.ReceiveExecutionStart");

	struct {
		struct AActor* OwnerActor;
	} parms;

	parms.OwnerActor = OwnerActor;

	ProcessEvent(p_ReceiveExecutionStart, &parms);
}

void UBTDecorator::ReceiveExecutionFinishAI(struct AAIController* OwnerController, struct APawn* ControlledPawn, char EBTNodeResult NodeResult){

	static UObject* p_ReceiveExecutionFinishAI = UObject::FindObject<UFunction>("Function AIModule.BTDecorator_BlueprintBase.ReceiveExecutionFinishAI");

	struct {
		struct AAIController* OwnerController;
		struct APawn* ControlledPawn;
		char EBTNodeResult NodeResult;
	} parms;

	parms.OwnerController = OwnerController;
	parms.ControlledPawn = ControlledPawn;
	parms.NodeResult = NodeResult;

	ProcessEvent(p_ReceiveExecutionFinishAI, &parms);
}

void UBTDecorator::ReceiveExecutionFinish(struct AActor* OwnerActor, char EBTNodeResult NodeResult){

	static UObject* p_ReceiveExecutionFinish = UObject::FindObject<UFunction>("Function AIModule.BTDecorator_BlueprintBase.ReceiveExecutionFinish");

	struct {
		struct AActor* OwnerActor;
		char EBTNodeResult NodeResult;
	} parms;

	parms.OwnerActor = OwnerActor;
	parms.NodeResult = NodeResult;

	ProcessEvent(p_ReceiveExecutionFinish, &parms);
}

bool UBTDecorator::PerformConditionCheckAI(struct AAIController* OwnerController, struct APawn* ControlledPawn){

	static UObject* p_PerformConditionCheckAI = UObject::FindObject<UFunction>("Function AIModule.BTDecorator_BlueprintBase.PerformConditionCheckAI");

	struct {
		struct AAIController* OwnerController;
		struct APawn* ControlledPawn;
		bool return_value;
	} parms;

	parms.OwnerController = OwnerController;
	parms.ControlledPawn = ControlledPawn;

	ProcessEvent(p_PerformConditionCheckAI, &parms);
	return parms.return_value;
}

bool UBTDecorator::PerformConditionCheck(struct AActor* OwnerActor){

	static UObject* p_PerformConditionCheck = UObject::FindObject<UFunction>("Function AIModule.BTDecorator_BlueprintBase.PerformConditionCheck");

	struct {
		struct AActor* OwnerActor;
		bool return_value;
	} parms;

	parms.OwnerActor = OwnerActor;

	ProcessEvent(p_PerformConditionCheck, &parms);
	return parms.return_value;
}

bool UBTDecorator::IsDecoratorObserverActive(){

	static UObject* p_IsDecoratorObserverActive = UObject::FindObject<UFunction>("Function AIModule.BTDecorator_BlueprintBase.IsDecoratorObserverActive");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_IsDecoratorObserverActive, &parms);
	return parms.return_value;
}

bool UBTDecorator::IsDecoratorExecutionActive(){

	static UObject* p_IsDecoratorExecutionActive = UObject::FindObject<UFunction>("Function AIModule.BTDecorator_BlueprintBase.IsDecoratorExecutionActive");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_IsDecoratorExecutionActive, &parms);
	return parms.return_value;
}

struct UAITask_RunEQS* UAITask::RunEQS(struct AAIController* Controller, struct UEnvQuery* QueryTemplate){

	static UObject* p_RunEQS = UObject::FindObject<UFunction>("Function AIModule.AITask_RunEQS.RunEQS");

	struct {
		struct AAIController* Controller;
		struct UEnvQuery* QueryTemplate;
		struct UAITask_RunEQS* return_value;
	} parms;

	parms.Controller = Controller;
	parms.QueryTemplate = QueryTemplate;

	ProcessEvent(p_RunEQS, &parms);
	return parms.return_value;
}

void UActorComponent::SetSenseEnabled(UAISense* SenseClass, bool bEnable){

	static UObject* p_SetSenseEnabled = UObject::FindObject<UFunction>("Function AIModule.AIPerceptionComponent.SetSenseEnabled");

	struct {
		UAISense* SenseClass;
		bool bEnable;
	} parms;

	parms.SenseClass = SenseClass;
	parms.bEnable = bEnable;

	ProcessEvent(p_SetSenseEnabled, &parms);
}

void UActorComponent::RequestStimuliListenerUpdate(){

	static UObject* p_RequestStimuliListenerUpdate = UObject::FindObject<UFunction>("Function AIModule.AIPerceptionComponent.RequestStimuliListenerUpdate");

	struct {
	} parms;


	ProcessEvent(p_RequestStimuliListenerUpdate, &parms);
}

void UActorComponent::OnOwnerEndPlay(struct AActor* Actor, char EEndPlayReason EndPlayReason){

	static UObject* p_OnOwnerEndPlay = UObject::FindObject<UFunction>("Function AIModule.AIPerceptionComponent.OnOwnerEndPlay");

	struct {
		struct AActor* Actor;
		char EEndPlayReason EndPlayReason;
	} parms;

	parms.Actor = Actor;
	parms.EndPlayReason = EndPlayReason;

	ProcessEvent(p_OnOwnerEndPlay, &parms);
}

void UActorComponent::GetPerceivedHostileActorsBySense(UAISense* SenseToUse, struct TArray<struct AActor*>& OutActors){

	static UObject* p_GetPerceivedHostileActorsBySense = UObject::FindObject<UFunction>("Function AIModule.AIPerceptionComponent.GetPerceivedHostileActorsBySense");

	struct {
		UAISense* SenseToUse;
		struct TArray<struct AActor*>& OutActors;
	} parms;

	parms.SenseToUse = SenseToUse;
	parms.OutActors = OutActors;

	ProcessEvent(p_GetPerceivedHostileActorsBySense, &parms);
}

void UActorComponent::GetPerceivedHostileActors(struct TArray<struct AActor*>& OutActors){

	static UObject* p_GetPerceivedHostileActors = UObject::FindObject<UFunction>("Function AIModule.AIPerceptionComponent.GetPerceivedHostileActors");

	struct {
		struct TArray<struct AActor*>& OutActors;
	} parms;

	parms.OutActors = OutActors;

	ProcessEvent(p_GetPerceivedHostileActors, &parms);
}

void UActorComponent::GetPerceivedActors(UAISense* SenseToUse, struct TArray<struct AActor*>& OutActors){

	static UObject* p_GetPerceivedActors = UObject::FindObject<UFunction>("Function AIModule.AIPerceptionComponent.GetPerceivedActors");

	struct {
		UAISense* SenseToUse;
		struct TArray<struct AActor*>& OutActors;
	} parms;

	parms.SenseToUse = SenseToUse;
	parms.OutActors = OutActors;

	ProcessEvent(p_GetPerceivedActors, &parms);
}

void UActorComponent::GetKnownPerceivedActors(UAISense* SenseToUse, struct TArray<struct AActor*>& OutActors){

	static UObject* p_GetKnownPerceivedActors = UObject::FindObject<UFunction>("Function AIModule.AIPerceptionComponent.GetKnownPerceivedActors");

	struct {
		UAISense* SenseToUse;
		struct TArray<struct AActor*>& OutActors;
	} parms;

	parms.SenseToUse = SenseToUse;
	parms.OutActors = OutActors;

	ProcessEvent(p_GetKnownPerceivedActors, &parms);
}

void UActorComponent::GetCurrentlyPerceivedActors(UAISense* SenseToUse, struct TArray<struct AActor*>& OutActors){

	static UObject* p_GetCurrentlyPerceivedActors = UObject::FindObject<UFunction>("Function AIModule.AIPerceptionComponent.GetCurrentlyPerceivedActors");

	struct {
		UAISense* SenseToUse;
		struct TArray<struct AActor*>& OutActors;
	} parms;

	parms.SenseToUse = SenseToUse;
	parms.OutActors = OutActors;

	ProcessEvent(p_GetCurrentlyPerceivedActors, &parms);
}

bool UActorComponent::GetActorsPerception(struct AActor* Actor, struct FActorPerceptionBlueprintInfo& Info){

	static UObject* p_GetActorsPerception = UObject::FindObject<UFunction>("Function AIModule.AIPerceptionComponent.GetActorsPerception");

	struct {
		struct AActor* Actor;
		struct FActorPerceptionBlueprintInfo& Info;
		bool return_value;
	} parms;

	parms.Actor = Actor;
	parms.Info = Info;

	ProcessEvent(p_GetActorsPerception, &parms);
	return parms.return_value;
}

void UActorComponent::ForgetAll(){

	static UObject* p_ForgetAll = UObject::FindObject<UFunction>("Function AIModule.AIPerceptionComponent.ForgetAll");

	struct {
	} parms;


	ProcessEvent(p_ForgetAll, &parms);
}

void UActorComponent::UnregisterFromSense(UAISense* SenseClass){

	static UObject* p_UnregisterFromSense = UObject::FindObject<UFunction>("Function AIModule.AIPerceptionStimuliSourceComponent.UnregisterFromSense");

	struct {
		UAISense* SenseClass;
	} parms;

	parms.SenseClass = SenseClass;

	ProcessEvent(p_UnregisterFromSense, &parms);
}

void UActorComponent::UnregisterFromPerceptionSystem(){

	static UObject* p_UnregisterFromPerceptionSystem = UObject::FindObject<UFunction>("Function AIModule.AIPerceptionStimuliSourceComponent.UnregisterFromPerceptionSystem");

	struct {
	} parms;


	ProcessEvent(p_UnregisterFromPerceptionSystem, &parms);
}

void UActorComponent::RegisterWithPerceptionSystem(){

	static UObject* p_RegisterWithPerceptionSystem = UObject::FindObject<UFunction>("Function AIModule.AIPerceptionStimuliSourceComponent.RegisterWithPerceptionSystem");

	struct {
	} parms;


	ProcessEvent(p_RegisterWithPerceptionSystem, &parms);
}

void UActorComponent::RegisterForSense(UAISense* SenseClass){

	static UObject* p_RegisterForSense = UObject::FindObject<UFunction>("Function AIModule.AIPerceptionStimuliSourceComponent.RegisterForSense");

	struct {
		UAISense* SenseClass;
	} parms;

	parms.SenseClass = SenseClass;

	ProcessEvent(p_RegisterForSense, &parms);
}

void UActorComponent::SetValueAsVector(struct FName& KeyName, struct FVector VectorValue){

	static UObject* p_SetValueAsVector = UObject::FindObject<UFunction>("Function AIModule.BlackboardComponent.SetValueAsVector");

	struct {
		struct FName& KeyName;
		struct FVector VectorValue;
	} parms;

	parms.KeyName = KeyName;
	parms.VectorValue = VectorValue;

	ProcessEvent(p_SetValueAsVector, &parms);
}

void UActorComponent::SetValueAsString(struct FName& KeyName, struct FString StringValue){

	static UObject* p_SetValueAsString = UObject::FindObject<UFunction>("Function AIModule.BlackboardComponent.SetValueAsString");

	struct {
		struct FName& KeyName;
		struct FString StringValue;
	} parms;

	parms.KeyName = KeyName;
	parms.StringValue = StringValue;

	ProcessEvent(p_SetValueAsString, &parms);
}

void UActorComponent::SetValueAsRotator(struct FName& KeyName, struct FRotator VectorValue){

	static UObject* p_SetValueAsRotator = UObject::FindObject<UFunction>("Function AIModule.BlackboardComponent.SetValueAsRotator");

	struct {
		struct FName& KeyName;
		struct FRotator VectorValue;
	} parms;

	parms.KeyName = KeyName;
	parms.VectorValue = VectorValue;

	ProcessEvent(p_SetValueAsRotator, &parms);
}

void UActorComponent::SetValueAsObject(struct FName& KeyName, struct UObject* ObjectValue){

	static UObject* p_SetValueAsObject = UObject::FindObject<UFunction>("Function AIModule.BlackboardComponent.SetValueAsObject");

	struct {
		struct FName& KeyName;
		struct UObject* ObjectValue;
	} parms;

	parms.KeyName = KeyName;
	parms.ObjectValue = ObjectValue;

	ProcessEvent(p_SetValueAsObject, &parms);
}

void UActorComponent::SetValueAsName(struct FName& KeyName, struct FName NameValue){

	static UObject* p_SetValueAsName = UObject::FindObject<UFunction>("Function AIModule.BlackboardComponent.SetValueAsName");

	struct {
		struct FName& KeyName;
		struct FName NameValue;
	} parms;

	parms.KeyName = KeyName;
	parms.NameValue = NameValue;

	ProcessEvent(p_SetValueAsName, &parms);
}

void UActorComponent::SetValueAsInt(struct FName& KeyName, int32_t IntValue){

	static UObject* p_SetValueAsInt = UObject::FindObject<UFunction>("Function AIModule.BlackboardComponent.SetValueAsInt");

	struct {
		struct FName& KeyName;
		int32_t IntValue;
	} parms;

	parms.KeyName = KeyName;
	parms.IntValue = IntValue;

	ProcessEvent(p_SetValueAsInt, &parms);
}

void UActorComponent::SetValueAsFloat(struct FName& KeyName, float FloatValue){

	static UObject* p_SetValueAsFloat = UObject::FindObject<UFunction>("Function AIModule.BlackboardComponent.SetValueAsFloat");

	struct {
		struct FName& KeyName;
		float FloatValue;
	} parms;

	parms.KeyName = KeyName;
	parms.FloatValue = FloatValue;

	ProcessEvent(p_SetValueAsFloat, &parms);
}

void UActorComponent::SetValueAsEnum(struct FName& KeyName, char EnumValue){

	static UObject* p_SetValueAsEnum = UObject::FindObject<UFunction>("Function AIModule.BlackboardComponent.SetValueAsEnum");

	struct {
		struct FName& KeyName;
		char EnumValue;
	} parms;

	parms.KeyName = KeyName;
	parms.EnumValue = EnumValue;

	ProcessEvent(p_SetValueAsEnum, &parms);
}

void UActorComponent::SetValueAsClass(struct FName& KeyName, UObject* ClassValue){

	static UObject* p_SetValueAsClass = UObject::FindObject<UFunction>("Function AIModule.BlackboardComponent.SetValueAsClass");

	struct {
		struct FName& KeyName;
		UObject* ClassValue;
	} parms;

	parms.KeyName = KeyName;
	parms.ClassValue = ClassValue;

	ProcessEvent(p_SetValueAsClass, &parms);
}

void UActorComponent::SetValueAsBool(struct FName& KeyName, bool BoolValue){

	static UObject* p_SetValueAsBool = UObject::FindObject<UFunction>("Function AIModule.BlackboardComponent.SetValueAsBool");

	struct {
		struct FName& KeyName;
		bool BoolValue;
	} parms;

	parms.KeyName = KeyName;
	parms.BoolValue = BoolValue;

	ProcessEvent(p_SetValueAsBool, &parms);
}

bool UActorComponent::IsVectorValueSet(struct FName& KeyName){

	static UObject* p_IsVectorValueSet = UObject::FindObject<UFunction>("Function AIModule.BlackboardComponent.IsVectorValueSet");

	struct {
		struct FName& KeyName;
		bool return_value;
	} parms;

	parms.KeyName = KeyName;

	ProcessEvent(p_IsVectorValueSet, &parms);
	return parms.return_value;
}

struct FVector UActorComponent::GetValueAsVector(struct FName& KeyName){

	static UObject* p_GetValueAsVector = UObject::FindObject<UFunction>("Function AIModule.BlackboardComponent.GetValueAsVector");

	struct {
		struct FName& KeyName;
		struct FVector return_value;
	} parms;

	parms.KeyName = KeyName;

	ProcessEvent(p_GetValueAsVector, &parms);
	return parms.return_value;
}

struct FString UActorComponent::GetValueAsString(struct FName& KeyName){

	static UObject* p_GetValueAsString = UObject::FindObject<UFunction>("Function AIModule.BlackboardComponent.GetValueAsString");

	struct {
		struct FName& KeyName;
		struct FString return_value;
	} parms;

	parms.KeyName = KeyName;

	ProcessEvent(p_GetValueAsString, &parms);
	return parms.return_value;
}

struct FRotator UActorComponent::GetValueAsRotator(struct FName& KeyName){

	static UObject* p_GetValueAsRotator = UObject::FindObject<UFunction>("Function AIModule.BlackboardComponent.GetValueAsRotator");

	struct {
		struct FName& KeyName;
		struct FRotator return_value;
	} parms;

	parms.KeyName = KeyName;

	ProcessEvent(p_GetValueAsRotator, &parms);
	return parms.return_value;
}

struct UObject* UActorComponent::GetValueAsObject(struct FName& KeyName){

	static UObject* p_GetValueAsObject = UObject::FindObject<UFunction>("Function AIModule.BlackboardComponent.GetValueAsObject");

	struct {
		struct FName& KeyName;
		struct UObject* return_value;
	} parms;

	parms.KeyName = KeyName;

	ProcessEvent(p_GetValueAsObject, &parms);
	return parms.return_value;
}

struct FName UActorComponent::GetValueAsName(struct FName& KeyName){

	static UObject* p_GetValueAsName = UObject::FindObject<UFunction>("Function AIModule.BlackboardComponent.GetValueAsName");

	struct {
		struct FName& KeyName;
		struct FName return_value;
	} parms;

	parms.KeyName = KeyName;

	ProcessEvent(p_GetValueAsName, &parms);
	return parms.return_value;
}

int32_t UActorComponent::GetValueAsInt(struct FName& KeyName){

	static UObject* p_GetValueAsInt = UObject::FindObject<UFunction>("Function AIModule.BlackboardComponent.GetValueAsInt");

	struct {
		struct FName& KeyName;
		int32_t return_value;
	} parms;

	parms.KeyName = KeyName;

	ProcessEvent(p_GetValueAsInt, &parms);
	return parms.return_value;
}

float UActorComponent::GetValueAsFloat(struct FName& KeyName){

	static UObject* p_GetValueAsFloat = UObject::FindObject<UFunction>("Function AIModule.BlackboardComponent.GetValueAsFloat");

	struct {
		struct FName& KeyName;
		float return_value;
	} parms;

	parms.KeyName = KeyName;

	ProcessEvent(p_GetValueAsFloat, &parms);
	return parms.return_value;
}

char UActorComponent::GetValueAsEnum(struct FName& KeyName){

	static UObject* p_GetValueAsEnum = UObject::FindObject<UFunction>("Function AIModule.BlackboardComponent.GetValueAsEnum");

	struct {
		struct FName& KeyName;
		char return_value;
	} parms;

	parms.KeyName = KeyName;

	ProcessEvent(p_GetValueAsEnum, &parms);
	return parms.return_value;
}

UObject* UActorComponent::GetValueAsClass(struct FName& KeyName){

	static UObject* p_GetValueAsClass = UObject::FindObject<UFunction>("Function AIModule.BlackboardComponent.GetValueAsClass");

	struct {
		struct FName& KeyName;
		UObject* return_value;
	} parms;

	parms.KeyName = KeyName;

	ProcessEvent(p_GetValueAsClass, &parms);
	return parms.return_value;
}

bool UActorComponent::GetValueAsBool(struct FName& KeyName){

	static UObject* p_GetValueAsBool = UObject::FindObject<UFunction>("Function AIModule.BlackboardComponent.GetValueAsBool");

	struct {
		struct FName& KeyName;
		bool return_value;
	} parms;

	parms.KeyName = KeyName;

	ProcessEvent(p_GetValueAsBool, &parms);
	return parms.return_value;
}

bool UActorComponent::GetRotationFromEntry(struct FName& KeyName, struct FRotator& ResultRotation){

	static UObject* p_GetRotationFromEntry = UObject::FindObject<UFunction>("Function AIModule.BlackboardComponent.GetRotationFromEntry");

	struct {
		struct FName& KeyName;
		struct FRotator& ResultRotation;
		bool return_value;
	} parms;

	parms.KeyName = KeyName;
	parms.ResultRotation = ResultRotation;

	ProcessEvent(p_GetRotationFromEntry, &parms);
	return parms.return_value;
}

bool UActorComponent::GetLocationFromEntry(struct FName& KeyName, struct FVector& ResultLocation){

	static UObject* p_GetLocationFromEntry = UObject::FindObject<UFunction>("Function AIModule.BlackboardComponent.GetLocationFromEntry");

	struct {
		struct FName& KeyName;
		struct FVector& ResultLocation;
		bool return_value;
	} parms;

	parms.KeyName = KeyName;
	parms.ResultLocation = ResultLocation;

	ProcessEvent(p_GetLocationFromEntry, &parms);
	return parms.return_value;
}

void UActorComponent::ClearValue(struct FName& KeyName){

	static UObject* p_ClearValue = UObject::FindObject<UFunction>("Function AIModule.BlackboardComponent.ClearValue");

	struct {
		struct FName& KeyName;
	} parms;

	parms.KeyName = KeyName;

	ProcessEvent(p_ClearValue, &parms);
}

void UAISubsystem::ReportPerceptionEvent(struct UObject* WorldContextObject, struct UAISenseEvent* PerceptionEvent){

	static UObject* p_ReportPerceptionEvent = UObject::FindObject<UFunction>("Function AIModule.AIPerceptionSystem.ReportPerceptionEvent");

	struct {
		struct UObject* WorldContextObject;
		struct UAISenseEvent* PerceptionEvent;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.PerceptionEvent = PerceptionEvent;

	ProcessEvent(p_ReportPerceptionEvent, &parms);
}

void UAISubsystem::ReportEvent(struct UAISenseEvent* PerceptionEvent){

	static UObject* p_ReportEvent = UObject::FindObject<UFunction>("Function AIModule.AIPerceptionSystem.ReportEvent");

	struct {
		struct UAISenseEvent* PerceptionEvent;
	} parms;

	parms.PerceptionEvent = PerceptionEvent;

	ProcessEvent(p_ReportEvent, &parms);
}

bool UAISubsystem::RegisterPerceptionStimuliSource(struct UObject* WorldContextObject, UAISense* Sense, struct AActor* Target){

	static UObject* p_RegisterPerceptionStimuliSource = UObject::FindObject<UFunction>("Function AIModule.AIPerceptionSystem.RegisterPerceptionStimuliSource");

	struct {
		struct UObject* WorldContextObject;
		UAISense* Sense;
		struct AActor* Target;
		bool return_value;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.Sense = Sense;
	parms.Target = Target;

	ProcessEvent(p_RegisterPerceptionStimuliSource, &parms);
	return parms.return_value;
}

void UAISubsystem::OnPerceptionStimuliSourceEndPlay(struct AActor* Actor, char EEndPlayReason EndPlayReason){

	static UObject* p_OnPerceptionStimuliSourceEndPlay = UObject::FindObject<UFunction>("Function AIModule.AIPerceptionSystem.OnPerceptionStimuliSourceEndPlay");

	struct {
		struct AActor* Actor;
		char EEndPlayReason EndPlayReason;
	} parms;

	parms.Actor = Actor;
	parms.EndPlayReason = EndPlayReason;

	ProcessEvent(p_OnPerceptionStimuliSourceEndPlay, &parms);
}

UAISense* UAISubsystem::GetSenseClassForStimulus(struct UObject* WorldContextObject, struct FAIStimulus& Stimulus){

	static UObject* p_GetSenseClassForStimulus = UObject::FindObject<UFunction>("Function AIModule.AIPerceptionSystem.GetSenseClassForStimulus");

	struct {
		struct UObject* WorldContextObject;
		struct FAIStimulus& Stimulus;
		UAISense* return_value;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.Stimulus = Stimulus;

	ProcessEvent(p_GetSenseClassForStimulus, &parms);
	return parms.return_value;
}

float UAISense::OnUpdate(struct TArray<struct UAISenseEvent*>& EventsToProcess){

	static UObject* p_OnUpdate = UObject::FindObject<UFunction>("Function AIModule.AISense_Blueprint.OnUpdate");

	struct {
		struct TArray<struct UAISenseEvent*>& EventsToProcess;
		float return_value;
	} parms;

	parms.EventsToProcess = EventsToProcess;

	ProcessEvent(p_OnUpdate, &parms);
	return parms.return_value;
}

void UAISense::OnListenerUpdated(struct AActor* ActorListener, struct UAIPerceptionComponent* PerceptionComponent){

	static UObject* p_OnListenerUpdated = UObject::FindObject<UFunction>("Function AIModule.AISense_Blueprint.OnListenerUpdated");

	struct {
		struct AActor* ActorListener;
		struct UAIPerceptionComponent* PerceptionComponent;
	} parms;

	parms.ActorListener = ActorListener;
	parms.PerceptionComponent = PerceptionComponent;

	ProcessEvent(p_OnListenerUpdated, &parms);
}

void UAISense::OnListenerUnregistered(struct AActor* ActorListener, struct UAIPerceptionComponent* PerceptionComponent){

	static UObject* p_OnListenerUnregistered = UObject::FindObject<UFunction>("Function AIModule.AISense_Blueprint.OnListenerUnregistered");

	struct {
		struct AActor* ActorListener;
		struct UAIPerceptionComponent* PerceptionComponent;
	} parms;

	parms.ActorListener = ActorListener;
	parms.PerceptionComponent = PerceptionComponent;

	ProcessEvent(p_OnListenerUnregistered, &parms);
}

void UAISense::OnListenerRegistered(struct AActor* ActorListener, struct UAIPerceptionComponent* PerceptionComponent){

	static UObject* p_OnListenerRegistered = UObject::FindObject<UFunction>("Function AIModule.AISense_Blueprint.OnListenerRegistered");

	struct {
		struct AActor* ActorListener;
		struct UAIPerceptionComponent* PerceptionComponent;
	} parms;

	parms.ActorListener = ActorListener;
	parms.PerceptionComponent = PerceptionComponent;

	ProcessEvent(p_OnListenerRegistered, &parms);
}

void UAISense::K2_OnNewPawn(struct APawn* NewPawn){

	static UObject* p_K2_OnNewPawn = UObject::FindObject<UFunction>("Function AIModule.AISense_Blueprint.K2_OnNewPawn");

	struct {
		struct APawn* NewPawn;
	} parms;

	parms.NewPawn = NewPawn;

	ProcessEvent(p_K2_OnNewPawn, &parms);
}

void UAISense::GetAllListenerComponents(struct TArray<struct UAIPerceptionComponent*>& ListenerComponents){

	static UObject* p_GetAllListenerComponents = UObject::FindObject<UFunction>("Function AIModule.AISense_Blueprint.GetAllListenerComponents");

	struct {
		struct TArray<struct UAIPerceptionComponent*>& ListenerComponents;
	} parms;

	parms.ListenerComponents = ListenerComponents;

	ProcessEvent(p_GetAllListenerComponents, &parms);
}

void UAISense::GetAllListenerActors(struct TArray<struct AActor*>& ListenerActors){

	static UObject* p_GetAllListenerActors = UObject::FindObject<UFunction>("Function AIModule.AISense_Blueprint.GetAllListenerActors");

	struct {
		struct TArray<struct AActor*>& ListenerActors;
	} parms;

	parms.ListenerActors = ListenerActors;

	ProcessEvent(p_GetAllListenerActors, &parms);
}

void UAISense::ReportDamageEvent(struct UObject* WorldContextObject, struct AActor* DamagedActor, struct AActor* Instigator, float DamageAmount, struct FVector EventLocation, struct FVector HitLocation, struct FName Tag){

	static UObject* p_ReportDamageEvent = UObject::FindObject<UFunction>("Function AIModule.AISense_Damage.ReportDamageEvent");

	struct {
		struct UObject* WorldContextObject;
		struct AActor* DamagedActor;
		struct AActor* Instigator;
		float DamageAmount;
		struct FVector EventLocation;
		struct FVector HitLocation;
		struct FName Tag;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.DamagedActor = DamagedActor;
	parms.Instigator = Instigator;
	parms.DamageAmount = DamageAmount;
	parms.EventLocation = EventLocation;
	parms.HitLocation = HitLocation;
	parms.Tag = Tag;

	ProcessEvent(p_ReportDamageEvent, &parms);
}

void UAISense::ReportNoiseEvent(struct UObject* WorldContextObject, struct FVector NoiseLocation, float Loudness, struct AActor* Instigator, float MaxRange, struct FName Tag){

	static UObject* p_ReportNoiseEvent = UObject::FindObject<UFunction>("Function AIModule.AISense_Hearing.ReportNoiseEvent");

	struct {
		struct UObject* WorldContextObject;
		struct FVector NoiseLocation;
		float Loudness;
		struct AActor* Instigator;
		float MaxRange;
		struct FName Tag;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.NoiseLocation = NoiseLocation;
	parms.Loudness = Loudness;
	parms.Instigator = Instigator;
	parms.MaxRange = MaxRange;
	parms.Tag = Tag;

	ProcessEvent(p_ReportNoiseEvent, &parms);
}

void UAISense::RequestPawnPredictionEvent(struct APawn* Requestor, struct AActor* PredictedActor, float PredictionTime){

	static UObject* p_RequestPawnPredictionEvent = UObject::FindObject<UFunction>("Function AIModule.AISense_Prediction.RequestPawnPredictionEvent");

	struct {
		struct APawn* Requestor;
		struct AActor* PredictedActor;
		float PredictionTime;
	} parms;

	parms.Requestor = Requestor;
	parms.PredictedActor = PredictedActor;
	parms.PredictionTime = PredictionTime;

	ProcessEvent(p_RequestPawnPredictionEvent, &parms);
}

void UAISense::RequestControllerPredictionEvent(struct AAIController* Requestor, struct AActor* PredictedActor, float PredictionTime){

	static UObject* p_RequestControllerPredictionEvent = UObject::FindObject<UFunction>("Function AIModule.AISense_Prediction.RequestControllerPredictionEvent");

	struct {
		struct AAIController* Requestor;
		struct AActor* PredictedActor;
		float PredictionTime;
	} parms;

	parms.Requestor = Requestor;
	parms.PredictedActor = PredictedActor;
	parms.PredictionTime = PredictionTime;

	ProcessEvent(p_RequestControllerPredictionEvent, &parms);
}

void UBrainComponent::SetDynamicSubtree(struct FGameplayTag InjectTag, struct UBehaviorTree* BehaviorAsset){

	static UObject* p_SetDynamicSubtree = UObject::FindObject<UFunction>("Function AIModule.BehaviorTreeComponent.SetDynamicSubtree");

	struct {
		struct FGameplayTag InjectTag;
		struct UBehaviorTree* BehaviorAsset;
	} parms;

	parms.InjectTag = InjectTag;
	parms.BehaviorAsset = BehaviorAsset;

	ProcessEvent(p_SetDynamicSubtree, &parms);
}

float UBrainComponent::GetTagCooldownEndTime(struct FGameplayTag CooldownTag){

	static UObject* p_GetTagCooldownEndTime = UObject::FindObject<UFunction>("Function AIModule.BehaviorTreeComponent.GetTagCooldownEndTime");

	struct {
		struct FGameplayTag CooldownTag;
		float return_value;
	} parms;

	parms.CooldownTag = CooldownTag;

	ProcessEvent(p_GetTagCooldownEndTime, &parms);
	return parms.return_value;
}

void UBrainComponent::AddCooldownTagDuration(struct FGameplayTag CooldownTag, float CooldownDuration, bool bAddToExistingDuration){

	static UObject* p_AddCooldownTagDuration = UObject::FindObject<UFunction>("Function AIModule.BehaviorTreeComponent.AddCooldownTagDuration");

	struct {
		struct FGameplayTag CooldownTag;
		float CooldownDuration;
		bool bAddToExistingDuration;
	} parms;

	parms.CooldownTag = CooldownTag;
	parms.CooldownDuration = CooldownDuration;
	parms.bAddToExistingDuration = bAddToExistingDuration;

	ProcessEvent(p_AddCooldownTagDuration, &parms);
}

struct UAITask_MoveTo* UAITask::AIMoveTo(struct AAIController* Controller, struct FVector GoalLocation, struct AActor* GoalActor, float AcceptanceRadius, char EAIOptionFlag StopOnOverlap, char EAIOptionFlag AcceptPartialPath, bool bUsePathfinding, bool bLockAILogic, bool bUseContinuosGoalTracking, char EAIOptionFlag ProjectGoalOnNavigation){

	static UObject* p_AIMoveTo = UObject::FindObject<UFunction>("Function AIModule.AITask_MoveTo.AIMoveTo");

	struct {
		struct AAIController* Controller;
		struct FVector GoalLocation;
		struct AActor* GoalActor;
		float AcceptanceRadius;
		char EAIOptionFlag StopOnOverlap;
		char EAIOptionFlag AcceptPartialPath;
		bool bUsePathfinding;
		bool bLockAILogic;
		bool bUseContinuosGoalTracking;
		char EAIOptionFlag ProjectGoalOnNavigation;
		struct UAITask_MoveTo* return_value;
	} parms;

	parms.Controller = Controller;
	parms.GoalLocation = GoalLocation;
	parms.GoalActor = GoalActor;
	parms.AcceptanceRadius = AcceptanceRadius;
	parms.StopOnOverlap = StopOnOverlap;
	parms.AcceptPartialPath = AcceptPartialPath;
	parms.bUsePathfinding = bUsePathfinding;
	parms.bLockAILogic = bLockAILogic;
	parms.bUseContinuosGoalTracking = bUseContinuosGoalTracking;
	parms.ProjectGoalOnNavigation = ProjectGoalOnNavigation;

	ProcessEvent(p_AIMoveTo, &parms);
	return parms.return_value;
}

void UAISystemBase::AILoggingVerbose(){

	static UObject* p_AILoggingVerbose = UObject::FindObject<UFunction>("Function AIModule.AISystem.AILoggingVerbose");

	struct {
	} parms;


	ProcessEvent(p_AILoggingVerbose, &parms);
}

void UAISystemBase::AIIgnorePlayers(){

	static UObject* p_AIIgnorePlayers = UObject::FindObject<UFunction>("Function AIModule.AISystem.AIIgnorePlayers");

	struct {
	} parms;


	ProcessEvent(p_AIIgnorePlayers, &parms);
}

void UActorComponent::StopLogic(struct FString reason){

	static UObject* p_StopLogic = UObject::FindObject<UFunction>("Function AIModule.BrainComponent.StopLogic");

	struct {
		struct FString reason;
	} parms;

	parms.reason = reason;

	ProcessEvent(p_StopLogic, &parms);
}

void UActorComponent::StartLogic(){

	static UObject* p_StartLogic = UObject::FindObject<UFunction>("Function AIModule.BrainComponent.StartLogic");

	struct {
	} parms;


	ProcessEvent(p_StartLogic, &parms);
}

void UActorComponent::RestartLogic(){

	static UObject* p_RestartLogic = UObject::FindObject<UFunction>("Function AIModule.BrainComponent.RestartLogic");

	struct {
	} parms;


	ProcessEvent(p_RestartLogic, &parms);
}

bool UActorComponent::IsRunning(){

	static UObject* p_IsRunning = UObject::FindObject<UFunction>("Function AIModule.BrainComponent.IsRunning");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_IsRunning, &parms);
	return parms.return_value;
}

bool UActorComponent::IsPaused(){

	static UObject* p_IsPaused = UObject::FindObject<UFunction>("Function AIModule.BrainComponent.IsPaused");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_IsPaused, &parms);
	return parms.return_value;
}

struct UBlackboardData* UInterface::GetBlackboardAsset(){

	static UObject* p_GetBlackboardAsset = UObject::FindObject<UFunction>("Function AIModule.BlackboardAssetProvider.GetBlackboardAsset");

	struct {
		struct UBlackboardData* return_value;
	} parms;


	ProcessEvent(p_GetBlackboardAsset, &parms);
	return parms.return_value;
}

void UBlueprintFunctionLibrary::StopUsingExternalEvent(struct UBTNode* NodeOwner){

	static UObject* p_StopUsingExternalEvent = UObject::FindObject<UFunction>("Function AIModule.BTFunctionLibrary.StopUsingExternalEvent");

	struct {
		struct UBTNode* NodeOwner;
	} parms;

	parms.NodeOwner = NodeOwner;

	ProcessEvent(p_StopUsingExternalEvent, &parms);
}

void UBlueprintFunctionLibrary::StartUsingExternalEvent(struct UBTNode* NodeOwner, struct AActor* OwningActor){

	static UObject* p_StartUsingExternalEvent = UObject::FindObject<UFunction>("Function AIModule.BTFunctionLibrary.StartUsingExternalEvent");

	struct {
		struct UBTNode* NodeOwner;
		struct AActor* OwningActor;
	} parms;

	parms.NodeOwner = NodeOwner;
	parms.OwningActor = OwningActor;

	ProcessEvent(p_StartUsingExternalEvent, &parms);
}

void UBlueprintFunctionLibrary::SetBlackboardValueAsVector(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key, struct FVector Value){

	static UObject* p_SetBlackboardValueAsVector = UObject::FindObject<UFunction>("Function AIModule.BTFunctionLibrary.SetBlackboardValueAsVector");

	struct {
		struct UBTNode* NodeOwner;
		struct FBlackboardKeySelector& Key;
		struct FVector Value;
	} parms;

	parms.NodeOwner = NodeOwner;
	parms.Key = Key;
	parms.Value = Value;

	ProcessEvent(p_SetBlackboardValueAsVector, &parms);
}

void UBlueprintFunctionLibrary::SetBlackboardValueAsString(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key, struct FString Value){

	static UObject* p_SetBlackboardValueAsString = UObject::FindObject<UFunction>("Function AIModule.BTFunctionLibrary.SetBlackboardValueAsString");

	struct {
		struct UBTNode* NodeOwner;
		struct FBlackboardKeySelector& Key;
		struct FString Value;
	} parms;

	parms.NodeOwner = NodeOwner;
	parms.Key = Key;
	parms.Value = Value;

	ProcessEvent(p_SetBlackboardValueAsString, &parms);
}

void UBlueprintFunctionLibrary::SetBlackboardValueAsRotator(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key, struct FRotator Value){

	static UObject* p_SetBlackboardValueAsRotator = UObject::FindObject<UFunction>("Function AIModule.BTFunctionLibrary.SetBlackboardValueAsRotator");

	struct {
		struct UBTNode* NodeOwner;
		struct FBlackboardKeySelector& Key;
		struct FRotator Value;
	} parms;

	parms.NodeOwner = NodeOwner;
	parms.Key = Key;
	parms.Value = Value;

	ProcessEvent(p_SetBlackboardValueAsRotator, &parms);
}

void UBlueprintFunctionLibrary::SetBlackboardValueAsObject(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key, struct UObject* Value){

	static UObject* p_SetBlackboardValueAsObject = UObject::FindObject<UFunction>("Function AIModule.BTFunctionLibrary.SetBlackboardValueAsObject");

	struct {
		struct UBTNode* NodeOwner;
		struct FBlackboardKeySelector& Key;
		struct UObject* Value;
	} parms;

	parms.NodeOwner = NodeOwner;
	parms.Key = Key;
	parms.Value = Value;

	ProcessEvent(p_SetBlackboardValueAsObject, &parms);
}

void UBlueprintFunctionLibrary::SetBlackboardValueAsName(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key, struct FName Value){

	static UObject* p_SetBlackboardValueAsName = UObject::FindObject<UFunction>("Function AIModule.BTFunctionLibrary.SetBlackboardValueAsName");

	struct {
		struct UBTNode* NodeOwner;
		struct FBlackboardKeySelector& Key;
		struct FName Value;
	} parms;

	parms.NodeOwner = NodeOwner;
	parms.Key = Key;
	parms.Value = Value;

	ProcessEvent(p_SetBlackboardValueAsName, &parms);
}

void UBlueprintFunctionLibrary::SetBlackboardValueAsInt(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key, int32_t Value){

	static UObject* p_SetBlackboardValueAsInt = UObject::FindObject<UFunction>("Function AIModule.BTFunctionLibrary.SetBlackboardValueAsInt");

	struct {
		struct UBTNode* NodeOwner;
		struct FBlackboardKeySelector& Key;
		int32_t Value;
	} parms;

	parms.NodeOwner = NodeOwner;
	parms.Key = Key;
	parms.Value = Value;

	ProcessEvent(p_SetBlackboardValueAsInt, &parms);
}

void UBlueprintFunctionLibrary::SetBlackboardValueAsFloat(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key, float Value){

	static UObject* p_SetBlackboardValueAsFloat = UObject::FindObject<UFunction>("Function AIModule.BTFunctionLibrary.SetBlackboardValueAsFloat");

	struct {
		struct UBTNode* NodeOwner;
		struct FBlackboardKeySelector& Key;
		float Value;
	} parms;

	parms.NodeOwner = NodeOwner;
	parms.Key = Key;
	parms.Value = Value;

	ProcessEvent(p_SetBlackboardValueAsFloat, &parms);
}

void UBlueprintFunctionLibrary::SetBlackboardValueAsEnum(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key, char Value){

	static UObject* p_SetBlackboardValueAsEnum = UObject::FindObject<UFunction>("Function AIModule.BTFunctionLibrary.SetBlackboardValueAsEnum");

	struct {
		struct UBTNode* NodeOwner;
		struct FBlackboardKeySelector& Key;
		char Value;
	} parms;

	parms.NodeOwner = NodeOwner;
	parms.Key = Key;
	parms.Value = Value;

	ProcessEvent(p_SetBlackboardValueAsEnum, &parms);
}

void UBlueprintFunctionLibrary::SetBlackboardValueAsClass(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key, UObject* Value){

	static UObject* p_SetBlackboardValueAsClass = UObject::FindObject<UFunction>("Function AIModule.BTFunctionLibrary.SetBlackboardValueAsClass");

	struct {
		struct UBTNode* NodeOwner;
		struct FBlackboardKeySelector& Key;
		UObject* Value;
	} parms;

	parms.NodeOwner = NodeOwner;
	parms.Key = Key;
	parms.Value = Value;

	ProcessEvent(p_SetBlackboardValueAsClass, &parms);
}

void UBlueprintFunctionLibrary::SetBlackboardValueAsBool(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key, bool Value){

	static UObject* p_SetBlackboardValueAsBool = UObject::FindObject<UFunction>("Function AIModule.BTFunctionLibrary.SetBlackboardValueAsBool");

	struct {
		struct UBTNode* NodeOwner;
		struct FBlackboardKeySelector& Key;
		bool Value;
	} parms;

	parms.NodeOwner = NodeOwner;
	parms.Key = Key;
	parms.Value = Value;

	ProcessEvent(p_SetBlackboardValueAsBool, &parms);
}

struct UBlackboardComponent* UBlueprintFunctionLibrary::GetOwnersBlackboard(struct UBTNode* NodeOwner){

	static UObject* p_GetOwnersBlackboard = UObject::FindObject<UFunction>("Function AIModule.BTFunctionLibrary.GetOwnersBlackboard");

	struct {
		struct UBTNode* NodeOwner;
		struct UBlackboardComponent* return_value;
	} parms;

	parms.NodeOwner = NodeOwner;

	ProcessEvent(p_GetOwnersBlackboard, &parms);
	return parms.return_value;
}

struct UBehaviorTreeComponent* UBlueprintFunctionLibrary::GetOwnerComponent(struct UBTNode* NodeOwner){

	static UObject* p_GetOwnerComponent = UObject::FindObject<UFunction>("Function AIModule.BTFunctionLibrary.GetOwnerComponent");

	struct {
		struct UBTNode* NodeOwner;
		struct UBehaviorTreeComponent* return_value;
	} parms;

	parms.NodeOwner = NodeOwner;

	ProcessEvent(p_GetOwnerComponent, &parms);
	return parms.return_value;
}

struct FVector UBlueprintFunctionLibrary::GetBlackboardValueAsVector(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key){

	static UObject* p_GetBlackboardValueAsVector = UObject::FindObject<UFunction>("Function AIModule.BTFunctionLibrary.GetBlackboardValueAsVector");

	struct {
		struct UBTNode* NodeOwner;
		struct FBlackboardKeySelector& Key;
		struct FVector return_value;
	} parms;

	parms.NodeOwner = NodeOwner;
	parms.Key = Key;

	ProcessEvent(p_GetBlackboardValueAsVector, &parms);
	return parms.return_value;
}

struct FString UBlueprintFunctionLibrary::GetBlackboardValueAsString(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key){

	static UObject* p_GetBlackboardValueAsString = UObject::FindObject<UFunction>("Function AIModule.BTFunctionLibrary.GetBlackboardValueAsString");

	struct {
		struct UBTNode* NodeOwner;
		struct FBlackboardKeySelector& Key;
		struct FString return_value;
	} parms;

	parms.NodeOwner = NodeOwner;
	parms.Key = Key;

	ProcessEvent(p_GetBlackboardValueAsString, &parms);
	return parms.return_value;
}

struct FRotator UBlueprintFunctionLibrary::GetBlackboardValueAsRotator(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key){

	static UObject* p_GetBlackboardValueAsRotator = UObject::FindObject<UFunction>("Function AIModule.BTFunctionLibrary.GetBlackboardValueAsRotator");

	struct {
		struct UBTNode* NodeOwner;
		struct FBlackboardKeySelector& Key;
		struct FRotator return_value;
	} parms;

	parms.NodeOwner = NodeOwner;
	parms.Key = Key;

	ProcessEvent(p_GetBlackboardValueAsRotator, &parms);
	return parms.return_value;
}

struct UObject* UBlueprintFunctionLibrary::GetBlackboardValueAsObject(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key){

	static UObject* p_GetBlackboardValueAsObject = UObject::FindObject<UFunction>("Function AIModule.BTFunctionLibrary.GetBlackboardValueAsObject");

	struct {
		struct UBTNode* NodeOwner;
		struct FBlackboardKeySelector& Key;
		struct UObject* return_value;
	} parms;

	parms.NodeOwner = NodeOwner;
	parms.Key = Key;

	ProcessEvent(p_GetBlackboardValueAsObject, &parms);
	return parms.return_value;
}

struct FName UBlueprintFunctionLibrary::GetBlackboardValueAsName(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key){

	static UObject* p_GetBlackboardValueAsName = UObject::FindObject<UFunction>("Function AIModule.BTFunctionLibrary.GetBlackboardValueAsName");

	struct {
		struct UBTNode* NodeOwner;
		struct FBlackboardKeySelector& Key;
		struct FName return_value;
	} parms;

	parms.NodeOwner = NodeOwner;
	parms.Key = Key;

	ProcessEvent(p_GetBlackboardValueAsName, &parms);
	return parms.return_value;
}

int32_t UBlueprintFunctionLibrary::GetBlackboardValueAsInt(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key){

	static UObject* p_GetBlackboardValueAsInt = UObject::FindObject<UFunction>("Function AIModule.BTFunctionLibrary.GetBlackboardValueAsInt");

	struct {
		struct UBTNode* NodeOwner;
		struct FBlackboardKeySelector& Key;
		int32_t return_value;
	} parms;

	parms.NodeOwner = NodeOwner;
	parms.Key = Key;

	ProcessEvent(p_GetBlackboardValueAsInt, &parms);
	return parms.return_value;
}

float UBlueprintFunctionLibrary::GetBlackboardValueAsFloat(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key){

	static UObject* p_GetBlackboardValueAsFloat = UObject::FindObject<UFunction>("Function AIModule.BTFunctionLibrary.GetBlackboardValueAsFloat");

	struct {
		struct UBTNode* NodeOwner;
		struct FBlackboardKeySelector& Key;
		float return_value;
	} parms;

	parms.NodeOwner = NodeOwner;
	parms.Key = Key;

	ProcessEvent(p_GetBlackboardValueAsFloat, &parms);
	return parms.return_value;
}

char UBlueprintFunctionLibrary::GetBlackboardValueAsEnum(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key){

	static UObject* p_GetBlackboardValueAsEnum = UObject::FindObject<UFunction>("Function AIModule.BTFunctionLibrary.GetBlackboardValueAsEnum");

	struct {
		struct UBTNode* NodeOwner;
		struct FBlackboardKeySelector& Key;
		char return_value;
	} parms;

	parms.NodeOwner = NodeOwner;
	parms.Key = Key;

	ProcessEvent(p_GetBlackboardValueAsEnum, &parms);
	return parms.return_value;
}

UObject* UBlueprintFunctionLibrary::GetBlackboardValueAsClass(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key){

	static UObject* p_GetBlackboardValueAsClass = UObject::FindObject<UFunction>("Function AIModule.BTFunctionLibrary.GetBlackboardValueAsClass");

	struct {
		struct UBTNode* NodeOwner;
		struct FBlackboardKeySelector& Key;
		UObject* return_value;
	} parms;

	parms.NodeOwner = NodeOwner;
	parms.Key = Key;

	ProcessEvent(p_GetBlackboardValueAsClass, &parms);
	return parms.return_value;
}

bool UBlueprintFunctionLibrary::GetBlackboardValueAsBool(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key){

	static UObject* p_GetBlackboardValueAsBool = UObject::FindObject<UFunction>("Function AIModule.BTFunctionLibrary.GetBlackboardValueAsBool");

	struct {
		struct UBTNode* NodeOwner;
		struct FBlackboardKeySelector& Key;
		bool return_value;
	} parms;

	parms.NodeOwner = NodeOwner;
	parms.Key = Key;

	ProcessEvent(p_GetBlackboardValueAsBool, &parms);
	return parms.return_value;
}

struct AActor* UBlueprintFunctionLibrary::GetBlackboardValueAsActor(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key){

	static UObject* p_GetBlackboardValueAsActor = UObject::FindObject<UFunction>("Function AIModule.BTFunctionLibrary.GetBlackboardValueAsActor");

	struct {
		struct UBTNode* NodeOwner;
		struct FBlackboardKeySelector& Key;
		struct AActor* return_value;
	} parms;

	parms.NodeOwner = NodeOwner;
	parms.Key = Key;

	ProcessEvent(p_GetBlackboardValueAsActor, &parms);
	return parms.return_value;
}

void UBlueprintFunctionLibrary::ClearBlackboardValueAsVector(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key){

	static UObject* p_ClearBlackboardValueAsVector = UObject::FindObject<UFunction>("Function AIModule.BTFunctionLibrary.ClearBlackboardValueAsVector");

	struct {
		struct UBTNode* NodeOwner;
		struct FBlackboardKeySelector& Key;
	} parms;

	parms.NodeOwner = NodeOwner;
	parms.Key = Key;

	ProcessEvent(p_ClearBlackboardValueAsVector, &parms);
}

void UBlueprintFunctionLibrary::ClearBlackboardValue(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key){

	static UObject* p_ClearBlackboardValue = UObject::FindObject<UFunction>("Function AIModule.BTFunctionLibrary.ClearBlackboardValue");

	struct {
		struct UBTNode* NodeOwner;
		struct FBlackboardKeySelector& Key;
	} parms;

	parms.NodeOwner = NodeOwner;
	parms.Key = Key;

	ProcessEvent(p_ClearBlackboardValue, &parms);
}

void UBTService::ReceiveTickAI(struct AAIController* OwnerController, struct APawn* ControlledPawn, float DeltaSeconds){

	static UObject* p_ReceiveTickAI = UObject::FindObject<UFunction>("Function AIModule.BTService_BlueprintBase.ReceiveTickAI");

	struct {
		struct AAIController* OwnerController;
		struct APawn* ControlledPawn;
		float DeltaSeconds;
	} parms;

	parms.OwnerController = OwnerController;
	parms.ControlledPawn = ControlledPawn;
	parms.DeltaSeconds = DeltaSeconds;

	ProcessEvent(p_ReceiveTickAI, &parms);
}

void UBTService::ReceiveTick(struct AActor* OwnerActor, float DeltaSeconds){

	static UObject* p_ReceiveTick = UObject::FindObject<UFunction>("Function AIModule.BTService_BlueprintBase.ReceiveTick");

	struct {
		struct AActor* OwnerActor;
		float DeltaSeconds;
	} parms;

	parms.OwnerActor = OwnerActor;
	parms.DeltaSeconds = DeltaSeconds;

	ProcessEvent(p_ReceiveTick, &parms);
}

void UBTService::ReceiveSearchStartAI(struct AAIController* OwnerController, struct APawn* ControlledPawn){

	static UObject* p_ReceiveSearchStartAI = UObject::FindObject<UFunction>("Function AIModule.BTService_BlueprintBase.ReceiveSearchStartAI");

	struct {
		struct AAIController* OwnerController;
		struct APawn* ControlledPawn;
	} parms;

	parms.OwnerController = OwnerController;
	parms.ControlledPawn = ControlledPawn;

	ProcessEvent(p_ReceiveSearchStartAI, &parms);
}

void UBTService::ReceiveSearchStart(struct AActor* OwnerActor){

	static UObject* p_ReceiveSearchStart = UObject::FindObject<UFunction>("Function AIModule.BTService_BlueprintBase.ReceiveSearchStart");

	struct {
		struct AActor* OwnerActor;
	} parms;

	parms.OwnerActor = OwnerActor;

	ProcessEvent(p_ReceiveSearchStart, &parms);
}

void UBTService::ReceiveDeactivationAI(struct AAIController* OwnerController, struct APawn* ControlledPawn){

	static UObject* p_ReceiveDeactivationAI = UObject::FindObject<UFunction>("Function AIModule.BTService_BlueprintBase.ReceiveDeactivationAI");

	struct {
		struct AAIController* OwnerController;
		struct APawn* ControlledPawn;
	} parms;

	parms.OwnerController = OwnerController;
	parms.ControlledPawn = ControlledPawn;

	ProcessEvent(p_ReceiveDeactivationAI, &parms);
}

void UBTService::ReceiveDeactivation(struct AActor* OwnerActor){

	static UObject* p_ReceiveDeactivation = UObject::FindObject<UFunction>("Function AIModule.BTService_BlueprintBase.ReceiveDeactivation");

	struct {
		struct AActor* OwnerActor;
	} parms;

	parms.OwnerActor = OwnerActor;

	ProcessEvent(p_ReceiveDeactivation, &parms);
}

void UBTService::ReceiveActivationAI(struct AAIController* OwnerController, struct APawn* ControlledPawn){

	static UObject* p_ReceiveActivationAI = UObject::FindObject<UFunction>("Function AIModule.BTService_BlueprintBase.ReceiveActivationAI");

	struct {
		struct AAIController* OwnerController;
		struct APawn* ControlledPawn;
	} parms;

	parms.OwnerController = OwnerController;
	parms.ControlledPawn = ControlledPawn;

	ProcessEvent(p_ReceiveActivationAI, &parms);
}

void UBTService::ReceiveActivation(struct AActor* OwnerActor){

	static UObject* p_ReceiveActivation = UObject::FindObject<UFunction>("Function AIModule.BTService_BlueprintBase.ReceiveActivation");

	struct {
		struct AActor* OwnerActor;
	} parms;

	parms.OwnerActor = OwnerActor;

	ProcessEvent(p_ReceiveActivation, &parms);
}

bool UBTService::IsServiceActive(){

	static UObject* p_IsServiceActive = UObject::FindObject<UFunction>("Function AIModule.BTService_BlueprintBase.IsServiceActive");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_IsServiceActive, &parms);
	return parms.return_value;
}

void UBTTaskNode::SetFinishOnMessageWithId(struct FName MessageName, int32_t RequestID){

	static UObject* p_SetFinishOnMessageWithId = UObject::FindObject<UFunction>("Function AIModule.BTTask_BlueprintBase.SetFinishOnMessageWithId");

	struct {
		struct FName MessageName;
		int32_t RequestID;
	} parms;

	parms.MessageName = MessageName;
	parms.RequestID = RequestID;

	ProcessEvent(p_SetFinishOnMessageWithId, &parms);
}

void UBTTaskNode::SetFinishOnMessage(struct FName MessageName){

	static UObject* p_SetFinishOnMessage = UObject::FindObject<UFunction>("Function AIModule.BTTask_BlueprintBase.SetFinishOnMessage");

	struct {
		struct FName MessageName;
	} parms;

	parms.MessageName = MessageName;

	ProcessEvent(p_SetFinishOnMessage, &parms);
}

void UBTTaskNode::ReceiveTickAI(struct AAIController* OwnerController, struct APawn* ControlledPawn, float DeltaSeconds){

	static UObject* p_ReceiveTickAI = UObject::FindObject<UFunction>("Function AIModule.BTTask_BlueprintBase.ReceiveTickAI");

	struct {
		struct AAIController* OwnerController;
		struct APawn* ControlledPawn;
		float DeltaSeconds;
	} parms;

	parms.OwnerController = OwnerController;
	parms.ControlledPawn = ControlledPawn;
	parms.DeltaSeconds = DeltaSeconds;

	ProcessEvent(p_ReceiveTickAI, &parms);
}

void UBTTaskNode::ReceiveTick(struct AActor* OwnerActor, float DeltaSeconds){

	static UObject* p_ReceiveTick = UObject::FindObject<UFunction>("Function AIModule.BTTask_BlueprintBase.ReceiveTick");

	struct {
		struct AActor* OwnerActor;
		float DeltaSeconds;
	} parms;

	parms.OwnerActor = OwnerActor;
	parms.DeltaSeconds = DeltaSeconds;

	ProcessEvent(p_ReceiveTick, &parms);
}

void UBTTaskNode::ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn){

	static UObject* p_ReceiveExecuteAI = UObject::FindObject<UFunction>("Function AIModule.BTTask_BlueprintBase.ReceiveExecuteAI");

	struct {
		struct AAIController* OwnerController;
		struct APawn* ControlledPawn;
	} parms;

	parms.OwnerController = OwnerController;
	parms.ControlledPawn = ControlledPawn;

	ProcessEvent(p_ReceiveExecuteAI, &parms);
}

void UBTTaskNode::ReceiveExecute(struct AActor* OwnerActor){

	static UObject* p_ReceiveExecute = UObject::FindObject<UFunction>("Function AIModule.BTTask_BlueprintBase.ReceiveExecute");

	struct {
		struct AActor* OwnerActor;
	} parms;

	parms.OwnerActor = OwnerActor;

	ProcessEvent(p_ReceiveExecute, &parms);
}

void UBTTaskNode::ReceiveAbortAI(struct AAIController* OwnerController, struct APawn* ControlledPawn){

	static UObject* p_ReceiveAbortAI = UObject::FindObject<UFunction>("Function AIModule.BTTask_BlueprintBase.ReceiveAbortAI");

	struct {
		struct AAIController* OwnerController;
		struct APawn* ControlledPawn;
	} parms;

	parms.OwnerController = OwnerController;
	parms.ControlledPawn = ControlledPawn;

	ProcessEvent(p_ReceiveAbortAI, &parms);
}

void UBTTaskNode::ReceiveAbort(struct AActor* OwnerActor){

	static UObject* p_ReceiveAbort = UObject::FindObject<UFunction>("Function AIModule.BTTask_BlueprintBase.ReceiveAbort");

	struct {
		struct AActor* OwnerActor;
	} parms;

	parms.OwnerActor = OwnerActor;

	ProcessEvent(p_ReceiveAbort, &parms);
}

bool UBTTaskNode::IsTaskExecuting(){

	static UObject* p_IsTaskExecuting = UObject::FindObject<UFunction>("Function AIModule.BTTask_BlueprintBase.IsTaskExecuting");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_IsTaskExecuting, &parms);
	return parms.return_value;
}

bool UBTTaskNode::IsTaskAborting(){

	static UObject* p_IsTaskAborting = UObject::FindObject<UFunction>("Function AIModule.BTTask_BlueprintBase.IsTaskAborting");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_IsTaskAborting, &parms);
	return parms.return_value;
}

void UBTTaskNode::FinishExecute(bool bSuccess){

	static UObject* p_FinishExecute = UObject::FindObject<UFunction>("Function AIModule.BTTask_BlueprintBase.FinishExecute");

	struct {
		bool bSuccess;
	} parms;

	parms.bSuccess = bSuccess;

	ProcessEvent(p_FinishExecute, &parms);
}

void UBTTaskNode::FinishAbort(){

	static UObject* p_FinishAbort = UObject::FindObject<UFunction>("Function AIModule.BTTask_BlueprintBase.FinishAbort");

	struct {
	} parms;


	ProcessEvent(p_FinishAbort, &parms);
}

void UObject::SetNamedParam(struct FName ParamName, float Value){

	static UObject* p_SetNamedParam = UObject::FindObject<UFunction>("Function AIModule.EnvQueryInstanceBlueprintWrapper.SetNamedParam");

	struct {
		struct FName ParamName;
		float Value;
	} parms;

	parms.ParamName = ParamName;
	parms.Value = Value;

	ProcessEvent(p_SetNamedParam, &parms);
}

struct TArray<struct FVector> UObject::GetResultsAsLocations(){

	static UObject* p_GetResultsAsLocations = UObject::FindObject<UFunction>("Function AIModule.EnvQueryInstanceBlueprintWrapper.GetResultsAsLocations");

	struct {
		struct TArray<struct FVector> return_value;
	} parms;


	ProcessEvent(p_GetResultsAsLocations, &parms);
	return parms.return_value;
}

struct TArray<struct AActor*> UObject::GetResultsAsActors(){

	static UObject* p_GetResultsAsActors = UObject::FindObject<UFunction>("Function AIModule.EnvQueryInstanceBlueprintWrapper.GetResultsAsActors");

	struct {
		struct TArray<struct AActor*> return_value;
	} parms;


	ProcessEvent(p_GetResultsAsActors, &parms);
	return parms.return_value;
}

bool UObject::GetQueryResultsAsLocations(struct TArray<struct FVector>& ResultLocations){

	static UObject* p_GetQueryResultsAsLocations = UObject::FindObject<UFunction>("Function AIModule.EnvQueryInstanceBlueprintWrapper.GetQueryResultsAsLocations");

	struct {
		struct TArray<struct FVector>& ResultLocations;
		bool return_value;
	} parms;

	parms.ResultLocations = ResultLocations;

	ProcessEvent(p_GetQueryResultsAsLocations, &parms);
	return parms.return_value;
}

bool UObject::GetQueryResultsAsActors(struct TArray<struct AActor*>& ResultActors){

	static UObject* p_GetQueryResultsAsActors = UObject::FindObject<UFunction>("Function AIModule.EnvQueryInstanceBlueprintWrapper.GetQueryResultsAsActors");

	struct {
		struct TArray<struct AActor*>& ResultActors;
		bool return_value;
	} parms;

	parms.ResultActors = ResultActors;

	ProcessEvent(p_GetQueryResultsAsActors, &parms);
	return parms.return_value;
}

float UObject::GetItemScore(int32_t ItemIndex){

	static UObject* p_GetItemScore = UObject::FindObject<UFunction>("Function AIModule.EnvQueryInstanceBlueprintWrapper.GetItemScore");

	struct {
		int32_t ItemIndex;
		float return_value;
	} parms;

	parms.ItemIndex = ItemIndex;

	ProcessEvent(p_GetItemScore, &parms);
	return parms.return_value;
}

void UObject::EQSQueryDoneSignature__DelegateSignature(struct UEnvQueryInstanceBlueprintWrapper* QueryInstance, char EEnvQueryStatus QueryStatus){

	static UObject* p_EQSQueryDoneSignature__DelegateSignature = UObject::FindObject<UFunction>("DelegateFunction AIModule.EnvQueryInstanceBlueprintWrapper.EQSQueryDoneSignature__DelegateSignature");

	struct {
		struct UEnvQueryInstanceBlueprintWrapper* QueryInstance;
		char EEnvQueryStatus QueryStatus;
	} parms;

	parms.QueryInstance = QueryInstance;
	parms.QueryStatus = QueryStatus;

	ProcessEvent(p_EQSQueryDoneSignature__DelegateSignature, &parms);
}

void UActorComponent::OnNavDataRegistered(struct ANavigationData* NavData){

	static UObject* p_OnNavDataRegistered = UObject::FindObject<UFunction>("Function AIModule.PathFollowingComponent.OnNavDataRegistered");

	struct {
		struct ANavigationData* NavData;
	} parms;

	parms.NavData = NavData;

	ProcessEvent(p_OnNavDataRegistered, &parms);
}

void UActorComponent::OnActorBump(struct AActor* SelfActor, struct AActor* OtherActor, struct FVector NormalImpulse, struct FHitResult& Hit){

	static UObject* p_OnActorBump = UObject::FindObject<UFunction>("Function AIModule.PathFollowingComponent.OnActorBump");

	struct {
		struct AActor* SelfActor;
		struct AActor* OtherActor;
		struct FVector NormalImpulse;
		struct FHitResult& Hit;
	} parms;

	parms.SelfActor = SelfActor;
	parms.OtherActor = OtherActor;
	parms.NormalImpulse = NormalImpulse;
	parms.Hit = Hit;

	ProcessEvent(p_OnActorBump, &parms);
}

struct FVector UActorComponent::GetPathDestination(){

	static UObject* p_GetPathDestination = UObject::FindObject<UFunction>("Function AIModule.PathFollowingComponent.GetPathDestination");

	struct {
		struct FVector return_value;
	} parms;


	ProcessEvent(p_GetPathDestination, &parms);
	return parms.return_value;
}

char EPathFollowingAction UActorComponent::GetPathActionType(){

	static UObject* p_GetPathActionType = UObject::FindObject<UFunction>("Function AIModule.PathFollowingComponent.GetPathActionType");

	struct {
		char EPathFollowingAction return_value;
	} parms;


	ProcessEvent(p_GetPathActionType, &parms);
	return parms.return_value;
}

void UPathFollowingComponent::SuspendCrowdSteering(bool bSuspend){

	static UObject* p_SuspendCrowdSteering = UObject::FindObject<UFunction>("Function AIModule.CrowdFollowingComponent.SuspendCrowdSteering");

	struct {
		bool bSuspend;
	} parms;

	parms.bSuspend = bSuspend;

	ProcessEvent(p_SuspendCrowdSteering, &parms);
}

void UEnvQueryContext::ProvideSingleLocation(struct UObject* QuerierObject, struct AActor* QuerierActor, struct FVector& ResultingLocation){

	static UObject* p_ProvideSingleLocation = UObject::FindObject<UFunction>("Function AIModule.EnvQueryContext_BlueprintBase.ProvideSingleLocation");

	struct {
		struct UObject* QuerierObject;
		struct AActor* QuerierActor;
		struct FVector& ResultingLocation;
	} parms;

	parms.QuerierObject = QuerierObject;
	parms.QuerierActor = QuerierActor;
	parms.ResultingLocation = ResultingLocation;

	ProcessEvent(p_ProvideSingleLocation, &parms);
}

void UEnvQueryContext::ProvideSingleActor(struct UObject* QuerierObject, struct AActor* QuerierActor, struct AActor*& ResultingActor){

	static UObject* p_ProvideSingleActor = UObject::FindObject<UFunction>("Function AIModule.EnvQueryContext_BlueprintBase.ProvideSingleActor");

	struct {
		struct UObject* QuerierObject;
		struct AActor* QuerierActor;
		struct AActor*& ResultingActor;
	} parms;

	parms.QuerierObject = QuerierObject;
	parms.QuerierActor = QuerierActor;
	parms.ResultingActor = ResultingActor;

	ProcessEvent(p_ProvideSingleActor, &parms);
}

void UEnvQueryContext::ProvideLocationsSet(struct UObject* QuerierObject, struct AActor* QuerierActor, struct TArray<struct FVector>& ResultingLocationSet){

	static UObject* p_ProvideLocationsSet = UObject::FindObject<UFunction>("Function AIModule.EnvQueryContext_BlueprintBase.ProvideLocationsSet");

	struct {
		struct UObject* QuerierObject;
		struct AActor* QuerierActor;
		struct TArray<struct FVector>& ResultingLocationSet;
	} parms;

	parms.QuerierObject = QuerierObject;
	parms.QuerierActor = QuerierActor;
	parms.ResultingLocationSet = ResultingLocationSet;

	ProcessEvent(p_ProvideLocationsSet, &parms);
}

void UEnvQueryContext::ProvideActorsSet(struct UObject* QuerierObject, struct AActor* QuerierActor, struct TArray<struct AActor*>& ResultingActorsSet){

	static UObject* p_ProvideActorsSet = UObject::FindObject<UFunction>("Function AIModule.EnvQueryContext_BlueprintBase.ProvideActorsSet");

	struct {
		struct UObject* QuerierObject;
		struct AActor* QuerierActor;
		struct TArray<struct AActor*>& ResultingActorsSet;
	} parms;

	parms.QuerierObject = QuerierObject;
	parms.QuerierActor = QuerierActor;
	parms.ResultingActorsSet = ResultingActorsSet;

	ProcessEvent(p_ProvideActorsSet, &parms);
}

struct UObject* UEnvQueryGenerator::GetQuerier(){

	static UObject* p_GetQuerier = UObject::FindObject<UFunction>("Function AIModule.EnvQueryGenerator_BlueprintBase.GetQuerier");

	struct {
		struct UObject* return_value;
	} parms;


	ProcessEvent(p_GetQuerier, &parms);
	return parms.return_value;
}

void UEnvQueryGenerator::DoItemGeneration(struct TArray<struct FVector>& ContextLocations){

	static UObject* p_DoItemGeneration = UObject::FindObject<UFunction>("Function AIModule.EnvQueryGenerator_BlueprintBase.DoItemGeneration");

	struct {
		struct TArray<struct FVector>& ContextLocations;
	} parms;

	parms.ContextLocations = ContextLocations;

	ProcessEvent(p_DoItemGeneration, &parms);
}

void UEnvQueryGenerator::AddGeneratedVector(struct FVector GeneratedVector){

	static UObject* p_AddGeneratedVector = UObject::FindObject<UFunction>("Function AIModule.EnvQueryGenerator_BlueprintBase.AddGeneratedVector");

	struct {
		struct FVector GeneratedVector;
	} parms;

	parms.GeneratedVector = GeneratedVector;

	ProcessEvent(p_AddGeneratedVector, &parms);
}

void UEnvQueryGenerator::AddGeneratedActor(struct AActor* GeneratedActor){

	static UObject* p_AddGeneratedActor = UObject::FindObject<UFunction>("Function AIModule.EnvQueryGenerator_BlueprintBase.AddGeneratedActor");

	struct {
		struct AActor* GeneratedActor;
	} parms;

	parms.GeneratedActor = GeneratedActor;

	ProcessEvent(p_AddGeneratedActor, &parms);
}

struct UEnvQueryInstanceBlueprintWrapper* UAISubsystem::RunEQSQuery(struct UObject* WorldContextObject, struct UEnvQuery* QueryTemplate, struct UObject* Querier, char EEnvQueryRunMode RunMode, UEnvQueryInstanceBlueprintWrapper* WrapperClass){

	static UObject* p_RunEQSQuery = UObject::FindObject<UFunction>("Function AIModule.EnvQueryManager.RunEQSQuery");

	struct {
		struct UObject* WorldContextObject;
		struct UEnvQuery* QueryTemplate;
		struct UObject* Querier;
		char EEnvQueryRunMode RunMode;
		UEnvQueryInstanceBlueprintWrapper* WrapperClass;
		struct UEnvQueryInstanceBlueprintWrapper* return_value;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.QueryTemplate = QueryTemplate;
	parms.Querier = Querier;
	parms.RunMode = RunMode;
	parms.WrapperClass = WrapperClass;

	ProcessEvent(p_RunEQSQuery, &parms);
	return parms.return_value;
}

void AActor::SetSmartLinkEnabled(bool bEnabled){

	static UObject* p_SetSmartLinkEnabled = UObject::FindObject<UFunction>("Function AIModule.NavLinkProxy.SetSmartLinkEnabled");

	struct {
		bool bEnabled;
	} parms;

	parms.bEnabled = bEnabled;

	ProcessEvent(p_SetSmartLinkEnabled, &parms);
}

void AActor::ResumePathFollowing(struct AActor* Agent){

	static UObject* p_ResumePathFollowing = UObject::FindObject<UFunction>("Function AIModule.NavLinkProxy.ResumePathFollowing");

	struct {
		struct AActor* Agent;
	} parms;

	parms.Agent = Agent;

	ProcessEvent(p_ResumePathFollowing, &parms);
}

void AActor::ReceiveSmartLinkReached(struct AActor* Agent, struct FVector& Destination){

	static UObject* p_ReceiveSmartLinkReached = UObject::FindObject<UFunction>("Function AIModule.NavLinkProxy.ReceiveSmartLinkReached");

	struct {
		struct AActor* Agent;
		struct FVector& Destination;
	} parms;

	parms.Agent = Agent;
	parms.Destination = Destination;

	ProcessEvent(p_ReceiveSmartLinkReached, &parms);
}

bool AActor::IsSmartLinkEnabled(){

	static UObject* p_IsSmartLinkEnabled = UObject::FindObject<UFunction>("Function AIModule.NavLinkProxy.IsSmartLinkEnabled");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_IsSmartLinkEnabled, &parms);
	return parms.return_value;
}

bool AActor::HasMovingAgents(){

	static UObject* p_HasMovingAgents = UObject::FindObject<UFunction>("Function AIModule.NavLinkProxy.HasMovingAgents");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_HasMovingAgents, &parms);
	return parms.return_value;
}

bool UObject::SetLocalNavigationGridDensity(struct UObject* WorldContextObject, float CellSize){

	static UObject* p_SetLocalNavigationGridDensity = UObject::FindObject<UFunction>("Function AIModule.NavLocalGridManager.SetLocalNavigationGridDensity");

	struct {
		struct UObject* WorldContextObject;
		float CellSize;
		bool return_value;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.CellSize = CellSize;

	ProcessEvent(p_SetLocalNavigationGridDensity, &parms);
	return parms.return_value;
}

void UObject::RemoveLocalNavigationGrid(struct UObject* WorldContextObject, int32_t GridId, bool bRebuildGrids){

	static UObject* p_RemoveLocalNavigationGrid = UObject::FindObject<UFunction>("Function AIModule.NavLocalGridManager.RemoveLocalNavigationGrid");

	struct {
		struct UObject* WorldContextObject;
		int32_t GridId;
		bool bRebuildGrids;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.GridId = GridId;
	parms.bRebuildGrids = bRebuildGrids;

	ProcessEvent(p_RemoveLocalNavigationGrid, &parms);
}

bool UObject::FindLocalNavigationGridPath(struct UObject* WorldContextObject, struct FVector& Start, struct FVector& End, struct TArray<struct FVector>& PathPoints){

	static UObject* p_FindLocalNavigationGridPath = UObject::FindObject<UFunction>("Function AIModule.NavLocalGridManager.FindLocalNavigationGridPath");

	struct {
		struct UObject* WorldContextObject;
		struct FVector& Start;
		struct FVector& End;
		struct TArray<struct FVector>& PathPoints;
		bool return_value;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.Start = Start;
	parms.End = End;
	parms.PathPoints = PathPoints;

	ProcessEvent(p_FindLocalNavigationGridPath, &parms);
	return parms.return_value;
}

int32_t UObject::AddLocalNavigationGridForPoints(struct UObject* WorldContextObject, struct TArray<struct FVector>& Locations, int32_t Radius2D, float Height, bool bRebuildGrids){

	static UObject* p_AddLocalNavigationGridForPoints = UObject::FindObject<UFunction>("Function AIModule.NavLocalGridManager.AddLocalNavigationGridForPoints");

	struct {
		struct UObject* WorldContextObject;
		struct TArray<struct FVector>& Locations;
		int32_t Radius2D;
		float Height;
		bool bRebuildGrids;
		int32_t return_value;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.Locations = Locations;
	parms.Radius2D = Radius2D;
	parms.Height = Height;
	parms.bRebuildGrids = bRebuildGrids;

	ProcessEvent(p_AddLocalNavigationGridForPoints, &parms);
	return parms.return_value;
}

int32_t UObject::AddLocalNavigationGridForPoint(struct UObject* WorldContextObject, struct FVector& Location, int32_t Radius2D, float Height, bool bRebuildGrids){

	static UObject* p_AddLocalNavigationGridForPoint = UObject::FindObject<UFunction>("Function AIModule.NavLocalGridManager.AddLocalNavigationGridForPoint");

	struct {
		struct UObject* WorldContextObject;
		struct FVector& Location;
		int32_t Radius2D;
		float Height;
		bool bRebuildGrids;
		int32_t return_value;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.Location = Location;
	parms.Radius2D = Radius2D;
	parms.Height = Height;
	parms.bRebuildGrids = bRebuildGrids;

	ProcessEvent(p_AddLocalNavigationGridForPoint, &parms);
	return parms.return_value;
}

int32_t UObject::AddLocalNavigationGridForCapsule(struct UObject* WorldContextObject, struct FVector& Location, float CapsuleRadius, float CapsuleHalfHeight, int32_t Radius2D, float Height, bool bRebuildGrids){

	static UObject* p_AddLocalNavigationGridForCapsule = UObject::FindObject<UFunction>("Function AIModule.NavLocalGridManager.AddLocalNavigationGridForCapsule");

	struct {
		struct UObject* WorldContextObject;
		struct FVector& Location;
		float CapsuleRadius;
		float CapsuleHalfHeight;
		int32_t Radius2D;
		float Height;
		bool bRebuildGrids;
		int32_t return_value;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.Location = Location;
	parms.CapsuleRadius = CapsuleRadius;
	parms.CapsuleHalfHeight = CapsuleHalfHeight;
	parms.Radius2D = Radius2D;
	parms.Height = Height;
	parms.bRebuildGrids = bRebuildGrids;

	ProcessEvent(p_AddLocalNavigationGridForCapsule, &parms);
	return parms.return_value;
}

int32_t UObject::AddLocalNavigationGridForBox(struct UObject* WorldContextObject, struct FVector& Location, struct FVector Extent, struct FRotator Rotation, int32_t Radius2D, float Height, bool bRebuildGrids){

	static UObject* p_AddLocalNavigationGridForBox = UObject::FindObject<UFunction>("Function AIModule.NavLocalGridManager.AddLocalNavigationGridForBox");

	struct {
		struct UObject* WorldContextObject;
		struct FVector& Location;
		struct FVector Extent;
		struct FRotator Rotation;
		int32_t Radius2D;
		float Height;
		bool bRebuildGrids;
		int32_t return_value;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.Location = Location;
	parms.Extent = Extent;
	parms.Rotation = Rotation;
	parms.Radius2D = Radius2D;
	parms.Height = Height;
	parms.bRebuildGrids = bRebuildGrids;

	ProcessEvent(p_AddLocalNavigationGridForBox, &parms);
	return parms.return_value;
}

char EAIRequestPriority UObject::GetActionPriority(){

	static UObject* p_GetActionPriority = UObject::FindObject<UFunction>("Function AIModule.PawnAction.GetActionPriority");

	struct {
		char EAIRequestPriority return_value;
	} parms;


	ProcessEvent(p_GetActionPriority, &parms);
	return parms.return_value;
}

void UObject::Finish(char EPawnActionResult WithResult){

	static UObject* p_Finish = UObject::FindObject<UFunction>("Function AIModule.PawnAction.Finish");

	struct {
		char EPawnActionResult WithResult;
	} parms;

	parms.WithResult = WithResult;

	ProcessEvent(p_Finish, &parms);
}

struct UPawnAction* UObject::CreateActionInstance(struct UObject* WorldContextObject, UPawnAction* ActionClass){

	static UObject* p_CreateActionInstance = UObject::FindObject<UFunction>("Function AIModule.PawnAction.CreateActionInstance");

	struct {
		struct UObject* WorldContextObject;
		UPawnAction* ActionClass;
		struct UPawnAction* return_value;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.ActionClass = ActionClass;

	ProcessEvent(p_CreateActionInstance, &parms);
	return parms.return_value;
}

void UPawnAction::ActionTick(struct APawn* ControlledPawn, float DeltaSeconds){

	static UObject* p_ActionTick = UObject::FindObject<UFunction>("Function AIModule.PawnAction_BlueprintBase.ActionTick");

	struct {
		struct APawn* ControlledPawn;
		float DeltaSeconds;
	} parms;

	parms.ControlledPawn = ControlledPawn;
	parms.DeltaSeconds = DeltaSeconds;

	ProcessEvent(p_ActionTick, &parms);
}

void UPawnAction::ActionStart(struct APawn* ControlledPawn){

	static UObject* p_ActionStart = UObject::FindObject<UFunction>("Function AIModule.PawnAction_BlueprintBase.ActionStart");

	struct {
		struct APawn* ControlledPawn;
	} parms;

	parms.ControlledPawn = ControlledPawn;

	ProcessEvent(p_ActionStart, &parms);
}

void UPawnAction::ActionResume(struct APawn* ControlledPawn){

	static UObject* p_ActionResume = UObject::FindObject<UFunction>("Function AIModule.PawnAction_BlueprintBase.ActionResume");

	struct {
		struct APawn* ControlledPawn;
	} parms;

	parms.ControlledPawn = ControlledPawn;

	ProcessEvent(p_ActionResume, &parms);
}

void UPawnAction::ActionPause(struct APawn* ControlledPawn){

	static UObject* p_ActionPause = UObject::FindObject<UFunction>("Function AIModule.PawnAction_BlueprintBase.ActionPause");

	struct {
		struct APawn* ControlledPawn;
	} parms;

	parms.ControlledPawn = ControlledPawn;

	ProcessEvent(p_ActionPause, &parms);
}

void UPawnAction::ActionFinished(struct APawn* ControlledPawn, char EPawnActionResult WithResult){

	static UObject* p_ActionFinished = UObject::FindObject<UFunction>("Function AIModule.PawnAction_BlueprintBase.ActionFinished");

	struct {
		struct APawn* ControlledPawn;
		char EPawnActionResult WithResult;
	} parms;

	parms.ControlledPawn = ControlledPawn;
	parms.WithResult = WithResult;

	ProcessEvent(p_ActionFinished, &parms);
}

bool UActorComponent::K2_PushAction(struct UPawnAction* NewAction, char EAIRequestPriority Priority, struct UObject* Instigator){

	static UObject* p_K2_PushAction = UObject::FindObject<UFunction>("Function AIModule.PawnActionsComponent.K2_PushAction");

	struct {
		struct UPawnAction* NewAction;
		char EAIRequestPriority Priority;
		struct UObject* Instigator;
		bool return_value;
	} parms;

	parms.NewAction = NewAction;
	parms.Priority = Priority;
	parms.Instigator = Instigator;

	ProcessEvent(p_K2_PushAction, &parms);
	return parms.return_value;
}

bool UActorComponent::K2_PerformAction(struct APawn* Pawn, struct UPawnAction* Action, char EAIRequestPriority Priority){

	static UObject* p_K2_PerformAction = UObject::FindObject<UFunction>("Function AIModule.PawnActionsComponent.K2_PerformAction");

	struct {
		struct APawn* Pawn;
		struct UPawnAction* Action;
		char EAIRequestPriority Priority;
		bool return_value;
	} parms;

	parms.Pawn = Pawn;
	parms.Action = Action;
	parms.Priority = Priority;

	ProcessEvent(p_K2_PerformAction, &parms);
	return parms.return_value;
}

char EPawnActionAbortState UActorComponent::K2_ForceAbortAction(struct UPawnAction* ActionToAbort){

	static UObject* p_K2_ForceAbortAction = UObject::FindObject<UFunction>("Function AIModule.PawnActionsComponent.K2_ForceAbortAction");

	struct {
		struct UPawnAction* ActionToAbort;
		char EPawnActionAbortState return_value;
	} parms;

	parms.ActionToAbort = ActionToAbort;

	ProcessEvent(p_K2_ForceAbortAction, &parms);
	return parms.return_value;
}

char EPawnActionAbortState UActorComponent::K2_AbortAction(struct UPawnAction* ActionToAbort){

	static UObject* p_K2_AbortAction = UObject::FindObject<UFunction>("Function AIModule.PawnActionsComponent.K2_AbortAction");

	struct {
		struct UPawnAction* ActionToAbort;
		char EPawnActionAbortState return_value;
	} parms;

	parms.ActionToAbort = ActionToAbort;

	ProcessEvent(p_K2_AbortAction, &parms);
	return parms.return_value;
}

void UActorComponent::SetSensingUpdatesEnabled(bool bEnabled){

	static UObject* p_SetSensingUpdatesEnabled = UObject::FindObject<UFunction>("Function AIModule.PawnSensingComponent.SetSensingUpdatesEnabled");

	struct {
		bool bEnabled;
	} parms;

	parms.bEnabled = bEnabled;

	ProcessEvent(p_SetSensingUpdatesEnabled, &parms);
}

void UActorComponent::SetSensingInterval(float NewSensingInterval){

	static UObject* p_SetSensingInterval = UObject::FindObject<UFunction>("Function AIModule.PawnSensingComponent.SetSensingInterval");

	struct {
		float NewSensingInterval;
	} parms;

	parms.NewSensingInterval = NewSensingInterval;

	ProcessEvent(p_SetSensingInterval, &parms);
}

void UActorComponent::SetPeripheralVisionAngle(float NewPeripheralVisionAngle){

	static UObject* p_SetPeripheralVisionAngle = UObject::FindObject<UFunction>("Function AIModule.PawnSensingComponent.SetPeripheralVisionAngle");

	struct {
		float NewPeripheralVisionAngle;
	} parms;

	parms.NewPeripheralVisionAngle = NewPeripheralVisionAngle;

	ProcessEvent(p_SetPeripheralVisionAngle, &parms);
}

void UActorComponent::SeePawnDelegate__DelegateSignature(struct APawn* Pawn){

	static UObject* p_SeePawnDelegate__DelegateSignature = UObject::FindObject<UFunction>("DelegateFunction AIModule.PawnSensingComponent.SeePawnDelegate__DelegateSignature");

	struct {
		struct APawn* Pawn;
	} parms;

	parms.Pawn = Pawn;

	ProcessEvent(p_SeePawnDelegate__DelegateSignature, &parms);
}

void UActorComponent::HearNoiseDelegate__DelegateSignature(struct APawn* Instigator, struct FVector& Location, float Volume){

	static UObject* p_HearNoiseDelegate__DelegateSignature = UObject::FindObject<UFunction>("DelegateFunction AIModule.PawnSensingComponent.HearNoiseDelegate__DelegateSignature");

	struct {
		struct APawn* Instigator;
		struct FVector& Location;
		float Volume;
	} parms;

	parms.Instigator = Instigator;
	parms.Location = Location;
	parms.Volume = Volume;

	ProcessEvent(p_HearNoiseDelegate__DelegateSignature, &parms);
}

float UActorComponent::GetPeripheralVisionCosine(){

	static UObject* p_GetPeripheralVisionCosine = UObject::FindObject<UFunction>("Function AIModule.PawnSensingComponent.GetPeripheralVisionCosine");

	struct {
		float return_value;
	} parms;


	ProcessEvent(p_GetPeripheralVisionCosine, &parms);
	return parms.return_value;
}

float UActorComponent::GetPeripheralVisionAngle(){

	static UObject* p_GetPeripheralVisionAngle = UObject::FindObject<UFunction>("Function AIModule.PawnSensingComponent.GetPeripheralVisionAngle");

	struct {
		float return_value;
	} parms;


	ProcessEvent(p_GetPeripheralVisionAngle, &parms);
	return parms.return_value;
}

