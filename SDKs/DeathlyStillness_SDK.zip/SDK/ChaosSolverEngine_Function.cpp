#include "SDK.h" 
 
 
void AActor::SetSolverActive(bool bActive){

	static UObject* p_SetSolverActive = UObject::FindObject<UFunction>("Function ChaosSolverEngine.ChaosSolverActor.SetSolverActive");

	struct {
		bool bActive;
	} parms;

	parms.bActive = bActive;

	ProcessEvent(p_SetSolverActive, &parms);
}

void AActor::SetAsCurrentWorldSolver(){

	static UObject* p_SetAsCurrentWorldSolver = UObject::FindObject<UFunction>("Function ChaosSolverEngine.ChaosSolverActor.SetAsCurrentWorldSolver");

	struct {
	} parms;


	ProcessEvent(p_SetAsCurrentWorldSolver, &parms);
}

struct FHitResult UBlueprintFunctionLibrary::ConvertPhysicsCollisionToHitResult(struct FChaosPhysicsCollisionInfo& PhysicsCollision){

	static UObject* p_ConvertPhysicsCollisionToHitResult = UObject::FindObject<UFunction>("Function ChaosSolverEngine.ChaosSolverEngineBlueprintLibrary.ConvertPhysicsCollisionToHitResult");

	struct {
		struct FChaosPhysicsCollisionInfo& PhysicsCollision;
		struct FHitResult return_value;
	} parms;

	parms.PhysicsCollision = PhysicsCollision;

	ProcessEvent(p_ConvertPhysicsCollisionToHitResult, &parms);
	return parms.return_value;
}

