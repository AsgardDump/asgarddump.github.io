#include "SDK.h" 
 
 
bool UAnimNotify::Received_Notify(struct USkeletalMeshComponent* bpp__MeshComp__pf, struct UAnimSequenceBase* bpp__Animation__pf){

	static UObject* p_Received_Notify = UObject::FindObject<UFunction>("Function Chinese_Vampire_AttackStart.Chinese_Vampire_AttackStart_C.Received_Notify");

	struct {
		struct USkeletalMeshComponent* bpp__MeshComp__pf;
		struct UAnimSequenceBase* bpp__Animation__pf;
		bool return_value;
	} parms;

	parms.bpp__MeshComp__pf = bpp__MeshComp__pf;
	parms.bpp__Animation__pf = bpp__Animation__pf;

	ProcessEvent(p_Received_Notify, &parms);
	return parms.return_value;
}

