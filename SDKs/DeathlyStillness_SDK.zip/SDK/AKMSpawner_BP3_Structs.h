#pragma once 
#include "SDK.h" 
 
 
// Function AKMSpawner_BP3.AKMSpawner_BP3_C.ExecuteUbergraph_AKMSpawner_BP3
// Size: 0x4(Inherited: 0x0) 
struct FExecuteUbergraph_AKMSpawner_BP3
{
	int32_t EntryPoint;  // 0x0(0x4)

}; 
