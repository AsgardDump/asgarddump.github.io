#include "SDK.h" 
 
 
void UObject::SetSkipAssigningGamepadToPlayer1(bool bSkipFirstPlayer){

	static UObject* p_SetSkipAssigningGamepadToPlayer1 = UObject::FindObject<UFunction>("Function EngineSettings.GameMapsSettings.SetSkipAssigningGamepadToPlayer1");

	struct {
		bool bSkipFirstPlayer;
	} parms;

	parms.bSkipFirstPlayer = bSkipFirstPlayer;

	ProcessEvent(p_SetSkipAssigningGamepadToPlayer1, &parms);
}

bool UObject::GetSkipAssigningGamepadToPlayer1(){

	static UObject* p_GetSkipAssigningGamepadToPlayer1 = UObject::FindObject<UFunction>("Function EngineSettings.GameMapsSettings.GetSkipAssigningGamepadToPlayer1");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_GetSkipAssigningGamepadToPlayer1, &parms);
	return parms.return_value;
}

struct UGameMapsSettings* UObject::GetGameMapsSettings(){

	static UObject* p_GetGameMapsSettings = UObject::FindObject<UFunction>("Function EngineSettings.GameMapsSettings.GetGameMapsSettings");

	struct {
		struct UGameMapsSettings* return_value;
	} parms;


	ProcessEvent(p_GetGameMapsSettings, &parms);
	return parms.return_value;
}

