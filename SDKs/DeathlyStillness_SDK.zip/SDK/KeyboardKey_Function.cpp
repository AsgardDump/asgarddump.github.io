#include "SDK.h" 
 
 
void UUserWidget::PreConstruct(bool IsDesignTime){

	static UObject* p_PreConstruct = UObject::FindObject<UFunction>("Function KeyboardKey.KeyboardKey_C.PreConstruct");

	struct {
		bool IsDesignTime;
	} parms;

	parms.IsDesignTime = IsDesignTime;

	ProcessEvent(p_PreConstruct, &parms);
}

void UUserWidget::ExecuteUbergraph_KeyboardKey(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph_KeyboardKey = UObject::FindObject<UFunction>("Function KeyboardKey.KeyboardKey_C.ExecuteUbergraph_KeyboardKey");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph_KeyboardKey, &parms);
}

