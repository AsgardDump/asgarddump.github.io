#include "SDK.h" 
 
 
bool UBlueprintFunctionLibrary::TestParameters(){

	static UObject* p_TestParameters = UObject::FindObject<UFunction>("Function DirectLinkTest.DirectLinkTestLibrary.TestParameters");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_TestParameters, &parms);
	return parms.return_value;
}

bool UBlueprintFunctionLibrary::StopSender(){

	static UObject* p_StopSender = UObject::FindObject<UFunction>("Function DirectLinkTest.DirectLinkTestLibrary.StopSender");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_StopSender, &parms);
	return parms.return_value;
}

bool UBlueprintFunctionLibrary::StopReceiver(){

	static UObject* p_StopReceiver = UObject::FindObject<UFunction>("Function DirectLinkTest.DirectLinkTestLibrary.StopReceiver");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_StopReceiver, &parms);
	return parms.return_value;
}

bool UBlueprintFunctionLibrary::StartSender(){

	static UObject* p_StartSender = UObject::FindObject<UFunction>("Function DirectLinkTest.DirectLinkTestLibrary.StartSender");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_StartSender, &parms);
	return parms.return_value;
}

bool UBlueprintFunctionLibrary::StartReceiver(){

	static UObject* p_StartReceiver = UObject::FindObject<UFunction>("Function DirectLinkTest.DirectLinkTestLibrary.StartReceiver");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_StartReceiver, &parms);
	return parms.return_value;
}

bool UBlueprintFunctionLibrary::SetupSender(){

	static UObject* p_SetupSender = UObject::FindObject<UFunction>("Function DirectLinkTest.DirectLinkTestLibrary.SetupSender");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_SetupSender, &parms);
	return parms.return_value;
}

bool UBlueprintFunctionLibrary::SetupReceiver(){

	static UObject* p_SetupReceiver = UObject::FindObject<UFunction>("Function DirectLinkTest.DirectLinkTestLibrary.SetupReceiver");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_SetupReceiver, &parms);
	return parms.return_value;
}

bool UBlueprintFunctionLibrary::SendScene(struct FString InFilePath){

	static UObject* p_SendScene = UObject::FindObject<UFunction>("Function DirectLinkTest.DirectLinkTestLibrary.SendScene");

	struct {
		struct FString InFilePath;
		bool return_value;
	} parms;

	parms.InFilePath = InFilePath;

	ProcessEvent(p_SendScene, &parms);
	return parms.return_value;
}

int32_t UBlueprintFunctionLibrary::MakeEndpoint(struct FString NiceName, bool bVerbose){

	static UObject* p_MakeEndpoint = UObject::FindObject<UFunction>("Function DirectLinkTest.DirectLinkTestLibrary.MakeEndpoint");

	struct {
		struct FString NiceName;
		bool bVerbose;
		int32_t return_value;
	} parms;

	parms.NiceName = NiceName;
	parms.bVerbose = bVerbose;

	ProcessEvent(p_MakeEndpoint, &parms);
	return parms.return_value;
}

bool UBlueprintFunctionLibrary::DumpReceivedScene(){

	static UObject* p_DumpReceivedScene = UObject::FindObject<UFunction>("Function DirectLinkTest.DirectLinkTestLibrary.DumpReceivedScene");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_DumpReceivedScene, &parms);
	return parms.return_value;
}

bool UBlueprintFunctionLibrary::DeleteEndpoint(int32_t EndpointId){

	static UObject* p_DeleteEndpoint = UObject::FindObject<UFunction>("Function DirectLinkTest.DirectLinkTestLibrary.DeleteEndpoint");

	struct {
		int32_t EndpointId;
		bool return_value;
	} parms;

	parms.EndpointId = EndpointId;

	ProcessEvent(p_DeleteEndpoint, &parms);
	return parms.return_value;
}

bool UBlueprintFunctionLibrary::DeleteAllEndpoint(){

	static UObject* p_DeleteAllEndpoint = UObject::FindObject<UFunction>("Function DirectLinkTest.DirectLinkTestLibrary.DeleteAllEndpoint");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_DeleteAllEndpoint, &parms);
	return parms.return_value;
}

bool UBlueprintFunctionLibrary::AddPublicSource(int32_t EndpointId, struct FString SourceName){

	static UObject* p_AddPublicSource = UObject::FindObject<UFunction>("Function DirectLinkTest.DirectLinkTestLibrary.AddPublicSource");

	struct {
		int32_t EndpointId;
		struct FString SourceName;
		bool return_value;
	} parms;

	parms.EndpointId = EndpointId;
	parms.SourceName = SourceName;

	ProcessEvent(p_AddPublicSource, &parms);
	return parms.return_value;
}

bool UBlueprintFunctionLibrary::AddPublicDestination(int32_t EndpointId, struct FString DestName){

	static UObject* p_AddPublicDestination = UObject::FindObject<UFunction>("Function DirectLinkTest.DirectLinkTestLibrary.AddPublicDestination");

	struct {
		int32_t EndpointId;
		struct FString DestName;
		bool return_value;
	} parms;

	parms.EndpointId = EndpointId;
	parms.DestName = DestName;

	ProcessEvent(p_AddPublicDestination, &parms);
	return parms.return_value;
}

