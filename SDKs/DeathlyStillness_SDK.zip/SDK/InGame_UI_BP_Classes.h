#pragma once 
#include <InGame_UI_BP_Structs.h>
 
 
 
// BlueprintGeneratedClass InGame_UI_BP.InGame_UI_BP_C
// Size: 0x238(Inherited: 0x220) 
struct AInGame_UI_BP_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct UWidgetComponent* Widget;  // 0x228(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x230(0x8)

	void (); // Function InGame_UI_BP.InGame_UI_BP_C.
	void ExecuteUbergraph_InGame_UI_BP(int32_t EntryPoint); // Function InGame_UI_BP.InGame_UI_BP_C.ExecuteUbergraph_InGame_UI_BP
}; 



