#pragma once 
#include <InGamePlayerState_Structs.h>
 
 
 
// BlueprintGeneratedClass InGamePlayerState.InGamePlayerState_C
// Size: 0x34C(Inherited: 0x320) 
struct AInGamePlayerState_C : public APlayerState
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x320(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x328(0x8)
	float ;  // 0x330(0x4)
	float ;  // 0x334(0x4)
	float ;  // 0x338(0x4)
	float ;  // 0x33C(0x4)
	float ;  // 0x340(0x4)
	float ;  // 0x344(0x4)
	float ;  // 0x348(0x4)

	void (float& ); // Function InGamePlayerState.InGamePlayerState_C.
	void (float& ); // Function InGamePlayerState.InGamePlayerState_C.
	void (); // Function InGamePlayerState.InGamePlayerState_C.
	void (); // Function InGamePlayerState.InGamePlayerState_C.
	void (); // Function InGamePlayerState.InGamePlayerState_C.
	void (float ); // Function InGamePlayerState.InGamePlayerState_C.
	void ExecuteUbergraph_InGamePlayerState(int32_t EntryPoint); // Function InGamePlayerState.InGamePlayerState_C.ExecuteUbergraph_InGamePlayerState
}; 



