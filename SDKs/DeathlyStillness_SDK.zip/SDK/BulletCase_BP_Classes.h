#pragma once 
#include <BulletCase_BP_Structs.h>
 
 
 
// BlueprintGeneratedClass BulletCase_BP.BulletCase_BP_C
// Size: 0x248(Inherited: 0x220) 
struct ABulletCase_BP_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct UStaticMeshComponent* StaticMesh;  // 0x228(0x8)
	struct USceneComponent* Scene;  // 0x230(0x8)
	struct UProjectileMovementComponent* ProjectileMovement;  // 0x238(0x8)
	float Min;  // 0x240(0x4)
	float Max;  // 0x244(0x4)

	void UserConstructionScript(); // Function BulletCase_BP.BulletCase_BP_C.UserConstructionScript
	void ReceiveBeginPlay(); // Function BulletCase_BP.BulletCase_BP_C.ReceiveBeginPlay
	void BndEvt__StaticMesh_K2Node_ComponentBoundEvent_0_ComponentHitSignature__DelegateSignature(struct UPrimitiveComponent* HitComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, struct FVector NormalImpulse, struct FHitResult& Hit); // Function BulletCase_BP.BulletCase_BP_C.BndEvt__StaticMesh_K2Node_ComponentBoundEvent_0_ComponentHitSignature__DelegateSignature
	void ExecuteUbergraph_BulletCase_BP(int32_t EntryPoint); // Function BulletCase_BP.BulletCase_BP_C.ExecuteUbergraph_BulletCase_BP
}; 



