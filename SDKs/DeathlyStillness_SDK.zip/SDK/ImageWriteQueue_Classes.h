#pragma once 
#include <ImageWriteQueue_Structs.h>
 
 
 
// Class ImageWriteQueue.ImageWriteBlueprintLibrary
// Size: 0x28(Inherited: 0x28) 
struct UImageWriteBlueprintLibrary : public UBlueprintFunctionLibrary
{

	void ExportToDisk(struct UTexture* Texture, struct FString Filename, struct FImageWriteOptions& Options); // Function ImageWriteQueue.ImageWriteBlueprintLibrary.ExportToDisk
}; 



