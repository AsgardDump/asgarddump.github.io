#pragma once 
#include "SDK.h" 
 
 
// Function Destination_UMG.Destination_UMG_C.ExecuteUbergraph_Destination_UMG
// Size: 0x124(Inherited: 0x0) 
struct FExecuteUbergraph_Destination_UMG
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FString CallFunc_Conv_TextToString_ReturnValue;  // 0x8(0x10)
	int32_t CallFunc_FTrunc_ReturnValue;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct FString CallFunc_Conv_IntToString_ReturnValue;  // 0x20(0x10)
	struct AActor* K2Node_CustomEvent____;  // 0x30(0x8)
	char pad_56[8];  // 0x38(0x8)
	struct FTransform K2Node_CustomEvent_T;  // 0x40(0x30)
	struct AActor* K2Node_CustomEvent_____;  // 0x70(0x8)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0x78(0x10)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x88(0xC)
	char pad_148[4];  // 0x94(0x4)
	struct FText CallFunc_Conv_StringToText_ReturnValue;  // 0x98(0x18)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_2;  // 0xB0(0xC)
	struct FVector CallFunc_InverseTransformLocation_ReturnValue;  // 0xBC(0xC)
	struct FVector CallFunc_Subtract_VectorVector_ReturnValue;  // 0xC8(0xC)
	float CallFunc_GetYawPitchFromVector_Yaw;  // 0xD4(0x4)
	float CallFunc_GetYawPitchFromVector_Pitch;  // 0xD8(0x4)
	float CallFunc_VSize_ReturnValue;  // 0xDC(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0xE0(0x4)
	char pad_228[4];  // 0xE4(0x4)
	struct APlayerController* CallFunc_GetOwningPlayer_ReturnValue;  // 0xE8(0x8)
	int32_t CallFunc_FTrunc_ReturnValue_2;  // 0xF0(0x4)
	int32_t CallFunc_GetViewportSize_SizeX;  // 0xF4(0x4)
	int32_t CallFunc_GetViewportSize_SizeY;  // 0xF8(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0xFC(0x4)
	struct UUMGSequencePlayer* CallFunc_PlayAnimation_ReturnValue;  // 0x100(0x8)
	float CallFunc_Conv_IntToFloat_ReturnValue;  // 0x108(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0x10C(0x4)
	float CallFunc_MapRangeClamped_ReturnValue;  // 0x110(0x4)
	float CallFunc_Conv_IntToFloat_ReturnValue_2;  // 0x114(0x4)
	float CallFunc_MapRangeClamped_ReturnValue_2;  // 0x118(0x4)
	struct FVector2D CallFunc_MakeVector2D_ReturnValue;  // 0x11C(0x8)

}; 
// Function Destination_UMG.Destination_UMG_C.QuestDistance
// Size: 0x48(Inherited: 0x0) 
struct FQuestDistance
{
	struct AActor* ;  // 0x0(0x8)
	char pad_8[8];  // 0x8(0x8)
	struct FTransform T;  // 0x10(0x30)
	struct AActor* ;  // 0x40(0x8)

}; 
