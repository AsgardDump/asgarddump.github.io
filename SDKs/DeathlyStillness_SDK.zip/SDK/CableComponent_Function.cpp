#include "SDK.h" 
 
 
void UMeshComponent::SetAttachEndToComponent(struct USceneComponent* Component, struct FName SocketName){

	static UObject* p_SetAttachEndToComponent = UObject::FindObject<UFunction>("Function CableComponent.CableComponent.SetAttachEndToComponent");

	struct {
		struct USceneComponent* Component;
		struct FName SocketName;
	} parms;

	parms.Component = Component;
	parms.SocketName = SocketName;

	ProcessEvent(p_SetAttachEndToComponent, &parms);
}

void UMeshComponent::SetAttachEndTo(struct AActor* Actor, struct FName ComponentProperty, struct FName SocketName){

	static UObject* p_SetAttachEndTo = UObject::FindObject<UFunction>("Function CableComponent.CableComponent.SetAttachEndTo");

	struct {
		struct AActor* Actor;
		struct FName ComponentProperty;
		struct FName SocketName;
	} parms;

	parms.Actor = Actor;
	parms.ComponentProperty = ComponentProperty;
	parms.SocketName = SocketName;

	ProcessEvent(p_SetAttachEndTo, &parms);
}

void UMeshComponent::GetCableParticleLocations(struct TArray<struct FVector>& Locations){

	static UObject* p_GetCableParticleLocations = UObject::FindObject<UFunction>("Function CableComponent.CableComponent.GetCableParticleLocations");

	struct {
		struct TArray<struct FVector>& Locations;
	} parms;

	parms.Locations = Locations;

	ProcessEvent(p_GetCableParticleLocations, &parms);
}

struct USceneComponent* UMeshComponent::GetAttachedComponent(){

	static UObject* p_GetAttachedComponent = UObject::FindObject<UFunction>("Function CableComponent.CableComponent.GetAttachedComponent");

	struct {
		struct USceneComponent* return_value;
	} parms;


	ProcessEvent(p_GetAttachedComponent, &parms);
	return parms.return_value;
}

struct AActor* UMeshComponent::GetAttachedActor(){

	static UObject* p_GetAttachedActor = UObject::FindObject<UFunction>("Function CableComponent.CableComponent.GetAttachedActor");

	struct {
		struct AActor* return_value;
	} parms;


	ProcessEvent(p_GetAttachedActor, &parms);
	return parms.return_value;
}

