#pragma once 
#include "SDK.h" 
 
 
// Function FPS.FPS_C.Tick
// Size: 0x3C(Inherited: 0x3C) 
struct FTick : public FTick
{
	struct FGeometry MyGeometry;  // 0x0(0x38)
	float InDeltaTime;  // 0x38(0x4)

}; 
// Function FPS.FPS_C.ExecuteUbergraph_FPS
// Size: 0x98(Inherited: 0x0) 
struct FExecuteUbergraph_FPS
{
	int32_t EntryPoint;  // 0x0(0x4)
	float CallFunc_GetWorldDeltaSeconds_ReturnValue;  // 0x4(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x8(0x4)
	struct FGeometry K2Node_Event_MyGeometry;  // 0xC(0x38)
	float K2Node_Event_InDeltaTime;  // 0x44(0x4)
	struct FText CallFunc_Conv_FloatToText_ReturnValue;  // 0x48(0x18)
	struct FString CallFunc_Conv_TextToString_ReturnValue;  // 0x60(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0x70(0x10)
	struct FText CallFunc_Conv_StringToText_ReturnValue;  // 0x80(0x18)

}; 
