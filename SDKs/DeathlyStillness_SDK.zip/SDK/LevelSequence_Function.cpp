#include "SDK.h" 
 
 
void UObject::SetBurnIn(struct FSoftClassPath InBurnInClass){

	static UObject* p_SetBurnIn = UObject::FindObject<UFunction>("Function LevelSequence.LevelSequenceBurnInOptions.SetBurnIn");

	struct {
		struct FSoftClassPath InBurnInClass;
	} parms;

	parms.InBurnInClass = InBurnInClass;

	ProcessEvent(p_SetBurnIn, &parms);
}

void AActor::SynchronizeToServer(float DesyncThresholdSeconds){

	static UObject* p_SynchronizeToServer = UObject::FindObject<UFunction>("Function LevelSequence.LevelSequenceMediaController.SynchronizeToServer");

	struct {
		float DesyncThresholdSeconds;
	} parms;

	parms.DesyncThresholdSeconds = DesyncThresholdSeconds;

	ProcessEvent(p_SynchronizeToServer, &parms);
}

void AActor::Play(){

	static UObject* p_Play = UObject::FindObject<UFunction>("Function LevelSequence.LevelSequenceMediaController.Play");

	struct {
	} parms;


	ProcessEvent(p_Play, &parms);
}

void AActor::OnRep_ServerStartTimeSeconds(){

	static UObject* p_OnRep_ServerStartTimeSeconds = UObject::FindObject<UFunction>("Function LevelSequence.LevelSequenceMediaController.OnRep_ServerStartTimeSeconds");

	struct {
	} parms;


	ProcessEvent(p_OnRep_ServerStartTimeSeconds, &parms);
}

struct ALevelSequenceActor* AActor::GetSequence(){

	static UObject* p_GetSequence = UObject::FindObject<UFunction>("Function LevelSequence.LevelSequenceMediaController.GetSequence");

	struct {
		struct ALevelSequenceActor* return_value;
	} parms;


	ProcessEvent(p_GetSequence, &parms);
	return parms.return_value;
}

struct UMediaComponent* AActor::GetMediaComponent(){

	static UObject* p_GetMediaComponent = UObject::FindObject<UFunction>("Function LevelSequence.LevelSequenceMediaController.GetMediaComponent");

	struct {
		struct UMediaComponent* return_value;
	} parms;


	ProcessEvent(p_GetMediaComponent, &parms);
	return parms.return_value;
}

void UMovieSceneSequence::RemoveMetaDataByClass(UObject* InClass){

	static UObject* p_RemoveMetaDataByClass = UObject::FindObject<UFunction>("Function LevelSequence.LevelSequence.RemoveMetaDataByClass");

	struct {
		UObject* InClass;
	} parms;

	parms.InClass = InClass;

	ProcessEvent(p_RemoveMetaDataByClass, &parms);
}

struct UObject* UMovieSceneSequence::FindOrAddMetaDataByClass(UObject* InClass){

	static UObject* p_FindOrAddMetaDataByClass = UObject::FindObject<UFunction>("Function LevelSequence.LevelSequence.FindOrAddMetaDataByClass");

	struct {
		UObject* InClass;
		struct UObject* return_value;
	} parms;

	parms.InClass = InClass;

	ProcessEvent(p_FindOrAddMetaDataByClass, &parms);
	return parms.return_value;
}

struct UObject* UMovieSceneSequence::FindMetaDataByClass(UObject* InClass){

	static UObject* p_FindMetaDataByClass = UObject::FindObject<UFunction>("Function LevelSequence.LevelSequence.FindMetaDataByClass");

	struct {
		UObject* InClass;
		struct UObject* return_value;
	} parms;

	parms.InClass = InClass;

	ProcessEvent(p_FindMetaDataByClass, &parms);
	return parms.return_value;
}

struct UObject* UMovieSceneSequence::CopyMetaData(struct UObject* InMetaData){

	static UObject* p_CopyMetaData = UObject::FindObject<UFunction>("Function LevelSequence.LevelSequence.CopyMetaData");

	struct {
		struct UObject* InMetaData;
		struct UObject* return_value;
	} parms;

	parms.InMetaData = InMetaData;

	ProcessEvent(p_CopyMetaData, &parms);
	return parms.return_value;
}

void AActor::ShowBurnin(){

	static UObject* p_ShowBurnin = UObject::FindObject<UFunction>("Function LevelSequence.LevelSequenceActor.ShowBurnin");

	struct {
	} parms;


	ProcessEvent(p_ShowBurnin, &parms);
}

void AActor::SetSequence(struct ULevelSequence* InSequence){

	static UObject* p_SetSequence = UObject::FindObject<UFunction>("Function LevelSequence.LevelSequenceActor.SetSequence");

	struct {
		struct ULevelSequence* InSequence;
	} parms;

	parms.InSequence = InSequence;

	ProcessEvent(p_SetSequence, &parms);
}

void AActor::SetReplicatePlayback(bool ReplicatePlayback){

	static UObject* p_SetReplicatePlayback = UObject::FindObject<UFunction>("Function LevelSequence.LevelSequenceActor.SetReplicatePlayback");

	struct {
		bool ReplicatePlayback;
	} parms;

	parms.ReplicatePlayback = ReplicatePlayback;

	ProcessEvent(p_SetReplicatePlayback, &parms);
}

void AActor::SetBindingByTag(struct FName BindingTag, struct TArray<struct AActor*>& Actors, bool bAllowBindingsFromAsset){

	static UObject* p_SetBindingByTag = UObject::FindObject<UFunction>("Function LevelSequence.LevelSequenceActor.SetBindingByTag");

	struct {
		struct FName BindingTag;
		struct TArray<struct AActor*>& Actors;
		bool bAllowBindingsFromAsset;
	} parms;

	parms.BindingTag = BindingTag;
	parms.Actors = Actors;
	parms.bAllowBindingsFromAsset = bAllowBindingsFromAsset;

	ProcessEvent(p_SetBindingByTag, &parms);
}

void AActor::SetBinding(struct FMovieSceneObjectBindingID Binding, struct TArray<struct AActor*>& Actors, bool bAllowBindingsFromAsset){

	static UObject* p_SetBinding = UObject::FindObject<UFunction>("Function LevelSequence.LevelSequenceActor.SetBinding");

	struct {
		struct FMovieSceneObjectBindingID Binding;
		struct TArray<struct AActor*>& Actors;
		bool bAllowBindingsFromAsset;
	} parms;

	parms.Binding = Binding;
	parms.Actors = Actors;
	parms.bAllowBindingsFromAsset = bAllowBindingsFromAsset;

	ProcessEvent(p_SetBinding, &parms);
}

void AActor::ResetBindings(){

	static UObject* p_ResetBindings = UObject::FindObject<UFunction>("Function LevelSequence.LevelSequenceActor.ResetBindings");

	struct {
	} parms;


	ProcessEvent(p_ResetBindings, &parms);
}

void AActor::ResetBinding(struct FMovieSceneObjectBindingID Binding){

	static UObject* p_ResetBinding = UObject::FindObject<UFunction>("Function LevelSequence.LevelSequenceActor.ResetBinding");

	struct {
		struct FMovieSceneObjectBindingID Binding;
	} parms;

	parms.Binding = Binding;

	ProcessEvent(p_ResetBinding, &parms);
}

void AActor::RemoveBindingByTag(struct FName Tag, struct AActor* Actor){

	static UObject* p_RemoveBindingByTag = UObject::FindObject<UFunction>("Function LevelSequence.LevelSequenceActor.RemoveBindingByTag");

	struct {
		struct FName Tag;
		struct AActor* Actor;
	} parms;

	parms.Tag = Tag;
	parms.Actor = Actor;

	ProcessEvent(p_RemoveBindingByTag, &parms);
}

void AActor::RemoveBinding(struct FMovieSceneObjectBindingID Binding, struct AActor* Actor){

	static UObject* p_RemoveBinding = UObject::FindObject<UFunction>("Function LevelSequence.LevelSequenceActor.RemoveBinding");

	struct {
		struct FMovieSceneObjectBindingID Binding;
		struct AActor* Actor;
	} parms;

	parms.Binding = Binding;
	parms.Actor = Actor;

	ProcessEvent(p_RemoveBinding, &parms);
}

void AActor::OnLevelSequenceLoaded__DelegateSignature(){

	static UObject* p_OnLevelSequenceLoaded__DelegateSignature = UObject::FindObject<UFunction>("DelegateFunction LevelSequence.LevelSequenceActor.OnLevelSequenceLoaded__DelegateSignature");

	struct {
	} parms;


	ProcessEvent(p_OnLevelSequenceLoaded__DelegateSignature, &parms);
}

struct ULevelSequence* AActor::LoadSequence(){

	static UObject* p_LoadSequence = UObject::FindObject<UFunction>("Function LevelSequence.LevelSequenceActor.LoadSequence");

	struct {
		struct ULevelSequence* return_value;
	} parms;


	ProcessEvent(p_LoadSequence, &parms);
	return parms.return_value;
}

void AActor::HideBurnin(){

	static UObject* p_HideBurnin = UObject::FindObject<UFunction>("Function LevelSequence.LevelSequenceActor.HideBurnin");

	struct {
	} parms;


	ProcessEvent(p_HideBurnin, &parms);
}

struct ULevelSequencePlayer* AActor::GetSequencePlayer(){

	static UObject* p_GetSequencePlayer = UObject::FindObject<UFunction>("Function LevelSequence.LevelSequenceActor.GetSequencePlayer");

	struct {
		struct ULevelSequencePlayer* return_value;
	} parms;


	ProcessEvent(p_GetSequencePlayer, &parms);
	return parms.return_value;
}

struct ULevelSequence* AActor::GetSequence(){

	static UObject* p_GetSequence = UObject::FindObject<UFunction>("Function LevelSequence.LevelSequenceActor.GetSequence");

	struct {
		struct ULevelSequence* return_value;
	} parms;


	ProcessEvent(p_GetSequence, &parms);
	return parms.return_value;
}

struct TArray<struct FMovieSceneObjectBindingID> AActor::FindNamedBindings(struct FName Tag){

	static UObject* p_FindNamedBindings = UObject::FindObject<UFunction>("Function LevelSequence.LevelSequenceActor.FindNamedBindings");

	struct {
		struct FName Tag;
		struct TArray<struct FMovieSceneObjectBindingID> return_value;
	} parms;

	parms.Tag = Tag;

	ProcessEvent(p_FindNamedBindings, &parms);
	return parms.return_value;
}

struct FMovieSceneObjectBindingID AActor::FindNamedBinding(struct FName Tag){

	static UObject* p_FindNamedBinding = UObject::FindObject<UFunction>("Function LevelSequence.LevelSequenceActor.FindNamedBinding");

	struct {
		struct FName Tag;
		struct FMovieSceneObjectBindingID return_value;
	} parms;

	parms.Tag = Tag;

	ProcessEvent(p_FindNamedBinding, &parms);
	return parms.return_value;
}

void AActor::AddBindingByTag(struct FName BindingTag, struct AActor* Actor, bool bAllowBindingsFromAsset){

	static UObject* p_AddBindingByTag = UObject::FindObject<UFunction>("Function LevelSequence.LevelSequenceActor.AddBindingByTag");

	struct {
		struct FName BindingTag;
		struct AActor* Actor;
		bool bAllowBindingsFromAsset;
	} parms;

	parms.BindingTag = BindingTag;
	parms.Actor = Actor;
	parms.bAllowBindingsFromAsset = bAllowBindingsFromAsset;

	ProcessEvent(p_AddBindingByTag, &parms);
}

void AActor::AddBinding(struct FMovieSceneObjectBindingID Binding, struct AActor* Actor, bool bAllowBindingsFromAsset){

	static UObject* p_AddBinding = UObject::FindObject<UFunction>("Function LevelSequence.LevelSequenceActor.AddBinding");

	struct {
		struct FMovieSceneObjectBindingID Binding;
		struct AActor* Actor;
		bool bAllowBindingsFromAsset;
	} parms;

	parms.Binding = Binding;
	parms.Actor = Actor;
	parms.bAllowBindingsFromAsset = bAllowBindingsFromAsset;

	ProcessEvent(p_AddBinding, &parms);
}

void UUserWidget::SetSettings(struct UObject* InSettings){

	static UObject* p_SetSettings = UObject::FindObject<UFunction>("Function LevelSequence.LevelSequenceBurnIn.SetSettings");

	struct {
		struct UObject* InSettings;
	} parms;

	parms.InSettings = InSettings;

	ProcessEvent(p_SetSettings, &parms);
}

ULevelSequenceBurnInInitSettings* UUserWidget::GetSettingsClass(){

	static UObject* p_GetSettingsClass = UObject::FindObject<UFunction>("Function LevelSequence.LevelSequenceBurnIn.GetSettingsClass");

	struct {
		ULevelSequenceBurnInInitSettings* return_value;
	} parms;


	ProcessEvent(p_GetSettingsClass, &parms);
	return parms.return_value;
}

void UObject::OnCreated(){

	static UObject* p_OnCreated = UObject::FindObject<UFunction>("Function LevelSequence.LevelSequenceDirector.OnCreated");

	struct {
	} parms;


	ProcessEvent(p_OnCreated, &parms);
}

struct UMovieSceneSequence* UObject::GetSequence(){

	static UObject* p_GetSequence = UObject::FindObject<UFunction>("Function LevelSequence.LevelSequenceDirector.GetSequence");

	struct {
		struct UMovieSceneSequence* return_value;
	} parms;


	ProcessEvent(p_GetSequence, &parms);
	return parms.return_value;
}

struct TArray<struct UObject*> UObject::GetBoundObjects(struct FMovieSceneObjectBindingID ObjectBinding){

	static UObject* p_GetBoundObjects = UObject::FindObject<UFunction>("Function LevelSequence.LevelSequenceDirector.GetBoundObjects");

	struct {
		struct FMovieSceneObjectBindingID ObjectBinding;
		struct TArray<struct UObject*> return_value;
	} parms;

	parms.ObjectBinding = ObjectBinding;

	ProcessEvent(p_GetBoundObjects, &parms);
	return parms.return_value;
}

struct UObject* UObject::GetBoundObject(struct FMovieSceneObjectBindingID ObjectBinding){

	static UObject* p_GetBoundObject = UObject::FindObject<UFunction>("Function LevelSequence.LevelSequenceDirector.GetBoundObject");

	struct {
		struct FMovieSceneObjectBindingID ObjectBinding;
		struct UObject* return_value;
	} parms;

	parms.ObjectBinding = ObjectBinding;

	ProcessEvent(p_GetBoundObject, &parms);
	return parms.return_value;
}

struct TArray<struct AActor*> UObject::GetBoundActors(struct FMovieSceneObjectBindingID ObjectBinding){

	static UObject* p_GetBoundActors = UObject::FindObject<UFunction>("Function LevelSequence.LevelSequenceDirector.GetBoundActors");

	struct {
		struct FMovieSceneObjectBindingID ObjectBinding;
		struct TArray<struct AActor*> return_value;
	} parms;

	parms.ObjectBinding = ObjectBinding;

	ProcessEvent(p_GetBoundActors, &parms);
	return parms.return_value;
}

struct AActor* UObject::GetBoundActor(struct FMovieSceneObjectBindingID ObjectBinding){

	static UObject* p_GetBoundActor = UObject::FindObject<UFunction>("Function LevelSequence.LevelSequenceDirector.GetBoundActor");

	struct {
		struct FMovieSceneObjectBindingID ObjectBinding;
		struct AActor* return_value;
	} parms;

	parms.ObjectBinding = ObjectBinding;

	ProcessEvent(p_GetBoundActor, &parms);
	return parms.return_value;
}

struct UCameraComponent* UMovieSceneSequencePlayer::GetActiveCameraComponent(){

	static UObject* p_GetActiveCameraComponent = UObject::FindObject<UFunction>("Function LevelSequence.LevelSequencePlayer.GetActiveCameraComponent");

	struct {
		struct UCameraComponent* return_value;
	} parms;


	ProcessEvent(p_GetActiveCameraComponent, &parms);
	return parms.return_value;
}

struct ULevelSequencePlayer* UMovieSceneSequencePlayer::CreateLevelSequencePlayer(struct UObject* WorldContextObject, struct ULevelSequence* LevelSequence, struct FMovieSceneSequencePlaybackSettings Settings, struct ALevelSequenceActor*& OutActor){

	static UObject* p_CreateLevelSequencePlayer = UObject::FindObject<UFunction>("Function LevelSequence.LevelSequencePlayer.CreateLevelSequencePlayer");

	struct {
		struct UObject* WorldContextObject;
		struct ULevelSequence* LevelSequence;
		struct FMovieSceneSequencePlaybackSettings Settings;
		struct ALevelSequenceActor*& OutActor;
		struct ULevelSequencePlayer* return_value;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.LevelSequence = LevelSequence;
	parms.Settings = Settings;
	parms.OutActor = OutActor;

	ProcessEvent(p_CreateLevelSequencePlayer, &parms);
	return parms.return_value;
}

