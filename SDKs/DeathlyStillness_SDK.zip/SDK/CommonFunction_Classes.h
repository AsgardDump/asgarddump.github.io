#pragma once 
#include <CommonFunction_Structs.h>
 
 
 
// BlueprintGeneratedClass CommonFunction.CommonFunction_C
// Size: 0x28(Inherited: 0x28) 
struct UCommonFunction_C : public UBlueprintFunctionLibrary
{

	void ShowFPS(int32_t Int, struct UObject* __WorldContext); // Function CommonFunction.CommonFunction_C.ShowFPS
}; 



