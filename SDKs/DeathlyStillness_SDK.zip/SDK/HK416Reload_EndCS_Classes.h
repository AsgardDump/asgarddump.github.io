#pragma once 
#include <HK416Reload_EndCS_Structs.h>
 
 
 
// BlueprintGeneratedClass HK416Reload_EndCS.HK416Reload_EndCS_C
// Size: 0x1B0(Inherited: 0x1B0) 
struct UHK416Reload_EndCS_C : public UMatineeCameraShake
{

}; 



