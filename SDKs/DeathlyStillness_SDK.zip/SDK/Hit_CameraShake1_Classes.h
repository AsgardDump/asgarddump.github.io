#pragma once 
#include <Hit_CameraShake1_Structs.h>
 
 
 
// BlueprintGeneratedClass Hit_CameraShake1.Hit_CameraShake1_C
// Size: 0x1B0(Inherited: 0x1B0) 
struct UHit_CameraShake1_C : public UMatineeCameraShake
{

}; 



