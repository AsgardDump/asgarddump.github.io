#pragma once 
#include <DatasmithCore_Structs.h>
 
 
 
// Class DatasmithCore.DatasmithMesh
// Size: 0x50(Inherited: 0x28) 
struct UDatasmithMesh : public UObject
{
	struct FString MeshName;  // 0x28(0x10)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool bIsCollisionMesh : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct TArray<struct FDatasmithMeshSourceModel> SourceModels;  // 0x40(0x10)

}; 



