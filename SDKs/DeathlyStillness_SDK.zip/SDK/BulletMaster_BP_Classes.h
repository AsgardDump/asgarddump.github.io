#pragma once 
#include <BulletMaster_BP_Structs.h>
 
 
 
// BlueprintGeneratedClass BulletMaster_BP.BulletMaster_BP_C
// Size: 0x24C(Inherited: 0x220) 
struct ABulletMaster_BP_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct UParticleSystemComponent* ParticleSystem;  // 0x228(0x8)
	struct UStaticMeshComponent* Sphere1;  // 0x230(0x8)
	struct USphereComponent* Sphere;  // 0x238(0x8)
	struct UProjectileMovementComponent* ProjectileMovement;  // 0x240(0x8)
	float ;  // 0x248(0x4)

	void (struct UPrimitiveComponent* InputObject, float , struct FHitResult Hit); // Function BulletMaster_BP.BulletMaster_BP_C.
	void (struct FHitResult& Hit); // Function BulletMaster_BP.BulletMaster_BP_C.
	void HitSurface(struct FHitResult& Hit); // Function BulletMaster_BP.BulletMaster_BP_C.HitSurface
	void ReceiveHit(struct UPrimitiveComponent* MyComp, struct AActor* Other, struct UPrimitiveComponent* OtherComp, bool bSelfMoved, struct FVector HitLocation, struct FVector HitNormal, struct FVector NormalImpulse, struct FHitResult& Hit); // Function BulletMaster_BP.BulletMaster_BP_C.ReceiveHit
	void ReceiveBeginPlay(); // Function BulletMaster_BP.BulletMaster_BP_C.ReceiveBeginPlay
	void ExecuteUbergraph_BulletMaster_BP(int32_t EntryPoint); // Function BulletMaster_BP.BulletMaster_BP_C.ExecuteUbergraph_BulletMaster_BP
}; 



