#pragma once 
#include <CameraIdle_Structs.h>
 
 
 
// BlueprintGeneratedClass CameraIdle.CameraIdle_C
// Size: 0x1B0(Inherited: 0x1B0) 
struct UCameraIdle_C : public UMatineeCameraShake
{

}; 



