#include "SDK.h" 
 
 
void UActorComponent::DebugAIOptimizer(bool bDebug){

	static UObject* p_DebugAIOptimizer = UObject::FindObject<UFunction>("Function AIOptimizer.AIOInvokerComponent.DebugAIOptimizer");

	struct {
		bool bDebug;
	} parms;

	parms.bDebug = bDebug;

	ProcessEvent(p_DebugAIOptimizer, &parms);
}

void UBlueprintFunctionLibrary::SetCharacterMovementEnabled(struct ACharacter* Character, bool bEnable){

	static UObject* p_SetCharacterMovementEnabled = UObject::FindObject<UFunction>("Function AIOptimizer.AIOBPLibrary.SetCharacterMovementEnabled");

	struct {
		struct ACharacter* Character;
		bool bEnable;
	} parms;

	parms.Character = Character;
	parms.bEnable = bEnable;

	ProcessEvent(p_SetCharacterMovementEnabled, &parms);
}

void UBlueprintFunctionLibrary::SetAILogicEnabled(struct AActor* Actor, bool bEnable){

	static UObject* p_SetAILogicEnabled = UObject::FindObject<UFunction>("Function AIOptimizer.AIOBPLibrary.SetAILogicEnabled");

	struct {
		struct AActor* Actor;
		bool bEnable;
	} parms;

	parms.Actor = Actor;
	parms.bEnable = bEnable;

	ProcessEvent(p_SetAILogicEnabled, &parms);
}

bool UBlueprintFunctionLibrary::RemoveHandle(struct TArray<struct FAIOSubjectHandle>& Array, struct FAIOSubjectHandle& Handle){

	static UObject* p_RemoveHandle = UObject::FindObject<UFunction>("Function AIOptimizer.AIOBPLibrary.RemoveHandle");

	struct {
		struct TArray<struct FAIOSubjectHandle>& Array;
		struct FAIOSubjectHandle& Handle;
		bool return_value;
	} parms;

	parms.Array = Array;
	parms.Handle = Handle;

	ProcessEvent(p_RemoveHandle, &parms);
	return parms.return_value;
}

bool UBlueprintFunctionLibrary::IsHandleValid(struct FAIOSubjectHandle& Handle){

	static UObject* p_IsHandleValid = UObject::FindObject<UFunction>("Function AIOptimizer.AIOBPLibrary.IsHandleValid");

	struct {
		struct FAIOSubjectHandle& Handle;
		bool return_value;
	} parms;

	parms.Handle = Handle;

	ProcessEvent(p_IsHandleValid, &parms);
	return parms.return_value;
}

struct FName UBlueprintFunctionLibrary::GetSubjectTag(){

	static UObject* p_GetSubjectTag = UObject::FindObject<UFunction>("Function AIOptimizer.AIOBPLibrary.GetSubjectTag");

	struct {
		struct FName return_value;
	} parms;


	ProcessEvent(p_GetSubjectTag, &parms);
	return parms.return_value;
}

struct FString UBlueprintFunctionLibrary::GetString(struct FAIOSubjectHandle& Handle){

	static UObject* p_GetString = UObject::FindObject<UFunction>("Function AIOptimizer.AIOBPLibrary.GetString");

	struct {
		struct FAIOSubjectHandle& Handle;
		struct FString return_value;
	} parms;

	parms.Handle = Handle;

	ProcessEvent(p_GetString, &parms);
	return parms.return_value;
}

struct FName UBlueprintFunctionLibrary::GetInvokerTag(){

	static UObject* p_GetInvokerTag = UObject::FindObject<UFunction>("Function AIOptimizer.AIOBPLibrary.GetInvokerTag");

	struct {
		struct FName return_value;
	} parms;


	ProcessEvent(p_GetInvokerTag, &parms);
	return parms.return_value;
}

int32_t UBlueprintFunctionLibrary::FindHandle(struct TArray<struct FAIOSubjectHandle>& Array, struct FAIOSubjectHandle& HandleToFind){

	static UObject* p_FindHandle = UObject::FindObject<UFunction>("Function AIOptimizer.AIOBPLibrary.FindHandle");

	struct {
		struct TArray<struct FAIOSubjectHandle>& Array;
		struct FAIOSubjectHandle& HandleToFind;
		int32_t return_value;
	} parms;

	parms.Array = Array;
	parms.HandleToFind = HandleToFind;

	ProcessEvent(p_FindHandle, &parms);
	return parms.return_value;
}

int32_t UBlueprintFunctionLibrary::AddUniqueHandle(struct TArray<struct FAIOSubjectHandle>& Array, struct FAIOSubjectHandle& Handle){

	static UObject* p_AddUniqueHandle = UObject::FindObject<UFunction>("Function AIOptimizer.AIOBPLibrary.AddUniqueHandle");

	struct {
		struct TArray<struct FAIOSubjectHandle>& Array;
		struct FAIOSubjectHandle& Handle;
		int32_t return_value;
	} parms;

	parms.Array = Array;
	parms.Handle = Handle;

	ProcessEvent(p_AddUniqueHandle, &parms);
	return parms.return_value;
}

bool UWorldSubsystem::UnregisterSubject(struct UAIOSubjectComponent* SubjectComponent){

	static UObject* p_UnregisterSubject = UObject::FindObject<UFunction>("Function AIOptimizer.AIOptimizerSubsystem.UnregisterSubject");

	struct {
		struct UAIOSubjectComponent* SubjectComponent;
		bool return_value;
	} parms;

	parms.SubjectComponent = SubjectComponent;

	ProcessEvent(p_UnregisterSubject, &parms);
	return parms.return_value;
}

bool UWorldSubsystem::UnregisterInvoker(struct UAIOInvokerComponent* InvokerComponent){

	static UObject* p_UnregisterInvoker = UObject::FindObject<UFunction>("Function AIOptimizer.AIOptimizerSubsystem.UnregisterInvoker");

	struct {
		struct UAIOInvokerComponent* InvokerComponent;
		bool return_value;
	} parms;

	parms.InvokerComponent = InvokerComponent;

	ProcessEvent(p_UnregisterInvoker, &parms);
	return parms.return_value;
}

void UWorldSubsystem::ShrinkArrays(){

	static UObject* p_ShrinkArrays = UObject::FindObject<UFunction>("Function AIOptimizer.AIOptimizerSubsystem.ShrinkArrays");

	struct {
	} parms;


	ProcessEvent(p_ShrinkArrays, &parms);
}

void UWorldSubsystem::SetIsSystemEnabled(bool bIsEnabled){

	static UObject* p_SetIsSystemEnabled = UObject::FindObject<UFunction>("Function AIOptimizer.AIOptimizerSubsystem.SetIsSystemEnabled");

	struct {
		bool bIsEnabled;
	} parms;

	parms.bIsEnabled = bIsEnabled;

	ProcessEvent(p_SetIsSystemEnabled, &parms);
}

bool UWorldSubsystem::RemoveDespawnedSubjectByHandle(struct FAIOSubjectHandle& Handle){

	static UObject* p_RemoveDespawnedSubjectByHandle = UObject::FindObject<UFunction>("Function AIOptimizer.AIOptimizerSubsystem.RemoveDespawnedSubjectByHandle");

	struct {
		struct FAIOSubjectHandle& Handle;
		bool return_value;
	} parms;

	parms.Handle = Handle;

	ProcessEvent(p_RemoveDespawnedSubjectByHandle, &parms);
	return parms.return_value;
}

bool UWorldSubsystem::RegisterSubject(struct UAIOSubjectComponent* SubjectComponent){

	static UObject* p_RegisterSubject = UObject::FindObject<UFunction>("Function AIOptimizer.AIOptimizerSubsystem.RegisterSubject");

	struct {
		struct UAIOSubjectComponent* SubjectComponent;
		bool return_value;
	} parms;

	parms.SubjectComponent = SubjectComponent;

	ProcessEvent(p_RegisterSubject, &parms);
	return parms.return_value;
}

bool UWorldSubsystem::RegisterInvoker(struct UAIOInvokerComponent* InvokerComponent){

	static UObject* p_RegisterInvoker = UObject::FindObject<UFunction>("Function AIOptimizer.AIOptimizerSubsystem.RegisterInvoker");

	struct {
		struct UAIOInvokerComponent* InvokerComponent;
		bool return_value;
	} parms;

	parms.InvokerComponent = InvokerComponent;

	ProcessEvent(p_RegisterInvoker, &parms);
	return parms.return_value;
}

void UWorldSubsystem::LoopSubjects(){

	static UObject* p_LoopSubjects = UObject::FindObject<UFunction>("Function AIOptimizer.AIOptimizerSubsystem.LoopSubjects");

	struct {
	} parms;


	ProcessEvent(p_LoopSubjects, &parms);
}

void UWorldSubsystem::LoopPendingSubjects(){

	static UObject* p_LoopPendingSubjects = UObject::FindObject<UFunction>("Function AIOptimizer.AIOptimizerSubsystem.LoopPendingSubjects");

	struct {
	} parms;


	ProcessEvent(p_LoopPendingSubjects, &parms);
}

bool UWorldSubsystem::K2_SpawnSubjectByHandle(uint8_t  Method, struct FAIOSubjectHandle& SubjectHandle){

	static UObject* p_K2_SpawnSubjectByHandle = UObject::FindObject<UFunction>("Function AIOptimizer.AIOptimizerSubsystem.K2_SpawnSubjectByHandle");

	struct {
		uint8_t  Method;
		struct FAIOSubjectHandle& SubjectHandle;
		bool return_value;
	} parms;

	parms.Method = Method;
	parms.SubjectHandle = SubjectHandle;

	ProcessEvent(p_K2_SpawnSubjectByHandle, &parms);
	return parms.return_value;
}

bool UWorldSubsystem::K2_DespawnSubjectByHandle(struct FAIOSubjectHandle& SubjectHandle, uint8_t  Method, float OverrideSpawnRadius, bool bAllowRespawnOnlyByHandle){

	static UObject* p_K2_DespawnSubjectByHandle = UObject::FindObject<UFunction>("Function AIOptimizer.AIOptimizerSubsystem.K2_DespawnSubjectByHandle");

	struct {
		struct FAIOSubjectHandle& SubjectHandle;
		uint8_t  Method;
		float OverrideSpawnRadius;
		bool bAllowRespawnOnlyByHandle;
		bool return_value;
	} parms;

	parms.SubjectHandle = SubjectHandle;
	parms.Method = Method;
	parms.OverrideSpawnRadius = OverrideSpawnRadius;
	parms.bAllowRespawnOnlyByHandle = bAllowRespawnOnlyByHandle;

	ProcessEvent(p_K2_DespawnSubjectByHandle, &parms);
	return parms.return_value;
}

bool UWorldSubsystem::K2_DespawnSubject(struct FAIOSubjectHandle& SubjectHandle, uint8_t  Method, struct UAIOSubjectComponent* Component, float OverrideSpawnRadius, bool bAllowRespawnOnlyByHandle){

	static UObject* p_K2_DespawnSubject = UObject::FindObject<UFunction>("Function AIOptimizer.AIOptimizerSubsystem.K2_DespawnSubject");

	struct {
		struct FAIOSubjectHandle& SubjectHandle;
		uint8_t  Method;
		struct UAIOSubjectComponent* Component;
		float OverrideSpawnRadius;
		bool bAllowRespawnOnlyByHandle;
		bool return_value;
	} parms;

	parms.SubjectHandle = SubjectHandle;
	parms.Method = Method;
	parms.Component = Component;
	parms.OverrideSpawnRadius = OverrideSpawnRadius;
	parms.bAllowRespawnOnlyByHandle = bAllowRespawnOnlyByHandle;

	ProcessEvent(p_K2_DespawnSubject, &parms);
	return parms.return_value;
}

int32_t UWorldSubsystem::GetSubjectIndex(struct UAIOSubjectComponent* Component){

	static UObject* p_GetSubjectIndex = UObject::FindObject<UFunction>("Function AIOptimizer.AIOptimizerSubsystem.GetSubjectIndex");

	struct {
		struct UAIOSubjectComponent* Component;
		int32_t return_value;
	} parms;

	parms.Component = Component;

	ProcessEvent(p_GetSubjectIndex, &parms);
	return parms.return_value;
}

int32_t UWorldSubsystem::GetInvokerIndex(struct UAIOInvokerComponent* Component){

	static UObject* p_GetInvokerIndex = UObject::FindObject<UFunction>("Function AIOptimizer.AIOptimizerSubsystem.GetInvokerIndex");

	struct {
		struct UAIOInvokerComponent* Component;
		int32_t return_value;
	} parms;

	parms.Component = Component;

	ProcessEvent(p_GetInvokerIndex, &parms);
	return parms.return_value;
}

float UWorldSubsystem::GetDistanceToClosestInvokerSquared(struct FVector& QuerierLocation){

	static UObject* p_GetDistanceToClosestInvokerSquared = UObject::FindObject<UFunction>("Function AIOptimizer.AIOptimizerSubsystem.GetDistanceToClosestInvokerSquared");

	struct {
		struct FVector& QuerierLocation;
		float return_value;
	} parms;

	parms.QuerierLocation = QuerierLocation;

	ProcessEvent(p_GetDistanceToClosestInvokerSquared, &parms);
	return parms.return_value;
}

struct TArray<struct FAIODebugSubjectData> UWorldSubsystem::GetDebugSubjects(){

	static UObject* p_GetDebugSubjects = UObject::FindObject<UFunction>("Function AIOptimizer.AIOptimizerSubsystem.GetDebugSubjects");

	struct {
		struct TArray<struct FAIODebugSubjectData> return_value;
	} parms;


	ProcessEvent(p_GetDebugSubjects, &parms);
	return parms.return_value;
}

struct FVector UWorldSubsystem::GetClosestInvokerLocation(struct FVector& QuerierLocation){

	static UObject* p_GetClosestInvokerLocation = UObject::FindObject<UFunction>("Function AIOptimizer.AIOptimizerSubsystem.GetClosestInvokerLocation");

	struct {
		struct FVector& QuerierLocation;
		struct FVector return_value;
	} parms;

	parms.QuerierLocation = QuerierLocation;

	ProcessEvent(p_GetClosestInvokerLocation, &parms);
	return parms.return_value;
}

struct TMap<uint8_t , int32_t> UWorldSubsystem::GetCategorizedDebugSubjects(struct TArray<struct FAIODebugSubjectData>& DebugSubjects){

	static UObject* p_GetCategorizedDebugSubjects = UObject::FindObject<UFunction>("Function AIOptimizer.AIOptimizerSubsystem.GetCategorizedDebugSubjects");

	struct {
		struct TArray<struct FAIODebugSubjectData>& DebugSubjects;
		struct TMap<uint8_t , int32_t> return_value;
	} parms;

	parms.DebugSubjects = DebugSubjects;

	ProcessEvent(p_GetCategorizedDebugSubjects, &parms);
	return parms.return_value;
}

void UInterface::OnSubjectSpawnedByOptimizerSubsystem(struct UAIOSubjectComponent* SpawnedSubjectComponent){

	static UObject* p_OnSubjectSpawnedByOptimizerSubsystem = UObject::FindObject<UFunction>("Function AIOptimizer.SpawnerInterface.OnSubjectSpawnedByOptimizerSubsystem");

	struct {
		struct UAIOSubjectComponent* SpawnedSubjectComponent;
	} parms;

	parms.SpawnedSubjectComponent = SpawnedSubjectComponent;

	ProcessEvent(p_OnSubjectSpawnedByOptimizerSubsystem, &parms);
}

void UInterface::OnSubjectDespawnedByOptimizerSubsystem(struct UAIOSubjectComponent* DespawnedSubjectComponent){

	static UObject* p_OnSubjectDespawnedByOptimizerSubsystem = UObject::FindObject<UFunction>("Function AIOptimizer.SpawnerInterface.OnSubjectDespawnedByOptimizerSubsystem");

	struct {
		struct UAIOSubjectComponent* DespawnedSubjectComponent;
	} parms;

	parms.DespawnedSubjectComponent = DespawnedSubjectComponent;

	ProcessEvent(p_OnSubjectDespawnedByOptimizerSubsystem, &parms);
}

void UActorComponent::UnregisterSubject(){

	static UObject* p_UnregisterSubject = UObject::FindObject<UFunction>("Function AIOptimizer.AIOSubjectComponent.UnregisterSubject");

	struct {
	} parms;


	ProcessEvent(p_UnregisterSubject, &parms);
}

bool UActorComponent::ShouldBeDespawned(struct UAIOptimizerSubsystem* Subsystem, bool bForceUpdateDataToInvokers){

	static UObject* p_ShouldBeDespawned = UObject::FindObject<UFunction>("Function AIOptimizer.AIOSubjectComponent.ShouldBeDespawned");

	struct {
		struct UAIOptimizerSubsystem* Subsystem;
		bool bForceUpdateDataToInvokers;
		bool return_value;
	} parms;

	parms.Subsystem = Subsystem;
	parms.bForceUpdateDataToInvokers = bForceUpdateDataToInvokers;

	ProcessEvent(p_ShouldBeDespawned, &parms);
	return parms.return_value;
}

void UActorComponent::SetSpawner(struct TScriptInterface<ISpawnerInterface> NewSpawner){

	static UObject* p_SetSpawner = UObject::FindObject<UFunction>("Function AIOptimizer.AIOSubjectComponent.SetSpawner");

	struct {
		struct TScriptInterface<ISpawnerInterface> NewSpawner;
	} parms;

	parms.NewSpawner = NewSpawner;

	ProcessEvent(p_SetSpawner, &parms);
}

void UActorComponent::SetCharacterFeatures(struct ACharacter* Character, int32_t FeaturesToEnable){

	static UObject* p_SetCharacterFeatures = UObject::FindObject<UFunction>("Function AIOptimizer.AIOSubjectComponent.SetCharacterFeatures");

	struct {
		struct ACharacter* Character;
		int32_t FeaturesToEnable;
	} parms;

	parms.Character = Character;
	parms.FeaturesToEnable = FeaturesToEnable;

	ProcessEvent(p_SetCharacterFeatures, &parms);
}

void UActorComponent::SetCanBeUpdatedBySubsystem(bool bCanBeUpdated){

	static UObject* p_SetCanBeUpdatedBySubsystem = UObject::FindObject<UFunction>("Function AIOptimizer.AIOSubjectComponent.SetCanBeUpdatedBySubsystem");

	struct {
		bool bCanBeUpdated;
	} parms;

	parms.bCanBeUpdated = bCanBeUpdated;

	ProcessEvent(p_SetCanBeUpdatedBySubsystem, &parms);
}

void UActorComponent::ReinitializeOptimizationLayers(struct TArray<struct FAIOptimizationLayer>& NewOptimizationLayers){

	static UObject* p_ReinitializeOptimizationLayers = UObject::FindObject<UFunction>("Function AIOptimizer.AIOSubjectComponent.ReinitializeOptimizationLayers");

	struct {
		struct TArray<struct FAIOptimizationLayer>& NewOptimizationLayers;
	} parms;

	parms.NewOptimizationLayers = NewOptimizationLayers;

	ProcessEvent(p_ReinitializeOptimizationLayers, &parms);
}

void UActorComponent::RegisterSubject(){

	static UObject* p_RegisterSubject = UObject::FindObject<UFunction>("Function AIOptimizer.AIOSubjectComponent.RegisterSubject");

	struct {
	} parms;


	ProcessEvent(p_RegisterSubject, &parms);
}

float UActorComponent::IsSeenByAnyInvoker(){

	static UObject* p_IsSeenByAnyInvoker = UObject::FindObject<UFunction>("Function AIOptimizer.AIOSubjectComponent.IsSeenByAnyInvoker");

	struct {
		float return_value;
	} parms;


	ProcessEvent(p_IsSeenByAnyInvoker, &parms);
	return parms.return_value;
}

bool UActorComponent::IsDespawning(){

	static UObject* p_IsDespawning = UObject::FindObject<UFunction>("Function AIOptimizer.AIOSubjectComponent.IsDespawning");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_IsDespawning, &parms);
	return parms.return_value;
}

float UActorComponent::GetSpawnRadiusSquared(struct UAIOptimizerSubsystem* Subsystem){

	static UObject* p_GetSpawnRadiusSquared = UObject::FindObject<UFunction>("Function AIOptimizer.AIOSubjectComponent.GetSpawnRadiusSquared");

	struct {
		struct UAIOptimizerSubsystem* Subsystem;
		float return_value;
	} parms;

	parms.Subsystem = Subsystem;

	ProcessEvent(p_GetSpawnRadiusSquared, &parms);
	return parms.return_value;
}

int32_t UActorComponent::GetOptimizationLayerForCurrentDistance(){

	static UObject* p_GetOptimizationLayerForCurrentDistance = UObject::FindObject<UFunction>("Function AIOptimizer.AIOSubjectComponent.GetOptimizationLayerForCurrentDistance");

	struct {
		int32_t return_value;
	} parms;


	ProcessEvent(p_GetOptimizationLayerForCurrentDistance, &parms);
	return parms.return_value;
}

float UActorComponent::GetDistanceToClosestInvoker(){

	static UObject* p_GetDistanceToClosestInvoker = UObject::FindObject<UFunction>("Function AIOptimizer.AIOSubjectComponent.GetDistanceToClosestInvoker");

	struct {
		float return_value;
	} parms;


	ProcessEvent(p_GetDistanceToClosestInvoker, &parms);
	return parms.return_value;
}

float UActorComponent::GetDespawnRadiusSquared(struct UAIOptimizerSubsystem* Subsystem){

	static UObject* p_GetDespawnRadiusSquared = UObject::FindObject<UFunction>("Function AIOptimizer.AIOSubjectComponent.GetDespawnRadiusSquared");

	struct {
		struct UAIOptimizerSubsystem* Subsystem;
		float return_value;
	} parms;

	parms.Subsystem = Subsystem;

	ProcessEvent(p_GetDespawnRadiusSquared, &parms);
	return parms.return_value;
}

int32_t UActorComponent::GetCurrentOptimizationLayer(){

	static UObject* p_GetCurrentOptimizationLayer = UObject::FindObject<UFunction>("Function AIOptimizer.AIOSubjectComponent.GetCurrentOptimizationLayer");

	struct {
		int32_t return_value;
	} parms;


	ProcessEvent(p_GetCurrentOptimizationLayer, &parms);
	return parms.return_value;
}

struct FVector UActorComponent::GetClosestInvokerLocation(){

	static UObject* p_GetClosestInvokerLocation = UObject::FindObject<UFunction>("Function AIOptimizer.AIOSubjectComponent.GetClosestInvokerLocation");

	struct {
		struct FVector return_value;
	} parms;


	ProcessEvent(p_GetClosestInvokerLocation, &parms);
	return parms.return_value;
}

bool UActorComponent::CanBeUpdatedBySubsystem(){

	static UObject* p_CanBeUpdatedBySubsystem = UObject::FindObject<UFunction>("Function AIOptimizer.AIOSubjectComponent.CanBeUpdatedBySubsystem");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_CanBeUpdatedBySubsystem, &parms);
	return parms.return_value;
}

