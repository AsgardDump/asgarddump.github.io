#include "SDK.h" 
 
 
void UBlueprintFunctionLibrary::ExportToDisk(struct UTexture* Texture, struct FString Filename, struct FImageWriteOptions& Options){

	static UObject* p_ExportToDisk = UObject::FindObject<UFunction>("Function ImageWriteQueue.ImageWriteBlueprintLibrary.ExportToDisk");

	struct {
		struct UTexture* Texture;
		struct FString Filename;
		struct FImageWriteOptions& Options;
	} parms;

	parms.Texture = Texture;
	parms.Filename = Filename;
	parms.Options = Options;

	ProcessEvent(p_ExportToDisk, &parms);
}

