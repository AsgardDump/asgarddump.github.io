#pragma once 
#include <KeyboardKey_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass KeyboardKey.KeyboardKey_C
// Size: 0x2A8(Inherited: 0x260) 
struct UKeyboardKey_C : public UUserWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x260(0x8)
	struct UCanvasPanel* CanvasPanel_1;  // 0x268(0x8)
	struct UImage* Image;  // 0x270(0x8)
	struct UImage* Image_73;  // 0x278(0x8)
	struct UTexture2D* KeyTexture;  // 0x280(0x8)
	struct FVector2D KeySize;  // 0x288(0x8)
	struct FLinearColor Specified Color;  // 0x290(0x10)
	struct UKeyBoardShow_C* KeyBoardShow;  // 0x2A0(0x8)

	void PreConstruct(bool IsDesignTime); // Function KeyboardKey.KeyboardKey_C.PreConstruct
	void ExecuteUbergraph_KeyboardKey(int32_t EntryPoint); // Function KeyboardKey.KeyboardKey_C.ExecuteUbergraph_KeyboardKey
}; 



