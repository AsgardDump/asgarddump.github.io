#pragma once 
#include "SDK.h" 
 
 
// ScriptStruct GameMap_Struct.GameMap_Struct
// Size: 0x98(Inherited: 0x0) 
struct FGameMap_Struct
{
	struct TArray<struct UTexture2D*> ;  // 0x0(0x10)
	struct FText ;  // 0x10(0x18)
	struct FText ;  // 0x28(0x18)
	struct FText ;  // 0x40(0x18)
	struct FText ;  // 0x58(0x18)
	struct TSoftObjectPtr<UObject> level_24_A8E8775B4260002057E79C9B9C3770EA;  // 0x70(0x28)

}; 
