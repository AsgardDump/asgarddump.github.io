#pragma once 
#include <AIBulletMaster_BP_Structs.h>
 
 
 
// DynamicClass AIBulletMaster_BP.AIBulletMaster_BP_C
// Size: 0x398(Inherited: 0x220) 
struct AAIBulletMaster_BP_C : public AActor
{
	struct USphereComponent* Sphere;  // 0x220(0x8)
	struct UProjectileMovementComponent* ProjectileMovement;  // 0x228(0x8)
	struct USoundBase* Sound;  // 0x230(0x8)
	struct UPrimitiveComponent* K2Node_Event_MyComp;  // 0x238(0x8)
	struct AActor* K2Node_Event_Other;  // 0x240(0x8)
	struct UPrimitiveComponent* K2Node_Event_OtherComp;  // 0x248(0x8)
	char pad_592_1 : 7;  // 0x250(0x1)
	bool K2Node_Event_bSelfMoved : 1;  // 0x250(0x1)
	char pad_593[3];  // 0x251(0x3)
	struct FVector K2Node_Event_HitLocation;  // 0x254(0xC)
	struct FVector K2Node_Event_HitNormal;  // 0x260(0xC)
	struct FVector K2Node_Event_NormalImpulse;  // 0x26C(0xC)
	struct FHitResult K2Node_Event_Hit;  // 0x278(0x88)
	char pad_768_1 : 7;  // 0x300(0x1)
	bool CallFunc_BreakHitResult_bBlockingHit : 1;  // 0x300(0x1)
	char pad_769_1 : 7;  // 0x301(0x1)
	bool CallFunc_BreakHitResult_bInitialOverlap : 1;  // 0x301(0x1)
	char pad_770[2];  // 0x302(0x2)
	float CallFunc_BreakHitResult_Time;  // 0x304(0x4)
	float CallFunc_BreakHitResult_Distance;  // 0x308(0x4)
	struct FVector CallFunc_BreakHitResult_Location;  // 0x30C(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactPoint;  // 0x318(0xC)
	struct FVector CallFunc_BreakHitResult_Normal;  // 0x324(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactNormal;  // 0x330(0xC)
	char pad_828[4];  // 0x33C(0x4)
	struct UPhysicalMaterial* CallFunc_BreakHitResult_PhysMat;  // 0x340(0x8)
	struct AActor* CallFunc_BreakHitResult_HitActor;  // 0x348(0x8)
	struct UPrimitiveComponent* CallFunc_BreakHitResult_HitComponent;  // 0x350(0x8)
	struct FName CallFunc_BreakHitResult_HitBoneName;  // 0x358(0x8)
	int32_t CallFunc_BreakHitResult_HitItem;  // 0x360(0x4)
	int32_t CallFunc_BreakHitResult_ElementIndex;  // 0x364(0x4)
	int32_t CallFunc_BreakHitResult_FaceIndex;  // 0x368(0x4)
	struct FVector CallFunc_BreakHitResult_TraceStart;  // 0x36C(0xC)
	struct FVector CallFunc_BreakHitResult_TraceEnd;  // 0x378(0xC)
	char pad_900[4];  // 0x384(0x4)
	struct AZombie_BP_C* K2Node_DynamicCast_AsZombie_BP;  // 0x388(0x8)
	char pad_912_1 : 7;  // 0x390(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x390(0x1)
	char pad_913_1 : 7;  // 0x391(0x1)
	bool ___bool_Has_Been_Initd_Variable : 1;  // 0x391(0x1)
	char pad_914_1 : 7;  // 0x392(0x1)
	bool ___bool_IsClosed_Variable : 1;  // 0x392(0x1)
	char pad_915[5];  // 0x393(0x5)

	void ReceiveHit(struct UPrimitiveComponent* bpp__MyComp__pf, struct AActor* bpp__Other__pf, struct UPrimitiveComponent* bpp__OtherComp__pf, bool bpp__bSelfMoved__pf, struct FVector bpp__HitLocation__pf, struct FVector bpp__HitNormal__pf, struct FVector bpp__NormalImpulse__pf, struct FHitResult& bpp__Hit__pf__const); // Function AIBulletMaster_BP.AIBulletMaster_BP_C.ReceiveHit
	void ReceiveBeginPlay(); // Function AIBulletMaster_BP.AIBulletMaster_BP_C.ReceiveBeginPlay
	void ExecuteUbergraph_AIBulletMaster_BP_2(int32_t bpp__EntryPoint__pf); // Function AIBulletMaster_BP.AIBulletMaster_BP_C.ExecuteUbergraph_AIBulletMaster_BP_2
}; 



