#pragma once 
#include "SDK.h" 
 
 
// Function AmmoSpawner.AmmoSpawner_C.ExecuteUbergraph_AmmoSpawner
// Size: 0x70(Inherited: 0x0) 
struct FExecuteUbergraph_AmmoSpawner
{
	int32_t EntryPoint;  // 0x0(0x4)
	int32_t ___int_Variable;  // 0x4(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x8(0x4)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0xC(0xC)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_LessEqual_IntInt_ReturnValue : 1;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)
	struct FVector CallFunc_K2_GetRandomPointInNavigableRadius_RandomLocation;  // 0x1C(0xC)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool CallFunc_K2_GetRandomPointInNavigableRadius_ReturnValue : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct FTransform CallFunc_Conv_VectorToTransform_ReturnValue;  // 0x30(0x30)
	struct AActor* CallFunc_BeginDeferredActorSpawnFromClass_ReturnValue;  // 0x60(0x8)
	struct ANewAmmo_BP_C* CallFunc_FinishSpawningActor_ReturnValue;  // 0x68(0x8)

}; 
