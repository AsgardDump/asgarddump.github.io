#include "SDK.h" 
 
 
void AActor::ReceiveBeginPlay(){

	static UObject* p_ReceiveBeginPlay = UObject::FindObject<UFunction>("Function AmmoSpawner.AmmoSpawner_C.ReceiveBeginPlay");

	struct {
	} parms;


	ProcessEvent(p_ReceiveBeginPlay, &parms);
}

void AActor::(){

	static UObject* p_ = UObject::FindObject<UFunction>("Function AmmoSpawner.AmmoSpawner_C.");

	struct {
	} parms;


	ProcessEvent(p_, &parms);
}

void AActor::ExecuteUbergraph_AmmoSpawner(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph_AmmoSpawner = UObject::FindObject<UFunction>("Function AmmoSpawner.AmmoSpawner_C.ExecuteUbergraph_AmmoSpawner");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph_AmmoSpawner, &parms);
}

