#include "SDK.h" 
 
 
uint8_t  UUserWidget::GetVisibility_1(){

	static UObject* p_GetVisibility_1 = UObject::FindObject<UFunction>("Function Fail.Fail_C.GetVisibility_1");

	struct {
		uint8_t  return_value;
	} parms;


	ProcessEvent(p_GetVisibility_1, &parms);
	return parms.return_value;
}

void UUserWidget::Construct(){

	static UObject* p_Construct = UObject::FindObject<UFunction>("Function Fail.Fail_C.Construct");

	struct {
	} parms;


	ProcessEvent(p_Construct, &parms);
}

void UUserWidget::ReStart(){

	static UObject* p_ReStart = UObject::FindObject<UFunction>("Function Fail.Fail_C.ReStart");

	struct {
	} parms;


	ProcessEvent(p_ReStart, &parms);
}

void UUserWidget::quit(){

	static UObject* p_quit = UObject::FindObject<UFunction>("Function Fail.Fail_C.quit");

	struct {
	} parms;


	ProcessEvent(p_quit, &parms);
}

void UUserWidget::ExecuteUbergraph_Fail(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph_Fail = UObject::FindObject<UFunction>("Function Fail.Fail_C.ExecuteUbergraph_Fail");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph_Fail, &parms);
}

