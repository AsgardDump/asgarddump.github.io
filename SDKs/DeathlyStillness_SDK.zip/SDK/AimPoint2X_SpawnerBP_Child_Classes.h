#pragma once 
#include <AimPoint2X_SpawnerBP_Child_Structs.h>
 
 
 
// BlueprintGeneratedClass AimPoint2X_SpawnerBP_Child.AimPoint2X_SpawnerBP_Child_C
// Size: 0x258(Inherited: 0x258) 
struct AAimPoint2X_SpawnerBP_Child_C : public AOpticsMaster_SpawnerBP_C
{

}; 



