#pragma once 
#include "SDK.h" 
 
 
// Function Entity_RandomMove.Entity_RandomMove_C.ExecuteUbergraph_Entity_RandomMove
// Size: 0x21(Inherited: 0x0) 
struct FExecuteUbergraph_Entity_RandomMove
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AAIController* K2Node_Event_OwnerController;  // 0x8(0x8)
	struct APawn* K2Node_Event_ControlledPawn;  // 0x10(0x8)
	struct ABP_Entity_Pawn_C* K2Node_DynamicCast_AsBP_Entity_Pawn;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x20(0x1)

}; 
// Function Entity_RandomMove.Entity_RandomMove_C.ReceiveExecuteAI
// Size: 0x10(Inherited: 0x10) 
struct FReceiveExecuteAI : public FReceiveExecuteAI
{
	struct AAIController* OwnerController;  // 0x0(0x8)
	struct APawn* ControlledPawn;  // 0x8(0x8)

}; 
