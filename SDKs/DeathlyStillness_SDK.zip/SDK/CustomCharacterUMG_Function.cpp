#include "SDK.h" 
 
 
void UUserWidget::(struct TMap<struct UTexture2D*, struct USkeletalMesh*>& TargetMap, char CustomCharacterEnum CustomCharacterEnum){

	static UObject* p_ = UObject::FindObject<UFunction>("Function CustomCharacterUMG.CustomCharacterUMG_C.");

	struct {
		struct TMap<struct UTexture2D*, struct USkeletalMesh*>& TargetMap;
		char CustomCharacterEnum CustomCharacterEnum;
	} parms;

	parms.TargetMap = TargetMap;
	parms.CustomCharacterEnum = CustomCharacterEnum;

	ProcessEvent(p_, &parms);
}

void UUserWidget::(struct TMap<struct UTexture2D*, struct UMaterialInterface*>& TargetMap, char CustomCharacterEnum CustomCharacterEnum){

	static UObject* p_ = UObject::FindObject<UFunction>("Function CustomCharacterUMG.CustomCharacterUMG_C.");

	struct {
		struct TMap<struct UTexture2D*, struct UMaterialInterface*>& TargetMap;
		char CustomCharacterEnum CustomCharacterEnum;
	} parms;

	parms.TargetMap = TargetMap;
	parms.CustomCharacterEnum = CustomCharacterEnum;

	ProcessEvent(p_, &parms);
}

void UUserWidget::(){

	static UObject* p_ = UObject::FindObject<UFunction>("Function CustomCharacterUMG.CustomCharacterUMG_C.");

	struct {
	} parms;


	ProcessEvent(p_, &parms);
}

void UUserWidget::Cloth1Click(){

	static UObject* p_Cloth1Click = UObject::FindObject<UFunction>("Function CustomCharacterUMG.CustomCharacterUMG_C.Cloth1Click");

	struct {
	} parms;


	ProcessEvent(p_Cloth1Click, &parms);
}

void UUserWidget::Cloth2Click(){

	static UObject* p_Cloth2Click = UObject::FindObject<UFunction>("Function CustomCharacterUMG.CustomCharacterUMG_C.Cloth2Click");

	struct {
	} parms;


	ProcessEvent(p_Cloth2Click, &parms);
}

void UUserWidget::Cloth3Click(){

	static UObject* p_Cloth3Click = UObject::FindObject<UFunction>("Function CustomCharacterUMG.CustomCharacterUMG_C.Cloth3Click");

	struct {
	} parms;


	ProcessEvent(p_Cloth3Click, &parms);
}

void UUserWidget::Cloth4Click(){

	static UObject* p_Cloth4Click = UObject::FindObject<UFunction>("Function CustomCharacterUMG.CustomCharacterUMG_C.Cloth4Click");

	struct {
	} parms;


	ProcessEvent(p_Cloth4Click, &parms);
}

void UUserWidget::(){

	static UObject* p_ = UObject::FindObject<UFunction>("Function CustomCharacterUMG.CustomCharacterUMG_C.");

	struct {
	} parms;


	ProcessEvent(p_, &parms);
}

void UUserWidget::(){

	static UObject* p_ = UObject::FindObject<UFunction>("Function CustomCharacterUMG.CustomCharacterUMG_C.");

	struct {
	} parms;


	ProcessEvent(p_, &parms);
}

void UUserWidget::Shoes1Click(){

	static UObject* p_Shoes1Click = UObject::FindObject<UFunction>("Function CustomCharacterUMG.CustomCharacterUMG_C.Shoes1Click");

	struct {
	} parms;


	ProcessEvent(p_Shoes1Click, &parms);
}

void UUserWidget::Shoes2Click(){

	static UObject* p_Shoes2Click = UObject::FindObject<UFunction>("Function CustomCharacterUMG.CustomCharacterUMG_C.Shoes2Click");

	struct {
	} parms;


	ProcessEvent(p_Shoes2Click, &parms);
}

void UUserWidget::Shoes3Click(){

	static UObject* p_Shoes3Click = UObject::FindObject<UFunction>("Function CustomCharacterUMG.CustomCharacterUMG_C.Shoes3Click");

	struct {
	} parms;


	ProcessEvent(p_Shoes3Click, &parms);
}

void UUserWidget::(){

	static UObject* p_ = UObject::FindObject<UFunction>("Function CustomCharacterUMG.CustomCharacterUMG_C.");

	struct {
	} parms;


	ProcessEvent(p_, &parms);
}

void UUserWidget::Hair1Click(){

	static UObject* p_Hair1Click = UObject::FindObject<UFunction>("Function CustomCharacterUMG.CustomCharacterUMG_C.Hair1Click");

	struct {
	} parms;


	ProcessEvent(p_Hair1Click, &parms);
}

void UUserWidget::Hair2Click(){

	static UObject* p_Hair2Click = UObject::FindObject<UFunction>("Function CustomCharacterUMG.CustomCharacterUMG_C.Hair2Click");

	struct {
	} parms;


	ProcessEvent(p_Hair2Click, &parms);
}

void UUserWidget::Hair3Click(){

	static UObject* p_Hair3Click = UObject::FindObject<UFunction>("Function CustomCharacterUMG.CustomCharacterUMG_C.Hair3Click");

	struct {
	} parms;


	ProcessEvent(p_Hair3Click, &parms);
}

void UUserWidget::Pant1Click(){

	static UObject* p_Pant1Click = UObject::FindObject<UFunction>("Function CustomCharacterUMG.CustomCharacterUMG_C.Pant1Click");

	struct {
	} parms;


	ProcessEvent(p_Pant1Click, &parms);
}

void UUserWidget::Pant2Click(){

	static UObject* p_Pant2Click = UObject::FindObject<UFunction>("Function CustomCharacterUMG.CustomCharacterUMG_C.Pant2Click");

	struct {
	} parms;


	ProcessEvent(p_Pant2Click, &parms);
}

void UUserWidget::Pant3Click(){

	static UObject* p_Pant3Click = UObject::FindObject<UFunction>("Function CustomCharacterUMG.CustomCharacterUMG_C.Pant3Click");

	struct {
	} parms;


	ProcessEvent(p_Pant3Click, &parms);
}

void UUserWidget::Pant4Click(){

	static UObject* p_Pant4Click = UObject::FindObject<UFunction>("Function CustomCharacterUMG.CustomCharacterUMG_C.Pant4Click");

	struct {
	} parms;


	ProcessEvent(p_Pant4Click, &parms);
}

void UUserWidget::(){

	static UObject* p_ = UObject::FindObject<UFunction>("Function CustomCharacterUMG.CustomCharacterUMG_C.");

	struct {
	} parms;


	ProcessEvent(p_, &parms);
}

void UUserWidget::ManCloth1Click(){

	static UObject* p_ManCloth1Click = UObject::FindObject<UFunction>("Function CustomCharacterUMG.CustomCharacterUMG_C.ManCloth1Click");

	struct {
	} parms;


	ProcessEvent(p_ManCloth1Click, &parms);
}

void UUserWidget::ManCloth2Click(){

	static UObject* p_ManCloth2Click = UObject::FindObject<UFunction>("Function CustomCharacterUMG.CustomCharacterUMG_C.ManCloth2Click");

	struct {
	} parms;


	ProcessEvent(p_ManCloth2Click, &parms);
}

void UUserWidget::ManCloth3Click(){

	static UObject* p_ManCloth3Click = UObject::FindObject<UFunction>("Function CustomCharacterUMG.CustomCharacterUMG_C.ManCloth3Click");

	struct {
	} parms;


	ProcessEvent(p_ManCloth3Click, &parms);
}

void UUserWidget::ManCloth4Click(){

	static UObject* p_ManCloth4Click = UObject::FindObject<UFunction>("Function CustomCharacterUMG.CustomCharacterUMG_C.ManCloth4Click");

	struct {
	} parms;


	ProcessEvent(p_ManCloth4Click, &parms);
}

void UUserWidget::ManCloth5Click(){

	static UObject* p_ManCloth5Click = UObject::FindObject<UFunction>("Function CustomCharacterUMG.CustomCharacterUMG_C.ManCloth5Click");

	struct {
	} parms;


	ProcessEvent(p_ManCloth5Click, &parms);
}

void UUserWidget::(){

	static UObject* p_ = UObject::FindObject<UFunction>("Function CustomCharacterUMG.CustomCharacterUMG_C.");

	struct {
	} parms;


	ProcessEvent(p_, &parms);
}

void UUserWidget::BunnyGirlHair1Click(){

	static UObject* p_BunnyGirlHair1Click = UObject::FindObject<UFunction>("Function CustomCharacterUMG.CustomCharacterUMG_C.BunnyGirlHair1Click");

	struct {
	} parms;


	ProcessEvent(p_BunnyGirlHair1Click, &parms);
}

void UUserWidget::BunnyGirlHair2Click(){

	static UObject* p_BunnyGirlHair2Click = UObject::FindObject<UFunction>("Function CustomCharacterUMG.CustomCharacterUMG_C.BunnyGirlHair2Click");

	struct {
	} parms;


	ProcessEvent(p_BunnyGirlHair2Click, &parms);
}

void UUserWidget::BunnyGirlHair3Click(){

	static UObject* p_BunnyGirlHair3Click = UObject::FindObject<UFunction>("Function CustomCharacterUMG.CustomCharacterUMG_C.BunnyGirlHair3Click");

	struct {
	} parms;


	ProcessEvent(p_BunnyGirlHair3Click, &parms);
}

void UUserWidget::(){

	static UObject* p_ = UObject::FindObject<UFunction>("Function CustomCharacterUMG.CustomCharacterUMG_C.");

	struct {
	} parms;


	ProcessEvent(p_, &parms);
}

void UUserWidget::(){

	static UObject* p_ = UObject::FindObject<UFunction>("Function CustomCharacterUMG.CustomCharacterUMG_C.");

	struct {
	} parms;


	ProcessEvent(p_, &parms);
}

void UUserWidget::SchoolGirlPant1Click(){

	static UObject* p_SchoolGirlPant1Click = UObject::FindObject<UFunction>("Function CustomCharacterUMG.CustomCharacterUMG_C.SchoolGirlPant1Click");

	struct {
	} parms;


	ProcessEvent(p_SchoolGirlPant1Click, &parms);
}

void UUserWidget::SchoolGirlPant2Click(){

	static UObject* p_SchoolGirlPant2Click = UObject::FindObject<UFunction>("Function CustomCharacterUMG.CustomCharacterUMG_C.SchoolGirlPant2Click");

	struct {
	} parms;


	ProcessEvent(p_SchoolGirlPant2Click, &parms);
}

void UUserWidget::SchoolGirlPant3Click(){

	static UObject* p_SchoolGirlPant3Click = UObject::FindObject<UFunction>("Function CustomCharacterUMG.CustomCharacterUMG_C.SchoolGirlPant3Click");

	struct {
	} parms;


	ProcessEvent(p_SchoolGirlPant3Click, &parms);
}

void UUserWidget::SchoolGirCloth1Click(){

	static UObject* p_SchoolGirCloth1Click = UObject::FindObject<UFunction>("Function CustomCharacterUMG.CustomCharacterUMG_C.SchoolGirCloth1Click");

	struct {
	} parms;


	ProcessEvent(p_SchoolGirCloth1Click, &parms);
}

void UUserWidget::SchoolGirCloth2Click(){

	static UObject* p_SchoolGirCloth2Click = UObject::FindObject<UFunction>("Function CustomCharacterUMG.CustomCharacterUMG_C.SchoolGirCloth2Click");

	struct {
	} parms;


	ProcessEvent(p_SchoolGirCloth2Click, &parms);
}

void UUserWidget::SchoolGirCloth3Click(){

	static UObject* p_SchoolGirCloth3Click = UObject::FindObject<UFunction>("Function CustomCharacterUMG.CustomCharacterUMG_C.SchoolGirCloth3Click");

	struct {
	} parms;


	ProcessEvent(p_SchoolGirCloth3Click, &parms);
}

void UUserWidget::SchoolGirCloth4Click(){

	static UObject* p_SchoolGirCloth4Click = UObject::FindObject<UFunction>("Function CustomCharacterUMG.CustomCharacterUMG_C.SchoolGirCloth4Click");

	struct {
	} parms;


	ProcessEvent(p_SchoolGirCloth4Click, &parms);
}

void UUserWidget::(){

	static UObject* p_ = UObject::FindObject<UFunction>("Function CustomCharacterUMG.CustomCharacterUMG_C.");

	struct {
	} parms;


	ProcessEvent(p_, &parms);
}

void UUserWidget::Construct(){

	static UObject* p_Construct = UObject::FindObject<UFunction>("Function CustomCharacterUMG.CustomCharacterUMG_C.Construct");

	struct {
	} parms;


	ProcessEvent(p_Construct, &parms);
}

void UUserWidget::(){

	static UObject* p_ = UObject::FindObject<UFunction>("Function CustomCharacterUMG.CustomCharacterUMG_C.");

	struct {
	} parms;


	ProcessEvent(p_, &parms);
}

void UUserWidget::SchoolGirSockClick(){

	static UObject* p_SchoolGirSockClick = UObject::FindObject<UFunction>("Function CustomCharacterUMG.CustomCharacterUMG_C.SchoolGirSockClick");

	struct {
	} parms;


	ProcessEvent(p_SchoolGirSockClick, &parms);
}

void UUserWidget::BunnyGirlHair4Click(){

	static UObject* p_BunnyGirlHair4Click = UObject::FindObject<UFunction>("Function CustomCharacterUMG.CustomCharacterUMG_C.BunnyGirlHair4Click");

	struct {
	} parms;


	ProcessEvent(p_BunnyGirlHair4Click, &parms);
}

void UUserWidget::(){

	static UObject* p_ = UObject::FindObject<UFunction>("Function CustomCharacterUMG.CustomCharacterUMG_C.");

	struct {
	} parms;


	ProcessEvent(p_, &parms);
}

void UUserWidget::ExecuteUbergraph_CustomCharacterUMG(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph_CustomCharacterUMG = UObject::FindObject<UFunction>("Function CustomCharacterUMG.CustomCharacterUMG_C.ExecuteUbergraph_CustomCharacterUMG");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph_CustomCharacterUMG, &parms);
}

