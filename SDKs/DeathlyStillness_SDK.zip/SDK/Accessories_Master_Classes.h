#pragma once 
#include <Accessories_Master_Structs.h>
 
 
 
// BlueprintGeneratedClass Accessories_Master.Accessories_Master_C
// Size: 0x231(Inherited: 0x220) 
struct AAccessories_Master_C : public AActor
{
	struct USceneComponent* DefaultSceneRoot;  // 0x220(0x8)
	AActor* SpawnAccessoriesClass;  // 0x228(0x8)
	char Optics_Enum AccessoriesType;  // 0x230(0x1)

}; 



