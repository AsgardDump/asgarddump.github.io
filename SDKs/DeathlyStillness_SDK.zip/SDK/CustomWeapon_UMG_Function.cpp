#include "SDK.h" 
 
 
void UUserWidget::(){

	static UObject* p_ = UObject::FindObject<UFunction>("Function CustomWeapon_UMG.CustomWeapon_UMG_C.");

	struct {
	} parms;


	ProcessEvent(p_, &parms);
}

void UUserWidget::(){

	static UObject* p_ = UObject::FindObject<UFunction>("Function CustomWeapon_UMG.CustomWeapon_UMG_C.");

	struct {
	} parms;


	ProcessEvent(p_, &parms);
}

void UUserWidget::(char WeaponType WeaponType){

	static UObject* p_ = UObject::FindObject<UFunction>("Function CustomWeapon_UMG.CustomWeapon_UMG_C.");

	struct {
		char WeaponType WeaponType;
	} parms;

	parms.WeaponType = WeaponType;

	ProcessEvent(p_, &parms);
}

void UUserWidget::(char WeaponType WeaponType, char AccessoriesType AccessoriesType){

	static UObject* p_ = UObject::FindObject<UFunction>("Function CustomWeapon_UMG.CustomWeapon_UMG_C.");

	struct {
		char WeaponType WeaponType;
		char AccessoriesType AccessoriesType;
	} parms;

	parms.WeaponType = WeaponType;
	parms.AccessoriesType = AccessoriesType;

	ProcessEvent(p_, &parms);
}

void UUserWidget::(){

	static UObject* p_ = UObject::FindObject<UFunction>("Function CustomWeapon_UMG.CustomWeapon_UMG_C.");

	struct {
	} parms;


	ProcessEvent(p_, &parms);
}

void UUserWidget::ExecuteUbergraph_CustomWeapon_UMG(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph_CustomWeapon_UMG = UObject::FindObject<UFunction>("Function CustomWeapon_UMG.CustomWeapon_UMG_C.ExecuteUbergraph_CustomWeapon_UMG");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph_CustomWeapon_UMG, &parms);
}

