#pragma once 
#include <CloseHit_Structs.h>
 
 
 
// BlueprintGeneratedClass CloseHit.CloseHit_C
// Size: 0x3C(Inherited: 0x38) 
struct UCloseHit_C : public UAnimNotify
{
	float Scale;  // 0x38(0x4)

	bool Received_Notify(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation); // Function CloseHit.CloseHit_C.Received_Notify
}; 



