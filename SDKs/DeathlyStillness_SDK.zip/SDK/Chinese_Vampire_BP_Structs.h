#pragma once 
#include "SDK.h" 
 
 
// Function Chinese_Vampire_BP.Chinese_Vampire_BP_C.OnFail_2180E67C465A2F1B00043781C4893172
// Size: 0x1(Inherited: 0x0) 
struct FOnFail_2180E67C465A2F1B00043781C4893172
{
	char EPathFollowingResult bpp__MovementResult__pf;  // 0x0(0x1)

}; 
// DelegateFunction Chinese_Vampire_BP.Chinese_Vampire_BP_C.OAISimpleDelegate__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FOAISimpleDelegate__DelegateSignature
{
	char EPathFollowingResult bpp__MovementResult__pf;  // 0x0(0x1)

}; 
// Function Chinese_Vampire_BP.Chinese_Vampire_BP_C.CustomMappingCheck
// Size: 0x50(Inherited: 0x0) 
struct FCustomMappingCheck
{
	struct FInputActionKeyMapping bpp__InputAction__pf;  // 0x0(0x28)
	struct FInputAxisKeyMapping bpp__InputAxis__pf;  // 0x28(0x28)

}; 
// Function Chinese_Vampire_BP.Chinese_Vampire_BP_C.DamageHit
// Size: 0x90(Inherited: 0x0) 
struct FDamageHit
{
	struct FHitResult bpp__Hit__pf;  // 0x0(0x88)
	float bpp__Damage__pf;  // 0x88(0x4)
	char pad_140_1 : 7;  // 0x8C(0x1)
	bool bpp__isMeleex__pfzy : 1;  // 0x8C(0x1)
	char pad_141[3];  // 0x8D(0x3)

}; 
// Function Chinese_Vampire_BP.Chinese_Vampire_BP_C.ExecuteUbergraph_Chinese_Vampire_BP_2
// Size: 0x4(Inherited: 0x0) 
struct FExecuteUbergraph_Chinese_Vampire_BP_2
{
	int32_t bpp__EntryPoint__pf;  // 0x0(0x4)

}; 
// Function Chinese_Vampire_BP.Chinese_Vampire_BP_C.ExecuteUbergraph_Chinese_Vampire_BP_3
// Size: 0x4(Inherited: 0x0) 
struct FExecuteUbergraph_Chinese_Vampire_BP_3
{
	int32_t bpp__EntryPoint__pf;  // 0x0(0x4)

}; 
// Function Chinese_Vampire_BP.Chinese_Vampire_BP_C.ReceiveTick
// Size: 0x4(Inherited: 0x0) 
struct FReceiveTick
{
	float bpp__DeltaSeconds__pf;  // 0x0(0x4)

}; 
// Function Chinese_Vampire_BP.Chinese_Vampire_BP_C.OnSuccess_2180E67C465A2F1B00043781C4893172
// Size: 0x1(Inherited: 0x0) 
struct FOnSuccess_2180E67C465A2F1B00043781C4893172
{
	char EPathFollowingResult bpp__MovementResult__pf;  // 0x0(0x1)

}; 
// Function Chinese_Vampire_BP.Chinese_Vampire_BP_C.SettingDetails
// Size: 0x30(Inherited: 0x0) 
struct FSettingDetails
{
	struct FText bpp__xx__pfGHtv8q__const;  // 0x0(0x18)
	struct FText bpp__xx__pfVyqlkt__const;  // 0x18(0x18)

}; 
// Function Chinese_Vampire_BP.Chinese_Vampire_BP_C.
// Size: 0x3(Inherited: 0x0) 
struct F
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bpp__xxxxxxx__pf23uLQtBkqzKtNZubiq6fu : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool bpp__xxxxxxxxxx__pfxruvQs2ZtvgusPuketOFqOLsLQtBkq : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool bpp__xxxxxxxYaw__pfxruvQs2ZtvgusPuLQtBkq : 1;  // 0x2(0x1)

}; 
