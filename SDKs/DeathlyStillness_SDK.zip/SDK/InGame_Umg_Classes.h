#pragma once 
#include <InGame_Umg_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass InGame_Umg.InGame_Umg_C
// Size: 0x3C8(Inherited: 0x260) 
struct UInGame_Umg_C : public UUserWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x260(0x8)
	struct UWidgetAnimation* ;  // 0x268(0x8)
	struct UWidgetAnimation* _1;  // 0x270(0x8)
	struct UWidgetAnimation* ZombieDead;  // 0x278(0x8)
	struct UWidgetAnimation* ;  // 0x280(0x8)
	struct UWidgetAnimation* HitHeadTip;  // 0x288(0x8)
	struct UWidgetAnimation* Dead;  // 0x290(0x8)
	struct UWidgetAnimation* Kick;  // 0x298(0x8)
	struct UWidgetAnimation* HitMarkerAnimation;  // 0x2A0(0x8)
	struct UWidgetAnimation* HitMarkerAnimationHead;  // 0x2A8(0x8)
	struct UWidgetAnimation* QuestStart;  // 0x2B0(0x8)
	struct UWidgetAnimation* Quest;  // 0x2B8(0x8)
	struct UWidgetAnimation* ScreenDamage;  // 0x2C0(0x8)
	struct UCanvasPanel* CrossHair;  // 0x2C8(0x8)
	struct UImage* DotCrosshair;  // 0x2D0(0x8)
	struct UImage* Down;  // 0x2D8(0x8)
	struct UCanvasPanel* Health;  // 0x2E0(0x8)
	struct UImage* HitMarker;  // 0x2E8(0x8)
	struct UImage* Image;  // 0x2F0(0x8)
	struct UImage* Image_1;  // 0x2F8(0x8)
	struct UImage* Image_11;  // 0x300(0x8)
	struct UImage* Image_50;  // 0x308(0x8)
	struct UImage* Image_88;  // 0x310(0x8)
	struct UImage* Image_89;  // 0x318(0x8)
	struct UImage* Image_263;  // 0x320(0x8)
	struct UImage* Left;  // 0x328(0x8)
	struct UOverlay* melee;  // 0x330(0x8)
	struct UProgressBar* ProgressBar_186;  // 0x338(0x8)
	struct UImage* Right;  // 0x340(0x8)
	struct UTextBlock* TextBlock_2;  // 0x348(0x8)
	struct UTextBlock* TextBlock_3;  // 0x350(0x8)
	struct UTextBlock* TextBlock_4;  // 0x358(0x8)
	struct UTextBlock* TextBlock_5;  // 0x360(0x8)
	struct UTextBlock* TextBlock_209;  // 0x368(0x8)
	struct UTextBlock* TextBlock_347;  // 0x370(0x8)
	struct UTextBlock* TextBlock_414;  // 0x378(0x8)
	struct UTextBlock* TextBlock_465;  // 0x380(0x8)
	struct UTextBlock* TextBlock_650;  // 0x388(0x8)
	struct UImage* Top;  // 0x390(0x8)
	struct UTextBlock* ;  // 0x398(0x8)
	struct APlayer_BP_C* PlayerRef;  // 0x3A0(0x8)
	int32_t ZombieNum;  // 0x3A8(0x4)
	char pad_940[4];  // 0x3AC(0x4)
	struct FText ;  // 0x3B0(0x18)

	struct FText GetText_3(); // Function InGame_Umg.InGame_Umg_C.GetText_3
	struct FText GetText_1(); // Function InGame_Umg.InGame_Umg_C.GetText_1
	struct FLinearColor GetFillColorAndOpacity_1(); // Function InGame_Umg.InGame_Umg_C.GetFillColorAndOpacity_1
	float GetPercent_1(); // Function InGame_Umg.InGame_Umg_C.GetPercent_1
	struct FText GetText_2(); // Function InGame_Umg.InGame_Umg_C.GetText_2
	void QuestTip_Evenet(); // Function InGame_Umg.InGame_Umg_C.QuestTip_Evenet
	void QuestStart_Event(); // Function InGame_Umg.InGame_Umg_C.QuestStart_Event
	void HitHead(); // Function InGame_Umg.InGame_Umg_C.HitHead
	void HitZombie(); // Function InGame_Umg.InGame_Umg_C.HitZombie
	void DamageEffect(); // Function InGame_Umg.InGame_Umg_C.DamageEffect
	void (char EUMGSequencePlayMode PlayMode); // Function InGame_Umg.InGame_Umg_C.
	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Function InGame_Umg.InGame_Umg_C.Tick
	void DeadScreen(char EUMGSequencePlayMode PlayMode); // Function InGame_Umg.InGame_Umg_C.DeadScreen
	void (uint8_t  , uint8_t  DOT); // Function InGame_Umg.InGame_Umg_C.
	void (); // Function InGame_Umg.InGame_Umg_C.
	void (); // Function InGame_Umg.InGame_Umg_C.
	void (char EUMGSequencePlayMode PlayMode); // Function InGame_Umg.InGame_Umg_C.
	void (); // Function InGame_Umg.InGame_Umg_C.
	void Construct(); // Function InGame_Umg.InGame_Umg_C.Construct
	void CrosshairFade_Event(char EUMGSequencePlayMode PlayMode); // Function InGame_Umg.InGame_Umg_C.CrosshairFade_Event
	void (); // Function InGame_Umg.InGame_Umg_C.
	void (); // Function InGame_Umg.InGame_Umg_C.
	void ExecuteUbergraph_InGame_Umg(int32_t EntryPoint); // Function InGame_Umg.InGame_Umg_C.ExecuteUbergraph_InGame_Umg
}; 



