#pragma once 
#include "SDK.h" 
 
 
// ScriptStruct DatasmithCore.DatasmithMeshSourceModel
// Size: 0x40(Inherited: 0x0) 
struct FDatasmithMeshSourceModel
{
	char pad_0[64];  // 0x0(0x40)

}; 
