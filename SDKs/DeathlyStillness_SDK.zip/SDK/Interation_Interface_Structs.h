#pragma once 
#include "SDK.h" 
 
 
// Function Interation_Interface.Interation_Interface_C.OpenDoor
// Size: 0x8(Inherited: 0x0) 
struct FOpenDoor
{
	struct APUBG_BaseCharacter_BP_C* Player;  // 0x0(0x8)

}; 
// Function Interation_Interface.Interation_Interface_C.PickUp
// Size: 0x8(Inherited: 0x0) 
struct FPickUp
{
	struct APUBG_BaseCharacter_BP_C* Player;  // 0x0(0x8)

}; 
