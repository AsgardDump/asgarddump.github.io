#include "SDK.h" 
 
 
void AActor::(){

	static UObject* p_ = UObject::FindObject<UFunction>("Function Clip_Master.Clip_Master_C.");

	struct {
	} parms;


	ProcessEvent(p_, &parms);
}

void AActor::ExecuteUbergraph_Clip_Master(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph_Clip_Master = UObject::FindObject<UFunction>("Function Clip_Master.Clip_Master_C.ExecuteUbergraph_Clip_Master");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph_Clip_Master, &parms);
}

