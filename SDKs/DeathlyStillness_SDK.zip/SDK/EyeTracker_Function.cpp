#include "SDK.h" 
 
 
void UBlueprintFunctionLibrary::SetEyeTrackedPlayer(struct APlayerController* PlayerController){

	static UObject* p_SetEyeTrackedPlayer = UObject::FindObject<UFunction>("Function EyeTracker.EyeTrackerFunctionLibrary.SetEyeTrackedPlayer");

	struct {
		struct APlayerController* PlayerController;
	} parms;

	parms.PlayerController = PlayerController;

	ProcessEvent(p_SetEyeTrackedPlayer, &parms);
}

bool UBlueprintFunctionLibrary::IsStereoGazeDataAvailable(){

	static UObject* p_IsStereoGazeDataAvailable = UObject::FindObject<UFunction>("Function EyeTracker.EyeTrackerFunctionLibrary.IsStereoGazeDataAvailable");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_IsStereoGazeDataAvailable, &parms);
	return parms.return_value;
}

bool UBlueprintFunctionLibrary::IsEyeTrackerConnected(){

	static UObject* p_IsEyeTrackerConnected = UObject::FindObject<UFunction>("Function EyeTracker.EyeTrackerFunctionLibrary.IsEyeTrackerConnected");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_IsEyeTrackerConnected, &parms);
	return parms.return_value;
}

bool UBlueprintFunctionLibrary::GetStereoGazeData(struct FEyeTrackerStereoGazeData& OutGazeData){

	static UObject* p_GetStereoGazeData = UObject::FindObject<UFunction>("Function EyeTracker.EyeTrackerFunctionLibrary.GetStereoGazeData");

	struct {
		struct FEyeTrackerStereoGazeData& OutGazeData;
		bool return_value;
	} parms;

	parms.OutGazeData = OutGazeData;

	ProcessEvent(p_GetStereoGazeData, &parms);
	return parms.return_value;
}

bool UBlueprintFunctionLibrary::GetGazeData(struct FEyeTrackerGazeData& OutGazeData){

	static UObject* p_GetGazeData = UObject::FindObject<UFunction>("Function EyeTracker.EyeTrackerFunctionLibrary.GetGazeData");

	struct {
		struct FEyeTrackerGazeData& OutGazeData;
		bool return_value;
	} parms;

	parms.OutGazeData = OutGazeData;

	ProcessEvent(p_GetGazeData, &parms);
	return parms.return_value;
}

