#pragma once 
#include "SDK.h" 
 
 
// Function AccessoriesSlot_UMG.AccessoriesSlot_UMG_C.ExecuteUbergraph_AccessoriesSlot_UMG
// Size: 0xC8(Inherited: 0x0) 
struct FExecuteUbergraph_AccessoriesSlot_UMG
{
	int32_t EntryPoint;  // 0x0(0x4)
	int32_t ___int_Array_Index_Variable;  // 0x4(0x4)
	int32_t ___int_Loop_Counter_Variable;  // 0x8(0x4)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool K2Node_Event_IsDesignTime : 1;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct UUMGSequencePlayer* CallFunc_PlayAnimation_ReturnValue;  // 0x18(0x8)
	struct UUMGSequencePlayer* CallFunc_PlayAnimation_ReturnValue_2;  // 0x20(0x8)
	struct TArray<struct UUserWidget*> CallFunc_GetAllWidgetsWithInterface_FoundWidgets;  // 0x28(0x10)
	struct UUserWidget* CallFunc_Array_Get_Item;  // 0x38(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x40(0x4)
	char pad_68[4];  // 0x44(0x4)
	struct TScriptInterface<IUIWeapon_C> K2Node_DynamicCast_AsUIWeapon;  // 0x48(0x10)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x58(0x1)
	char pad_89_1 : 7;  // 0x59(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x59(0x1)
	char pad_90[6];  // 0x5A(0x6)
	struct FSlateColor K2Node_MakeStruct_SlateColor;  // 0x60(0x28)
	struct FSlateColor K2Node_MakeStruct_SlateColor_2;  // 0x88(0x28)
	char pad_176_1 : 7;  // 0xB0(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0xB0(0x1)
	char pad_177[7];  // 0xB1(0x7)
	struct ACustomWeapon_BP_C* CallFunc_GetActorOfClass_ReturnValue;  // 0xB8(0x8)
	struct ACustomWeapon_BP_C* CallFunc_GetActorOfClass_ReturnValue_2;  // 0xC0(0x8)

}; 
// Function AccessoriesSlot_UMG.AccessoriesSlot_UMG_C.PreConstruct
// Size: 0x1(Inherited: 0x1) 
struct FPreConstruct : public FPreConstruct
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool IsDesignTime : 1;  // 0x0(0x1)

}; 
