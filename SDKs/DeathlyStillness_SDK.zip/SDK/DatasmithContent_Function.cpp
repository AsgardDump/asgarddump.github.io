#include "SDK.h" 
 
 
struct FString UBlueprintFunctionLibrary::GetDatasmithUserDataValueForKey(struct UObject* Object, struct FName Key){

	static UObject* p_GetDatasmithUserDataValueForKey = UObject::FindObject<UFunction>("Function DatasmithContent.DatasmithContentBlueprintLibrary.GetDatasmithUserDataValueForKey");

	struct {
		struct UObject* Object;
		struct FName Key;
		struct FString return_value;
	} parms;

	parms.Object = Object;
	parms.Key = Key;

	ProcessEvent(p_GetDatasmithUserDataValueForKey, &parms);
	return parms.return_value;
}

void UBlueprintFunctionLibrary::GetDatasmithUserDataKeysAndValuesForValue(struct UObject* Object, struct FString StringToMatch, struct TArray<struct FName>& OutKeys, struct TArray<struct FString>& OutValues){

	static UObject* p_GetDatasmithUserDataKeysAndValuesForValue = UObject::FindObject<UFunction>("Function DatasmithContent.DatasmithContentBlueprintLibrary.GetDatasmithUserDataKeysAndValuesForValue");

	struct {
		struct UObject* Object;
		struct FString StringToMatch;
		struct TArray<struct FName>& OutKeys;
		struct TArray<struct FString>& OutValues;
	} parms;

	parms.Object = Object;
	parms.StringToMatch = StringToMatch;
	parms.OutKeys = OutKeys;
	parms.OutValues = OutValues;

	ProcessEvent(p_GetDatasmithUserDataKeysAndValuesForValue, &parms);
}

struct UDatasmithAssetUserData* UBlueprintFunctionLibrary::GetDatasmithUserData(struct UObject* Object){

	static UObject* p_GetDatasmithUserData = UObject::FindObject<UFunction>("Function DatasmithContent.DatasmithContentBlueprintLibrary.GetDatasmithUserData");

	struct {
		struct UObject* Object;
		struct UDatasmithAssetUserData* return_value;
	} parms;

	parms.Object = Object;

	ProcessEvent(p_GetDatasmithUserData, &parms);
	return parms.return_value;
}

void AActor::PlayLevelSequence(struct ULevelSequence* SequenceToPlay){

	static UObject* p_PlayLevelSequence = UObject::FindObject<UFunction>("Function DatasmithContent.DatasmithImportedSequencesActor.PlayLevelSequence");

	struct {
		struct ULevelSequence* SequenceToPlay;
	} parms;

	parms.SequenceToPlay = SequenceToPlay;

	ProcessEvent(p_PlayLevelSequence, &parms);
}

