#pragma once 
#include <Entity_ChasoPlayer_Structs.h>
 
 
 
// BlueprintGeneratedClass Entity_ChasoPlayer.Entity_ChasoPlayer_C
// Size: 0xB0(Inherited: 0xA8) 
struct UEntity_ChasoPlayer_C : public UBTTask_BlueprintBase
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0xA8(0x8)

	void OnFail_ABB689194B7AD14A72915FA5A6BB4E61(char EPathFollowingResult MovementResult); // Function Entity_ChasoPlayer.Entity_ChasoPlayer_C.OnFail_ABB689194B7AD14A72915FA5A6BB4E61
	void OnSuccess_ABB689194B7AD14A72915FA5A6BB4E61(char EPathFollowingResult MovementResult); // Function Entity_ChasoPlayer.Entity_ChasoPlayer_C.OnSuccess_ABB689194B7AD14A72915FA5A6BB4E61
	void ReceiveTickAI(struct AAIController* OwnerController, struct APawn* ControlledPawn, float DeltaSeconds); // Function Entity_ChasoPlayer.Entity_ChasoPlayer_C.ReceiveTickAI
	void (); // Function Entity_ChasoPlayer.Entity_ChasoPlayer_C.
	void ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function Entity_ChasoPlayer.Entity_ChasoPlayer_C.ReceiveExecuteAI
	void ExecuteUbergraph_Entity_ChasoPlayer(int32_t EntryPoint); // Function Entity_ChasoPlayer.Entity_ChasoPlayer_C.ExecuteUbergraph_Entity_ChasoPlayer
}; 



