#include "SDK.h" 
 
 
void UUserWidget::Construct(){

	static UObject* p_Construct = UObject::FindObject<UFunction>("Function KeyBoardShow.KeyBoardShow_C.Construct");

	struct {
	} parms;


	ProcessEvent(p_Construct, &parms);
}

void UUserWidget::StartGame(){

	static UObject* p_StartGame = UObject::FindObject<UFunction>("Function KeyBoardShow.KeyBoardShow_C.StartGame");

	struct {
	} parms;


	ProcessEvent(p_StartGame, &parms);
}

void UUserWidget::ExecuteUbergraph_KeyBoardShow(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph_KeyBoardShow = UObject::FindObject<UFunction>("Function KeyBoardShow.KeyBoardShow_C.ExecuteUbergraph_KeyBoardShow");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph_KeyBoardShow, &parms);
}

