#include "SDK.h" 
 
 
bool UBlueprintFunctionLibrary::RemoveGameplayTag(struct FGameplayTagContainer& TagContainer, struct FGameplayTag Tag){

	static UObject* p_RemoveGameplayTag = UObject::FindObject<UFunction>("Function GameplayTags.BlueprintGameplayTagLibrary.RemoveGameplayTag");

	struct {
		struct FGameplayTagContainer& TagContainer;
		struct FGameplayTag Tag;
		bool return_value;
	} parms;

	parms.TagContainer = TagContainer;
	parms.Tag = Tag;

	ProcessEvent(p_RemoveGameplayTag, &parms);
	return parms.return_value;
}

bool UBlueprintFunctionLibrary::NotEqual_TagTag(struct FGameplayTag A, struct FString B){

	static UObject* p_NotEqual_TagTag = UObject::FindObject<UFunction>("Function GameplayTags.BlueprintGameplayTagLibrary.NotEqual_TagTag");

	struct {
		struct FGameplayTag A;
		struct FString B;
		bool return_value;
	} parms;

	parms.A = A;
	parms.B = B;

	ProcessEvent(p_NotEqual_TagTag, &parms);
	return parms.return_value;
}

bool UBlueprintFunctionLibrary::NotEqual_TagContainerTagContainer(struct FGameplayTagContainer A, struct FString B){

	static UObject* p_NotEqual_TagContainerTagContainer = UObject::FindObject<UFunction>("Function GameplayTags.BlueprintGameplayTagLibrary.NotEqual_TagContainerTagContainer");

	struct {
		struct FGameplayTagContainer A;
		struct FString B;
		bool return_value;
	} parms;

	parms.A = A;
	parms.B = B;

	ProcessEvent(p_NotEqual_TagContainerTagContainer, &parms);
	return parms.return_value;
}

bool UBlueprintFunctionLibrary::NotEqual_GameplayTagContainer(struct FGameplayTagContainer& A, struct FGameplayTagContainer& B){

	static UObject* p_NotEqual_GameplayTagContainer = UObject::FindObject<UFunction>("Function GameplayTags.BlueprintGameplayTagLibrary.NotEqual_GameplayTagContainer");

	struct {
		struct FGameplayTagContainer& A;
		struct FGameplayTagContainer& B;
		bool return_value;
	} parms;

	parms.A = A;
	parms.B = B;

	ProcessEvent(p_NotEqual_GameplayTagContainer, &parms);
	return parms.return_value;
}

bool UBlueprintFunctionLibrary::NotEqual_GameplayTag(struct FGameplayTag A, struct FGameplayTag B){

	static UObject* p_NotEqual_GameplayTag = UObject::FindObject<UFunction>("Function GameplayTags.BlueprintGameplayTagLibrary.NotEqual_GameplayTag");

	struct {
		struct FGameplayTag A;
		struct FGameplayTag B;
		bool return_value;
	} parms;

	parms.A = A;
	parms.B = B;

	ProcessEvent(p_NotEqual_GameplayTag, &parms);
	return parms.return_value;
}

bool UBlueprintFunctionLibrary::MatchesTag(struct FGameplayTag TagOne, struct FGameplayTag TagTwo, bool bExactMatch){

	static UObject* p_MatchesTag = UObject::FindObject<UFunction>("Function GameplayTags.BlueprintGameplayTagLibrary.MatchesTag");

	struct {
		struct FGameplayTag TagOne;
		struct FGameplayTag TagTwo;
		bool bExactMatch;
		bool return_value;
	} parms;

	parms.TagOne = TagOne;
	parms.TagTwo = TagTwo;
	parms.bExactMatch = bExactMatch;

	ProcessEvent(p_MatchesTag, &parms);
	return parms.return_value;
}

bool UBlueprintFunctionLibrary::MatchesAnyTags(struct FGameplayTag TagOne, struct FGameplayTagContainer& OtherContainer, bool bExactMatch){

	static UObject* p_MatchesAnyTags = UObject::FindObject<UFunction>("Function GameplayTags.BlueprintGameplayTagLibrary.MatchesAnyTags");

	struct {
		struct FGameplayTag TagOne;
		struct FGameplayTagContainer& OtherContainer;
		bool bExactMatch;
		bool return_value;
	} parms;

	parms.TagOne = TagOne;
	parms.OtherContainer = OtherContainer;
	parms.bExactMatch = bExactMatch;

	ProcessEvent(p_MatchesAnyTags, &parms);
	return parms.return_value;
}

struct FGameplayTagContainer UBlueprintFunctionLibrary::MakeLiteralGameplayTagContainer(struct FGameplayTagContainer Value){

	static UObject* p_MakeLiteralGameplayTagContainer = UObject::FindObject<UFunction>("Function GameplayTags.BlueprintGameplayTagLibrary.MakeLiteralGameplayTagContainer");

	struct {
		struct FGameplayTagContainer Value;
		struct FGameplayTagContainer return_value;
	} parms;

	parms.Value = Value;

	ProcessEvent(p_MakeLiteralGameplayTagContainer, &parms);
	return parms.return_value;
}

struct FGameplayTag UBlueprintFunctionLibrary::MakeLiteralGameplayTag(struct FGameplayTag Value){

	static UObject* p_MakeLiteralGameplayTag = UObject::FindObject<UFunction>("Function GameplayTags.BlueprintGameplayTagLibrary.MakeLiteralGameplayTag");

	struct {
		struct FGameplayTag Value;
		struct FGameplayTag return_value;
	} parms;

	parms.Value = Value;

	ProcessEvent(p_MakeLiteralGameplayTag, &parms);
	return parms.return_value;
}

struct FGameplayTagQuery UBlueprintFunctionLibrary::MakeGameplayTagQuery(struct FGameplayTagQuery TagQuery){

	static UObject* p_MakeGameplayTagQuery = UObject::FindObject<UFunction>("Function GameplayTags.BlueprintGameplayTagLibrary.MakeGameplayTagQuery");

	struct {
		struct FGameplayTagQuery TagQuery;
		struct FGameplayTagQuery return_value;
	} parms;

	parms.TagQuery = TagQuery;

	ProcessEvent(p_MakeGameplayTagQuery, &parms);
	return parms.return_value;
}

struct FGameplayTagContainer UBlueprintFunctionLibrary::MakeGameplayTagContainerFromTag(struct FGameplayTag SingleTag){

	static UObject* p_MakeGameplayTagContainerFromTag = UObject::FindObject<UFunction>("Function GameplayTags.BlueprintGameplayTagLibrary.MakeGameplayTagContainerFromTag");

	struct {
		struct FGameplayTag SingleTag;
		struct FGameplayTagContainer return_value;
	} parms;

	parms.SingleTag = SingleTag;

	ProcessEvent(p_MakeGameplayTagContainerFromTag, &parms);
	return parms.return_value;
}

struct FGameplayTagContainer UBlueprintFunctionLibrary::MakeGameplayTagContainerFromArray(struct TArray<struct FGameplayTag>& GameplayTags){

	static UObject* p_MakeGameplayTagContainerFromArray = UObject::FindObject<UFunction>("Function GameplayTags.BlueprintGameplayTagLibrary.MakeGameplayTagContainerFromArray");

	struct {
		struct TArray<struct FGameplayTag>& GameplayTags;
		struct FGameplayTagContainer return_value;
	} parms;

	parms.GameplayTags = GameplayTags;

	ProcessEvent(p_MakeGameplayTagContainerFromArray, &parms);
	return parms.return_value;
}

bool UBlueprintFunctionLibrary::IsTagQueryEmpty(struct FGameplayTagQuery& TagQuery){

	static UObject* p_IsTagQueryEmpty = UObject::FindObject<UFunction>("Function GameplayTags.BlueprintGameplayTagLibrary.IsTagQueryEmpty");

	struct {
		struct FGameplayTagQuery& TagQuery;
		bool return_value;
	} parms;

	parms.TagQuery = TagQuery;

	ProcessEvent(p_IsTagQueryEmpty, &parms);
	return parms.return_value;
}

bool UBlueprintFunctionLibrary::IsGameplayTagValid(struct FGameplayTag GameplayTag){

	static UObject* p_IsGameplayTagValid = UObject::FindObject<UFunction>("Function GameplayTags.BlueprintGameplayTagLibrary.IsGameplayTagValid");

	struct {
		struct FGameplayTag GameplayTag;
		bool return_value;
	} parms;

	parms.GameplayTag = GameplayTag;

	ProcessEvent(p_IsGameplayTagValid, &parms);
	return parms.return_value;
}

bool UBlueprintFunctionLibrary::HasTag(struct FGameplayTagContainer& TagContainer, struct FGameplayTag Tag, bool bExactMatch){

	static UObject* p_HasTag = UObject::FindObject<UFunction>("Function GameplayTags.BlueprintGameplayTagLibrary.HasTag");

	struct {
		struct FGameplayTagContainer& TagContainer;
		struct FGameplayTag Tag;
		bool bExactMatch;
		bool return_value;
	} parms;

	parms.TagContainer = TagContainer;
	parms.Tag = Tag;
	parms.bExactMatch = bExactMatch;

	ProcessEvent(p_HasTag, &parms);
	return parms.return_value;
}

bool UBlueprintFunctionLibrary::HasAnyTags(struct FGameplayTagContainer& TagContainer, struct FGameplayTagContainer& OtherContainer, bool bExactMatch){

	static UObject* p_HasAnyTags = UObject::FindObject<UFunction>("Function GameplayTags.BlueprintGameplayTagLibrary.HasAnyTags");

	struct {
		struct FGameplayTagContainer& TagContainer;
		struct FGameplayTagContainer& OtherContainer;
		bool bExactMatch;
		bool return_value;
	} parms;

	parms.TagContainer = TagContainer;
	parms.OtherContainer = OtherContainer;
	parms.bExactMatch = bExactMatch;

	ProcessEvent(p_HasAnyTags, &parms);
	return parms.return_value;
}

bool UBlueprintFunctionLibrary::HasAllTags(struct FGameplayTagContainer& TagContainer, struct FGameplayTagContainer& OtherContainer, bool bExactMatch){

	static UObject* p_HasAllTags = UObject::FindObject<UFunction>("Function GameplayTags.BlueprintGameplayTagLibrary.HasAllTags");

	struct {
		struct FGameplayTagContainer& TagContainer;
		struct FGameplayTagContainer& OtherContainer;
		bool bExactMatch;
		bool return_value;
	} parms;

	parms.TagContainer = TagContainer;
	parms.OtherContainer = OtherContainer;
	parms.bExactMatch = bExactMatch;

	ProcessEvent(p_HasAllTags, &parms);
	return parms.return_value;
}

bool UBlueprintFunctionLibrary::HasAllMatchingGameplayTags(struct TScriptInterface<IGameplayTagAssetInterface> TagContainerInterface, struct FGameplayTagContainer& OtherContainer){

	static UObject* p_HasAllMatchingGameplayTags = UObject::FindObject<UFunction>("Function GameplayTags.BlueprintGameplayTagLibrary.HasAllMatchingGameplayTags");

	struct {
		struct TScriptInterface<IGameplayTagAssetInterface> TagContainerInterface;
		struct FGameplayTagContainer& OtherContainer;
		bool return_value;
	} parms;

	parms.TagContainerInterface = TagContainerInterface;
	parms.OtherContainer = OtherContainer;

	ProcessEvent(p_HasAllMatchingGameplayTags, &parms);
	return parms.return_value;
}

struct FName UBlueprintFunctionLibrary::GetTagName(struct FGameplayTag& GameplayTag){

	static UObject* p_GetTagName = UObject::FindObject<UFunction>("Function GameplayTags.BlueprintGameplayTagLibrary.GetTagName");

	struct {
		struct FGameplayTag& GameplayTag;
		struct FName return_value;
	} parms;

	parms.GameplayTag = GameplayTag;

	ProcessEvent(p_GetTagName, &parms);
	return parms.return_value;
}

int32_t UBlueprintFunctionLibrary::GetNumGameplayTagsInContainer(struct FGameplayTagContainer& TagContainer){

	static UObject* p_GetNumGameplayTagsInContainer = UObject::FindObject<UFunction>("Function GameplayTags.BlueprintGameplayTagLibrary.GetNumGameplayTagsInContainer");

	struct {
		struct FGameplayTagContainer& TagContainer;
		int32_t return_value;
	} parms;

	parms.TagContainer = TagContainer;

	ProcessEvent(p_GetNumGameplayTagsInContainer, &parms);
	return parms.return_value;
}

struct FString UBlueprintFunctionLibrary::GetDebugStringFromGameplayTagContainer(struct FGameplayTagContainer& TagContainer){

	static UObject* p_GetDebugStringFromGameplayTagContainer = UObject::FindObject<UFunction>("Function GameplayTags.BlueprintGameplayTagLibrary.GetDebugStringFromGameplayTagContainer");

	struct {
		struct FGameplayTagContainer& TagContainer;
		struct FString return_value;
	} parms;

	parms.TagContainer = TagContainer;

	ProcessEvent(p_GetDebugStringFromGameplayTagContainer, &parms);
	return parms.return_value;
}

struct FString UBlueprintFunctionLibrary::GetDebugStringFromGameplayTag(struct FGameplayTag GameplayTag){

	static UObject* p_GetDebugStringFromGameplayTag = UObject::FindObject<UFunction>("Function GameplayTags.BlueprintGameplayTagLibrary.GetDebugStringFromGameplayTag");

	struct {
		struct FGameplayTag GameplayTag;
		struct FString return_value;
	} parms;

	parms.GameplayTag = GameplayTag;

	ProcessEvent(p_GetDebugStringFromGameplayTag, &parms);
	return parms.return_value;
}

void UBlueprintFunctionLibrary::GetAllActorsOfClassMatchingTagQuery(struct UObject* WorldContextObject, AActor* ActorClass, struct FGameplayTagQuery& GameplayTagQuery, struct TArray<struct AActor*>& OutActors){

	static UObject* p_GetAllActorsOfClassMatchingTagQuery = UObject::FindObject<UFunction>("Function GameplayTags.BlueprintGameplayTagLibrary.GetAllActorsOfClassMatchingTagQuery");

	struct {
		struct UObject* WorldContextObject;
		AActor* ActorClass;
		struct FGameplayTagQuery& GameplayTagQuery;
		struct TArray<struct AActor*>& OutActors;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.ActorClass = ActorClass;
	parms.GameplayTagQuery = GameplayTagQuery;
	parms.OutActors = OutActors;

	ProcessEvent(p_GetAllActorsOfClassMatchingTagQuery, &parms);
}

bool UBlueprintFunctionLibrary::EqualEqual_GameplayTagContainer(struct FGameplayTagContainer& A, struct FGameplayTagContainer& B){

	static UObject* p_EqualEqual_GameplayTagContainer = UObject::FindObject<UFunction>("Function GameplayTags.BlueprintGameplayTagLibrary.EqualEqual_GameplayTagContainer");

	struct {
		struct FGameplayTagContainer& A;
		struct FGameplayTagContainer& B;
		bool return_value;
	} parms;

	parms.A = A;
	parms.B = B;

	ProcessEvent(p_EqualEqual_GameplayTagContainer, &parms);
	return parms.return_value;
}

bool UBlueprintFunctionLibrary::EqualEqual_GameplayTag(struct FGameplayTag A, struct FGameplayTag B){

	static UObject* p_EqualEqual_GameplayTag = UObject::FindObject<UFunction>("Function GameplayTags.BlueprintGameplayTagLibrary.EqualEqual_GameplayTag");

	struct {
		struct FGameplayTag A;
		struct FGameplayTag B;
		bool return_value;
	} parms;

	parms.A = A;
	parms.B = B;

	ProcessEvent(p_EqualEqual_GameplayTag, &parms);
	return parms.return_value;
}

bool UBlueprintFunctionLibrary::DoesTagAssetInterfaceHaveTag(struct TScriptInterface<IGameplayTagAssetInterface> TagContainerInterface, struct FGameplayTag Tag){

	static UObject* p_DoesTagAssetInterfaceHaveTag = UObject::FindObject<UFunction>("Function GameplayTags.BlueprintGameplayTagLibrary.DoesTagAssetInterfaceHaveTag");

	struct {
		struct TScriptInterface<IGameplayTagAssetInterface> TagContainerInterface;
		struct FGameplayTag Tag;
		bool return_value;
	} parms;

	parms.TagContainerInterface = TagContainerInterface;
	parms.Tag = Tag;

	ProcessEvent(p_DoesTagAssetInterfaceHaveTag, &parms);
	return parms.return_value;
}

bool UBlueprintFunctionLibrary::DoesContainerMatchTagQuery(struct FGameplayTagContainer& TagContainer, struct FGameplayTagQuery& TagQuery){

	static UObject* p_DoesContainerMatchTagQuery = UObject::FindObject<UFunction>("Function GameplayTags.BlueprintGameplayTagLibrary.DoesContainerMatchTagQuery");

	struct {
		struct FGameplayTagContainer& TagContainer;
		struct FGameplayTagQuery& TagQuery;
		bool return_value;
	} parms;

	parms.TagContainer = TagContainer;
	parms.TagQuery = TagQuery;

	ProcessEvent(p_DoesContainerMatchTagQuery, &parms);
	return parms.return_value;
}

void UBlueprintFunctionLibrary::BreakGameplayTagContainer(struct FGameplayTagContainer& GameplayTagContainer, struct TArray<struct FGameplayTag>& GameplayTags){

	static UObject* p_BreakGameplayTagContainer = UObject::FindObject<UFunction>("Function GameplayTags.BlueprintGameplayTagLibrary.BreakGameplayTagContainer");

	struct {
		struct FGameplayTagContainer& GameplayTagContainer;
		struct TArray<struct FGameplayTag>& GameplayTags;
	} parms;

	parms.GameplayTagContainer = GameplayTagContainer;
	parms.GameplayTags = GameplayTags;

	ProcessEvent(p_BreakGameplayTagContainer, &parms);
}

void UBlueprintFunctionLibrary::AppendGameplayTagContainers(struct FGameplayTagContainer& InOutTagContainer, struct FGameplayTagContainer& InTagContainer){

	static UObject* p_AppendGameplayTagContainers = UObject::FindObject<UFunction>("Function GameplayTags.BlueprintGameplayTagLibrary.AppendGameplayTagContainers");

	struct {
		struct FGameplayTagContainer& InOutTagContainer;
		struct FGameplayTagContainer& InTagContainer;
	} parms;

	parms.InOutTagContainer = InOutTagContainer;
	parms.InTagContainer = InTagContainer;

	ProcessEvent(p_AppendGameplayTagContainers, &parms);
}

void UBlueprintFunctionLibrary::AddGameplayTag(struct FGameplayTagContainer& TagContainer, struct FGameplayTag Tag){

	static UObject* p_AddGameplayTag = UObject::FindObject<UFunction>("Function GameplayTags.BlueprintGameplayTagLibrary.AddGameplayTag");

	struct {
		struct FGameplayTagContainer& TagContainer;
		struct FGameplayTag Tag;
	} parms;

	parms.TagContainer = TagContainer;
	parms.Tag = Tag;

	ProcessEvent(p_AddGameplayTag, &parms);
}

bool UInterface::HasMatchingGameplayTag(struct FGameplayTag TagToCheck){

	static UObject* p_HasMatchingGameplayTag = UObject::FindObject<UFunction>("Function GameplayTags.GameplayTagAssetInterface.HasMatchingGameplayTag");

	struct {
		struct FGameplayTag TagToCheck;
		bool return_value;
	} parms;

	parms.TagToCheck = TagToCheck;

	ProcessEvent(p_HasMatchingGameplayTag, &parms);
	return parms.return_value;
}

bool UInterface::HasAnyMatchingGameplayTags(struct FGameplayTagContainer& TagContainer){

	static UObject* p_HasAnyMatchingGameplayTags = UObject::FindObject<UFunction>("Function GameplayTags.GameplayTagAssetInterface.HasAnyMatchingGameplayTags");

	struct {
		struct FGameplayTagContainer& TagContainer;
		bool return_value;
	} parms;

	parms.TagContainer = TagContainer;

	ProcessEvent(p_HasAnyMatchingGameplayTags, &parms);
	return parms.return_value;
}

bool UInterface::HasAllMatchingGameplayTags(struct FGameplayTagContainer& TagContainer){

	static UObject* p_HasAllMatchingGameplayTags = UObject::FindObject<UFunction>("Function GameplayTags.GameplayTagAssetInterface.HasAllMatchingGameplayTags");

	struct {
		struct FGameplayTagContainer& TagContainer;
		bool return_value;
	} parms;

	parms.TagContainer = TagContainer;

	ProcessEvent(p_HasAllMatchingGameplayTags, &parms);
	return parms.return_value;
}

void UInterface::GetOwnedGameplayTags(struct FGameplayTagContainer& TagContainer){

	static UObject* p_GetOwnedGameplayTags = UObject::FindObject<UFunction>("Function GameplayTags.GameplayTagAssetInterface.GetOwnedGameplayTags");

	struct {
		struct FGameplayTagContainer& TagContainer;
	} parms;

	parms.TagContainer = TagContainer;

	ProcessEvent(p_GetOwnedGameplayTags, &parms);
}

