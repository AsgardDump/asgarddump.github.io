#include "SDK.h" 
 
 
uint8_t  UBlueprintFunctionLibrary::ShowCellularDataConfirmation(){

	static UObject* p_ShowCellularDataConfirmation = UObject::FindObject<UFunction>("Function GooglePAD.GooglePADFunctionLibrary.ShowCellularDataConfirmation");

	struct {
		uint8_t  return_value;
	} parms;


	ProcessEvent(p_ShowCellularDataConfirmation, &parms);
	return parms.return_value;
}

uint8_t  UBlueprintFunctionLibrary::RequestRemoval(struct FString Name){

	static UObject* p_RequestRemoval = UObject::FindObject<UFunction>("Function GooglePAD.GooglePADFunctionLibrary.RequestRemoval");

	struct {
		struct FString Name;
		uint8_t  return_value;
	} parms;

	parms.Name = Name;

	ProcessEvent(p_RequestRemoval, &parms);
	return parms.return_value;
}

uint8_t  UBlueprintFunctionLibrary::RequestInfo(struct TArray<struct FString> AssetPacks){

	static UObject* p_RequestInfo = UObject::FindObject<UFunction>("Function GooglePAD.GooglePADFunctionLibrary.RequestInfo");

	struct {
		struct TArray<struct FString> AssetPacks;
		uint8_t  return_value;
	} parms;

	parms.AssetPacks = AssetPacks;

	ProcessEvent(p_RequestInfo, &parms);
	return parms.return_value;
}

uint8_t  UBlueprintFunctionLibrary::RequestDownload(struct TArray<struct FString> AssetPacks){

	static UObject* p_RequestDownload = UObject::FindObject<UFunction>("Function GooglePAD.GooglePADFunctionLibrary.RequestDownload");

	struct {
		struct TArray<struct FString> AssetPacks;
		uint8_t  return_value;
	} parms;

	parms.AssetPacks = AssetPacks;

	ProcessEvent(p_RequestDownload, &parms);
	return parms.return_value;
}

void UBlueprintFunctionLibrary::ReleaseDownloadState(int32_t State){

	static UObject* p_ReleaseDownloadState = UObject::FindObject<UFunction>("Function GooglePAD.GooglePADFunctionLibrary.ReleaseDownloadState");

	struct {
		int32_t State;
	} parms;

	parms.State = State;

	ProcessEvent(p_ReleaseDownloadState, &parms);
}

void UBlueprintFunctionLibrary::ReleaseAssetPackLocation(int32_t Location){

	static UObject* p_ReleaseAssetPackLocation = UObject::FindObject<UFunction>("Function GooglePAD.GooglePADFunctionLibrary.ReleaseAssetPackLocation");

	struct {
		int32_t Location;
	} parms;

	parms.Location = Location;

	ProcessEvent(p_ReleaseAssetPackLocation, &parms);
}

int32_t UBlueprintFunctionLibrary::GetTotalBytesToDownload(int32_t State){

	static UObject* p_GetTotalBytesToDownload = UObject::FindObject<UFunction>("Function GooglePAD.GooglePADFunctionLibrary.GetTotalBytesToDownload");

	struct {
		int32_t State;
		int32_t return_value;
	} parms;

	parms.State = State;

	ProcessEvent(p_GetTotalBytesToDownload, &parms);
	return parms.return_value;
}

uint8_t  UBlueprintFunctionLibrary::GetStorageMethod(int32_t Location){

	static UObject* p_GetStorageMethod = UObject::FindObject<UFunction>("Function GooglePAD.GooglePADFunctionLibrary.GetStorageMethod");

	struct {
		int32_t Location;
		uint8_t  return_value;
	} parms;

	parms.Location = Location;

	ProcessEvent(p_GetStorageMethod, &parms);
	return parms.return_value;
}

uint8_t  UBlueprintFunctionLibrary::GetShowCellularDataConfirmationStatus(uint8_t & Status){

	static UObject* p_GetShowCellularDataConfirmationStatus = UObject::FindObject<UFunction>("Function GooglePAD.GooglePADFunctionLibrary.GetShowCellularDataConfirmationStatus");

	struct {
		uint8_t & Status;
		uint8_t  return_value;
	} parms;

	parms.Status = Status;

	ProcessEvent(p_GetShowCellularDataConfirmationStatus, &parms);
	return parms.return_value;
}

uint8_t  UBlueprintFunctionLibrary::GetDownloadStatus(int32_t State){

	static UObject* p_GetDownloadStatus = UObject::FindObject<UFunction>("Function GooglePAD.GooglePADFunctionLibrary.GetDownloadStatus");

	struct {
		int32_t State;
		uint8_t  return_value;
	} parms;

	parms.State = State;

	ProcessEvent(p_GetDownloadStatus, &parms);
	return parms.return_value;
}

uint8_t  UBlueprintFunctionLibrary::GetDownloadState(struct FString Name, int32_t& State){

	static UObject* p_GetDownloadState = UObject::FindObject<UFunction>("Function GooglePAD.GooglePADFunctionLibrary.GetDownloadState");

	struct {
		struct FString Name;
		int32_t& State;
		uint8_t  return_value;
	} parms;

	parms.Name = Name;
	parms.State = State;

	ProcessEvent(p_GetDownloadState, &parms);
	return parms.return_value;
}

int32_t UBlueprintFunctionLibrary::GetBytesDownloaded(int32_t State){

	static UObject* p_GetBytesDownloaded = UObject::FindObject<UFunction>("Function GooglePAD.GooglePADFunctionLibrary.GetBytesDownloaded");

	struct {
		int32_t State;
		int32_t return_value;
	} parms;

	parms.State = State;

	ProcessEvent(p_GetBytesDownloaded, &parms);
	return parms.return_value;
}

struct FString UBlueprintFunctionLibrary::GetAssetsPath(int32_t Location){

	static UObject* p_GetAssetsPath = UObject::FindObject<UFunction>("Function GooglePAD.GooglePADFunctionLibrary.GetAssetsPath");

	struct {
		int32_t Location;
		struct FString return_value;
	} parms;

	parms.Location = Location;

	ProcessEvent(p_GetAssetsPath, &parms);
	return parms.return_value;
}

uint8_t  UBlueprintFunctionLibrary::GetAssetPackLocation(struct FString Name, int32_t& Location){

	static UObject* p_GetAssetPackLocation = UObject::FindObject<UFunction>("Function GooglePAD.GooglePADFunctionLibrary.GetAssetPackLocation");

	struct {
		struct FString Name;
		int32_t& Location;
		uint8_t  return_value;
	} parms;

	parms.Name = Name;
	parms.Location = Location;

	ProcessEvent(p_GetAssetPackLocation, &parms);
	return parms.return_value;
}

uint8_t  UBlueprintFunctionLibrary::CancelDownload(struct TArray<struct FString> AssetPacks){

	static UObject* p_CancelDownload = UObject::FindObject<UFunction>("Function GooglePAD.GooglePADFunctionLibrary.CancelDownload");

	struct {
		struct TArray<struct FString> AssetPacks;
		uint8_t  return_value;
	} parms;

	parms.AssetPacks = AssetPacks;

	ProcessEvent(p_CancelDownload, &parms);
	return parms.return_value;
}

