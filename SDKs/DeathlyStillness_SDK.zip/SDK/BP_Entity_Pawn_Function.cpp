#include "SDK.h" 
 
 
void ACharacter::Simulate Physics for Roar(){

	static UObject* p_Simulate Physics for Roar = UObject::FindObject<UFunction>("Function BP_Entity_Pawn.BP_Entity_Pawn_C.Simulate Physics for Roar");

	struct {
	} parms;


	ProcessEvent(p_Simulate Physics for Roar, &parms);
}

void ACharacter::(bool Orient Rotation to Movement, bool Use Controller Rotation Yaw, bool ){

	static UObject* p_ = UObject::FindObject<UFunction>("Function BP_Entity_Pawn.BP_Entity_Pawn_C.");

	struct {
		bool Orient Rotation to Movement;
		bool Use Controller Rotation Yaw;
		bool ;
	} parms;

	parms.Orient Rotation to Movement = Orient Rotation to Movement;
	parms.Use Controller Rotation Yaw = Use Controller Rotation Yaw;
	parms. = ;

	ProcessEvent(p_, &parms);
}

void ACharacter::OnFail_A575B2C740A89FE0D490E0A57BBC2713(char EPathFollowingResult MovementResult){

	static UObject* p_OnFail_A575B2C740A89FE0D490E0A57BBC2713 = UObject::FindObject<UFunction>("Function BP_Entity_Pawn.BP_Entity_Pawn_C.OnFail_A575B2C740A89FE0D490E0A57BBC2713");

	struct {
		char EPathFollowingResult MovementResult;
	} parms;

	parms.MovementResult = MovementResult;

	ProcessEvent(p_OnFail_A575B2C740A89FE0D490E0A57BBC2713, &parms);
}

void ACharacter::OnSuccess_A575B2C740A89FE0D490E0A57BBC2713(char EPathFollowingResult MovementResult){

	static UObject* p_OnSuccess_A575B2C740A89FE0D490E0A57BBC2713 = UObject::FindObject<UFunction>("Function BP_Entity_Pawn.BP_Entity_Pawn_C.OnSuccess_A575B2C740A89FE0D490E0A57BBC2713");

	struct {
		char EPathFollowingResult MovementResult;
	} parms;

	parms.MovementResult = MovementResult;

	ProcessEvent(p_OnSuccess_A575B2C740A89FE0D490E0A57BBC2713, &parms);
}

void ACharacter::(){

	static UObject* p_ = UObject::FindObject<UFunction>("Function BP_Entity_Pawn.BP_Entity_Pawn_C.");

	struct {
	} parms;


	ProcessEvent(p_, &parms);
}

void ACharacter::(){

	static UObject* p_ = UObject::FindObject<UFunction>("Function BP_Entity_Pawn.BP_Entity_Pawn_C.");

	struct {
	} parms;


	ProcessEvent(p_, &parms);
}

void ACharacter::ResetScream(){

	static UObject* p_ResetScream = UObject::FindObject<UFunction>("Function BP_Entity_Pawn.BP_Entity_Pawn_C.ResetScream");

	struct {
	} parms;


	ProcessEvent(p_ResetScream, &parms);
}

void ACharacter::DamageHit(struct FHitResult Hit, float Damage, bool isMelee?){

	static UObject* p_DamageHit = UObject::FindObject<UFunction>("Function BP_Entity_Pawn.BP_Entity_Pawn_C.DamageHit");

	struct {
		struct FHitResult Hit;
		float Damage;
		bool isMelee?;
	} parms;

	parms.Hit = Hit;
	parms.Damage = Damage;
	parms.isMelee? = isMelee?;

	ProcessEvent(p_DamageHit, &parms);
}

void ACharacter::(){

	static UObject* p_ = UObject::FindObject<UFunction>("Function BP_Entity_Pawn.BP_Entity_Pawn_C.");

	struct {
	} parms;


	ProcessEvent(p_, &parms);
}

void ACharacter::(){

	static UObject* p_ = UObject::FindObject<UFunction>("Function BP_Entity_Pawn.BP_Entity_Pawn_C.");

	struct {
	} parms;


	ProcessEvent(p_, &parms);
}

void ACharacter::(){

	static UObject* p_ = UObject::FindObject<UFunction>("Function BP_Entity_Pawn.BP_Entity_Pawn_C.");

	struct {
	} parms;


	ProcessEvent(p_, &parms);
}

void ACharacter::(){

	static UObject* p_ = UObject::FindObject<UFunction>("Function BP_Entity_Pawn.BP_Entity_Pawn_C.");

	struct {
	} parms;


	ProcessEvent(p_, &parms);
}

void ACharacter::(){

	static UObject* p_ = UObject::FindObject<UFunction>("Function BP_Entity_Pawn.BP_Entity_Pawn_C.");

	struct {
	} parms;


	ProcessEvent(p_, &parms);
}

void ACharacter::CustomMappingCheck(struct FInputActionKeyMapping InputAction, struct FInputAxisKeyMapping InputAxis){

	static UObject* p_CustomMappingCheck = UObject::FindObject<UFunction>("Function BP_Entity_Pawn.BP_Entity_Pawn_C.CustomMappingCheck");

	struct {
		struct FInputActionKeyMapping InputAction;
		struct FInputAxisKeyMapping InputAxis;
	} parms;

	parms.InputAction = InputAction;
	parms.InputAxis = InputAxis;

	ProcessEvent(p_CustomMappingCheck, &parms);
}

void ACharacter::initializeSetting(){

	static UObject* p_initializeSetting = UObject::FindObject<UFunction>("Function BP_Entity_Pawn.BP_Entity_Pawn_C.initializeSetting");

	struct {
	} parms;


	ProcessEvent(p_initializeSetting, &parms);
}

void ACharacter::SettingDetails(struct FText , struct FText ){

	static UObject* p_SettingDetails = UObject::FindObject<UFunction>("Function BP_Entity_Pawn.BP_Entity_Pawn_C.SettingDetails");

	struct {
		struct FText ;
		struct FText ;
	} parms;

	parms. = ;
	parms. = ;

	ProcessEvent(p_SettingDetails, &parms);
}

void ACharacter::(){

	static UObject* p_ = UObject::FindObject<UFunction>("Function BP_Entity_Pawn.BP_Entity_Pawn_C.");

	struct {
	} parms;


	ProcessEvent(p_, &parms);
}

void ACharacter::(){

	static UObject* p_ = UObject::FindObject<UFunction>("Function BP_Entity_Pawn.BP_Entity_Pawn_C.");

	struct {
	} parms;


	ProcessEvent(p_, &parms);
}

void ACharacter::Reset(){

	static UObject* p_Reset = UObject::FindObject<UFunction>("Function BP_Entity_Pawn.BP_Entity_Pawn_C.Reset");

	struct {
	} parms;


	ProcessEvent(p_Reset, &parms);
}

void ACharacter::ReceiveBeginPlay(){

	static UObject* p_ReceiveBeginPlay = UObject::FindObject<UFunction>("Function BP_Entity_Pawn.BP_Entity_Pawn_C.ReceiveBeginPlay");

	struct {
	} parms;


	ProcessEvent(p_ReceiveBeginPlay, &parms);
}

void ACharacter::(){

	static UObject* p_ = UObject::FindObject<UFunction>("Function BP_Entity_Pawn.BP_Entity_Pawn_C.");

	struct {
	} parms;


	ProcessEvent(p_, &parms);
}

void ACharacter::SettingApply(){

	static UObject* p_SettingApply = UObject::FindObject<UFunction>("Function BP_Entity_Pawn.BP_Entity_Pawn_C.SettingApply");

	struct {
	} parms;


	ProcessEvent(p_SettingApply, &parms);
}

void ACharacter::(){

	static UObject* p_ = UObject::FindObject<UFunction>("Function BP_Entity_Pawn.BP_Entity_Pawn_C.");

	struct {
	} parms;


	ProcessEvent(p_, &parms);
}

void ACharacter::(){

	static UObject* p_ = UObject::FindObject<UFunction>("Function BP_Entity_Pawn.BP_Entity_Pawn_C.");

	struct {
	} parms;


	ProcessEvent(p_, &parms);
}

void ACharacter::ExecuteUbergraph_BP_Entity_Pawn(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph_BP_Entity_Pawn = UObject::FindObject<UFunction>("Function BP_Entity_Pawn.BP_Entity_Pawn_C.ExecuteUbergraph_BP_Entity_Pawn");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph_BP_Entity_Pawn, &parms);
}

