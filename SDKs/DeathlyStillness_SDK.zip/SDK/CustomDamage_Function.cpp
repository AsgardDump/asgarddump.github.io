#include "SDK.h" 
 
 
void UInterface::DamageHit(struct FHitResult bpp__Hit__pf, float bpp__Damage__pf, bool bpp__isMeleex__pfzy){

	static UObject* p_DamageHit = UObject::FindObject<UFunction>("Function CustomDamage.CustomDamage_C.DamageHit");

	struct {
		struct FHitResult bpp__Hit__pf;
		float bpp__Damage__pf;
		bool bpp__isMeleex__pfzy;
	} parms;

	parms.bpp__Hit__pf = bpp__Hit__pf;
	parms.bpp__Damage__pf = bpp__Damage__pf;
	parms.bpp__isMeleex__pfzy = bpp__isMeleex__pfzy;

	ProcessEvent(p_DamageHit, &parms);
}

