#pragma once 
#include "SDK.h" 
 
 
// Function BP_Flashlight_Demo.BP_Flashlight_Demo_C.UserConstructionScript
// Size: 0x72(Inherited: 0x0) 
struct FUserConstructionScript : public FUserConstructionScript
{
	struct FLinearColor CallFunc_Conv_ColorToLinearColor_ReturnValue;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)
	struct FVector CallFunc_Conv_LinearColorToVector_ReturnValue;  // 0x14(0xC)
	struct FTransform CallFunc_MakeTransform_ReturnValue;  // 0x20(0x30)
	struct FLinearColor CallFunc_Conv_ColorToLinearColor_ReturnValue_2;  // 0x50(0x10)
	struct USpotLightComponent* CallFunc_AddComponent_ReturnValue;  // 0x60(0x8)
	struct UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue;  // 0x68(0x8)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool CallFunc_K2_AttachToComponent_ReturnValue : 1;  // 0x70(0x1)
	char pad_113_1 : 7;  // 0x71(0x1)
	bool CallFunc_SetStaticMesh_ReturnValue : 1;  // 0x71(0x1)

}; 
// Function BP_Flashlight_Demo.BP_Flashlight_Demo_C.ExecuteUbergraph_BP_Flashlight_Demo
// Size: 0x4(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Flashlight_Demo
{
	int32_t EntryPoint;  // 0x0(0x4)

}; 
// Function BP_Flashlight_Demo.BP_Flashlight_Demo_C.Set Intensity
// Size: 0xC(Inherited: 0x0) 
struct FSet Intensity
{
	float CallFunc_Conv_BoolToFloat_ReturnValue;  // 0x0(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x4(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_2;  // 0x8(0x4)

}; 
