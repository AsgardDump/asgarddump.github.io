#pragma once 
#include <Landscape_Structs.h>
 
 
 
// Class Landscape.LandscapeMeshCollisionComponent
// Size: 0x550(Inherited: 0x530) 
struct ULandscapeMeshCollisionComponent : public ULandscapeHeightfieldCollisionComponent
{
	struct FGuid MeshGuid;  // 0x530(0x10)
	char pad_1344[16];  // 0x540(0x10)

}; 



// Class Landscape.LandscapeComponent
// Size: 0x670(Inherited: 0x450) 
struct ULandscapeComponent : public UPrimitiveComponent
{
	int32_t SectionBaseX;  // 0x450(0x4)
	int32_t SectionBaseY;  // 0x454(0x4)
	int32_t ComponentSizeQuads;  // 0x458(0x4)
	int32_t SubsectionSizeQuads;  // 0x45C(0x4)
	int32_t NumSubsections;  // 0x460(0x4)
	char pad_1124[4];  // 0x464(0x4)
	struct UMaterialInterface* OverrideMaterial;  // 0x468(0x8)
	struct UMaterialInterface* OverrideHoleMaterial;  // 0x470(0x8)
	struct TArray<struct FLandscapeComponentMaterialOverride> OverrideMaterials;  // 0x478(0x10)
	struct TArray<struct UMaterialInstanceConstant*> MaterialInstances;  // 0x488(0x10)
	struct TArray<struct UMaterialInstanceDynamic*> MaterialInstancesDynamic;  // 0x498(0x10)
	struct TArray<int8_t> LODIndexToMaterialIndex;  // 0x4A8(0x10)
	struct TArray<int8_t> MaterialIndexToDisabledTessellationMaterial;  // 0x4B8(0x10)
	struct UTexture2D* XYOffsetmapTexture;  // 0x4C8(0x8)
	struct FVector4 WeightmapScaleBias;  // 0x4D0(0x10)
	float WeightmapSubsectionOffset;  // 0x4E0(0x4)
	char pad_1252[12];  // 0x4E4(0xC)
	struct FVector4 HeightmapScaleBias;  // 0x4F0(0x10)
	struct FBox CachedLocalBox;  // 0x500(0x1C)
	 CollisionComponent;  // 0x51C(0x1C)
	struct UTexture2D* HeightmapTexture;  // 0x538(0x8)
	struct TArray<struct FWeightmapLayerAllocationInfo> WeightmapLayerAllocations;  // 0x540(0x10)
	struct TArray<struct UTexture2D*> WeightmapTextures;  // 0x550(0x10)
	struct ULandscapeLODStreamingProxy* LODStreamingProxy;  // 0x560(0x8)
	struct FGuid MapBuildDataId;  // 0x568(0x10)
	struct TArray<struct FGuid> IrrelevantLights;  // 0x578(0x10)
	int32_t CollisionMipLevel;  // 0x588(0x4)
	int32_t SimpleCollisionMipLevel;  // 0x58C(0x4)
	float NegativeZBoundsExtension;  // 0x590(0x4)
	float PositiveZBoundsExtension;  // 0x594(0x4)
	float StaticLightingResolution;  // 0x598(0x4)
	int32_t ForcedLOD;  // 0x59C(0x4)
	int32_t LODBias;  // 0x5A0(0x4)
	struct FGuid StateId;  // 0x5A4(0x10)
	struct FGuid BakedTextureMaterialGuid;  // 0x5B4(0x10)
	char pad_1476[4];  // 0x5C4(0x4)
	struct UTexture2D* GIBakedBaseColorTexture;  // 0x5C8(0x8)
	char MobileBlendableLayerMask;  // 0x5D0(0x1)
	char pad_1489[7];  // 0x5D1(0x7)
	struct UMaterialInterface* MobileMaterialInterface;  // 0x5D8(0x8)
	struct TArray<struct UMaterialInterface*> MobileMaterialInterfaces;  // 0x5E0(0x10)
	struct TArray<struct UTexture2D*> MobileWeightmapTextures;  // 0x5F0(0x10)
	char pad_1536[112];  // 0x600(0x70)

	struct UMaterialInstanceDynamic* GetMaterialInstanceDynamic(int32_t InIndex); // Function Landscape.LandscapeComponent.GetMaterialInstanceDynamic
	float EditorGetPaintLayerWeightByNameAtLocation(struct FVector& InLocation, struct FName InPaintLayerName); // Function Landscape.LandscapeComponent.EditorGetPaintLayerWeightByNameAtLocation
	float EditorGetPaintLayerWeightAtLocation(struct FVector& InLocation, struct ULandscapeLayerInfoObject* PaintLayer); // Function Landscape.LandscapeComponent.EditorGetPaintLayerWeightAtLocation
}; 



// Class Landscape.LandscapeInfoMap
// Size: 0x80(Inherited: 0x28) 
struct ULandscapeInfoMap : public UObject
{
	char pad_40[88];  // 0x28(0x58)

}; 



// Class Landscape.ControlPointMeshActor
// Size: 0x228(Inherited: 0x220) 
struct AControlPointMeshActor : public AActor
{
	struct UControlPointMeshComponent* ControlPointMeshComponent;  // 0x220(0x8)

}; 



// Class Landscape.ControlPointMeshComponent
// Size: 0x4F0(Inherited: 0x4E0) 
struct UControlPointMeshComponent : public UStaticMeshComponent
{
	float VirtualTextureMainPassMaxDrawDistance;  // 0x4E0(0x4)
	char pad_1252[12];  // 0x4E4(0xC)

}; 



// Class Landscape.LandscapeProxy
// Size: 0x598(Inherited: 0x220) 
struct ALandscapeProxy : public AActor
{
	struct ULandscapeSplinesComponent* SplineComponent;  // 0x220(0x8)
	struct FGuid LandscapeGuid;  // 0x228(0x10)
	struct FIntPoint LandscapeSectionOffset;  // 0x238(0x8)
	int32_t MaxLODLevel;  // 0x240(0x4)
	float LODDistanceFactor;  // 0x244(0x4)
	char ELandscapeLODFalloff LODFalloff;  // 0x248(0x1)
	char pad_585[3];  // 0x249(0x3)
	float ComponentScreenSizeToUseSubSections;  // 0x24C(0x4)
	float LOD0ScreenSize;  // 0x250(0x4)
	float LOD0DistributionSetting;  // 0x254(0x4)
	float LODDistributionSetting;  // 0x258(0x4)
	float TessellationComponentScreenSize;  // 0x25C(0x4)
	char pad_608_1 : 7;  // 0x260(0x1)
	bool UseTessellationComponentScreenSizeFalloff : 1;  // 0x260(0x1)
	char pad_609[3];  // 0x261(0x3)
	float TessellationComponentScreenSizeFalloff;  // 0x264(0x4)
	int32_t OccluderGeometryLOD;  // 0x268(0x4)
	int32_t StaticLightingLOD;  // 0x26C(0x4)
	struct UPhysicalMaterial* DefaultPhysMaterial;  // 0x270(0x8)
	float StreamingDistanceMultiplier;  // 0x278(0x4)
	char pad_636[4];  // 0x27C(0x4)
	struct UMaterialInterface* LandscapeMaterial;  // 0x280(0x8)
	char pad_648[32];  // 0x288(0x20)
	struct UMaterialInterface* LandscapeHoleMaterial;  // 0x2A8(0x8)
	struct TArray<struct FLandscapeProxyMaterialOverride> LandscapeMaterialsOverride;  // 0x2B0(0x10)
	char pad_704_1 : 7;  // 0x2C0(0x1)
	bool bMeshHoles : 1;  // 0x2C0(0x1)
	char MeshHolesMaxLod;  // 0x2C1(0x1)
	char pad_706[6];  // 0x2C2(0x6)
	struct TArray<struct URuntimeVirtualTexture*> RuntimeVirtualTextures;  // 0x2C8(0x10)
	int32_t VirtualTextureNumLods;  // 0x2D8(0x4)
	int32_t VirtualTextureLodBias;  // 0x2DC(0x4)
	uint8_t  VirtualTextureRenderPassType;  // 0x2E0(0x1)
	char pad_737[3];  // 0x2E1(0x3)
	float NegativeZBoundsExtension;  // 0x2E4(0x4)
	float PositiveZBoundsExtension;  // 0x2E8(0x4)
	char pad_748[4];  // 0x2EC(0x4)
	struct TArray<struct ULandscapeComponent*> LandscapeComponents;  // 0x2F0(0x10)
	struct TArray<struct ULandscapeHeightfieldCollisionComponent*> CollisionComponents;  // 0x300(0x10)
	struct TArray<struct UHierarchicalInstancedStaticMeshComponent*> FoliageComponents;  // 0x310(0x10)
	char pad_800[100];  // 0x320(0x64)
	char pad_900_1 : 7;  // 0x384(0x1)
	bool bHasLandscapeGrass : 1;  // 0x384(0x1)
	char pad_901[3];  // 0x385(0x3)
	float StaticLightingResolution;  // 0x388(0x4)
	char CastShadow : 1;  // 0x38C(0x1)
	char bCastDynamicShadow : 1;  // 0x38C(0x1)
	char bCastStaticShadow : 1;  // 0x38C(0x1)
	char pad_908_1 : 5;  // 0x38C(0x1)
	char pad_909[4];  // 0x38D(0x4)
	char bCastFarShadow : 1;  // 0x390(0x1)
	char pad_912_1 : 7;  // 0x390(0x1)
	char pad_913[4];  // 0x391(0x4)
	char bCastHiddenShadow : 1;  // 0x394(0x1)
	char pad_916_1 : 7;  // 0x394(0x1)
	char pad_917[4];  // 0x395(0x4)
	char bCastShadowAsTwoSided : 1;  // 0x398(0x1)
	char pad_920_1 : 7;  // 0x398(0x1)
	char pad_921[4];  // 0x399(0x4)
	char bAffectDistanceFieldLighting : 1;  // 0x39C(0x1)
	char pad_924_1 : 7;  // 0x39C(0x1)
	struct FLightingChannels LightingChannels;  // 0x39D(0x1)
	char pad_926[2];  // 0x39E(0x2)
	char bUseMaterialPositionOffsetInStaticLighting : 1;  // 0x3A0(0x1)
	char bRenderCustomDepth : 1;  // 0x3A0(0x1)
	char pad_928_1 : 6;  // 0x3A0(0x1)
	char pad_929[4];  // 0x3A1(0x4)
	uint8_t  CustomDepthStencilWriteMask;  // 0x3A4(0x1)
	char pad_933[3];  // 0x3A5(0x3)
	int32_t CustomDepthStencilValue;  // 0x3A8(0x4)
	float LDMaxDrawDistance;  // 0x3AC(0x4)
	struct FLightmassPrimitiveSettings LightmassSettings;  // 0x3B0(0x18)
	int32_t CollisionMipLevel;  // 0x3C8(0x4)
	int32_t SimpleCollisionMipLevel;  // 0x3CC(0x4)
	float CollisionThickness;  // 0x3D0(0x4)
	char pad_980[4];  // 0x3D4(0x4)
	struct FBodyInstance BodyInstance;  // 0x3D8(0x158)
	char bGenerateOverlapEvents : 1;  // 0x530(0x1)
	char bBakeMaterialPositionOffsetIntoCollision : 1;  // 0x530(0x1)
	char pad_1328_1 : 6;  // 0x530(0x1)
	char pad_1329[4];  // 0x531(0x4)
	int32_t ComponentSizeQuads;  // 0x534(0x4)
	int32_t SubsectionSizeQuads;  // 0x538(0x4)
	int32_t NumSubsections;  // 0x53C(0x4)
	char bUsedForNavigation : 1;  // 0x540(0x1)
	char bFillCollisionUnderLandscapeForNavmesh : 1;  // 0x540(0x1)
	char pad_1344_1 : 6;  // 0x540(0x1)
	char pad_1345[4];  // 0x541(0x4)
	char pad_1348_1 : 7;  // 0x544(0x1)
	bool bUseDynamicMaterialInstance : 1;  // 0x544(0x1)
	uint8_t  NavigationGeometryGatheringMode;  // 0x545(0x1)
	char pad_1350_1 : 7;  // 0x546(0x1)
	bool bUseLandscapeForCullingInvisibleHLODVertices : 1;  // 0x546(0x1)
	char pad_1351_1 : 7;  // 0x547(0x1)
	bool bHasLayersContent : 1;  // 0x547(0x1)
	struct TMap<struct UTexture2D*, struct ULandscapeWeightmapUsage*> WeightmapUsageMap;  // 0x548(0x50)

	void SetLandscapeMaterialVectorParameterValue(struct FName ParameterName, struct FLinearColor Value); // Function Landscape.LandscapeProxy.SetLandscapeMaterialVectorParameterValue
	void SetLandscapeMaterialTextureParameterValue(struct FName ParameterName, struct UTexture* Value); // Function Landscape.LandscapeProxy.SetLandscapeMaterialTextureParameterValue
	void SetLandscapeMaterialScalarParameterValue(struct FName ParameterName, float Value); // Function Landscape.LandscapeProxy.SetLandscapeMaterialScalarParameterValue
	bool LandscapeExportHeightmapToRenderTarget(struct UTextureRenderTarget2D* InRenderTarget, bool InExportHeightIntoRGChannel, bool InExportLandscapeProxies); // Function Landscape.LandscapeProxy.LandscapeExportHeightmapToRenderTarget
	void EditorSetLandscapeMaterial(struct UMaterialInterface* NewLandscapeMaterial); // Function Landscape.LandscapeProxy.EditorSetLandscapeMaterial
	void EditorApplySpline(struct USplineComponent* InSplineComponent, float StartWidth, float EndWidth, float StartSideFalloff, float EndSideFalloff, float StartRoll, float EndRoll, int32_t NumSubdivisions, bool bRaiseHeights, bool bLowerHeights, struct ULandscapeLayerInfoObject* PaintLayer, struct FName EditLayerName); // Function Landscape.LandscapeProxy.EditorApplySpline
	void ChangeUseTessellationComponentScreenSizeFalloff(bool InComponentScreenSizeToUseSubSections); // Function Landscape.LandscapeProxy.ChangeUseTessellationComponentScreenSizeFalloff
	void ChangeTessellationComponentScreenSizeFalloff(float InUseTessellationComponentScreenSizeFalloff); // Function Landscape.LandscapeProxy.ChangeTessellationComponentScreenSizeFalloff
	void ChangeTessellationComponentScreenSize(float InTessellationComponentScreenSize); // Function Landscape.LandscapeProxy.ChangeTessellationComponentScreenSize
	void ChangeLODDistanceFactor(float InLODDistanceFactor); // Function Landscape.LandscapeProxy.ChangeLODDistanceFactor
	void ChangeComponentScreenSizeToUseSubSections(float InComponentScreenSizeToUseSubSections); // Function Landscape.LandscapeProxy.ChangeComponentScreenSizeToUseSubSections
}; 



// Class Landscape.MaterialExpressionLandscapeGrassOutput
// Size: 0x50(Inherited: 0x40) 
struct UMaterialExpressionLandscapeGrassOutput : public UMaterialExpressionCustomOutput
{
	struct TArray<struct FGrassInput> GrassTypes;  // 0x40(0x10)

}; 



// Class Landscape.Landscape
// Size: 0x598(Inherited: 0x598) 
struct ALandscape : public ALandscapeProxy
{

}; 



// Class Landscape.LandscapeLODStreamingProxy
// Size: 0x68(Inherited: 0x60) 
struct ULandscapeLODStreamingProxy : public UStreamableRenderAsset
{
	char pad_96[8];  // 0x60(0x8)

}; 



// Class Landscape.LandscapeMeshProxyActor
// Size: 0x228(Inherited: 0x220) 
struct ALandscapeMeshProxyActor : public AActor
{
	struct ULandscapeMeshProxyComponent* LandscapeMeshProxyComponent;  // 0x220(0x8)

}; 



// Class Landscape.LandscapeBlueprintBrushBase
// Size: 0x220(Inherited: 0x220) 
struct ALandscapeBlueprintBrushBase : public AActor
{

	void RequestLandscapeUpdate(); // Function Landscape.LandscapeBlueprintBrushBase.RequestLandscapeUpdate
	struct UTextureRenderTarget2D* Render(bool InIsHeightmap, struct UTextureRenderTarget2D* InCombinedResult, struct FName& InWeightmapLayerName); // Function Landscape.LandscapeBlueprintBrushBase.Render
	void Initialize(struct FTransform& InLandscapeTransform, struct FIntPoint& InLandscapeSize, struct FIntPoint& InLandscapeRenderTargetSize); // Function Landscape.LandscapeBlueprintBrushBase.Initialize
	void GetBlueprintRenderDependencies(struct TArray<struct UObject*>& OutStreamableAssets); // Function Landscape.LandscapeBlueprintBrushBase.GetBlueprintRenderDependencies
}; 



// Class Landscape.LandscapeGizmoActor
// Size: 0x220(Inherited: 0x220) 
struct ALandscapeGizmoActor : public AActor
{

}; 



// Class Landscape.LandscapeGizmoActiveActor
// Size: 0x270(Inherited: 0x220) 
struct ALandscapeGizmoActiveActor : public ALandscapeGizmoActor
{
	char pad_544[80];  // 0x220(0x50)

}; 



// Class Landscape.LandscapeGizmoRenderComponent
// Size: 0x450(Inherited: 0x450) 
struct ULandscapeGizmoRenderComponent : public UPrimitiveComponent
{

}; 



// Class Landscape.LandscapeGrassType
// Size: 0x60(Inherited: 0x28) 
struct ULandscapeGrassType : public UObject
{
	struct TArray<struct FGrassVariety> GrassVarieties;  // 0x28(0x10)
	char bEnableDensityScaling : 1;  // 0x38(0x1)
	char pad_56_1 : 7;  // 0x38(0x1)
	char pad_57[8];  // 0x39(0x8)
	struct UStaticMesh* GrassMesh;  // 0x40(0x8)
	float GrassDensity;  // 0x48(0x4)
	float PlacementJitter;  // 0x4C(0x4)
	int32_t StartCullDistance;  // 0x50(0x4)
	int32_t EndCullDistance;  // 0x54(0x4)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool RandomRotation : 1;  // 0x58(0x1)
	char pad_89_1 : 7;  // 0x59(0x1)
	bool AlignToSurface : 1;  // 0x59(0x1)
	char pad_90[6];  // 0x5A(0x6)

}; 



// Class Landscape.LandscapeWeightmapUsage
// Size: 0x58(Inherited: 0x28) 
struct ULandscapeWeightmapUsage : public UObject
{
	struct ULandscapeComponent* ChannelUsage[4];  // 0x28(0x20)
	struct FGuid LayerGuid;  // 0x48(0x10)

}; 



// Class Landscape.LandscapeHeightfieldCollisionComponent
// Size: 0x530(Inherited: 0x450) 
struct ULandscapeHeightfieldCollisionComponent : public UPrimitiveComponent
{
	struct TArray<struct ULandscapeLayerInfoObject*> ComponentLayerInfos;  // 0x450(0x10)
	int32_t SectionBaseX;  // 0x460(0x4)
	int32_t SectionBaseY;  // 0x464(0x4)
	int32_t CollisionSizeQuads;  // 0x468(0x4)
	float CollisionScale;  // 0x46C(0x4)
	int32_t SimpleCollisionSizeQuads;  // 0x470(0x4)
	char pad_1140[4];  // 0x474(0x4)
	struct TArray<char> CollisionQuadFlags;  // 0x478(0x10)
	struct FGuid HeightfieldGuid;  // 0x488(0x10)
	struct FBox CachedLocalBox;  // 0x498(0x1C)
	 RenderComponent;  // 0x4B4(0x1C)
	char pad_1232[16];  // 0x4D0(0x10)
	struct TArray<struct UPhysicalMaterial*> CookedPhysicalMaterials;  // 0x4E0(0x10)
	char pad_1264[64];  // 0x4F0(0x40)

	struct ULandscapeComponent* GetRenderComponent(); // Function Landscape.LandscapeHeightfieldCollisionComponent.GetRenderComponent
}; 



// Class Landscape.LandscapeSplineSegment
// Size: 0xB0(Inherited: 0x28) 
struct ULandscapeSplineSegment : public UObject
{
	struct FLandscapeSplineSegmentConnection Connections[2];  // 0x28(0x30)
	struct FInterpCurveVector SplineInfo;  // 0x58(0x18)
	struct TArray<struct FLandscapeSplineInterpPoint> Points;  // 0x70(0x10)
	struct FBox Bounds;  // 0x80(0x1C)
	char pad_156[4];  // 0x9C(0x4)
	struct TArray<struct USplineMeshComponent*> LocalMeshComponents;  // 0xA0(0x10)

}; 



// Class Landscape.LandscapeInfo
// Size: 0x210(Inherited: 0x28) 
struct ULandscapeInfo : public UObject
{
	 LandscapeActor;  // 0x28(0x1C)
	struct FGuid LandscapeGuid;  // 0x44(0x10)
	int32_t ComponentSizeQuads;  // 0x54(0x4)
	int32_t SubsectionSizeQuads;  // 0x58(0x4)
	int32_t ComponentNumSubsections;  // 0x5C(0x4)
	struct FVector DrawScale;  // 0x60(0xC)
	char pad_108[164];  // 0x6C(0xA4)
	struct TArray<struct ALandscapeStreamingProxy*> Proxies;  // 0x110(0x10)
	char pad_288[240];  // 0x120(0xF0)

}; 



// Class Landscape.MaterialExpressionLandscapeLayerSwitch
// Size: 0x88(Inherited: 0x40) 
struct UMaterialExpressionLandscapeLayerSwitch : public UMaterialExpression
{
	struct FExpressionInput LayerUsed;  // 0x40(0x14)
	struct FExpressionInput LayerNotUsed;  // 0x54(0x14)
	struct FName ParameterName;  // 0x68(0x8)
	char PreviewUsed : 1;  // 0x70(0x1)
	char pad_112_1 : 7;  // 0x70(0x1)
	char pad_113[4];  // 0x71(0x4)
	struct FGuid ExpressionGUID;  // 0x74(0x10)
	char pad_132[4];  // 0x84(0x4)

}; 



// Class Landscape.LandscapeLayerInfoObject
// Size: 0x50(Inherited: 0x28) 
struct ULandscapeLayerInfoObject : public UObject
{
	struct FName LayerName;  // 0x28(0x8)
	struct UPhysicalMaterial* PhysMaterial;  // 0x30(0x8)
	float Hardness;  // 0x38(0x4)
	struct FLinearColor LayerUsageDebugColor;  // 0x3C(0x10)
	char pad_76[4];  // 0x4C(0x4)

}; 



// Class Landscape.LandscapeMaterialInstanceConstant
// Size: 0x330(Inherited: 0x318) 
struct ULandscapeMaterialInstanceConstant : public UMaterialInstanceConstant
{
	struct TArray<struct FLandscapeMaterialTextureStreamingInfo> TextureStreamingInfo;  // 0x318(0x10)
	char bIsLayerThumbnail : 1;  // 0x328(0x1)
	char bDisableTessellation : 1;  // 0x328(0x1)
	char bMobile : 1;  // 0x328(0x1)
	char bEditorToolUsage : 1;  // 0x328(0x1)
	char pad_808_1 : 4;  // 0x328(0x1)
	char pad_809[8];  // 0x329(0x8)

}; 



// Class Landscape.LandscapeMeshProxyComponent
// Size: 0x510(Inherited: 0x4E0) 
struct ULandscapeMeshProxyComponent : public UStaticMeshComponent
{
	struct FGuid LandscapeGuid;  // 0x4E0(0x10)
	struct TArray<struct FIntPoint> ProxyComponentBases;  // 0x4F0(0x10)
	int8_t ProxyLOD;  // 0x500(0x1)
	char pad_1281[15];  // 0x501(0xF)

}; 



// Class Landscape.LandscapeSettings
// Size: 0x40(Inherited: 0x38) 
struct ULandscapeSettings : public UDeveloperSettings
{
	int32_t MaxNumberOfLayers;  // 0x38(0x4)
	char pad_60[4];  // 0x3C(0x4)

}; 



// Class Landscape.LandscapeSplinesComponent
// Size: 0x480(Inherited: 0x450) 
struct ULandscapeSplinesComponent : public UPrimitiveComponent
{
	struct TArray<struct ULandscapeSplineControlPoint*> ControlPoints;  // 0x450(0x10)
	struct TArray<struct ULandscapeSplineSegment*> Segments;  // 0x460(0x10)
	struct TArray<struct UMeshComponent*> CookedForeignMeshComponents;  // 0x470(0x10)

	struct TArray<struct USplineMeshComponent*> GetSplineMeshComponents(); // Function Landscape.LandscapeSplinesComponent.GetSplineMeshComponents
}; 



// Class Landscape.MaterialExpressionLandscapeLayerWeight
// Size: 0x90(Inherited: 0x40) 
struct UMaterialExpressionLandscapeLayerWeight : public UMaterialExpression
{
	struct FExpressionInput Base;  // 0x40(0x14)
	struct FExpressionInput Layer;  // 0x54(0x14)
	struct FName ParameterName;  // 0x68(0x8)
	float PreviewWeight;  // 0x70(0x4)
	struct FVector ConstBase;  // 0x74(0xC)
	struct FGuid ExpressionGUID;  // 0x80(0x10)

}; 



// Class Landscape.LandscapeSplineControlPoint
// Size: 0xA8(Inherited: 0x28) 
struct ULandscapeSplineControlPoint : public UObject
{
	struct FVector Location;  // 0x28(0xC)
	struct FRotator Rotation;  // 0x34(0xC)
	float Width;  // 0x40(0x4)
	float LayerWidthRatio;  // 0x44(0x4)
	float SideFalloff;  // 0x48(0x4)
	float LeftSideFalloffFactor;  // 0x4C(0x4)
	float RightSideFalloffFactor;  // 0x50(0x4)
	float LeftSideLayerFalloffFactor;  // 0x54(0x4)
	float RightSideLayerFalloffFactor;  // 0x58(0x4)
	float EndFalloff;  // 0x5C(0x4)
	struct TArray<struct FLandscapeSplineConnection> ConnectedSegments;  // 0x60(0x10)
	struct TArray<struct FLandscapeSplineInterpPoint> Points;  // 0x70(0x10)
	struct FBox Bounds;  // 0x80(0x1C)
	char pad_156[4];  // 0x9C(0x4)
	struct UControlPointMeshComponent* LocalMeshComponent;  // 0xA0(0x8)

}; 



// Class Landscape.LandscapeStreamingProxy
// Size: 0x5B8(Inherited: 0x598) 
struct ALandscapeStreamingProxy : public ALandscapeProxy
{
	 LandscapeActor;  // 0x598(0x1C)
	char pad_1460[4];  // 0x5B4(0x4)

}; 



// Class Landscape.MaterialExpressionLandscapePhysicalMaterialOutput
// Size: 0x50(Inherited: 0x40) 
struct UMaterialExpressionLandscapePhysicalMaterialOutput : public UMaterialExpressionCustomOutput
{
	struct TArray<struct FPhysicalMaterialInput> Inputs;  // 0x40(0x10)

}; 



// Class Landscape.LandscapeSubsystem
// Size: 0x50(Inherited: 0x40) 
struct ULandscapeSubsystem : public UTickableWorldSubsystem
{
	char pad_64[16];  // 0x40(0x10)

}; 



// Class Landscape.MaterialExpressionLandscapeLayerBlend
// Size: 0x60(Inherited: 0x40) 
struct UMaterialExpressionLandscapeLayerBlend : public UMaterialExpression
{
	struct TArray<struct FLayerBlendInput> Layers;  // 0x40(0x10)
	struct FGuid ExpressionGUID;  // 0x50(0x10)

}; 



// Class Landscape.MaterialExpressionLandscapeLayerCoords
// Size: 0x58(Inherited: 0x40) 
struct UMaterialExpressionLandscapeLayerCoords : public UMaterialExpression
{
	char ETerrainCoordMappingType MappingType;  // 0x40(0x1)
	char ELandscapeCustomizedCoordType CustomUVType;  // 0x41(0x1)
	char pad_66[2];  // 0x42(0x2)
	float MappingScale;  // 0x44(0x4)
	float MappingRotation;  // 0x48(0x4)
	float MappingPanU;  // 0x4C(0x4)
	float MappingPanV;  // 0x50(0x4)
	char pad_84[4];  // 0x54(0x4)

}; 



// Class Landscape.MaterialExpressionLandscapeLayerSample
// Size: 0x60(Inherited: 0x40) 
struct UMaterialExpressionLandscapeLayerSample : public UMaterialExpression
{
	struct FName ParameterName;  // 0x40(0x8)
	float PreviewWeight;  // 0x48(0x4)
	struct FGuid ExpressionGUID;  // 0x4C(0x10)
	char pad_92[4];  // 0x5C(0x4)

}; 



// Class Landscape.MaterialExpressionLandscapeVisibilityMask
// Size: 0x50(Inherited: 0x40) 
struct UMaterialExpressionLandscapeVisibilityMask : public UMaterialExpression
{
	struct FGuid ExpressionGUID;  // 0x40(0x10)

}; 



