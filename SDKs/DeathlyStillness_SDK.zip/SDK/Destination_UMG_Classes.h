#pragma once 
#include <Destination_UMG_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass Destination_UMG.Destination_UMG_C
// Size: 0x2A0(Inherited: 0x260) 
struct UDestination_UMG_C : public UUserWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x260(0x8)
	struct UWidgetAnimation* Tip;  // 0x268(0x8)
	struct UImage* Image_1;  // 0x270(0x8)
	struct UTextBlock* TextBlock_65;  // 0x278(0x8)
	float Distance;  // 0x280(0x4)
	float OffsetPosition;  // 0x284(0x4)
	struct FText ;  // 0x288(0x18)

	void QuestDistance(struct AActor* , struct FTransform& T, struct AActor* ); // Function Destination_UMG.Destination_UMG_C.QuestDistance
	void Construct(); // Function Destination_UMG.Destination_UMG_C.Construct
	void ExecuteUbergraph_Destination_UMG(int32_t EntryPoint); // Function Destination_UMG.Destination_UMG_C.ExecuteUbergraph_Destination_UMG
}; 



