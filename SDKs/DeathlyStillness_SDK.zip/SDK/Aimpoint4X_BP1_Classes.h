#pragma once 
#include <Aimpoint4X_BP1_Structs.h>
 
 
 
// BlueprintGeneratedClass Aimpoint4X_BP1.Aimpoint4X_BP1_C
// Size: 0x2B0(Inherited: 0x2B0) 
struct AAimpoint4X_BP1_C : public AAimpoint2X_BP_C
{

}; 



