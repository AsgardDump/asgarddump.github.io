#include "SDK.h" 
 
 
void UBTTask_BlueprintBase::ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn){

	static UObject* p_ReceiveExecuteAI = UObject::FindObject<UFunction>("Function Entity_RandomMove.Entity_RandomMove_C.ReceiveExecuteAI");

	struct {
		struct AAIController* OwnerController;
		struct APawn* ControlledPawn;
	} parms;

	parms.OwnerController = OwnerController;
	parms.ControlledPawn = ControlledPawn;

	ProcessEvent(p_ReceiveExecuteAI, &parms);
}

void UBTTask_BlueprintBase::ExecuteUbergraph_Entity_RandomMove(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph_Entity_RandomMove = UObject::FindObject<UFunction>("Function Entity_RandomMove.Entity_RandomMove_C.ExecuteUbergraph_Entity_RandomMove");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph_Entity_RandomMove, &parms);
}

