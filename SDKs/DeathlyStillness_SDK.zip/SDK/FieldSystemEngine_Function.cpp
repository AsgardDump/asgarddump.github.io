#include "SDK.h" 
 
 
struct UFieldSystemMetaDataIteration* UFieldSystemMetaData::SetMetaDataIteration(int32_t Iterations){

	static UObject* p_SetMetaDataIteration = UObject::FindObject<UFunction>("Function FieldSystemEngine.FieldSystemMetaDataIteration.SetMetaDataIteration");

	struct {
		int32_t Iterations;
		struct UFieldSystemMetaDataIteration* return_value;
	} parms;

	parms.Iterations = Iterations;

	ProcessEvent(p_SetMetaDataIteration, &parms);
	return parms.return_value;
}

void UPrimitiveComponent::ResetFieldSystem(){

	static UObject* p_ResetFieldSystem = UObject::FindObject<UFunction>("Function FieldSystemEngine.FieldSystemComponent.ResetFieldSystem");

	struct {
	} parms;


	ProcessEvent(p_ResetFieldSystem, &parms);
}

void UPrimitiveComponent::RemovePersistentFields(){

	static UObject* p_RemovePersistentFields = UObject::FindObject<UFunction>("Function FieldSystemEngine.FieldSystemComponent.RemovePersistentFields");

	struct {
	} parms;


	ProcessEvent(p_RemovePersistentFields, &parms);
}

void UPrimitiveComponent::ApplyUniformVectorFalloffForce(bool Enabled, struct FVector Position, struct FVector Direction, float Radius, float Magnitude){

	static UObject* p_ApplyUniformVectorFalloffForce = UObject::FindObject<UFunction>("Function FieldSystemEngine.FieldSystemComponent.ApplyUniformVectorFalloffForce");

	struct {
		bool Enabled;
		struct FVector Position;
		struct FVector Direction;
		float Radius;
		float Magnitude;
	} parms;

	parms.Enabled = Enabled;
	parms.Position = Position;
	parms.Direction = Direction;
	parms.Radius = Radius;
	parms.Magnitude = Magnitude;

	ProcessEvent(p_ApplyUniformVectorFalloffForce, &parms);
}

void UPrimitiveComponent::ApplyStrainField(bool Enabled, struct FVector Position, float Radius, float Magnitude, int32_t Iterations){

	static UObject* p_ApplyStrainField = UObject::FindObject<UFunction>("Function FieldSystemEngine.FieldSystemComponent.ApplyStrainField");

	struct {
		bool Enabled;
		struct FVector Position;
		float Radius;
		float Magnitude;
		int32_t Iterations;
	} parms;

	parms.Enabled = Enabled;
	parms.Position = Position;
	parms.Radius = Radius;
	parms.Magnitude = Magnitude;
	parms.Iterations = Iterations;

	ProcessEvent(p_ApplyStrainField, &parms);
}

void UPrimitiveComponent::ApplyStayDynamicField(bool Enabled, struct FVector Position, float Radius){

	static UObject* p_ApplyStayDynamicField = UObject::FindObject<UFunction>("Function FieldSystemEngine.FieldSystemComponent.ApplyStayDynamicField");

	struct {
		bool Enabled;
		struct FVector Position;
		float Radius;
	} parms;

	parms.Enabled = Enabled;
	parms.Position = Position;
	parms.Radius = Radius;

	ProcessEvent(p_ApplyStayDynamicField, &parms);
}

void UPrimitiveComponent::ApplyRadialVectorFalloffForce(bool Enabled, struct FVector Position, float Radius, float Magnitude){

	static UObject* p_ApplyRadialVectorFalloffForce = UObject::FindObject<UFunction>("Function FieldSystemEngine.FieldSystemComponent.ApplyRadialVectorFalloffForce");

	struct {
		bool Enabled;
		struct FVector Position;
		float Radius;
		float Magnitude;
	} parms;

	parms.Enabled = Enabled;
	parms.Position = Position;
	parms.Radius = Radius;
	parms.Magnitude = Magnitude;

	ProcessEvent(p_ApplyRadialVectorFalloffForce, &parms);
}

void UPrimitiveComponent::ApplyRadialForce(bool Enabled, struct FVector Position, float Magnitude){

	static UObject* p_ApplyRadialForce = UObject::FindObject<UFunction>("Function FieldSystemEngine.FieldSystemComponent.ApplyRadialForce");

	struct {
		bool Enabled;
		struct FVector Position;
		float Magnitude;
	} parms;

	parms.Enabled = Enabled;
	parms.Position = Position;
	parms.Magnitude = Magnitude;

	ProcessEvent(p_ApplyRadialForce, &parms);
}

void UPrimitiveComponent::ApplyPhysicsField(bool Enabled, char EFieldPhysicsType Target, struct UFieldSystemMetaData* MetaData, struct UFieldNodeBase* Field){

	static UObject* p_ApplyPhysicsField = UObject::FindObject<UFunction>("Function FieldSystemEngine.FieldSystemComponent.ApplyPhysicsField");

	struct {
		bool Enabled;
		char EFieldPhysicsType Target;
		struct UFieldSystemMetaData* MetaData;
		struct UFieldNodeBase* Field;
	} parms;

	parms.Enabled = Enabled;
	parms.Target = Target;
	parms.MetaData = MetaData;
	parms.Field = Field;

	ProcessEvent(p_ApplyPhysicsField, &parms);
}

void UPrimitiveComponent::ApplyLinearForce(bool Enabled, struct FVector Direction, float Magnitude){

	static UObject* p_ApplyLinearForce = UObject::FindObject<UFunction>("Function FieldSystemEngine.FieldSystemComponent.ApplyLinearForce");

	struct {
		bool Enabled;
		struct FVector Direction;
		float Magnitude;
	} parms;

	parms.Enabled = Enabled;
	parms.Direction = Direction;
	parms.Magnitude = Magnitude;

	ProcessEvent(p_ApplyLinearForce, &parms);
}

void UPrimitiveComponent::AddPersistentField(bool Enabled, char EFieldPhysicsType Target, struct UFieldSystemMetaData* MetaData, struct UFieldNodeBase* Field){

	static UObject* p_AddPersistentField = UObject::FindObject<UFunction>("Function FieldSystemEngine.FieldSystemComponent.AddPersistentField");

	struct {
		bool Enabled;
		char EFieldPhysicsType Target;
		struct UFieldSystemMetaData* MetaData;
		struct UFieldNodeBase* Field;
	} parms;

	parms.Enabled = Enabled;
	parms.Target = Target;
	parms.MetaData = MetaData;
	parms.Field = Field;

	ProcessEvent(p_AddPersistentField, &parms);
}

void UPrimitiveComponent::AddFieldCommand(bool Enabled, char EFieldPhysicsType Target, struct UFieldSystemMetaData* MetaData, struct UFieldNodeBase* Field){

	static UObject* p_AddFieldCommand = UObject::FindObject<UFunction>("Function FieldSystemEngine.FieldSystemComponent.AddFieldCommand");

	struct {
		bool Enabled;
		char EFieldPhysicsType Target;
		struct UFieldSystemMetaData* MetaData;
		struct UFieldNodeBase* Field;
	} parms;

	parms.Enabled = Enabled;
	parms.Target = Target;
	parms.MetaData = MetaData;
	parms.Field = Field;

	ProcessEvent(p_AddFieldCommand, &parms);
}

struct UFieldSystemMetaDataProcessingResolution* UFieldSystemMetaData::SetMetaDataaProcessingResolutionType(char EFieldResolutionType ResolutionType){

	static UObject* p_SetMetaDataaProcessingResolutionType = UObject::FindObject<UFunction>("Function FieldSystemEngine.FieldSystemMetaDataProcessingResolution.SetMetaDataaProcessingResolutionType");

	struct {
		char EFieldResolutionType ResolutionType;
		struct UFieldSystemMetaDataProcessingResolution* return_value;
	} parms;

	parms.ResolutionType = ResolutionType;

	ProcessEvent(p_SetMetaDataaProcessingResolutionType, &parms);
	return parms.return_value;
}

struct UFieldSystemMetaDataFilter* UFieldSystemMetaData::SetMetaDataFilterType(char EFieldFilterType FilterType){

	static UObject* p_SetMetaDataFilterType = UObject::FindObject<UFunction>("Function FieldSystemEngine.FieldSystemMetaDataFilter.SetMetaDataFilterType");

	struct {
		char EFieldFilterType FilterType;
		struct UFieldSystemMetaDataFilter* return_value;
	} parms;

	parms.FilterType = FilterType;

	ProcessEvent(p_SetMetaDataFilterType, &parms);
	return parms.return_value;
}

struct UUniformVector* UFieldNodeVector::SetUniformVector(float Magnitude, struct FVector Direction){

	static UObject* p_SetUniformVector = UObject::FindObject<UFunction>("Function FieldSystemEngine.UniformVector.SetUniformVector");

	struct {
		float Magnitude;
		struct FVector Direction;
		struct UUniformVector* return_value;
	} parms;

	parms.Magnitude = Magnitude;
	parms.Direction = Direction;

	ProcessEvent(p_SetUniformVector, &parms);
	return parms.return_value;
}

struct UUniformInteger* UFieldNodeInt::SetUniformInteger(int32_t Magnitude){

	static UObject* p_SetUniformInteger = UObject::FindObject<UFunction>("Function FieldSystemEngine.UniformInteger.SetUniformInteger");

	struct {
		int32_t Magnitude;
		struct UUniformInteger* return_value;
	} parms;

	parms.Magnitude = Magnitude;

	ProcessEvent(p_SetUniformInteger, &parms);
	return parms.return_value;
}

struct URadialIntMask* UFieldNodeInt::SetRadialIntMask(float Radius, struct FVector Position, int32_t InteriorValue, int32_t ExteriorValue, char ESetMaskConditionType SetMaskConditionIn){

	static UObject* p_SetRadialIntMask = UObject::FindObject<UFunction>("Function FieldSystemEngine.RadialIntMask.SetRadialIntMask");

	struct {
		float Radius;
		struct FVector Position;
		int32_t InteriorValue;
		int32_t ExteriorValue;
		char ESetMaskConditionType SetMaskConditionIn;
		struct URadialIntMask* return_value;
	} parms;

	parms.Radius = Radius;
	parms.Position = Position;
	parms.InteriorValue = InteriorValue;
	parms.ExteriorValue = ExteriorValue;
	parms.SetMaskConditionIn = SetMaskConditionIn;

	ProcessEvent(p_SetRadialIntMask, &parms);
	return parms.return_value;
}

struct UUniformScalar* UFieldNodeFloat::SetUniformScalar(float Magnitude){

	static UObject* p_SetUniformScalar = UObject::FindObject<UFunction>("Function FieldSystemEngine.UniformScalar.SetUniformScalar");

	struct {
		float Magnitude;
		struct UUniformScalar* return_value;
	} parms;

	parms.Magnitude = Magnitude;

	ProcessEvent(p_SetUniformScalar, &parms);
	return parms.return_value;
}

struct UWaveScalar* UFieldNodeFloat::SetWaveScalar(float Magnitude, struct FVector Position, float Wavelength, float Period, float Time, char EWaveFunctionType Function, char EFieldFalloffType Falloff){

	static UObject* p_SetWaveScalar = UObject::FindObject<UFunction>("Function FieldSystemEngine.WaveScalar.SetWaveScalar");

	struct {
		float Magnitude;
		struct FVector Position;
		float Wavelength;
		float Period;
		float Time;
		char EWaveFunctionType Function;
		char EFieldFalloffType Falloff;
		struct UWaveScalar* return_value;
	} parms;

	parms.Magnitude = Magnitude;
	parms.Position = Position;
	parms.Wavelength = Wavelength;
	parms.Period = Period;
	parms.Time = Time;
	parms.Function = Function;
	parms.Falloff = Falloff;

	ProcessEvent(p_SetWaveScalar, &parms);
	return parms.return_value;
}

struct URadialFalloff* UFieldNodeFloat::SetRadialFalloff(float Magnitude, float MinRange, float MaxRange, float Default, float Radius, struct FVector Position, char EFieldFalloffType Falloff){

	static UObject* p_SetRadialFalloff = UObject::FindObject<UFunction>("Function FieldSystemEngine.RadialFalloff.SetRadialFalloff");

	struct {
		float Magnitude;
		float MinRange;
		float MaxRange;
		float Default;
		float Radius;
		struct FVector Position;
		char EFieldFalloffType Falloff;
		struct URadialFalloff* return_value;
	} parms;

	parms.Magnitude = Magnitude;
	parms.MinRange = MinRange;
	parms.MaxRange = MaxRange;
	parms.Default = Default;
	parms.Radius = Radius;
	parms.Position = Position;
	parms.Falloff = Falloff;

	ProcessEvent(p_SetRadialFalloff, &parms);
	return parms.return_value;
}

struct UPlaneFalloff* UFieldNodeFloat::SetPlaneFalloff(float Magnitude, float MinRange, float MaxRange, float Default, float Distance, struct FVector Position, struct FVector Normal, char EFieldFalloffType Falloff){

	static UObject* p_SetPlaneFalloff = UObject::FindObject<UFunction>("Function FieldSystemEngine.PlaneFalloff.SetPlaneFalloff");

	struct {
		float Magnitude;
		float MinRange;
		float MaxRange;
		float Default;
		float Distance;
		struct FVector Position;
		struct FVector Normal;
		char EFieldFalloffType Falloff;
		struct UPlaneFalloff* return_value;
	} parms;

	parms.Magnitude = Magnitude;
	parms.MinRange = MinRange;
	parms.MaxRange = MaxRange;
	parms.Default = Default;
	parms.Distance = Distance;
	parms.Position = Position;
	parms.Normal = Normal;
	parms.Falloff = Falloff;

	ProcessEvent(p_SetPlaneFalloff, &parms);
	return parms.return_value;
}

struct UBoxFalloff* UFieldNodeFloat::SetBoxFalloff(float Magnitude, float MinRange, float MaxRange, float Default, struct FTransform Transform, char EFieldFalloffType Falloff){

	static UObject* p_SetBoxFalloff = UObject::FindObject<UFunction>("Function FieldSystemEngine.BoxFalloff.SetBoxFalloff");

	struct {
		float Magnitude;
		float MinRange;
		float MaxRange;
		float Default;
		struct FTransform Transform;
		char EFieldFalloffType Falloff;
		struct UBoxFalloff* return_value;
	} parms;

	parms.Magnitude = Magnitude;
	parms.MinRange = MinRange;
	parms.MaxRange = MaxRange;
	parms.Default = Default;
	parms.Transform = Transform;
	parms.Falloff = Falloff;

	ProcessEvent(p_SetBoxFalloff, &parms);
	return parms.return_value;
}

struct UNoiseField* UFieldNodeFloat::SetNoiseField(float MinRange, float MaxRange, struct FTransform Transform){

	static UObject* p_SetNoiseField = UObject::FindObject<UFunction>("Function FieldSystemEngine.NoiseField.SetNoiseField");

	struct {
		float MinRange;
		float MaxRange;
		struct FTransform Transform;
		struct UNoiseField* return_value;
	} parms;

	parms.MinRange = MinRange;
	parms.MaxRange = MaxRange;
	parms.Transform = Transform;

	ProcessEvent(p_SetNoiseField, &parms);
	return parms.return_value;
}

struct URadialVector* UFieldNodeVector::SetRadialVector(float Magnitude, struct FVector Position){

	static UObject* p_SetRadialVector = UObject::FindObject<UFunction>("Function FieldSystemEngine.RadialVector.SetRadialVector");

	struct {
		float Magnitude;
		struct FVector Position;
		struct URadialVector* return_value;
	} parms;

	parms.Magnitude = Magnitude;
	parms.Position = Position;

	ProcessEvent(p_SetRadialVector, &parms);
	return parms.return_value;
}

struct URandomVector* UFieldNodeVector::SetRandomVector(float Magnitude){

	static UObject* p_SetRandomVector = UObject::FindObject<UFunction>("Function FieldSystemEngine.RandomVector.SetRandomVector");

	struct {
		float Magnitude;
		struct URandomVector* return_value;
	} parms;

	parms.Magnitude = Magnitude;

	ProcessEvent(p_SetRandomVector, &parms);
	return parms.return_value;
}

struct UOperatorField* UFieldNodeBase::SetOperatorField(float Magnitude, struct UFieldNodeBase* LeftField, struct UFieldNodeBase* RightField, char EFieldOperationType Operation){

	static UObject* p_SetOperatorField = UObject::FindObject<UFunction>("Function FieldSystemEngine.OperatorField.SetOperatorField");

	struct {
		float Magnitude;
		struct UFieldNodeBase* LeftField;
		struct UFieldNodeBase* RightField;
		char EFieldOperationType Operation;
		struct UOperatorField* return_value;
	} parms;

	parms.Magnitude = Magnitude;
	parms.LeftField = LeftField;
	parms.RightField = RightField;
	parms.Operation = Operation;

	ProcessEvent(p_SetOperatorField, &parms);
	return parms.return_value;
}

struct UToIntegerField* UFieldNodeInt::SetToIntegerField(struct UFieldNodeFloat* FloatField){

	static UObject* p_SetToIntegerField = UObject::FindObject<UFunction>("Function FieldSystemEngine.ToIntegerField.SetToIntegerField");

	struct {
		struct UFieldNodeFloat* FloatField;
		struct UToIntegerField* return_value;
	} parms;

	parms.FloatField = FloatField;

	ProcessEvent(p_SetToIntegerField, &parms);
	return parms.return_value;
}

struct UToFloatField* UFieldNodeFloat::SetToFloatField(struct UFieldNodeInt* IntegerField){

	static UObject* p_SetToFloatField = UObject::FindObject<UFunction>("Function FieldSystemEngine.ToFloatField.SetToFloatField");

	struct {
		struct UFieldNodeInt* IntegerField;
		struct UToFloatField* return_value;
	} parms;

	parms.IntegerField = IntegerField;

	ProcessEvent(p_SetToFloatField, &parms);
	return parms.return_value;
}

struct UCullingField* UFieldNodeBase::SetCullingField(struct UFieldNodeBase* Culling, struct UFieldNodeBase* Field, char EFieldCullingOperationType Operation){

	static UObject* p_SetCullingField = UObject::FindObject<UFunction>("Function FieldSystemEngine.CullingField.SetCullingField");

	struct {
		struct UFieldNodeBase* Culling;
		struct UFieldNodeBase* Field;
		char EFieldCullingOperationType Operation;
		struct UCullingField* return_value;
	} parms;

	parms.Culling = Culling;
	parms.Field = Field;
	parms.Operation = Operation;

	ProcessEvent(p_SetCullingField, &parms);
	return parms.return_value;
}

struct UReturnResultsTerminal* UFieldNodeBase::SetReturnResultsTerminal(){

	static UObject* p_SetReturnResultsTerminal = UObject::FindObject<UFunction>("Function FieldSystemEngine.ReturnResultsTerminal.SetReturnResultsTerminal");

	struct {
		struct UReturnResultsTerminal* return_value;
	} parms;


	ProcessEvent(p_SetReturnResultsTerminal, &parms);
	return parms.return_value;
}

