#pragma once 
#include "SDK.h" 
 
 
// Function InGame_Umg.InGame_Umg_C.ExecuteUbergraph_InGame_Umg
// Size: 0x1E0(Inherited: 0x0) 
struct FExecuteUbergraph_InGame_Umg
{
	int32_t EntryPoint;  // 0x0(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x4(0x4)
	struct FTimerHandle CallFunc_K2_SetTimer_ReturnValue;  // 0x8(0x8)
	struct UUMGSequencePlayer* CallFunc_PlayAnimation_ReturnValue;  // 0x10(0x8)
	struct UUMGSequencePlayer* CallFunc_PlayAnimation_ReturnValue_2;  // 0x18(0x8)
	struct TArray<struct AZombie_BP_C*> CallFunc_GetAllActorsOfClass_OutActors;  // 0x20(0x10)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x30(0x4)
	char pad_52[4];  // 0x34(0x4)
	struct UUMGSequencePlayer* CallFunc_PlayAnimation_ReturnValue_3;  // 0x38(0x8)
	struct FText CallFunc_Conv_IntToText_ReturnValue;  // 0x40(0x18)
	struct UUMGSequencePlayer* CallFunc_PlayAnimation_ReturnValue_4;  // 0x58(0x8)
	struct UUMGSequencePlayer* CallFunc_PlayAnimation_ReturnValue_5;  // 0x60(0x8)
	char EUMGSequencePlayMode K2Node_CustomEvent_PlayMode_4;  // 0x68(0x1)
	char pad_105[7];  // 0x69(0x7)
	struct UUMGSequencePlayer* CallFunc_PlayAnimation_ReturnValue_6;  // 0x70(0x8)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x78(0x1)
	char pad_121[3];  // 0x79(0x3)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x7C(0x4)
	float CallFunc_MapRangeClamped_ReturnValue;  // 0x80(0x4)
	struct FVector2D CallFunc_MakeVector2D_ReturnValue;  // 0x84(0x8)
	struct FVector2D CallFunc_MakeVector2D_ReturnValue_2;  // 0x8C(0x8)
	float CallFunc_Abs_ReturnValue;  // 0x94(0x4)
	struct FVector2D CallFunc_MakeVector2D_ReturnValue_3;  // 0x98(0x8)
	struct FVector2D CallFunc_MakeVector2D_ReturnValue_4;  // 0xA0(0x8)
	struct FGeometry K2Node_Event_MyGeometry;  // 0xA8(0x38)
	float K2Node_Event_InDeltaTime;  // 0xE0(0x4)
	char EUMGSequencePlayMode K2Node_CustomEvent_PlayMode_3;  // 0xE4(0x1)
	uint8_t  K2Node_CustomEvent___;  // 0xE5(0x1)
	uint8_t  K2Node_CustomEvent_dot;  // 0xE6(0x1)
	char pad_231[1];  // 0xE7(0x1)
	struct UUMGSequencePlayer* CallFunc_PlayAnimation_ReturnValue_7;  // 0xE8(0x8)
	struct UUMGSequencePlayer* CallFunc_PlayAnimation_ReturnValue_8;  // 0xF0(0x8)
	char EUMGSequencePlayMode K2Node_CustomEvent_PlayMode_2;  // 0xF8(0x1)
	char pad_249[7];  // 0xF9(0x7)
	struct UUMGSequencePlayer* CallFunc_PlayAnimation_ReturnValue_9;  // 0x100(0x8)
	struct UUMGSequencePlayer* CallFunc_PlayAnimation_ReturnValue_10;  // 0x108(0x8)
	struct APawn* CallFunc_GetPlayerPawn_ReturnValue;  // 0x110(0x8)
	struct APlayer_BP_C* K2Node_DynamicCast_AsPlayer_BP;  // 0x118(0x8)
	char pad_288_1 : 7;  // 0x120(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x120(0x1)
	char EUMGSequencePlayMode K2Node_CustomEvent_PlayMode;  // 0x121(0x1)
	char pad_290[6];  // 0x122(0x6)
	struct UUMGSequencePlayer* CallFunc_PlayAnimation_ReturnValue_11;  // 0x128(0x8)
	struct FSlateFontInfo K2Node_MakeStruct_SlateFontInfo;  // 0x130(0x58)
	struct FSlateFontInfo K2Node_MakeStruct_SlateFontInfo_2;  // 0x188(0x58)

}; 
// Function InGame_Umg.InGame_Umg_C.CrosshairFade_Event
// Size: 0x1(Inherited: 0x0) 
struct FCrosshairFade_Event
{
	char EUMGSequencePlayMode PlayMode;  // 0x0(0x1)

}; 
// Function InGame_Umg.InGame_Umg_C.GetText_2
// Size: 0x39(Inherited: 0x0) 
struct FGetText_2
{
	struct FText ReturnValue;  // 0x0(0x18)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool ___bool_Has_Been_Initd_Variable : 1;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool ___bool_IsClosed_Variable : 1;  // 0x19(0x1)
	char pad_26[6];  // 0x1A(0x6)
	struct FText CallFunc_Conv_IntToText_ReturnValue;  // 0x20(0x18)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool CallFunc_LessEqual_IntInt_ReturnValue : 1;  // 0x38(0x1)

}; 
// Function InGame_Umg.InGame_Umg_C.
// Size: 0x1(Inherited: 0x0) 
struct F
{
	char EUMGSequencePlayMode PlayMode;  // 0x0(0x1)

}; 
// Function InGame_Umg.InGame_Umg_C.DeadScreen
// Size: 0x1(Inherited: 0x0) 
struct FDeadScreen
{
	char EUMGSequencePlayMode PlayMode;  // 0x0(0x1)

}; 
// Function InGame_Umg.InGame_Umg_C.GetPercent_1
// Size: 0x24(Inherited: 0x0) 
struct FGetPercent_1
{
	float ReturnValue;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct ACharacter* CallFunc_GetPlayerCharacter_ReturnValue;  // 0x8(0x8)
	struct APlayer_BP_C* K2Node_DynamicCast_AsPlayer_BP;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)
	float CallFunc_SCL_Pure_GetSafeFloat_ReturnValue;  // 0x1C(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x20(0x4)

}; 
// Function InGame_Umg.InGame_Umg_C.Tick
// Size: 0x3C(Inherited: 0x3C) 
struct FTick : public FTick
{
	struct FGeometry MyGeometry;  // 0x0(0x38)
	float InDeltaTime;  // 0x38(0x4)

}; 
// Function InGame_Umg.InGame_Umg_C.GetFillColorAndOpacity_1
// Size: 0x38(Inherited: 0x0) 
struct FGetFillColorAndOpacity_1
{
	struct FLinearColor ReturnValue;  // 0x0(0x10)
	struct ACharacter* CallFunc_GetPlayerCharacter_ReturnValue;  // 0x10(0x8)
	struct APlayer_BP_C* K2Node_DynamicCast_AsPlayer_BP;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x20(0x1)
	char pad_33[3];  // 0x21(0x3)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x24(0x4)
	struct FLinearColor K2Node_MakeStruct_LinearColor;  // 0x28(0x10)

}; 
// Function InGame_Umg.InGame_Umg_C.GetText_1
// Size: 0x90(Inherited: 0x0) 
struct FGetText_1
{
	struct FText ReturnValue;  // 0x0(0x18)
	struct FSlateColor K2Node_MakeStruct_SlateColor;  // 0x18(0x28)
	struct FSlateColor K2Node_MakeStruct_SlateColor_2;  // 0x40(0x28)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x68(0x1)
	char pad_105[3];  // 0x69(0x3)
	int32_t CallFunc_SCL_Pure_GetSafeInt_ReturnValue;  // 0x6C(0x4)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool CallFunc_LessEqual_IntInt_ReturnValue : 1;  // 0x70(0x1)
	char pad_113[7];  // 0x71(0x7)
	struct FText CallFunc_Conv_IntToText_ReturnValue;  // 0x78(0x18)

}; 
// Function InGame_Umg.InGame_Umg_C.GetText_3
// Size: 0x38(Inherited: 0x0) 
struct FGetText_3
{
	struct FText ReturnValue;  // 0x0(0x18)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)
	int32_t CallFunc_SCL_Pure_GetSafeInt_ReturnValue;  // 0x1C(0x4)
	struct FText CallFunc_Conv_IntToText_ReturnValue;  // 0x20(0x18)

}; 
