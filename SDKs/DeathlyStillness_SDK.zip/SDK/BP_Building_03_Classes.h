#pragma once 
#include <BP_Building_03_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Building_03.BP_Building_03_C
// Size: 0x2B0(Inherited: 0x220) 
struct ABP_Building_03_C : public AActor
{
	struct UStaticMeshComponent* SM_Building_03_Lobby;  // 0x220(0x8)
	struct UChildActorComponent* ChildActor3;  // 0x228(0x8)
	struct UChildActorComponent* ChildActor2;  // 0x230(0x8)
	struct UChildActorComponent* ChildActor1;  // 0x238(0x8)
	struct UChildActorComponent* ChildActor;  // 0x240(0x8)
	struct UChildActorComponent* BP_Aircon;  // 0x248(0x8)
	struct UStaticMeshComponent* StaticMesh4;  // 0x250(0x8)
	struct UStaticMeshComponent* SM_Awning3;  // 0x258(0x8)
	struct UStaticMeshComponent* SM_Building_03_Door;  // 0x260(0x8)
	struct UStaticMeshComponent* StaticMesh3;  // 0x268(0x8)
	struct UStaticMeshComponent* StaticMesh2;  // 0x270(0x8)
	struct UStaticMeshComponent* StaticMesh1;  // 0x278(0x8)
	struct UStaticMeshComponent* StaticMesh;  // 0x280(0x8)
	struct UStaticMeshComponent* SM_CurtainSmall;  // 0x288(0x8)
	struct UStaticMeshComponent* SM_Building_03_Window;  // 0x290(0x8)
	struct UStaticMeshComponent* SM_Building_03_Columns;  // 0x298(0x8)
	struct UStaticMeshComponent* SM_Building_03;  // 0x2A0(0x8)
	struct USceneComponent* Scene;  // 0x2A8(0x8)

}; 



