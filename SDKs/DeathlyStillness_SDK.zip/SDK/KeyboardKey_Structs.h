#pragma once 
#include "SDK.h" 
 
 
// Function KeyboardKey.KeyboardKey_C.ExecuteUbergraph_KeyboardKey
// Size: 0x60(Inherited: 0x0) 
struct FExecuteUbergraph_KeyboardKey
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FSlateColor K2Node_MakeStruct_SlateColor;  // 0x8(0x28)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool K2Node_Event_IsDesignTime : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)
	struct UCanvasPanelSlot* CallFunc_SlotAsCanvasSlot_ReturnValue;  // 0x38(0x8)
	float CallFunc_BreakVector2D_X;  // 0x40(0x4)
	float CallFunc_BreakVector2D_Y;  // 0x44(0x4)
	struct UCanvasPanelSlot* CallFunc_SlotAsCanvasSlot_ReturnValue_2;  // 0x48(0x8)
	float CallFunc_Subtract_FloatFloat_ReturnValue;  // 0x50(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue_2;  // 0x54(0x4)
	struct FVector2D CallFunc_MakeVector2D_ReturnValue;  // 0x58(0x8)

}; 
// Function KeyboardKey.KeyboardKey_C.PreConstruct
// Size: 0x1(Inherited: 0x1) 
struct FPreConstruct : public FPreConstruct
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool IsDesignTime : 1;  // 0x0(0x1)

}; 
