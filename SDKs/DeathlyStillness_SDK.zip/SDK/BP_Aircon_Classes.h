#pragma once 
#include <BP_Aircon_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Aircon.BP_Aircon_C
// Size: 0x230(Inherited: 0x220) 
struct ABP_Aircon_C : public AActor
{
	struct USceneComponent* Scene;  // 0x220(0x8)
	char ENUM_AirconType Aircon Type;  // 0x228(0x1)
	char ENUM_AirconSupportType Support Type;  // 0x229(0x1)
	char pad_554[2];  // 0x22A(0x2)
	float Aircon offset;  // 0x22C(0x4)

	void UserConstructionScript(); // Function BP_Aircon.BP_Aircon_C.UserConstructionScript
}; 



