#include "SDK.h" 
 
 
int32_t UBlueprintFunctionLibrary::FoliageOverlappingSphereCount(struct UObject* WorldContextObject, struct UStaticMesh* StaticMesh, struct FVector CenterPosition, float Radius){

	static UObject* p_FoliageOverlappingSphereCount = UObject::FindObject<UFunction>("Function Foliage.FoliageStatistics.FoliageOverlappingSphereCount");

	struct {
		struct UObject* WorldContextObject;
		struct UStaticMesh* StaticMesh;
		struct FVector CenterPosition;
		float Radius;
		int32_t return_value;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.StaticMesh = StaticMesh;
	parms.CenterPosition = CenterPosition;
	parms.Radius = Radius;

	ProcessEvent(p_FoliageOverlappingSphereCount, &parms);
	return parms.return_value;
}

int32_t UBlueprintFunctionLibrary::FoliageOverlappingBoxCount(struct UObject* WorldContextObject, struct UStaticMesh* StaticMesh, struct FBox Box){

	static UObject* p_FoliageOverlappingBoxCount = UObject::FindObject<UFunction>("Function Foliage.FoliageStatistics.FoliageOverlappingBoxCount");

	struct {
		struct UObject* WorldContextObject;
		struct UStaticMesh* StaticMesh;
		struct FBox Box;
		int32_t return_value;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.StaticMesh = StaticMesh;
	parms.Box = Box;

	ProcessEvent(p_FoliageOverlappingBoxCount, &parms);
	return parms.return_value;
}

void AStaticMeshActor::CapsuleTouched(struct UPrimitiveComponent* OverlappedComp, struct AActor* Other, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult& OverlapInfo){

	static UObject* p_CapsuleTouched = UObject::FindObject<UFunction>("Function Foliage.InteractiveFoliageActor.CapsuleTouched");

	struct {
		struct UPrimitiveComponent* OverlappedComp;
		struct AActor* Other;
		struct UPrimitiveComponent* OtherComp;
		int32_t OtherBodyIndex;
		bool bFromSweep;
		struct FHitResult& OverlapInfo;
	} parms;

	parms.OverlappedComp = OverlappedComp;
	parms.Other = Other;
	parms.OtherComp = OtherComp;
	parms.OtherBodyIndex = OtherBodyIndex;
	parms.bFromSweep = bFromSweep;
	parms.OverlapInfo = OverlapInfo;

	ProcessEvent(p_CapsuleTouched, &parms);
}

void UObject::Simulate(int32_t NumSteps){

	static UObject* p_Simulate = UObject::FindObject<UFunction>("Function Foliage.ProceduralFoliageSpawner.Simulate");

	struct {
		int32_t NumSteps;
	} parms;

	parms.NumSteps = NumSteps;

	ProcessEvent(p_Simulate, &parms);
}

