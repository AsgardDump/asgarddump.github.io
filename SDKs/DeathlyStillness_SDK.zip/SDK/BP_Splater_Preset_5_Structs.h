#pragma once 
#include "SDK.h" 
 
 
// Function BP_Splater_Preset_5.BP_Splater_Preset_4_C.ExecuteUbergraph_BP_Splater_Preset_5
// Size: 0x190(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Splater_Preset_5
{
	int32_t EntryPoint;  // 0x0(0x4)
	int32_t ___int_Array_Index_Variable;  // 0x4(0x4)
	struct TArray<struct FBasicParticleData> K2Node_Event_Data;  // 0x8(0x10)
	struct UNiagaraSystem* K2Node_Event_NiagaraSystem;  // 0x18(0x8)
	struct FBasicParticleData CallFunc_Array_Get_Item;  // 0x20(0x1C)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x3C(0x4)
	struct FRotator CallFunc_MakeRotFromZ_ReturnValue;  // 0x40(0xC)
	int32_t CallFunc_Array_Length_ReturnValue_2;  // 0x4C(0x4)
	float CallFunc_FClamp_ReturnValue;  // 0x50(0x4)
	int32_t CallFunc_Subtract_IntInt_ReturnValue;  // 0x54(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x58(0x4)
	int32_t CallFunc_RandomIntegerInRange_ReturnValue;  // 0x5C(0x4)
	struct UMaterialInterface* CallFunc_Array_Get_Item_2;  // 0x60(0x8)
	struct UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue;  // 0x68(0x8)
	float CallFunc_RandomFloatInRange_ReturnValue;  // 0x70(0x4)
	float CallFunc_RandomFloatInRange_ReturnValue_2;  // 0x74(0x4)
	int32_t ___int_Loop_Counter_Variable;  // 0x78(0x4)
	char pad_124_1 : 7;  // 0x7C(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x7C(0x1)
	char pad_125[3];  // 0x7D(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x80(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0x84(0x4)
	float CallFunc_FClamp_ReturnValue_2;  // 0x88(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x8C(0x4)
	float CallFunc_FClamp_ReturnValue_3;  // 0x90(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue_2;  // 0x94(0x4)
	struct FVector CallFunc_Conv_FloatToVector_ReturnValue;  // 0x98(0xC)
	char pad_164[12];  // 0xA4(0xC)
	struct FTransform CallFunc_MakeTransform_ReturnValue;  // 0xB0(0x30)
	struct AActor* CallFunc_BeginDeferredActorSpawnFromClass_ReturnValue;  // 0xE0(0x8)
	struct ABP_Bloodstain_Main_C* CallFunc_FinishSpawningActor_ReturnValue;  // 0xE8(0x8)
	float CallFunc_BreakRotator_Roll;  // 0xF0(0x4)
	float CallFunc_BreakRotator_Pitch;  // 0xF4(0x4)
	float CallFunc_BreakRotator_Yaw;  // 0xF8(0x4)
	struct FRotator CallFunc_MakeRotator_ReturnValue;  // 0xFC(0xC)
	struct FHitResult CallFunc_K2_SetRelativeRotation_SweepHitResult;  // 0x108(0x88)

}; 
// Function BP_Splater_Preset_5.BP_Splater_Preset_4_C.ReceiveParticleData
// Size: 0x18(Inherited: 0x0) 
struct FReceiveParticleData
{
	struct TArray<struct FBasicParticleData> Data;  // 0x0(0x10)
	struct UNiagaraSystem* NiagaraSystem;  // 0x10(0x8)

}; 
