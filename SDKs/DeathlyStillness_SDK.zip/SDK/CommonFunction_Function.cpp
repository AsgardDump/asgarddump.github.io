#include "SDK.h" 
 
 
void UBlueprintFunctionLibrary::ShowFPS(int32_t Int, struct UObject* __WorldContext){

	static UObject* p_ShowFPS = UObject::FindObject<UFunction>("Function CommonFunction.CommonFunction_C.ShowFPS");

	struct {
		int32_t Int;
		struct UObject* __WorldContext;
	} parms;

	parms.Int = Int;
	parms.__WorldContext = __WorldContext;

	ProcessEvent(p_ShowFPS, &parms);
}

