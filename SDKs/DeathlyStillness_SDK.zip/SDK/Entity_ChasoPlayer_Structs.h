#pragma once 
#include "SDK.h" 
 
 
// Function Entity_ChasoPlayer.Entity_ChasoPlayer_C.ExecuteUbergraph_Entity_ChasoPlayer
// Size: 0xB9(Inherited: 0x0) 
struct FExecuteUbergraph_Entity_ChasoPlayer
{
	int32_t EntryPoint;  // 0x0(0x4)
	struct FName CallFunc_MakeLiteralName_ReturnValue;  // 0x4(0x8)
	char EPathFollowingResult K2Node_CustomEvent_MovementResult_2;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x10(0x10)
	char EPathFollowingResult K2Node_CustomEvent_MovementResult;  // 0x20(0x1)
	char pad_33[3];  // 0x21(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x24(0x10)
	char EPathFollowingResult ___byte_Variable;  // 0x34(0x1)
	char pad_53[3];  // 0x35(0x3)
	struct FName CallFunc_MakeLiteralName_ReturnValue_2;  // 0x38(0x8)
	struct AAIController* K2Node_Event_OwnerController_2;  // 0x40(0x8)
	struct APawn* K2Node_Event_ControlledPawn_2;  // 0x48(0x8)
	float K2Node_Event_DeltaSeconds;  // 0x50(0x4)
	char pad_84[4];  // 0x54(0x4)
	struct ABP_Entity_Pawn_C* K2Node_DynamicCast_AsBP_Entity_Pawn;  // 0x58(0x8)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x60(0x1)
	char pad_97[7];  // 0x61(0x7)
	struct AAIController* CallFunc_GetAIController_ReturnValue;  // 0x68(0x8)
	struct AEntity_AiController_C* K2Node_DynamicCast_AsEntity_Ai_Controller;  // 0x70(0x8)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x78(0x1)
	char pad_121[7];  // 0x79(0x7)
	struct UBlackboardComponent* CallFunc_GetBlackboard_ReturnValue;  // 0x80(0x8)
	float CallFunc_RandomFloatInRange_ReturnValue;  // 0x88(0x4)
	char pad_140[4];  // 0x8C(0x4)
	struct AAIController* K2Node_Event_OwnerController;  // 0x90(0x8)
	struct APawn* K2Node_Event_ControlledPawn;  // 0x98(0x8)
	struct FTimerHandle CallFunc_K2_SetTimer_ReturnValue;  // 0xA0(0x8)
	struct APawn* CallFunc_GetPlayerPawn_ReturnValue;  // 0xA8(0x8)
	struct UAIAsyncTaskBlueprintProxy* CallFunc_CreateMoveToProxyObject_ReturnValue;  // 0xB0(0x8)
	char pad_184_1 : 7;  // 0xB8(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0xB8(0x1)

}; 
// Function Entity_ChasoPlayer.Entity_ChasoPlayer_C.OnFail_ABB689194B7AD14A72915FA5A6BB4E61
// Size: 0x1(Inherited: 0x0) 
struct FOnFail_ABB689194B7AD14A72915FA5A6BB4E61
{
	char EPathFollowingResult MovementResult;  // 0x0(0x1)

}; 
// Function Entity_ChasoPlayer.Entity_ChasoPlayer_C.ReceiveExecuteAI
// Size: 0x10(Inherited: 0x10) 
struct FReceiveExecuteAI : public FReceiveExecuteAI
{
	struct AAIController* OwnerController;  // 0x0(0x8)
	struct APawn* ControlledPawn;  // 0x8(0x8)

}; 
// Function Entity_ChasoPlayer.Entity_ChasoPlayer_C.ReceiveTickAI
// Size: 0x14(Inherited: 0x18) 
struct FReceiveTickAI : public FReceiveTickAI
{
	struct AAIController* OwnerController;  // 0x0(0x8)
	struct APawn* ControlledPawn;  // 0x8(0x8)
	float DeltaSeconds;  // 0x10(0x4)

}; 
// Function Entity_ChasoPlayer.Entity_ChasoPlayer_C.OnSuccess_ABB689194B7AD14A72915FA5A6BB4E61
// Size: 0x1(Inherited: 0x0) 
struct FOnSuccess_ABB689194B7AD14A72915FA5A6BB4E61
{
	char EPathFollowingResult MovementResult;  // 0x0(0x1)

}; 
