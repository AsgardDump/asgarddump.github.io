#pragma once 
#include <Chinese_Vampire_AttackStart_Structs.h>
 
 
 
// DynamicClass Chinese_Vampire_AttackStart.Chinese_Vampire_AttackStart_C
// Size: 0x38(Inherited: 0x38) 
struct UChinese_Vampire_AttackStart_C : public UAnimNotify
{

	bool Received_Notify(struct USkeletalMeshComponent* bpp__MeshComp__pf, struct UAnimSequenceBase* bpp__Animation__pf); // Function Chinese_Vampire_AttackStart.Chinese_Vampire_AttackStart_C.Received_Notify
}; 



