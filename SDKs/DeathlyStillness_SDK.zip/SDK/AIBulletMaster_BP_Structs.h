#pragma once 
#include "SDK.h" 
 
 
// Function AIBulletMaster_BP.AIBulletMaster_BP_C.ExecuteUbergraph_AIBulletMaster_BP_2
// Size: 0x4(Inherited: 0x0) 
struct FExecuteUbergraph_AIBulletMaster_BP_2
{
	int32_t bpp__EntryPoint__pf;  // 0x0(0x4)

}; 
// Function AIBulletMaster_BP.AIBulletMaster_BP_C.ReceiveHit
// Size: 0xC8(Inherited: 0x0) 
struct FReceiveHit
{
	struct UPrimitiveComponent* bpp__MyComp__pf;  // 0x0(0x8)
	struct AActor* bpp__Other__pf;  // 0x8(0x8)
	struct UPrimitiveComponent* bpp__OtherComp__pf;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool bpp__bSelfMoved__pf : 1;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)
	struct FVector bpp__HitLocation__pf;  // 0x1C(0xC)
	struct FVector bpp__HitNormal__pf;  // 0x28(0xC)
	struct FVector bpp__NormalImpulse__pf;  // 0x34(0xC)
	struct FHitResult bpp__Hit__pf__const;  // 0x40(0x88)

}; 
