#include "SDK.h" 
 
 
void AActor::UserConstructionScript(){

	static UObject* p_UserConstructionScript = UObject::FindObject<UFunction>("Function BP_Pipe.BP_Pipe_C.UserConstructionScript");

	struct {
	} parms;


	ProcessEvent(p_UserConstructionScript, &parms);
}

