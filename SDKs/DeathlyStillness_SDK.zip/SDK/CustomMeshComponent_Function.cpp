#include "SDK.h" 
 
 
bool UMeshComponent::SetCustomMeshTriangles(struct TArray<struct FCustomMeshTriangle>& Triangles){

	static UObject* p_SetCustomMeshTriangles = UObject::FindObject<UFunction>("Function CustomMeshComponent.CustomMeshComponent.SetCustomMeshTriangles");

	struct {
		struct TArray<struct FCustomMeshTriangle>& Triangles;
		bool return_value;
	} parms;

	parms.Triangles = Triangles;

	ProcessEvent(p_SetCustomMeshTriangles, &parms);
	return parms.return_value;
}

void UMeshComponent::ClearCustomMeshTriangles(){

	static UObject* p_ClearCustomMeshTriangles = UObject::FindObject<UFunction>("Function CustomMeshComponent.CustomMeshComponent.ClearCustomMeshTriangles");

	struct {
	} parms;


	ProcessEvent(p_ClearCustomMeshTriangles, &parms);
}

void UMeshComponent::AddCustomMeshTriangles(struct TArray<struct FCustomMeshTriangle>& Triangles){

	static UObject* p_AddCustomMeshTriangles = UObject::FindObject<UFunction>("Function CustomMeshComponent.CustomMeshComponent.AddCustomMeshTriangles");

	struct {
		struct TArray<struct FCustomMeshTriangle>& Triangles;
	} parms;

	parms.Triangles = Triangles;

	ProcessEvent(p_AddCustomMeshTriangles, &parms);
}

