#pragma once 
#include <Entity_FindPlayer_Structs.h>
 
 
 
// BlueprintGeneratedClass Entity_FindPlayer.Entity_FindPlayer_C
// Size: 0xB0(Inherited: 0xA8) 
struct UEntity_FindPlayer_C : public UBTTask_BlueprintBase
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0xA8(0x8)

	void OnFail_AF1AD3FC44F1D7FEE4BA7FBE27A21D76(char EPathFollowingResult MovementResult); // Function Entity_FindPlayer.Entity_FindPlayer_C.OnFail_AF1AD3FC44F1D7FEE4BA7FBE27A21D76
	void OnSuccess_AF1AD3FC44F1D7FEE4BA7FBE27A21D76(char EPathFollowingResult MovementResult); // Function Entity_FindPlayer.Entity_FindPlayer_C.OnSuccess_AF1AD3FC44F1D7FEE4BA7FBE27A21D76
	void ReceiveTickAI(struct AAIController* OwnerController, struct APawn* ControlledPawn, float DeltaSeconds); // Function Entity_FindPlayer.Entity_FindPlayer_C.ReceiveTickAI
	void ExecuteUbergraph_Entity_FindPlayer(int32_t EntryPoint); // Function Entity_FindPlayer.Entity_FindPlayer_C.ExecuteUbergraph_Entity_FindPlayer
}; 



