#pragma once 
#include <_Structs.h>
 
 
 
// BlueprintGeneratedClass .
// Size: 0x238(Inherited: 0x220) 
struct A : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct UAudioComponent* Audio;  // 0x228(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x230(0x8)

	void (struct USoundBase* NewSound); // Function ..
	void (int32_t EntryPoint); // Function ..
}; 



