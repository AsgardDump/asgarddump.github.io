#pragma once 
#include <CustomCharacterState_BP_Structs.h>
 
 
 
// BlueprintGeneratedClass CustomCharacterState_BP.CustomCharacterState_BP_C
// Size: 0x259(Inherited: 0x28) 
struct UCustomCharacterState_BP_C : public USaveGame
{
	struct FCustomCharacter_Struct SaveCharacterState;  // 0x28(0x230)
	char CharacterModel CharacterModel;  // 0x258(0x1)

}; 



