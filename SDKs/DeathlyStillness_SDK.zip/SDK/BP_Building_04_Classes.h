#pragma once 
#include <BP_Building_04_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Building_04.BP_Building_04_C
// Size: 0x258(Inherited: 0x220) 
struct ABP_Building_04_C : public AActor
{
	struct UStaticMeshComponent* StaticMesh;  // 0x220(0x8)
	struct UStaticMeshComponent* SM_Curtain;  // 0x228(0x8)
	struct UStaticMeshComponent* SM_Building_04_Shutter;  // 0x230(0x8)
	struct UStaticMeshComponent* SM_Building_04_Window;  // 0x238(0x8)
	struct UStaticMeshComponent* SM_Building_04_Columns;  // 0x240(0x8)
	struct UStaticMeshComponent* SM_Building_04;  // 0x248(0x8)
	struct USceneComponent* Scene;  // 0x250(0x8)

}; 



