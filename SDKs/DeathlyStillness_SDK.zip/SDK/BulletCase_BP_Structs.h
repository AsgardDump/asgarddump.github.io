#pragma once 
#include "SDK.h" 
 
 
// Function BulletCase_BP.BulletCase_BP_C.ExecuteUbergraph_BulletCase_BP
// Size: 0x14C(Inherited: 0x0) 
struct FExecuteUbergraph_BulletCase_BP
{
	int32_t EntryPoint;  // 0x0(0x4)
	float CallFunc_RandomFloatInRange_ReturnValue;  // 0x4(0x4)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ___bool_Has_Been_Initd_Variable : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	int32_t ___int_Variable;  // 0xC(0x4)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_NotEqual_IntInt_ReturnValue : 1;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x14(0x4)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool ___bool_IsClosed_Variable : 1;  // 0x19(0x1)
	char pad_26[6];  // 0x1A(0x6)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_HitComponent;  // 0x20(0x8)
	struct AActor* K2Node_ComponentBoundEvent_OtherActor;  // 0x28(0x8)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OtherComp;  // 0x30(0x8)
	struct FVector K2Node_ComponentBoundEvent_NormalImpulse;  // 0x38(0xC)
	struct FHitResult K2Node_ComponentBoundEvent_Hit;  // 0x44(0x88)
	char pad_204_1 : 7;  // 0xCC(0x1)
	bool CallFunc_BreakHitResult_bBlockingHit : 1;  // 0xCC(0x1)
	char pad_205_1 : 7;  // 0xCD(0x1)
	bool CallFunc_BreakHitResult_bInitialOverlap : 1;  // 0xCD(0x1)
	char pad_206[2];  // 0xCE(0x2)
	float CallFunc_BreakHitResult_Time;  // 0xD0(0x4)
	float CallFunc_BreakHitResult_Distance;  // 0xD4(0x4)
	struct FVector CallFunc_BreakHitResult_Location;  // 0xD8(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactPoint;  // 0xE4(0xC)
	struct FVector CallFunc_BreakHitResult_Normal;  // 0xF0(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactNormal;  // 0xFC(0xC)
	struct UPhysicalMaterial* CallFunc_BreakHitResult_PhysMat;  // 0x108(0x8)
	struct AActor* CallFunc_BreakHitResult_HitActor;  // 0x110(0x8)
	struct UPrimitiveComponent* CallFunc_BreakHitResult_HitComponent;  // 0x118(0x8)
	struct FName CallFunc_BreakHitResult_HitBoneName;  // 0x120(0x8)
	int32_t CallFunc_BreakHitResult_HitItem;  // 0x128(0x4)
	int32_t CallFunc_BreakHitResult_ElementIndex;  // 0x12C(0x4)
	int32_t CallFunc_BreakHitResult_FaceIndex;  // 0x130(0x4)
	struct FVector CallFunc_BreakHitResult_TraceStart;  // 0x134(0xC)
	struct FVector CallFunc_BreakHitResult_TraceEnd;  // 0x140(0xC)

}; 
// Function BulletCase_BP.BulletCase_BP_C.BndEvt__StaticMesh_K2Node_ComponentBoundEvent_0_ComponentHitSignature__DelegateSignature
// Size: 0xAC(Inherited: 0x0) 
struct FBndEvt__StaticMesh_K2Node_ComponentBoundEvent_0_ComponentHitSignature__DelegateSignature
{
	struct UPrimitiveComponent* HitComponent;  // 0x0(0x8)
	struct AActor* OtherActor;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	struct FVector NormalImpulse;  // 0x18(0xC)
	struct FHitResult Hit;  // 0x24(0x88)

}; 
// Function BulletCase_BP.BulletCase_BP_C.UserConstructionScript
// Size: 0x98(Inherited: 0x0) 
struct FUserConstructionScript : public FUserConstructionScript
{
	float CallFunc_RandomFloatInRange_ReturnValue;  // 0x0(0x4)
	struct FRotator CallFunc_RandomRotator_ReturnValue;  // 0x4(0xC)
	struct FHitResult CallFunc_K2_SetWorldRotation_SweepHitResult;  // 0x10(0x88)

}; 
