#pragma once 
#include <AccessoriesType_UMG_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass AccessoriesType_UMG.AccessoriesType_UMG_C
// Size: 0x2BA(Inherited: 0x260) 
struct UAccessoriesType_UMG_C : public UUserWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x260(0x8)
	struct UWidgetAnimation* 1;  // 0x268(0x8)
	struct UButton* Button_260;  // 0x270(0x8)
	struct UImage* Image_94;  // 0x278(0x8)
	struct UImage* Image_487;  // 0x280(0x8)
	struct UTextBlock* TextBlock_158;  // 0x288(0x8)
	struct UTexture2D* WeaponTexture;  // 0x290(0x8)
	char AccessoriesType AccessoriesType;  // 0x298(0x1)
	char pad_665[7];  // 0x299(0x7)
	struct FText AccessoriesName;  // 0x2A0(0x18)
	char pad_696_1 : 7;  // 0x2B8(0x1)
	bool  : 1;  // 0x2B8(0x1)
	char WeaponType WeaponType;  // 0x2B9(0x1)

	void (); // Function AccessoriesType_UMG.AccessoriesType_UMG_C.
	void (); // Function AccessoriesType_UMG.AccessoriesType_UMG_C.
	void BndEvt__Button_259_K2Node_ComponentBoundEvent_0_OnButtonHoverEvent__DelegateSignature(); // Function AccessoriesType_UMG.AccessoriesType_UMG_C.BndEvt__Button_259_K2Node_ComponentBoundEvent_0_OnButtonHoverEvent__DelegateSignature
	void BndEvt__Button_259_K2Node_ComponentBoundEvent_1_OnButtonHoverEvent__DelegateSignature(); // Function AccessoriesType_UMG.AccessoriesType_UMG_C.BndEvt__Button_259_K2Node_ComponentBoundEvent_1_OnButtonHoverEvent__DelegateSignature
	void BndEvt__Button_259_K2Node_ComponentBoundEvent_2_OnButtonClickedEvent__DelegateSignature(); // Function AccessoriesType_UMG.AccessoriesType_UMG_C.BndEvt__Button_259_K2Node_ComponentBoundEvent_2_OnButtonClickedEvent__DelegateSignature
	void PreConstruct(bool IsDesignTime); // Function AccessoriesType_UMG.AccessoriesType_UMG_C.PreConstruct
	void (); // Function AccessoriesType_UMG.AccessoriesType_UMG_C.
	void ExecuteUbergraph_AccessoriesType_UMG(int32_t EntryPoint); // Function AccessoriesType_UMG.AccessoriesType_UMG_C.ExecuteUbergraph_AccessoriesType_UMG
}; 



