#pragma once 
#include <FireShake_Structs.h>
 
 
 
// BlueprintGeneratedClass FireShake.FireShake_C
// Size: 0x1B0(Inherited: 0x1B0) 
struct UFireShake_C : public UMatineeCameraShake
{

}; 



