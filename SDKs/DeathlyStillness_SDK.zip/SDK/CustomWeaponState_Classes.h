#pragma once 
#include <CustomWeaponState_Structs.h>
 
 
 
// BlueprintGeneratedClass CustomWeaponState.CustomWeaponState_C
// Size: 0x50(Inherited: 0x28) 
struct UCustomWeaponState_C : public USaveGame
{
	char WeaponType WeaponType;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct TArray<char Optics_Enum> OpticsType;  // 0x30(0x10)
	struct TArray<char MuzzleType> MuzzleType;  // 0x40(0x10)

}; 



