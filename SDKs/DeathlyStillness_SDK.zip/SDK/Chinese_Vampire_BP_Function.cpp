#include "SDK.h" 
 
 
void ACharacter::(bool bpp__xxxxxxx__pf23uLQtBkqzKtNZubiq6fu, bool bpp__xxxxxxxxxx__pfxruvQs2ZtvgusPuketOFqOLsLQtBkq, bool bpp__xxxxxxxYaw__pfxruvQs2ZtvgusPuLQtBkq){

	static UObject* p_ = UObject::FindObject<UFunction>("Function Chinese_Vampire_BP.Chinese_Vampire_BP_C.");

	struct {
		bool bpp__xxxxxxx__pf23uLQtBkqzKtNZubiq6fu;
		bool bpp__xxxxxxxxxx__pfxruvQs2ZtvgusPuketOFqOLsLQtBkq;
		bool bpp__xxxxxxxYaw__pfxruvQs2ZtvgusPuLQtBkq;
	} parms;

	parms.bpp__xxxxxxx__pf23uLQtBkqzKtNZubiq6fu = bpp__xxxxxxx__pf23uLQtBkqzKtNZubiq6fu;
	parms.bpp__xxxxxxxxxx__pfxruvQs2ZtvgusPuketOFqOLsLQtBkq = bpp__xxxxxxxxxx__pfxruvQs2ZtvgusPuketOFqOLsLQtBkq;
	parms.bpp__xxxxxxxYaw__pfxruvQs2ZtvgusPuLQtBkq = bpp__xxxxxxxYaw__pfxruvQs2ZtvgusPuLQtBkq;

	ProcessEvent(p_, &parms);
}

void ACharacter::(){

	static UObject* p_ = UObject::FindObject<UFunction>("Function Chinese_Vampire_BP.Chinese_Vampire_BP_C.");

	struct {
	} parms;


	ProcessEvent(p_, &parms);
}

void ACharacter::(){

	static UObject* p_ = UObject::FindObject<UFunction>("Function Chinese_Vampire_BP.Chinese_Vampire_BP_C.");

	struct {
	} parms;


	ProcessEvent(p_, &parms);
}

void ACharacter::(){

	static UObject* p_ = UObject::FindObject<UFunction>("Function Chinese_Vampire_BP.Chinese_Vampire_BP_C.");

	struct {
	} parms;


	ProcessEvent(p_, &parms);
}

void ACharacter::(struct USceneComponent* bpp__xx__pfiJsGHt){

	static UObject* p_ = UObject::FindObject<UFunction>("Function Chinese_Vampire_BP.Chinese_Vampire_BP_C.");

	struct {
		struct USceneComponent* bpp__xx__pfiJsGHt;
	} parms;

	parms.bpp__xx__pfiJsGHt = bpp__xx__pfiJsGHt;

	ProcessEvent(p_, &parms);
}

void ACharacter::(){

	static UObject* p_ = UObject::FindObject<UFunction>("Function Chinese_Vampire_BP.Chinese_Vampire_BP_C.");

	struct {
	} parms;


	ProcessEvent(p_, &parms);
}

void ACharacter::(){

	static UObject* p_ = UObject::FindObject<UFunction>("Function Chinese_Vampire_BP.Chinese_Vampire_BP_C.");

	struct {
	} parms;


	ProcessEvent(p_, &parms);
}

void ACharacter::(){

	static UObject* p_ = UObject::FindObject<UFunction>("Function Chinese_Vampire_BP.Chinese_Vampire_BP_C.");

	struct {
	} parms;


	ProcessEvent(p_, &parms);
}

void ACharacter::SettingDetails(struct FText& bpp__xx__pfGHtv8q__const, struct FText& bpp__xx__pfVyqlkt__const){

	static UObject* p_SettingDetails = UObject::FindObject<UFunction>("Function Chinese_Vampire_BP.Chinese_Vampire_BP_C.SettingDetails");

	struct {
		struct FText& bpp__xx__pfGHtv8q__const;
		struct FText& bpp__xx__pfVyqlkt__const;
	} parms;

	parms.bpp__xx__pfGHtv8q__const = bpp__xx__pfGHtv8q__const;
	parms.bpp__xx__pfVyqlkt__const = bpp__xx__pfVyqlkt__const;

	ProcessEvent(p_SettingDetails, &parms);
}

void ACharacter::SettingApply(){

	static UObject* p_SettingApply = UObject::FindObject<UFunction>("Function Chinese_Vampire_BP.Chinese_Vampire_BP_C.SettingApply");

	struct {
	} parms;


	ProcessEvent(p_SettingApply, &parms);
}

void ACharacter::RightFootSound(){

	static UObject* p_RightFootSound = UObject::FindObject<UFunction>("Function Chinese_Vampire_BP.Chinese_Vampire_BP_C.RightFootSound");

	struct {
	} parms;


	ProcessEvent(p_RightFootSound, &parms);
}

void ACharacter::ResetAttack(){

	static UObject* p_ResetAttack = UObject::FindObject<UFunction>("Function Chinese_Vampire_BP.Chinese_Vampire_BP_C.ResetAttack");

	struct {
	} parms;


	ProcessEvent(p_ResetAttack, &parms);
}

void ACharacter::Reset(){

	static UObject* p_Reset = UObject::FindObject<UFunction>("Function Chinese_Vampire_BP.Chinese_Vampire_BP_C.Reset");

	struct {
	} parms;


	ProcessEvent(p_Reset, &parms);
}

void ACharacter::ReceiveTick(float bpp__DeltaSeconds__pf){

	static UObject* p_ReceiveTick = UObject::FindObject<UFunction>("Function Chinese_Vampire_BP.Chinese_Vampire_BP_C.ReceiveTick");

	struct {
		float bpp__DeltaSeconds__pf;
	} parms;

	parms.bpp__DeltaSeconds__pf = bpp__DeltaSeconds__pf;

	ProcessEvent(p_ReceiveTick, &parms);
}

void ACharacter::ReceiveBeginPlay(){

	static UObject* p_ReceiveBeginPlay = UObject::FindObject<UFunction>("Function Chinese_Vampire_BP.Chinese_Vampire_BP_C.ReceiveBeginPlay");

	struct {
	} parms;


	ProcessEvent(p_ReceiveBeginPlay, &parms);
}

void ACharacter::OnSuccess_2180E67C465A2F1B00043781C4893172(char EPathFollowingResult bpp__MovementResult__pf){

	static UObject* p_OnSuccess_2180E67C465A2F1B00043781C4893172 = UObject::FindObject<UFunction>("Function Chinese_Vampire_BP.Chinese_Vampire_BP_C.OnSuccess_2180E67C465A2F1B00043781C4893172");

	struct {
		char EPathFollowingResult bpp__MovementResult__pf;
	} parms;

	parms.bpp__MovementResult__pf = bpp__MovementResult__pf;

	ProcessEvent(p_OnSuccess_2180E67C465A2F1B00043781C4893172, &parms);
}

void ACharacter::OnFail_2180E67C465A2F1B00043781C4893172(char EPathFollowingResult bpp__MovementResult__pf){

	static UObject* p_OnFail_2180E67C465A2F1B00043781C4893172 = UObject::FindObject<UFunction>("Function Chinese_Vampire_BP.Chinese_Vampire_BP_C.OnFail_2180E67C465A2F1B00043781C4893172");

	struct {
		char EPathFollowingResult bpp__MovementResult__pf;
	} parms;

	parms.bpp__MovementResult__pf = bpp__MovementResult__pf;

	ProcessEvent(p_OnFail_2180E67C465A2F1B00043781C4893172, &parms);
}

void ACharacter::leftFootSound(){

	static UObject* p_leftFootSound = UObject::FindObject<UFunction>("Function Chinese_Vampire_BP.Chinese_Vampire_BP_C.leftFootSound");

	struct {
	} parms;


	ProcessEvent(p_leftFootSound, &parms);
}

void ACharacter::initializeSetting(){

	static UObject* p_initializeSetting = UObject::FindObject<UFunction>("Function Chinese_Vampire_BP.Chinese_Vampire_BP_C.initializeSetting");

	struct {
	} parms;


	ProcessEvent(p_initializeSetting, &parms);
}

void ACharacter::ExecuteUbergraph_Chinese_Vampire_BP_3(int32_t bpp__EntryPoint__pf){

	static UObject* p_ExecuteUbergraph_Chinese_Vampire_BP_3 = UObject::FindObject<UFunction>("Function Chinese_Vampire_BP.Chinese_Vampire_BP_C.ExecuteUbergraph_Chinese_Vampire_BP_3");

	struct {
		int32_t bpp__EntryPoint__pf;
	} parms;

	parms.bpp__EntryPoint__pf = bpp__EntryPoint__pf;

	ProcessEvent(p_ExecuteUbergraph_Chinese_Vampire_BP_3, &parms);
}

void ACharacter::ExecuteUbergraph_Chinese_Vampire_BP_2(int32_t bpp__EntryPoint__pf){

	static UObject* p_ExecuteUbergraph_Chinese_Vampire_BP_2 = UObject::FindObject<UFunction>("Function Chinese_Vampire_BP.Chinese_Vampire_BP_C.ExecuteUbergraph_Chinese_Vampire_BP_2");

	struct {
		int32_t bpp__EntryPoint__pf;
	} parms;

	parms.bpp__EntryPoint__pf = bpp__EntryPoint__pf;

	ProcessEvent(p_ExecuteUbergraph_Chinese_Vampire_BP_2, &parms);
}

void ACharacter::DamageHit(struct FHitResult bpp__Hit__pf, float bpp__Damage__pf, bool bpp__isMeleex__pfzy){

	static UObject* p_DamageHit = UObject::FindObject<UFunction>("Function Chinese_Vampire_BP.Chinese_Vampire_BP_C.DamageHit");

	struct {
		struct FHitResult bpp__Hit__pf;
		float bpp__Damage__pf;
		bool bpp__isMeleex__pfzy;
	} parms;

	parms.bpp__Hit__pf = bpp__Hit__pf;
	parms.bpp__Damage__pf = bpp__Damage__pf;
	parms.bpp__isMeleex__pfzy = bpp__isMeleex__pfzy;

	ProcessEvent(p_DamageHit, &parms);
}

void ACharacter::CustomMappingCheck(struct FInputActionKeyMapping bpp__InputAction__pf, struct FInputAxisKeyMapping bpp__InputAxis__pf){

	static UObject* p_CustomMappingCheck = UObject::FindObject<UFunction>("Function Chinese_Vampire_BP.Chinese_Vampire_BP_C.CustomMappingCheck");

	struct {
		struct FInputActionKeyMapping bpp__InputAction__pf;
		struct FInputAxisKeyMapping bpp__InputAxis__pf;
	} parms;

	parms.bpp__InputAction__pf = bpp__InputAction__pf;
	parms.bpp__InputAxis__pf = bpp__InputAxis__pf;

	ProcessEvent(p_CustomMappingCheck, &parms);
}

void ACharacter::ChangeLightColor(){

	static UObject* p_ChangeLightColor = UObject::FindObject<UFunction>("Function Chinese_Vampire_BP.Chinese_Vampire_BP_C.ChangeLightColor");

	struct {
	} parms;


	ProcessEvent(p_ChangeLightColor, &parms);
}

void ACharacter::OAISimpleDelegate__DelegateSignature(char EPathFollowingResult bpp__MovementResult__pf){

	static UObject* p_OAISimpleDelegate__DelegateSignature = UObject::FindObject<UFunction>("DelegateFunction Chinese_Vampire_BP.Chinese_Vampire_BP_C.OAISimpleDelegate__DelegateSignature");

	struct {
		char EPathFollowingResult bpp__MovementResult__pf;
	} parms;

	parms.bpp__MovementResult__pf = bpp__MovementResult__pf;

	ProcessEvent(p_OAISimpleDelegate__DelegateSignature, &parms);
}

