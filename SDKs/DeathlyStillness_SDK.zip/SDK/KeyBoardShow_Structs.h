#pragma once 
#include "SDK.h" 
 
 
// Function KeyBoardShow.KeyBoardShow_C.ExecuteUbergraph_KeyBoardShow
// Size: 0x48(Inherited: 0x0) 
struct FExecuteUbergraph_KeyBoardShow
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool ___bool_Has_Been_Initd_Variable : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool ___bool_IsClosed_Variable : 1;  // 0x5(0x1)
	char pad_6[2];  // 0x6(0x2)
	struct UUMGSequencePlayer* CallFunc_PlayAnimation_ReturnValue;  // 0x8(0x8)
	struct UUMGSequencePlayer* CallFunc_PlayAnimation_ReturnValue_2;  // 0x10(0x8)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue;  // 0x18(0x8)
	struct TArray<struct APlayer_BP_C*> CallFunc_GetAllActorsOfClass_OutActors;  // 0x20(0x10)
	struct APlayer_BP_C* CallFunc_Array_Get_Item;  // 0x30(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x38(0x10)

}; 
