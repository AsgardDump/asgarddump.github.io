#pragma once 
#include <Bullet_Master_Structs.h>
 
 
 
// BlueprintGeneratedClass Bullet_Master.Bullet_Master_C
// Size: 0x24C(Inherited: 0x220) 
struct ABullet_Master_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct UStaticMeshComponent* Sphere;  // 0x228(0x8)
	struct USphereComponent* Sphere1;  // 0x230(0x8)
	struct UProjectileMovementComponent* ProjectileMovement;  // 0x238(0x8)
	struct USoundBase* Sound;  // 0x240(0x8)
	float Impulse Strengh;  // 0x248(0x4)

	void HitSurface(struct FHitResult& Hit); // Function Bullet_Master.Bullet_Master_C.HitSurface
	void ReceiveBeginPlay(); // Function Bullet_Master.Bullet_Master_C.ReceiveBeginPlay
	void ReceiveHit(struct UPrimitiveComponent* MyComp, struct AActor* Other, struct UPrimitiveComponent* OtherComp, bool bSelfMoved, struct FVector HitLocation, struct FVector HitNormal, struct FVector NormalImpulse, struct FHitResult& Hit); // Function Bullet_Master.Bullet_Master_C.ReceiveHit
	void ExecuteUbergraph_Bullet_Master(int32_t EntryPoint); // Function Bullet_Master.Bullet_Master_C.ExecuteUbergraph_Bullet_Master
}; 



