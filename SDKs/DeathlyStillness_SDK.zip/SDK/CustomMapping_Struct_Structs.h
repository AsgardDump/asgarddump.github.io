#pragma once 
#include "SDK.h" 
 
 
// ScriptStruct CustomMapping_Struct.CustomMapping_Struct
// Size: 0x68(Inherited: 0x0) 
struct FCustomMapping_Struct
{
	struct FText DisplayName_6_3030B640459C345EA31858A7C4DF0F53;  // 0x0(0x18)
	struct FName MappingName_14_838623264D209857B45F338204DE25D1;  // 0x18(0x8)
	struct FInputChord KeyBoardSelector_20_984A9763461AEF4696960EA0EC5A290D;  // 0x20(0x20)
	struct FInputChord GamePadSelector_23_177AFA7C4BAEC110650FEB84BFF68A95;  // 0x40(0x20)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool IsAxis_9_1267A8EF49F3693B77B1CC9440BDCEAF : 1;  // 0x60(0x1)
	char pad_97[3];  // 0x61(0x3)
	float AxisValue_11_3A8747F74918A925EBF45AA72B3711D6;  // 0x64(0x4)

}; 
