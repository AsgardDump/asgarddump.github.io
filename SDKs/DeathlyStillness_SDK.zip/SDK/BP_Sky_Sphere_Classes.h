#pragma once 
#include <BP_Sky_Sphere_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Sky_Sphere.BP_Sky_Sphere_C
// Size: 0x2C0(Inherited: 0x220) 
struct ABP_Sky_Sphere_C : public AActor
{
	struct UStaticMeshComponent* SkySphereMesh;  // 0x220(0x8)
	struct USceneComponent* Base;  // 0x228(0x8)
	struct UMaterialInstanceDynamic* Sky material;  // 0x230(0x8)
	char pad_568_1 : 7;  // 0x238(0x1)
	bool Refresh material : 1;  // 0x238(0x1)
	char pad_569[7];  // 0x239(0x7)
	struct ADirectionalLight* Directional light actor;  // 0x240(0x8)
	char pad_584_1 : 7;  // 0x248(0x1)
	bool Colors determined by sun position : 1;  // 0x248(0x1)
	char pad_585[3];  // 0x249(0x3)
	float Sun height;  // 0x24C(0x4)
	float Sun Brightness;  // 0x250(0x4)
	float Horizon falloff;  // 0x254(0x4)
	struct FLinearColor Zenith Color;  // 0x258(0x10)
	struct FLinearColor Horizon color;  // 0x268(0x10)
	struct FLinearColor Cloud color;  // 0x278(0x10)
	struct FLinearColor Overall Color;  // 0x288(0x10)
	float Cloud Speed;  // 0x298(0x4)
	float Cloud opacity;  // 0x29C(0x4)
	float Stars brightness;  // 0x2A0(0x4)
	char pad_676[4];  // 0x2A4(0x4)
	struct UCurveLinearColor* Horizon color curve;  // 0x2A8(0x8)
	struct UCurveLinearColor* Zenith color curve;  // 0x2B0(0x8)
	struct UCurveLinearColor* Cloud color curve;  // 0x2B8(0x8)

	void RefreshMaterial(); // Function BP_Sky_Sphere.BP_Sky_Sphere_C.RefreshMaterial
	void UpdateSunDirection(); // Function BP_Sky_Sphere.BP_Sky_Sphere_C.UpdateSunDirection
	void UserConstructionScript(); // Function BP_Sky_Sphere.BP_Sky_Sphere_C.UserConstructionScript
}; 



