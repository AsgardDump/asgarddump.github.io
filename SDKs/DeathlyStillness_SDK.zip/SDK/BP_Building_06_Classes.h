#pragma once 
#include <BP_Building_06_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Building_06.BP_Building_06_C
// Size: 0x2A8(Inherited: 0x220) 
struct ABP_Building_06_C : public AActor
{
	struct UStaticMeshComponent* StaticMesh13;  // 0x220(0x8)
	struct UStaticMeshComponent* StaticMesh12;  // 0x228(0x8)
	struct UStaticMeshComponent* StaticMesh11;  // 0x230(0x8)
	struct UStaticMeshComponent* StaticMesh10;  // 0x238(0x8)
	struct UStaticMeshComponent* StaticMesh9;  // 0x240(0x8)
	struct UStaticMeshComponent* StaticMesh8;  // 0x248(0x8)
	struct UStaticMeshComponent* StaticMesh7;  // 0x250(0x8)
	struct UStaticMeshComponent* StaticMesh6;  // 0x258(0x8)
	struct UStaticMeshComponent* StaticMesh5;  // 0x260(0x8)
	struct UStaticMeshComponent* StaticMesh4;  // 0x268(0x8)
	struct UStaticMeshComponent* StaticMesh3;  // 0x270(0x8)
	struct UStaticMeshComponent* StaticMesh2;  // 0x278(0x8)
	struct UStaticMeshComponent* StaticMesh1;  // 0x280(0x8)
	struct UStaticMeshComponent* StaticMesh;  // 0x288(0x8)
	struct UStaticMeshComponent* SM_CurtainSmall;  // 0x290(0x8)
	struct UStaticMeshComponent* SM_Building_06;  // 0x298(0x8)
	struct USceneComponent* Scene;  // 0x2A0(0x8)

}; 



