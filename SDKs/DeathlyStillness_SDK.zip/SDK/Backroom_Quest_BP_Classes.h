#pragma once 
#include <Backroom_Quest_BP_Structs.h>
 
 
 
// DynamicClass Backroom_Quest_BP.Backroom_Quest_BP_C
// Size: 0x2D0(Inherited: 0x220) 
struct ABackroom_Quest_BP_C : public AActor
{
	char pad_544[8];  // 0x220(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x228(0x8)
	uint8_t  Quest;  // 0x230(0x1)
	char pad_561[7];  // 0x231(0x7)
	struct APlayer_BP_C* PlayerRef;  // 0x238(0x8)
	struct AChinese_Vampire_BP_C* ChineseVcampireRef;  // 0x240(0x8)
	struct UUserWidget* ;  // 0x248(0x8)
	char pad_592_1 : 7;  // 0x250(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x250(0x1)
	char pad_593[7];  // 0x251(0x7)
	struct APlayer_BP_C* CallFunc_GetActorOfClass_ReturnValue_2;  // 0x258(0x8)
	struct AActor* CallFunc_GetActorOfClass_ReturnValue_3;  // 0x260(0x8)
	struct AActor* CallFunc_GetActorOfClass_ReturnValue_4;  // 0x268(0x8)
	struct AActor* CallFunc_GetActorOfClass_ReturnValue_5;  // 0x270(0x8)
	char pad_632[8];  // 0x278(0x8)
	struct FTransform CallFunc_GetTransform_ReturnValue;  // 0x280(0x30)
	struct AActor* CallFunc_BeginDeferredActorSpawnFromClass_ReturnValue;  // 0x2B0(0x8)
	struct AActor* CallFunc_GetActorOfClass_ReturnValue_6;  // 0x2B8(0x8)
	struct AActor* CallFunc_GetActorOfClass_ReturnValue_7;  // 0x2C0(0x8)
	struct AActor* CallFunc_GetActorOfClass_ReturnValue_8;  // 0x2C8(0x8)

	void (); // Function Backroom_Quest_BP.Backroom_Quest_BP_C.
	void RefreshQuest(); // Function Backroom_Quest_BP.Backroom_Quest_BP_C.RefreshQuest
	void ReceiveBeginPlay(); // Function Backroom_Quest_BP.Backroom_Quest_BP_C.ReceiveBeginPlay
	void ExecuteUbergraph_Backroom_Quest_BP_1(int32_t bpp__EntryPoint__pf); // Function Backroom_Quest_BP.Backroom_Quest_BP_C.ExecuteUbergraph_Backroom_Quest_BP_1
	void EndTalk(); // Function Backroom_Quest_BP.Backroom_Quest_BP_C.EndTalk
}; 



