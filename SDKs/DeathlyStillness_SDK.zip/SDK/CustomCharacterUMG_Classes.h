#pragma once 
#include <CustomCharacterUMG_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass CustomCharacterUMG.CustomCharacterUMG_C
// Size: 0x10A8(Inherited: 0x260) 
struct UCustomCharacterUMG_C : public UUserWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x260(0x8)
	struct UWidgetAnimation* SchoolGirlPantAnim;  // 0x268(0x8)
	struct UWidgetAnimation* SchoolGirlClothAnim;  // 0x270(0x8)
	struct UWidgetAnimation* NewYearGirlClothAnim;  // 0x278(0x8)
	struct UWidgetAnimation* MaidClothAnim;  // 0x280(0x8)
	struct UWidgetAnimation* AmayaClothAnim;  // 0x288(0x8)
	struct UWidgetAnimation* ModAnim;  // 0x290(0x8)
	struct UWidgetAnimation* BunnyGirlPantsAnim;  // 0x298(0x8)
	struct UWidgetAnimation* BunnyGirlClothAnim;  // 0x2A0(0x8)
	struct UWidgetAnimation* BunnyGirlHairAnim;  // 0x2A8(0x8)
	struct UWidgetAnimation* ManHatAnim;  // 0x2B0(0x8)
	struct UWidgetAnimation* ManFaceAnim;  // 0x2B8(0x8)
	struct UWidgetAnimation* ManPantAnim;  // 0x2C0(0x8)
	struct UWidgetAnimation* ManClothAnim;  // 0x2C8(0x8)
	struct UWidgetAnimation* CharacterAnim;  // 0x2D0(0x8)
	struct UWidgetAnimation* FemalePantAnim;  // 0x2D8(0x8)
	struct UWidgetAnimation* FemaleShoesAnim;  // 0x2E0(0x8)
	struct UWidgetAnimation* FemaleHairAnim;  // 0x2E8(0x8)
	struct UWidgetAnimation* FemaleTextureAnim;  // 0x2F0(0x8)
	struct UWidgetAnimation* FemaleClothAnim;  // 0x2F8(0x8)
	struct UWidgetAnimation* FemaleFaceAnim;  // 0x300(0x8)
	struct U* Amaya_2;  // 0x308(0x8)
	struct UScrollBox* AmayaCloth;  // 0x310(0x8)
	struct UScrollBox* BunnyGirlCloth;  // 0x318(0x8)
	struct U* BunnyGirlCloth1;  // 0x320(0x8)
	struct U* BunnyGirlCloth2_2;  // 0x328(0x8)
	struct U* BunnyGirlCloth3;  // 0x330(0x8)
	struct U* BunnyGirlCloth3_2;  // 0x338(0x8)
	struct U* BunnyGirlCloth3_3;  // 0x340(0x8)
	struct U* BunnyGirlCloth3_4;  // 0x348(0x8)
	struct U* BunnyGirlCloth3_5;  // 0x350(0x8)
	struct UScrollBox* BunnyGirlHair;  // 0x358(0x8)
	struct U* BunnyGirlHair1;  // 0x360(0x8)
	struct U* BunnyGirlHair2;  // 0x368(0x8)
	struct U* BunnyGirlHair3;  // 0x370(0x8)
	struct U* BunnyGirlHair4;  // 0x378(0x8)
	struct UScrollBox* BunnyGirlPants;  // 0x380(0x8)
	struct U* BunnyGirlPants1;  // 0x388(0x8)
	struct U* BunnyGirlPants2_2;  // 0x390(0x8)
	struct U* BunnyGirlPants3_2;  // 0x398(0x8)
	struct U* BunnyGril_2;  // 0x3A0(0x8)
	struct UScrollBox* CharacterSelect;  // 0x3A8(0x8)
	struct U* Female;  // 0x3B0(0x8)
	struct UScrollBox* FemaleCloth;  // 0x3B8(0x8)
	struct U* FemaleCloth1;  // 0x3C0(0x8)
	struct U* FemaleCloth1_2;  // 0x3C8(0x8)
	struct U* FemaleCloth2;  // 0x3D0(0x8)
	struct U* FemaleCloth2_2;  // 0x3D8(0x8)
	struct U* FemaleCloth3;  // 0x3E0(0x8)
	struct U* FemaleCloth3_2;  // 0x3E8(0x8)
	struct U* FemaleCloth4;  // 0x3F0(0x8)
	struct UScrollBox* FemaleFace;  // 0x3F8(0x8)
	struct U* FemaleFace1;  // 0x400(0x8)
	struct U* FemaleFace10;  // 0x408(0x8)
	struct U* FemaleFace11;  // 0x410(0x8)
	struct U* FemaleFace12;  // 0x418(0x8)
	struct U* FemaleFace13;  // 0x420(0x8)
	struct U* FemaleFace14;  // 0x428(0x8)
	struct U* FemaleFace15;  // 0x430(0x8)
	struct U* FemaleFace16;  // 0x438(0x8)
	struct U* FemaleFace17;  // 0x440(0x8)
	struct U* FemaleFace2;  // 0x448(0x8)
	struct U* FemaleFace3;  // 0x450(0x8)
	struct U* FemaleFace4;  // 0x458(0x8)
	struct U* FemaleFace5;  // 0x460(0x8)
	struct U* FemaleFace6;  // 0x468(0x8)
	struct U* FemaleFace7;  // 0x470(0x8)
	struct U* FemaleFace8;  // 0x478(0x8)
	struct U* FemaleFace9;  // 0x480(0x8)
	struct UScrollBox* FemaleHair;  // 0x488(0x8)
	struct U* FemaleHair1;  // 0x490(0x8)
	struct U* FemaleHair1_2;  // 0x498(0x8)
	struct U* FemaleHair1_3;  // 0x4A0(0x8)
	struct U* FemaleHair1_4;  // 0x4A8(0x8)
	struct U* FemaleHair1_5;  // 0x4B0(0x8)
	struct UScrollBox* FemalePant;  // 0x4B8(0x8)
	struct U* FemalePant1;  // 0x4C0(0x8)
	struct U* FemalePant1_2;  // 0x4C8(0x8)
	struct U* FemalePant1_3;  // 0x4D0(0x8)
	struct U* FemalePant1_4;  // 0x4D8(0x8)
	struct UScrollBox* FemaleShoes;  // 0x4E0(0x8)
	struct U* FemaleShoes1;  // 0x4E8(0x8)
	struct U* FemaleShoes1_2;  // 0x4F0(0x8)
	struct U* FemaleShoes1_3;  // 0x4F8(0x8)
	struct UImage* Image;  // 0x500(0x8)
	struct U* Maid;  // 0x508(0x8)
	struct UScrollBox* MaidCloth;  // 0x510(0x8)
	struct U* MaidCloth1_3;  // 0x518(0x8)
	struct U* MaidCloth2_3;  // 0x520(0x8)
	struct U* MaidCloth3_3;  // 0x528(0x8)
	struct U* Man;  // 0x530(0x8)
	struct UScrollBox* ManCloth;  // 0x538(0x8)
	struct U* ManCloth1;  // 0x540(0x8)
	struct U* ManCloth2;  // 0x548(0x8)
	struct U* ManCloth3;  // 0x550(0x8)
	struct U* ManCloth4;  // 0x558(0x8)
	struct U* ManCloth5;  // 0x560(0x8)
	struct UScrollBox* ManFace;  // 0x568(0x8)
	struct U* ManFace1;  // 0x570(0x8)
	struct U* ManFace2;  // 0x578(0x8)
	struct U* ManFace3;  // 0x580(0x8)
	struct UScrollBox* ManHat;  // 0x588(0x8)
	struct U* ManHat1;  // 0x590(0x8)
	struct U* ManHat2;  // 0x598(0x8)
	struct U* ManHat3;  // 0x5A0(0x8)
	struct U* ManHat4;  // 0x5A8(0x8)
	struct U* ManHat5;  // 0x5B0(0x8)
	struct U* ManPant1;  // 0x5B8(0x8)
	struct U* ManPant2;  // 0x5C0(0x8)
	struct U* ManPant3;  // 0x5C8(0x8)
	struct U* ManPant4;  // 0x5D0(0x8)
	struct U* ManPant5;  // 0x5D8(0x8)
	struct U* ManPant6;  // 0x5E0(0x8)
	struct UScrollBox* ManPants;  // 0x5E8(0x8)
	struct U* MOD;  // 0x5F0(0x8)
	struct UScrollBox* ModSelect_2;  // 0x5F8(0x8)
	struct U* NewYearGirl;  // 0x600(0x8)
	struct UScrollBox* NewYearGirlCloth_2;  // 0x608(0x8)
	struct U* NewYearGirlCloth1;  // 0x610(0x8)
	struct U* NewYearGirlCloth2;  // 0x618(0x8)
	struct U* NewYearGirlCloth3;  // 0x620(0x8)
	struct U* NewYearGirlCloth3_2;  // 0x628(0x8)
	struct UScrollBox* SchoolGirlCloth;  // 0x630(0x8)
	struct U* SchoolGirlCloth1;  // 0x638(0x8)
	struct U* SchoolGirlCloth2;  // 0x640(0x8)
	struct U* SchoolGirlCloth3;  // 0x648(0x8)
	struct U* SchoolGirlCloth4;  // 0x650(0x8)
	struct UScrollBox* SchoolGirlPant;  // 0x658(0x8)
	struct U* SchoolGirlPant1;  // 0x660(0x8)
	struct U* SchoolGirlPant1_2;  // 0x668(0x8)
	struct U* SchoolGirlPant1_3;  // 0x670(0x8)
	struct U* SchoolGirlPant1_4;  // 0x678(0x8)
	struct U* SchoolGril;  // 0x680(0x8)
	struct UTextBlock* TextBlock_3;  // 0x688(0x8)
	struct UScrollBox* Textures;  // 0x690(0x8)
	struct UUniformGridPanel* TexUniformGridPanel;  // 0x698(0x8)
	struct U* ;  // 0x6A0(0x8)
	struct U* ;  // 0x6A8(0x8)
	struct U* ;  // 0x6B0(0x8)
	struct U* ;  // 0x6B8(0x8)
	struct U* ;  // 0x6C0(0x8)
	struct U* ;  // 0x6C8(0x8)
	struct U* ;  // 0x6D0(0x8)
	struct U* ;  // 0x6D8(0x8)
	struct TMap<struct UTexture2D*, struct USkeletalMesh*> FemaleHoodieTextures;  // 0x6E0(0x50)
	int32_t ;  // 0x730(0x4)
	int32_t ;  // 0x734(0x4)
	struct TMap<struct UTexture2D*, struct USkeletalMesh*> FemaleTurtleneckTextures;  // 0x738(0x50)
	struct TMap<struct UTexture2D*, struct USkeletalMesh*> FemaleTanktopTextures;  // 0x788(0x50)
	struct TMap<struct UTexture2D*, struct USkeletalMesh*> FemaleTShirtTextures;  // 0x7D8(0x50)
	struct TMap<struct UTexture2D*, struct UMaterialInterface*> FemaleCombatShoesTextures;  // 0x828(0x50)
	struct TMap<struct UTexture2D*, struct UMaterialInterface*> FemaleSportShoesTextures;  // 0x878(0x50)
	struct TMap<struct UTexture2D*, struct UMaterialInterface*> FemaleSportShoesTextures_2;  // 0x8C8(0x50)
	struct TMap<struct UTexture2D*, struct USkeletalMesh*> FemaleHairTextures;  // 0x918(0x50)
	struct TMap<struct UTexture2D*, struct USkeletalMesh*> FemaleHairTextures_1;  // 0x968(0x50)
	struct TMap<struct UTexture2D*, struct USkeletalMesh*> FemaleHairTextures_2;  // 0x9B8(0x50)
	struct TMap<struct UTexture2D*, struct UMaterialInterface*> FemalePantsTextures;  // 0xA08(0x50)
	struct TMap<struct UTexture2D*, struct UMaterialInterface*> FemalePantsTextures_1;  // 0xA58(0x50)
	struct TMap<struct UTexture2D*, struct UMaterialInterface*> FemalePantsTextures_2;  // 0xAA8(0x50)
	struct TMap<struct UTexture2D*, struct UMaterialInterface*> FemalePantsTextures_3;  // 0xAF8(0x50)
	char CharacterModel CharacterModel;  // 0xB48(0x1)
	char pad_2889[7];  // 0xB49(0x7)
	struct TMap<struct UTexture2D*, struct USkeletalMesh*> ManClothTextures_2;  // 0xB50(0x50)
	struct TMap<struct UTexture2D*, struct USkeletalMesh*> ManClothTextures_3;  // 0xBA0(0x50)
	struct TMap<struct UTexture2D*, struct USkeletalMesh*> ManClothTextures_4;  // 0xBF0(0x50)
	struct TMap<struct UTexture2D*, struct USkeletalMesh*> ManClothTextures_5;  // 0xC40(0x50)
	struct TMap<struct UTexture2D*, struct USkeletalMesh*> ManClothTextures_6;  // 0xC90(0x50)
	struct TMap<struct UTexture2D*, struct USkeletalMesh*> BunnyGirlHairTextures_1;  // 0xCE0(0x50)
	struct TMap<struct UTexture2D*, struct USkeletalMesh*> BunnyGirlHairTextures_2;  // 0xD30(0x50)
	struct TMap<struct UTexture2D*, struct USkeletalMesh*> BunnyGirlHairTextures_3;  // 0xD80(0x50)
	struct TMap<struct UTexture2D*, struct UMaterialInterface*> SchoolGirPantTextures_2;  // 0xDD0(0x50)
	struct TMap<struct UTexture2D*, struct UMaterialInterface*> SchoolGirPantTextures_3;  // 0xE20(0x50)
	struct TMap<struct UTexture2D*, struct UMaterialInterface*> SchoolGirPantTextures_4;  // 0xE70(0x50)
	struct TMap<struct UTexture2D*, struct USkeletalMesh*> SchoolGirClothTextures_1;  // 0xEC0(0x50)
	struct TMap<struct UTexture2D*, struct USkeletalMesh*> SchoolGirClothTextures_2;  // 0xF10(0x50)
	struct TMap<struct UTexture2D*, struct USkeletalMesh*> SchoolGirClothTextures_3;  // 0xF60(0x50)
	struct TMap<struct UTexture2D*, struct USkeletalMesh*> SchoolGirClothTextures_4;  // 0xFB0(0x50)
	struct TMap<struct UTexture2D*, struct USkeletalMesh*> SchoolGirSockTextures_5;  // 0x1000(0x50)
	struct TMap<struct UTexture2D*, struct USkeletalMesh*> BunnyGirlHairTextures_4;  // 0x1050(0x50)
	struct ACustomCharacter_C* CustomCharacterRef;  // 0x10A0(0x8)

	void (struct TMap<struct UTexture2D*, struct USkeletalMesh*>& TargetMap, char CustomCharacterEnum CustomCharacterEnum); // Function CustomCharacterUMG.CustomCharacterUMG_C.
	void (struct TMap<struct UTexture2D*, struct UMaterialInterface*>& TargetMap, char CustomCharacterEnum CustomCharacterEnum); // Function CustomCharacterUMG.CustomCharacterUMG_C.
	void (); // Function CustomCharacterUMG.CustomCharacterUMG_C.
	void Cloth1Click(); // Function CustomCharacterUMG.CustomCharacterUMG_C.Cloth1Click
	void Cloth2Click(); // Function CustomCharacterUMG.CustomCharacterUMG_C.Cloth2Click
	void Cloth3Click(); // Function CustomCharacterUMG.CustomCharacterUMG_C.Cloth3Click
	void Cloth4Click(); // Function CustomCharacterUMG.CustomCharacterUMG_C.Cloth4Click
	void (); // Function CustomCharacterUMG.CustomCharacterUMG_C.
	void (); // Function CustomCharacterUMG.CustomCharacterUMG_C.
	void Shoes1Click(); // Function CustomCharacterUMG.CustomCharacterUMG_C.Shoes1Click
	void Shoes2Click(); // Function CustomCharacterUMG.CustomCharacterUMG_C.Shoes2Click
	void Shoes3Click(); // Function CustomCharacterUMG.CustomCharacterUMG_C.Shoes3Click
	void (); // Function CustomCharacterUMG.CustomCharacterUMG_C.
	void Hair1Click(); // Function CustomCharacterUMG.CustomCharacterUMG_C.Hair1Click
	void Hair2Click(); // Function CustomCharacterUMG.CustomCharacterUMG_C.Hair2Click
	void Hair3Click(); // Function CustomCharacterUMG.CustomCharacterUMG_C.Hair3Click
	void Pant1Click(); // Function CustomCharacterUMG.CustomCharacterUMG_C.Pant1Click
	void Pant2Click(); // Function CustomCharacterUMG.CustomCharacterUMG_C.Pant2Click
	void Pant3Click(); // Function CustomCharacterUMG.CustomCharacterUMG_C.Pant3Click
	void Pant4Click(); // Function CustomCharacterUMG.CustomCharacterUMG_C.Pant4Click
	void (); // Function CustomCharacterUMG.CustomCharacterUMG_C.
	void ManCloth1Click(); // Function CustomCharacterUMG.CustomCharacterUMG_C.ManCloth1Click
	void ManCloth2Click(); // Function CustomCharacterUMG.CustomCharacterUMG_C.ManCloth2Click
	void ManCloth3Click(); // Function CustomCharacterUMG.CustomCharacterUMG_C.ManCloth3Click
	void ManCloth4Click(); // Function CustomCharacterUMG.CustomCharacterUMG_C.ManCloth4Click
	void ManCloth5Click(); // Function CustomCharacterUMG.CustomCharacterUMG_C.ManCloth5Click
	void (); // Function CustomCharacterUMG.CustomCharacterUMG_C.
	void BunnyGirlHair1Click(); // Function CustomCharacterUMG.CustomCharacterUMG_C.BunnyGirlHair1Click
	void BunnyGirlHair2Click(); // Function CustomCharacterUMG.CustomCharacterUMG_C.BunnyGirlHair2Click
	void BunnyGirlHair3Click(); // Function CustomCharacterUMG.CustomCharacterUMG_C.BunnyGirlHair3Click
	void (); // Function CustomCharacterUMG.CustomCharacterUMG_C.
	void (); // Function CustomCharacterUMG.CustomCharacterUMG_C.
	void SchoolGirlPant1Click(); // Function CustomCharacterUMG.CustomCharacterUMG_C.SchoolGirlPant1Click
	void SchoolGirlPant2Click(); // Function CustomCharacterUMG.CustomCharacterUMG_C.SchoolGirlPant2Click
	void SchoolGirlPant3Click(); // Function CustomCharacterUMG.CustomCharacterUMG_C.SchoolGirlPant3Click
	void SchoolGirCloth1Click(); // Function CustomCharacterUMG.CustomCharacterUMG_C.SchoolGirCloth1Click
	void SchoolGirCloth2Click(); // Function CustomCharacterUMG.CustomCharacterUMG_C.SchoolGirCloth2Click
	void SchoolGirCloth3Click(); // Function CustomCharacterUMG.CustomCharacterUMG_C.SchoolGirCloth3Click
	void SchoolGirCloth4Click(); // Function CustomCharacterUMG.CustomCharacterUMG_C.SchoolGirCloth4Click
	void (); // Function CustomCharacterUMG.CustomCharacterUMG_C.
	void Construct(); // Function CustomCharacterUMG.CustomCharacterUMG_C.Construct
	void (); // Function CustomCharacterUMG.CustomCharacterUMG_C.
	void SchoolGirSockClick(); // Function CustomCharacterUMG.CustomCharacterUMG_C.SchoolGirSockClick
	void BunnyGirlHair4Click(); // Function CustomCharacterUMG.CustomCharacterUMG_C.BunnyGirlHair4Click
	void (); // Function CustomCharacterUMG.CustomCharacterUMG_C.
	void ExecuteUbergraph_CustomCharacterUMG(int32_t EntryPoint); // Function CustomCharacterUMG.CustomCharacterUMG_C.ExecuteUbergraph_CustomCharacterUMG
}; 



