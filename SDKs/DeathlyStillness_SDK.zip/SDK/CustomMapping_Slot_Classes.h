#pragma once 
#include <CustomMapping_Slot_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass CustomMapping_Slot.CustomMapping_Slot_C
// Size: 0x368(Inherited: 0x260) 
struct UCustomMapping_Slot_C : public UUserWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x260(0x8)
	struct UBorder* Border;  // 0x268(0x8)
	struct UBorder* Border_52;  // 0x270(0x8)
	struct UBorder* Border_117;  // 0x278(0x8)
	struct UInputKeySelector* InputGamePad;  // 0x280(0x8)
	struct UInputKeySelector* InputKeyBoard;  // 0x288(0x8)
	struct UTextBlock* TextBlock;  // 0x290(0x8)
	struct UTextBlock* TextBlock_2;  // 0x298(0x8)
	struct UTextBlock* TextBlock_91;  // 0x2A0(0x8)
	char pad_680_1 : 7;  // 0x2A8(0x1)
	bool IsClick : 1;  // 0x2A8(0x1)
	char pad_681[7];  // 0x2A9(0x7)
	struct FCustomMapping_Struct CustomMappingStruct;  // 0x2B0(0x68)
	char pad_792_1 : 7;  // 0x318(0x1)
	bool KeyOrPad? : 1;  // 0x318(0x1)
	char pad_793[7];  // 0x319(0x7)
	struct FInputChord Selected Key;  // 0x320(0x20)
	struct U* ;  // 0x340(0x8)
	struct FInputChord Selected GamePad;  // 0x348(0x20)

	struct FText FindText(struct UInputKeySelector* ); // Function CustomMapping_Slot.CustomMapping_Slot_C.FindText
	void AddMapping(struct FInputChord& InputChord); // Function CustomMapping_Slot.CustomMapping_Slot_C.AddMapping
	void RemoveMapping(struct FInputChord& InputChord); // Function CustomMapping_Slot.CustomMapping_Slot_C.RemoveMapping
	void Construct(); // Function CustomMapping_Slot.CustomMapping_Slot_C.Construct
	void OnMouseEnter(struct FGeometry MyGeometry, struct FPointerEvent& MouseEvent); // Function CustomMapping_Slot.CustomMapping_Slot_C.OnMouseEnter
	void OnMouseLeave(struct FPointerEvent& MouseEvent); // Function CustomMapping_Slot.CustomMapping_Slot_C.OnMouseLeave
	void BndEvt__CustomMapping_Slot_InputKeySelector1_K2Node_ComponentBoundEvent_2_OnKeySelected__DelegateSignature(struct FInputChord SelectedKey); // Function CustomMapping_Slot.CustomMapping_Slot_C.BndEvt__CustomMapping_Slot_InputKeySelector1_K2Node_ComponentBoundEvent_2_OnKeySelected__DelegateSignature
	void BndEvt__CustomMapping_Slot_InputKeySelector1_K2Node_ComponentBoundEvent_3_OnIsSelectingKeyChanged__DelegateSignature(); // Function CustomMapping_Slot.CustomMapping_Slot_C.BndEvt__CustomMapping_Slot_InputKeySelector1_K2Node_ComponentBoundEvent_3_OnIsSelectingKeyChanged__DelegateSignature
	void BndEvt__CustomMapping_Slot_InputKeySelector2_K2Node_ComponentBoundEvent_4_OnKeySelected__DelegateSignature(struct FInputChord SelectedKey); // Function CustomMapping_Slot.CustomMapping_Slot_C.BndEvt__CustomMapping_Slot_InputKeySelector2_K2Node_ComponentBoundEvent_4_OnKeySelected__DelegateSignature
	void BndEvt__CustomMapping_Slot_InputKeySelector2_K2Node_ComponentBoundEvent_5_OnIsSelectingKeyChanged__DelegateSignature(); // Function CustomMapping_Slot.CustomMapping_Slot_C.BndEvt__CustomMapping_Slot_InputKeySelector2_K2Node_ComponentBoundEvent_5_OnIsSelectingKeyChanged__DelegateSignature
	void CanMapping(); // Function CustomMapping_Slot.CustomMapping_Slot_C.CanMapping
	void StopMapping(); // Function CustomMapping_Slot.CustomMapping_Slot_C.StopMapping
	void StopMappingGamePad(); // Function CustomMapping_Slot.CustomMapping_Slot_C.StopMappingGamePad
	void CamMappingGamePad(); // Function CustomMapping_Slot.CustomMapping_Slot_C.CamMappingGamePad
	void ExecuteUbergraph_CustomMapping_Slot(int32_t EntryPoint); // Function CustomMapping_Slot.CustomMapping_Slot_C.ExecuteUbergraph_CustomMapping_Slot
}; 



