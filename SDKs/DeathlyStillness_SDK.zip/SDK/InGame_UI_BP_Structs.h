#pragma once 
#include "SDK.h" 
 
 
// Function InGame_UI_BP.InGame_UI_BP_C.ExecuteUbergraph_InGame_UI_BP
// Size: 0x28(Inherited: 0x0) 
struct FExecuteUbergraph_InGame_UI_BP
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UUserWidget* CallFunc_GetUserWidgetObject_ReturnValue;  // 0x8(0x8)
	struct UInGame_Umg_C* K2Node_DynamicCast_AsIn_Game_Umg;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct UUMGSequencePlayer* CallFunc_PlayAnimation_ReturnValue;  // 0x20(0x8)

}; 
