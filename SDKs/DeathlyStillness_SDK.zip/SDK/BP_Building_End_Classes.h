#pragma once 
#include <BP_Building_End_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Building_End.BP_Building_End_C
// Size: 0x280(Inherited: 0x220) 
struct ABP_Building_End_C : public AActor
{
	struct UStaticMeshComponent* SM_Blind;  // 0x220(0x8)
	struct UStaticMeshComponent* StaticMesh8;  // 0x228(0x8)
	struct UStaticMeshComponent* StaticMesh7;  // 0x230(0x8)
	struct UStaticMeshComponent* StaticMesh6;  // 0x238(0x8)
	struct UStaticMeshComponent* StaticMesh5;  // 0x240(0x8)
	struct UStaticMeshComponent* StaticMesh4;  // 0x248(0x8)
	struct UStaticMeshComponent* StaticMesh3;  // 0x250(0x8)
	struct UStaticMeshComponent* StaticMesh2;  // 0x258(0x8)
	struct UStaticMeshComponent* StaticMesh1;  // 0x260(0x8)
	struct UStaticMeshComponent* StaticMesh;  // 0x268(0x8)
	struct UStaticMeshComponent* SM_Building_End;  // 0x270(0x8)
	struct USceneComponent* Scene;  // 0x278(0x8)

}; 



