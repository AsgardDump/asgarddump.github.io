#include "SDK.h" 
 
 
void AGameModeBase::ReceiveBeginPlay(){

	static UObject* p_ReceiveBeginPlay = UObject::FindObject<UFunction>("Function InGameGameMode.InGameGameMode_C.ReceiveBeginPlay");

	struct {
	} parms;


	ProcessEvent(p_ReceiveBeginPlay, &parms);
}

void AGameModeBase::(){

	static UObject* p_ = UObject::FindObject<UFunction>("Function InGameGameMode.InGameGameMode_C.");

	struct {
	} parms;


	ProcessEvent(p_, &parms);
}

void AGameModeBase::(){

	static UObject* p_ = UObject::FindObject<UFunction>("Function InGameGameMode.InGameGameMode_C.");

	struct {
	} parms;


	ProcessEvent(p_, &parms);
}

void AGameModeBase::ExecuteUbergraph_InGameGameMode(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph_InGameGameMode = UObject::FindObject<UFunction>("Function InGameGameMode.InGameGameMode_C.ExecuteUbergraph_InGameGameMode");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph_InGameGameMode, &parms);
}

