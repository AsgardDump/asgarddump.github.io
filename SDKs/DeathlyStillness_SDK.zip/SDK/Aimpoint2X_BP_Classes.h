#pragma once 
#include <Aimpoint2X_BP_Structs.h>
 
 
 
// BlueprintGeneratedClass Aimpoint2X_BP.Aimpoint2X_BP_C
// Size: 0x2B0(Inherited: 0x2B0) 
struct AAimpoint2X_BP_C : public APickUpMaster_C
{

}; 



