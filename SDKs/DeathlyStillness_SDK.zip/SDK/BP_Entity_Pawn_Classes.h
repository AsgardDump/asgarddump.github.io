#pragma once 
#include <BP_Entity_Pawn_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Entity_Pawn.BP_Entity_Pawn_C
// Size: 0x625(Inherited: 0x4C0) 
struct ABP_Entity_Pawn_C : public ACharacter
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x4C0(0x8)
	struct UAudioComponent* Sound;  // 0x4C8(0x8)
	struct UArrowComponent* LeftFoot;  // 0x4D0(0x8)
	struct UArrowComponent* RightFoot;  // 0x4D8(0x8)
	char pad_1248_1 : 7;  // 0x4E0(0x1)
	bool Dead : 1;  // 0x4E0(0x1)
	char pad_1249[7];  // 0x4E1(0x7)
	struct APlayer_BP_C* PlayerRef;  // 0x4E8(0x8)
	char pad_1264_1 : 7;  // 0x4F0(0x1)
	bool CanScream? : 1;  // 0x4F0(0x1)
	char pad_1265_1 : 7;  // 0x4F1(0x1)
	bool Scream? : 1;  // 0x4F1(0x1)
	char pad_1266[6];  // 0x4F2(0x6)
	struct UAudioComponent* Aggressive;  // 0x4F8(0x8)
	struct TArray<struct UAnimMontage*> Hit;  // 0x500(0x10)
	char pad_1296_1 : 7;  // 0x510(0x1)
	bool MeleeByPlayer? : 1;  // 0x510(0x1)
	char pad_1297[7];  // 0x511(0x7)
	struct AActor* HitPlayer;  // 0x518(0x8)
	struct FName ;  // 0x520(0x8)
	struct FName ;  // 0x528(0x8)
	float In Play Rate;  // 0x530(0x4)
	struct FHitResult Hit_Result;  // 0x534(0x88)
	char pad_1468[4];  // 0x5BC(0x4)
	struct UAnimMontage* Montage;  // 0x5C0(0x8)
	struct USoundBase* ZombieSound;  // 0x5C8(0x8)
	struct FSafeFloat ;  // 0x5D0(0x38)
	struct UEntity_Anim_C* As Entity Anim;  // 0x608(0x8)
	struct UAudioComponent* ;  // 0x610(0x8)
	float Health;  // 0x618(0x4)
	float Max Walk Speed;  // 0x61C(0x4)
	float ;  // 0x620(0x4)
	char GameDifficultyEnum ;  // 0x624(0x1)

	void Simulate Physics for Roar(); // Function BP_Entity_Pawn.BP_Entity_Pawn_C.Simulate Physics for Roar
	void (bool Orient Rotation to Movement, bool Use Controller Rotation Yaw, bool ); // Function BP_Entity_Pawn.BP_Entity_Pawn_C.
	void OnFail_A575B2C740A89FE0D490E0A57BBC2713(char EPathFollowingResult MovementResult); // Function BP_Entity_Pawn.BP_Entity_Pawn_C.OnFail_A575B2C740A89FE0D490E0A57BBC2713
	void OnSuccess_A575B2C740A89FE0D490E0A57BBC2713(char EPathFollowingResult MovementResult); // Function BP_Entity_Pawn.BP_Entity_Pawn_C.OnSuccess_A575B2C740A89FE0D490E0A57BBC2713
	void (); // Function BP_Entity_Pawn.BP_Entity_Pawn_C.
	void (); // Function BP_Entity_Pawn.BP_Entity_Pawn_C.
	void ResetScream(); // Function BP_Entity_Pawn.BP_Entity_Pawn_C.ResetScream
	void DamageHit(struct FHitResult Hit, float Damage, bool isMelee?); // Function BP_Entity_Pawn.BP_Entity_Pawn_C.DamageHit
	void (); // Function BP_Entity_Pawn.BP_Entity_Pawn_C.
	void (); // Function BP_Entity_Pawn.BP_Entity_Pawn_C.
	void (); // Function BP_Entity_Pawn.BP_Entity_Pawn_C.
	void (); // Function BP_Entity_Pawn.BP_Entity_Pawn_C.
	void (); // Function BP_Entity_Pawn.BP_Entity_Pawn_C.
	void CustomMappingCheck(struct FInputActionKeyMapping InputAction, struct FInputAxisKeyMapping InputAxis); // Function BP_Entity_Pawn.BP_Entity_Pawn_C.CustomMappingCheck
	void initializeSetting(); // Function BP_Entity_Pawn.BP_Entity_Pawn_C.initializeSetting
	void SettingDetails(struct FText , struct FText ); // Function BP_Entity_Pawn.BP_Entity_Pawn_C.SettingDetails
	void (); // Function BP_Entity_Pawn.BP_Entity_Pawn_C.
	void (); // Function BP_Entity_Pawn.BP_Entity_Pawn_C.
	void Reset(); // Function BP_Entity_Pawn.BP_Entity_Pawn_C.Reset
	void ReceiveBeginPlay(); // Function BP_Entity_Pawn.BP_Entity_Pawn_C.ReceiveBeginPlay
	void (); // Function BP_Entity_Pawn.BP_Entity_Pawn_C.
	void SettingApply(); // Function BP_Entity_Pawn.BP_Entity_Pawn_C.SettingApply
	void (); // Function BP_Entity_Pawn.BP_Entity_Pawn_C.
	void (); // Function BP_Entity_Pawn.BP_Entity_Pawn_C.
	void ExecuteUbergraph_BP_Entity_Pawn(int32_t EntryPoint); // Function BP_Entity_Pawn.BP_Entity_Pawn_C.ExecuteUbergraph_BP_Entity_Pawn
}; 



