#include "SDK.h" 
 
 
void UAnimInstance::EvaluateGraphExposedInputs_ExecuteUbergraph_Chinese_Vampire_Anim_AnimGraphNode_TransitionResult_EB9E32154ACFBB550C2A05A05D2169BC(){

	static UObject* p_EvaluateGraphExposedInputs_ExecuteUbergraph_Chinese_Vampire_Anim_AnimGraphNode_TransitionResult_EB9E32154ACFBB550C2A05A05D2169BC = UObject::FindObject<UFunction>("Function Chinese_Vampire_Anim.Chinese_Vampire_Anim_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Chinese_Vampire_Anim_AnimGraphNode_TransitionResult_EB9E32154ACFBB550C2A05A05D2169BC");

	struct {
	} parms;


	ProcessEvent(p_EvaluateGraphExposedInputs_ExecuteUbergraph_Chinese_Vampire_Anim_AnimGraphNode_TransitionResult_EB9E32154ACFBB550C2A05A05D2169BC, &parms);
}

void UAnimInstance::EvaluateGraphExposedInputs_ExecuteUbergraph_Chinese_Vampire_Anim_AnimGraphNode_TransitionResult_3E7315F5434EED083EBC369FB01CDB75(){

	static UObject* p_EvaluateGraphExposedInputs_ExecuteUbergraph_Chinese_Vampire_Anim_AnimGraphNode_TransitionResult_3E7315F5434EED083EBC369FB01CDB75 = UObject::FindObject<UFunction>("Function Chinese_Vampire_Anim.Chinese_Vampire_Anim_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Chinese_Vampire_Anim_AnimGraphNode_TransitionResult_3E7315F5434EED083EBC369FB01CDB75");

	struct {
	} parms;


	ProcessEvent(p_EvaluateGraphExposedInputs_ExecuteUbergraph_Chinese_Vampire_Anim_AnimGraphNode_TransitionResult_3E7315F5434EED083EBC369FB01CDB75, &parms);
}

void UAnimInstance::EvaluateGraphExposedInputs_ExecuteUbergraph_Chinese_Vampire_Anim_AnimGraphNode_TransitionResult_2EE96C804F850CEAF9D49A80DCE0877C(){

	static UObject* p_EvaluateGraphExposedInputs_ExecuteUbergraph_Chinese_Vampire_Anim_AnimGraphNode_TransitionResult_2EE96C804F850CEAF9D49A80DCE0877C = UObject::FindObject<UFunction>("Function Chinese_Vampire_Anim.Chinese_Vampire_Anim_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Chinese_Vampire_Anim_AnimGraphNode_TransitionResult_2EE96C804F850CEAF9D49A80DCE0877C");

	struct {
	} parms;


	ProcessEvent(p_EvaluateGraphExposedInputs_ExecuteUbergraph_Chinese_Vampire_Anim_AnimGraphNode_TransitionResult_2EE96C804F850CEAF9D49A80DCE0877C, &parms);
}

void UAnimInstance::EvaluateGraphExposedInputs_ExecuteUbergraph_Chinese_Vampire_Anim_AnimGraphNode_SequencePlayer_96498C024137B4B00D88BBA3A57F672F(){

	static UObject* p_EvaluateGraphExposedInputs_ExecuteUbergraph_Chinese_Vampire_Anim_AnimGraphNode_SequencePlayer_96498C024137B4B00D88BBA3A57F672F = UObject::FindObject<UFunction>("Function Chinese_Vampire_Anim.Chinese_Vampire_Anim_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Chinese_Vampire_Anim_AnimGraphNode_SequencePlayer_96498C024137B4B00D88BBA3A57F672F");

	struct {
	} parms;


	ProcessEvent(p_EvaluateGraphExposedInputs_ExecuteUbergraph_Chinese_Vampire_Anim_AnimGraphNode_SequencePlayer_96498C024137B4B00D88BBA3A57F672F, &parms);
}

void UAnimInstance::EvaluateGraphExposedInputs_ExecuteUbergraph_Chinese_Vampire_Anim_AnimGraphNode_BlendSpacePlayer_F8C4EBF74FC67412A098ECBA6869C80A(){

	static UObject* p_EvaluateGraphExposedInputs_ExecuteUbergraph_Chinese_Vampire_Anim_AnimGraphNode_BlendSpacePlayer_F8C4EBF74FC67412A098ECBA6869C80A = UObject::FindObject<UFunction>("Function Chinese_Vampire_Anim.Chinese_Vampire_Anim_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Chinese_Vampire_Anim_AnimGraphNode_BlendSpacePlayer_F8C4EBF74FC67412A098ECBA6869C80A");

	struct {
	} parms;


	ProcessEvent(p_EvaluateGraphExposedInputs_ExecuteUbergraph_Chinese_Vampire_Anim_AnimGraphNode_BlendSpacePlayer_F8C4EBF74FC67412A098ECBA6869C80A, &parms);
}

void UAnimInstance::EvaluateGraphExposedInputs_ExecuteUbergraph_Chinese_Vampire_Anim_AnimGraphNode_BlendListByBool_3251FFD64ADAD31A9E3E0B945C7C07F5(){

	static UObject* p_EvaluateGraphExposedInputs_ExecuteUbergraph_Chinese_Vampire_Anim_AnimGraphNode_BlendListByBool_3251FFD64ADAD31A9E3E0B945C7C07F5 = UObject::FindObject<UFunction>("Function Chinese_Vampire_Anim.Chinese_Vampire_Anim_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Chinese_Vampire_Anim_AnimGraphNode_BlendListByBool_3251FFD64ADAD31A9E3E0B945C7C07F5");

	struct {
	} parms;


	ProcessEvent(p_EvaluateGraphExposedInputs_ExecuteUbergraph_Chinese_Vampire_Anim_AnimGraphNode_BlendListByBool_3251FFD64ADAD31A9E3E0B945C7C07F5, &parms);
}

void UAnimInstance::BlueprintUpdateAnimation(float bpp__DeltaTimeX__pf){

	static UObject* p_BlueprintUpdateAnimation = UObject::FindObject<UFunction>("Function Chinese_Vampire_Anim.Chinese_Vampire_Anim_C.BlueprintUpdateAnimation");

	struct {
		float bpp__DeltaTimeX__pf;
	} parms;

	parms.bpp__DeltaTimeX__pf = bpp__DeltaTimeX__pf;

	ProcessEvent(p_BlueprintUpdateAnimation, &parms);
}

void UAnimInstance::BlueprintInitializeAnimation(){

	static UObject* p_BlueprintInitializeAnimation = UObject::FindObject<UFunction>("Function Chinese_Vampire_Anim.Chinese_Vampire_Anim_C.BlueprintInitializeAnimation");

	struct {
	} parms;


	ProcessEvent(p_BlueprintInitializeAnimation, &parms);
}

void UAnimInstance::AnimNotify_Footstep(){

	static UObject* p_AnimNotify_Footstep = UObject::FindObject<UFunction>("Function Chinese_Vampire_Anim.Chinese_Vampire_Anim_C.AnimNotify_Footstep");

	struct {
	} parms;


	ProcessEvent(p_AnimNotify_Footstep, &parms);
}

void UAnimInstance::AnimGraph(struct FPoseLink& bpp__AnimGraph__pf){

	static UObject* p_AnimGraph = UObject::FindObject<UFunction>("Function Chinese_Vampire_Anim.Chinese_Vampire_Anim_C.AnimGraph");

	struct {
		struct FPoseLink& bpp__AnimGraph__pf;
	} parms;

	parms.bpp__AnimGraph__pf = bpp__AnimGraph__pf;

	ProcessEvent(p_AnimGraph, &parms);
}

