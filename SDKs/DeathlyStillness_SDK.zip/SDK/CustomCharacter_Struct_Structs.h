#pragma once 
#include "SDK.h" 
 
 
// ScriptStruct CustomCharacter_Struct.CustomCharacter_Struct
// Size: 0x230(Inherited: 0x0) 
struct FCustomCharacter_Struct
{
	struct TMap<struct USkeletalMesh*, struct UMaterialInterface*> ManState_29_E0041CB344E69B9E115AEB835BD1006B;  // 0x0(0x50)
	struct TMap<struct USkeletalMesh*, struct UMaterialInterface*> FemaleState_36_2D436FE34F72CFF47A1380B93394E49A;  // 0x50(0x50)
	struct TMap<struct USkeletalMesh*, struct UMaterialInterface*> BunnyGirlState_43_AEDAED5D44AC126BD3014B9B58826984;  // 0xA0(0x50)
	struct TMap<struct USkeletalMesh*, struct UMaterialInterface*> MaidState_46_65B2AF7942598FCB2C16A88897DCD3D5;  // 0xF0(0x50)
	struct TMap<struct USkeletalMesh*, struct UMaterialInterface*> NewYearGirl_53_459E78314B3658D01B171883722D207C;  // 0x140(0x50)
	struct TMap<struct USkeletalMesh*, struct UMaterialInterface*> Amaya_51_0FB1534E475403D688360B8E4190924E;  // 0x190(0x50)
	struct TMap<struct USkeletalMesh*, struct UMaterialInterface*> SchoolGirl_58_9CDC706A47410B70609BB2B54F1E54A9;  // 0x1E0(0x50)

}; 
