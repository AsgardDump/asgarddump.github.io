#include "SDK.h" 
 
 
void UClothingInteractor::SetVelocityScale(struct FVector LinearVelocityScale, float AngularVelocityScale, float FictitiousAngularScale){

	static UObject* p_SetVelocityScale = UObject::FindObject<UFunction>("Function ChaosCloth.ChaosClothingInteractor.SetVelocityScale");

	struct {
		struct FVector LinearVelocityScale;
		float AngularVelocityScale;
		float FictitiousAngularScale;
	} parms;

	parms.LinearVelocityScale = LinearVelocityScale;
	parms.AngularVelocityScale = AngularVelocityScale;
	parms.FictitiousAngularScale = FictitiousAngularScale;

	ProcessEvent(p_SetVelocityScale, &parms);
}

void UClothingInteractor::SetMaterialLinear(float EdgeStiffness, float BendingStiffness, float AreaStiffness){

	static UObject* p_SetMaterialLinear = UObject::FindObject<UFunction>("Function ChaosCloth.ChaosClothingInteractor.SetMaterialLinear");

	struct {
		float EdgeStiffness;
		float BendingStiffness;
		float AreaStiffness;
	} parms;

	parms.EdgeStiffness = EdgeStiffness;
	parms.BendingStiffness = BendingStiffness;
	parms.AreaStiffness = AreaStiffness;

	ProcessEvent(p_SetMaterialLinear, &parms);
}

void UClothingInteractor::SetLongRangeAttachmentLinear(float TetherStiffness){

	static UObject* p_SetLongRangeAttachmentLinear = UObject::FindObject<UFunction>("Function ChaosCloth.ChaosClothingInteractor.SetLongRangeAttachmentLinear");

	struct {
		float TetherStiffness;
	} parms;

	parms.TetherStiffness = TetherStiffness;

	ProcessEvent(p_SetLongRangeAttachmentLinear, &parms);
}

void UClothingInteractor::SetLongRangeAttachment(struct FVector2D TetherStiffness){

	static UObject* p_SetLongRangeAttachment = UObject::FindObject<UFunction>("Function ChaosCloth.ChaosClothingInteractor.SetLongRangeAttachment");

	struct {
		struct FVector2D TetherStiffness;
	} parms;

	parms.TetherStiffness = TetherStiffness;

	ProcessEvent(p_SetLongRangeAttachment, &parms);
}

void UClothingInteractor::SetGravity(float GravityScale, bool bIsGravityOverridden, struct FVector GravityOverride){

	static UObject* p_SetGravity = UObject::FindObject<UFunction>("Function ChaosCloth.ChaosClothingInteractor.SetGravity");

	struct {
		float GravityScale;
		bool bIsGravityOverridden;
		struct FVector GravityOverride;
	} parms;

	parms.GravityScale = GravityScale;
	parms.bIsGravityOverridden = bIsGravityOverridden;
	parms.GravityOverride = GravityOverride;

	ProcessEvent(p_SetGravity, &parms);
}

void UClothingInteractor::SetDamping(float DampingCoefficient){

	static UObject* p_SetDamping = UObject::FindObject<UFunction>("Function ChaosCloth.ChaosClothingInteractor.SetDamping");

	struct {
		float DampingCoefficient;
	} parms;

	parms.DampingCoefficient = DampingCoefficient;

	ProcessEvent(p_SetDamping, &parms);
}

void UClothingInteractor::SetCollision(float CollisionThickness, float FrictionCoefficient, bool bUseCCD, float SelfCollisionThickness){

	static UObject* p_SetCollision = UObject::FindObject<UFunction>("Function ChaosCloth.ChaosClothingInteractor.SetCollision");

	struct {
		float CollisionThickness;
		float FrictionCoefficient;
		bool bUseCCD;
		float SelfCollisionThickness;
	} parms;

	parms.CollisionThickness = CollisionThickness;
	parms.FrictionCoefficient = FrictionCoefficient;
	parms.bUseCCD = bUseCCD;
	parms.SelfCollisionThickness = SelfCollisionThickness;

	ProcessEvent(p_SetCollision, &parms);
}

void UClothingInteractor::SetAnimDriveLinear(float AnimDriveStiffness){

	static UObject* p_SetAnimDriveLinear = UObject::FindObject<UFunction>("Function ChaosCloth.ChaosClothingInteractor.SetAnimDriveLinear");

	struct {
		float AnimDriveStiffness;
	} parms;

	parms.AnimDriveStiffness = AnimDriveStiffness;

	ProcessEvent(p_SetAnimDriveLinear, &parms);
}

void UClothingInteractor::SetAnimDrive(struct FVector2D AnimDriveStiffness, struct FVector2D AnimDriveDamping){

	static UObject* p_SetAnimDrive = UObject::FindObject<UFunction>("Function ChaosCloth.ChaosClothingInteractor.SetAnimDrive");

	struct {
		struct FVector2D AnimDriveStiffness;
		struct FVector2D AnimDriveDamping;
	} parms;

	parms.AnimDriveStiffness = AnimDriveStiffness;
	parms.AnimDriveDamping = AnimDriveDamping;

	ProcessEvent(p_SetAnimDrive, &parms);
}

void UClothingInteractor::SetAerodynamics(float DragCoefficient, float LiftCoefficient, struct FVector WindVelocity){

	static UObject* p_SetAerodynamics = UObject::FindObject<UFunction>("Function ChaosCloth.ChaosClothingInteractor.SetAerodynamics");

	struct {
		float DragCoefficient;
		float LiftCoefficient;
		struct FVector WindVelocity;
	} parms;

	parms.DragCoefficient = DragCoefficient;
	parms.LiftCoefficient = LiftCoefficient;
	parms.WindVelocity = WindVelocity;

	ProcessEvent(p_SetAerodynamics, &parms);
}

void UClothingInteractor::ResetAndTeleport(bool bReset, bool bTeleport){

	static UObject* p_ResetAndTeleport = UObject::FindObject<UFunction>("Function ChaosCloth.ChaosClothingInteractor.ResetAndTeleport");

	struct {
		bool bReset;
		bool bTeleport;
	} parms;

	parms.bReset = bReset;
	parms.bTeleport = bTeleport;

	ProcessEvent(p_ResetAndTeleport, &parms);
}

