#pragma once 
#include <Interation_Interface_Structs.h>
 
 
 
// BlueprintGeneratedClass Interation_Interface.Interation_Interface_C
// Size: 0x28(Inherited: 0x28) 
struct UInteration_Interface_C : public UInterface
{

	void (); // Function Interation_Interface.Interation_Interface_C.
	void OpenDoor(struct APUBG_BaseCharacter_BP_C* Player); // Function Interation_Interface.Interation_Interface_C.OpenDoor
	void SetRenderClose(); // Function Interation_Interface.Interation_Interface_C.SetRenderClose
	void SetRenderOpen(); // Function Interation_Interface.Interation_Interface_C.SetRenderOpen
	void PickUp(struct APUBG_BaseCharacter_BP_C* Player); // Function Interation_Interface.Interation_Interface_C.PickUp
}; 



