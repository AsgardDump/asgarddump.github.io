#include "SDK.h" 
 
 
void UBaseMediaSource::SetSequencePath(struct FString Path){

	static UObject* p_SetSequencePath = UObject::FindObject<UFunction>("Function ImgMedia.ImgMediaSource.SetSequencePath");

	struct {
		struct FString Path;
	} parms;

	parms.Path = Path;

	ProcessEvent(p_SetSequencePath, &parms);
}

void UBaseMediaSource::SetMipLevelDistance(float Distance){

	static UObject* p_SetMipLevelDistance = UObject::FindObject<UFunction>("Function ImgMedia.ImgMediaSource.SetMipLevelDistance");

	struct {
		float Distance;
	} parms;

	parms.Distance = Distance;

	ProcessEvent(p_SetMipLevelDistance, &parms);
}

void UBaseMediaSource::RemoveTargetObject(struct AActor* InActor){

	static UObject* p_RemoveTargetObject = UObject::FindObject<UFunction>("Function ImgMedia.ImgMediaSource.RemoveTargetObject");

	struct {
		struct AActor* InActor;
	} parms;

	parms.InActor = InActor;

	ProcessEvent(p_RemoveTargetObject, &parms);
}

void UBaseMediaSource::RemoveGlobalCamera(struct AActor* InActor){

	static UObject* p_RemoveGlobalCamera = UObject::FindObject<UFunction>("Function ImgMedia.ImgMediaSource.RemoveGlobalCamera");

	struct {
		struct AActor* InActor;
	} parms;

	parms.InActor = InActor;

	ProcessEvent(p_RemoveGlobalCamera, &parms);
}

struct FString UBaseMediaSource::GetSequencePath(){

	static UObject* p_GetSequencePath = UObject::FindObject<UFunction>("Function ImgMedia.ImgMediaSource.GetSequencePath");

	struct {
		struct FString return_value;
	} parms;


	ProcessEvent(p_GetSequencePath, &parms);
	return parms.return_value;
}

void UBaseMediaSource::GetProxies(struct TArray<struct FString>& OutProxies){

	static UObject* p_GetProxies = UObject::FindObject<UFunction>("Function ImgMedia.ImgMediaSource.GetProxies");

	struct {
		struct TArray<struct FString>& OutProxies;
	} parms;

	parms.OutProxies = OutProxies;

	ProcessEvent(p_GetProxies, &parms);
}

void UBaseMediaSource::AddTargetObject(struct AActor* InActor, float Width){

	static UObject* p_AddTargetObject = UObject::FindObject<UFunction>("Function ImgMedia.ImgMediaSource.AddTargetObject");

	struct {
		struct AActor* InActor;
		float Width;
	} parms;

	parms.InActor = InActor;
	parms.Width = Width;

	ProcessEvent(p_AddTargetObject, &parms);
}

void UBaseMediaSource::AddGlobalCamera(struct AActor* InActor){

	static UObject* p_AddGlobalCamera = UObject::FindObject<UFunction>("Function ImgMedia.ImgMediaSource.AddGlobalCamera");

	struct {
		struct AActor* InActor;
	} parms;

	parms.InActor = InActor;

	ProcessEvent(p_AddGlobalCamera, &parms);
}

