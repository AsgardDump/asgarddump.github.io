#include "SDK.h" 
 
 
void AActor::UserConstructionScript(){

	static UObject* p_UserConstructionScript = UObject::FindObject<UFunction>("Function BulletCase_BP.BulletCase_BP_C.UserConstructionScript");

	struct {
	} parms;


	ProcessEvent(p_UserConstructionScript, &parms);
}

void AActor::ReceiveBeginPlay(){

	static UObject* p_ReceiveBeginPlay = UObject::FindObject<UFunction>("Function BulletCase_BP.BulletCase_BP_C.ReceiveBeginPlay");

	struct {
	} parms;


	ProcessEvent(p_ReceiveBeginPlay, &parms);
}

void AActor::BndEvt__StaticMesh_K2Node_ComponentBoundEvent_0_ComponentHitSignature__DelegateSignature(struct UPrimitiveComponent* HitComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, struct FVector NormalImpulse, struct FHitResult& Hit){

	static UObject* p_BndEvt__StaticMesh_K2Node_ComponentBoundEvent_0_ComponentHitSignature__DelegateSignature = UObject::FindObject<UFunction>("Function BulletCase_BP.BulletCase_BP_C.BndEvt__StaticMesh_K2Node_ComponentBoundEvent_0_ComponentHitSignature__DelegateSignature");

	struct {
		struct UPrimitiveComponent* HitComponent;
		struct AActor* OtherActor;
		struct UPrimitiveComponent* OtherComp;
		struct FVector NormalImpulse;
		struct FHitResult& Hit;
	} parms;

	parms.HitComponent = HitComponent;
	parms.OtherActor = OtherActor;
	parms.OtherComp = OtherComp;
	parms.NormalImpulse = NormalImpulse;
	parms.Hit = Hit;

	ProcessEvent(p_BndEvt__StaticMesh_K2Node_ComponentBoundEvent_0_ComponentHitSignature__DelegateSignature, &parms);
}

void AActor::ExecuteUbergraph_BulletCase_BP(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph_BulletCase_BP = UObject::FindObject<UFunction>("Function BulletCase_BP.BulletCase_BP_C.ExecuteUbergraph_BulletCase_BP");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph_BulletCase_BP, &parms);
}

