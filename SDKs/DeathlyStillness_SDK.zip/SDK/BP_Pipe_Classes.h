#pragma once 
#include <BP_Pipe_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Pipe.BP_Pipe_C
// Size: 0x232(Inherited: 0x220) 
struct ABP_Pipe_C : public AActor
{
	struct USceneComponent* Scene;  // 0x220(0x8)
	struct USplineComponent* Spline;  // 0x228(0x8)
	char ENUM_PipeStyle Pipe Style;  // 0x230(0x1)
	char pad_561_1 : 7;  // 0x231(0x1)
	bool Colour : 1;  // 0x231(0x1)

	void UserConstructionScript(); // Function BP_Pipe.BP_Pipe_C.UserConstructionScript
}; 



