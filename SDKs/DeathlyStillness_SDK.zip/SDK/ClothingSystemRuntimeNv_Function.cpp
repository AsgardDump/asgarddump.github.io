#include "SDK.h" 
 
 
void UClothingSimulationInteractor::SetAnimDriveDamperStiffness(float InStiffness){

	static UObject* p_SetAnimDriveDamperStiffness = UObject::FindObject<UFunction>("Function ClothingSystemRuntimeNv.ClothingSimulationInteractorNv.SetAnimDriveDamperStiffness");

	struct {
		float InStiffness;
	} parms;

	parms.InStiffness = InStiffness;

	ProcessEvent(p_SetAnimDriveDamperStiffness, &parms);
}

