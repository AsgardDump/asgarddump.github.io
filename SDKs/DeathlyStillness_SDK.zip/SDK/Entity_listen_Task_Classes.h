#pragma once 
#include <Entity_listen_Task_Structs.h>
 
 
 
// BlueprintGeneratedClass Entity_listen_Task.Entity_listen_Task_C
// Size: 0xB8(Inherited: 0xA8) 
struct UEntity_listen_Task_C : public UBTTask_BlueprintBase
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0xA8(0x8)
	struct AZombie_BP_C* As Zombie BP;  // 0xB0(0x8)

	void OnFail_CA1963E1418C4F4A316F0D86889B8592(char EPathFollowingResult MovementResult); // Function Entity_listen_Task.Entity_listen_Task_C.OnFail_CA1963E1418C4F4A316F0D86889B8592
	void OnSuccess_CA1963E1418C4F4A316F0D86889B8592(char EPathFollowingResult MovementResult); // Function Entity_listen_Task.Entity_listen_Task_C.OnSuccess_CA1963E1418C4F4A316F0D86889B8592
	void ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function Entity_listen_Task.Entity_listen_Task_C.ReceiveExecuteAI
	void ReceiveTickAI(struct AAIController* OwnerController, struct APawn* ControlledPawn, float DeltaSeconds); // Function Entity_listen_Task.Entity_listen_Task_C.ReceiveTickAI
	void (); // Function Entity_listen_Task.Entity_listen_Task_C.
	void ExecuteUbergraph_Entity_listen_Task(int32_t EntryPoint); // Function Entity_listen_Task.Entity_listen_Task_C.ExecuteUbergraph_Entity_listen_Task
}; 



