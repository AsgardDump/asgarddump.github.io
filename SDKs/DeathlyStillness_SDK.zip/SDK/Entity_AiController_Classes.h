#pragma once 
#include <Entity_AiController_Structs.h>
 
 
 
// BlueprintGeneratedClass Entity_AiController.Entity_AiController_C
// Size: 0x364(Inherited: 0x328) 
struct AEntity_AiController_C : public AAIController
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x328(0x8)
	struct UAIPerceptionComponent* AIPerception;  // 0x330(0x8)
	struct APawn* ZombieRef;  // 0x338(0x8)
	struct FVector ;  // 0x340(0xC)
	char pad_844[4];  // 0x34C(0x4)
	struct APlayer_BP_C* PlayerRef;  // 0x350(0x8)
	struct FVector Hear Stimulus Location;  // 0x358(0xC)

	void BndEvt__AIPerception_K2Node_ComponentBoundEvent_1_ActorPerceptionUpdatedDelegate__DelegateSignature(struct AActor* Actor, struct FAIStimulus Stimulus); // Function Entity_AiController.Entity_AiController_C.BndEvt__AIPerception_K2Node_ComponentBoundEvent_1_ActorPerceptionUpdatedDelegate__DelegateSignature
	void ReceivePossess(struct APawn* PossessedPawn); // Function Entity_AiController.Entity_AiController_C.ReceivePossess
	void Reset(); // Function Entity_AiController.Entity_AiController_C.Reset
	void ReceiveBeginPlay(); // Function Entity_AiController.Entity_AiController_C.ReceiveBeginPlay
	void ExecuteUbergraph_Entity_AiController(int32_t EntryPoint); // Function Entity_AiController.Entity_AiController_C.ExecuteUbergraph_Entity_AiController
}; 



