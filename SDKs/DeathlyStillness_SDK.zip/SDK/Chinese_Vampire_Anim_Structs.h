#pragma once 
#include "SDK.h" 
 
 
// Function Chinese_Vampire_Anim.Chinese_Vampire_Anim_C.AnimGraph
// Size: 0x10(Inherited: 0x0) 
struct FAnimGraph
{
	struct FPoseLink bpp__AnimGraph__pf;  // 0x0(0x10)

}; 
// Function Chinese_Vampire_Anim.Chinese_Vampire_Anim_C.BlueprintUpdateAnimation
// Size: 0x4(Inherited: 0x0) 
struct FBlueprintUpdateAnimation
{
	float bpp__DeltaTimeX__pf;  // 0x0(0x4)

}; 
