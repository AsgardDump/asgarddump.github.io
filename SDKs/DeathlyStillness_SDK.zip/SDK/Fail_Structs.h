#pragma once 
#include "SDK.h" 
 
 
// Function Fail.Fail_C.ExecuteUbergraph_Fail
// Size: 0x168(Inherited: 0x0) 
struct FExecuteUbergraph_Fail
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct ULoading_C* CallFunc_Create_ReturnValue;  // 0x8(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x10(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x20(0x10)
	struct UUMGSequencePlayer* CallFunc_PlayAnimation_ReturnValue;  // 0x30(0x8)
	struct AGameModeBase* CallFunc_GetGameMode_ReturnValue;  // 0x38(0x8)
	struct AInGameGameMode_C* K2Node_DynamicCast_AsIn_Game_Game_Mode;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)
	struct APawn* CallFunc_GetPlayerPawn_ReturnValue;  // 0x50(0x8)
	struct APlayer_BP_C* K2Node_DynamicCast_AsPlayer_BP;  // 0x58(0x8)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x60(0x1)
	char pad_97[7];  // 0x61(0x7)
	struct FString CallFunc_Conv_IntToString_ReturnValue;  // 0x68(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0x78(0x10)
	struct FText CallFunc_Conv_StringToText_ReturnValue;  // 0x88(0x18)
	float CallFunc__________;  // 0xA0(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0xA4(0x4)
	struct FText CallFunc_Conv_FloatToText_ReturnValue;  // 0xA8(0x18)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0xC0(0x4)
	char pad_196[4];  // 0xC4(0x4)
	struct FString CallFunc_Conv_FloatToString_ReturnValue;  // 0xC8(0x10)
	float CallFunc___________2;  // 0xD8(0x4)
	char pad_220[4];  // 0xDC(0x4)
	struct FString CallFunc_Concat_StrStr_ReturnValue_2;  // 0xE0(0x10)
	float CallFunc_Divide_FloatFloat_ReturnValue_2;  // 0xF0(0x4)
	char pad_244[4];  // 0xF4(0x4)
	struct FText CallFunc_Conv_StringToText_ReturnValue_2;  // 0xF8(0x18)
	float CallFunc_Multiply_FloatFloat_ReturnValue_2;  // 0x110(0x4)
	int32_t CallFunc_FTrunc_ReturnValue;  // 0x114(0x4)
	struct FString CallFunc_Conv_FloatToString_ReturnValue_2;  // 0x118(0x10)
	struct FText CallFunc_Conv_IntToText_ReturnValue;  // 0x128(0x18)
	struct FString CallFunc_Concat_StrStr_ReturnValue_3;  // 0x140(0x10)
	struct FText CallFunc_Conv_StringToText_ReturnValue_3;  // 0x150(0x18)

}; 
// Function Fail.Fail_C.GetVisibility_1
// Size: 0x2(Inherited: 0x0) 
struct FGetVisibility_1
{
	uint8_t  ReturnValue;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_IsAnimationPlaying_ReturnValue : 1;  // 0x1(0x1)

}; 
