#pragma once 
#include "SDK.h" 
 
 
// Function HeadSpringArm_Anim.HeadSpringArm_Anim_C.AnimGraph
// Size: 0x10(Inherited: 0x0) 
struct FAnimGraph
{
	struct FPoseLink AnimGraph;  // 0x0(0x10)

}; 
// Function HeadSpringArm_Anim.HeadSpringArm_Anim_C.ExecuteUbergraph_HeadSpringArm_Anim
// Size: 0x4C(Inherited: 0x0) 
struct FExecuteUbergraph_HeadSpringArm_Anim
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_GreaterEqual_FloatFloat_ReturnValue : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool CallFunc_GreaterEqual_FloatFloat_ReturnValue_2 : 1;  // 0x5(0x1)
	char pad_6[2];  // 0x6(0x2)
	float K2Node_Event_DeltaTimeX;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct APawn* CallFunc_TryGetPawnOwner_ReturnValue;  // 0x10(0x8)
	struct UPawnMovementComponent* CallFunc_GetMovementComponent_ReturnValue;  // 0x18(0x8)
	struct FVector CallFunc_GetVelocity_ReturnValue;  // 0x20(0xC)
	char pad_44_1 : 7;  // 0x2C(0x1)
	bool CallFunc_IsCrouching_ReturnValue : 1;  // 0x2C(0x1)
	char pad_45[3];  // 0x2D(0x3)
	float CallFunc_VSize_ReturnValue;  // 0x30(0x4)
	char pad_52[4];  // 0x34(0x4)
	struct APUBG_BaseCharacter_BP_C* K2Node_DynamicCast_AsPUBG_Base_Character_BP;  // 0x38(0x8)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x40(0x1)
	char pad_65[3];  // 0x41(0x3)
	float CallFunc_GetWorldDeltaSeconds_ReturnValue;  // 0x44(0x4)
	float CallFunc_FInterpTo_ReturnValue;  // 0x48(0x4)

}; 
// Function HeadSpringArm_Anim.HeadSpringArm_Anim_C.BlueprintUpdateAnimation
// Size: 0x4(Inherited: 0x4) 
struct FBlueprintUpdateAnimation : public FBlueprintUpdateAnimation
{
	float DeltaTimeX;  // 0x0(0x4)

}; 
