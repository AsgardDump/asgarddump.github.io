#include "SDK.h" 
 
 
bool UAnimNotify::Received_Notify(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation){

	static UObject* p_Received_Notify = UObject::FindObject<UFunction>("Function ClipDrop.ClipDrop_C.Received_Notify");

	struct {
		struct USkeletalMeshComponent* MeshComp;
		struct UAnimSequenceBase* Animation;
		bool return_value;
	} parms;

	parms.MeshComp = MeshComp;
	parms.Animation = Animation;

	ProcessEvent(p_Received_Notify, &parms);
	return parms.return_value;
}

