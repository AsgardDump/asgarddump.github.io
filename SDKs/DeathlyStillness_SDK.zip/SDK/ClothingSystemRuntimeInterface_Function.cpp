#include "SDK.h" 
 
 
void UObject::SetNumSubsteps(int32_t NumSubsteps){

	static UObject* p_SetNumSubsteps = UObject::FindObject<UFunction>("Function ClothingSystemRuntimeInterface.ClothingSimulationInteractor.SetNumSubsteps");

	struct {
		int32_t NumSubsteps;
	} parms;

	parms.NumSubsteps = NumSubsteps;

	ProcessEvent(p_SetNumSubsteps, &parms);
}

void UObject::SetNumIterations(int32_t NumIterations){

	static UObject* p_SetNumIterations = UObject::FindObject<UFunction>("Function ClothingSystemRuntimeInterface.ClothingSimulationInteractor.SetNumIterations");

	struct {
		int32_t NumIterations;
	} parms;

	parms.NumIterations = NumIterations;

	ProcessEvent(p_SetNumIterations, &parms);
}

void UObject::SetAnimDriveSpringStiffness(float InStiffness){

	static UObject* p_SetAnimDriveSpringStiffness = UObject::FindObject<UFunction>("Function ClothingSystemRuntimeInterface.ClothingSimulationInteractor.SetAnimDriveSpringStiffness");

	struct {
		float InStiffness;
	} parms;

	parms.InStiffness = InStiffness;

	ProcessEvent(p_SetAnimDriveSpringStiffness, &parms);
}

void UObject::PhysicsAssetUpdated(){

	static UObject* p_PhysicsAssetUpdated = UObject::FindObject<UFunction>("Function ClothingSystemRuntimeInterface.ClothingSimulationInteractor.PhysicsAssetUpdated");

	struct {
	} parms;


	ProcessEvent(p_PhysicsAssetUpdated, &parms);
}

float UObject::GetSimulationTime(){

	static UObject* p_GetSimulationTime = UObject::FindObject<UFunction>("Function ClothingSystemRuntimeInterface.ClothingSimulationInteractor.GetSimulationTime");

	struct {
		float return_value;
	} parms;


	ProcessEvent(p_GetSimulationTime, &parms);
	return parms.return_value;
}

int32_t UObject::GetNumSubsteps(){

	static UObject* p_GetNumSubsteps = UObject::FindObject<UFunction>("Function ClothingSystemRuntimeInterface.ClothingSimulationInteractor.GetNumSubsteps");

	struct {
		int32_t return_value;
	} parms;


	ProcessEvent(p_GetNumSubsteps, &parms);
	return parms.return_value;
}

int32_t UObject::GetNumKinematicParticles(){

	static UObject* p_GetNumKinematicParticles = UObject::FindObject<UFunction>("Function ClothingSystemRuntimeInterface.ClothingSimulationInteractor.GetNumKinematicParticles");

	struct {
		int32_t return_value;
	} parms;


	ProcessEvent(p_GetNumKinematicParticles, &parms);
	return parms.return_value;
}

int32_t UObject::GetNumIterations(){

	static UObject* p_GetNumIterations = UObject::FindObject<UFunction>("Function ClothingSystemRuntimeInterface.ClothingSimulationInteractor.GetNumIterations");

	struct {
		int32_t return_value;
	} parms;


	ProcessEvent(p_GetNumIterations, &parms);
	return parms.return_value;
}

int32_t UObject::GetNumDynamicParticles(){

	static UObject* p_GetNumDynamicParticles = UObject::FindObject<UFunction>("Function ClothingSystemRuntimeInterface.ClothingSimulationInteractor.GetNumDynamicParticles");

	struct {
		int32_t return_value;
	} parms;


	ProcessEvent(p_GetNumDynamicParticles, &parms);
	return parms.return_value;
}

int32_t UObject::GetNumCloths(){

	static UObject* p_GetNumCloths = UObject::FindObject<UFunction>("Function ClothingSystemRuntimeInterface.ClothingSimulationInteractor.GetNumCloths");

	struct {
		int32_t return_value;
	} parms;


	ProcessEvent(p_GetNumCloths, &parms);
	return parms.return_value;
}

struct UClothingInteractor* UObject::GetClothingInteractor(struct FString ClothingAssetName){

	static UObject* p_GetClothingInteractor = UObject::FindObject<UFunction>("Function ClothingSystemRuntimeInterface.ClothingSimulationInteractor.GetClothingInteractor");

	struct {
		struct FString ClothingAssetName;
		struct UClothingInteractor* return_value;
	} parms;

	parms.ClothingAssetName = ClothingAssetName;

	ProcessEvent(p_GetClothingInteractor, &parms);
	return parms.return_value;
}

void UObject::EnableGravityOverride(struct FVector& InVector){

	static UObject* p_EnableGravityOverride = UObject::FindObject<UFunction>("Function ClothingSystemRuntimeInterface.ClothingSimulationInteractor.EnableGravityOverride");

	struct {
		struct FVector& InVector;
	} parms;

	parms.InVector = InVector;

	ProcessEvent(p_EnableGravityOverride, &parms);
}

void UObject::DisableGravityOverride(){

	static UObject* p_DisableGravityOverride = UObject::FindObject<UFunction>("Function ClothingSystemRuntimeInterface.ClothingSimulationInteractor.DisableGravityOverride");

	struct {
	} parms;


	ProcessEvent(p_DisableGravityOverride, &parms);
}

void UObject::ClothConfigUpdated(){

	static UObject* p_ClothConfigUpdated = UObject::FindObject<UFunction>("Function ClothingSystemRuntimeInterface.ClothingSimulationInteractor.ClothConfigUpdated");

	struct {
	} parms;


	ProcessEvent(p_ClothConfigUpdated, &parms);
}

