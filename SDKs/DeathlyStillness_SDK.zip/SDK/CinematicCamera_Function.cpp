#include "SDK.h" 
 
 
struct USplineComponent* AActor::GetRailSplineComponent(){

	static UObject* p_GetRailSplineComponent = UObject::FindObject<UFunction>("Function CinematicCamera.CameraRig_Rail.GetRailSplineComponent");

	struct {
		struct USplineComponent* return_value;
	} parms;


	ProcessEvent(p_GetRailSplineComponent, &parms);
	return parms.return_value;
}

struct UCineCameraComponent* ACameraActor::GetCineCameraComponent(){

	static UObject* p_GetCineCameraComponent = UObject::FindObject<UFunction>("Function CinematicCamera.CineCameraActor.GetCineCameraComponent");

	struct {
		struct UCineCameraComponent* return_value;
	} parms;


	ProcessEvent(p_GetCineCameraComponent, &parms);
	return parms.return_value;
}

void UCameraComponent::SetLensPresetByName(struct FString InPresetName){

	static UObject* p_SetLensPresetByName = UObject::FindObject<UFunction>("Function CinematicCamera.CineCameraComponent.SetLensPresetByName");

	struct {
		struct FString InPresetName;
	} parms;

	parms.InPresetName = InPresetName;

	ProcessEvent(p_SetLensPresetByName, &parms);
}

void UCameraComponent::SetFilmbackPresetByName(struct FString InPresetName){

	static UObject* p_SetFilmbackPresetByName = UObject::FindObject<UFunction>("Function CinematicCamera.CineCameraComponent.SetFilmbackPresetByName");

	struct {
		struct FString InPresetName;
	} parms;

	parms.InPresetName = InPresetName;

	ProcessEvent(p_SetFilmbackPresetByName, &parms);
}

void UCameraComponent::SetCurrentFocalLength(float InFocalLength){

	static UObject* p_SetCurrentFocalLength = UObject::FindObject<UFunction>("Function CinematicCamera.CineCameraComponent.SetCurrentFocalLength");

	struct {
		float InFocalLength;
	} parms;

	parms.InFocalLength = InFocalLength;

	ProcessEvent(p_SetCurrentFocalLength, &parms);
}

float UCameraComponent::GetVerticalFieldOfView(){

	static UObject* p_GetVerticalFieldOfView = UObject::FindObject<UFunction>("Function CinematicCamera.CineCameraComponent.GetVerticalFieldOfView");

	struct {
		float return_value;
	} parms;


	ProcessEvent(p_GetVerticalFieldOfView, &parms);
	return parms.return_value;
}

struct TArray<struct FNamedLensPreset> UCameraComponent::GetLensPresetsCopy(){

	static UObject* p_GetLensPresetsCopy = UObject::FindObject<UFunction>("Function CinematicCamera.CineCameraComponent.GetLensPresetsCopy");

	struct {
		struct TArray<struct FNamedLensPreset> return_value;
	} parms;


	ProcessEvent(p_GetLensPresetsCopy, &parms);
	return parms.return_value;
}

struct FString UCameraComponent::GetLensPresetName(){

	static UObject* p_GetLensPresetName = UObject::FindObject<UFunction>("Function CinematicCamera.CineCameraComponent.GetLensPresetName");

	struct {
		struct FString return_value;
	} parms;


	ProcessEvent(p_GetLensPresetName, &parms);
	return parms.return_value;
}

float UCameraComponent::GetHorizontalFieldOfView(){

	static UObject* p_GetHorizontalFieldOfView = UObject::FindObject<UFunction>("Function CinematicCamera.CineCameraComponent.GetHorizontalFieldOfView");

	struct {
		float return_value;
	} parms;


	ProcessEvent(p_GetHorizontalFieldOfView, &parms);
	return parms.return_value;
}

struct TArray<struct FNamedFilmbackPreset> UCameraComponent::GetFilmbackPresetsCopy(){

	static UObject* p_GetFilmbackPresetsCopy = UObject::FindObject<UFunction>("Function CinematicCamera.CineCameraComponent.GetFilmbackPresetsCopy");

	struct {
		struct TArray<struct FNamedFilmbackPreset> return_value;
	} parms;


	ProcessEvent(p_GetFilmbackPresetsCopy, &parms);
	return parms.return_value;
}

struct FString UCameraComponent::GetFilmbackPresetName(){

	static UObject* p_GetFilmbackPresetName = UObject::FindObject<UFunction>("Function CinematicCamera.CineCameraComponent.GetFilmbackPresetName");

	struct {
		struct FString return_value;
	} parms;


	ProcessEvent(p_GetFilmbackPresetName, &parms);
	return parms.return_value;
}

struct FString UCameraComponent::GetDefaultFilmbackPresetName(){

	static UObject* p_GetDefaultFilmbackPresetName = UObject::FindObject<UFunction>("Function CinematicCamera.CineCameraComponent.GetDefaultFilmbackPresetName");

	struct {
		struct FString return_value;
	} parms;


	ProcessEvent(p_GetDefaultFilmbackPresetName, &parms);
	return parms.return_value;
}

