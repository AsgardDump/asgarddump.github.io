#pragma once 
#include "SDK.h" 
 
 
// Function CustomDamage.CustomDamage_C.DamageHit
// Size: 0x90(Inherited: 0x0) 
struct FDamageHit
{
	struct FHitResult bpp__Hit__pf;  // 0x0(0x88)
	float bpp__Damage__pf;  // 0x88(0x4)
	char pad_140_1 : 7;  // 0x8C(0x1)
	bool bpp__isMeleex__pfzy : 1;  // 0x8C(0x1)
	char pad_141[3];  // 0x8D(0x3)

}; 
