#pragma once 
#include "SDK.h" 
 
 
// Function Backroom_Quest_BP.Backroom_Quest_BP_C.ExecuteUbergraph_Backroom_Quest_BP_1
// Size: 0x4(Inherited: 0x0) 
struct FExecuteUbergraph_Backroom_Quest_BP_1
{
	int32_t bpp__EntryPoint__pf;  // 0x0(0x4)

}; 
