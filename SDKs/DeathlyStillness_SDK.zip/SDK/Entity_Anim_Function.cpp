#include "SDK.h" 
 
 
void UAnimInstance::AnimGraph(struct FPoseLink& AnimGraph){

	static UObject* p_AnimGraph = UObject::FindObject<UFunction>("Function Entity_Anim.Entity_Anim_C.AnimGraph");

	struct {
		struct FPoseLink& AnimGraph;
	} parms;

	parms.AnimGraph = AnimGraph;

	ProcessEvent(p_AnimGraph, &parms);
}

void UAnimInstance::EvaluateGraphExposedInputs_ExecuteUbergraph_Entity_Anim_AnimGraphNode_BlendListByBool_2EFF006A47A63720EAD32FB2FB8061E9(){

	static UObject* p_EvaluateGraphExposedInputs_ExecuteUbergraph_Entity_Anim_AnimGraphNode_BlendListByBool_2EFF006A47A63720EAD32FB2FB8061E9 = UObject::FindObject<UFunction>("Function Entity_Anim.Entity_Anim_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Entity_Anim_AnimGraphNode_BlendListByBool_2EFF006A47A63720EAD32FB2FB8061E9");

	struct {
	} parms;


	ProcessEvent(p_EvaluateGraphExposedInputs_ExecuteUbergraph_Entity_Anim_AnimGraphNode_BlendListByBool_2EFF006A47A63720EAD32FB2FB8061E9, &parms);
}

void UAnimInstance::BlueprintUpdateAnimation(float DeltaTimeX){

	static UObject* p_BlueprintUpdateAnimation = UObject::FindObject<UFunction>("Function Entity_Anim.Entity_Anim_C.BlueprintUpdateAnimation");

	struct {
		float DeltaTimeX;
	} parms;

	parms.DeltaTimeX = DeltaTimeX;

	ProcessEvent(p_BlueprintUpdateAnimation, &parms);
}

void UAnimInstance::ExecuteUbergraph_Entity_Anim(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph_Entity_Anim = UObject::FindObject<UFunction>("Function Entity_Anim.Entity_Anim_C.ExecuteUbergraph_Entity_Anim");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph_Entity_Anim, &parms);
}

