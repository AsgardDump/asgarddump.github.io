#pragma once 
#include <CustomDamage_Structs.h>
 
 
 
// DynamicClass CustomDamage.CustomDamage_C
// Size: 0x28(Inherited: 0x28) 
struct UCustomDamage_C : public UInterface
{

	void DamageHit(struct FHitResult bpp__Hit__pf, float bpp__Damage__pf, bool bpp__isMeleex__pfzy); // Function CustomDamage.CustomDamage_C.DamageHit
}; 



