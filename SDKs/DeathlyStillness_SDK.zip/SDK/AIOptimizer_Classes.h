#pragma once 
#include <AIOptimizer_Structs.h>
 
 
 
// Class AIOptimizer.AIOInvokerComponent
// Size: 0xB8(Inherited: 0xB0) 
struct UAIOInvokerComponent : public UActorComponent
{
	struct UUserWidget* DebugWidget;  // 0xB0(0x8)

	void DebugAIOptimizer(bool bDebug); // Function AIOptimizer.AIOInvokerComponent.DebugAIOptimizer
}; 



// Class AIOptimizer.AIOBPLibrary
// Size: 0x28(Inherited: 0x28) 
struct UAIOBPLibrary : public UBlueprintFunctionLibrary
{

	void SetCharacterMovementEnabled(struct ACharacter* Character, bool bEnable); // Function AIOptimizer.AIOBPLibrary.SetCharacterMovementEnabled
	void SetAILogicEnabled(struct AActor* Actor, bool bEnable); // Function AIOptimizer.AIOBPLibrary.SetAILogicEnabled
	bool RemoveHandle(struct TArray<struct FAIOSubjectHandle>& Array, struct FAIOSubjectHandle& Handle); // Function AIOptimizer.AIOBPLibrary.RemoveHandle
	bool IsHandleValid(struct FAIOSubjectHandle& Handle); // Function AIOptimizer.AIOBPLibrary.IsHandleValid
	struct FName GetSubjectTag(); // Function AIOptimizer.AIOBPLibrary.GetSubjectTag
	struct FString GetString(struct FAIOSubjectHandle& Handle); // Function AIOptimizer.AIOBPLibrary.GetString
	struct FName GetInvokerTag(); // Function AIOptimizer.AIOBPLibrary.GetInvokerTag
	int32_t FindHandle(struct TArray<struct FAIOSubjectHandle>& Array, struct FAIOSubjectHandle& HandleToFind); // Function AIOptimizer.AIOBPLibrary.FindHandle
	int32_t AddUniqueHandle(struct TArray<struct FAIOSubjectHandle>& Array, struct FAIOSubjectHandle& Handle); // Function AIOptimizer.AIOBPLibrary.AddUniqueHandle
}; 



// Class AIOptimizer.AIOData_Base
// Size: 0x28(Inherited: 0x28) 
struct UAIOData_Base : public UObject
{

}; 



// Class AIOptimizer.AIODeveloperSettings
// Size: 0x60(Inherited: 0x38) 
struct UAIODeveloperSettings : public UDeveloperSettings
{
	char bIsSubsystemEnabled : 1;  // 0x38(0x1)
	char bDisplayDebugInfo : 1;  // 0x38(0x1)
	char pad_56_1 : 6;  // 0x38(0x1)
	char pad_57[8];  // 0x39(0x8)
	UUserWidget* DebugWidgetClass;  // 0x40(0x8)
	float OptimizationUpdateInterval;  // 0x48(0x4)
	uint8_t  HandleSpawnDespawnMethod;  // 0x4C(0x1)
	char pad_77[3];  // 0x4D(0x3)
	int32_t SpawnCapacityPerUpdate;  // 0x50(0x4)
	float SpawnInterval;  // 0x54(0x4)
	float DespawnRadius;  // 0x58(0x4)
	float PeripheralVisionHalfAngleDegrees;  // 0x5C(0x4)

}; 



// Class AIOptimizer.AIOptimizerSubsystem
// Size: 0xC8(Inherited: 0x30) 
struct UAIOptimizerSubsystem : public UWorldSubsystem
{
	struct FMulticastInlineDelegate OnSubjectDespawned;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnSubjectSpawned;  // 0x40(0x10)
	struct FMulticastInlineDelegate OnSubsystemEnabledChanged;  // 0x50(0x10)
	struct TArray<struct FAIOSubject> SpawnedSubjects;  // 0x60(0x10)
	struct TArray<struct FAIODespawnedSubject> DespawnedSubjects;  // 0x70(0x10)
	struct TArray<struct FAIOInvoker> Invokers;  // 0x80(0x10)
	struct TArray<struct FAIOSubject> PendingDespawnSubjectsHeap;  // 0x90(0x10)
	struct TArray<struct FAIODespawnedSubject> PendingSpawnSubjectsHeap;  // 0xA0(0x10)
	char pad_176[24];  // 0xB0(0x18)

	bool UnregisterSubject(struct UAIOSubjectComponent* SubjectComponent); // Function AIOptimizer.AIOptimizerSubsystem.UnregisterSubject
	bool UnregisterInvoker(struct UAIOInvokerComponent* InvokerComponent); // Function AIOptimizer.AIOptimizerSubsystem.UnregisterInvoker
	void ShrinkArrays(); // Function AIOptimizer.AIOptimizerSubsystem.ShrinkArrays
	void SetIsSystemEnabled(bool bIsEnabled); // Function AIOptimizer.AIOptimizerSubsystem.SetIsSystemEnabled
	bool RemoveDespawnedSubjectByHandle(struct FAIOSubjectHandle& Handle); // Function AIOptimizer.AIOptimizerSubsystem.RemoveDespawnedSubjectByHandle
	bool RegisterSubject(struct UAIOSubjectComponent* SubjectComponent); // Function AIOptimizer.AIOptimizerSubsystem.RegisterSubject
	bool RegisterInvoker(struct UAIOInvokerComponent* InvokerComponent); // Function AIOptimizer.AIOptimizerSubsystem.RegisterInvoker
	void LoopSubjects(); // Function AIOptimizer.AIOptimizerSubsystem.LoopSubjects
	void LoopPendingSubjects(); // Function AIOptimizer.AIOptimizerSubsystem.LoopPendingSubjects
	bool K2_SpawnSubjectByHandle(uint8_t  Method, struct FAIOSubjectHandle& SubjectHandle); // Function AIOptimizer.AIOptimizerSubsystem.K2_SpawnSubjectByHandle
	bool K2_DespawnSubjectByHandle(struct FAIOSubjectHandle& SubjectHandle, uint8_t  Method, float OverrideSpawnRadius, bool bAllowRespawnOnlyByHandle); // Function AIOptimizer.AIOptimizerSubsystem.K2_DespawnSubjectByHandle
	bool K2_DespawnSubject(struct FAIOSubjectHandle& SubjectHandle, uint8_t  Method, struct UAIOSubjectComponent* Component, float OverrideSpawnRadius, bool bAllowRespawnOnlyByHandle); // Function AIOptimizer.AIOptimizerSubsystem.K2_DespawnSubject
	int32_t GetSubjectIndex(struct UAIOSubjectComponent* Component); // Function AIOptimizer.AIOptimizerSubsystem.GetSubjectIndex
	int32_t GetInvokerIndex(struct UAIOInvokerComponent* Component); // Function AIOptimizer.AIOptimizerSubsystem.GetInvokerIndex
	float GetDistanceToClosestInvokerSquared(struct FVector& QuerierLocation); // Function AIOptimizer.AIOptimizerSubsystem.GetDistanceToClosestInvokerSquared
	struct TArray<struct FAIODebugSubjectData> GetDebugSubjects(); // Function AIOptimizer.AIOptimizerSubsystem.GetDebugSubjects
	struct FVector GetClosestInvokerLocation(struct FVector& QuerierLocation); // Function AIOptimizer.AIOptimizerSubsystem.GetClosestInvokerLocation
	struct TMap<uint8_t , int32_t> GetCategorizedDebugSubjects(struct TArray<struct FAIODebugSubjectData>& DebugSubjects); // Function AIOptimizer.AIOptimizerSubsystem.GetCategorizedDebugSubjects
}; 



// Class AIOptimizer.SpawnerInterface
// Size: 0x28(Inherited: 0x28) 
struct USpawnerInterface : public UInterface
{

	void OnSubjectSpawnedByOptimizerSubsystem(struct UAIOSubjectComponent* SpawnedSubjectComponent); // Function AIOptimizer.SpawnerInterface.OnSubjectSpawnedByOptimizerSubsystem
	void OnSubjectDespawnedByOptimizerSubsystem(struct UAIOSubjectComponent* DespawnedSubjectComponent); // Function AIOptimizer.SpawnerInterface.OnSubjectDespawnedByOptimizerSubsystem
}; 



// Class AIOptimizer.AIOSubjectComponent
// Size: 0x148(Inherited: 0xB0) 
struct UAIOSubjectComponent : public UActorComponent
{
	char pad_176[28];  // 0xB0(0x1C)
	struct FAIOSubjectHandle Handle;  // 0xCC(0x4)
	char pad_208[8];  // 0xD0(0x8)
	struct FMulticastInlineDelegate OnOptimizationUpdate;  // 0xD8(0x10)
	struct FMulticastInlineDelegate OnPreDespawn;  // 0xE8(0x10)
	struct FMulticastInlineDelegate OnPostSpawned;  // 0xF8(0x10)
	struct AActor* Spawner;  // 0x108(0x8)
	char bCanBeUpdatedBySubsystem : 1;  // 0x110(0x1)
	char bAllowSubsystemToAutoDespawn : 1;  // 0x110(0x1)
	char pad_272_1 : 6;  // 0x110(0x1)
	char pad_273[4];  // 0x111(0x4)
	float OverrideSubsystemDespawnRadius;  // 0x114(0x4)
	char Priority;  // 0x118(0x1)
	char pad_281[7];  // 0x119(0x7)
	UAIOData_Base* DataClass;  // 0x120(0x8)
	struct TArray<struct FAIOptimizationLayer> OptimizationLayers;  // 0x128(0x10)
	char bShouldCalculateIsSeen : 1;  // 0x138(0x1)
	char pad_312_1 : 7;  // 0x138(0x1)
	char pad_313[16];  // 0x139(0x10)

	void UnregisterSubject(); // Function AIOptimizer.AIOSubjectComponent.UnregisterSubject
	bool ShouldBeDespawned(struct UAIOptimizerSubsystem* Subsystem, bool bForceUpdateDataToInvokers); // Function AIOptimizer.AIOSubjectComponent.ShouldBeDespawned
	void SetSpawner(struct TScriptInterface<ISpawnerInterface> NewSpawner); // Function AIOptimizer.AIOSubjectComponent.SetSpawner
	void SetCharacterFeatures(struct ACharacter* Character, int32_t FeaturesToEnable); // Function AIOptimizer.AIOSubjectComponent.SetCharacterFeatures
	void SetCanBeUpdatedBySubsystem(bool bCanBeUpdated); // Function AIOptimizer.AIOSubjectComponent.SetCanBeUpdatedBySubsystem
	void ReinitializeOptimizationLayers(struct TArray<struct FAIOptimizationLayer>& NewOptimizationLayers); // Function AIOptimizer.AIOSubjectComponent.ReinitializeOptimizationLayers
	void RegisterSubject(); // Function AIOptimizer.AIOSubjectComponent.RegisterSubject
	float IsSeenByAnyInvoker(); // Function AIOptimizer.AIOSubjectComponent.IsSeenByAnyInvoker
	bool IsDespawning(); // Function AIOptimizer.AIOSubjectComponent.IsDespawning
	float GetSpawnRadiusSquared(struct UAIOptimizerSubsystem* Subsystem); // Function AIOptimizer.AIOSubjectComponent.GetSpawnRadiusSquared
	int32_t GetOptimizationLayerForCurrentDistance(); // Function AIOptimizer.AIOSubjectComponent.GetOptimizationLayerForCurrentDistance
	float GetDistanceToClosestInvoker(); // Function AIOptimizer.AIOSubjectComponent.GetDistanceToClosestInvoker
	float GetDespawnRadiusSquared(struct UAIOptimizerSubsystem* Subsystem); // Function AIOptimizer.AIOSubjectComponent.GetDespawnRadiusSquared
	int32_t GetCurrentOptimizationLayer(); // Function AIOptimizer.AIOSubjectComponent.GetCurrentOptimizationLayer
	struct FVector GetClosestInvokerLocation(); // Function AIOptimizer.AIOSubjectComponent.GetClosestInvokerLocation
	bool CanBeUpdatedBySubsystem(); // Function AIOptimizer.AIOSubjectComponent.CanBeUpdatedBySubsystem
}; 



