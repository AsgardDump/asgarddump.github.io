#pragma once 
#include <Aimpoint3X_SpawnerBP_Structs.h>
 
 
 
// BlueprintGeneratedClass Aimpoint3X_SpawnerBP.Aimpoint3X_SpawnerBP_C
// Size: 0x258(Inherited: 0x258) 
struct AAimpoint3X_SpawnerBP_C : public AOpticsMaster_SpawnerBP_C
{

}; 



