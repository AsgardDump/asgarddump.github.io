#pragma once 
#include "SDK.h" 
 
 
// Function ..
// Size: 0x8(Inherited: 0x0) 
struct F
{
	struct USoundBase* NewSound;  // 0x0(0x8)

}; 
