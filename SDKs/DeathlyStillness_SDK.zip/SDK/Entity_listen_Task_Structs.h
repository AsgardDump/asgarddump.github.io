#pragma once 
#include "SDK.h" 
 
 
// Function Entity_listen_Task.Entity_listen_Task_C.OnFail_CA1963E1418C4F4A316F0D86889B8592
// Size: 0x1(Inherited: 0x0) 
struct FOnFail_CA1963E1418C4F4A316F0D86889B8592
{
	char EPathFollowingResult MovementResult;  // 0x0(0x1)

}; 
// Function Entity_listen_Task.Entity_listen_Task_C.ExecuteUbergraph_Entity_listen_Task
// Size: 0xB0(Inherited: 0x0) 
struct FExecuteUbergraph_Entity_listen_Task
{
	int32_t EntryPoint;  // 0x0(0x4)
	float CallFunc_RandomFloatInRange_ReturnValue;  // 0x4(0x4)
	char EPathFollowingResult K2Node_CustomEvent_MovementResult_2;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0xC(0x10)
	char EPathFollowingResult K2Node_CustomEvent_MovementResult;  // 0x1C(0x1)
	char pad_29[3];  // 0x1D(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x20(0x10)
	char EPathFollowingResult ___byte_Variable;  // 0x30(0x1)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x31(0x1)
	char pad_50[6];  // 0x32(0x6)
	struct AAIController* K2Node_Event_OwnerController_2;  // 0x38(0x8)
	struct APawn* K2Node_Event_ControlledPawn_2;  // 0x40(0x8)
	struct FName CallFunc_MakeLiteralName_ReturnValue;  // 0x48(0x8)
	struct AAIController* K2Node_Event_OwnerController;  // 0x50(0x8)
	struct APawn* K2Node_Event_ControlledPawn;  // 0x58(0x8)
	float K2Node_Event_DeltaSeconds;  // 0x60(0x4)
	char pad_100[4];  // 0x64(0x4)
	struct ABP_Entity_Pawn_C* K2Node_DynamicCast_AsBP_Entity_Pawn;  // 0x68(0x8)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x70(0x1)
	char pad_113[7];  // 0x71(0x7)
	struct AAIController* CallFunc_GetAIController_ReturnValue;  // 0x78(0x8)
	struct AEntity_AiController_C* K2Node_DynamicCast_AsEntity_Ai_Controller;  // 0x80(0x8)
	char pad_136_1 : 7;  // 0x88(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x88(0x1)
	char pad_137[7];  // 0x89(0x7)
	struct UBlackboardComponent* CallFunc_GetBlackboard_ReturnValue;  // 0x90(0x8)
	struct UAIAsyncTaskBlueprintProxy* CallFunc_CreateMoveToProxyObject_ReturnValue;  // 0x98(0x8)
	char pad_160_1 : 7;  // 0xA0(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0xA0(0x1)
	char pad_161[7];  // 0xA1(0x7)
	struct FTimerHandle CallFunc_K2_SetTimer_ReturnValue;  // 0xA8(0x8)

}; 
// Function Entity_listen_Task.Entity_listen_Task_C.ReceiveTickAI
// Size: 0x14(Inherited: 0x18) 
struct FReceiveTickAI : public FReceiveTickAI
{
	struct AAIController* OwnerController;  // 0x0(0x8)
	struct APawn* ControlledPawn;  // 0x8(0x8)
	float DeltaSeconds;  // 0x10(0x4)

}; 
// Function Entity_listen_Task.Entity_listen_Task_C.ReceiveExecuteAI
// Size: 0x10(Inherited: 0x10) 
struct FReceiveExecuteAI : public FReceiveExecuteAI
{
	struct AAIController* OwnerController;  // 0x0(0x8)
	struct APawn* ControlledPawn;  // 0x8(0x8)

}; 
// Function Entity_listen_Task.Entity_listen_Task_C.OnSuccess_CA1963E1418C4F4A316F0D86889B8592
// Size: 0x1(Inherited: 0x0) 
struct FOnSuccess_CA1963E1418C4F4A316F0D86889B8592
{
	char EPathFollowingResult MovementResult;  // 0x0(0x1)

}; 
