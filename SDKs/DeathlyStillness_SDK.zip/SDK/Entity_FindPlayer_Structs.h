#pragma once 
#include "SDK.h" 
 
 
// Function Entity_FindPlayer.Entity_FindPlayer_C.ExecuteUbergraph_Entity_FindPlayer
// Size: 0x71(Inherited: 0x0) 
struct FExecuteUbergraph_Entity_FindPlayer
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct APawn* CallFunc_GetPlayerPawn_ReturnValue;  // 0x8(0x8)
	char EPathFollowingResult K2Node_CustomEvent_MovementResult_2;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x14(0x10)
	char EPathFollowingResult K2Node_CustomEvent_MovementResult;  // 0x24(0x1)
	char pad_37[3];  // 0x25(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x28(0x10)
	char EPathFollowingResult ___byte_Variable;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct AAIController* K2Node_Event_OwnerController;  // 0x40(0x8)
	struct APawn* K2Node_Event_ControlledPawn;  // 0x48(0x8)
	float K2Node_Event_DeltaSeconds;  // 0x50(0x4)
	char pad_84[4];  // 0x54(0x4)
	struct ABP_Entity_Pawn_C* K2Node_DynamicCast_AsBP_Entity_Pawn;  // 0x58(0x8)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x60(0x1)
	char pad_97[7];  // 0x61(0x7)
	struct UAIAsyncTaskBlueprintProxy* CallFunc_CreateMoveToProxyObject_ReturnValue;  // 0x68(0x8)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x70(0x1)

}; 
// Function Entity_FindPlayer.Entity_FindPlayer_C.ReceiveTickAI
// Size: 0x14(Inherited: 0x18) 
struct FReceiveTickAI : public FReceiveTickAI
{
	struct AAIController* OwnerController;  // 0x0(0x8)
	struct APawn* ControlledPawn;  // 0x8(0x8)
	float DeltaSeconds;  // 0x10(0x4)

}; 
// Function Entity_FindPlayer.Entity_FindPlayer_C.OnSuccess_AF1AD3FC44F1D7FEE4BA7FBE27A21D76
// Size: 0x1(Inherited: 0x0) 
struct FOnSuccess_AF1AD3FC44F1D7FEE4BA7FBE27A21D76
{
	char EPathFollowingResult MovementResult;  // 0x0(0x1)

}; 
// Function Entity_FindPlayer.Entity_FindPlayer_C.OnFail_AF1AD3FC44F1D7FEE4BA7FBE27A21D76
// Size: 0x1(Inherited: 0x0) 
struct FOnFail_AF1AD3FC44F1D7FEE4BA7FBE27A21D76
{
	char EPathFollowingResult MovementResult;  // 0x0(0x1)

}; 
