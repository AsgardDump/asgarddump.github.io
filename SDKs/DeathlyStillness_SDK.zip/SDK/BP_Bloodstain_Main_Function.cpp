#include "SDK.h" 
 
 
void AActor::Dissolving__FinishedFunc(){

	static UObject* p_Dissolving__FinishedFunc = UObject::FindObject<UFunction>("Function BP_Bloodstain_Main.BP_Bloodstain_Main_C.Dissolving__FinishedFunc");

	struct {
	} parms;


	ProcessEvent(p_Dissolving__FinishedFunc, &parms);
}

void AActor::Dissolving__UpdateFunc(){

	static UObject* p_Dissolving__UpdateFunc = UObject::FindObject<UFunction>("Function BP_Bloodstain_Main.BP_Bloodstain_Main_C.Dissolving__UpdateFunc");

	struct {
	} parms;


	ProcessEvent(p_Dissolving__UpdateFunc, &parms);
}

void AActor::Timeline_0__FinishedFunc(){

	static UObject* p_Timeline_0__FinishedFunc = UObject::FindObject<UFunction>("Function BP_Bloodstain_Main.BP_Bloodstain_Main_C.Timeline_0__FinishedFunc");

	struct {
	} parms;


	ProcessEvent(p_Timeline_0__FinishedFunc, &parms);
}

void AActor::Timeline_0__UpdateFunc(){

	static UObject* p_Timeline_0__UpdateFunc = UObject::FindObject<UFunction>("Function BP_Bloodstain_Main.BP_Bloodstain_Main_C.Timeline_0__UpdateFunc");

	struct {
	} parms;


	ProcessEvent(p_Timeline_0__UpdateFunc, &parms);
}

void AActor::ReceiveBeginPlay(){

	static UObject* p_ReceiveBeginPlay = UObject::FindObject<UFunction>("Function BP_Bloodstain_Main.BP_Bloodstain_Main_C.ReceiveBeginPlay");

	struct {
	} parms;


	ProcessEvent(p_ReceiveBeginPlay, &parms);
}

void AActor::ExecuteUbergraph_BP_Bloodstain_Main(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph_BP_Bloodstain_Main = UObject::FindObject<UFunction>("Function BP_Bloodstain_Main.BP_Bloodstain_Main_C.ExecuteUbergraph_BP_Bloodstain_Main");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph_BP_Bloodstain_Main, &parms);
}

