#pragma once 
#include <BP_Bloodstain_Main_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Bloodstain_Main.BP_Bloodstain_Main_C
// Size: 0x274(Inherited: 0x220) 
struct ABP_Bloodstain_Main_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct UDecalComponent* Decal;  // 0x228(0x8)
	struct UStaticMeshComponent* Plane;  // 0x230(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x238(0x8)
	float Timeline_0_Dissolve_Rate_C74AE9DE4796FBF5B3D929A2EA67A74E;  // 0x240(0x4)
	char ETimelineDirection Timeline_0__Direction_C74AE9DE4796FBF5B3D929A2EA67A74E;  // 0x244(0x1)
	char pad_581[3];  // 0x245(0x3)
	struct UTimelineComponent* Timeline_1;  // 0x248(0x8)
	float Dissolving_Dissolve_Rate_CBD5B54442FA3C2AFBEBBE9D8EBDCF39;  // 0x250(0x4)
	char ETimelineDirection Dissolving__Direction_CBD5B54442FA3C2AFBEBBE9D8EBDCF39;  // 0x254(0x1)
	char pad_597[3];  // 0x255(0x3)
	struct UTimelineComponent* Dissolving;  // 0x258(0x8)
	struct UMaterialInstanceDynamic* Material;  // 0x260(0x8)
	struct UMaterialInterface* Static_Material;  // 0x268(0x8)
	float LifeTime;  // 0x270(0x4)

	void Dissolving__FinishedFunc(); // Function BP_Bloodstain_Main.BP_Bloodstain_Main_C.Dissolving__FinishedFunc
	void Dissolving__UpdateFunc(); // Function BP_Bloodstain_Main.BP_Bloodstain_Main_C.Dissolving__UpdateFunc
	void Timeline_0__FinishedFunc(); // Function BP_Bloodstain_Main.BP_Bloodstain_Main_C.Timeline_0__FinishedFunc
	void Timeline_0__UpdateFunc(); // Function BP_Bloodstain_Main.BP_Bloodstain_Main_C.Timeline_0__UpdateFunc
	void ReceiveBeginPlay(); // Function BP_Bloodstain_Main.BP_Bloodstain_Main_C.ReceiveBeginPlay
	void ExecuteUbergraph_BP_Bloodstain_Main(int32_t EntryPoint); // Function BP_Bloodstain_Main.BP_Bloodstain_Main_C.ExecuteUbergraph_BP_Bloodstain_Main
}; 



