#pragma once 
#include <CustomWeapon_BP_Structs.h>
 
 
 
// BlueprintGeneratedClass CustomWeapon_BP.CustomWeapon_BP_C
// Size: 0x2A0(Inherited: 0x220) 
struct ACustomWeapon_BP_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct UStaticMeshComponent* EOTech;  // 0x228(0x8)
	struct UStaticMeshComponent* RedDot;  // 0x230(0x8)
	struct UStaticMeshComponent* Medium_Suppressor_01;  // 0x238(0x8)
	struct USkeletalMeshComponent* Weapon;  // 0x240(0x8)
	struct USkeletalMeshComponent* Clip;  // 0x248(0x8)
	char WeaponType WeaponType;  // 0x250(0x1)
	char pad_593[7];  // 0x251(0x7)
	struct UCustomWeaponState_C* SaveGame;  // 0x258(0x8)
	struct TArray<char Optics_Enum> AllOptics;  // 0x260(0x10)
	char Optics_Enum Optics Type;  // 0x270(0x1)
	char AccessoriesType Accessories Enum;  // 0x271(0x1)
	char pad_626[6];  // 0x272(0x6)
	struct TArray<char MuzzleType> AllMuzzle;  // 0x278(0x10)
	char MuzzleType MuzzleType;  // 0x288(0x1)
	char pad_649[7];  // 0x289(0x7)
	struct USkeletalMeshComponent* HK416Sight;  // 0x290(0x8)
	struct USkeletalMeshComponent* HK416_Stock;  // 0x298(0x8)

	void (); // Function CustomWeapon_BP.CustomWeapon_BP_C.
	void (); // Function CustomWeapon_BP.CustomWeapon_BP_C.
	void (); // Function CustomWeapon_BP.CustomWeapon_BP_C.
	void ReceiveBeginPlay(); // Function CustomWeapon_BP.CustomWeapon_BP_C.ReceiveBeginPlay
	void (char WeaponType WeaponType, char Optics_Enum OpticsType); // Function CustomWeapon_BP.CustomWeapon_BP_C.
	void (char WeaponType WeaponType); // Function CustomWeapon_BP.CustomWeapon_BP_C.
	void (char MuzzleType MuzzleType, char WeaponType WeaponType); // Function CustomWeapon_BP.CustomWeapon_BP_C.
	void (); // Function CustomWeapon_BP.CustomWeapon_BP_C.
	void ExecuteUbergraph_CustomWeapon_BP(int32_t EntryPoint); // Function CustomWeapon_BP.CustomWeapon_BP_C.ExecuteUbergraph_CustomWeapon_BP
}; 



