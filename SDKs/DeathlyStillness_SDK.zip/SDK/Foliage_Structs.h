#pragma once 
#include "SDK.h" 
 
 
// DelegateFunction Foliage.InstancePointDamageSignature__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FInstancePointDamageSignature__DelegateSignature
{
	int32_t InstanceIndex;  // 0x0(0x4)
	float Damage;  // 0x4(0x4)
	struct AController* InstigatedBy;  // 0x8(0x8)
	struct FVector HitLocation;  // 0x10(0xC)
	struct FVector ShotFromDirection;  // 0x1C(0xC)
	struct UDamageType* DamageType;  // 0x28(0x8)
	struct AActor* DamageCauser;  // 0x30(0x8)

}; 
// Function Foliage.ProceduralFoliageSpawner.Simulate
// Size: 0x4(Inherited: 0x0) 
struct FSimulate
{
	int32_t NumSteps;  // 0x0(0x4)

}; 
// Function Foliage.FoliageStatistics.FoliageOverlappingBoxCount
// Size: 0x30(Inherited: 0x0) 
struct FFoliageOverlappingBoxCount
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct UStaticMesh* StaticMesh;  // 0x8(0x8)
	struct FBox Box;  // 0x10(0x1C)
	int32_t ReturnValue;  // 0x2C(0x4)

}; 
// ScriptStruct Foliage.FoliageTypeObject
// Size: 0x20(Inherited: 0x0) 
struct FFoliageTypeObject
{
	struct UObject* FoliageTypeObject;  // 0x0(0x8)
	struct UFoliageType* TypeInstance;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bIsAsset : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	UFoliageType_InstancedStaticMesh* Type;  // 0x18(0x8)

}; 
// DelegateFunction Foliage.InstanceRadialDamageSignature__DelegateSignature
// Size: 0x48(Inherited: 0x0) 
struct FInstanceRadialDamageSignature__DelegateSignature
{
	struct TArray<int32_t> Instances;  // 0x0(0x10)
	struct TArray<float> Damages;  // 0x10(0x10)
	struct AController* InstigatedBy;  // 0x20(0x8)
	struct FVector Origin;  // 0x28(0xC)
	float MaxRadius;  // 0x34(0x4)
	struct UDamageType* DamageType;  // 0x38(0x8)
	struct AActor* DamageCauser;  // 0x40(0x8)

}; 
// ScriptStruct Foliage.FoliageVertexColorChannelMask
// Size: 0xC(Inherited: 0x0) 
struct FFoliageVertexColorChannelMask
{
	char UseMask : 1;  // 0x0(0x1)
	char pad_0_1 : 7;  // 0x0(0x1)
	char pad_1[4];  // 0x1(0x4)
	float MaskThreshold;  // 0x4(0x4)
	char InvertMask : 1;  // 0x8(0x1)
	char pad_8_1 : 7;  // 0x8(0x1)
	char pad_9[4];  // 0x9(0x4)

}; 
// ScriptStruct Foliage.ProceduralFoliageInstance
// Size: 0x50(Inherited: 0x0) 
struct FProceduralFoliageInstance
{
	struct FQuat Rotation;  // 0x0(0x10)
	struct FVector Location;  // 0x10(0xC)
	float Age;  // 0x1C(0x4)
	struct FVector Normal;  // 0x20(0xC)
	float Scale;  // 0x2C(0x4)
	struct UFoliageType* Type;  // 0x30(0x8)
	char pad_56[24];  // 0x38(0x18)

}; 
// Function Foliage.InteractiveFoliageActor.CapsuleTouched
// Size: 0xA8(Inherited: 0x0) 
struct FCapsuleTouched
{
	struct UPrimitiveComponent* OverlappedComp;  // 0x0(0x8)
	struct AActor* Other;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	int32_t OtherBodyIndex;  // 0x18(0x4)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool bFromSweep : 1;  // 0x1C(0x1)
	char pad_29[3];  // 0x1D(0x3)
	struct FHitResult OverlapInfo;  // 0x20(0x88)

}; 
// Function Foliage.FoliageStatistics.FoliageOverlappingSphereCount
// Size: 0x28(Inherited: 0x0) 
struct FFoliageOverlappingSphereCount
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct UStaticMesh* StaticMesh;  // 0x8(0x8)
	struct FVector CenterPosition;  // 0x10(0xC)
	float Radius;  // 0x1C(0x4)
	int32_t ReturnValue;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)

}; 
