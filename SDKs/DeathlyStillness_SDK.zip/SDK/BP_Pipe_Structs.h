#pragma once 
#include "SDK.h" 
 
 
// Function BP_Pipe.BP_Pipe_C.UserConstructionScript
// Size: 0xB9(Inherited: 0x0) 
struct FUserConstructionScript : public FUserConstructionScript
{
	struct FTransform ___struct_Variable;  // 0x0(0x30)
	struct FTransform ___struct_Variable_2;  // 0x30(0x30)
	struct USplineMeshComponent* CallFunc_AddComponent_ReturnValue;  // 0x60(0x8)
	struct USplineMeshComponent* CallFunc_AddComponent_ReturnValue_2;  // 0x68(0x8)
	int32_t ___int_Variable;  // 0x70(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x74(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0x78(0x4)
	char pad_124_1 : 7;  // 0x7C(0x1)
	bool CallFunc_K2_AttachToComponent_ReturnValue : 1;  // 0x7C(0x1)
	char pad_125_1 : 7;  // 0x7D(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x7D(0x1)
	char pad_126_1 : 7;  // 0x7E(0x1)
	bool CallFunc_K2_AttachToComponent_ReturnValue_2 : 1;  // 0x7E(0x1)
	char pad_127[1];  // 0x7F(0x1)
	struct FVector CallFunc_GetLocationAndTangentAtSplinePoint_Location;  // 0x80(0xC)
	struct FVector CallFunc_GetLocationAndTangentAtSplinePoint_Tangent;  // 0x8C(0xC)
	struct FVector CallFunc_GetLocationAndTangentAtSplinePoint_Location_2;  // 0x98(0xC)
	struct FVector CallFunc_GetLocationAndTangentAtSplinePoint_Tangent_2;  // 0xA4(0xC)
	int32_t CallFunc_GetNumberOfSplinePoints_ReturnValue;  // 0xB0(0x4)
	int32_t CallFunc_Subtract_IntInt_ReturnValue;  // 0xB4(0x4)
	char pad_184_1 : 7;  // 0xB8(0x1)
	bool CallFunc_LessEqual_IntInt_ReturnValue : 1;  // 0xB8(0x1)

}; 
