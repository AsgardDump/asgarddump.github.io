#include "SDK.h" 
 
 
void AActor::(){

	static UObject* p_ = UObject::FindObject<UFunction>("Function Backroom_Quest_BP.Backroom_Quest_BP_C.");

	struct {
	} parms;


	ProcessEvent(p_, &parms);
}

void AActor::RefreshQuest(){

	static UObject* p_RefreshQuest = UObject::FindObject<UFunction>("Function Backroom_Quest_BP.Backroom_Quest_BP_C.RefreshQuest");

	struct {
	} parms;


	ProcessEvent(p_RefreshQuest, &parms);
}

void AActor::ReceiveBeginPlay(){

	static UObject* p_ReceiveBeginPlay = UObject::FindObject<UFunction>("Function Backroom_Quest_BP.Backroom_Quest_BP_C.ReceiveBeginPlay");

	struct {
	} parms;


	ProcessEvent(p_ReceiveBeginPlay, &parms);
}

void AActor::ExecuteUbergraph_Backroom_Quest_BP_1(int32_t bpp__EntryPoint__pf){

	static UObject* p_ExecuteUbergraph_Backroom_Quest_BP_1 = UObject::FindObject<UFunction>("Function Backroom_Quest_BP.Backroom_Quest_BP_C.ExecuteUbergraph_Backroom_Quest_BP_1");

	struct {
		int32_t bpp__EntryPoint__pf;
	} parms;

	parms.bpp__EntryPoint__pf = bpp__EntryPoint__pf;

	ProcessEvent(p_ExecuteUbergraph_Backroom_Quest_BP_1, &parms);
}

void AActor::EndTalk(){

	static UObject* p_EndTalk = UObject::FindObject<UFunction>("Function Backroom_Quest_BP.Backroom_Quest_BP_C.EndTalk");

	struct {
	} parms;


	ProcessEvent(p_EndTalk, &parms);
}

