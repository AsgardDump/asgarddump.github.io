#pragma once 
#include <EOTechSpawn_BP_Structs.h>
 
 
 
// BlueprintGeneratedClass EOTechSpawn_BP.EOTechSpawn_BP_C
// Size: 0x240(Inherited: 0x231) 
struct AEOTechSpawn_BP_C : public AAccessories_Master_C
{
	char pad_561[7];  // 0x231(0x7)
	struct UStaticMeshComponent* StaticMesh;  // 0x238(0x8)

}; 



