#include "SDK.h" 
 
 
void AWeapon_Spawn_Master_BP_C::ExecuteUbergraph_AKMSpawner_BP3(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph_AKMSpawner_BP3 = UObject::FindObject<UFunction>("Function AKMSpawner_BP3.AKMSpawner_BP3_C.ExecuteUbergraph_AKMSpawner_BP3");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph_AKMSpawner_BP3, &parms);
}

