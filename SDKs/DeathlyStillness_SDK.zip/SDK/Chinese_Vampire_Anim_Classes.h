#pragma once 
#include <Chinese_Vampire_Anim_Structs.h>
 
 
 
// DynamicClass Chinese_Vampire_Anim.Chinese_Vampire_Anim_C
// Size: 0xAE0(Inherited: 0x2C0) 
struct UChinese_Vampire_Anim_C : public UAnimInstance
{
	struct FAnimNode_Root AnimGraphNode_Root;  // 0x2B8(0x30)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_3;  // 0x2E8(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_2;  // 0x310(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult;  // 0x338(0x28)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_4;  // 0x360(0x80)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_3;  // 0x3E0(0x30)
	struct FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer;  // 0x410(0xE8)
	struct FAnimNode_LayeredBoneBlend AnimGraphNode_LayeredBoneBlend;  // 0x4F8(0xC0)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_3;  // 0x5B8(0x80)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_2;  // 0x638(0x30)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_2;  // 0x668(0x80)
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool;  // 0x6E8(0xA0)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer;  // 0x788(0x80)
	struct FAnimNode_StateResult AnimGraphNode_StateResult;  // 0x808(0x30)
	struct FAnimNode_StateMachine AnimGraphNode_StateMachine;  // 0x838(0xB0)
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose;  // 0x8E8(0x158)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose;  // 0xA40(0x28)
	struct FAnimNode_Slot AnimGraphNode_Slot;  // 0xA68(0x48)
	float Speed;  // 0xAB0(0x4)
	char pad_2748_1 : 7;  // 0xABC(0x1)
	bool Dead? : 1;  // 0xAB4(0x1)
	char pad_2749_1 : 7;  // 0xABD(0x1)
	bool Hit : 1;  // 0xAB5(0x1)
	struct AChinese_Vampire_BP_C* As Chinese Vampire BP;  // 0xAB8(0x8)
	float ;  // 0xAC0(0x4)
	float K2Node_Event_DeltaTimeX;  // 0xAC4(0x4)
	struct AChinese_Vampire_BP_C* K2Node_DynamicCast_AsChinese_Vampire_BP;  // 0xAC8(0x8)
	char pad_2774_1 : 7;  // 0xAD6(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0xAD0(0x1)
	char pad_2775[9];  // 0xAD7(0x9)

	void EvaluateGraphExposedInputs_ExecuteUbergraph_Chinese_Vampire_Anim_AnimGraphNode_TransitionResult_EB9E32154ACFBB550C2A05A05D2169BC(); // Function Chinese_Vampire_Anim.Chinese_Vampire_Anim_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Chinese_Vampire_Anim_AnimGraphNode_TransitionResult_EB9E32154ACFBB550C2A05A05D2169BC
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Chinese_Vampire_Anim_AnimGraphNode_TransitionResult_3E7315F5434EED083EBC369FB01CDB75(); // Function Chinese_Vampire_Anim.Chinese_Vampire_Anim_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Chinese_Vampire_Anim_AnimGraphNode_TransitionResult_3E7315F5434EED083EBC369FB01CDB75
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Chinese_Vampire_Anim_AnimGraphNode_TransitionResult_2EE96C804F850CEAF9D49A80DCE0877C(); // Function Chinese_Vampire_Anim.Chinese_Vampire_Anim_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Chinese_Vampire_Anim_AnimGraphNode_TransitionResult_2EE96C804F850CEAF9D49A80DCE0877C
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Chinese_Vampire_Anim_AnimGraphNode_SequencePlayer_96498C024137B4B00D88BBA3A57F672F(); // Function Chinese_Vampire_Anim.Chinese_Vampire_Anim_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Chinese_Vampire_Anim_AnimGraphNode_SequencePlayer_96498C024137B4B00D88BBA3A57F672F
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Chinese_Vampire_Anim_AnimGraphNode_BlendSpacePlayer_F8C4EBF74FC67412A098ECBA6869C80A(); // Function Chinese_Vampire_Anim.Chinese_Vampire_Anim_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Chinese_Vampire_Anim_AnimGraphNode_BlendSpacePlayer_F8C4EBF74FC67412A098ECBA6869C80A
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Chinese_Vampire_Anim_AnimGraphNode_BlendListByBool_3251FFD64ADAD31A9E3E0B945C7C07F5(); // Function Chinese_Vampire_Anim.Chinese_Vampire_Anim_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Chinese_Vampire_Anim_AnimGraphNode_BlendListByBool_3251FFD64ADAD31A9E3E0B945C7C07F5
	void BlueprintUpdateAnimation(float bpp__DeltaTimeX__pf); // Function Chinese_Vampire_Anim.Chinese_Vampire_Anim_C.BlueprintUpdateAnimation
	void BlueprintInitializeAnimation(); // Function Chinese_Vampire_Anim.Chinese_Vampire_Anim_C.BlueprintInitializeAnimation
	void AnimNotify_Footstep(); // Function Chinese_Vampire_Anim.Chinese_Vampire_Anim_C.AnimNotify_Footstep
	void AnimGraph(struct FPoseLink& bpp__AnimGraph__pf); // Function Chinese_Vampire_Anim.Chinese_Vampire_Anim_C.AnimGraph
}; 



