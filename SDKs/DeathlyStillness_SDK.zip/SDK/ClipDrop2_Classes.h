#pragma once 
#include <ClipDrop2_Structs.h>
 
 
 
// BlueprintGeneratedClass ClipDrop2.ClipDrop2_C
// Size: 0x44(Inherited: 0x38) 
struct UClipDrop2_C : public UAnimNotify
{
	float Scale;  // 0x38(0x4)
	struct FName Socket Name;  // 0x3C(0x8)

	bool Received_Notify(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation); // Function ClipDrop2.ClipDrop2_C.Received_Notify
}; 



