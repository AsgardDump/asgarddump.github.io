#pragma once 
#include <Aimpoint4X_SpawnerBP_Structs.h>
 
 
 
// BlueprintGeneratedClass Aimpoint4X_SpawnerBP.Aimpoint4X_SpawnerBP_C
// Size: 0x260(Inherited: 0x258) 
struct AAimpoint4X_SpawnerBP_C : public AOpticsMaster_SpawnerBP_C
{
	struct UStaticMeshComponent* M150_ADS;  // 0x258(0x8)

}; 



