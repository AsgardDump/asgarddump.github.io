#pragma once 
#include <Entity_RandomMove_Structs.h>
 
 
 
// BlueprintGeneratedClass Entity_RandomMove.Entity_RandomMove_C
// Size: 0xB0(Inherited: 0xA8) 
struct UEntity_RandomMove_C : public UBTTask_BlueprintBase
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0xA8(0x8)

	void ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function Entity_RandomMove.Entity_RandomMove_C.ReceiveExecuteAI
	void ExecuteUbergraph_Entity_RandomMove(int32_t EntryPoint); // Function Entity_RandomMove.Entity_RandomMove_C.ExecuteUbergraph_Entity_RandomMove
}; 



