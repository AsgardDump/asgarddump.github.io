#include "SDK.h" 
 
 
void AActor::ReceiveBeginPlay(){

	static UObject* p_ReceiveBeginPlay = UObject::FindObject<UFunction>("Function BP_Splater_Preset_5.BP_Splater_Preset_4_C.ReceiveBeginPlay");

	struct {
	} parms;


	ProcessEvent(p_ReceiveBeginPlay, &parms);
}

void AActor::ReceiveParticleData(struct TArray<struct FBasicParticleData>& Data, struct UNiagaraSystem* NiagaraSystem){

	static UObject* p_ReceiveParticleData = UObject::FindObject<UFunction>("Function BP_Splater_Preset_5.BP_Splater_Preset_4_C.ReceiveParticleData");

	struct {
		struct TArray<struct FBasicParticleData>& Data;
		struct UNiagaraSystem* NiagaraSystem;
	} parms;

	parms.Data = Data;
	parms.NiagaraSystem = NiagaraSystem;

	ProcessEvent(p_ReceiveParticleData, &parms);
}

void AActor::SpawnDrops(){

	static UObject* p_SpawnDrops = UObject::FindObject<UFunction>("Function BP_Splater_Preset_5.BP_Splater_Preset_4_C.SpawnDrops");

	struct {
	} parms;


	ProcessEvent(p_SpawnDrops, &parms);
}

void AActor::ExecuteUbergraph_BP_Splater_Preset_5(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph_BP_Splater_Preset_5 = UObject::FindObject<UFunction>("Function BP_Splater_Preset_5.BP_Splater_Preset_4_C.ExecuteUbergraph_BP_Splater_Preset_5");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph_BP_Splater_Preset_5, &parms);
}

