#pragma once 
#include <BP_Splater_Preset_8_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Splater_Preset_8.BP_Splater_Preset_7_C
// Size: 0x29C(Inherited: 0x220) 
struct ABP_Splater_Preset_7_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct UNiagaraComponent* DropletStyle_Niagara;  // 0x228(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x230(0x8)
	float Particle_Size;  // 0x238(0x4)
	int32_t Max_Drops;  // 0x23C(0x4)
	float Cur_Droplets;  // 0x240(0x4)
	char pad_580[4];  // 0x244(0x4)
	struct TArray<struct FBasicParticleData> Data;  // 0x248(0x10)
	struct TArray<struct UMaterialInterface*> Splat_Materials;  // 0x258(0x10)
	float SplatSize_Min;  // 0x268(0x4)
	float SplatSize_Max;  // 0x26C(0x4)
	struct UNiagaraSystem* Burst_Style;  // 0x270(0x8)
	struct FLinearColor Color;  // 0x278(0x10)
	float Splat_Duration;  // 0x288(0x4)
	float Particle_Min_Distance;  // 0x28C(0x4)
	float Particle_MaxDistance;  // 0x290(0x4)
	float Particle_LifeTime_Multiplier;  // 0x294(0x4)
	float Gravity_Scale;  // 0x298(0x4)

	void ReceiveBeginPlay(); // Function BP_Splater_Preset_8.BP_Splater_Preset_7_C.ReceiveBeginPlay
	void ReceiveParticleData(struct TArray<struct FBasicParticleData>& Data, struct UNiagaraSystem* NiagaraSystem); // Function BP_Splater_Preset_8.BP_Splater_Preset_7_C.ReceiveParticleData
	void SpawnDrops(); // Function BP_Splater_Preset_8.BP_Splater_Preset_7_C.SpawnDrops
	void ExecuteUbergraph_BP_Splater_Preset_8(int32_t EntryPoint); // Function BP_Splater_Preset_8.BP_Splater_Preset_7_C.ExecuteUbergraph_BP_Splater_Preset_8
}; 



