#pragma once 
#include <Clip_Master_Structs.h>
 
 
 
// BlueprintGeneratedClass Clip_Master.Clip_Master_C
// Size: 0x238(Inherited: 0x220) 
struct AClip_Master_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct USkeletalMeshComponent* SkeletalMesh;  // 0x228(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x230(0x8)

	void (); // Function Clip_Master.Clip_Master_C.
	void ExecuteUbergraph_Clip_Master(int32_t EntryPoint); // Function Clip_Master.Clip_Master_C.ExecuteUbergraph_Clip_Master
}; 



