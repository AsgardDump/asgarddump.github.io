#pragma once 
#include <HK416Reload_EndCS1_Structs.h>
 
 
 
// BlueprintGeneratedClass HK416Reload_EndCS1.HK416Reload_EndCS1_C
// Size: 0x1B0(Inherited: 0x1B0) 
struct UHK416Reload_EndCS1_C : public UMatineeCameraShake
{

}; 



