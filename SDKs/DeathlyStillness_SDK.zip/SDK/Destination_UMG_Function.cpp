#include "SDK.h" 
 
 
void UUserWidget::QuestDistance(struct AActor* , struct FTransform& T, struct AActor* ){

	static UObject* p_QuestDistance = UObject::FindObject<UFunction>("Function Destination_UMG.Destination_UMG_C.QuestDistance");

	struct {
		struct AActor* ;
		struct FTransform& T;
		struct AActor* ;
	} parms;

	parms. = ;
	parms.T = T;
	parms. = ;

	ProcessEvent(p_QuestDistance, &parms);
}

void UUserWidget::Construct(){

	static UObject* p_Construct = UObject::FindObject<UFunction>("Function Destination_UMG.Destination_UMG_C.Construct");

	struct {
	} parms;


	ProcessEvent(p_Construct, &parms);
}

void UUserWidget::ExecuteUbergraph_Destination_UMG(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph_Destination_UMG = UObject::FindObject<UFunction>("Function Destination_UMG.Destination_UMG_C.ExecuteUbergraph_Destination_UMG");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph_Destination_UMG, &parms);
}

