#include "SDK.h" 
 
 
void UObject::ReadyForActivation(){

	static UObject* p_ReadyForActivation = UObject::FindObject<UFunction>("Function GameplayTasks.GameplayTask.ReadyForActivation");

	struct {
	} parms;


	ProcessEvent(p_ReadyForActivation, &parms);
}

void UObject::GenericGameplayTaskDelegate__DelegateSignature(){

	static UObject* p_GenericGameplayTaskDelegate__DelegateSignature = UObject::FindObject<UFunction>("DelegateFunction GameplayTasks.GameplayTask.GenericGameplayTaskDelegate__DelegateSignature");

	struct {
	} parms;


	ProcessEvent(p_GenericGameplayTaskDelegate__DelegateSignature, &parms);
}

void UObject::EndTask(){

	static UObject* p_EndTask = UObject::FindObject<UFunction>("Function GameplayTasks.GameplayTask.EndTask");

	struct {
	} parms;


	ProcessEvent(p_EndTask, &parms);
}

struct UGameplayTask_WaitDelay* UGameplayTask::TaskWaitDelay(struct TScriptInterface<IGameplayTaskOwnerInterface> TaskOwner, float Time, char Priority){

	static UObject* p_TaskWaitDelay = UObject::FindObject<UFunction>("Function GameplayTasks.GameplayTask_WaitDelay.TaskWaitDelay");

	struct {
		struct TScriptInterface<IGameplayTaskOwnerInterface> TaskOwner;
		float Time;
		char Priority;
		struct UGameplayTask_WaitDelay* return_value;
	} parms;

	parms.TaskOwner = TaskOwner;
	parms.Time = Time;
	parms.Priority = Priority;

	ProcessEvent(p_TaskWaitDelay, &parms);
	return parms.return_value;
}

void UGameplayTask::TaskDelayDelegate__DelegateSignature(){

	static UObject* p_TaskDelayDelegate__DelegateSignature = UObject::FindObject<UFunction>("DelegateFunction GameplayTasks.GameplayTask_WaitDelay.TaskDelayDelegate__DelegateSignature");

	struct {
	} parms;


	ProcessEvent(p_TaskDelayDelegate__DelegateSignature, &parms);
}

struct UGameplayTask_SpawnActor* UGameplayTask::SpawnActor(struct TScriptInterface<IGameplayTaskOwnerInterface> TaskOwner, struct FVector SpawnLocation, struct FRotator SpawnRotation, AActor* Class, bool bSpawnOnlyOnAuthority){

	static UObject* p_SpawnActor = UObject::FindObject<UFunction>("Function GameplayTasks.GameplayTask_SpawnActor.SpawnActor");

	struct {
		struct TScriptInterface<IGameplayTaskOwnerInterface> TaskOwner;
		struct FVector SpawnLocation;
		struct FRotator SpawnRotation;
		AActor* Class;
		bool bSpawnOnlyOnAuthority;
		struct UGameplayTask_SpawnActor* return_value;
	} parms;

	parms.TaskOwner = TaskOwner;
	parms.SpawnLocation = SpawnLocation;
	parms.SpawnRotation = SpawnRotation;
	parms.Class = Class;
	parms.bSpawnOnlyOnAuthority = bSpawnOnlyOnAuthority;

	ProcessEvent(p_SpawnActor, &parms);
	return parms.return_value;
}

void UGameplayTask::FinishSpawningActor(struct UObject* WorldContextObject, struct AActor* SpawnedActor){

	static UObject* p_FinishSpawningActor = UObject::FindObject<UFunction>("Function GameplayTasks.GameplayTask_SpawnActor.FinishSpawningActor");

	struct {
		struct UObject* WorldContextObject;
		struct AActor* SpawnedActor;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.SpawnedActor = SpawnedActor;

	ProcessEvent(p_FinishSpawningActor, &parms);
}

bool UGameplayTask::BeginSpawningActor(struct UObject* WorldContextObject, struct AActor*& SpawnedActor){

	static UObject* p_BeginSpawningActor = UObject::FindObject<UFunction>("Function GameplayTasks.GameplayTask_SpawnActor.BeginSpawningActor");

	struct {
		struct UObject* WorldContextObject;
		struct AActor*& SpawnedActor;
		bool return_value;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.SpawnedActor = SpawnedActor;

	ProcessEvent(p_BeginSpawningActor, &parms);
	return parms.return_value;
}

struct UGameplayTask_ClaimResource* UGameplayTask::ClaimResources(struct TScriptInterface<IGameplayTaskOwnerInterface> InTaskOwner, struct TArray<UGameplayTaskResource*> ResourceClasses, char Priority, struct FName TaskInstanceName){

	static UObject* p_ClaimResources = UObject::FindObject<UFunction>("Function GameplayTasks.GameplayTask_ClaimResource.ClaimResources");

	struct {
		struct TScriptInterface<IGameplayTaskOwnerInterface> InTaskOwner;
		struct TArray<UGameplayTaskResource*> ResourceClasses;
		char Priority;
		struct FName TaskInstanceName;
		struct UGameplayTask_ClaimResource* return_value;
	} parms;

	parms.InTaskOwner = InTaskOwner;
	parms.ResourceClasses = ResourceClasses;
	parms.Priority = Priority;
	parms.TaskInstanceName = TaskInstanceName;

	ProcessEvent(p_ClaimResources, &parms);
	return parms.return_value;
}

struct UGameplayTask_ClaimResource* UGameplayTask::ClaimResource(struct TScriptInterface<IGameplayTaskOwnerInterface> InTaskOwner, UGameplayTaskResource* ResourceClass, char Priority, struct FName TaskInstanceName){

	static UObject* p_ClaimResource = UObject::FindObject<UFunction>("Function GameplayTasks.GameplayTask_ClaimResource.ClaimResource");

	struct {
		struct TScriptInterface<IGameplayTaskOwnerInterface> InTaskOwner;
		UGameplayTaskResource* ResourceClass;
		char Priority;
		struct FName TaskInstanceName;
		struct UGameplayTask_ClaimResource* return_value;
	} parms;

	parms.InTaskOwner = InTaskOwner;
	parms.ResourceClass = ResourceClass;
	parms.Priority = Priority;
	parms.TaskInstanceName = TaskInstanceName;

	ProcessEvent(p_ClaimResource, &parms);
	return parms.return_value;
}

void UActorComponent::OnRep_SimulatedTasks(){

	static UObject* p_OnRep_SimulatedTasks = UObject::FindObject<UFunction>("Function GameplayTasks.GameplayTasksComponent.OnRep_SimulatedTasks");

	struct {
	} parms;


	ProcessEvent(p_OnRep_SimulatedTasks, &parms);
}

uint8_t  UActorComponent::K2_RunGameplayTask(struct TScriptInterface<IGameplayTaskOwnerInterface> TaskOwner, struct UGameplayTask* Task, char Priority, struct TArray<UGameplayTaskResource*> AdditionalRequiredResources, struct TArray<UGameplayTaskResource*> AdditionalClaimedResources){

	static UObject* p_K2_RunGameplayTask = UObject::FindObject<UFunction>("Function GameplayTasks.GameplayTasksComponent.K2_RunGameplayTask");

	struct {
		struct TScriptInterface<IGameplayTaskOwnerInterface> TaskOwner;
		struct UGameplayTask* Task;
		char Priority;
		struct TArray<UGameplayTaskResource*> AdditionalRequiredResources;
		struct TArray<UGameplayTaskResource*> AdditionalClaimedResources;
		uint8_t  return_value;
	} parms;

	parms.TaskOwner = TaskOwner;
	parms.Task = Task;
	parms.Priority = Priority;
	parms.AdditionalRequiredResources = AdditionalRequiredResources;
	parms.AdditionalClaimedResources = AdditionalClaimedResources;

	ProcessEvent(p_K2_RunGameplayTask, &parms);
	return parms.return_value;
}

