#pragma once 
#include "SDK.h" 
 
 
// Function CustomWeapon_BP.CustomWeapon_BP_C.ExecuteUbergraph_CustomWeapon_BP
// Size: 0x78(Inherited: 0x0) 
struct FExecuteUbergraph_CustomWeapon_BP
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct TArray<char MuzzleType> K2Node_MakeArray_Array;  // 0x8(0x10)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool CallFunc_DoesSaveGameExist_ReturnValue : 1;  // 0x19(0x1)
	char pad_26[6];  // 0x1A(0x6)
	struct UCustomWeaponState_C* CallFunc_CreateSaveGameObject_ReturnValue;  // 0x20(0x8)
	struct USaveGame* CallFunc_LoadGameFromSlot_ReturnValue;  // 0x28(0x8)
	struct UCustomWeaponState_C* K2Node_DynamicCast_AsCustom_Weapon_State;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x38(0x1)
	char pad_57_1 : 7;  // 0x39(0x1)
	bool CallFunc_SaveGameToSlot_ReturnValue : 1;  // 0x39(0x1)
	char pad_58_1 : 7;  // 0x3A(0x1)
	bool CallFunc_DoesSaveGameExist_ReturnValue_2 : 1;  // 0x3A(0x1)
	char pad_59[5];  // 0x3B(0x5)
	struct USaveGame* CallFunc_LoadGameFromSlot_ReturnValue_2;  // 0x40(0x8)
	struct UCustomWeaponState_C* K2Node_DynamicCast_AsCustom_Weapon_State_2;  // 0x48(0x8)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x50(0x1)
	char WeaponType K2Node_CustomEvent_WeaponType_3;  // 0x51(0x1)
	char Optics_Enum K2Node_CustomEvent_OpticsType;  // 0x52(0x1)
	char pad_83_1 : 7;  // 0x53(0x1)
	bool K2Node_SwitchEnum_CmpSuccess_2 : 1;  // 0x53(0x1)
	char pad_84_1 : 7;  // 0x54(0x1)
	bool CallFunc_SetStaticMesh_ReturnValue : 1;  // 0x54(0x1)
	char pad_85_1 : 7;  // 0x55(0x1)
	bool CallFunc_SetStaticMesh_ReturnValue_2 : 1;  // 0x55(0x1)
	char pad_86[2];  // 0x56(0x2)
	int32_t CallFunc_Conv_ByteToInt_ReturnValue;  // 0x58(0x4)
	char pad_92_1 : 7;  // 0x5C(0x1)
	bool K2Node_SwitchEnum_CmpSuccess_3 : 1;  // 0x5C(0x1)
	char WeaponType K2Node_CustomEvent_WeaponType_2;  // 0x5D(0x1)
	char MuzzleType CallFunc_Array_Get_Item;  // 0x5E(0x1)
	char pad_95_1 : 7;  // 0x5F(0x1)
	bool CallFunc_SetStaticMesh_ReturnValue_3 : 1;  // 0x5F(0x1)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool K2Node_SwitchEnum_CmpSuccess_4 : 1;  // 0x60(0x1)
	char MuzzleType K2Node_CustomEvent_MuzzleType;  // 0x61(0x1)
	char WeaponType K2Node_CustomEvent_WeaponType;  // 0x62(0x1)
	char pad_99_1 : 7;  // 0x63(0x1)
	bool K2Node_SwitchEnum_CmpSuccess_5 : 1;  // 0x63(0x1)
	char pad_100[4];  // 0x64(0x4)
	struct TArray<char Optics_Enum> K2Node_MakeArray_Array_2;  // 0x68(0x10)

}; 
// Function CustomWeapon_BP.CustomWeapon_BP_C.
// Size: 0x72(Inherited: 0x0) 
struct F
{
	struct FTransform ___struct_Variable;  // 0x0(0x30)
	struct FTransform ___struct_Variable_2;  // 0x30(0x30)
	struct USkeletalMeshComponent* CallFunc_AddComponent_ReturnValue;  // 0x60(0x8)
	struct USkeletalMeshComponent* CallFunc_AddComponent_ReturnValue_2;  // 0x68(0x8)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool CallFunc_K2_AttachToComponent_ReturnValue : 1;  // 0x70(0x1)
	char pad_113_1 : 7;  // 0x71(0x1)
	bool CallFunc_K2_AttachToComponent_ReturnValue_2 : 1;  // 0x71(0x1)

}; 
