#include "SDK.h" 
 
 
void AActor::(struct USoundBase* NewSound){

	static UObject* p_ = UObject::FindObject<UFunction>("Function ..");

	struct {
		struct USoundBase* NewSound;
	} parms;

	parms.NewSound = NewSound;

	ProcessEvent(p_, &parms);
}

void AActor::(int32_t EntryPoint){

	static UObject* p_ = UObject::FindObject<UFunction>("Function ..");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_, &parms);
}

