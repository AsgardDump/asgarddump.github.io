#include "SDK.h" 
 
 
void UAnimInstance::AnimGraph(struct FPoseLink& AnimGraph){

	static UObject* p_AnimGraph = UObject::FindObject<UFunction>("Function CharacterSelectAnim.CharacterSelectAnim_C.AnimGraph");

	struct {
		struct FPoseLink& AnimGraph;
	} parms;

	parms.AnimGraph = AnimGraph;

	ProcessEvent(p_AnimGraph, &parms);
}

void UAnimInstance::ExecuteUbergraph_CharacterSelectAnim(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph_CharacterSelectAnim = UObject::FindObject<UFunction>("Function CharacterSelectAnim.CharacterSelectAnim_C.ExecuteUbergraph_CharacterSelectAnim");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph_CharacterSelectAnim, &parms);
}

