#pragma once 
#include <jog_CameraShake_Structs.h>
 
 
 
// BlueprintGeneratedClass jog_CameraShake.jog_CameraShake_C
// Size: 0x1B0(Inherited: 0x1B0) 
struct Ujog_CameraShake_C : public UMatineeCameraShake
{

}; 



