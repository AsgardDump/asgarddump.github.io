#include "SDK.h" 
 
 
void AActor::(){

	static UObject* p_ = UObject::FindObject<UFunction>("Function CustomWeapon_BP.CustomWeapon_BP_C.");

	struct {
	} parms;


	ProcessEvent(p_, &parms);
}

void AActor::(){

	static UObject* p_ = UObject::FindObject<UFunction>("Function CustomWeapon_BP.CustomWeapon_BP_C.");

	struct {
	} parms;


	ProcessEvent(p_, &parms);
}

void AActor::(){

	static UObject* p_ = UObject::FindObject<UFunction>("Function CustomWeapon_BP.CustomWeapon_BP_C.");

	struct {
	} parms;


	ProcessEvent(p_, &parms);
}

void AActor::ReceiveBeginPlay(){

	static UObject* p_ReceiveBeginPlay = UObject::FindObject<UFunction>("Function CustomWeapon_BP.CustomWeapon_BP_C.ReceiveBeginPlay");

	struct {
	} parms;


	ProcessEvent(p_ReceiveBeginPlay, &parms);
}

void AActor::(char WeaponType WeaponType, char Optics_Enum OpticsType){

	static UObject* p_ = UObject::FindObject<UFunction>("Function CustomWeapon_BP.CustomWeapon_BP_C.");

	struct {
		char WeaponType WeaponType;
		char Optics_Enum OpticsType;
	} parms;

	parms.WeaponType = WeaponType;
	parms.OpticsType = OpticsType;

	ProcessEvent(p_, &parms);
}

void AActor::(char WeaponType WeaponType){

	static UObject* p_ = UObject::FindObject<UFunction>("Function CustomWeapon_BP.CustomWeapon_BP_C.");

	struct {
		char WeaponType WeaponType;
	} parms;

	parms.WeaponType = WeaponType;

	ProcessEvent(p_, &parms);
}

void AActor::(char MuzzleType MuzzleType, char WeaponType WeaponType){

	static UObject* p_ = UObject::FindObject<UFunction>("Function CustomWeapon_BP.CustomWeapon_BP_C.");

	struct {
		char MuzzleType MuzzleType;
		char WeaponType WeaponType;
	} parms;

	parms.MuzzleType = MuzzleType;
	parms.WeaponType = WeaponType;

	ProcessEvent(p_, &parms);
}

void AActor::(){

	static UObject* p_ = UObject::FindObject<UFunction>("Function CustomWeapon_BP.CustomWeapon_BP_C.");

	struct {
	} parms;


	ProcessEvent(p_, &parms);
}

void AActor::ExecuteUbergraph_CustomWeapon_BP(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph_CustomWeapon_BP = UObject::FindObject<UFunction>("Function CustomWeapon_BP.CustomWeapon_BP_C.ExecuteUbergraph_CustomWeapon_BP");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph_CustomWeapon_BP, &parms);
}

