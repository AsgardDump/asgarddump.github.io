#pragma once 
#include <Fail_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass Fail.Fail_C
// Size: 0x2E0(Inherited: 0x260) 
struct UFail_C : public UUserWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x260(0x8)
	struct UWidgetAnimation* Appear;  // 0x268(0x8)
	struct UTextBlock* TextBlock;  // 0x270(0x8)
	struct UTextBlock* TextBlock_2;  // 0x278(0x8)
	struct UTextBlock* TextBlock_4;  // 0x280(0x8)
	struct UTextBlock* TextBlock_5;  // 0x288(0x8)
	struct UTextBlock* TextBlock_8;  // 0x290(0x8)
	struct UTextBlock* TextBlock_236;  // 0x298(0x8)
	struct UTextBlock* ;  // 0x2A0(0x8)
	struct UTextBlock* ;  // 0x2A8(0x8)
	struct UTextBlock* ;  // 0x2B0(0x8)
	struct UTextBlock* ;  // 0x2B8(0x8)
	struct UTextBlock* ;  // 0x2C0(0x8)
	struct U* ;  // 0x2C8(0x8)
	struct U* _2;  // 0x2D0(0x8)
	struct APlayer_BP_C* As Player BP;  // 0x2D8(0x8)

	uint8_t  GetVisibility_1(); // Function Fail.Fail_C.GetVisibility_1
	void Construct(); // Function Fail.Fail_C.Construct
	void ReStart(); // Function Fail.Fail_C.ReStart
	void quit(); // Function Fail.Fail_C.quit
	void ExecuteUbergraph_Fail(int32_t EntryPoint); // Function Fail.Fail_C.ExecuteUbergraph_Fail
}; 



