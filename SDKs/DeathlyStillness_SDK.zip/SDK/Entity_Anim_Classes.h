#pragma once 
#include <Entity_Anim_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass Entity_Anim.Entity_Anim_C
// Size: 0x1274(Inherited: 0x2C0) 
struct UEntity_Anim_C : public UAnimInstance
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x2C0(0x8)
	struct FAnimNode_Root AnimGraphNode_Root;  // 0x2C8(0x30)
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool_3;  // 0x2F8(0xA0)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_2;  // 0x398(0x80)
	struct FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer;  // 0x418(0xE8)
	struct FAnimNode_StateResult AnimGraphNode_StateResult;  // 0x500(0x30)
	struct FAnimNode_StateMachine AnimGraphNode_StateMachine;  // 0x530(0xB0)
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose_2;  // 0x5E0(0x158)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer;  // 0x738(0x80)
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool_2;  // 0x7B8(0xA0)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_4;  // 0x858(0x28)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_3;  // 0x880(0x28)
	struct FAnimNode_Slot AnimGraphNode_Slot;  // 0x8A8(0x48)
	struct FAnimNode_LayeredBoneBlend AnimGraphNode_LayeredBoneBlend;  // 0x8F0(0xC0)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_6;  // 0x9B0(0x108)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace;  // 0xAB8(0x20)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace;  // 0xAD8(0x20)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_5;  // 0xAF8(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_4;  // 0xC00(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_3;  // 0xD08(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_2;  // 0xE10(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone;  // 0xF18(0x108)
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose;  // 0x1020(0x158)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_2;  // 0x1178(0x28)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose;  // 0x11A0(0x28)
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool;  // 0x11C8(0xA0)
	float Speed;  // 0x1268(0x4)
	char pad_4716_1 : 7;  // 0x126C(0x1)
	bool  : 1;  // 0x126C(0x1)
	char pad_4717_1 : 7;  // 0x126D(0x1)
	bool Crouch? : 1;  // 0x126D(0x1)
	char pad_4718[2];  // 0x126E(0x2)
	float ;  // 0x1270(0x4)

	void AnimGraph(struct FPoseLink& AnimGraph); // Function Entity_Anim.Entity_Anim_C.AnimGraph
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Entity_Anim_AnimGraphNode_BlendListByBool_2EFF006A47A63720EAD32FB2FB8061E9(); // Function Entity_Anim.Entity_Anim_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Entity_Anim_AnimGraphNode_BlendListByBool_2EFF006A47A63720EAD32FB2FB8061E9
	void BlueprintUpdateAnimation(float DeltaTimeX); // Function Entity_Anim.Entity_Anim_C.BlueprintUpdateAnimation
	void ExecuteUbergraph_Entity_Anim(int32_t EntryPoint); // Function Entity_Anim.Entity_Anim_C.ExecuteUbergraph_Entity_Anim
}; 



