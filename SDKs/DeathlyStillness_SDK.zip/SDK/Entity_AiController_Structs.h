#pragma once 
#include "SDK.h" 
 
 
// Function Entity_AiController.Entity_AiController_C.ExecuteUbergraph_Entity_AiController
// Size: 0xD0(Inherited: 0x0) 
struct FExecuteUbergraph_Entity_AiController
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UBlackboardComponent* CallFunc_GetBlackboard_ReturnValue;  // 0x8(0x8)
	struct AActor* K2Node_ComponentBoundEvent_Actor;  // 0x10(0x8)
	struct FAIStimulus K2Node_ComponentBoundEvent_Stimulus;  // 0x18(0x3C)
	char pad_84[4];  // 0x54(0x4)
	struct UBlackboardComponent* CallFunc_GetBlackboard_ReturnValue_2;  // 0x58(0x8)
	struct APlayer_BP_C* K2Node_DynamicCast_AsPlayer_BP;  // 0x60(0x8)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x68(0x1)
	char pad_105_1 : 7;  // 0x69(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // 0x69(0x1)
	char pad_106_1 : 7;  // 0x6A(0x1)
	bool CallFunc_EqualEqual_NameName_ReturnValue : 1;  // 0x6A(0x1)
	char pad_107[1];  // 0x6B(0x1)
	struct FName CallFunc_MakeLiteralName_ReturnValue;  // 0x6C(0x8)
	char pad_116[4];  // 0x74(0x4)
	struct APawn* K2Node_Event_PossessedPawn;  // 0x78(0x8)
	char pad_128_1 : 7;  // 0x80(0x1)
	bool CallFunc_RunBehaviorTree_ReturnValue : 1;  // 0x80(0x1)
	char pad_129[3];  // 0x81(0x3)
	struct FName CallFunc_MakeLiteralName_ReturnValue_2;  // 0x84(0x8)
	char pad_140[4];  // 0x8C(0x4)
	struct UBlackboardComponent* CallFunc_GetBlackboard_ReturnValue_3;  // 0x90(0x8)
	char pad_152_1 : 7;  // 0x98(0x1)
	bool ___bool_Has_Been_Initd_Variable : 1;  // 0x98(0x1)
	char pad_153_1 : 7;  // 0x99(0x1)
	bool ___bool_IsClosed_Variable : 1;  // 0x99(0x1)
	char pad_154[6];  // 0x9A(0x6)
	struct APawn* CallFunc_GetPlayerPawn_ReturnValue;  // 0xA0(0x8)
	struct FName CallFunc_MakeLiteralName_ReturnValue_3;  // 0xA8(0x8)
	struct APlayer_BP_C* K2Node_DynamicCast_AsPlayer_BP_2;  // 0xB0(0x8)
	char pad_184_1 : 7;  // 0xB8(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0xB8(0x1)
	char pad_185[7];  // 0xB9(0x7)
	struct UBlackboardComponent* CallFunc_GetBlackboard_ReturnValue_4;  // 0xC0(0x8)
	struct FName CallFunc_MakeLiteralName_ReturnValue_4;  // 0xC8(0x8)

}; 
// Function Entity_AiController.Entity_AiController_C.ReceivePossess
// Size: 0x8(Inherited: 0x8) 
struct FReceivePossess : public FReceivePossess
{
	struct APawn* PossessedPawn;  // 0x0(0x8)

}; 
// Function Entity_AiController.Entity_AiController_C.BndEvt__AIPerception_K2Node_ComponentBoundEvent_1_ActorPerceptionUpdatedDelegate__DelegateSignature
// Size: 0x44(Inherited: 0x0) 
struct FBndEvt__AIPerception_K2Node_ComponentBoundEvent_1_ActorPerceptionUpdatedDelegate__DelegateSignature
{
	struct AActor* Actor;  // 0x0(0x8)
	struct FAIStimulus Stimulus;  // 0x8(0x3C)

}; 
