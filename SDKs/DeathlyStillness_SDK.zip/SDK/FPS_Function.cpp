#include "SDK.h" 
 
 
void UUserWidget::Tick(struct FGeometry MyGeometry, float InDeltaTime){

	static UObject* p_Tick = UObject::FindObject<UFunction>("Function FPS.FPS_C.Tick");

	struct {
		struct FGeometry MyGeometry;
		float InDeltaTime;
	} parms;

	parms.MyGeometry = MyGeometry;
	parms.InDeltaTime = InDeltaTime;

	ProcessEvent(p_Tick, &parms);
}

void UUserWidget::ExecuteUbergraph_FPS(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph_FPS = UObject::FindObject<UFunction>("Function FPS.FPS_C.ExecuteUbergraph_FPS");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph_FPS, &parms);
}

