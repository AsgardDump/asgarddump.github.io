#include "SDK.h" 
 
 
void AActor::ReceiveHit(struct UPrimitiveComponent* bpp__MyComp__pf, struct AActor* bpp__Other__pf, struct UPrimitiveComponent* bpp__OtherComp__pf, bool bpp__bSelfMoved__pf, struct FVector bpp__HitLocation__pf, struct FVector bpp__HitNormal__pf, struct FVector bpp__NormalImpulse__pf, struct FHitResult& bpp__Hit__pf__const){

	static UObject* p_ReceiveHit = UObject::FindObject<UFunction>("Function AIBulletMaster_BP.AIBulletMaster_BP_C.ReceiveHit");

	struct {
		struct UPrimitiveComponent* bpp__MyComp__pf;
		struct AActor* bpp__Other__pf;
		struct UPrimitiveComponent* bpp__OtherComp__pf;
		bool bpp__bSelfMoved__pf;
		struct FVector bpp__HitLocation__pf;
		struct FVector bpp__HitNormal__pf;
		struct FVector bpp__NormalImpulse__pf;
		struct FHitResult& bpp__Hit__pf__const;
	} parms;

	parms.bpp__MyComp__pf = bpp__MyComp__pf;
	parms.bpp__Other__pf = bpp__Other__pf;
	parms.bpp__OtherComp__pf = bpp__OtherComp__pf;
	parms.bpp__bSelfMoved__pf = bpp__bSelfMoved__pf;
	parms.bpp__HitLocation__pf = bpp__HitLocation__pf;
	parms.bpp__HitNormal__pf = bpp__HitNormal__pf;
	parms.bpp__NormalImpulse__pf = bpp__NormalImpulse__pf;
	parms.bpp__Hit__pf__const = bpp__Hit__pf__const;

	ProcessEvent(p_ReceiveHit, &parms);
}

void AActor::ReceiveBeginPlay(){

	static UObject* p_ReceiveBeginPlay = UObject::FindObject<UFunction>("Function AIBulletMaster_BP.AIBulletMaster_BP_C.ReceiveBeginPlay");

	struct {
	} parms;


	ProcessEvent(p_ReceiveBeginPlay, &parms);
}

void AActor::ExecuteUbergraph_AIBulletMaster_BP_2(int32_t bpp__EntryPoint__pf){

	static UObject* p_ExecuteUbergraph_AIBulletMaster_BP_2 = UObject::FindObject<UFunction>("Function AIBulletMaster_BP.AIBulletMaster_BP_C.ExecuteUbergraph_AIBulletMaster_BP_2");

	struct {
		int32_t bpp__EntryPoint__pf;
	} parms;

	parms.bpp__EntryPoint__pf = bpp__EntryPoint__pf;

	ProcessEvent(p_ExecuteUbergraph_AIBulletMaster_BP_2, &parms);
}

