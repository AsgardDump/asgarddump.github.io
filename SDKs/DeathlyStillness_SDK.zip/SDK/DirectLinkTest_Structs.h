#pragma once 
#include "SDK.h" 
 
 
// Function DirectLinkTest.DirectLinkTestLibrary.DeleteEndpoint
// Size: 0x8(Inherited: 0x0) 
struct FDeleteEndpoint
{
	int32_t EndpointId;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool ReturnValue : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)

}; 
// Function DirectLinkTest.DirectLinkTestLibrary.AddPublicDestination
// Size: 0x20(Inherited: 0x0) 
struct FAddPublicDestination
{
	int32_t EndpointId;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FString DestName;  // 0x8(0x10)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool ReturnValue : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)

}; 
// Function DirectLinkTest.DirectLinkTestLibrary.StopReceiver
// Size: 0x1(Inherited: 0x0) 
struct FStopReceiver
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function DirectLinkTest.DirectLinkTestLibrary.DumpReceivedScene
// Size: 0x1(Inherited: 0x0) 
struct FDumpReceivedScene
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function DirectLinkTest.DirectLinkTestLibrary.DeleteAllEndpoint
// Size: 0x1(Inherited: 0x0) 
struct FDeleteAllEndpoint
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function DirectLinkTest.DirectLinkTestLibrary.AddPublicSource
// Size: 0x20(Inherited: 0x0) 
struct FAddPublicSource
{
	int32_t EndpointId;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FString SourceName;  // 0x8(0x10)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool ReturnValue : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)

}; 
// Function DirectLinkTest.DirectLinkTestLibrary.MakeEndpoint
// Size: 0x18(Inherited: 0x0) 
struct FMakeEndpoint
{
	struct FString NiceName;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bVerbose : 1;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)
	int32_t ReturnValue;  // 0x14(0x4)

}; 
// Function DirectLinkTest.DirectLinkTestLibrary.SendScene
// Size: 0x18(Inherited: 0x0) 
struct FSendScene
{
	struct FString InFilePath;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function DirectLinkTest.DirectLinkTestLibrary.SetupReceiver
// Size: 0x1(Inherited: 0x0) 
struct FSetupReceiver
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function DirectLinkTest.DirectLinkTestLibrary.SetupSender
// Size: 0x1(Inherited: 0x0) 
struct FSetupSender
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function DirectLinkTest.DirectLinkTestLibrary.StartSender
// Size: 0x1(Inherited: 0x0) 
struct FStartSender
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function DirectLinkTest.DirectLinkTestLibrary.StartReceiver
// Size: 0x1(Inherited: 0x0) 
struct FStartReceiver
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function DirectLinkTest.DirectLinkTestLibrary.StopSender
// Size: 0x1(Inherited: 0x0) 
struct FStopSender
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function DirectLinkTest.DirectLinkTestLibrary.TestParameters
// Size: 0x1(Inherited: 0x0) 
struct FTestParameters
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
