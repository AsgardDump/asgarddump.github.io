#include "SDK.h" 
 
 
void AActor::RefreshMaterial(){

	static UObject* p_RefreshMaterial = UObject::FindObject<UFunction>("Function BP_Sky_Sphere.BP_Sky_Sphere_C.RefreshMaterial");

	struct {
	} parms;


	ProcessEvent(p_RefreshMaterial, &parms);
}

void AActor::UpdateSunDirection(){

	static UObject* p_UpdateSunDirection = UObject::FindObject<UFunction>("Function BP_Sky_Sphere.BP_Sky_Sphere_C.UpdateSunDirection");

	struct {
	} parms;


	ProcessEvent(p_UpdateSunDirection, &parms);
}

void AActor::UserConstructionScript(){

	static UObject* p_UserConstructionScript = UObject::FindObject<UFunction>("Function BP_Sky_Sphere.BP_Sky_Sphere_C.UserConstructionScript");

	struct {
	} parms;


	ProcessEvent(p_UserConstructionScript, &parms);
}

