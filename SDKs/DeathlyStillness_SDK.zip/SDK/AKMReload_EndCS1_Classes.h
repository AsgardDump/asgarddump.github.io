#pragma once 
#include <AKMReload_EndCS1_Structs.h>
 
 
 
// BlueprintGeneratedClass AKMReload_EndCS1.AKMReload_EndCS1_C
// Size: 0x1B0(Inherited: 0x1B0) 
struct UAKMReload_EndCS1_C : public UMatineeCameraShake
{

}; 



