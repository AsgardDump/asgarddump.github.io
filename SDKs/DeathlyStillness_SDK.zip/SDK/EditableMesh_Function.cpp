#include "SDK.h" 
 
 
struct UEditableMesh* UObject::MakeEditableMesh(struct UPrimitiveComponent* PrimitiveComponent, int32_t LODIndex){

	static UObject* p_MakeEditableMesh = UObject::FindObject<UFunction>("Function EditableMesh.EditableMeshFactory.MakeEditableMesh");

	struct {
		struct UPrimitiveComponent* PrimitiveComponent;
		int32_t LODIndex;
		struct UEditableMesh* return_value;
	} parms;

	parms.PrimitiveComponent = PrimitiveComponent;
	parms.LODIndex = LODIndex;

	ProcessEvent(p_MakeEditableMesh, &parms);
	return parms.return_value;
}

void UObject::WeldVertices(struct TArray<struct FVertexID>& VertexIDs, struct FVertexID& OutNewVertexID){

	static UObject* p_WeldVertices = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.WeldVertices");

	struct {
		struct TArray<struct FVertexID>& VertexIDs;
		struct FVertexID& OutNewVertexID;
	} parms;

	parms.VertexIDs = VertexIDs;
	parms.OutNewVertexID = OutNewVertexID;

	ProcessEvent(p_WeldVertices, &parms);
}

void UObject::TryToRemoveVertex(struct FVertexID VertexID, bool& bOutWasVertexRemoved, struct FEdgeID& OutNewEdgeID){

	static UObject* p_TryToRemoveVertex = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.TryToRemoveVertex");

	struct {
		struct FVertexID VertexID;
		bool& bOutWasVertexRemoved;
		struct FEdgeID& OutNewEdgeID;
	} parms;

	parms.VertexID = VertexID;
	parms.bOutWasVertexRemoved = bOutWasVertexRemoved;
	parms.OutNewEdgeID = OutNewEdgeID;

	ProcessEvent(p_TryToRemoveVertex, &parms);
}

void UObject::TryToRemovePolygonEdge(struct FEdgeID EdgeID, bool& bOutWasEdgeRemoved, struct FPolygonID& OutNewPolygonID){

	static UObject* p_TryToRemovePolygonEdge = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.TryToRemovePolygonEdge");

	struct {
		struct FEdgeID EdgeID;
		bool& bOutWasEdgeRemoved;
		struct FPolygonID& OutNewPolygonID;
	} parms;

	parms.EdgeID = EdgeID;
	parms.bOutWasEdgeRemoved = bOutWasEdgeRemoved;
	parms.OutNewPolygonID = OutNewPolygonID;

	ProcessEvent(p_TryToRemovePolygonEdge, &parms);
}

void UObject::TriangulatePolygons(struct TArray<struct FPolygonID>& PolygonIDs, struct TArray<struct FPolygonID>& OutNewTrianglePolygons){

	static UObject* p_TriangulatePolygons = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.TriangulatePolygons");

	struct {
		struct TArray<struct FPolygonID>& PolygonIDs;
		struct TArray<struct FPolygonID>& OutNewTrianglePolygons;
	} parms;

	parms.PolygonIDs = PolygonIDs;
	parms.OutNewTrianglePolygons = OutNewTrianglePolygons;

	ProcessEvent(p_TriangulatePolygons, &parms);
}

void UObject::TessellatePolygons(struct TArray<struct FPolygonID>& PolygonIDs, uint8_t  TriangleTessellationMode, struct TArray<struct FPolygonID>& OutNewPolygonIDs){

	static UObject* p_TessellatePolygons = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.TessellatePolygons");

	struct {
		struct TArray<struct FPolygonID>& PolygonIDs;
		uint8_t  TriangleTessellationMode;
		struct TArray<struct FPolygonID>& OutNewPolygonIDs;
	} parms;

	parms.PolygonIDs = PolygonIDs;
	parms.TriangleTessellationMode = TriangleTessellationMode;
	parms.OutNewPolygonIDs = OutNewPolygonIDs;

	ProcessEvent(p_TessellatePolygons, &parms);
}

void UObject::StartModification(uint8_t  MeshModificationType, uint8_t  MeshTopologyChange){

	static UObject* p_StartModification = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.StartModification");

	struct {
		uint8_t  MeshModificationType;
		uint8_t  MeshTopologyChange;
	} parms;

	parms.MeshModificationType = MeshModificationType;
	parms.MeshTopologyChange = MeshTopologyChange;

	ProcessEvent(p_StartModification, &parms);
}

void UObject::SplitPolygons(struct TArray<struct FPolygonToSplit>& PolygonsToSplit, struct TArray<struct FEdgeID>& OutNewEdgeIDs){

	static UObject* p_SplitPolygons = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.SplitPolygons");

	struct {
		struct TArray<struct FPolygonToSplit>& PolygonsToSplit;
		struct TArray<struct FEdgeID>& OutNewEdgeIDs;
	} parms;

	parms.PolygonsToSplit = PolygonsToSplit;
	parms.OutNewEdgeIDs = OutNewEdgeIDs;

	ProcessEvent(p_SplitPolygons, &parms);
}

void UObject::SplitPolygonalMesh(struct FPlane& InPlane, struct TArray<struct FPolygonID>& PolygonIDs1, struct TArray<struct FPolygonID>& PolygonIDs2, struct TArray<struct FEdgeID>& BoundaryIDs){

	static UObject* p_SplitPolygonalMesh = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.SplitPolygonalMesh");

	struct {
		struct FPlane& InPlane;
		struct TArray<struct FPolygonID>& PolygonIDs1;
		struct TArray<struct FPolygonID>& PolygonIDs2;
		struct TArray<struct FEdgeID>& BoundaryIDs;
	} parms;

	parms.InPlane = InPlane;
	parms.PolygonIDs1 = PolygonIDs1;
	parms.PolygonIDs2 = PolygonIDs2;
	parms.BoundaryIDs = BoundaryIDs;

	ProcessEvent(p_SplitPolygonalMesh, &parms);
}

void UObject::SplitEdge(struct FEdgeID EdgeID, struct TArray<float>& Splits, struct TArray<struct FVertexID>& OutNewVertexIDs){

	static UObject* p_SplitEdge = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.SplitEdge");

	struct {
		struct FEdgeID EdgeID;
		struct TArray<float>& Splits;
		struct TArray<struct FVertexID>& OutNewVertexIDs;
	} parms;

	parms.EdgeID = EdgeID;
	parms.Splits = Splits;
	parms.OutNewVertexIDs = OutNewVertexIDs;

	ProcessEvent(p_SplitEdge, &parms);
}

void UObject::SetVerticesCornerSharpness(struct TArray<struct FVertexID>& VertexIDs, struct TArray<float>& VerticesNewCornerSharpness){

	static UObject* p_SetVerticesCornerSharpness = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.SetVerticesCornerSharpness");

	struct {
		struct TArray<struct FVertexID>& VertexIDs;
		struct TArray<float>& VerticesNewCornerSharpness;
	} parms;

	parms.VertexIDs = VertexIDs;
	parms.VerticesNewCornerSharpness = VerticesNewCornerSharpness;

	ProcessEvent(p_SetVerticesCornerSharpness, &parms);
}

void UObject::SetVerticesAttributes(struct TArray<struct FAttributesForVertex>& AttributesForVertices){

	static UObject* p_SetVerticesAttributes = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.SetVerticesAttributes");

	struct {
		struct TArray<struct FAttributesForVertex>& AttributesForVertices;
	} parms;

	parms.AttributesForVertices = AttributesForVertices;

	ProcessEvent(p_SetVerticesAttributes, &parms);
}

void UObject::SetVertexInstancesAttributes(struct TArray<struct FAttributesForVertexInstance>& AttributesForVertexInstances){

	static UObject* p_SetVertexInstancesAttributes = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.SetVertexInstancesAttributes");

	struct {
		struct TArray<struct FAttributesForVertexInstance>& AttributesForVertexInstances;
	} parms;

	parms.AttributesForVertexInstances = AttributesForVertexInstances;

	ProcessEvent(p_SetVertexInstancesAttributes, &parms);
}

void UObject::SetTextureCoordinateCount(int32_t NumTexCoords){

	static UObject* p_SetTextureCoordinateCount = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.SetTextureCoordinateCount");

	struct {
		int32_t NumTexCoords;
	} parms;

	parms.NumTexCoords = NumTexCoords;

	ProcessEvent(p_SetTextureCoordinateCount, &parms);
}

void UObject::SetSubdivisionCount(int32_t NewSubdivisionCount){

	static UObject* p_SetSubdivisionCount = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.SetSubdivisionCount");

	struct {
		int32_t NewSubdivisionCount;
	} parms;

	parms.NewSubdivisionCount = NewSubdivisionCount;

	ProcessEvent(p_SetSubdivisionCount, &parms);
}

void UObject::SetPolygonsVertexAttributes(struct TArray<struct FVertexAttributesForPolygon>& VertexAttributesForPolygons){

	static UObject* p_SetPolygonsVertexAttributes = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.SetPolygonsVertexAttributes");

	struct {
		struct TArray<struct FVertexAttributesForPolygon>& VertexAttributesForPolygons;
	} parms;

	parms.VertexAttributesForPolygons = VertexAttributesForPolygons;

	ProcessEvent(p_SetPolygonsVertexAttributes, &parms);
}

void UObject::SetEdgesHardnessAutomatically(struct TArray<struct FEdgeID>& EdgeIDs, float MaxDotProductForSoftEdge){

	static UObject* p_SetEdgesHardnessAutomatically = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.SetEdgesHardnessAutomatically");

	struct {
		struct TArray<struct FEdgeID>& EdgeIDs;
		float MaxDotProductForSoftEdge;
	} parms;

	parms.EdgeIDs = EdgeIDs;
	parms.MaxDotProductForSoftEdge = MaxDotProductForSoftEdge;

	ProcessEvent(p_SetEdgesHardnessAutomatically, &parms);
}

void UObject::SetEdgesHardness(struct TArray<struct FEdgeID>& EdgeIDs, struct TArray<bool>& EdgesNewIsHard){

	static UObject* p_SetEdgesHardness = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.SetEdgesHardness");

	struct {
		struct TArray<struct FEdgeID>& EdgeIDs;
		struct TArray<bool>& EdgesNewIsHard;
	} parms;

	parms.EdgeIDs = EdgeIDs;
	parms.EdgesNewIsHard = EdgesNewIsHard;

	ProcessEvent(p_SetEdgesHardness, &parms);
}

void UObject::SetEdgesCreaseSharpness(struct TArray<struct FEdgeID>& EdgeIDs, struct TArray<float>& EdgesNewCreaseSharpness){

	static UObject* p_SetEdgesCreaseSharpness = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.SetEdgesCreaseSharpness");

	struct {
		struct TArray<struct FEdgeID>& EdgeIDs;
		struct TArray<float>& EdgesNewCreaseSharpness;
	} parms;

	parms.EdgeIDs = EdgeIDs;
	parms.EdgesNewCreaseSharpness = EdgesNewCreaseSharpness;

	ProcessEvent(p_SetEdgesCreaseSharpness, &parms);
}

void UObject::SetEdgesAttributes(struct TArray<struct FAttributesForEdge>& AttributesForEdges){

	static UObject* p_SetEdgesAttributes = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.SetEdgesAttributes");

	struct {
		struct TArray<struct FAttributesForEdge>& AttributesForEdges;
	} parms;

	parms.AttributesForEdges = AttributesForEdges;

	ProcessEvent(p_SetEdgesAttributes, &parms);
}

void UObject::SetAllowUndo(bool bInAllowUndo){

	static UObject* p_SetAllowUndo = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.SetAllowUndo");

	struct {
		bool bInAllowUndo;
	} parms;

	parms.bInAllowUndo = bInAllowUndo;

	ProcessEvent(p_SetAllowUndo, &parms);
}

void UObject::SetAllowSpatialDatabase(bool bInAllowSpatialDatabase){

	static UObject* p_SetAllowSpatialDatabase = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.SetAllowSpatialDatabase");

	struct {
		bool bInAllowSpatialDatabase;
	} parms;

	parms.bInAllowSpatialDatabase = bInAllowSpatialDatabase;

	ProcessEvent(p_SetAllowSpatialDatabase, &parms);
}

void UObject::SetAllowCompact(bool bInAllowCompact){

	static UObject* p_SetAllowCompact = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.SetAllowCompact");

	struct {
		bool bInAllowCompact;
	} parms;

	parms.bInAllowCompact = bInAllowCompact;

	ProcessEvent(p_SetAllowCompact, &parms);
}

void UObject::SearchSpatialDatabaseForPolygonsPotentiallyIntersectingPlane(struct FPlane& InPlane, struct TArray<struct FPolygonID>& OutPolygons){

	static UObject* p_SearchSpatialDatabaseForPolygonsPotentiallyIntersectingPlane = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.SearchSpatialDatabaseForPolygonsPotentiallyIntersectingPlane");

	struct {
		struct FPlane& InPlane;
		struct TArray<struct FPolygonID>& OutPolygons;
	} parms;

	parms.InPlane = InPlane;
	parms.OutPolygons = OutPolygons;

	ProcessEvent(p_SearchSpatialDatabaseForPolygonsPotentiallyIntersectingPlane, &parms);
}

void UObject::SearchSpatialDatabaseForPolygonsPotentiallyIntersectingLineSegment(struct FVector LineSegmentStart, struct FVector LineSegmentEnd, struct TArray<struct FPolygonID>& OutPolygons){

	static UObject* p_SearchSpatialDatabaseForPolygonsPotentiallyIntersectingLineSegment = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.SearchSpatialDatabaseForPolygonsPotentiallyIntersectingLineSegment");

	struct {
		struct FVector LineSegmentStart;
		struct FVector LineSegmentEnd;
		struct TArray<struct FPolygonID>& OutPolygons;
	} parms;

	parms.LineSegmentStart = LineSegmentStart;
	parms.LineSegmentEnd = LineSegmentEnd;
	parms.OutPolygons = OutPolygons;

	ProcessEvent(p_SearchSpatialDatabaseForPolygonsPotentiallyIntersectingLineSegment, &parms);
}

void UObject::SearchSpatialDatabaseForPolygonsInVolume(struct TArray<struct FPlane>& Planes, struct TArray<struct FPolygonID>& OutPolygons){

	static UObject* p_SearchSpatialDatabaseForPolygonsInVolume = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.SearchSpatialDatabaseForPolygonsInVolume");

	struct {
		struct TArray<struct FPlane>& Planes;
		struct TArray<struct FPolygonID>& OutPolygons;
	} parms;

	parms.Planes = Planes;
	parms.OutPolygons = OutPolygons;

	ProcessEvent(p_SearchSpatialDatabaseForPolygonsInVolume, &parms);
}

struct UEditableMesh* UObject::RevertInstance(){

	static UObject* p_RevertInstance = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.RevertInstance");

	struct {
		struct UEditableMesh* return_value;
	} parms;


	ProcessEvent(p_RevertInstance, &parms);
	return parms.return_value;
}

void UObject::Revert(){

	static UObject* p_Revert = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.Revert");

	struct {
	} parms;


	ProcessEvent(p_Revert, &parms);
}

void UObject::RebuildRenderMesh(){

	static UObject* p_RebuildRenderMesh = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.RebuildRenderMesh");

	struct {
	} parms;


	ProcessEvent(p_RebuildRenderMesh, &parms);
}

void UObject::QuadrangulateMesh(struct TArray<struct FPolygonID>& OutNewPolygonIDs){

	static UObject* p_QuadrangulateMesh = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.QuadrangulateMesh");

	struct {
		struct TArray<struct FPolygonID>& OutNewPolygonIDs;
	} parms;

	parms.OutNewPolygonIDs = OutNewPolygonIDs;

	ProcessEvent(p_QuadrangulateMesh, &parms);
}

void UObject::PropagateInstanceChanges(){

	static UObject* p_PropagateInstanceChanges = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.PropagateInstanceChanges");

	struct {
	} parms;


	ProcessEvent(p_PropagateInstanceChanges, &parms);
}

void UObject::MoveVertices(struct TArray<struct FVertexToMove>& VerticesToMove){

	static UObject* p_MoveVertices = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.MoveVertices");

	struct {
		struct TArray<struct FVertexToMove>& VerticesToMove;
	} parms;

	parms.VerticesToMove = VerticesToMove;

	ProcessEvent(p_MoveVertices, &parms);
}

struct FVertexID UObject::MakeVertexID(int32_t VertexIndex){

	static UObject* p_MakeVertexID = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.MakeVertexID");

	struct {
		int32_t VertexIndex;
		struct FVertexID return_value;
	} parms;

	parms.VertexIndex = VertexIndex;

	ProcessEvent(p_MakeVertexID, &parms);
	return parms.return_value;
}

struct FPolygonID UObject::MakePolygonID(int32_t PolygonIndex){

	static UObject* p_MakePolygonID = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.MakePolygonID");

	struct {
		int32_t PolygonIndex;
		struct FPolygonID return_value;
	} parms;

	parms.PolygonIndex = PolygonIndex;

	ProcessEvent(p_MakePolygonID, &parms);
	return parms.return_value;
}

struct FPolygonGroupID UObject::MakePolygonGroupID(int32_t PolygonGroupIndex){

	static UObject* p_MakePolygonGroupID = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.MakePolygonGroupID");

	struct {
		int32_t PolygonGroupIndex;
		struct FPolygonGroupID return_value;
	} parms;

	parms.PolygonGroupIndex = PolygonGroupIndex;

	ProcessEvent(p_MakePolygonGroupID, &parms);
	return parms.return_value;
}

struct FEdgeID UObject::MakeEdgeID(int32_t EdgeIndex){

	static UObject* p_MakeEdgeID = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.MakeEdgeID");

	struct {
		int32_t EdgeIndex;
		struct FEdgeID return_value;
	} parms;

	parms.EdgeIndex = EdgeIndex;

	ProcessEvent(p_MakeEdgeID, &parms);
	return parms.return_value;
}

bool UObject::IsValidVertex(struct FVertexID VertexID){

	static UObject* p_IsValidVertex = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.IsValidVertex");

	struct {
		struct FVertexID VertexID;
		bool return_value;
	} parms;

	parms.VertexID = VertexID;

	ProcessEvent(p_IsValidVertex, &parms);
	return parms.return_value;
}

bool UObject::IsValidPolygonGroup(struct FPolygonGroupID PolygonGroupID){

	static UObject* p_IsValidPolygonGroup = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.IsValidPolygonGroup");

	struct {
		struct FPolygonGroupID PolygonGroupID;
		bool return_value;
	} parms;

	parms.PolygonGroupID = PolygonGroupID;

	ProcessEvent(p_IsValidPolygonGroup, &parms);
	return parms.return_value;
}

bool UObject::IsValidPolygon(struct FPolygonID PolygonID){

	static UObject* p_IsValidPolygon = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.IsValidPolygon");

	struct {
		struct FPolygonID PolygonID;
		bool return_value;
	} parms;

	parms.PolygonID = PolygonID;

	ProcessEvent(p_IsValidPolygon, &parms);
	return parms.return_value;
}

bool UObject::IsValidEdge(struct FEdgeID EdgeID){

	static UObject* p_IsValidEdge = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.IsValidEdge");

	struct {
		struct FEdgeID EdgeID;
		bool return_value;
	} parms;

	parms.EdgeID = EdgeID;

	ProcessEvent(p_IsValidEdge, &parms);
	return parms.return_value;
}

bool UObject::IsUndoAllowed(){

	static UObject* p_IsUndoAllowed = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.IsUndoAllowed");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_IsUndoAllowed, &parms);
	return parms.return_value;
}

bool UObject::IsSpatialDatabaseAllowed(){

	static UObject* p_IsSpatialDatabaseAllowed = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.IsSpatialDatabaseAllowed");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_IsSpatialDatabaseAllowed, &parms);
	return parms.return_value;
}

bool UObject::IsPreviewingSubdivisions(){

	static UObject* p_IsPreviewingSubdivisions = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.IsPreviewingSubdivisions");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_IsPreviewingSubdivisions, &parms);
	return parms.return_value;
}

bool UObject::IsOrphanedVertex(struct FVertexID VertexID){

	static UObject* p_IsOrphanedVertex = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.IsOrphanedVertex");

	struct {
		struct FVertexID VertexID;
		bool return_value;
	} parms;

	parms.VertexID = VertexID;

	ProcessEvent(p_IsOrphanedVertex, &parms);
	return parms.return_value;
}

bool UObject::IsCompactAllowed(){

	static UObject* p_IsCompactAllowed = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.IsCompactAllowed");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_IsCompactAllowed, &parms);
	return parms.return_value;
}

bool UObject::IsCommittedAsInstance(){

	static UObject* p_IsCommittedAsInstance = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.IsCommittedAsInstance");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_IsCommittedAsInstance, &parms);
	return parms.return_value;
}

bool UObject::IsCommitted(){

	static UObject* p_IsCommitted = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.IsCommitted");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_IsCommitted, &parms);
	return parms.return_value;
}

bool UObject::IsBeingModified(){

	static UObject* p_IsBeingModified = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.IsBeingModified");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_IsBeingModified, &parms);
	return parms.return_value;
}

struct FVertexID UObject::InvalidVertexID(){

	static UObject* p_InvalidVertexID = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.InvalidVertexID");

	struct {
		struct FVertexID return_value;
	} parms;


	ProcessEvent(p_InvalidVertexID, &parms);
	return parms.return_value;
}

struct FPolygonID UObject::InvalidPolygonID(){

	static UObject* p_InvalidPolygonID = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.InvalidPolygonID");

	struct {
		struct FPolygonID return_value;
	} parms;


	ProcessEvent(p_InvalidPolygonID, &parms);
	return parms.return_value;
}

struct FPolygonGroupID UObject::InvalidPolygonGroupID(){

	static UObject* p_InvalidPolygonGroupID = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.InvalidPolygonGroupID");

	struct {
		struct FPolygonGroupID return_value;
	} parms;


	ProcessEvent(p_InvalidPolygonGroupID, &parms);
	return parms.return_value;
}

struct FEdgeID UObject::InvalidEdgeID(){

	static UObject* p_InvalidEdgeID = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.InvalidEdgeID");

	struct {
		struct FEdgeID return_value;
	} parms;


	ProcessEvent(p_InvalidEdgeID, &parms);
	return parms.return_value;
}

void UObject::InsetPolygons(struct TArray<struct FPolygonID>& PolygonIDs, float InsetFixedDistance, float InsetProgressTowardCenter, uint8_t  Mode, struct TArray<struct FPolygonID>& OutNewCenterPolygonIDs, struct TArray<struct FPolygonID>& OutNewSidePolygonIDs){

	static UObject* p_InsetPolygons = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.InsetPolygons");

	struct {
		struct TArray<struct FPolygonID>& PolygonIDs;
		float InsetFixedDistance;
		float InsetProgressTowardCenter;
		uint8_t  Mode;
		struct TArray<struct FPolygonID>& OutNewCenterPolygonIDs;
		struct TArray<struct FPolygonID>& OutNewSidePolygonIDs;
	} parms;

	parms.PolygonIDs = PolygonIDs;
	parms.InsetFixedDistance = InsetFixedDistance;
	parms.InsetProgressTowardCenter = InsetProgressTowardCenter;
	parms.Mode = Mode;
	parms.OutNewCenterPolygonIDs = OutNewCenterPolygonIDs;
	parms.OutNewSidePolygonIDs = OutNewSidePolygonIDs;

	ProcessEvent(p_InsetPolygons, &parms);
}

void UObject::InsertEdgeLoop(struct FEdgeID EdgeID, struct TArray<float>& Splits, struct TArray<struct FEdgeID>& OutNewEdgeIDs){

	static UObject* p_InsertEdgeLoop = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.InsertEdgeLoop");

	struct {
		struct FEdgeID EdgeID;
		struct TArray<float>& Splits;
		struct TArray<struct FEdgeID>& OutNewEdgeIDs;
	} parms;

	parms.EdgeID = EdgeID;
	parms.Splits = Splits;
	parms.OutNewEdgeIDs = OutNewEdgeIDs;

	ProcessEvent(p_InsertEdgeLoop, &parms);
}

void UObject::InitializeAdapters(){

	static UObject* p_InitializeAdapters = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.InitializeAdapters");

	struct {
	} parms;


	ProcessEvent(p_InitializeAdapters, &parms);
}

struct FEdgeID UObject::GetVertexPairEdge(struct FVertexID VertexID, struct FVertexID NextVertexID, bool& bOutEdgeWindingIsReversed){

	static UObject* p_GetVertexPairEdge = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.GetVertexPairEdge");

	struct {
		struct FVertexID VertexID;
		struct FVertexID NextVertexID;
		bool& bOutEdgeWindingIsReversed;
		struct FEdgeID return_value;
	} parms;

	parms.VertexID = VertexID;
	parms.NextVertexID = NextVertexID;
	parms.bOutEdgeWindingIsReversed = bOutEdgeWindingIsReversed;

	ProcessEvent(p_GetVertexPairEdge, &parms);
	return parms.return_value;
}

struct FVertexID UObject::GetVertexInstanceVertex(struct FVertexInstanceID VertexInstanceID){

	static UObject* p_GetVertexInstanceVertex = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.GetVertexInstanceVertex");

	struct {
		struct FVertexInstanceID VertexInstanceID;
		struct FVertexID return_value;
	} parms;

	parms.VertexInstanceID = VertexInstanceID;

	ProcessEvent(p_GetVertexInstanceVertex, &parms);
	return parms.return_value;
}

int32_t UObject::GetVertexInstanceCount(){

	static UObject* p_GetVertexInstanceCount = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.GetVertexInstanceCount");

	struct {
		int32_t return_value;
	} parms;


	ProcessEvent(p_GetVertexInstanceCount, &parms);
	return parms.return_value;
}

void UObject::GetVertexInstanceConnectedPolygons(struct FVertexInstanceID VertexInstanceID, struct TArray<struct FPolygonID>& OutConnectedPolygonIDs){

	static UObject* p_GetVertexInstanceConnectedPolygons = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.GetVertexInstanceConnectedPolygons");

	struct {
		struct FVertexInstanceID VertexInstanceID;
		struct TArray<struct FPolygonID>& OutConnectedPolygonIDs;
	} parms;

	parms.VertexInstanceID = VertexInstanceID;
	parms.OutConnectedPolygonIDs = OutConnectedPolygonIDs;

	ProcessEvent(p_GetVertexInstanceConnectedPolygons, &parms);
}

int32_t UObject::GetVertexInstanceConnectedPolygonCount(struct FVertexInstanceID VertexInstanceID){

	static UObject* p_GetVertexInstanceConnectedPolygonCount = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.GetVertexInstanceConnectedPolygonCount");

	struct {
		struct FVertexInstanceID VertexInstanceID;
		int32_t return_value;
	} parms;

	parms.VertexInstanceID = VertexInstanceID;

	ProcessEvent(p_GetVertexInstanceConnectedPolygonCount, &parms);
	return parms.return_value;
}

struct FPolygonID UObject::GetVertexInstanceConnectedPolygon(struct FVertexInstanceID VertexInstanceID, int32_t ConnectedPolygonNumber){

	static UObject* p_GetVertexInstanceConnectedPolygon = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.GetVertexInstanceConnectedPolygon");

	struct {
		struct FVertexInstanceID VertexInstanceID;
		int32_t ConnectedPolygonNumber;
		struct FPolygonID return_value;
	} parms;

	parms.VertexInstanceID = VertexInstanceID;
	parms.ConnectedPolygonNumber = ConnectedPolygonNumber;

	ProcessEvent(p_GetVertexInstanceConnectedPolygon, &parms);
	return parms.return_value;
}

int32_t UObject::GetVertexCount(){

	static UObject* p_GetVertexCount = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.GetVertexCount");

	struct {
		int32_t return_value;
	} parms;


	ProcessEvent(p_GetVertexCount, &parms);
	return parms.return_value;
}

void UObject::GetVertexConnectedPolygons(struct FVertexID VertexID, struct TArray<struct FPolygonID>& OutConnectedPolygonIDs){

	static UObject* p_GetVertexConnectedPolygons = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.GetVertexConnectedPolygons");

	struct {
		struct FVertexID VertexID;
		struct TArray<struct FPolygonID>& OutConnectedPolygonIDs;
	} parms;

	parms.VertexID = VertexID;
	parms.OutConnectedPolygonIDs = OutConnectedPolygonIDs;

	ProcessEvent(p_GetVertexConnectedPolygons, &parms);
}

void UObject::GetVertexConnectedEdges(struct FVertexID VertexID, struct TArray<struct FEdgeID>& OutConnectedEdgeIDs){

	static UObject* p_GetVertexConnectedEdges = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.GetVertexConnectedEdges");

	struct {
		struct FVertexID VertexID;
		struct TArray<struct FEdgeID>& OutConnectedEdgeIDs;
	} parms;

	parms.VertexID = VertexID;
	parms.OutConnectedEdgeIDs = OutConnectedEdgeIDs;

	ProcessEvent(p_GetVertexConnectedEdges, &parms);
}

int32_t UObject::GetVertexConnectedEdgeCount(struct FVertexID VertexID){

	static UObject* p_GetVertexConnectedEdgeCount = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.GetVertexConnectedEdgeCount");

	struct {
		struct FVertexID VertexID;
		int32_t return_value;
	} parms;

	parms.VertexID = VertexID;

	ProcessEvent(p_GetVertexConnectedEdgeCount, &parms);
	return parms.return_value;
}

struct FEdgeID UObject::GetVertexConnectedEdge(struct FVertexID VertexID, int32_t ConnectedEdgeNumber){

	static UObject* p_GetVertexConnectedEdge = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.GetVertexConnectedEdge");

	struct {
		struct FVertexID VertexID;
		int32_t ConnectedEdgeNumber;
		struct FEdgeID return_value;
	} parms;

	parms.VertexID = VertexID;
	parms.ConnectedEdgeNumber = ConnectedEdgeNumber;

	ProcessEvent(p_GetVertexConnectedEdge, &parms);
	return parms.return_value;
}

void UObject::GetVertexAdjacentVertices(struct FVertexID VertexID, struct TArray<struct FVertexID>& OutAdjacentVertexIDs){

	static UObject* p_GetVertexAdjacentVertices = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.GetVertexAdjacentVertices");

	struct {
		struct FVertexID VertexID;
		struct TArray<struct FVertexID>& OutAdjacentVertexIDs;
	} parms;

	parms.VertexID = VertexID;
	parms.OutAdjacentVertexIDs = OutAdjacentVertexIDs;

	ProcessEvent(p_GetVertexAdjacentVertices, &parms);
}

int32_t UObject::GetTextureCoordinateCount(){

	static UObject* p_GetTextureCoordinateCount = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.GetTextureCoordinateCount");

	struct {
		int32_t return_value;
	} parms;


	ProcessEvent(p_GetTextureCoordinateCount, &parms);
	return parms.return_value;
}

struct FSubdivisionLimitData UObject::GetSubdivisionLimitData(){

	static UObject* p_GetSubdivisionLimitData = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.GetSubdivisionLimitData");

	struct {
		struct FSubdivisionLimitData return_value;
	} parms;


	ProcessEvent(p_GetSubdivisionLimitData, &parms);
	return parms.return_value;
}

int32_t UObject::GetSubdivisionCount(){

	static UObject* p_GetSubdivisionCount = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.GetSubdivisionCount");

	struct {
		int32_t return_value;
	} parms;


	ProcessEvent(p_GetSubdivisionCount, &parms);
	return parms.return_value;
}

int32_t UObject::GetPolygonTriangulatedTriangleCount(struct FPolygonID PolygonID){

	static UObject* p_GetPolygonTriangulatedTriangleCount = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.GetPolygonTriangulatedTriangleCount");

	struct {
		struct FPolygonID PolygonID;
		int32_t return_value;
	} parms;

	parms.PolygonID = PolygonID;

	ProcessEvent(p_GetPolygonTriangulatedTriangleCount, &parms);
	return parms.return_value;
}

struct FTriangleID UObject::GetPolygonTriangulatedTriangle(struct FPolygonID PolygonID, int32_t PolygonTriangleNumber){

	static UObject* p_GetPolygonTriangulatedTriangle = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.GetPolygonTriangulatedTriangle");

	struct {
		struct FPolygonID PolygonID;
		int32_t PolygonTriangleNumber;
		struct FTriangleID return_value;
	} parms;

	parms.PolygonID = PolygonID;
	parms.PolygonTriangleNumber = PolygonTriangleNumber;

	ProcessEvent(p_GetPolygonTriangulatedTriangle, &parms);
	return parms.return_value;
}

void UObject::GetPolygonPerimeterVertices(struct FPolygonID PolygonID, struct TArray<struct FVertexID>& OutPolygonPerimeterVertexIDs){

	static UObject* p_GetPolygonPerimeterVertices = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.GetPolygonPerimeterVertices");

	struct {
		struct FPolygonID PolygonID;
		struct TArray<struct FVertexID>& OutPolygonPerimeterVertexIDs;
	} parms;

	parms.PolygonID = PolygonID;
	parms.OutPolygonPerimeterVertexIDs = OutPolygonPerimeterVertexIDs;

	ProcessEvent(p_GetPolygonPerimeterVertices, &parms);
}

void UObject::GetPolygonPerimeterVertexInstances(struct FPolygonID PolygonID, struct TArray<struct FVertexInstanceID>& OutPolygonPerimeterVertexInstanceIDs){

	static UObject* p_GetPolygonPerimeterVertexInstances = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.GetPolygonPerimeterVertexInstances");

	struct {
		struct FPolygonID PolygonID;
		struct TArray<struct FVertexInstanceID>& OutPolygonPerimeterVertexInstanceIDs;
	} parms;

	parms.PolygonID = PolygonID;
	parms.OutPolygonPerimeterVertexInstanceIDs = OutPolygonPerimeterVertexInstanceIDs;

	ProcessEvent(p_GetPolygonPerimeterVertexInstances, &parms);
}

struct FVertexInstanceID UObject::GetPolygonPerimeterVertexInstance(struct FPolygonID PolygonID, int32_t PolygonVertexNumber){

	static UObject* p_GetPolygonPerimeterVertexInstance = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.GetPolygonPerimeterVertexInstance");

	struct {
		struct FPolygonID PolygonID;
		int32_t PolygonVertexNumber;
		struct FVertexInstanceID return_value;
	} parms;

	parms.PolygonID = PolygonID;
	parms.PolygonVertexNumber = PolygonVertexNumber;

	ProcessEvent(p_GetPolygonPerimeterVertexInstance, &parms);
	return parms.return_value;
}

int32_t UObject::GetPolygonPerimeterVertexCount(struct FPolygonID PolygonID){

	static UObject* p_GetPolygonPerimeterVertexCount = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.GetPolygonPerimeterVertexCount");

	struct {
		struct FPolygonID PolygonID;
		int32_t return_value;
	} parms;

	parms.PolygonID = PolygonID;

	ProcessEvent(p_GetPolygonPerimeterVertexCount, &parms);
	return parms.return_value;
}

struct FVertexID UObject::GetPolygonPerimeterVertex(struct FPolygonID PolygonID, int32_t PolygonVertexNumber){

	static UObject* p_GetPolygonPerimeterVertex = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.GetPolygonPerimeterVertex");

	struct {
		struct FPolygonID PolygonID;
		int32_t PolygonVertexNumber;
		struct FVertexID return_value;
	} parms;

	parms.PolygonID = PolygonID;
	parms.PolygonVertexNumber = PolygonVertexNumber;

	ProcessEvent(p_GetPolygonPerimeterVertex, &parms);
	return parms.return_value;
}

void UObject::GetPolygonPerimeterEdges(struct FPolygonID PolygonID, struct TArray<struct FEdgeID>& OutPolygonPerimeterEdgeIDs){

	static UObject* p_GetPolygonPerimeterEdges = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.GetPolygonPerimeterEdges");

	struct {
		struct FPolygonID PolygonID;
		struct TArray<struct FEdgeID>& OutPolygonPerimeterEdgeIDs;
	} parms;

	parms.PolygonID = PolygonID;
	parms.OutPolygonPerimeterEdgeIDs = OutPolygonPerimeterEdgeIDs;

	ProcessEvent(p_GetPolygonPerimeterEdges, &parms);
}

int32_t UObject::GetPolygonPerimeterEdgeCount(struct FPolygonID PolygonID){

	static UObject* p_GetPolygonPerimeterEdgeCount = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.GetPolygonPerimeterEdgeCount");

	struct {
		struct FPolygonID PolygonID;
		int32_t return_value;
	} parms;

	parms.PolygonID = PolygonID;

	ProcessEvent(p_GetPolygonPerimeterEdgeCount, &parms);
	return parms.return_value;
}

struct FEdgeID UObject::GetPolygonPerimeterEdge(struct FPolygonID PolygonID, int32_t PerimeterEdgeNumber, bool& bOutEdgeWindingIsReversedForPolygon){

	static UObject* p_GetPolygonPerimeterEdge = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.GetPolygonPerimeterEdge");

	struct {
		struct FPolygonID PolygonID;
		int32_t PerimeterEdgeNumber;
		bool& bOutEdgeWindingIsReversedForPolygon;
		struct FEdgeID return_value;
	} parms;

	parms.PolygonID = PolygonID;
	parms.PerimeterEdgeNumber = PerimeterEdgeNumber;
	parms.bOutEdgeWindingIsReversedForPolygon = bOutEdgeWindingIsReversedForPolygon;

	ProcessEvent(p_GetPolygonPerimeterEdge, &parms);
	return parms.return_value;
}

struct FPolygonID UObject::GetPolygonInGroup(struct FPolygonGroupID PolygonGroupID, int32_t PolygonNumber){

	static UObject* p_GetPolygonInGroup = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.GetPolygonInGroup");

	struct {
		struct FPolygonGroupID PolygonGroupID;
		int32_t PolygonNumber;
		struct FPolygonID return_value;
	} parms;

	parms.PolygonGroupID = PolygonGroupID;
	parms.PolygonNumber = PolygonNumber;

	ProcessEvent(p_GetPolygonInGroup, &parms);
	return parms.return_value;
}

int32_t UObject::GetPolygonGroupCount(){

	static UObject* p_GetPolygonGroupCount = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.GetPolygonGroupCount");

	struct {
		int32_t return_value;
	} parms;


	ProcessEvent(p_GetPolygonGroupCount, &parms);
	return parms.return_value;
}

int32_t UObject::GetPolygonCountInGroup(struct FPolygonGroupID PolygonGroupID){

	static UObject* p_GetPolygonCountInGroup = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.GetPolygonCountInGroup");

	struct {
		struct FPolygonGroupID PolygonGroupID;
		int32_t return_value;
	} parms;

	parms.PolygonGroupID = PolygonGroupID;

	ProcessEvent(p_GetPolygonCountInGroup, &parms);
	return parms.return_value;
}

int32_t UObject::GetPolygonCount(){

	static UObject* p_GetPolygonCount = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.GetPolygonCount");

	struct {
		int32_t return_value;
	} parms;


	ProcessEvent(p_GetPolygonCount, &parms);
	return parms.return_value;
}

void UObject::GetPolygonAdjacentPolygons(struct FPolygonID PolygonID, struct TArray<struct FPolygonID>& OutAdjacentPolygons){

	static UObject* p_GetPolygonAdjacentPolygons = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.GetPolygonAdjacentPolygons");

	struct {
		struct FPolygonID PolygonID;
		struct TArray<struct FPolygonID>& OutAdjacentPolygons;
	} parms;

	parms.PolygonID = PolygonID;
	parms.OutAdjacentPolygons = OutAdjacentPolygons;

	ProcessEvent(p_GetPolygonAdjacentPolygons, &parms);
}

struct FPolygonGroupID UObject::GetGroupForPolygon(struct FPolygonID PolygonID){

	static UObject* p_GetGroupForPolygon = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.GetGroupForPolygon");

	struct {
		struct FPolygonID PolygonID;
		struct FPolygonGroupID return_value;
	} parms;

	parms.PolygonID = PolygonID;

	ProcessEvent(p_GetGroupForPolygon, &parms);
	return parms.return_value;
}

struct FPolygonGroupID UObject::GetFirstValidPolygonGroup(){

	static UObject* p_GetFirstValidPolygonGroup = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.GetFirstValidPolygonGroup");

	struct {
		struct FPolygonGroupID return_value;
	} parms;


	ProcessEvent(p_GetFirstValidPolygonGroup, &parms);
	return parms.return_value;
}

void UObject::GetEdgeVertices(struct FEdgeID EdgeID, struct FVertexID& OutEdgeVertexID0, struct FVertexID& OutEdgeVertexID1){

	static UObject* p_GetEdgeVertices = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.GetEdgeVertices");

	struct {
		struct FEdgeID EdgeID;
		struct FVertexID& OutEdgeVertexID0;
		struct FVertexID& OutEdgeVertexID1;
	} parms;

	parms.EdgeID = EdgeID;
	parms.OutEdgeVertexID0 = OutEdgeVertexID0;
	parms.OutEdgeVertexID1 = OutEdgeVertexID1;

	ProcessEvent(p_GetEdgeVertices, &parms);
}

struct FVertexID UObject::GetEdgeVertex(struct FEdgeID EdgeID, int32_t EdgeVertexNumber){

	static UObject* p_GetEdgeVertex = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.GetEdgeVertex");

	struct {
		struct FEdgeID EdgeID;
		int32_t EdgeVertexNumber;
		struct FVertexID return_value;
	} parms;

	parms.EdgeID = EdgeID;
	parms.EdgeVertexNumber = EdgeVertexNumber;

	ProcessEvent(p_GetEdgeVertex, &parms);
	return parms.return_value;
}

struct FEdgeID UObject::GetEdgeThatConnectsVertices(struct FVertexID VertexID0, struct FVertexID VertexID1){

	static UObject* p_GetEdgeThatConnectsVertices = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.GetEdgeThatConnectsVertices");

	struct {
		struct FVertexID VertexID0;
		struct FVertexID VertexID1;
		struct FEdgeID return_value;
	} parms;

	parms.VertexID0 = VertexID0;
	parms.VertexID1 = VertexID1;

	ProcessEvent(p_GetEdgeThatConnectsVertices, &parms);
	return parms.return_value;
}

void UObject::GetEdgeLoopElements(struct FEdgeID EdgeID, struct TArray<struct FEdgeID>& EdgeLoopIDs){

	static UObject* p_GetEdgeLoopElements = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.GetEdgeLoopElements");

	struct {
		struct FEdgeID EdgeID;
		struct TArray<struct FEdgeID>& EdgeLoopIDs;
	} parms;

	parms.EdgeID = EdgeID;
	parms.EdgeLoopIDs = EdgeLoopIDs;

	ProcessEvent(p_GetEdgeLoopElements, &parms);
}

int32_t UObject::GetEdgeCount(){

	static UObject* p_GetEdgeCount = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.GetEdgeCount");

	struct {
		int32_t return_value;
	} parms;


	ProcessEvent(p_GetEdgeCount, &parms);
	return parms.return_value;
}

void UObject::GetEdgeConnectedPolygons(struct FEdgeID EdgeID, struct TArray<struct FPolygonID>& OutConnectedPolygonIDs){

	static UObject* p_GetEdgeConnectedPolygons = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.GetEdgeConnectedPolygons");

	struct {
		struct FEdgeID EdgeID;
		struct TArray<struct FPolygonID>& OutConnectedPolygonIDs;
	} parms;

	parms.EdgeID = EdgeID;
	parms.OutConnectedPolygonIDs = OutConnectedPolygonIDs;

	ProcessEvent(p_GetEdgeConnectedPolygons, &parms);
}

int32_t UObject::GetEdgeConnectedPolygonCount(struct FEdgeID EdgeID){

	static UObject* p_GetEdgeConnectedPolygonCount = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.GetEdgeConnectedPolygonCount");

	struct {
		struct FEdgeID EdgeID;
		int32_t return_value;
	} parms;

	parms.EdgeID = EdgeID;

	ProcessEvent(p_GetEdgeConnectedPolygonCount, &parms);
	return parms.return_value;
}

struct FPolygonID UObject::GetEdgeConnectedPolygon(struct FEdgeID EdgeID, int32_t ConnectedPolygonNumber){

	static UObject* p_GetEdgeConnectedPolygon = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.GetEdgeConnectedPolygon");

	struct {
		struct FEdgeID EdgeID;
		int32_t ConnectedPolygonNumber;
		struct FPolygonID return_value;
	} parms;

	parms.EdgeID = EdgeID;
	parms.ConnectedPolygonNumber = ConnectedPolygonNumber;

	ProcessEvent(p_GetEdgeConnectedPolygon, &parms);
	return parms.return_value;
}

void UObject::GeneratePolygonTangentsAndNormals(struct TArray<struct FPolygonID>& PolygonIDs){

	static UObject* p_GeneratePolygonTangentsAndNormals = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.GeneratePolygonTangentsAndNormals");

	struct {
		struct TArray<struct FPolygonID>& PolygonIDs;
	} parms;

	parms.PolygonIDs = PolygonIDs;

	ProcessEvent(p_GeneratePolygonTangentsAndNormals, &parms);
}

void UObject::FlipPolygons(struct TArray<struct FPolygonID>& PolygonIDs){

	static UObject* p_FlipPolygons = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.FlipPolygons");

	struct {
		struct TArray<struct FPolygonID>& PolygonIDs;
	} parms;

	parms.PolygonIDs = PolygonIDs;

	ProcessEvent(p_FlipPolygons, &parms);
}

int32_t UObject::FindPolygonPerimeterVertexNumberForVertex(struct FPolygonID PolygonID, struct FVertexID VertexID){

	static UObject* p_FindPolygonPerimeterVertexNumberForVertex = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.FindPolygonPerimeterVertexNumberForVertex");

	struct {
		struct FPolygonID PolygonID;
		struct FVertexID VertexID;
		int32_t return_value;
	} parms;

	parms.PolygonID = PolygonID;
	parms.VertexID = VertexID;

	ProcessEvent(p_FindPolygonPerimeterVertexNumberForVertex, &parms);
	return parms.return_value;
}

int32_t UObject::FindPolygonPerimeterEdgeNumberForVertices(struct FPolygonID PolygonID, struct FVertexID EdgeVertexID0, struct FVertexID EdgeVertexID1){

	static UObject* p_FindPolygonPerimeterEdgeNumberForVertices = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.FindPolygonPerimeterEdgeNumberForVertices");

	struct {
		struct FPolygonID PolygonID;
		struct FVertexID EdgeVertexID0;
		struct FVertexID EdgeVertexID1;
		int32_t return_value;
	} parms;

	parms.PolygonID = PolygonID;
	parms.EdgeVertexID0 = EdgeVertexID0;
	parms.EdgeVertexID1 = EdgeVertexID1;

	ProcessEvent(p_FindPolygonPerimeterEdgeNumberForVertices, &parms);
	return parms.return_value;
}

void UObject::FindPolygonLoop(struct FEdgeID EdgeID, struct TArray<struct FEdgeID>& OutEdgeLoopEdgeIDs, struct TArray<struct FEdgeID>& OutFlippedEdgeIDs, struct TArray<struct FEdgeID>& OutReversedEdgeIDPathToTake, struct TArray<struct FPolygonID>& OutPolygonIDsToSplit){

	static UObject* p_FindPolygonLoop = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.FindPolygonLoop");

	struct {
		struct FEdgeID EdgeID;
		struct TArray<struct FEdgeID>& OutEdgeLoopEdgeIDs;
		struct TArray<struct FEdgeID>& OutFlippedEdgeIDs;
		struct TArray<struct FEdgeID>& OutReversedEdgeIDPathToTake;
		struct TArray<struct FPolygonID>& OutPolygonIDsToSplit;
	} parms;

	parms.EdgeID = EdgeID;
	parms.OutEdgeLoopEdgeIDs = OutEdgeLoopEdgeIDs;
	parms.OutFlippedEdgeIDs = OutFlippedEdgeIDs;
	parms.OutReversedEdgeIDPathToTake = OutReversedEdgeIDPathToTake;
	parms.OutPolygonIDsToSplit = OutPolygonIDsToSplit;

	ProcessEvent(p_FindPolygonLoop, &parms);
}

void UObject::ExtrudePolygons(struct TArray<struct FPolygonID>& Polygons, float ExtrudeDistance, bool bKeepNeighborsTogether, struct TArray<struct FPolygonID>& OutNewExtrudedFrontPolygons){

	static UObject* p_ExtrudePolygons = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.ExtrudePolygons");

	struct {
		struct TArray<struct FPolygonID>& Polygons;
		float ExtrudeDistance;
		bool bKeepNeighborsTogether;
		struct TArray<struct FPolygonID>& OutNewExtrudedFrontPolygons;
	} parms;

	parms.Polygons = Polygons;
	parms.ExtrudeDistance = ExtrudeDistance;
	parms.bKeepNeighborsTogether = bKeepNeighborsTogether;
	parms.OutNewExtrudedFrontPolygons = OutNewExtrudedFrontPolygons;

	ProcessEvent(p_ExtrudePolygons, &parms);
}

void UObject::ExtendVertices(struct TArray<struct FVertexID>& VertexIDs, bool bOnlyExtendClosestEdge, struct FVector ReferencePosition, struct TArray<struct FVertexID>& OutNewExtendedVertexIDs){

	static UObject* p_ExtendVertices = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.ExtendVertices");

	struct {
		struct TArray<struct FVertexID>& VertexIDs;
		bool bOnlyExtendClosestEdge;
		struct FVector ReferencePosition;
		struct TArray<struct FVertexID>& OutNewExtendedVertexIDs;
	} parms;

	parms.VertexIDs = VertexIDs;
	parms.bOnlyExtendClosestEdge = bOnlyExtendClosestEdge;
	parms.ReferencePosition = ReferencePosition;
	parms.OutNewExtendedVertexIDs = OutNewExtendedVertexIDs;

	ProcessEvent(p_ExtendVertices, &parms);
}

void UObject::ExtendEdges(struct TArray<struct FEdgeID>& EdgeIDs, bool bWeldNeighbors, struct TArray<struct FEdgeID>& OutNewExtendedEdgeIDs){

	static UObject* p_ExtendEdges = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.ExtendEdges");

	struct {
		struct TArray<struct FEdgeID>& EdgeIDs;
		bool bWeldNeighbors;
		struct TArray<struct FEdgeID>& OutNewExtendedEdgeIDs;
	} parms;

	parms.EdgeIDs = EdgeIDs;
	parms.bWeldNeighbors = bWeldNeighbors;
	parms.OutNewExtendedEdgeIDs = OutNewExtendedEdgeIDs;

	ProcessEvent(p_ExtendEdges, &parms);
}

void UObject::EndModification(bool bFromUndo){

	static UObject* p_EndModification = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.EndModification");

	struct {
		bool bFromUndo;
	} parms;

	parms.bFromUndo = bFromUndo;

	ProcessEvent(p_EndModification, &parms);
}

void UObject::DeleteVertexInstances(struct TArray<struct FVertexInstanceID>& VertexInstanceIDsToDelete, bool bDeleteOrphanedVertices){

	static UObject* p_DeleteVertexInstances = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.DeleteVertexInstances");

	struct {
		struct TArray<struct FVertexInstanceID>& VertexInstanceIDsToDelete;
		bool bDeleteOrphanedVertices;
	} parms;

	parms.VertexInstanceIDsToDelete = VertexInstanceIDsToDelete;
	parms.bDeleteOrphanedVertices = bDeleteOrphanedVertices;

	ProcessEvent(p_DeleteVertexInstances, &parms);
}

void UObject::DeleteVertexAndConnectedEdgesAndPolygons(struct FVertexID VertexID, bool bDeleteOrphanedEdges, bool bDeleteOrphanedVertices, bool bDeleteOrphanedVertexInstances, bool bDeleteEmptyPolygonGroups){

	static UObject* p_DeleteVertexAndConnectedEdgesAndPolygons = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.DeleteVertexAndConnectedEdgesAndPolygons");

	struct {
		struct FVertexID VertexID;
		bool bDeleteOrphanedEdges;
		bool bDeleteOrphanedVertices;
		bool bDeleteOrphanedVertexInstances;
		bool bDeleteEmptyPolygonGroups;
	} parms;

	parms.VertexID = VertexID;
	parms.bDeleteOrphanedEdges = bDeleteOrphanedEdges;
	parms.bDeleteOrphanedVertices = bDeleteOrphanedVertices;
	parms.bDeleteOrphanedVertexInstances = bDeleteOrphanedVertexInstances;
	parms.bDeleteEmptyPolygonGroups = bDeleteEmptyPolygonGroups;

	ProcessEvent(p_DeleteVertexAndConnectedEdgesAndPolygons, &parms);
}

void UObject::DeletePolygons(struct TArray<struct FPolygonID>& PolygonIDsToDelete, bool bDeleteOrphanedEdges, bool bDeleteOrphanedVertices, bool bDeleteOrphanedVertexInstances, bool bDeleteEmptyPolygonGroups){

	static UObject* p_DeletePolygons = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.DeletePolygons");

	struct {
		struct TArray<struct FPolygonID>& PolygonIDsToDelete;
		bool bDeleteOrphanedEdges;
		bool bDeleteOrphanedVertices;
		bool bDeleteOrphanedVertexInstances;
		bool bDeleteEmptyPolygonGroups;
	} parms;

	parms.PolygonIDsToDelete = PolygonIDsToDelete;
	parms.bDeleteOrphanedEdges = bDeleteOrphanedEdges;
	parms.bDeleteOrphanedVertices = bDeleteOrphanedVertices;
	parms.bDeleteOrphanedVertexInstances = bDeleteOrphanedVertexInstances;
	parms.bDeleteEmptyPolygonGroups = bDeleteEmptyPolygonGroups;

	ProcessEvent(p_DeletePolygons, &parms);
}

void UObject::DeletePolygonGroups(struct TArray<struct FPolygonGroupID>& PolygonGroupIDs){

	static UObject* p_DeletePolygonGroups = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.DeletePolygonGroups");

	struct {
		struct TArray<struct FPolygonGroupID>& PolygonGroupIDs;
	} parms;

	parms.PolygonGroupIDs = PolygonGroupIDs;

	ProcessEvent(p_DeletePolygonGroups, &parms);
}

void UObject::DeleteOrphanVertices(struct TArray<struct FVertexID>& VertexIDsToDelete){

	static UObject* p_DeleteOrphanVertices = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.DeleteOrphanVertices");

	struct {
		struct TArray<struct FVertexID>& VertexIDsToDelete;
	} parms;

	parms.VertexIDsToDelete = VertexIDsToDelete;

	ProcessEvent(p_DeleteOrphanVertices, &parms);
}

void UObject::DeleteEdges(struct TArray<struct FEdgeID>& EdgeIDsToDelete, bool bDeleteOrphanedVertices){

	static UObject* p_DeleteEdges = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.DeleteEdges");

	struct {
		struct TArray<struct FEdgeID>& EdgeIDsToDelete;
		bool bDeleteOrphanedVertices;
	} parms;

	parms.EdgeIDsToDelete = EdgeIDsToDelete;
	parms.bDeleteOrphanedVertices = bDeleteOrphanedVertices;

	ProcessEvent(p_DeleteEdges, &parms);
}

void UObject::DeleteEdgeAndConnectedPolygons(struct FEdgeID EdgeID, bool bDeleteOrphanedEdges, bool bDeleteOrphanedVertices, bool bDeleteOrphanedVertexInstances, bool bDeleteEmptyPolygonGroups){

	static UObject* p_DeleteEdgeAndConnectedPolygons = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.DeleteEdgeAndConnectedPolygons");

	struct {
		struct FEdgeID EdgeID;
		bool bDeleteOrphanedEdges;
		bool bDeleteOrphanedVertices;
		bool bDeleteOrphanedVertexInstances;
		bool bDeleteEmptyPolygonGroups;
	} parms;

	parms.EdgeID = EdgeID;
	parms.bDeleteOrphanedEdges = bDeleteOrphanedEdges;
	parms.bDeleteOrphanedVertices = bDeleteOrphanedVertices;
	parms.bDeleteOrphanedVertexInstances = bDeleteOrphanedVertexInstances;
	parms.bDeleteEmptyPolygonGroups = bDeleteEmptyPolygonGroups;

	ProcessEvent(p_DeleteEdgeAndConnectedPolygons, &parms);
}

void UObject::CreateVertices(struct TArray<struct FVertexToCreate>& VerticesToCreate, struct TArray<struct FVertexID>& OutNewVertexIDs){

	static UObject* p_CreateVertices = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.CreateVertices");

	struct {
		struct TArray<struct FVertexToCreate>& VerticesToCreate;
		struct TArray<struct FVertexID>& OutNewVertexIDs;
	} parms;

	parms.VerticesToCreate = VerticesToCreate;
	parms.OutNewVertexIDs = OutNewVertexIDs;

	ProcessEvent(p_CreateVertices, &parms);
}

void UObject::CreateVertexInstances(struct TArray<struct FVertexInstanceToCreate>& VertexInstancesToCreate, struct TArray<struct FVertexInstanceID>& OutNewVertexInstanceIDs){

	static UObject* p_CreateVertexInstances = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.CreateVertexInstances");

	struct {
		struct TArray<struct FVertexInstanceToCreate>& VertexInstancesToCreate;
		struct TArray<struct FVertexInstanceID>& OutNewVertexInstanceIDs;
	} parms;

	parms.VertexInstancesToCreate = VertexInstancesToCreate;
	parms.OutNewVertexInstanceIDs = OutNewVertexInstanceIDs;

	ProcessEvent(p_CreateVertexInstances, &parms);
}

void UObject::CreatePolygons(struct TArray<struct FPolygonToCreate>& PolygonsToCreate, struct TArray<struct FPolygonID>& OutNewPolygonIDs, struct TArray<struct FEdgeID>& OutNewEdgeIDs){

	static UObject* p_CreatePolygons = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.CreatePolygons");

	struct {
		struct TArray<struct FPolygonToCreate>& PolygonsToCreate;
		struct TArray<struct FPolygonID>& OutNewPolygonIDs;
		struct TArray<struct FEdgeID>& OutNewEdgeIDs;
	} parms;

	parms.PolygonsToCreate = PolygonsToCreate;
	parms.OutNewPolygonIDs = OutNewPolygonIDs;
	parms.OutNewEdgeIDs = OutNewEdgeIDs;

	ProcessEvent(p_CreatePolygons, &parms);
}

void UObject::CreatePolygonGroups(struct TArray<struct FPolygonGroupToCreate>& PolygonGroupsToCreate, struct TArray<struct FPolygonGroupID>& OutNewPolygonGroupIDs){

	static UObject* p_CreatePolygonGroups = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.CreatePolygonGroups");

	struct {
		struct TArray<struct FPolygonGroupToCreate>& PolygonGroupsToCreate;
		struct TArray<struct FPolygonGroupID>& OutNewPolygonGroupIDs;
	} parms;

	parms.PolygonGroupsToCreate = PolygonGroupsToCreate;
	parms.OutNewPolygonGroupIDs = OutNewPolygonGroupIDs;

	ProcessEvent(p_CreatePolygonGroups, &parms);
}

void UObject::CreateMissingPolygonPerimeterEdges(struct FPolygonID PolygonID, struct TArray<struct FEdgeID>& OutNewEdgeIDs){

	static UObject* p_CreateMissingPolygonPerimeterEdges = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.CreateMissingPolygonPerimeterEdges");

	struct {
		struct FPolygonID PolygonID;
		struct TArray<struct FEdgeID>& OutNewEdgeIDs;
	} parms;

	parms.PolygonID = PolygonID;
	parms.OutNewEdgeIDs = OutNewEdgeIDs;

	ProcessEvent(p_CreateMissingPolygonPerimeterEdges, &parms);
}

void UObject::CreateEmptyVertexRange(int32_t NumVerticesToCreate, struct TArray<struct FVertexID>& OutNewVertexIDs){

	static UObject* p_CreateEmptyVertexRange = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.CreateEmptyVertexRange");

	struct {
		int32_t NumVerticesToCreate;
		struct TArray<struct FVertexID>& OutNewVertexIDs;
	} parms;

	parms.NumVerticesToCreate = NumVerticesToCreate;
	parms.OutNewVertexIDs = OutNewVertexIDs;

	ProcessEvent(p_CreateEmptyVertexRange, &parms);
}

void UObject::CreateEdges(struct TArray<struct FEdgeToCreate>& EdgesToCreate, struct TArray<struct FEdgeID>& OutNewEdgeIDs){

	static UObject* p_CreateEdges = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.CreateEdges");

	struct {
		struct TArray<struct FEdgeToCreate>& EdgesToCreate;
		struct TArray<struct FEdgeID>& OutNewEdgeIDs;
	} parms;

	parms.EdgesToCreate = EdgesToCreate;
	parms.OutNewEdgeIDs = OutNewEdgeIDs;

	ProcessEvent(p_CreateEdges, &parms);
}

void UObject::ComputePolygonsSharedEdges(struct TArray<struct FPolygonID>& PolygonIDs, struct TArray<struct FEdgeID>& OutSharedEdgeIDs){

	static UObject* p_ComputePolygonsSharedEdges = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.ComputePolygonsSharedEdges");

	struct {
		struct TArray<struct FPolygonID>& PolygonIDs;
		struct TArray<struct FEdgeID>& OutSharedEdgeIDs;
	} parms;

	parms.PolygonIDs = PolygonIDs;
	parms.OutSharedEdgeIDs = OutSharedEdgeIDs;

	ProcessEvent(p_ComputePolygonsSharedEdges, &parms);
}

struct FPlane UObject::ComputePolygonPlane(struct FPolygonID PolygonID){

	static UObject* p_ComputePolygonPlane = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.ComputePolygonPlane");

	struct {
		struct FPolygonID PolygonID;
		struct FPlane return_value;
	} parms;

	parms.PolygonID = PolygonID;

	ProcessEvent(p_ComputePolygonPlane, &parms);
	return parms.return_value;
}

struct FVector UObject::ComputePolygonNormal(struct FPolygonID PolygonID){

	static UObject* p_ComputePolygonNormal = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.ComputePolygonNormal");

	struct {
		struct FPolygonID PolygonID;
		struct FVector return_value;
	} parms;

	parms.PolygonID = PolygonID;

	ProcessEvent(p_ComputePolygonNormal, &parms);
	return parms.return_value;
}

struct FVector UObject::ComputePolygonCenter(struct FPolygonID PolygonID){

	static UObject* p_ComputePolygonCenter = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.ComputePolygonCenter");

	struct {
		struct FPolygonID PolygonID;
		struct FVector return_value;
	} parms;

	parms.PolygonID = PolygonID;

	ProcessEvent(p_ComputePolygonCenter, &parms);
	return parms.return_value;
}

struct FBoxSphereBounds UObject::ComputeBoundingBoxAndSphere(){

	static UObject* p_ComputeBoundingBoxAndSphere = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.ComputeBoundingBoxAndSphere");

	struct {
		struct FBoxSphereBounds return_value;
	} parms;


	ProcessEvent(p_ComputeBoundingBoxAndSphere, &parms);
	return parms.return_value;
}

struct FBox UObject::ComputeBoundingBox(){

	static UObject* p_ComputeBoundingBox = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.ComputeBoundingBox");

	struct {
		struct FBox return_value;
	} parms;


	ProcessEvent(p_ComputeBoundingBox, &parms);
	return parms.return_value;
}

struct UEditableMesh* UObject::CommitInstance(struct UPrimitiveComponent* ComponentToInstanceTo){

	static UObject* p_CommitInstance = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.CommitInstance");

	struct {
		struct UPrimitiveComponent* ComponentToInstanceTo;
		struct UEditableMesh* return_value;
	} parms;

	parms.ComponentToInstanceTo = ComponentToInstanceTo;

	ProcessEvent(p_CommitInstance, &parms);
	return parms.return_value;
}

void UObject::Commit(){

	static UObject* p_Commit = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.Commit");

	struct {
	} parms;


	ProcessEvent(p_Commit, &parms);
}

void UObject::ChangePolygonsVertexInstances(struct TArray<struct FChangeVertexInstancesForPolygon>& VertexInstancesForPolygons){

	static UObject* p_ChangePolygonsVertexInstances = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.ChangePolygonsVertexInstances");

	struct {
		struct TArray<struct FChangeVertexInstancesForPolygon>& VertexInstancesForPolygons;
	} parms;

	parms.VertexInstancesForPolygons = VertexInstancesForPolygons;

	ProcessEvent(p_ChangePolygonsVertexInstances, &parms);
}

void UObject::BevelPolygons(struct TArray<struct FPolygonID>& PolygonIDs, float BevelFixedDistance, float BevelProgressTowardCenter, struct TArray<struct FPolygonID>& OutNewCenterPolygonIDs, struct TArray<struct FPolygonID>& OutNewSidePolygonIDs){

	static UObject* p_BevelPolygons = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.BevelPolygons");

	struct {
		struct TArray<struct FPolygonID>& PolygonIDs;
		float BevelFixedDistance;
		float BevelProgressTowardCenter;
		struct TArray<struct FPolygonID>& OutNewCenterPolygonIDs;
		struct TArray<struct FPolygonID>& OutNewSidePolygonIDs;
	} parms;

	parms.PolygonIDs = PolygonIDs;
	parms.BevelFixedDistance = BevelFixedDistance;
	parms.BevelProgressTowardCenter = BevelProgressTowardCenter;
	parms.OutNewCenterPolygonIDs = OutNewCenterPolygonIDs;
	parms.OutNewSidePolygonIDs = OutNewSidePolygonIDs;

	ProcessEvent(p_BevelPolygons, &parms);
}

void UObject::AssignPolygonsToPolygonGroups(struct TArray<struct FPolygonGroupForPolygon>& PolygonGroupForPolygons, bool bDeleteOrphanedPolygonGroups){

	static UObject* p_AssignPolygonsToPolygonGroups = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.AssignPolygonsToPolygonGroups");

	struct {
		struct TArray<struct FPolygonGroupForPolygon>& PolygonGroupForPolygons;
		bool bDeleteOrphanedPolygonGroups;
	} parms;

	parms.PolygonGroupForPolygons = PolygonGroupForPolygons;
	parms.bDeleteOrphanedPolygonGroups = bDeleteOrphanedPolygonGroups;

	ProcessEvent(p_AssignPolygonsToPolygonGroups, &parms);
}

bool UObject::AnyChangesToUndo(){

	static UObject* p_AnyChangesToUndo = UObject::FindObject<UFunction>("Function EditableMesh.EditableMesh.AnyChangesToUndo");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_AnyChangesToUndo, &parms);
	return parms.return_value;
}

