#pragma once 
#include <AmmoSpawner_Structs.h>
 
 
 
// BlueprintGeneratedClass AmmoSpawner.AmmoSpawner_C
// Size: 0x234(Inherited: 0x220) 
struct AAmmoSpawner_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x228(0x8)
	int32_t ;  // 0x230(0x4)

	void ReceiveBeginPlay(); // Function AmmoSpawner.AmmoSpawner_C.ReceiveBeginPlay
	void (); // Function AmmoSpawner.AmmoSpawner_C.
	void ExecuteUbergraph_AmmoSpawner(int32_t EntryPoint); // Function AmmoSpawner.AmmoSpawner_C.ExecuteUbergraph_AmmoSpawner
}; 



