#pragma once 
#include <AKMReload_EndCS_Structs.h>
 
 
 
// BlueprintGeneratedClass AKMReload_EndCS.AKMReload_EndCS_C
// Size: 0x1B0(Inherited: 0x1B0) 
struct UAKMReload_EndCS_C : public UMatineeCameraShake
{

}; 



