#pragma once 
#include <CustomCharacter_Structs.h>
 
 
 
// BlueprintGeneratedClass CustomCharacter.CustomCharacter_C
// Size: 0x5D4(Inherited: 0x4C0) 
struct ACustomCharacter_C : public ACharacter
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x4C0(0x8)
	struct USkeletalMeshComponent* Hat;  // 0x4C8(0x8)
	struct USkeletalMeshComponent* Legs;  // 0x4D0(0x8)
	struct USkeletalMeshComponent* Hand;  // 0x4D8(0x8)
	struct USkeletalMeshComponent* Belt;  // 0x4E0(0x8)
	struct USkeletalMeshComponent* Pants;  // 0x4E8(0x8)
	struct USkeletalMeshComponent* Cloth;  // 0x4F0(0x8)
	struct USkeletalMeshComponent* Shoes;  // 0x4F8(0x8)
	struct USkeletalMeshComponent* HairSocket;  // 0x500(0x8)
	struct USkeletalMeshComponent* Head;  // 0x508(0x8)
	float ____1______0_63D6A7D04C1B1DED661831A412DC42F0;  // 0x510(0x4)
	char ETimelineDirection ____1__Direction_63D6A7D04C1B1DED661831A412DC42F0;  // 0x514(0x1)
	char pad_1301[3];  // 0x515(0x3)
	struct UTimelineComponent* _2;  // 0x518(0x8)
	float ____0______0_2755B4F04961DB9976752BB8CF62921C;  // 0x520(0x4)
	char ETimelineDirection ____0__Direction_2755B4F04961DB9976752BB8CF62921C;  // 0x524(0x1)
	char pad_1317[3];  // 0x525(0x3)
	struct UTimelineComponent* _1;  // 0x528(0x8)
	char pad_1328_1 : 7;  // 0x530(0x1)
	bool CanRotator : 1;  // 0x530(0x1)
	char CharacterModel CharacterModel;  // 0x531(0x1)
	char pad_1330[6];  // 0x532(0x6)
	struct UCharacterSelectAnim_C* AnimRef;  // 0x538(0x8)
	struct USkeletalMesh* BaseMesh;  // 0x540(0x8)
	struct USkeletalMesh* HeadMesh;  // 0x548(0x8)
	struct UMaterialInterface* HeadMaterials;  // 0x550(0x8)
	struct USkeletalMesh* HairMesh;  // 0x558(0x8)
	struct USkeletalMesh* ShoesMesh;  // 0x560(0x8)
	struct UMaterialInterface* ShoesMaterials;  // 0x568(0x8)
	struct USkeletalMesh* ClothMesh;  // 0x570(0x8)
	struct USkeletalMesh* PantsMesh;  // 0x578(0x8)
	struct UMaterialInterface* PantsMaterials;  // 0x580(0x8)
	struct USkeletalMesh* BeltMesh;  // 0x588(0x8)
	struct USkeletalMesh* HandMesh;  // 0x590(0x8)
	struct USkeletalMesh* LegsMesh;  // 0x598(0x8)
	struct USkeletalMesh* HatMesh;  // 0x5A0(0x8)
	struct UCustomCharacterState_BP_C* As Custom Character State BP;  // 0x5A8(0x8)
	struct ACustomCharacter_C* CustomCharacterRef;  // 0x5B0(0x8)
	struct TArray<struct UAnimMontage*> AmayaDance;  // 0x5B8(0x10)
	struct FRotator ActorRotation;  // 0x5C8(0xC)

	void (); // Function CustomCharacter.CustomCharacter_C.
	void (); // Function CustomCharacter.CustomCharacter_C.
	void (); // Function CustomCharacter.CustomCharacter_C.
	void (); // Function CustomCharacter.CustomCharacter_C.
	void (); // Function CustomCharacter.CustomCharacter_C.
	void (char CharacterModel CharacterModel); // Function CustomCharacter.CustomCharacter_C.
	void (); // Function CustomCharacter.CustomCharacter_C.
	void (); // Function CustomCharacter.CustomCharacter_C.
	void (); // Function CustomCharacter.CustomCharacter_C.
	void (float Z); // Function CustomCharacter.CustomCharacter_C.
	void UserConstructionScript(); // Function CustomCharacter.CustomCharacter_C.UserConstructionScript
	void (); // Function CustomCharacter.CustomCharacter_C.
	void (); // Function CustomCharacter.CustomCharacter_C.
	void (); // Function CustomCharacter.CustomCharacter_C.
	void (); // Function CustomCharacter.CustomCharacter_C.
	void OnNotifyEnd_9662C3F24F401F50D7E320ABFEEF79EA(struct FName NotifyName); // Function CustomCharacter.CustomCharacter_C.OnNotifyEnd_9662C3F24F401F50D7E320ABFEEF79EA
	void OnNotifyBegin_9662C3F24F401F50D7E320ABFEEF79EA(struct FName NotifyName); // Function CustomCharacter.CustomCharacter_C.OnNotifyBegin_9662C3F24F401F50D7E320ABFEEF79EA
	void OnInterrupted_9662C3F24F401F50D7E320ABFEEF79EA(struct FName NotifyName); // Function CustomCharacter.CustomCharacter_C.OnInterrupted_9662C3F24F401F50D7E320ABFEEF79EA
	void OnBlendOut_9662C3F24F401F50D7E320ABFEEF79EA(struct FName NotifyName); // Function CustomCharacter.CustomCharacter_C.OnBlendOut_9662C3F24F401F50D7E320ABFEEF79EA
	void OnCompleted_9662C3F24F401F50D7E320ABFEEF79EA(struct FName NotifyName); // Function CustomCharacter.CustomCharacter_C.OnCompleted_9662C3F24F401F50D7E320ABFEEF79EA
	void InpActEvt_LeftMouseButton_K2Node_InputKeyEvent_2(struct FKey Key); // Function CustomCharacter.CustomCharacter_C.InpActEvt_LeftMouseButton_K2Node_InputKeyEvent_2
	void InpActEvt_LeftMouseButton_K2Node_InputKeyEvent_1(struct FKey Key); // Function CustomCharacter.CustomCharacter_C.InpActEvt_LeftMouseButton_K2Node_InputKeyEvent_1
	void (char CharacterModel Selection); // Function CustomCharacter.CustomCharacter_C.
	void (); // Function CustomCharacter.CustomCharacter_C.
	void InpAxisEvt_Turn_K2Node_InputAxisEvent_1(float AxisValue); // Function CustomCharacter.CustomCharacter_C.InpAxisEvt_Turn_K2Node_InputAxisEvent_1
	void ReceiveBeginPlay(); // Function CustomCharacter.CustomCharacter_C.ReceiveBeginPlay
	void (); // Function CustomCharacter.CustomCharacter_C.
	void (); // Function CustomCharacter.CustomCharacter_C.
	void (); // Function CustomCharacter.CustomCharacter_C.
	void ExecuteUbergraph_CustomCharacter(int32_t EntryPoint); // Function CustomCharacter.CustomCharacter_C.ExecuteUbergraph_CustomCharacter
}; 



