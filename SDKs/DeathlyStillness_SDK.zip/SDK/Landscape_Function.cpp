#include "SDK.h" 
 
 
struct UMaterialInstanceDynamic* UPrimitiveComponent::GetMaterialInstanceDynamic(int32_t InIndex){

	static UObject* p_GetMaterialInstanceDynamic = UObject::FindObject<UFunction>("Function Landscape.LandscapeComponent.GetMaterialInstanceDynamic");

	struct {
		int32_t InIndex;
		struct UMaterialInstanceDynamic* return_value;
	} parms;

	parms.InIndex = InIndex;

	ProcessEvent(p_GetMaterialInstanceDynamic, &parms);
	return parms.return_value;
}

float UPrimitiveComponent::EditorGetPaintLayerWeightByNameAtLocation(struct FVector& InLocation, struct FName InPaintLayerName){

	static UObject* p_EditorGetPaintLayerWeightByNameAtLocation = UObject::FindObject<UFunction>("Function Landscape.LandscapeComponent.EditorGetPaintLayerWeightByNameAtLocation");

	struct {
		struct FVector& InLocation;
		struct FName InPaintLayerName;
		float return_value;
	} parms;

	parms.InLocation = InLocation;
	parms.InPaintLayerName = InPaintLayerName;

	ProcessEvent(p_EditorGetPaintLayerWeightByNameAtLocation, &parms);
	return parms.return_value;
}

float UPrimitiveComponent::EditorGetPaintLayerWeightAtLocation(struct FVector& InLocation, struct ULandscapeLayerInfoObject* PaintLayer){

	static UObject* p_EditorGetPaintLayerWeightAtLocation = UObject::FindObject<UFunction>("Function Landscape.LandscapeComponent.EditorGetPaintLayerWeightAtLocation");

	struct {
		struct FVector& InLocation;
		struct ULandscapeLayerInfoObject* PaintLayer;
		float return_value;
	} parms;

	parms.InLocation = InLocation;
	parms.PaintLayer = PaintLayer;

	ProcessEvent(p_EditorGetPaintLayerWeightAtLocation, &parms);
	return parms.return_value;
}

void AActor::SetLandscapeMaterialVectorParameterValue(struct FName ParameterName, struct FLinearColor Value){

	static UObject* p_SetLandscapeMaterialVectorParameterValue = UObject::FindObject<UFunction>("Function Landscape.LandscapeProxy.SetLandscapeMaterialVectorParameterValue");

	struct {
		struct FName ParameterName;
		struct FLinearColor Value;
	} parms;

	parms.ParameterName = ParameterName;
	parms.Value = Value;

	ProcessEvent(p_SetLandscapeMaterialVectorParameterValue, &parms);
}

void AActor::SetLandscapeMaterialTextureParameterValue(struct FName ParameterName, struct UTexture* Value){

	static UObject* p_SetLandscapeMaterialTextureParameterValue = UObject::FindObject<UFunction>("Function Landscape.LandscapeProxy.SetLandscapeMaterialTextureParameterValue");

	struct {
		struct FName ParameterName;
		struct UTexture* Value;
	} parms;

	parms.ParameterName = ParameterName;
	parms.Value = Value;

	ProcessEvent(p_SetLandscapeMaterialTextureParameterValue, &parms);
}

void AActor::SetLandscapeMaterialScalarParameterValue(struct FName ParameterName, float Value){

	static UObject* p_SetLandscapeMaterialScalarParameterValue = UObject::FindObject<UFunction>("Function Landscape.LandscapeProxy.SetLandscapeMaterialScalarParameterValue");

	struct {
		struct FName ParameterName;
		float Value;
	} parms;

	parms.ParameterName = ParameterName;
	parms.Value = Value;

	ProcessEvent(p_SetLandscapeMaterialScalarParameterValue, &parms);
}

bool AActor::LandscapeExportHeightmapToRenderTarget(struct UTextureRenderTarget2D* InRenderTarget, bool InExportHeightIntoRGChannel, bool InExportLandscapeProxies){

	static UObject* p_LandscapeExportHeightmapToRenderTarget = UObject::FindObject<UFunction>("Function Landscape.LandscapeProxy.LandscapeExportHeightmapToRenderTarget");

	struct {
		struct UTextureRenderTarget2D* InRenderTarget;
		bool InExportHeightIntoRGChannel;
		bool InExportLandscapeProxies;
		bool return_value;
	} parms;

	parms.InRenderTarget = InRenderTarget;
	parms.InExportHeightIntoRGChannel = InExportHeightIntoRGChannel;
	parms.InExportLandscapeProxies = InExportLandscapeProxies;

	ProcessEvent(p_LandscapeExportHeightmapToRenderTarget, &parms);
	return parms.return_value;
}

void AActor::EditorSetLandscapeMaterial(struct UMaterialInterface* NewLandscapeMaterial){

	static UObject* p_EditorSetLandscapeMaterial = UObject::FindObject<UFunction>("Function Landscape.LandscapeProxy.EditorSetLandscapeMaterial");

	struct {
		struct UMaterialInterface* NewLandscapeMaterial;
	} parms;

	parms.NewLandscapeMaterial = NewLandscapeMaterial;

	ProcessEvent(p_EditorSetLandscapeMaterial, &parms);
}

void AActor::EditorApplySpline(struct USplineComponent* InSplineComponent, float StartWidth, float EndWidth, float StartSideFalloff, float EndSideFalloff, float StartRoll, float EndRoll, int32_t NumSubdivisions, bool bRaiseHeights, bool bLowerHeights, struct ULandscapeLayerInfoObject* PaintLayer, struct FName EditLayerName){

	static UObject* p_EditorApplySpline = UObject::FindObject<UFunction>("Function Landscape.LandscapeProxy.EditorApplySpline");

	struct {
		struct USplineComponent* InSplineComponent;
		float StartWidth;
		float EndWidth;
		float StartSideFalloff;
		float EndSideFalloff;
		float StartRoll;
		float EndRoll;
		int32_t NumSubdivisions;
		bool bRaiseHeights;
		bool bLowerHeights;
		struct ULandscapeLayerInfoObject* PaintLayer;
		struct FName EditLayerName;
	} parms;

	parms.InSplineComponent = InSplineComponent;
	parms.StartWidth = StartWidth;
	parms.EndWidth = EndWidth;
	parms.StartSideFalloff = StartSideFalloff;
	parms.EndSideFalloff = EndSideFalloff;
	parms.StartRoll = StartRoll;
	parms.EndRoll = EndRoll;
	parms.NumSubdivisions = NumSubdivisions;
	parms.bRaiseHeights = bRaiseHeights;
	parms.bLowerHeights = bLowerHeights;
	parms.PaintLayer = PaintLayer;
	parms.EditLayerName = EditLayerName;

	ProcessEvent(p_EditorApplySpline, &parms);
}

void AActor::ChangeUseTessellationComponentScreenSizeFalloff(bool InComponentScreenSizeToUseSubSections){

	static UObject* p_ChangeUseTessellationComponentScreenSizeFalloff = UObject::FindObject<UFunction>("Function Landscape.LandscapeProxy.ChangeUseTessellationComponentScreenSizeFalloff");

	struct {
		bool InComponentScreenSizeToUseSubSections;
	} parms;

	parms.InComponentScreenSizeToUseSubSections = InComponentScreenSizeToUseSubSections;

	ProcessEvent(p_ChangeUseTessellationComponentScreenSizeFalloff, &parms);
}

void AActor::ChangeTessellationComponentScreenSizeFalloff(float InUseTessellationComponentScreenSizeFalloff){

	static UObject* p_ChangeTessellationComponentScreenSizeFalloff = UObject::FindObject<UFunction>("Function Landscape.LandscapeProxy.ChangeTessellationComponentScreenSizeFalloff");

	struct {
		float InUseTessellationComponentScreenSizeFalloff;
	} parms;

	parms.InUseTessellationComponentScreenSizeFalloff = InUseTessellationComponentScreenSizeFalloff;

	ProcessEvent(p_ChangeTessellationComponentScreenSizeFalloff, &parms);
}

void AActor::ChangeTessellationComponentScreenSize(float InTessellationComponentScreenSize){

	static UObject* p_ChangeTessellationComponentScreenSize = UObject::FindObject<UFunction>("Function Landscape.LandscapeProxy.ChangeTessellationComponentScreenSize");

	struct {
		float InTessellationComponentScreenSize;
	} parms;

	parms.InTessellationComponentScreenSize = InTessellationComponentScreenSize;

	ProcessEvent(p_ChangeTessellationComponentScreenSize, &parms);
}

void AActor::ChangeLODDistanceFactor(float InLODDistanceFactor){

	static UObject* p_ChangeLODDistanceFactor = UObject::FindObject<UFunction>("Function Landscape.LandscapeProxy.ChangeLODDistanceFactor");

	struct {
		float InLODDistanceFactor;
	} parms;

	parms.InLODDistanceFactor = InLODDistanceFactor;

	ProcessEvent(p_ChangeLODDistanceFactor, &parms);
}

void AActor::ChangeComponentScreenSizeToUseSubSections(float InComponentScreenSizeToUseSubSections){

	static UObject* p_ChangeComponentScreenSizeToUseSubSections = UObject::FindObject<UFunction>("Function Landscape.LandscapeProxy.ChangeComponentScreenSizeToUseSubSections");

	struct {
		float InComponentScreenSizeToUseSubSections;
	} parms;

	parms.InComponentScreenSizeToUseSubSections = InComponentScreenSizeToUseSubSections;

	ProcessEvent(p_ChangeComponentScreenSizeToUseSubSections, &parms);
}

void AActor::RequestLandscapeUpdate(){

	static UObject* p_RequestLandscapeUpdate = UObject::FindObject<UFunction>("Function Landscape.LandscapeBlueprintBrushBase.RequestLandscapeUpdate");

	struct {
	} parms;


	ProcessEvent(p_RequestLandscapeUpdate, &parms);
}

struct UTextureRenderTarget2D* AActor::Render(bool InIsHeightmap, struct UTextureRenderTarget2D* InCombinedResult, struct FName& InWeightmapLayerName){

	static UObject* p_Render = UObject::FindObject<UFunction>("Function Landscape.LandscapeBlueprintBrushBase.Render");

	struct {
		bool InIsHeightmap;
		struct UTextureRenderTarget2D* InCombinedResult;
		struct FName& InWeightmapLayerName;
		struct UTextureRenderTarget2D* return_value;
	} parms;

	parms.InIsHeightmap = InIsHeightmap;
	parms.InCombinedResult = InCombinedResult;
	parms.InWeightmapLayerName = InWeightmapLayerName;

	ProcessEvent(p_Render, &parms);
	return parms.return_value;
}

void AActor::Initialize(struct FTransform& InLandscapeTransform, struct FIntPoint& InLandscapeSize, struct FIntPoint& InLandscapeRenderTargetSize){

	static UObject* p_Initialize = UObject::FindObject<UFunction>("Function Landscape.LandscapeBlueprintBrushBase.Initialize");

	struct {
		struct FTransform& InLandscapeTransform;
		struct FIntPoint& InLandscapeSize;
		struct FIntPoint& InLandscapeRenderTargetSize;
	} parms;

	parms.InLandscapeTransform = InLandscapeTransform;
	parms.InLandscapeSize = InLandscapeSize;
	parms.InLandscapeRenderTargetSize = InLandscapeRenderTargetSize;

	ProcessEvent(p_Initialize, &parms);
}

void AActor::GetBlueprintRenderDependencies(struct TArray<struct UObject*>& OutStreamableAssets){

	static UObject* p_GetBlueprintRenderDependencies = UObject::FindObject<UFunction>("Function Landscape.LandscapeBlueprintBrushBase.GetBlueprintRenderDependencies");

	struct {
		struct TArray<struct UObject*>& OutStreamableAssets;
	} parms;

	parms.OutStreamableAssets = OutStreamableAssets;

	ProcessEvent(p_GetBlueprintRenderDependencies, &parms);
}

struct ULandscapeComponent* UPrimitiveComponent::GetRenderComponent(){

	static UObject* p_GetRenderComponent = UObject::FindObject<UFunction>("Function Landscape.LandscapeHeightfieldCollisionComponent.GetRenderComponent");

	struct {
		struct ULandscapeComponent* return_value;
	} parms;


	ProcessEvent(p_GetRenderComponent, &parms);
	return parms.return_value;
}

struct TArray<struct USplineMeshComponent*> UPrimitiveComponent::GetSplineMeshComponents(){

	static UObject* p_GetSplineMeshComponents = UObject::FindObject<UFunction>("Function Landscape.LandscapeSplinesComponent.GetSplineMeshComponents");

	struct {
		struct TArray<struct USplineMeshComponent*> return_value;
	} parms;


	ProcessEvent(p_GetSplineMeshComponents, &parms);
	return parms.return_value;
}

