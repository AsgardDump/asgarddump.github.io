#pragma once 
#include "SDK.h" 
 
 
// Function InGamePlayerState.InGamePlayerState_C.ExecuteUbergraph_InGamePlayerState
// Size: 0x24(Inherited: 0x0) 
struct FExecuteUbergraph_InGamePlayerState
{
	int32_t EntryPoint;  // 0x0(0x4)
	float K2Node_CustomEvent___;  // 0x4(0x4)
	float ___float_Variable;  // 0x8(0x4)
	float ___float_Variable_2;  // 0xC(0x4)
	float ___float_Variable_3;  // 0x10(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0x14(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue_2;  // 0x18(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue_3;  // 0x1C(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue_4;  // 0x20(0x4)

}; 
// Function InGamePlayerState.InGamePlayerState_C.
// Size: 0x14(Inherited: 0x0) 
struct F
{
	float ;  // 0x0(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x4(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x8(0x4)
	int32_t CallFunc_Round_ReturnValue;  // 0xC(0x4)
	float CallFunc_Conv_IntToFloat_ReturnValue;  // 0x10(0x4)

}; 
