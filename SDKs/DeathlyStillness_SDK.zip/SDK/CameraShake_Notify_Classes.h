#pragma once 
#include <CameraShake_Notify_Structs.h>
 
 
 
// BlueprintGeneratedClass CameraShake_Notify.CameraShake_Notify_C
// Size: 0x48(Inherited: 0x38) 
struct UCameraShake_Notify_C : public UAnimNotify
{
	float Scale;  // 0x38(0x4)
	char pad_60[4];  // 0x3C(0x4)
	UCameraShakeBase* Shake;  // 0x40(0x8)

	bool Received_Notify(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation); // Function CameraShake_Notify.CameraShake_Notify_C.Received_Notify
}; 



