#pragma once 
#include "SDK.h" 
 
 
// Function BP_Bloodstain_Main.BP_Bloodstain_Main_C.ExecuteUbergraph_BP_Bloodstain_Main
// Size: 0x18(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Bloodstain_Main
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UMaterialInterface* CallFunc_GetMaterial_ReturnValue;  // 0x8(0x8)
	struct UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue;  // 0x10(0x8)

}; 
