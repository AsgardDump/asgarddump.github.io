#pragma once 
#include <BP_Flashlight_Demo_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Flashlight_Demo.BP_Flashlight_Demo_C
// Size: 0x260(Inherited: 0x220) 
struct ABP_Flashlight_Demo_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct UStaticMeshComponent* Static Mesh Flashlight;  // 0x228(0x8)
	struct UStaticMesh* Mesh;  // 0x230(0x8)
	char pad_568_1 : 7;  // 0x238(0x1)
	bool ON : 1;  // 0x238(0x1)
	char pad_569[3];  // 0x239(0x3)
	float Intensity;  // 0x23C(0x4)
	float Light Intensity Multiplier;  // 0x240(0x4)
	float Outer Cone Angle;  // 0x244(0x4)
	float Inner Cone Angle;  // 0x248(0x4)
	struct FColor Light Color;  // 0x24C(0x4)
	struct UPointLightComponent* Light Source 1;  // 0x250(0x8)
	struct UTexture* Spotlight Beam Texture;  // 0x258(0x8)

	void Set Intensity(); // Function BP_Flashlight_Demo.BP_Flashlight_Demo_C.Set Intensity
	void UserConstructionScript(); // Function BP_Flashlight_Demo.BP_Flashlight_Demo_C.UserConstructionScript
	void ReceiveBeginPlay(); // Function BP_Flashlight_Demo.BP_Flashlight_Demo_C.ReceiveBeginPlay
	void TurnOn(); // Function BP_Flashlight_Demo.BP_Flashlight_Demo_C.TurnOn
	void TurnOff(); // Function BP_Flashlight_Demo.BP_Flashlight_Demo_C.TurnOff
	void (); // Function BP_Flashlight_Demo.BP_Flashlight_Demo_C.
	void ExecuteUbergraph_BP_Flashlight_Demo(int32_t EntryPoint); // Function BP_Flashlight_Demo.BP_Flashlight_Demo_C.ExecuteUbergraph_BP_Flashlight_Demo
}; 



