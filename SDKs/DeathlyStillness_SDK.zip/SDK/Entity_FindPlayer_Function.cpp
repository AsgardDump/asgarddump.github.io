#include "SDK.h" 
 
 
void UBTTask_BlueprintBase::OnFail_AF1AD3FC44F1D7FEE4BA7FBE27A21D76(char EPathFollowingResult MovementResult){

	static UObject* p_OnFail_AF1AD3FC44F1D7FEE4BA7FBE27A21D76 = UObject::FindObject<UFunction>("Function Entity_FindPlayer.Entity_FindPlayer_C.OnFail_AF1AD3FC44F1D7FEE4BA7FBE27A21D76");

	struct {
		char EPathFollowingResult MovementResult;
	} parms;

	parms.MovementResult = MovementResult;

	ProcessEvent(p_OnFail_AF1AD3FC44F1D7FEE4BA7FBE27A21D76, &parms);
}

void UBTTask_BlueprintBase::OnSuccess_AF1AD3FC44F1D7FEE4BA7FBE27A21D76(char EPathFollowingResult MovementResult){

	static UObject* p_OnSuccess_AF1AD3FC44F1D7FEE4BA7FBE27A21D76 = UObject::FindObject<UFunction>("Function Entity_FindPlayer.Entity_FindPlayer_C.OnSuccess_AF1AD3FC44F1D7FEE4BA7FBE27A21D76");

	struct {
		char EPathFollowingResult MovementResult;
	} parms;

	parms.MovementResult = MovementResult;

	ProcessEvent(p_OnSuccess_AF1AD3FC44F1D7FEE4BA7FBE27A21D76, &parms);
}

void UBTTask_BlueprintBase::ReceiveTickAI(struct AAIController* OwnerController, struct APawn* ControlledPawn, float DeltaSeconds){

	static UObject* p_ReceiveTickAI = UObject::FindObject<UFunction>("Function Entity_FindPlayer.Entity_FindPlayer_C.ReceiveTickAI");

	struct {
		struct AAIController* OwnerController;
		struct APawn* ControlledPawn;
		float DeltaSeconds;
	} parms;

	parms.OwnerController = OwnerController;
	parms.ControlledPawn = ControlledPawn;
	parms.DeltaSeconds = DeltaSeconds;

	ProcessEvent(p_ReceiveTickAI, &parms);
}

void UBTTask_BlueprintBase::ExecuteUbergraph_Entity_FindPlayer(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph_Entity_FindPlayer = UObject::FindObject<UFunction>("Function Entity_FindPlayer.Entity_FindPlayer_C.ExecuteUbergraph_Entity_FindPlayer");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph_Entity_FindPlayer, &parms);
}

