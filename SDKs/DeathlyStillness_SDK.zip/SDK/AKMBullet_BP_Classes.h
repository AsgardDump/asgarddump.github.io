#pragma once 
#include <AKMBullet_BP_Structs.h>
 
 
 
// BlueprintGeneratedClass AKMBullet_BP.AKMBullet_BP_C
// Size: 0x24C(Inherited: 0x24C) 
struct AAKMBullet_BP_C : public ABulletMaster_BP_C
{

}; 



