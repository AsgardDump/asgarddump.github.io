#include "SDK.h" 
 
 
struct UMatineeCameraShake* UCameraShakeBase::StartMatineeCameraShakeFromSource(struct APlayerCameraManager* PlayerCameraManager, UMatineeCameraShake* ShakeClass, struct UCameraShakeSourceComponent* SourceComponent, float Scale, uint8_t  PlaySpace, struct FRotator UserPlaySpaceRot){

	static UObject* p_StartMatineeCameraShakeFromSource = UObject::FindObject<UFunction>("Function GameplayCameras.MatineeCameraShake.StartMatineeCameraShakeFromSource");

	struct {
		struct APlayerCameraManager* PlayerCameraManager;
		UMatineeCameraShake* ShakeClass;
		struct UCameraShakeSourceComponent* SourceComponent;
		float Scale;
		uint8_t  PlaySpace;
		struct FRotator UserPlaySpaceRot;
		struct UMatineeCameraShake* return_value;
	} parms;

	parms.PlayerCameraManager = PlayerCameraManager;
	parms.ShakeClass = ShakeClass;
	parms.SourceComponent = SourceComponent;
	parms.Scale = Scale;
	parms.PlaySpace = PlaySpace;
	parms.UserPlaySpaceRot = UserPlaySpaceRot;

	ProcessEvent(p_StartMatineeCameraShakeFromSource, &parms);
	return parms.return_value;
}

struct UMatineeCameraShake* UCameraShakeBase::StartMatineeCameraShake(struct APlayerCameraManager* PlayerCameraManager, UMatineeCameraShake* ShakeClass, float Scale, uint8_t  PlaySpace, struct FRotator UserPlaySpaceRot){

	static UObject* p_StartMatineeCameraShake = UObject::FindObject<UFunction>("Function GameplayCameras.MatineeCameraShake.StartMatineeCameraShake");

	struct {
		struct APlayerCameraManager* PlayerCameraManager;
		UMatineeCameraShake* ShakeClass;
		float Scale;
		uint8_t  PlaySpace;
		struct FRotator UserPlaySpaceRot;
		struct UMatineeCameraShake* return_value;
	} parms;

	parms.PlayerCameraManager = PlayerCameraManager;
	parms.ShakeClass = ShakeClass;
	parms.Scale = Scale;
	parms.PlaySpace = PlaySpace;
	parms.UserPlaySpaceRot = UserPlaySpaceRot;

	ProcessEvent(p_StartMatineeCameraShake, &parms);
	return parms.return_value;
}

void UCameraShakeBase::ReceiveStopShake(bool bImmediately){

	static UObject* p_ReceiveStopShake = UObject::FindObject<UFunction>("Function GameplayCameras.MatineeCameraShake.ReceiveStopShake");

	struct {
		bool bImmediately;
	} parms;

	parms.bImmediately = bImmediately;

	ProcessEvent(p_ReceiveStopShake, &parms);
}

void UCameraShakeBase::ReceivePlayShake(float Scale){

	static UObject* p_ReceivePlayShake = UObject::FindObject<UFunction>("Function GameplayCameras.MatineeCameraShake.ReceivePlayShake");

	struct {
		float Scale;
	} parms;

	parms.Scale = Scale;

	ProcessEvent(p_ReceivePlayShake, &parms);
}

bool UCameraShakeBase::ReceiveIsFinished(){

	static UObject* p_ReceiveIsFinished = UObject::FindObject<UFunction>("Function GameplayCameras.MatineeCameraShake.ReceiveIsFinished");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_ReceiveIsFinished, &parms);
	return parms.return_value;
}

void UCameraShakeBase::BlueprintUpdateCameraShake(float DeltaTime, float Alpha, struct FMinimalViewInfo& POV, struct FMinimalViewInfo& ModifiedPOV){

	static UObject* p_BlueprintUpdateCameraShake = UObject::FindObject<UFunction>("Function GameplayCameras.MatineeCameraShake.BlueprintUpdateCameraShake");

	struct {
		float DeltaTime;
		float Alpha;
		struct FMinimalViewInfo& POV;
		struct FMinimalViewInfo& ModifiedPOV;
	} parms;

	parms.DeltaTime = DeltaTime;
	parms.Alpha = Alpha;
	parms.POV = POV;
	parms.ModifiedPOV = ModifiedPOV;

	ProcessEvent(p_BlueprintUpdateCameraShake, &parms);
}

struct UMatineeCameraShake* UBlueprintFunctionLibrary::Conv_MatineeCameraShake(struct UCameraShakeBase* CameraShake){

	static UObject* p_Conv_MatineeCameraShake = UObject::FindObject<UFunction>("Function GameplayCameras.MatineeCameraShakeFunctionLibrary.Conv_MatineeCameraShake");

	struct {
		struct UCameraShakeBase* CameraShake;
		struct UMatineeCameraShake* return_value;
	} parms;

	parms.CameraShake = CameraShake;

	ProcessEvent(p_Conv_MatineeCameraShake, &parms);
	return parms.return_value;
}

