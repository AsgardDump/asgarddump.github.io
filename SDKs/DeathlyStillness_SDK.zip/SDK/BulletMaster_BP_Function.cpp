#include "SDK.h" 
 
 
void AActor::(struct UPrimitiveComponent* InputObject, float , struct FHitResult Hit){

	static UObject* p_ = UObject::FindObject<UFunction>("Function BulletMaster_BP.BulletMaster_BP_C.");

	struct {
		struct UPrimitiveComponent* InputObject;
		float ;
		struct FHitResult Hit;
	} parms;

	parms.InputObject = InputObject;
	parms. = ;
	parms.Hit = Hit;

	ProcessEvent(p_, &parms);
}

void AActor::(struct FHitResult& Hit){

	static UObject* p_ = UObject::FindObject<UFunction>("Function BulletMaster_BP.BulletMaster_BP_C.");

	struct {
		struct FHitResult& Hit;
	} parms;

	parms.Hit = Hit;

	ProcessEvent(p_, &parms);
}

void AActor::HitSurface(struct FHitResult& Hit){

	static UObject* p_HitSurface = UObject::FindObject<UFunction>("Function BulletMaster_BP.BulletMaster_BP_C.HitSurface");

	struct {
		struct FHitResult& Hit;
	} parms;

	parms.Hit = Hit;

	ProcessEvent(p_HitSurface, &parms);
}

void AActor::ReceiveHit(struct UPrimitiveComponent* MyComp, struct AActor* Other, struct UPrimitiveComponent* OtherComp, bool bSelfMoved, struct FVector HitLocation, struct FVector HitNormal, struct FVector NormalImpulse, struct FHitResult& Hit){

	static UObject* p_ReceiveHit = UObject::FindObject<UFunction>("Function BulletMaster_BP.BulletMaster_BP_C.ReceiveHit");

	struct {
		struct UPrimitiveComponent* MyComp;
		struct AActor* Other;
		struct UPrimitiveComponent* OtherComp;
		bool bSelfMoved;
		struct FVector HitLocation;
		struct FVector HitNormal;
		struct FVector NormalImpulse;
		struct FHitResult& Hit;
	} parms;

	parms.MyComp = MyComp;
	parms.Other = Other;
	parms.OtherComp = OtherComp;
	parms.bSelfMoved = bSelfMoved;
	parms.HitLocation = HitLocation;
	parms.HitNormal = HitNormal;
	parms.NormalImpulse = NormalImpulse;
	parms.Hit = Hit;

	ProcessEvent(p_ReceiveHit, &parms);
}

void AActor::ReceiveBeginPlay(){

	static UObject* p_ReceiveBeginPlay = UObject::FindObject<UFunction>("Function BulletMaster_BP.BulletMaster_BP_C.ReceiveBeginPlay");

	struct {
	} parms;


	ProcessEvent(p_ReceiveBeginPlay, &parms);
}

void AActor::ExecuteUbergraph_BulletMaster_BP(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph_BulletMaster_BP = UObject::FindObject<UFunction>("Function BulletMaster_BP.BulletMaster_BP_C.ExecuteUbergraph_BulletMaster_BP");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph_BulletMaster_BP, &parms);
}

