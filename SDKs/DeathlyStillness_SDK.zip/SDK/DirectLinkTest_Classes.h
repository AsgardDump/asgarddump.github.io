#pragma once 
#include <DirectLinkTest_Structs.h>
 
 
 
// Class DirectLinkTest.DirectLinkTestLibrary
// Size: 0x28(Inherited: 0x28) 
struct UDirectLinkTestLibrary : public UBlueprintFunctionLibrary
{

	bool TestParameters(); // Function DirectLinkTest.DirectLinkTestLibrary.TestParameters
	bool StopSender(); // Function DirectLinkTest.DirectLinkTestLibrary.StopSender
	bool StopReceiver(); // Function DirectLinkTest.DirectLinkTestLibrary.StopReceiver
	bool StartSender(); // Function DirectLinkTest.DirectLinkTestLibrary.StartSender
	bool StartReceiver(); // Function DirectLinkTest.DirectLinkTestLibrary.StartReceiver
	bool SetupSender(); // Function DirectLinkTest.DirectLinkTestLibrary.SetupSender
	bool SetupReceiver(); // Function DirectLinkTest.DirectLinkTestLibrary.SetupReceiver
	bool SendScene(struct FString InFilePath); // Function DirectLinkTest.DirectLinkTestLibrary.SendScene
	int32_t MakeEndpoint(struct FString NiceName, bool bVerbose); // Function DirectLinkTest.DirectLinkTestLibrary.MakeEndpoint
	bool DumpReceivedScene(); // Function DirectLinkTest.DirectLinkTestLibrary.DumpReceivedScene
	bool DeleteEndpoint(int32_t EndpointId); // Function DirectLinkTest.DirectLinkTestLibrary.DeleteEndpoint
	bool DeleteAllEndpoint(); // Function DirectLinkTest.DirectLinkTestLibrary.DeleteAllEndpoint
	bool AddPublicSource(int32_t EndpointId, struct FString SourceName); // Function DirectLinkTest.DirectLinkTestLibrary.AddPublicSource
	bool AddPublicDestination(int32_t EndpointId, struct FString DestName); // Function DirectLinkTest.DirectLinkTestLibrary.AddPublicDestination
}; 



