#pragma once 
#include "SDK.h" 
 
 
// Function Chinese_Vampire_AttackStart.Chinese_Vampire_AttackStart_C.Received_Notify
// Size: 0x18(Inherited: 0x0) 
struct FReceived_Notify
{
	struct USkeletalMeshComponent* bpp__MeshComp__pf;  // 0x0(0x8)
	struct UAnimSequenceBase* bpp__Animation__pf;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
