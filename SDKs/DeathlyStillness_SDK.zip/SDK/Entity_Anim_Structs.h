#pragma once 
#include "SDK.h" 
 
 
// Function Entity_Anim.Entity_Anim_C.BlueprintUpdateAnimation
// Size: 0x4(Inherited: 0x4) 
struct FBlueprintUpdateAnimation : public FBlueprintUpdateAnimation
{
	float DeltaTimeX;  // 0x0(0x4)

}; 
// Function Entity_Anim.Entity_Anim_C.ExecuteUbergraph_Entity_Anim
// Size: 0x29(Inherited: 0x0) 
struct FExecuteUbergraph_Entity_Anim
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct APawn* CallFunc_TryGetPawnOwner_ReturnValue;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)
	struct FVector CallFunc_GetVelocity_ReturnValue;  // 0x14(0xC)
	float CallFunc_VSize_ReturnValue;  // 0x20(0x4)
	float K2Node_Event_DeltaTimeX;  // 0x24(0x4)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue : 1;  // 0x28(0x1)

}; 
// Function Entity_Anim.Entity_Anim_C.AnimGraph
// Size: 0x10(Inherited: 0x0) 
struct FAnimGraph
{
	struct FPoseLink AnimGraph;  // 0x0(0x10)

}; 
