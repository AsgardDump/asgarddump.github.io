#pragma once 
#include <ClipDrop1_Structs.h>
 
 
 
// BlueprintGeneratedClass ClipDrop1.ClipDrop1_C
// Size: 0x44(Inherited: 0x38) 
struct UClipDrop1_C : public UAnimNotify
{
	float Scale;  // 0x38(0x4)
	struct FName Socket Name;  // 0x3C(0x8)

	bool Received_Notify(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation); // Function ClipDrop1.ClipDrop1_C.Received_Notify
}; 



