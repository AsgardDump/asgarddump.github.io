#pragma once 
#include <BP_ClothesRack_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_ClothesRack.BP_ClothesRack_C
// Size: 0x231(Inherited: 0x220) 
struct ABP_ClothesRack_C : public AActor
{
	struct USceneComponent* Scene;  // 0x220(0x8)
	int32_t Width (m);  // 0x228(0x4)
	int32_t I;  // 0x22C(0x4)
	char ENUM_ClothesRackType Style;  // 0x230(0x1)

	void UserConstructionScript(); // Function BP_ClothesRack.BP_ClothesRack_C.UserConstructionScript
}; 



