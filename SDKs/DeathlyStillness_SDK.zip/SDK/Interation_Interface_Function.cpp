#include "SDK.h" 
 
 
void UInterface::(){

	static UObject* p_ = UObject::FindObject<UFunction>("Function Interation_Interface.Interation_Interface_C.");

	struct {
	} parms;


	ProcessEvent(p_, &parms);
}

void UInterface::OpenDoor(struct APUBG_BaseCharacter_BP_C* Player){

	static UObject* p_OpenDoor = UObject::FindObject<UFunction>("Function Interation_Interface.Interation_Interface_C.OpenDoor");

	struct {
		struct APUBG_BaseCharacter_BP_C* Player;
	} parms;

	parms.Player = Player;

	ProcessEvent(p_OpenDoor, &parms);
}

void UInterface::SetRenderClose(){

	static UObject* p_SetRenderClose = UObject::FindObject<UFunction>("Function Interation_Interface.Interation_Interface_C.SetRenderClose");

	struct {
	} parms;


	ProcessEvent(p_SetRenderClose, &parms);
}

void UInterface::SetRenderOpen(){

	static UObject* p_SetRenderOpen = UObject::FindObject<UFunction>("Function Interation_Interface.Interation_Interface_C.SetRenderOpen");

	struct {
	} parms;


	ProcessEvent(p_SetRenderOpen, &parms);
}

void UInterface::PickUp(struct APUBG_BaseCharacter_BP_C* Player){

	static UObject* p_PickUp = UObject::FindObject<UFunction>("Function Interation_Interface.Interation_Interface_C.PickUp");

	struct {
		struct APUBG_BaseCharacter_BP_C* Player;
	} parms;

	parms.Player = Player;

	ProcessEvent(p_PickUp, &parms);
}

