#include "SDK.h" 
 
 
void AActor::(){

	static UObject* p_ = UObject::FindObject<UFunction>("Function InGame_UI_BP.InGame_UI_BP_C.");

	struct {
	} parms;


	ProcessEvent(p_, &parms);
}

void AActor::ExecuteUbergraph_InGame_UI_BP(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph_InGame_UI_BP = UObject::FindObject<UFunction>("Function InGame_UI_BP.InGame_UI_BP_C.ExecuteUbergraph_InGame_UI_BP");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph_InGame_UI_BP, &parms);
}

