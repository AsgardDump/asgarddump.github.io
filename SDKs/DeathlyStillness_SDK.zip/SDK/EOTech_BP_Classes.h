#pragma once 
#include <EOTech_BP_Structs.h>
 
 
 
// BlueprintGeneratedClass EOTech_BP.EOTech_BP_C
// Size: 0x2B0(Inherited: 0x2B0) 
struct AEOTech_BP_C : public APickUpMaster_C
{

}; 



