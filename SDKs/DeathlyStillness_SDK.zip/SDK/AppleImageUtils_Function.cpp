#include "SDK.h" 
 
 
struct UAppleImageUtilsBaseAsyncTaskBlueprintProxy* UObject::CreateProxyObjectForConvertToTIFF(struct UTexture* SourceImage, bool bWantColor, bool bUseGpu, float Scale, uint8_t  Rotate){

	static UObject* p_CreateProxyObjectForConvertToTIFF = UObject::FindObject<UFunction>("Function AppleImageUtils.AppleImageUtilsBaseAsyncTaskBlueprintProxy.CreateProxyObjectForConvertToTIFF");

	struct {
		struct UTexture* SourceImage;
		bool bWantColor;
		bool bUseGpu;
		float Scale;
		uint8_t  Rotate;
		struct UAppleImageUtilsBaseAsyncTaskBlueprintProxy* return_value;
	} parms;

	parms.SourceImage = SourceImage;
	parms.bWantColor = bWantColor;
	parms.bUseGpu = bUseGpu;
	parms.Scale = Scale;
	parms.Rotate = Rotate;

	ProcessEvent(p_CreateProxyObjectForConvertToTIFF, &parms);
	return parms.return_value;
}

struct UAppleImageUtilsBaseAsyncTaskBlueprintProxy* UObject::CreateProxyObjectForConvertToPNG(struct UTexture* SourceImage, bool bWantColor, bool bUseGpu, float Scale, uint8_t  Rotate){

	static UObject* p_CreateProxyObjectForConvertToPNG = UObject::FindObject<UFunction>("Function AppleImageUtils.AppleImageUtilsBaseAsyncTaskBlueprintProxy.CreateProxyObjectForConvertToPNG");

	struct {
		struct UTexture* SourceImage;
		bool bWantColor;
		bool bUseGpu;
		float Scale;
		uint8_t  Rotate;
		struct UAppleImageUtilsBaseAsyncTaskBlueprintProxy* return_value;
	} parms;

	parms.SourceImage = SourceImage;
	parms.bWantColor = bWantColor;
	parms.bUseGpu = bUseGpu;
	parms.Scale = Scale;
	parms.Rotate = Rotate;

	ProcessEvent(p_CreateProxyObjectForConvertToPNG, &parms);
	return parms.return_value;
}

struct UAppleImageUtilsBaseAsyncTaskBlueprintProxy* UObject::CreateProxyObjectForConvertToJPEG(struct UTexture* SourceImage, int32_t Quality, bool bWantColor, bool bUseGpu, float Scale, uint8_t  Rotate){

	static UObject* p_CreateProxyObjectForConvertToJPEG = UObject::FindObject<UFunction>("Function AppleImageUtils.AppleImageUtilsBaseAsyncTaskBlueprintProxy.CreateProxyObjectForConvertToJPEG");

	struct {
		struct UTexture* SourceImage;
		int32_t Quality;
		bool bWantColor;
		bool bUseGpu;
		float Scale;
		uint8_t  Rotate;
		struct UAppleImageUtilsBaseAsyncTaskBlueprintProxy* return_value;
	} parms;

	parms.SourceImage = SourceImage;
	parms.Quality = Quality;
	parms.bWantColor = bWantColor;
	parms.bUseGpu = bUseGpu;
	parms.Scale = Scale;
	parms.Rotate = Rotate;

	ProcessEvent(p_CreateProxyObjectForConvertToJPEG, &parms);
	return parms.return_value;
}

struct UAppleImageUtilsBaseAsyncTaskBlueprintProxy* UObject::CreateProxyObjectForConvertToHEIF(struct UTexture* SourceImage, int32_t Quality, bool bWantColor, bool bUseGpu, float Scale, uint8_t  Rotate){

	static UObject* p_CreateProxyObjectForConvertToHEIF = UObject::FindObject<UFunction>("Function AppleImageUtils.AppleImageUtilsBaseAsyncTaskBlueprintProxy.CreateProxyObjectForConvertToHEIF");

	struct {
		struct UTexture* SourceImage;
		int32_t Quality;
		bool bWantColor;
		bool bUseGpu;
		float Scale;
		uint8_t  Rotate;
		struct UAppleImageUtilsBaseAsyncTaskBlueprintProxy* return_value;
	} parms;

	parms.SourceImage = SourceImage;
	parms.Quality = Quality;
	parms.bWantColor = bWantColor;
	parms.bUseGpu = bUseGpu;
	parms.Scale = Scale;
	parms.Rotate = Rotate;

	ProcessEvent(p_CreateProxyObjectForConvertToHEIF, &parms);
	return parms.return_value;
}

