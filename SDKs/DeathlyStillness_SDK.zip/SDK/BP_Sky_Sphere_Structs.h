#pragma once 
#include "SDK.h" 
 
 
// Function BP_Sky_Sphere.BP_Sky_Sphere_C.UserConstructionScript
// Size: 0x8(Inherited: 0x0) 
struct FUserConstructionScript : public FUserConstructionScript
{
	struct UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue;  // 0x0(0x8)

}; 
// Function BP_Sky_Sphere.BP_Sky_Sphere_C.UpdateSunDirection
// Size: 0x98(Inherited: 0x0) 
struct FUpdateSunDirection
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool CallFunc_Less_FloatFloat_ReturnValue : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	struct FRotator CallFunc_K2_GetActorRotation_ReturnValue;  // 0x4(0xC)
	float CallFunc_Abs_ReturnValue;  // 0x10(0x4)
	float CallFunc_BreakRotator_Roll;  // 0x14(0x4)
	float CallFunc_BreakRotator_Pitch;  // 0x18(0x4)
	float CallFunc_BreakRotator_Yaw;  // 0x1C(0x4)
	float CallFunc_SelectFloat_ReturnValue;  // 0x20(0x4)
	float CallFunc_MapRangeUnclamped_ReturnValue;  // 0x24(0x4)
	struct FRotator CallFunc_K2_GetActorRotation_ReturnValue_2;  // 0x28(0xC)
	struct FLinearColor CallFunc_Conv_ColorToLinearColor_ReturnValue;  // 0x34(0x10)
	struct FVector CallFunc_Conv_RotatorToVector_ReturnValue;  // 0x44(0xC)
	struct FLinearColor CallFunc_Conv_VectorToLinearColor_ReturnValue;  // 0x50(0x10)
	float CallFunc_Abs_ReturnValue_2;  // 0x60(0x4)
	struct FLinearColor CallFunc_GetClampedLinearColorValue_ReturnValue;  // 0x64(0x10)
	float CallFunc_Lerp_ReturnValue;  // 0x74(0x4)
	struct FLinearColor CallFunc_GetClampedLinearColorValue_ReturnValue_2;  // 0x78(0x10)
	struct FLinearColor CallFunc_GetClampedLinearColorValue_ReturnValue_3;  // 0x88(0x10)

}; 
// Function BP_Sky_Sphere.BP_Sky_Sphere_C.RefreshMaterial
// Size: 0xF8(Inherited: 0x0) 
struct FRefreshMaterial
{
	float CallFunc_Abs_ReturnValue;  // 0x0(0x4)
	struct FLinearColor CallFunc_GetClampedLinearColorValue_ReturnValue;  // 0x4(0x10)
	float CallFunc_Lerp_ReturnValue;  // 0x14(0x4)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_Less_FloatFloat_ReturnValue : 1;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)
	float CallFunc_Abs_ReturnValue_2;  // 0x1C(0x4)
	float CallFunc_SelectFloat_ReturnValue;  // 0x20(0x4)
	float CallFunc_MapRangeUnclamped_ReturnValue;  // 0x24(0x4)
	struct FRotator CallFunc_K2_GetActorRotation_ReturnValue;  // 0x28(0xC)
	float CallFunc_BreakRotator_Roll;  // 0x34(0x4)
	float CallFunc_BreakRotator_Pitch;  // 0x38(0x4)
	float CallFunc_BreakRotator_Yaw;  // 0x3C(0x4)
	struct FRotator CallFunc_K2_GetActorRotation_ReturnValue_2;  // 0x40(0xC)
	struct FRotator CallFunc_MakeRotator_ReturnValue;  // 0x4C(0xC)
	float CallFunc_BreakRotator_Roll_2;  // 0x58(0x4)
	float CallFunc_BreakRotator_Pitch_2;  // 0x5C(0x4)
	float CallFunc_BreakRotator_Yaw_2;  // 0x60(0x4)
	struct FVector CallFunc_Conv_RotatorToVector_ReturnValue;  // 0x64(0xC)
	float CallFunc_MapRangeUnclamped_ReturnValue_2;  // 0x70(0x4)
	struct FLinearColor CallFunc_Conv_VectorToLinearColor_ReturnValue;  // 0x74(0x10)
	struct FLinearColor CallFunc_GetClampedLinearColorValue_ReturnValue_2;  // 0x84(0x10)
	struct FLinearColor CallFunc_GetClampedLinearColorValue_ReturnValue_3;  // 0x94(0x10)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0xA4(0x4)
	float CallFunc_FClamp_ReturnValue;  // 0xA8(0x4)
	struct FLinearColor CallFunc_LinearColorLerp_ReturnValue;  // 0xAC(0x10)
	struct FLinearColor CallFunc_Conv_ColorToLinearColor_ReturnValue;  // 0xBC(0x10)
	char pad_204_1 : 7;  // 0xCC(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0xCC(0x1)
	char pad_205[3];  // 0xCD(0x3)
	struct FRotator CallFunc_K2_GetActorRotation_ReturnValue_3;  // 0xD0(0xC)
	struct FVector CallFunc_Conv_RotatorToVector_ReturnValue_2;  // 0xDC(0xC)
	struct FLinearColor CallFunc_Conv_VectorToLinearColor_ReturnValue_2;  // 0xE8(0x10)

}; 
