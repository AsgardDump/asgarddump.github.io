#include "SDK.h" 
 
 
void UMeshComponent::TickAtThisTime(float Time, bool bInIsRunning, bool bInBackwards, bool bInIsLooping){

	static UObject* p_TickAtThisTime = UObject::FindObject<UFunction>("Function GeometryCache.GeometryCacheComponent.TickAtThisTime");

	struct {
		float Time;
		bool bInIsRunning;
		bool bInBackwards;
		bool bInIsLooping;
	} parms;

	parms.Time = Time;
	parms.bInIsRunning = bInIsRunning;
	parms.bInBackwards = bInBackwards;
	parms.bInIsLooping = bInIsLooping;

	ProcessEvent(p_TickAtThisTime, &parms);
}

void UMeshComponent::Stop(){

	static UObject* p_Stop = UObject::FindObject<UFunction>("Function GeometryCache.GeometryCacheComponent.Stop");

	struct {
	} parms;


	ProcessEvent(p_Stop, &parms);
}

void UMeshComponent::SetStartTimeOffset(float NewStartTimeOffset){

	static UObject* p_SetStartTimeOffset = UObject::FindObject<UFunction>("Function GeometryCache.GeometryCacheComponent.SetStartTimeOffset");

	struct {
		float NewStartTimeOffset;
	} parms;

	parms.NewStartTimeOffset = NewStartTimeOffset;

	ProcessEvent(p_SetStartTimeOffset, &parms);
}

void UMeshComponent::SetPlaybackSpeed(float NewPlaybackSpeed){

	static UObject* p_SetPlaybackSpeed = UObject::FindObject<UFunction>("Function GeometryCache.GeometryCacheComponent.SetPlaybackSpeed");

	struct {
		float NewPlaybackSpeed;
	} parms;

	parms.NewPlaybackSpeed = NewPlaybackSpeed;

	ProcessEvent(p_SetPlaybackSpeed, &parms);
}

void UMeshComponent::SetMotionVectorScale(float NewMotionVectorScale){

	static UObject* p_SetMotionVectorScale = UObject::FindObject<UFunction>("Function GeometryCache.GeometryCacheComponent.SetMotionVectorScale");

	struct {
		float NewMotionVectorScale;
	} parms;

	parms.NewMotionVectorScale = NewMotionVectorScale;

	ProcessEvent(p_SetMotionVectorScale, &parms);
}

void UMeshComponent::SetLooping(bool bNewLooping){

	static UObject* p_SetLooping = UObject::FindObject<UFunction>("Function GeometryCache.GeometryCacheComponent.SetLooping");

	struct {
		bool bNewLooping;
	} parms;

	parms.bNewLooping = bNewLooping;

	ProcessEvent(p_SetLooping, &parms);
}

bool UMeshComponent::SetGeometryCache(struct UGeometryCache* NewGeomCache){

	static UObject* p_SetGeometryCache = UObject::FindObject<UFunction>("Function GeometryCache.GeometryCacheComponent.SetGeometryCache");

	struct {
		struct UGeometryCache* NewGeomCache;
		bool return_value;
	} parms;

	parms.NewGeomCache = NewGeomCache;

	ProcessEvent(p_SetGeometryCache, &parms);
	return parms.return_value;
}

void UMeshComponent::SetExtrapolateFrames(bool bNewExtrapolating){

	static UObject* p_SetExtrapolateFrames = UObject::FindObject<UFunction>("Function GeometryCache.GeometryCacheComponent.SetExtrapolateFrames");

	struct {
		bool bNewExtrapolating;
	} parms;

	parms.bNewExtrapolating = bNewExtrapolating;

	ProcessEvent(p_SetExtrapolateFrames, &parms);
}

void UMeshComponent::PlayReversedFromEnd(){

	static UObject* p_PlayReversedFromEnd = UObject::FindObject<UFunction>("Function GeometryCache.GeometryCacheComponent.PlayReversedFromEnd");

	struct {
	} parms;


	ProcessEvent(p_PlayReversedFromEnd, &parms);
}

void UMeshComponent::PlayReversed(){

	static UObject* p_PlayReversed = UObject::FindObject<UFunction>("Function GeometryCache.GeometryCacheComponent.PlayReversed");

	struct {
	} parms;


	ProcessEvent(p_PlayReversed, &parms);
}

void UMeshComponent::PlayFromStart(){

	static UObject* p_PlayFromStart = UObject::FindObject<UFunction>("Function GeometryCache.GeometryCacheComponent.PlayFromStart");

	struct {
	} parms;


	ProcessEvent(p_PlayFromStart, &parms);
}

void UMeshComponent::Play(){

	static UObject* p_Play = UObject::FindObject<UFunction>("Function GeometryCache.GeometryCacheComponent.Play");

	struct {
	} parms;


	ProcessEvent(p_Play, &parms);
}

void UMeshComponent::Pause(){

	static UObject* p_Pause = UObject::FindObject<UFunction>("Function GeometryCache.GeometryCacheComponent.Pause");

	struct {
	} parms;


	ProcessEvent(p_Pause, &parms);
}

bool UMeshComponent::IsPlayingReversed(){

	static UObject* p_IsPlayingReversed = UObject::FindObject<UFunction>("Function GeometryCache.GeometryCacheComponent.IsPlayingReversed");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_IsPlayingReversed, &parms);
	return parms.return_value;
}

bool UMeshComponent::IsPlaying(){

	static UObject* p_IsPlaying = UObject::FindObject<UFunction>("Function GeometryCache.GeometryCacheComponent.IsPlaying");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_IsPlaying, &parms);
	return parms.return_value;
}

bool UMeshComponent::IsLooping(){

	static UObject* p_IsLooping = UObject::FindObject<UFunction>("Function GeometryCache.GeometryCacheComponent.IsLooping");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_IsLooping, &parms);
	return parms.return_value;
}

bool UMeshComponent::IsExtrapolatingFrames(){

	static UObject* p_IsExtrapolatingFrames = UObject::FindObject<UFunction>("Function GeometryCache.GeometryCacheComponent.IsExtrapolatingFrames");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_IsExtrapolatingFrames, &parms);
	return parms.return_value;
}

float UMeshComponent::GetStartTimeOffset(){

	static UObject* p_GetStartTimeOffset = UObject::FindObject<UFunction>("Function GeometryCache.GeometryCacheComponent.GetStartTimeOffset");

	struct {
		float return_value;
	} parms;


	ProcessEvent(p_GetStartTimeOffset, &parms);
	return parms.return_value;
}

float UMeshComponent::GetPlaybackSpeed(){

	static UObject* p_GetPlaybackSpeed = UObject::FindObject<UFunction>("Function GeometryCache.GeometryCacheComponent.GetPlaybackSpeed");

	struct {
		float return_value;
	} parms;


	ProcessEvent(p_GetPlaybackSpeed, &parms);
	return parms.return_value;
}

float UMeshComponent::GetPlaybackDirection(){

	static UObject* p_GetPlaybackDirection = UObject::FindObject<UFunction>("Function GeometryCache.GeometryCacheComponent.GetPlaybackDirection");

	struct {
		float return_value;
	} parms;


	ProcessEvent(p_GetPlaybackDirection, &parms);
	return parms.return_value;
}

int32_t UMeshComponent::GetNumberOfFrames(){

	static UObject* p_GetNumberOfFrames = UObject::FindObject<UFunction>("Function GeometryCache.GeometryCacheComponent.GetNumberOfFrames");

	struct {
		int32_t return_value;
	} parms;


	ProcessEvent(p_GetNumberOfFrames, &parms);
	return parms.return_value;
}

float UMeshComponent::GetMotionVectorScale(){

	static UObject* p_GetMotionVectorScale = UObject::FindObject<UFunction>("Function GeometryCache.GeometryCacheComponent.GetMotionVectorScale");

	struct {
		float return_value;
	} parms;


	ProcessEvent(p_GetMotionVectorScale, &parms);
	return parms.return_value;
}

float UMeshComponent::GetDuration(){

	static UObject* p_GetDuration = UObject::FindObject<UFunction>("Function GeometryCache.GeometryCacheComponent.GetDuration");

	struct {
		float return_value;
	} parms;


	ProcessEvent(p_GetDuration, &parms);
	return parms.return_value;
}

float UMeshComponent::GetAnimationTime(){

	static UObject* p_GetAnimationTime = UObject::FindObject<UFunction>("Function GeometryCache.GeometryCacheComponent.GetAnimationTime");

	struct {
		float return_value;
	} parms;


	ProcessEvent(p_GetAnimationTime, &parms);
	return parms.return_value;
}

struct UGeometryCacheComponent* AActor::GetGeometryCacheComponent(){

	static UObject* p_GetGeometryCacheComponent = UObject::FindObject<UFunction>("Function GeometryCache.GeometryCacheActor.GetGeometryCacheComponent");

	struct {
		struct UGeometryCacheComponent* return_value;
	} parms;


	ProcessEvent(p_GetGeometryCacheComponent, &parms);
	return parms.return_value;
}

void UGeometryCacheTrack::AddMeshSample(struct FGeometryCacheMeshData& MeshData, float SampleTime){

	static UObject* p_AddMeshSample = UObject::FindObject<UFunction>("Function GeometryCache.GeometryCacheTrack_FlipbookAnimation.AddMeshSample");

	struct {
		struct FGeometryCacheMeshData& MeshData;
		float SampleTime;
	} parms;

	parms.MeshData = MeshData;
	parms.SampleTime = SampleTime;

	ProcessEvent(p_AddMeshSample, &parms);
}

void UGeometryCacheTrack::SetMesh(struct FGeometryCacheMeshData& NewMeshData){

	static UObject* p_SetMesh = UObject::FindObject<UFunction>("Function GeometryCache.GeometryCacheTrack_TransformAnimation.SetMesh");

	struct {
		struct FGeometryCacheMeshData& NewMeshData;
	} parms;

	parms.NewMeshData = NewMeshData;

	ProcessEvent(p_SetMesh, &parms);
}

void UGeometryCacheTrack::SetMesh(struct FGeometryCacheMeshData& NewMeshData){

	static UObject* p_SetMesh = UObject::FindObject<UFunction>("Function GeometryCache.GeometryCacheTrack_TransformGroupAnimation.SetMesh");

	struct {
		struct FGeometryCacheMeshData& NewMeshData;
	} parms;

	parms.NewMeshData = NewMeshData;

	ProcessEvent(p_SetMesh, &parms);
}

