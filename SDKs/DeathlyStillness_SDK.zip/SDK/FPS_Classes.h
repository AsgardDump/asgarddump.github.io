#pragma once 
#include <FPS_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass FPS.FPS_C
// Size: 0x270(Inherited: 0x260) 
struct UFPS_C : public UUserWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x260(0x8)
	struct UTextBlock* TextBlock_33;  // 0x268(0x8)

	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Function FPS.FPS_C.Tick
	void ExecuteUbergraph_FPS(int32_t EntryPoint); // Function FPS.FPS_C.ExecuteUbergraph_FPS
}; 



