#pragma once 
#include <AttackVoice_Structs.h>
 
 
 
// BlueprintGeneratedClass AttackVoice.AttackVoice_C
// Size: 0x3C(Inherited: 0x38) 
struct UAttackVoice_C : public UAnimNotify
{
	float Scale;  // 0x38(0x4)

	bool Received_Notify(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation); // Function AttackVoice.AttackVoice_C.Received_Notify
}; 



