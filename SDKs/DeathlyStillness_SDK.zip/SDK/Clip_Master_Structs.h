#pragma once 
#include "SDK.h" 
 
 
// Function Clip_Master.Clip_Master_C.ExecuteUbergraph_Clip_Master
// Size: 0x4(Inherited: 0x0) 
struct FExecuteUbergraph_Clip_Master
{
	int32_t EntryPoint;  // 0x0(0x4)

}; 
