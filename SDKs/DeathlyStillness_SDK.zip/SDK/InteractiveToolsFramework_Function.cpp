#include "SDK.h" 
 
 
bool UInterface::HasTangentVectors(){

	static UObject* p_HasTangentVectors = UObject::FindObject<UFunction>("Function InteractiveToolsFramework.GizmoAxisSource.HasTangentVectors");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_HasTangentVectors, &parms);
	return parms.return_value;
}

void UInterface::GetTangentVectors(struct FVector& TangentXOut, struct FVector& TangentYOut){

	static UObject* p_GetTangentVectors = UObject::FindObject<UFunction>("Function InteractiveToolsFramework.GizmoAxisSource.GetTangentVectors");

	struct {
		struct FVector& TangentXOut;
		struct FVector& TangentYOut;
	} parms;

	parms.TangentXOut = TangentXOut;
	parms.TangentYOut = TangentYOut;

	ProcessEvent(p_GetTangentVectors, &parms);
}

struct FVector UInterface::GetOrigin(){

	static UObject* p_GetOrigin = UObject::FindObject<UFunction>("Function InteractiveToolsFramework.GizmoAxisSource.GetOrigin");

	struct {
		struct FVector return_value;
	} parms;


	ProcessEvent(p_GetOrigin, &parms);
	return parms.return_value;
}

struct FVector UInterface::GetDirection(){

	static UObject* p_GetDirection = UObject::FindObject<UFunction>("Function InteractiveToolsFramework.GizmoAxisSource.GetDirection");

	struct {
		struct FVector return_value;
	} parms;


	ProcessEvent(p_GetDirection, &parms);
	return parms.return_value;
}

void UInterface::SetTransform(struct FTransform& NewTransform){

	static UObject* p_SetTransform = UObject::FindObject<UFunction>("Function InteractiveToolsFramework.GizmoTransformSource.SetTransform");

	struct {
		struct FTransform& NewTransform;
	} parms;

	parms.NewTransform = NewTransform;

	ProcessEvent(p_SetTransform, &parms);
}

struct FTransform UInterface::GetTransform(){

	static UObject* p_GetTransform = UObject::FindObject<UFunction>("Function InteractiveToolsFramework.GizmoTransformSource.GetTransform");

	struct {
		struct FTransform return_value;
	} parms;


	ProcessEvent(p_GetTransform, &parms);
	return parms.return_value;
}

void UInterface::SetParameter(struct FVector2D& NewValue){

	static UObject* p_SetParameter = UObject::FindObject<UFunction>("Function InteractiveToolsFramework.GizmoVec2ParameterSource.SetParameter");

	struct {
		struct FVector2D& NewValue;
	} parms;

	parms.NewValue = NewValue;

	ProcessEvent(p_SetParameter, &parms);
}

struct FVector2D UInterface::GetParameter(){

	static UObject* p_GetParameter = UObject::FindObject<UFunction>("Function InteractiveToolsFramework.GizmoVec2ParameterSource.GetParameter");

	struct {
		struct FVector2D return_value;
	} parms;


	ProcessEvent(p_GetParameter, &parms);
	return parms.return_value;
}

void UInterface::EndModify(){

	static UObject* p_EndModify = UObject::FindObject<UFunction>("Function InteractiveToolsFramework.GizmoVec2ParameterSource.EndModify");

	struct {
	} parms;


	ProcessEvent(p_EndModify, &parms);
}

void UInterface::BeginModify(){

	static UObject* p_BeginModify = UObject::FindObject<UFunction>("Function InteractiveToolsFramework.GizmoVec2ParameterSource.BeginModify");

	struct {
	} parms;


	ProcessEvent(p_BeginModify, &parms);
}

void UPrimitiveComponent::UpdateWorldLocalState(bool bWorldIn){

	static UObject* p_UpdateWorldLocalState = UObject::FindObject<UFunction>("Function InteractiveToolsFramework.GizmoBaseComponent.UpdateWorldLocalState");

	struct {
		bool bWorldIn;
	} parms;

	parms.bWorldIn = bWorldIn;

	ProcessEvent(p_UpdateWorldLocalState, &parms);
}

void UPrimitiveComponent::UpdateHoverState(bool bHoveringIn){

	static UObject* p_UpdateHoverState = UObject::FindObject<UFunction>("Function InteractiveToolsFramework.GizmoBaseComponent.UpdateHoverState");

	struct {
		bool bHoveringIn;
	} parms;

	parms.bHoveringIn = bHoveringIn;

	ProcessEvent(p_UpdateHoverState, &parms);
}

void UInterface::UpdateHoverState(bool bHovering){

	static UObject* p_UpdateHoverState = UObject::FindObject<UFunction>("Function InteractiveToolsFramework.GizmoClickTarget.UpdateHoverState");

	struct {
		bool bHovering;
	} parms;

	parms.bHovering = bHovering;

	ProcessEvent(p_UpdateHoverState, &parms);
}

void UInterface::EndUpdate(){

	static UObject* p_EndUpdate = UObject::FindObject<UFunction>("Function InteractiveToolsFramework.GizmoStateTarget.EndUpdate");

	struct {
	} parms;


	ProcessEvent(p_EndUpdate, &parms);
}

void UInterface::BeginUpdate(){

	static UObject* p_BeginUpdate = UObject::FindObject<UFunction>("Function InteractiveToolsFramework.GizmoStateTarget.BeginUpdate");

	struct {
	} parms;


	ProcessEvent(p_BeginUpdate, &parms);
}

void UInterface::SetParameter(float NewValue){

	static UObject* p_SetParameter = UObject::FindObject<UFunction>("Function InteractiveToolsFramework.GizmoFloatParameterSource.SetParameter");

	struct {
		float NewValue;
	} parms;

	parms.NewValue = NewValue;

	ProcessEvent(p_SetParameter, &parms);
}

float UInterface::GetParameter(){

	static UObject* p_GetParameter = UObject::FindObject<UFunction>("Function InteractiveToolsFramework.GizmoFloatParameterSource.GetParameter");

	struct {
		float return_value;
	} parms;


	ProcessEvent(p_GetParameter, &parms);
	return parms.return_value;
}

void UInterface::EndModify(){

	static UObject* p_EndModify = UObject::FindObject<UFunction>("Function InteractiveToolsFramework.GizmoFloatParameterSource.EndModify");

	struct {
	} parms;


	ProcessEvent(p_EndModify, &parms);
}

void UInterface::BeginModify(){

	static UObject* p_BeginModify = UObject::FindObject<UFunction>("Function InteractiveToolsFramework.GizmoFloatParameterSource.BeginModify");

	struct {
	} parms;


	ProcessEvent(p_BeginModify, &parms);
}

