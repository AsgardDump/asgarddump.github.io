#pragma once 
#include "SDK.h" 
 
 
// Function InGameGameMode.InGameGameMode_C.ExecuteUbergraph_InGameGameMode
// Size: 0x44(Inherited: 0x0) 
struct FExecuteUbergraph_InGameGameMode
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct APawn* CallFunc_GetPlayerPawn_ReturnValue;  // 0x8(0x8)
	int32_t ___int_Variable;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct APlayer_BP_C* K2Node_DynamicCast_AsPlayer_BP;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x20(0x1)
	char pad_33[3];  // 0x21(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x24(0x10)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x34(0x4)
	struct FTimerHandle CallFunc_K2_SetTimerDelegate_ReturnValue;  // 0x38(0x8)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x40(0x4)

}; 
