#pragma once 
#include <AKMReload_StartCS_Structs.h>
 
 
 
// BlueprintGeneratedClass AKMReload_StartCS.AKMReload_StartCS_C
// Size: 0x1B0(Inherited: 0x1B0) 
struct UAKMReload_StartCS_C : public UMatineeCameraShake
{

}; 



