#pragma once 
#include <HeadSpringArm_Anim_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass HeadSpringArm_Anim.HeadSpringArm_Anim_C
// Size: 0xC2C(Inherited: 0x2C0) 
struct UHeadSpringArm_Anim_C : public UAnimInstance
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x2C0(0x8)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_8;  // 0x2C8(0x80)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_7;  // 0x348(0x80)
	struct FAnimNode_BlendListByEnum AnimGraphNode_BlendListByEnum_2;  // 0x3C8(0xB0)
	struct FAnimNode_BlendListByEnum AnimGraphNode_BlendListByEnum;  // 0x478(0xB0)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_6;  // 0x528(0x80)
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool_3;  // 0x5A8(0xA0)
	struct FAnimNode_Slot AnimGraphNode_Slot;  // 0x648(0x48)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_5;  // 0x690(0x80)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_4;  // 0x710(0x80)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_3;  // 0x790(0x80)
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool_2;  // 0x810(0xA0)
	struct FAnimNode_Root AnimGraphNode_Root;  // 0x8B0(0x30)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_2;  // 0x8E0(0x80)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer;  // 0x960(0x80)
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool;  // 0x9E0(0xA0)
	struct FAnimNode_RotationOffsetBlendSpace AnimGraphNode_RotationOffsetBlendSpace;  // 0xA80(0x190)
	char CharacterState PlayerState;  // 0xC10(0x1)
	char ArmedState ArmedState;  // 0xC11(0x1)
	char pad_3090[2];  // 0xC12(0x2)
	float Speed;  // 0xC14(0x4)
	char pad_3096_1 : 7;  // 0xC18(0x1)
	bool IsCrouch? : 1;  // 0xC18(0x1)
	char pad_3097[7];  // 0xC19(0x7)
	struct APUBG_BaseCharacter_BP_C* As PUBG Base Character BP;  // 0xC20(0x8)
	float LeanDirection;  // 0xC28(0x4)

	void AnimGraph(struct FPoseLink& AnimGraph); // Function HeadSpringArm_Anim.HeadSpringArm_Anim_C.AnimGraph
	void EvaluateGraphExposedInputs_ExecuteUbergraph_HeadSpringArm_Anim_AnimGraphNode_BlendListByBool_ADAE08EA4B61A5FC4B9233BC0BC13AE6(); // Function HeadSpringArm_Anim.HeadSpringArm_Anim_C.EvaluateGraphExposedInputs_ExecuteUbergraph_HeadSpringArm_Anim_AnimGraphNode_BlendListByBool_ADAE08EA4B61A5FC4B9233BC0BC13AE6
	void EvaluateGraphExposedInputs_ExecuteUbergraph_HeadSpringArm_Anim_AnimGraphNode_BlendListByBool_CAAEEB4C431BD853504706A8D470C26A(); // Function HeadSpringArm_Anim.HeadSpringArm_Anim_C.EvaluateGraphExposedInputs_ExecuteUbergraph_HeadSpringArm_Anim_AnimGraphNode_BlendListByBool_CAAEEB4C431BD853504706A8D470C26A
	void BlueprintUpdateAnimation(float DeltaTimeX); // Function HeadSpringArm_Anim.HeadSpringArm_Anim_C.BlueprintUpdateAnimation
	void ExecuteUbergraph_HeadSpringArm_Anim(int32_t EntryPoint); // Function HeadSpringArm_Anim.HeadSpringArm_Anim_C.ExecuteUbergraph_HeadSpringArm_Anim
}; 



