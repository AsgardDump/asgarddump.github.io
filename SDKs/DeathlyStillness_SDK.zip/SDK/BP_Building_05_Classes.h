#pragma once 
#include <BP_Building_05_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Building_05.BP_Building_05_C
// Size: 0x2E0(Inherited: 0x220) 
struct ABP_Building_05_C : public AActor
{
	struct UStaticMeshComponent* StaticMesh5;  // 0x220(0x8)
	struct UStaticMeshComponent* SM_Awning3;  // 0x228(0x8)
	struct UStaticMeshComponent* StaticMesh4;  // 0x230(0x8)
	struct UStaticMeshComponent* StaticMesh3;  // 0x238(0x8)
	struct UStaticMeshComponent* SM_CurtainCurved;  // 0x240(0x8)
	struct UChildActorComponent* ChildActor8;  // 0x248(0x8)
	struct UChildActorComponent* ChildActor7;  // 0x250(0x8)
	struct UChildActorComponent* ChildActor6;  // 0x258(0x8)
	struct UChildActorComponent* ChildActor5;  // 0x260(0x8)
	struct UChildActorComponent* ChildActor4;  // 0x268(0x8)
	struct UChildActorComponent* ChildActor3;  // 0x270(0x8)
	struct UChildActorComponent* ChildActor2;  // 0x278(0x8)
	struct UChildActorComponent* ChildActor1;  // 0x280(0x8)
	struct UChildActorComponent* ChildActor;  // 0x288(0x8)
	struct UChildActorComponent* BP_Aircon;  // 0x290(0x8)
	struct UStaticMeshComponent* StaticMesh2;  // 0x298(0x8)
	struct UStaticMeshComponent* StaticMesh1;  // 0x2A0(0x8)
	struct UStaticMeshComponent* StaticMesh;  // 0x2A8(0x8)
	struct UStaticMeshComponent* SM_Curtain;  // 0x2B0(0x8)
	struct UStaticMeshComponent* SM_Building_05_Ground;  // 0x2B8(0x8)
	struct UStaticMeshComponent* SM_Building_05_CurvedWindow;  // 0x2C0(0x8)
	struct UStaticMeshComponent* SM_Building_05_Window;  // 0x2C8(0x8)
	struct UStaticMeshComponent* SM_Building_05;  // 0x2D0(0x8)
	struct USceneComponent* Scene;  // 0x2D8(0x8)

}; 



