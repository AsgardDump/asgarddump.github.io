#pragma once 
#include <AKM_BP3_Structs.h>
 
 
 
// BlueprintGeneratedClass AKM_BP3.AKM_BP3_C
// Size: 0x2B8(Inherited: 0x2B0) 
struct AAKM_BP3_C : public APickUpMaster_C
{
	struct USkeletalMeshComponent* AK-47_Mag_setting;  // 0x2B0(0x8)

}; 



