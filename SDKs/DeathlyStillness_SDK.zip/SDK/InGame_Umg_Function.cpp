#include "SDK.h" 
 
 
struct FText UUserWidget::GetText_3(){

	static UObject* p_GetText_3 = UObject::FindObject<UFunction>("Function InGame_Umg.InGame_Umg_C.GetText_3");

	struct {
		struct FText return_value;
	} parms;


	ProcessEvent(p_GetText_3, &parms);
	return parms.return_value;
}

struct FText UUserWidget::GetText_1(){

	static UObject* p_GetText_1 = UObject::FindObject<UFunction>("Function InGame_Umg.InGame_Umg_C.GetText_1");

	struct {
		struct FText return_value;
	} parms;


	ProcessEvent(p_GetText_1, &parms);
	return parms.return_value;
}

struct FLinearColor UUserWidget::GetFillColorAndOpacity_1(){

	static UObject* p_GetFillColorAndOpacity_1 = UObject::FindObject<UFunction>("Function InGame_Umg.InGame_Umg_C.GetFillColorAndOpacity_1");

	struct {
		struct FLinearColor return_value;
	} parms;


	ProcessEvent(p_GetFillColorAndOpacity_1, &parms);
	return parms.return_value;
}

float UUserWidget::GetPercent_1(){

	static UObject* p_GetPercent_1 = UObject::FindObject<UFunction>("Function InGame_Umg.InGame_Umg_C.GetPercent_1");

	struct {
		float return_value;
	} parms;


	ProcessEvent(p_GetPercent_1, &parms);
	return parms.return_value;
}

struct FText UUserWidget::GetText_2(){

	static UObject* p_GetText_2 = UObject::FindObject<UFunction>("Function InGame_Umg.InGame_Umg_C.GetText_2");

	struct {
		struct FText return_value;
	} parms;


	ProcessEvent(p_GetText_2, &parms);
	return parms.return_value;
}

void UUserWidget::QuestTip_Evenet(){

	static UObject* p_QuestTip_Evenet = UObject::FindObject<UFunction>("Function InGame_Umg.InGame_Umg_C.QuestTip_Evenet");

	struct {
	} parms;


	ProcessEvent(p_QuestTip_Evenet, &parms);
}

void UUserWidget::QuestStart_Event(){

	static UObject* p_QuestStart_Event = UObject::FindObject<UFunction>("Function InGame_Umg.InGame_Umg_C.QuestStart_Event");

	struct {
	} parms;


	ProcessEvent(p_QuestStart_Event, &parms);
}

void UUserWidget::HitHead(){

	static UObject* p_HitHead = UObject::FindObject<UFunction>("Function InGame_Umg.InGame_Umg_C.HitHead");

	struct {
	} parms;


	ProcessEvent(p_HitHead, &parms);
}

void UUserWidget::HitZombie(){

	static UObject* p_HitZombie = UObject::FindObject<UFunction>("Function InGame_Umg.InGame_Umg_C.HitZombie");

	struct {
	} parms;


	ProcessEvent(p_HitZombie, &parms);
}

void UUserWidget::DamageEffect(){

	static UObject* p_DamageEffect = UObject::FindObject<UFunction>("Function InGame_Umg.InGame_Umg_C.DamageEffect");

	struct {
	} parms;


	ProcessEvent(p_DamageEffect, &parms);
}

void UUserWidget::(char EUMGSequencePlayMode PlayMode){

	static UObject* p_ = UObject::FindObject<UFunction>("Function InGame_Umg.InGame_Umg_C.");

	struct {
		char EUMGSequencePlayMode PlayMode;
	} parms;

	parms.PlayMode = PlayMode;

	ProcessEvent(p_, &parms);
}

void UUserWidget::Tick(struct FGeometry MyGeometry, float InDeltaTime){

	static UObject* p_Tick = UObject::FindObject<UFunction>("Function InGame_Umg.InGame_Umg_C.Tick");

	struct {
		struct FGeometry MyGeometry;
		float InDeltaTime;
	} parms;

	parms.MyGeometry = MyGeometry;
	parms.InDeltaTime = InDeltaTime;

	ProcessEvent(p_Tick, &parms);
}

void UUserWidget::DeadScreen(char EUMGSequencePlayMode PlayMode){

	static UObject* p_DeadScreen = UObject::FindObject<UFunction>("Function InGame_Umg.InGame_Umg_C.DeadScreen");

	struct {
		char EUMGSequencePlayMode PlayMode;
	} parms;

	parms.PlayMode = PlayMode;

	ProcessEvent(p_DeadScreen, &parms);
}

void UUserWidget::(uint8_t  , uint8_t  DOT){

	static UObject* p_ = UObject::FindObject<UFunction>("Function InGame_Umg.InGame_Umg_C.");

	struct {
		uint8_t  ;
		uint8_t  DOT;
	} parms;

	parms. = ;
	parms.DOT = DOT;

	ProcessEvent(p_, &parms);
}

void UUserWidget::(){

	static UObject* p_ = UObject::FindObject<UFunction>("Function InGame_Umg.InGame_Umg_C.");

	struct {
	} parms;


	ProcessEvent(p_, &parms);
}

void UUserWidget::(){

	static UObject* p_ = UObject::FindObject<UFunction>("Function InGame_Umg.InGame_Umg_C.");

	struct {
	} parms;


	ProcessEvent(p_, &parms);
}

void UUserWidget::(char EUMGSequencePlayMode PlayMode){

	static UObject* p_ = UObject::FindObject<UFunction>("Function InGame_Umg.InGame_Umg_C.");

	struct {
		char EUMGSequencePlayMode PlayMode;
	} parms;

	parms.PlayMode = PlayMode;

	ProcessEvent(p_, &parms);
}

void UUserWidget::(){

	static UObject* p_ = UObject::FindObject<UFunction>("Function InGame_Umg.InGame_Umg_C.");

	struct {
	} parms;


	ProcessEvent(p_, &parms);
}

void UUserWidget::Construct(){

	static UObject* p_Construct = UObject::FindObject<UFunction>("Function InGame_Umg.InGame_Umg_C.Construct");

	struct {
	} parms;


	ProcessEvent(p_Construct, &parms);
}

void UUserWidget::CrosshairFade_Event(char EUMGSequencePlayMode PlayMode){

	static UObject* p_CrosshairFade_Event = UObject::FindObject<UFunction>("Function InGame_Umg.InGame_Umg_C.CrosshairFade_Event");

	struct {
		char EUMGSequencePlayMode PlayMode;
	} parms;

	parms.PlayMode = PlayMode;

	ProcessEvent(p_CrosshairFade_Event, &parms);
}

void UUserWidget::(){

	static UObject* p_ = UObject::FindObject<UFunction>("Function InGame_Umg.InGame_Umg_C.");

	struct {
	} parms;


	ProcessEvent(p_, &parms);
}

void UUserWidget::(){

	static UObject* p_ = UObject::FindObject<UFunction>("Function InGame_Umg.InGame_Umg_C.");

	struct {
	} parms;


	ProcessEvent(p_, &parms);
}

void UUserWidget::ExecuteUbergraph_InGame_Umg(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph_InGame_Umg = UObject::FindObject<UFunction>("Function InGame_Umg.InGame_Umg_C.ExecuteUbergraph_InGame_Umg");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph_InGame_Umg, &parms);
}

