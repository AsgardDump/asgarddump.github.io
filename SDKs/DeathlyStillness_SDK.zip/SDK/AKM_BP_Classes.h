#pragma once 
#include <AKM_BP_Structs.h>
 
 
 
// BlueprintGeneratedClass AKM_BP.AKM_BP_C
// Size: 0x569(Inherited: 0x569) 
struct AAKM_BP_C : public AWeapon_Master_C
{

}; 



