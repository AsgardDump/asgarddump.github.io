#pragma once 
#include "SDK.h" 
 
 
// Function CustomMapping_Slot.CustomMapping_Slot_C.FindText
// Size: 0x70(Inherited: 0x0) 
struct FFindText
{
	struct UInputKeySelector* ;  // 0x0(0x8)
	struct FText ReturnValue;  // 0x8(0x18)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool ___bool_Variable : 1;  // 0x20(0x1)
	char pad_33_1 : 7;  // 0x21(0x1)
	bool CallFunc_GetIsSelectingKey_ReturnValue : 1;  // 0x21(0x1)
	char pad_34_1 : 7;  // 0x22(0x1)
	bool ___bool_Variable_2 : 1;  // 0x22(0x1)
	char pad_35_1 : 7;  // 0x23(0x1)
	bool CallFunc_Key_IsValid_ReturnValue : 1;  // 0x23(0x1)
	char pad_36[4];  // 0x24(0x4)
	struct FText CallFunc_Key_GetDisplayName_ReturnValue;  // 0x28(0x18)
	struct FText K2Node_Select_Default;  // 0x40(0x18)
	struct FText K2Node_Select_Default_2;  // 0x58(0x18)

}; 
// Function CustomMapping_Slot.CustomMapping_Slot_C.ExecuteUbergraph_CustomMapping_Slot
// Size: 0x191(Inherited: 0x0) 
struct FExecuteUbergraph_CustomMapping_Slot
{
	int32_t EntryPoint;  // 0x0(0x4)
	struct FGeometry K2Node_Event_MyGeometry;  // 0x4(0x38)
	char pad_60[4];  // 0x3C(0x4)
	struct FPointerEvent K2Node_Event_MouseEvent_2;  // 0x40(0x70)
	struct FPointerEvent K2Node_Event_MouseEvent;  // 0xB0(0x70)
	struct FInputChord K2Node_ComponentBoundEvent_SelectedKey_2;  // 0x120(0x20)
	struct FText CallFunc_FindText_ReturnValue;  // 0x140(0x18)
	struct FInputChord K2Node_ComponentBoundEvent_SelectedKey;  // 0x158(0x20)
	struct FText CallFunc_FindText_ReturnValue_2;  // 0x178(0x18)
	char pad_400_1 : 7;  // 0x190(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x190(0x1)

}; 
// Function CustomMapping_Slot.CustomMapping_Slot_C.BndEvt__CustomMapping_Slot_InputKeySelector2_K2Node_ComponentBoundEvent_4_OnKeySelected__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FBndEvt__CustomMapping_Slot_InputKeySelector2_K2Node_ComponentBoundEvent_4_OnKeySelected__DelegateSignature
{
	struct FInputChord SelectedKey;  // 0x0(0x20)

}; 
// Function CustomMapping_Slot.CustomMapping_Slot_C.BndEvt__CustomMapping_Slot_InputKeySelector1_K2Node_ComponentBoundEvent_2_OnKeySelected__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FBndEvt__CustomMapping_Slot_InputKeySelector1_K2Node_ComponentBoundEvent_2_OnKeySelected__DelegateSignature
{
	struct FInputChord SelectedKey;  // 0x0(0x20)

}; 
// Function CustomMapping_Slot.CustomMapping_Slot_C.OnMouseLeave
// Size: 0x70(Inherited: 0x70) 
struct FOnMouseLeave : public FOnMouseLeave
{
	struct FPointerEvent MouseEvent;  // 0x0(0x70)

}; 
// Function CustomMapping_Slot.CustomMapping_Slot_C.OnMouseEnter
// Size: 0xA8(Inherited: 0xA8) 
struct FOnMouseEnter : public FOnMouseEnter
{
	struct FGeometry MyGeometry;  // 0x0(0x38)
	struct FPointerEvent MouseEvent;  // 0x38(0x70)

}; 
// Function CustomMapping_Slot.CustomMapping_Slot_C.RemoveMapping
// Size: 0x78(Inherited: 0x0) 
struct FRemoveMapping
{
	struct FInputChord InputChord;  // 0x0(0x20)
	struct UInputSettings* CallFunc_GetInputSettings_ReturnValue;  // 0x20(0x8)
	struct FInputActionKeyMapping K2Node_MakeStruct_InputActionKeyMapping;  // 0x28(0x28)
	struct FInputAxisKeyMapping K2Node_MakeStruct_InputAxisKeyMapping;  // 0x50(0x28)

}; 
// Function CustomMapping_Slot.CustomMapping_Slot_C.AddMapping
// Size: 0x78(Inherited: 0x0) 
struct FAddMapping
{
	struct FInputChord InputChord;  // 0x0(0x20)
	struct UInputSettings* CallFunc_GetInputSettings_ReturnValue;  // 0x20(0x8)
	struct FInputActionKeyMapping K2Node_MakeStruct_InputActionKeyMapping;  // 0x28(0x28)
	struct FInputAxisKeyMapping K2Node_MakeStruct_InputAxisKeyMapping;  // 0x50(0x28)

}; 
