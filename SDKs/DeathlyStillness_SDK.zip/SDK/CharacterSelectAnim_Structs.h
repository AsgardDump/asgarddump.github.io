#pragma once 
#include "SDK.h" 
 
 
// Function CharacterSelectAnim.CharacterSelectAnim_C.ExecuteUbergraph_CharacterSelectAnim
// Size: 0x4(Inherited: 0x0) 
struct FExecuteUbergraph_CharacterSelectAnim
{
	int32_t EntryPoint;  // 0x0(0x4)

}; 
// Function CharacterSelectAnim.CharacterSelectAnim_C.AnimGraph
// Size: 0x10(Inherited: 0x0) 
struct FAnimGraph
{
	struct FPoseLink AnimGraph;  // 0x0(0x10)

}; 
