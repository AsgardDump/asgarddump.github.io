#pragma once 
#include "SDK.h" 
 
 
// Function CommonFunction.CommonFunction_C.ShowFPS
// Size: 0x61(Inherited: 0x0) 
struct FShowFPS
{
	int32_t Int;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UObject* __WorldContext;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool K2Node_SwitchInteger_CmpSuccess : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct UFPS_C* CallFunc_Create_ReturnValue;  // 0x18(0x8)
	struct TArray<struct UFPS_C*> CallFunc_GetAllWidgetsOfClass_FoundWidgets;  // 0x20(0x10)
	struct UFPS_C* CallFunc_Array_Get_Item;  // 0x30(0x8)
	struct TArray<struct UFPS_C*> CallFunc_GetAllWidgetsOfClass_FoundWidgets_2;  // 0x38(0x10)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)
	struct UFPS_C* CallFunc_Array_Get_Item_2;  // 0x50(0x8)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x58(0x1)
	char pad_89[3];  // 0x59(0x3)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x5C(0x4)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue : 1;  // 0x60(0x1)

}; 
