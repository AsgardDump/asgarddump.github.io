#pragma once 
#include <InGameGameMode_Structs.h>
 
 
 
// BlueprintGeneratedClass InGameGameMode.InGameGameMode_C
// Size: 0x2D4(Inherited: 0x2C0) 
struct AInGameGameMode_C : public AGameModeBase
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x2C0(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x2C8(0x8)
	int32_t Time;  // 0x2D0(0x4)

	void ReceiveBeginPlay(); // Function InGameGameMode.InGameGameMode_C.ReceiveBeginPlay
	void (); // Function InGameGameMode.InGameGameMode_C.
	void (); // Function InGameGameMode.InGameGameMode_C.
	void ExecuteUbergraph_InGameGameMode(int32_t EntryPoint); // Function InGameGameMode.InGameGameMode_C.ExecuteUbergraph_InGameGameMode
}; 



