#pragma once 
#include <DatasmithGLTFTranslator_Structs.h>
 
 
 
// Class DatasmithGLTFTranslator.DatasmithGLTFImportOptions
// Size: 0x30(Inherited: 0x28) 
struct UDatasmithGLTFImportOptions : public UDatasmithOptionsBase
{
	char pad_40_1 : 7;  // 0x28(0x1)
	bool bGenerateLightmapUVs : 1;  // 0x28(0x1)
	char pad_41[3];  // 0x29(0x3)
	float ImportScale;  // 0x2C(0x4)

}; 



