#include "SDK.h" 
 
 
void USceneComponent::SortTrailingEvents(struct TArray<struct FChaosTrailingEventData>& TrailingEvents, uint8_t  SortMethod){

	static UObject* p_SortTrailingEvents = UObject::FindObject<UFunction>("Function GeometryCollectionEngine.ChaosDestructionListener.SortTrailingEvents");

	struct {
		struct TArray<struct FChaosTrailingEventData>& TrailingEvents;
		uint8_t  SortMethod;
	} parms;

	parms.TrailingEvents = TrailingEvents;
	parms.SortMethod = SortMethod;

	ProcessEvent(p_SortTrailingEvents, &parms);
}

void USceneComponent::SortCollisionEvents(struct TArray<struct FChaosCollisionEventData>& CollisionEvents, uint8_t  SortMethod){

	static UObject* p_SortCollisionEvents = UObject::FindObject<UFunction>("Function GeometryCollectionEngine.ChaosDestructionListener.SortCollisionEvents");

	struct {
		struct TArray<struct FChaosCollisionEventData>& CollisionEvents;
		uint8_t  SortMethod;
	} parms;

	parms.CollisionEvents = CollisionEvents;
	parms.SortMethod = SortMethod;

	ProcessEvent(p_SortCollisionEvents, &parms);
}

void USceneComponent::SortBreakingEvents(struct TArray<struct FChaosBreakingEventData>& BreakingEvents, uint8_t  SortMethod){

	static UObject* p_SortBreakingEvents = UObject::FindObject<UFunction>("Function GeometryCollectionEngine.ChaosDestructionListener.SortBreakingEvents");

	struct {
		struct TArray<struct FChaosBreakingEventData>& BreakingEvents;
		uint8_t  SortMethod;
	} parms;

	parms.BreakingEvents = BreakingEvents;
	parms.SortMethod = SortMethod;

	ProcessEvent(p_SortBreakingEvents, &parms);
}

void USceneComponent::SetTrailingEventRequestSettings(struct FChaosTrailingEventRequestSettings& InSettings){

	static UObject* p_SetTrailingEventRequestSettings = UObject::FindObject<UFunction>("Function GeometryCollectionEngine.ChaosDestructionListener.SetTrailingEventRequestSettings");

	struct {
		struct FChaosTrailingEventRequestSettings& InSettings;
	} parms;

	parms.InSettings = InSettings;

	ProcessEvent(p_SetTrailingEventRequestSettings, &parms);
}

void USceneComponent::SetTrailingEventEnabled(bool bIsEnabled){

	static UObject* p_SetTrailingEventEnabled = UObject::FindObject<UFunction>("Function GeometryCollectionEngine.ChaosDestructionListener.SetTrailingEventEnabled");

	struct {
		bool bIsEnabled;
	} parms;

	parms.bIsEnabled = bIsEnabled;

	ProcessEvent(p_SetTrailingEventEnabled, &parms);
}

void USceneComponent::SetCollisionEventRequestSettings(struct FChaosCollisionEventRequestSettings& InSettings){

	static UObject* p_SetCollisionEventRequestSettings = UObject::FindObject<UFunction>("Function GeometryCollectionEngine.ChaosDestructionListener.SetCollisionEventRequestSettings");

	struct {
		struct FChaosCollisionEventRequestSettings& InSettings;
	} parms;

	parms.InSettings = InSettings;

	ProcessEvent(p_SetCollisionEventRequestSettings, &parms);
}

void USceneComponent::SetCollisionEventEnabled(bool bIsEnabled){

	static UObject* p_SetCollisionEventEnabled = UObject::FindObject<UFunction>("Function GeometryCollectionEngine.ChaosDestructionListener.SetCollisionEventEnabled");

	struct {
		bool bIsEnabled;
	} parms;

	parms.bIsEnabled = bIsEnabled;

	ProcessEvent(p_SetCollisionEventEnabled, &parms);
}

void USceneComponent::SetBreakingEventRequestSettings(struct FChaosBreakingEventRequestSettings& InSettings){

	static UObject* p_SetBreakingEventRequestSettings = UObject::FindObject<UFunction>("Function GeometryCollectionEngine.ChaosDestructionListener.SetBreakingEventRequestSettings");

	struct {
		struct FChaosBreakingEventRequestSettings& InSettings;
	} parms;

	parms.InSettings = InSettings;

	ProcessEvent(p_SetBreakingEventRequestSettings, &parms);
}

void USceneComponent::SetBreakingEventEnabled(bool bIsEnabled){

	static UObject* p_SetBreakingEventEnabled = UObject::FindObject<UFunction>("Function GeometryCollectionEngine.ChaosDestructionListener.SetBreakingEventEnabled");

	struct {
		bool bIsEnabled;
	} parms;

	parms.bIsEnabled = bIsEnabled;

	ProcessEvent(p_SetBreakingEventEnabled, &parms);
}

void USceneComponent::RemoveGeometryCollectionActor(struct AGeometryCollectionActor* GeometryCollectionActor){

	static UObject* p_RemoveGeometryCollectionActor = UObject::FindObject<UFunction>("Function GeometryCollectionEngine.ChaosDestructionListener.RemoveGeometryCollectionActor");

	struct {
		struct AGeometryCollectionActor* GeometryCollectionActor;
	} parms;

	parms.GeometryCollectionActor = GeometryCollectionActor;

	ProcessEvent(p_RemoveGeometryCollectionActor, &parms);
}

void USceneComponent::RemoveChaosSolverActor(struct AChaosSolverActor* ChaosSolverActor){

	static UObject* p_RemoveChaosSolverActor = UObject::FindObject<UFunction>("Function GeometryCollectionEngine.ChaosDestructionListener.RemoveChaosSolverActor");

	struct {
		struct AChaosSolverActor* ChaosSolverActor;
	} parms;

	parms.ChaosSolverActor = ChaosSolverActor;

	ProcessEvent(p_RemoveChaosSolverActor, &parms);
}

bool USceneComponent::IsEventListening(){

	static UObject* p_IsEventListening = UObject::FindObject<UFunction>("Function GeometryCollectionEngine.ChaosDestructionListener.IsEventListening");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_IsEventListening, &parms);
	return parms.return_value;
}

void USceneComponent::AddGeometryCollectionActor(struct AGeometryCollectionActor* GeometryCollectionActor){

	static UObject* p_AddGeometryCollectionActor = UObject::FindObject<UFunction>("Function GeometryCollectionEngine.ChaosDestructionListener.AddGeometryCollectionActor");

	struct {
		struct AGeometryCollectionActor* GeometryCollectionActor;
	} parms;

	parms.GeometryCollectionActor = GeometryCollectionActor;

	ProcessEvent(p_AddGeometryCollectionActor, &parms);
}

void USceneComponent::AddChaosSolverActor(struct AChaosSolverActor* ChaosSolverActor){

	static UObject* p_AddChaosSolverActor = UObject::FindObject<UFunction>("Function GeometryCollectionEngine.ChaosDestructionListener.AddChaosSolverActor");

	struct {
		struct AChaosSolverActor* ChaosSolverActor;
	} parms;

	parms.ChaosSolverActor = ChaosSolverActor;

	ProcessEvent(p_AddChaosSolverActor, &parms);
}

bool AActor::RaycastSingle(struct FVector Start, struct FVector End, struct FHitResult& OutHit){

	static UObject* p_RaycastSingle = UObject::FindObject<UFunction>("Function GeometryCollectionEngine.GeometryCollectionActor.RaycastSingle");

	struct {
		struct FVector Start;
		struct FVector End;
		struct FHitResult& OutHit;
		bool return_value;
	} parms;

	parms.Start = Start;
	parms.End = End;
	parms.OutHit = OutHit;

	ProcessEvent(p_RaycastSingle, &parms);
	return parms.return_value;
}

void UActorComponent::ReceivePhysicsCollision(struct FChaosPhysicsCollisionInfo& CollisionInfo){

	static UObject* p_ReceivePhysicsCollision = UObject::FindObject<UFunction>("Function GeometryCollectionEngine.StaticMeshSimulationComponent.ReceivePhysicsCollision");

	struct {
		struct FChaosPhysicsCollisionInfo& CollisionInfo;
	} parms;

	parms.CollisionInfo = CollisionInfo;

	ProcessEvent(p_ReceivePhysicsCollision, &parms);
}

void UActorComponent::ForceRecreatePhysicsState(){

	static UObject* p_ForceRecreatePhysicsState = UObject::FindObject<UFunction>("Function GeometryCollectionEngine.StaticMeshSimulationComponent.ForceRecreatePhysicsState");

	struct {
	} parms;


	ProcessEvent(p_ForceRecreatePhysicsState, &parms);
}

void UMeshComponent::SetNotifyBreaks(bool bNewNotifyBreaks){

	static UObject* p_SetNotifyBreaks = UObject::FindObject<UFunction>("Function GeometryCollectionEngine.GeometryCollectionComponent.SetNotifyBreaks");

	struct {
		bool bNewNotifyBreaks;
	} parms;

	parms.bNewNotifyBreaks = bNewNotifyBreaks;

	ProcessEvent(p_SetNotifyBreaks, &parms);
}

void UMeshComponent::ReceivePhysicsCollision(struct FChaosPhysicsCollisionInfo& CollisionInfo){

	static UObject* p_ReceivePhysicsCollision = UObject::FindObject<UFunction>("Function GeometryCollectionEngine.GeometryCollectionComponent.ReceivePhysicsCollision");

	struct {
		struct FChaosPhysicsCollisionInfo& CollisionInfo;
	} parms;

	parms.CollisionInfo = CollisionInfo;

	ProcessEvent(p_ReceivePhysicsCollision, &parms);
}

void UMeshComponent::OnRep_RepData(struct FGeometryCollectionRepData& OldData){

	static UObject* p_OnRep_RepData = UObject::FindObject<UFunction>("Function GeometryCollectionEngine.GeometryCollectionComponent.OnRep_RepData");

	struct {
		struct FGeometryCollectionRepData& OldData;
	} parms;

	parms.OldData = OldData;

	ProcessEvent(p_OnRep_RepData, &parms);
}

void UMeshComponent::NotifyGeometryCollectionPhysicsStateChange__DelegateSignature(struct UGeometryCollectionComponent* FracturedComponent){

	static UObject* p_NotifyGeometryCollectionPhysicsStateChange__DelegateSignature = UObject::FindObject<UFunction>("DelegateFunction GeometryCollectionEngine.GeometryCollectionComponent.NotifyGeometryCollectionPhysicsStateChange__DelegateSignature");

	struct {
		struct UGeometryCollectionComponent* FracturedComponent;
	} parms;

	parms.FracturedComponent = FracturedComponent;

	ProcessEvent(p_NotifyGeometryCollectionPhysicsStateChange__DelegateSignature, &parms);
}

void UMeshComponent::NotifyGeometryCollectionPhysicsLoadingStateChange__DelegateSignature(struct UGeometryCollectionComponent* FracturedComponent){

	static UObject* p_NotifyGeometryCollectionPhysicsLoadingStateChange__DelegateSignature = UObject::FindObject<UFunction>("DelegateFunction GeometryCollectionEngine.GeometryCollectionComponent.NotifyGeometryCollectionPhysicsLoadingStateChange__DelegateSignature");

	struct {
		struct UGeometryCollectionComponent* FracturedComponent;
	} parms;

	parms.FracturedComponent = FracturedComponent;

	ProcessEvent(p_NotifyGeometryCollectionPhysicsLoadingStateChange__DelegateSignature, &parms);
}

void UMeshComponent::NetAbandonCluster(int32_t TransformIndex){

	static UObject* p_NetAbandonCluster = UObject::FindObject<UFunction>("Function GeometryCollectionEngine.GeometryCollectionComponent.NetAbandonCluster");

	struct {
		int32_t TransformIndex;
	} parms;

	parms.TransformIndex = TransformIndex;

	ProcessEvent(p_NetAbandonCluster, &parms);
}

void UMeshComponent::ApplyPhysicsField(bool Enabled, uint8_t  Target, struct UFieldSystemMetaData* MetaData, struct UFieldNodeBase* Field){

	static UObject* p_ApplyPhysicsField = UObject::FindObject<UFunction>("Function GeometryCollectionEngine.GeometryCollectionComponent.ApplyPhysicsField");

	struct {
		bool Enabled;
		uint8_t  Target;
		struct UFieldSystemMetaData* MetaData;
		struct UFieldNodeBase* Field;
	} parms;

	parms.Enabled = Enabled;
	parms.Target = Target;
	parms.MetaData = MetaData;
	parms.Field = Field;

	ProcessEvent(p_ApplyPhysicsField, &parms);
}

void UMeshComponent::ApplyKinematicField(float Radius, struct FVector Position){

	static UObject* p_ApplyKinematicField = UObject::FindObject<UFunction>("Function GeometryCollectionEngine.GeometryCollectionComponent.ApplyKinematicField");

	struct {
		float Radius;
		struct FVector Position;
	} parms;

	parms.Radius = Radius;
	parms.Position = Position;

	ProcessEvent(p_ApplyKinematicField, &parms);
}

void UActorComponent::ReceivePhysicsCollision(struct FChaosPhysicsCollisionInfo& CollisionInfo){

	static UObject* p_ReceivePhysicsCollision = UObject::FindObject<UFunction>("Function GeometryCollectionEngine.SkeletalMeshSimulationComponent.ReceivePhysicsCollision");

	struct {
		struct FChaosPhysicsCollisionInfo& CollisionInfo;
	} parms;

	parms.CollisionInfo = CollisionInfo;

	ProcessEvent(p_ReceivePhysicsCollision, &parms);
}

