#include "SDK.h" 
 
 
struct FText UUserWidget::FindText(struct UInputKeySelector* ){

	static UObject* p_FindText = UObject::FindObject<UFunction>("Function CustomMapping_Slot.CustomMapping_Slot_C.FindText");

	struct {
		struct UInputKeySelector* ;
		struct FText return_value;
	} parms;

	parms. = ;

	ProcessEvent(p_FindText, &parms);
	return parms.return_value;
}

void UUserWidget::AddMapping(struct FInputChord& InputChord){

	static UObject* p_AddMapping = UObject::FindObject<UFunction>("Function CustomMapping_Slot.CustomMapping_Slot_C.AddMapping");

	struct {
		struct FInputChord& InputChord;
	} parms;

	parms.InputChord = InputChord;

	ProcessEvent(p_AddMapping, &parms);
}

void UUserWidget::RemoveMapping(struct FInputChord& InputChord){

	static UObject* p_RemoveMapping = UObject::FindObject<UFunction>("Function CustomMapping_Slot.CustomMapping_Slot_C.RemoveMapping");

	struct {
		struct FInputChord& InputChord;
	} parms;

	parms.InputChord = InputChord;

	ProcessEvent(p_RemoveMapping, &parms);
}

void UUserWidget::Construct(){

	static UObject* p_Construct = UObject::FindObject<UFunction>("Function CustomMapping_Slot.CustomMapping_Slot_C.Construct");

	struct {
	} parms;


	ProcessEvent(p_Construct, &parms);
}

void UUserWidget::OnMouseEnter(struct FGeometry MyGeometry, struct FPointerEvent& MouseEvent){

	static UObject* p_OnMouseEnter = UObject::FindObject<UFunction>("Function CustomMapping_Slot.CustomMapping_Slot_C.OnMouseEnter");

	struct {
		struct FGeometry MyGeometry;
		struct FPointerEvent& MouseEvent;
	} parms;

	parms.MyGeometry = MyGeometry;
	parms.MouseEvent = MouseEvent;

	ProcessEvent(p_OnMouseEnter, &parms);
}

void UUserWidget::OnMouseLeave(struct FPointerEvent& MouseEvent){

	static UObject* p_OnMouseLeave = UObject::FindObject<UFunction>("Function CustomMapping_Slot.CustomMapping_Slot_C.OnMouseLeave");

	struct {
		struct FPointerEvent& MouseEvent;
	} parms;

	parms.MouseEvent = MouseEvent;

	ProcessEvent(p_OnMouseLeave, &parms);
}

void UUserWidget::BndEvt__CustomMapping_Slot_InputKeySelector1_K2Node_ComponentBoundEvent_2_OnKeySelected__DelegateSignature(struct FInputChord SelectedKey){

	static UObject* p_BndEvt__CustomMapping_Slot_InputKeySelector1_K2Node_ComponentBoundEvent_2_OnKeySelected__DelegateSignature = UObject::FindObject<UFunction>("Function CustomMapping_Slot.CustomMapping_Slot_C.BndEvt__CustomMapping_Slot_InputKeySelector1_K2Node_ComponentBoundEvent_2_OnKeySelected__DelegateSignature");

	struct {
		struct FInputChord SelectedKey;
	} parms;

	parms.SelectedKey = SelectedKey;

	ProcessEvent(p_BndEvt__CustomMapping_Slot_InputKeySelector1_K2Node_ComponentBoundEvent_2_OnKeySelected__DelegateSignature, &parms);
}

void UUserWidget::BndEvt__CustomMapping_Slot_InputKeySelector1_K2Node_ComponentBoundEvent_3_OnIsSelectingKeyChanged__DelegateSignature(){

	static UObject* p_BndEvt__CustomMapping_Slot_InputKeySelector1_K2Node_ComponentBoundEvent_3_OnIsSelectingKeyChanged__DelegateSignature = UObject::FindObject<UFunction>("Function CustomMapping_Slot.CustomMapping_Slot_C.BndEvt__CustomMapping_Slot_InputKeySelector1_K2Node_ComponentBoundEvent_3_OnIsSelectingKeyChanged__DelegateSignature");

	struct {
	} parms;


	ProcessEvent(p_BndEvt__CustomMapping_Slot_InputKeySelector1_K2Node_ComponentBoundEvent_3_OnIsSelectingKeyChanged__DelegateSignature, &parms);
}

void UUserWidget::BndEvt__CustomMapping_Slot_InputKeySelector2_K2Node_ComponentBoundEvent_4_OnKeySelected__DelegateSignature(struct FInputChord SelectedKey){

	static UObject* p_BndEvt__CustomMapping_Slot_InputKeySelector2_K2Node_ComponentBoundEvent_4_OnKeySelected__DelegateSignature = UObject::FindObject<UFunction>("Function CustomMapping_Slot.CustomMapping_Slot_C.BndEvt__CustomMapping_Slot_InputKeySelector2_K2Node_ComponentBoundEvent_4_OnKeySelected__DelegateSignature");

	struct {
		struct FInputChord SelectedKey;
	} parms;

	parms.SelectedKey = SelectedKey;

	ProcessEvent(p_BndEvt__CustomMapping_Slot_InputKeySelector2_K2Node_ComponentBoundEvent_4_OnKeySelected__DelegateSignature, &parms);
}

void UUserWidget::BndEvt__CustomMapping_Slot_InputKeySelector2_K2Node_ComponentBoundEvent_5_OnIsSelectingKeyChanged__DelegateSignature(){

	static UObject* p_BndEvt__CustomMapping_Slot_InputKeySelector2_K2Node_ComponentBoundEvent_5_OnIsSelectingKeyChanged__DelegateSignature = UObject::FindObject<UFunction>("Function CustomMapping_Slot.CustomMapping_Slot_C.BndEvt__CustomMapping_Slot_InputKeySelector2_K2Node_ComponentBoundEvent_5_OnIsSelectingKeyChanged__DelegateSignature");

	struct {
	} parms;


	ProcessEvent(p_BndEvt__CustomMapping_Slot_InputKeySelector2_K2Node_ComponentBoundEvent_5_OnIsSelectingKeyChanged__DelegateSignature, &parms);
}

void UUserWidget::CanMapping(){

	static UObject* p_CanMapping = UObject::FindObject<UFunction>("Function CustomMapping_Slot.CustomMapping_Slot_C.CanMapping");

	struct {
	} parms;


	ProcessEvent(p_CanMapping, &parms);
}

void UUserWidget::StopMapping(){

	static UObject* p_StopMapping = UObject::FindObject<UFunction>("Function CustomMapping_Slot.CustomMapping_Slot_C.StopMapping");

	struct {
	} parms;


	ProcessEvent(p_StopMapping, &parms);
}

void UUserWidget::StopMappingGamePad(){

	static UObject* p_StopMappingGamePad = UObject::FindObject<UFunction>("Function CustomMapping_Slot.CustomMapping_Slot_C.StopMappingGamePad");

	struct {
	} parms;


	ProcessEvent(p_StopMappingGamePad, &parms);
}

void UUserWidget::CamMappingGamePad(){

	static UObject* p_CamMappingGamePad = UObject::FindObject<UFunction>("Function CustomMapping_Slot.CustomMapping_Slot_C.CamMappingGamePad");

	struct {
	} parms;


	ProcessEvent(p_CamMappingGamePad, &parms);
}

void UUserWidget::ExecuteUbergraph_CustomMapping_Slot(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph_CustomMapping_Slot = UObject::FindObject<UFunction>("Function CustomMapping_Slot.CustomMapping_Slot_C.ExecuteUbergraph_CustomMapping_Slot");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph_CustomMapping_Slot, &parms);
}

