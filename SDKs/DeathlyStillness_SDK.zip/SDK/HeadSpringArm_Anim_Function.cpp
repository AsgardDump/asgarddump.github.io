#include "SDK.h" 
 
 
void UAnimInstance::AnimGraph(struct FPoseLink& AnimGraph){

	static UObject* p_AnimGraph = UObject::FindObject<UFunction>("Function HeadSpringArm_Anim.HeadSpringArm_Anim_C.AnimGraph");

	struct {
		struct FPoseLink& AnimGraph;
	} parms;

	parms.AnimGraph = AnimGraph;

	ProcessEvent(p_AnimGraph, &parms);
}

void UAnimInstance::EvaluateGraphExposedInputs_ExecuteUbergraph_HeadSpringArm_Anim_AnimGraphNode_BlendListByBool_ADAE08EA4B61A5FC4B9233BC0BC13AE6(){

	static UObject* p_EvaluateGraphExposedInputs_ExecuteUbergraph_HeadSpringArm_Anim_AnimGraphNode_BlendListByBool_ADAE08EA4B61A5FC4B9233BC0BC13AE6 = UObject::FindObject<UFunction>("Function HeadSpringArm_Anim.HeadSpringArm_Anim_C.EvaluateGraphExposedInputs_ExecuteUbergraph_HeadSpringArm_Anim_AnimGraphNode_BlendListByBool_ADAE08EA4B61A5FC4B9233BC0BC13AE6");

	struct {
	} parms;


	ProcessEvent(p_EvaluateGraphExposedInputs_ExecuteUbergraph_HeadSpringArm_Anim_AnimGraphNode_BlendListByBool_ADAE08EA4B61A5FC4B9233BC0BC13AE6, &parms);
}

void UAnimInstance::EvaluateGraphExposedInputs_ExecuteUbergraph_HeadSpringArm_Anim_AnimGraphNode_BlendListByBool_CAAEEB4C431BD853504706A8D470C26A(){

	static UObject* p_EvaluateGraphExposedInputs_ExecuteUbergraph_HeadSpringArm_Anim_AnimGraphNode_BlendListByBool_CAAEEB4C431BD853504706A8D470C26A = UObject::FindObject<UFunction>("Function HeadSpringArm_Anim.HeadSpringArm_Anim_C.EvaluateGraphExposedInputs_ExecuteUbergraph_HeadSpringArm_Anim_AnimGraphNode_BlendListByBool_CAAEEB4C431BD853504706A8D470C26A");

	struct {
	} parms;


	ProcessEvent(p_EvaluateGraphExposedInputs_ExecuteUbergraph_HeadSpringArm_Anim_AnimGraphNode_BlendListByBool_CAAEEB4C431BD853504706A8D470C26A, &parms);
}

void UAnimInstance::BlueprintUpdateAnimation(float DeltaTimeX){

	static UObject* p_BlueprintUpdateAnimation = UObject::FindObject<UFunction>("Function HeadSpringArm_Anim.HeadSpringArm_Anim_C.BlueprintUpdateAnimation");

	struct {
		float DeltaTimeX;
	} parms;

	parms.DeltaTimeX = DeltaTimeX;

	ProcessEvent(p_BlueprintUpdateAnimation, &parms);
}

void UAnimInstance::ExecuteUbergraph_HeadSpringArm_Anim(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph_HeadSpringArm_Anim = UObject::FindObject<UFunction>("Function HeadSpringArm_Anim.HeadSpringArm_Anim_C.ExecuteUbergraph_HeadSpringArm_Anim");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph_HeadSpringArm_Anim, &parms);
}

