#include "SDK.h" 
 
 
void AAIController::BndEvt__AIPerception_K2Node_ComponentBoundEvent_1_ActorPerceptionUpdatedDelegate__DelegateSignature(struct AActor* Actor, struct FAIStimulus Stimulus){

	static UObject* p_BndEvt__AIPerception_K2Node_ComponentBoundEvent_1_ActorPerceptionUpdatedDelegate__DelegateSignature = UObject::FindObject<UFunction>("Function Entity_AiController.Entity_AiController_C.BndEvt__AIPerception_K2Node_ComponentBoundEvent_1_ActorPerceptionUpdatedDelegate__DelegateSignature");

	struct {
		struct AActor* Actor;
		struct FAIStimulus Stimulus;
	} parms;

	parms.Actor = Actor;
	parms.Stimulus = Stimulus;

	ProcessEvent(p_BndEvt__AIPerception_K2Node_ComponentBoundEvent_1_ActorPerceptionUpdatedDelegate__DelegateSignature, &parms);
}

void AAIController::ReceivePossess(struct APawn* PossessedPawn){

	static UObject* p_ReceivePossess = UObject::FindObject<UFunction>("Function Entity_AiController.Entity_AiController_C.ReceivePossess");

	struct {
		struct APawn* PossessedPawn;
	} parms;

	parms.PossessedPawn = PossessedPawn;

	ProcessEvent(p_ReceivePossess, &parms);
}

void AAIController::Reset(){

	static UObject* p_Reset = UObject::FindObject<UFunction>("Function Entity_AiController.Entity_AiController_C.Reset");

	struct {
	} parms;


	ProcessEvent(p_Reset, &parms);
}

void AAIController::ReceiveBeginPlay(){

	static UObject* p_ReceiveBeginPlay = UObject::FindObject<UFunction>("Function Entity_AiController.Entity_AiController_C.ReceiveBeginPlay");

	struct {
	} parms;


	ProcessEvent(p_ReceiveBeginPlay, &parms);
}

void AAIController::ExecuteUbergraph_Entity_AiController(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph_Entity_AiController = UObject::FindObject<UFunction>("Function Entity_AiController.Entity_AiController_C.ExecuteUbergraph_Entity_AiController");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph_Entity_AiController, &parms);
}

