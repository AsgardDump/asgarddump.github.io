#include "SDK.h" 
 
 
void AAKMSpawner_BP3_C::ExecuteUbergraph_AKMSpawner_BP(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph_AKMSpawner_BP = UObject::FindObject<UFunction>("Function AKMSpawner_BP.AKMSpawner_BP_C.ExecuteUbergraph_AKMSpawner_BP");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph_AKMSpawner_BP, &parms);
}

