#pragma once 
#include <CustomWeapon_UMG_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass CustomWeapon_UMG.CustomWeapon_UMG_C
// Size: 0x2CC(Inherited: 0x260) 
struct UCustomWeapon_UMG_C : public UUserWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x260(0x8)
	struct UWeaponSlot_UMG_C* AKM;  // 0x268(0x8)
	struct UVerticalBox* ;  // 0x270(0x8)
	struct UVerticalBox* _2;  // 0x278(0x8)
	struct UImage* Image_15;  // 0x280(0x8)
	struct UVerticalBox* ;  // 0x288(0x8)
	struct UTextBlock* TextBlock_736;  // 0x290(0x8)
	struct UWeaponSlot_UMG_C* WeaponSlot_UMG;  // 0x298(0x8)
	struct UWeaponSlot_UMG_C* WeaponSlot_UMG_2;  // 0x2A0(0x8)
	struct UVerticalBox* ;  // 0x2A8(0x8)
	struct U* ;  // 0x2B0(0x8)
	struct U* ;  // 0x2B8(0x8)
	struct UVerticalBox* ;  // 0x2C0(0x8)
	char WeaponType WeaponType;  // 0x2C8(0x1)
	char Optics_Enum OpticsType;  // 0x2C9(0x1)
	char AccessoriesType Accessories Type;  // 0x2CA(0x1)
	char MuzzleType MuzzleType;  // 0x2CB(0x1)

	void (); // Function CustomWeapon_UMG.CustomWeapon_UMG_C.
	void (); // Function CustomWeapon_UMG.CustomWeapon_UMG_C.
	void (char WeaponType WeaponType); // Function CustomWeapon_UMG.CustomWeapon_UMG_C.
	void (char WeaponType WeaponType, char AccessoriesType AccessoriesType); // Function CustomWeapon_UMG.CustomWeapon_UMG_C.
	void (); // Function CustomWeapon_UMG.CustomWeapon_UMG_C.
	void ExecuteUbergraph_CustomWeapon_UMG(int32_t EntryPoint); // Function CustomWeapon_UMG.CustomWeapon_UMG_C.ExecuteUbergraph_CustomWeapon_UMG
}; 



