#pragma once 
#include <BP_BASE_Stump_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_BASE_Stump.BP_BASE_Stump_C
// Size: 0x368(Inherited: 0x368) 
struct ABP_BASE_Stump_C : public ABP_StaticHarvestNode_C
{

	uint8_t  CanRevertToFoliage(); // Function BP_BASE_Stump.BP_BASE_Stump_C.CanRevertToFoliage
}; 



