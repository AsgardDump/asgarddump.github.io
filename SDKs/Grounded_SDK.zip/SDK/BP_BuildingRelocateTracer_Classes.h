#pragma once 
#include <BP_BuildingRelocateTracer_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_BuildingRelocateTracer.BP_BuildingRelocateTracer_C
// Size: 0x248(Inherited: 0x230) 
struct ABP_BuildingRelocateTracer_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x230(0x8)
	struct USplineMeshComponent* SplineMesh;  // 0x238(0x8)
	struct UMaterialInstanceDynamic* TracerMID;  // 0x240(0x8)

	void UserConstructionScript(); // Function BP_BuildingRelocateTracer.BP_BuildingRelocateTracer_C.UserConstructionScript
	void ReceiveTick(float DeltaSeconds); // Function BP_BuildingRelocateTracer.BP_BuildingRelocateTracer_C.ReceiveTick
	void ExecuteUbergraph_BP_BuildingRelocateTracer(int32_t EntryPoint); // Function BP_BuildingRelocateTracer.BP_BuildingRelocateTracer_C.ExecuteUbergraph_BP_BuildingRelocateTracer
}; 



