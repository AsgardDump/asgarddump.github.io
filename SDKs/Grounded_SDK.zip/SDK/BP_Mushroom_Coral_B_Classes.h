#pragma once 
#include <BP_Mushroom_Coral_B_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Mushroom_Coral_B.BP_Mushroom_Coral_B_C
// Size: 0x478(Inherited: 0x469) 
struct ABP_Mushroom_Coral_B_C : public ABP_BASE_Mushroom_C
{
	char pad_1129[7];  // 0x469(0x7)
	struct UMaterialInstanceDynamic* MushroomMID_1;  // 0x470(0x8)

}; 



