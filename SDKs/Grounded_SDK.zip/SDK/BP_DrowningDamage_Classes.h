#pragma once 
#include <BP_DrowningDamage_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_DrowningDamage.BP_DrowningDamage_C
// Size: 0x78(Inherited: 0x78) 
struct UBP_DrowningDamage_C : public USurvivalDamageType
{

}; 



