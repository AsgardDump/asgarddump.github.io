#pragma once 
#include <BP_Pupa_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Pupa.BP_Pupa_C
// Size: 0x370(Inherited: 0x368) 
struct ABP_Pupa_C : public ABP_StaticHarvestNode_C
{
	struct UVisualStateComponent* VisualState;  // 0x368(0x8)

}; 



