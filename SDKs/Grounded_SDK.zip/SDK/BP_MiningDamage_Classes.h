#pragma once 
#include <BP_MiningDamage_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_MiningDamage.BP_MiningDamage_C
// Size: 0x78(Inherited: 0x78) 
struct UBP_MiningDamage_C : public USurvivalDamageType
{

}; 



