#pragma once 
#include <BP_Hedge_Berry_A_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Hedge_Berry_A.BP_Hedge_Berry_A_C
// Size: 0x430(Inherited: 0x430) 
struct ABP_Hedge_Berry_A_C : public ABP_BASE_Hedge_Berry_C
{

}; 



