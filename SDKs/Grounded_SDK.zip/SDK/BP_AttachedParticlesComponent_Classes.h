#pragma once 
#include <BP_AttachedParticlesComponent_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_AttachedParticlesComponent.BP_AttachedParticlesComponent_C
// Size: 0x168(Inherited: 0xB0) 
struct UBP_AttachedParticlesComponent_C : public UActorComponent
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0xB0(0x8)
	struct UParticleSystemComponent* AttachedEmitter;  // 0xB8(0x8)
	struct UParticleSystemComponent* WaterEmitter;  // 0xC0(0x8)
	struct UParticleSystemComponent* WaterBubblesEmitter;  // 0xC8(0x8)
	struct UParticleSystem* ParticleSystemDefault;  // 0xD0(0x8)
	struct UParticleSystem* ParticleSystemWater;  // 0xD8(0x8)
	struct UParticleSystem* ParticleSystemBubbles;  // 0xE0(0x8)
	struct UParticleSystem* ParticleSystemWeedKiller;  // 0xE8(0x8)
	AActor* BP_WaterLarge;  // 0xF0(0x8)
	struct TArray<struct UBoxComponent*> WaterTriggers;  // 0xF8(0x10)
	struct TArray<struct ATriggerVolume*> WeedKillerVolumes;  // 0x108(0x10)
	struct TArray<struct ATriggerBox*> LabVolumesTriggers;  // 0x118(0x10)
	struct ABP_SurvivalPlayerCharacter_C* LocalPlayerCharacter;  // 0x128(0x8)
	float WaterHeight;  // 0x130(0x4)
	char pad_308_1 : 7;  // 0x134(0x1)
	bool IsPlayerOverlapping : 1;  // 0x134(0x1)
	char pad_309_1 : 7;  // 0x135(0x1)
	bool HasSetup : 1;  // 0x135(0x1)
	char pad_310[2];  // 0x136(0x2)
	struct FName WeedKillerVolumeTrigger;  // 0x138(0x8)
	struct FName LabVolumeTrigger;  // 0x140(0x8)
	struct FName MouthSocket;  // 0x148(0x8)
	struct UCapsuleComponent* LocalPlayerCapsule;  // 0x150(0x8)
	char pad_344_1 : 7;  // 0x158(0x1)
	bool HasWaterParticles : 1;  // 0x158(0x1)
	char pad_345[3];  // 0x159(0x3)
	int32_t NumberOfWaterVolumes;  // 0x15C(0x4)
	float SpawnParticleCeiling;  // 0x160(0x4)
	float SpawnParticleFloor;  // 0x164(0x4)

	void ReceiveTick(float DeltaSeconds); // Function BP_AttachedParticlesComponent.BP_AttachedParticlesComponent_C.ReceiveTick
	void BeginOverlapWeedKiller(struct AActor* OverlappedActor, struct AActor* OtherActor); // Function BP_AttachedParticlesComponent.BP_AttachedParticlesComponent_C.BeginOverlapWeedKiller
	void EndOverlapWeedKiller(struct AActor* OverlappedActor, struct AActor* OtherActor); // Function BP_AttachedParticlesComponent.BP_AttachedParticlesComponent_C.EndOverlapWeedKiller
	void BeginOverlapLab(struct AActor* OverlappedActor, struct AActor* OtherActor); // Function BP_AttachedParticlesComponent.BP_AttachedParticlesComponent_C.BeginOverlapLab
	void EndOverlapLab(struct AActor* OverlappedActor, struct AActor* OtherActor); // Function BP_AttachedParticlesComponent.BP_AttachedParticlesComponent_C.EndOverlapLab
	void SetupEffects(); // Function BP_AttachedParticlesComponent.BP_AttachedParticlesComponent_C.SetupEffects
	void SetWaterParticles(bool InWater, struct ABP_Water_Large_C* OverlappedWaterVolume); // Function BP_AttachedParticlesComponent.BP_AttachedParticlesComponent_C.SetWaterParticles
	void EnableWaterParticleOverrride(); // Function BP_AttachedParticlesComponent.BP_AttachedParticlesComponent_C.EnableWaterParticleOverrride
	void DisableWaterParticleOverride(); // Function BP_AttachedParticlesComponent.BP_AttachedParticlesComponent_C.DisableWaterParticleOverride
	void ExecuteUbergraph_BP_AttachedParticlesComponent(int32_t EntryPoint); // Function BP_AttachedParticlesComponent.BP_AttachedParticlesComponent_C.ExecuteUbergraph_BP_AttachedParticlesComponent
}; 



