#pragma once 
#include "SDK.h" 
 
 
// Function BP_Pupa_Topple.BP_Pupa_Topple_C.ExecuteUbergraph_BP_Pupa_Topple
// Size: 0x5(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Pupa_Topple
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0x4(0x1)

}; 
// Function BP_Pupa_Topple.BP_Pupa_Topple_C.Handle Death
// Size: 0xB0(Inherited: 0xB9) 
struct FHandle Death : public FHandle Death
{
	struct FDamageInfo DamageInfo;  // 0x0(0x68)
	struct FTransform CallFunc_GetSocketTransform_ReturnValue;  // 0x70(0x30)
	struct AActor* CallFunc_BeginDeferredActorSpawnFromClass_ReturnValue;  // 0xA0(0x8)
	struct AActor* CallFunc_FinishSpawningActor_ReturnValue;  // 0xA8(0x8)

}; 
// Function BP_Pupa_Topple.BP_Pupa_Topple_C.IsSourceForItem
// Size: 0x2A(Inherited: 0x0) 
struct FIsSourceForItem
{
	struct FDataTableRowHandle ItemType;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct UActorComponent* CallFunc_FindClassDefaultComponentByClass_ReturnValue;  // 0x18(0x8)
	struct ULootComponent* K2Node_DynamicCast_AsLoot_Component;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x28(0x1)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool CallFunc_CanDropItem_ReturnValue : 1;  // 0x29(0x1)

}; 
// Function BP_Pupa_Topple.BP_Pupa_Topple_C.GetItemSourceWorldLocation
// Size: 0x1C(Inherited: 0x0) 
struct FGetItemSourceWorldLocation
{
	struct FDataTableRowHandle ItemType;  // 0x0(0x10)
	struct FVector ReturnValue;  // 0x10(0xC)

}; 
