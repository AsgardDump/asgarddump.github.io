#pragma once 
#include "SDK.h" 
 
 
// Function BP_BASE_GrassBlade.BP_BASE_GrassBlade_C.ExecuteUbergraph_BP_BASE_GrassBlade
// Size: 0x10A(Inherited: 0x0) 
struct FExecuteUbergraph_BP_BASE_GrassBlade
{
	int32_t EntryPoint;  // 0x0(0x4)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x4(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x14(0x10)
	float K2Node_Event_DeltaSeconds;  // 0x24(0x4)
	struct UPrimitiveComponent* K2Node_CustomEvent_OverlappedComponent_2;  // 0x28(0x8)
	struct AActor* K2Node_CustomEvent_OtherActor_2;  // 0x30(0x8)
	struct UPrimitiveComponent* K2Node_CustomEvent_OtherComp_2;  // 0x38(0x8)
	int32_t K2Node_CustomEvent_OtherBodyIndex_2;  // 0x40(0x4)
	char pad_68_1 : 7;  // 0x44(0x1)
	bool K2Node_CustomEvent_bFromSweep : 1;  // 0x44(0x1)
	char pad_69[3];  // 0x45(0x3)
	struct FHitResult K2Node_CustomEvent_SweepResult;  // 0x48(0x88)
	struct UPrimitiveComponent* K2Node_CustomEvent_OverlappedComponent;  // 0xD0(0x8)
	struct AActor* K2Node_CustomEvent_OtherActor;  // 0xD8(0x8)
	struct UPrimitiveComponent* K2Node_CustomEvent_OtherComp;  // 0xE0(0x8)
	int32_t K2Node_CustomEvent_OtherBodyIndex;  // 0xE8(0x4)
	char pad_236[4];  // 0xEC(0x4)
	struct APhysicsVolume* K2Node_DynamicCast_AsPhysics_Volume;  // 0xF0(0x8)
	char pad_248_1 : 7;  // 0xF8(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0xF8(0x1)
	char pad_249[7];  // 0xF9(0x7)
	struct APhysicsVolume* K2Node_DynamicCast_AsPhysics_Volume_2;  // 0x100(0x8)
	char pad_264_1 : 7;  // 0x108(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x108(0x1)
	char pad_265_1 : 7;  // 0x109(0x1)
	bool CallFunc_IsOverlappingWaterVolume_ReturnValue : 1;  // 0x109(0x1)

}; 
// Function BP_BASE_GrassBlade.BP_BASE_GrassBlade_C.OnStaticTopEndOverlap
// Size: 0x1C(Inherited: 0x0) 
struct FOnStaticTopEndOverlap
{
	struct UPrimitiveComponent* OverlappedComponent;  // 0x0(0x8)
	struct AActor* OtherActor;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	int32_t OtherBodyIndex;  // 0x18(0x4)

}; 
// Function BP_BASE_GrassBlade.BP_BASE_GrassBlade_C.OnStaticTopBeginOverlap
// Size: 0xA8(Inherited: 0x0) 
struct FOnStaticTopBeginOverlap
{
	struct UPrimitiveComponent* OverlappedComponent;  // 0x0(0x8)
	struct AActor* OtherActor;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	int32_t OtherBodyIndex;  // 0x18(0x4)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool bFromSweep : 1;  // 0x1C(0x1)
	char pad_29[3];  // 0x1D(0x3)
	struct FHitResult SweepResult;  // 0x20(0x88)

}; 
// Function BP_BASE_GrassBlade.BP_BASE_GrassBlade_C.ReceiveTick
// Size: 0x4(Inherited: 0x4) 
struct FReceiveTick : public FReceiveTick
{
	float DeltaSeconds;  // 0x0(0x4)

}; 
