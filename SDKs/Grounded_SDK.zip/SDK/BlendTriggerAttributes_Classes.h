#pragma once 
#include <BlendTriggerAttributes_Structs.h>
 
 
 
