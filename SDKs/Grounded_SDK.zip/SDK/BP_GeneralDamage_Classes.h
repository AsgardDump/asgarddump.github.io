#pragma once 
#include <BP_GeneralDamage_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_GeneralDamage.BP_GeneralDamage_C
// Size: 0x78(Inherited: 0x78) 
struct UBP_GeneralDamage_C : public USurvivalDamageType
{

}; 



