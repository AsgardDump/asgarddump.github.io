#pragma once 
#include "SDK.h" 
 
 
// Function BP_AlgaeB.BP_AlgaeB_C.ExecuteUbergraph_BP_AlgaeB
// Size: 0x4(Inherited: 0x0) 
struct FExecuteUbergraph_BP_AlgaeB
{
	int32_t EntryPoint;  // 0x0(0x4)

}; 
