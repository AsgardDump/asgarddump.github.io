#pragma once 
#include <BP_BombardierThorax_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_BombardierThorax.BP_BombardierThorax_C
// Size: 0x2B8(Inherited: 0x2A3) 
struct ABP_BombardierThorax_C : public ABP_InsectPart_C
{
	char pad_675[5];  // 0x2A3(0x5)
	struct UCableComponent* CableLegLFront;  // 0x2A8(0x8)
	struct UCableComponent* CableLegRFront;  // 0x2B0(0x8)

}; 



