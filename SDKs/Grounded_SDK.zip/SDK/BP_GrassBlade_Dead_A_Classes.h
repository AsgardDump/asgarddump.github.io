#pragma once 
#include <BP_GrassBlade_Dead_A_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_GrassBlade_Dead_A.BP_GrassBlade_Dead_A_C
// Size: 0x418(Inherited: 0x418) 
struct ABP_GrassBlade_Dead_A_C : public ABP_BASE_GrassBlade_Dead_C
{

}; 



