#pragma once 
#include "SDK.h" 
 
 
// Function BP_Pond_Breaker_Switch_2.BP_Pond_Breaker_Switch_1_C.ExecuteUbergraph_BP_Pond_Breaker_Switch_2
// Size: 0x4(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Pond_Breaker_Switch_2
{
	int32_t EntryPoint;  // 0x0(0x4)

}; 
