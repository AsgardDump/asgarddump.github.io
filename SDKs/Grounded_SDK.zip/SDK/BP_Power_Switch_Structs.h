#pragma once 
#include "SDK.h" 
 
 
// Function BP_Power_Switch.BP_Power_Switch_C.ExecuteUbergraph_BP_Power_Switch
// Size: 0xF3(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Power_Switch
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UDynamicMaterialCache* CallFunc_GetDynamicMaterialCache_ReturnValue;  // 0x8(0x8)
	char ETimelineDirection Temp_byte_Variable;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool Temp_bool_IsClosed_Variable : 1;  // 0x11(0x1)
	char pad_18_1 : 7;  // 0x12(0x1)
	bool Temp_bool_Has_Been_Initd_Variable : 1;  // 0x12(0x1)
	char pad_19_1 : 7;  // 0x13(0x1)
	bool Temp_bool_Has_Been_Initd_Variable_2 : 1;  // 0x13(0x1)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool CallFunc_IsDemoMode_ReturnValue : 1;  // 0x14(0x1)
	char pad_21[3];  // 0x15(0x3)
	struct FRotator CallFunc_MakeRotator_ReturnValue;  // 0x18(0xC)
	struct FRotator CallFunc_RLerp_ReturnValue;  // 0x24(0xC)
	struct FHitResult CallFunc_K2_SetRelativeLocationAndRotation_SweepHitResult;  // 0x30(0x88)
	char pad_184_1 : 7;  // 0xB8(0x1)
	bool K2Node_Event_IsOpen : 1;  // 0xB8(0x1)
	char pad_185[3];  // 0xB9(0x3)
	struct FLinearColor K2Node_Select_Default;  // 0xBC(0x10)
	char pad_204[4];  // 0xCC(0x4)
	struct UMaterialInstanceDynamic* CallFunc_AssignDynamicMaterialWithColor_ReturnValue;  // 0xD0(0x8)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0xD8(0xC)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_2;  // 0xE4(0xC)
	char pad_240_1 : 7;  // 0xF0(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0xF0(0x1)
	char pad_241_1 : 7;  // 0xF1(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0xF1(0x1)
	char pad_242_1 : 7;  // 0xF2(0x1)
	bool Temp_bool_IsClosed_Variable_2 : 1;  // 0xF2(0x1)

}; 
// Function BP_Power_Switch.BP_Power_Switch_C.OnUpdateVisualState
// Size: 0x1(Inherited: 0x1) 
struct FOnUpdateVisualState : public FOnUpdateVisualState
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool IsOpen : 1;  // 0x0(0x1)

}; 
