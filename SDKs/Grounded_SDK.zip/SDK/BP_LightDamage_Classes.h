#pragma once 
#include <BP_LightDamage_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_LightDamage.BP_LightDamage_C
// Size: 0x78(Inherited: 0x78) 
struct UBP_LightDamage_C : public USurvivalDamageType
{

}; 



