#pragma once 
#include "SDK.h" 
 
 
// Function BP_Plant_Small_Leafy_A_Dry.BP_Plant_Small_Leafy_A_Dry_C.SpawnParticles
// Size: 0x8(Inherited: 0x0) 
struct FSpawnParticles
{
	struct AActor* DestroyedActor;  // 0x0(0x8)

}; 
// Function BP_Plant_Small_Leafy_A_Dry.BP_Plant_Small_Leafy_A_Dry_C.ExecuteUbergraph_BP_Plant_Small_Leafy_A_Dry
// Size: 0x30(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Plant_Small_Leafy_A_Dry
{
	int32_t EntryPoint;  // 0x0(0x4)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue;  // 0x4(0xC)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x10(0x10)
	struct UParticleSystemComponent* CallFunc_SpawnEmitterAtLocation_ReturnValue;  // 0x20(0x8)
	struct AActor* K2Node_CustomEvent_DestroyedActor;  // 0x28(0x8)

}; 
