#pragma once 
#include <AudioLib_Structs.h>
 
 
 
// BlueprintGeneratedClass AudioLib.AudioLib_C
// Size: 0x28(Inherited: 0x28) 
struct UAudioLib_C : public UBlueprintFunctionLibrary
{

	void SequenceContainer2D(struct TArray<struct USoundBase*>& Sound List, struct UObject* __WorldContext); // Function AudioLib.AudioLib_C.SequenceContainer2D
	float GetRandomStartTime(struct UAudioComponent* NewParam, struct UObject* __WorldContext); // Function AudioLib.AudioLib_C.GetRandomStartTime
	void GetLocalListenerLocation(struct UObject* __WorldContext, struct FVector& Location); // Function AudioLib.AudioLib_C.GetLocalListenerLocation
	void GetDistanceToPlayer(struct AActor* Target, float Duration, struct UObject* __WorldContext); // Function AudioLib.AudioLib_C.GetDistanceToPlayer
	void MultiGetDistanceToPlayer(struct TArray<struct AActor*>& Target, float Duration, struct UObject* __WorldContext); // Function AudioLib.AudioLib_C.MultiGetDistanceToPlayer
}; 



