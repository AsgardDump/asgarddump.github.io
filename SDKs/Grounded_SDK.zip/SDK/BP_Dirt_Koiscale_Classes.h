#pragma once 
#include <BP_Dirt_Koiscale_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Dirt_Koiscale.BP_Dirt_Koiscale_C
// Size: 0x368(Inherited: 0x368) 
struct ABP_Dirt_Koiscale_C : public ABP_StaticHarvestNode_C
{

}; 



