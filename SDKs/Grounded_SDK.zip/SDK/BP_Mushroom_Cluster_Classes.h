#pragma once 
#include <BP_Mushroom_Cluster_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Mushroom_Cluster.BP_Mushroom_Cluster_C
// Size: 0x469(Inherited: 0x469) 
struct ABP_Mushroom_Cluster_C : public ABP_BASE_Mushroom_C
{

}; 



