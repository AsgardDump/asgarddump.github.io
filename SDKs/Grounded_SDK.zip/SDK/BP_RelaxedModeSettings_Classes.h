#pragma once 
#include <BP_RelaxedModeSettings_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_RelaxedModeSettings.BP_RelaxedModeSettings_C
// Size: 0x78(Inherited: 0x78) 
struct UBP_RelaxedModeSettings_C : public USurvivalGameModeSettings
{

}; 



