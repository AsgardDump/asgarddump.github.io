#pragma once 
#include <BP_Mushroom_Twisty_B_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Mushroom_Twisty_B.BP_Mushroom_Twisty_B_C
// Size: 0x4A8(Inherited: 0x4A8) 
struct ABP_Mushroom_Twisty_B_C : public ABP_Mushroom_Twisty_A_C
{

}; 



