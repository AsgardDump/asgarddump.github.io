#pragma once 
#include "SDK.h" 
 
 
// Function BP_Pond_Breaker_Switch_Base.BP_Pond_Breaker_Switch_Base_C.ExecuteUbergraph_BP_Pond_Breaker_Switch_Base
// Size: 0x109(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Pond_Breaker_Switch_Base
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool K2Node_CustomEvent_IsEnabled : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool K2Node_Event_IsOpen_2 : 1;  // 0x5(0x1)
	char pad_6[2];  // 0x6(0x2)
	struct AActor* K2Node_Event_ActorInstigator;  // 0x8(0x8)
	struct ASurvivalPlayerCharacter* K2Node_DynamicCast_AsSurvival_Player_Character;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)
	struct FLinearColor CallFunc_GetLightColor_ReturnValue;  // 0x1C(0x10)
	char pad_44_1 : 7;  // 0x2C(0x1)
	bool K2Node_ComponentBoundEvent_bIsActive_2 : 1;  // 0x2C(0x1)
	char pad_45_1 : 7;  // 0x2D(0x1)
	bool K2Node_CustomEvent_ToggleOn : 1;  // 0x2D(0x1)
	char pad_46[2];  // 0x2E(0x2)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x30(0x4)
	char pad_52_1 : 7;  // 0x34(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0x34(0x1)
	char pad_53_1 : 7;  // 0x35(0x1)
	bool CallFunc_HasAuthority_ReturnValue_2 : 1;  // 0x35(0x1)
	char pad_54_1 : 7;  // 0x36(0x1)
	bool CallFunc_HasAuthority_ReturnValue_3 : 1;  // 0x36(0x1)
	char pad_55_1 : 7;  // 0x37(0x1)
	bool CallFunc_IsEnabled_ReturnValue : 1;  // 0x37(0x1)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool CallFunc_IsEnabled_ReturnValue_2 : 1;  // 0x38(0x1)
	char pad_57[3];  // 0x39(0x3)
	float CallFunc_GetTimelineLength_ReturnValue;  // 0x3C(0x4)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool CallFunc_IsEnabled_ReturnValue_3 : 1;  // 0x40(0x1)
	char pad_65_1 : 7;  // 0x41(0x1)
	bool CallFunc_HasAuthority_ReturnValue_4 : 1;  // 0x41(0x1)
	char pad_66_1 : 7;  // 0x42(0x1)
	bool K2Node_ComponentBoundEvent_bIsActive : 1;  // 0x42(0x1)
	char pad_67[1];  // 0x43(0x1)
	float CallFunc_GetTimelineLength_ReturnValue_2;  // 0x44(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x48(0x4)
	char pad_76_1 : 7;  // 0x4C(0x1)
	bool K2Node_Event_IsOpen : 1;  // 0x4C(0x1)
	char pad_77_1 : 7;  // 0x4D(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x4D(0x1)
	char pad_78[2];  // 0x4E(0x2)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x50(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x54(0x4)
	struct ABP_Fan_B_C* CallFunc_Array_Get_Item;  // 0x58(0x8)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x60(0xC)
	char pad_108_1 : 7;  // 0x6C(0x1)
	bool CallFunc_IsEnabled_ReturnValue_4 : 1;  // 0x6C(0x1)
	char pad_109_1 : 7;  // 0x6D(0x1)
	bool CallFunc_IsEnabled_ReturnValue_5 : 1;  // 0x6D(0x1)
	char pad_110_1 : 7;  // 0x6E(0x1)
	bool CallFunc_IsEnabled_ReturnValue_6 : 1;  // 0x6E(0x1)
	char pad_111[1];  // 0x6F(0x1)
	struct FRotator CallFunc_RLerp_ReturnValue;  // 0x70(0xC)
	struct FHitResult CallFunc_K2_SetRelativeRotation_SweepHitResult;  // 0x7C(0x88)
	float CallFunc_GetPlaybackPosition_ReturnValue;  // 0x104(0x4)
	char pad_264_1 : 7;  // 0x108(0x1)
	bool CallFunc_GreaterEqual_FloatFloat_ReturnValue : 1;  // 0x108(0x1)

}; 
// Function BP_Pond_Breaker_Switch_Base.BP_Pond_Breaker_Switch_Base_C.UserConstructionScript
// Size: 0x78(Inherited: 0x0) 
struct FUserConstructionScript : public FUserConstructionScript
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Temp_bool_Variable : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	float Temp_float_Variable;  // 0x4(0x4)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	struct FLinearColor Temp_struct_Variable;  // 0xC(0x10)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool Temp_bool_Variable_3 : 1;  // 0x1C(0x1)
	char pad_29[3];  // 0x1D(0x3)
	struct FLinearColor Temp_struct_Variable_2;  // 0x20(0x10)
	struct UMaterialInterface* CallFunc_GetMaterial_ReturnValue;  // 0x30(0x8)
	struct UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue;  // 0x38(0x8)
	struct FLinearColor K2Node_Select_Default;  // 0x40(0x10)
	struct FLinearColor K2Node_Select_Default_2;  // 0x50(0x10)
	float K2Node_Select_Default_3;  // 0x60(0x4)
	char pad_100[4];  // 0x64(0x4)
	struct UMaterialInterface* CallFunc_GetMaterial_ReturnValue_2;  // 0x68(0x8)
	struct UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue_2;  // 0x70(0x8)

}; 
// Function BP_Pond_Breaker_Switch_Base.BP_Pond_Breaker_Switch_Base_C.OnUpdateVisualState
// Size: 0x1(Inherited: 0x1) 
struct FOnUpdateVisualState : public FOnUpdateVisualState
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool IsOpen : 1;  // 0x0(0x1)

}; 
// Function BP_Pond_Breaker_Switch_Base.BP_Pond_Breaker_Switch_Base_C.LightOn
// Size: 0x1(Inherited: 0x0) 
struct FLightOn
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool IsEnabled : 1;  // 0x0(0x1)

}; 
// Function BP_Pond_Breaker_Switch_Base.BP_Pond_Breaker_Switch_Base_C.ToggleConnectedFans
// Size: 0x1(Inherited: 0x0) 
struct FToggleConnectedFans
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ToggleOn : 1;  // 0x0(0x1)

}; 
// Function BP_Pond_Breaker_Switch_Base.BP_Pond_Breaker_Switch_Base_C.BndEvt__ConditionalToggle_Vis_PostPowerSurge_Off_K2Node_ComponentBoundEvent_2_OnConditionalStateChanged__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FBndEvt__ConditionalToggle_Vis_PostPowerSurge_Off_K2Node_ComponentBoundEvent_2_OnConditionalStateChanged__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bIsActive : 1;  // 0x0(0x1)

}; 
// Function BP_Pond_Breaker_Switch_Base.BP_Pond_Breaker_Switch_Base_C.BndEvt__ConditionalToggle_IsOn_K2Node_ComponentBoundEvent_0_OnConditionalStateChanged__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FBndEvt__ConditionalToggle_IsOn_K2Node_ComponentBoundEvent_0_OnConditionalStateChanged__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bIsActive : 1;  // 0x0(0x1)

}; 
// Function BP_Pond_Breaker_Switch_Base.BP_Pond_Breaker_Switch_Base_C.OnOpenStateChanged
// Size: 0x10(Inherited: 0x10) 
struct FOnOpenStateChanged : public FOnOpenStateChanged
{
	char pad_16_1 : 7;  // 0x10(0x1)
	bool IsOpen : 1;  // 0x0(0x1)
	struct AActor* ActorInstigator;  // 0x8(0x8)

}; 
// Function BP_Pond_Breaker_Switch_Base.BP_Pond_Breaker_Switch_Base_C.GetInteractionText
// Size: 0x30(Inherited: 0x20) 
struct FGetInteractionText : public FGetInteractionText
{
	uint8_t  Channel;  // 0x0(0x1)
	struct AActor* InstigatedBy;  // 0x8(0x8)
	struct FString OutText;  // 0x10(0x10)
	struct FString CallFunc_GetLocStringText_ReturnValue;  // 0x20(0x10)

}; 
// Function BP_Pond_Breaker_Switch_Base.BP_Pond_Breaker_Switch_Base_C.IsInteractionEnabled
// Size: 0x13(Inherited: 0x18) 
struct FIsInteractionEnabled : public FIsInteractionEnabled
{
	uint8_t  Channel;  // 0x0(0x1)
	struct AActor* InstigatedBy;  // 0x8(0x8)
	char EInteractionState ReturnValue;  // 0x10(0x1)
	char EInteractionState CallFunc_IsInteractionEnabled_ReturnValue;  // 0x11(0x1)
	char pad_35_1 : 7;  // 0x23(0x1)
	bool CallFunc_IsEnabled_ReturnValue : 1;  // 0x12(0x1)

}; 
