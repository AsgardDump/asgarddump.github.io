#pragma once 
#include <BP_Hazard_Stink_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Hazard_Stink.BP_Hazard_Stink_C
// Size: 0x399(Inherited: 0x388) 
struct ABP_Hazard_Stink_C : public AHazardSphere
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x388(0x8)
	struct UParticleSystemComponent* PS_Hazard;  // 0x390(0x8)
	char pad_920_1 : 7;  // 0x398(0x1)
	bool UseNiagara : 1;  // 0x398(0x1)

	void NewFunction_1(); // Function BP_Hazard_Stink.BP_Hazard_Stink_C.NewFunction_1
	void ReceiveBeginPlay(); // Function BP_Hazard_Stink.BP_Hazard_Stink_C.ReceiveBeginPlay
	void EndVFX(); // Function BP_Hazard_Stink.BP_Hazard_Stink_C.EndVFX
	void ExecuteUbergraph_BP_Hazard_Stink(int32_t EntryPoint); // Function BP_Hazard_Stink.BP_Hazard_Stink_C.ExecuteUbergraph_BP_Hazard_Stink
}; 



