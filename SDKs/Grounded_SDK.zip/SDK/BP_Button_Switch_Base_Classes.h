#pragma once 
#include <BP_Button_Switch_Base_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Button_Switch_Base.BP_Button_Switch_Base_C
// Size: 0x308(Inherited: 0x288) 
struct ABP_Button_Switch_Base_C : public ASwitch
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x288(0x8)
	struct UStaticMeshComponent* ButtonMesh;  // 0x290(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x298(0x8)
	float ButtonAnimationTimeline_Driver_706794914E7651E5C9DB58899377931D;  // 0x2A0(0x4)
	char ETimelineDirection ButtonAnimationTimeline__Direction_706794914E7651E5C9DB58899377931D;  // 0x2A4(0x1)
	char pad_677[3];  // 0x2A5(0x3)
	struct UTimelineComponent* ButtonAnimationTimeline;  // 0x2A8(0x8)
	float LightTimeline_Driver_90BABA7A4D1801437BC991A3CFB652BF;  // 0x2B0(0x4)
	char ETimelineDirection LightTimeline__Direction_90BABA7A4D1801437BC991A3CFB652BF;  // 0x2B4(0x1)
	char pad_693[3];  // 0x2B5(0x3)
	struct UTimelineComponent* LightTimeline;  // 0x2B8(0x8)
	struct FLinearColor OnLightColor;  // 0x2C0(0x10)
	struct FLinearColor OffLightColor;  // 0x2D0(0x10)
	char pad_736_1 : 7;  // 0x2E0(0x1)
	bool UseBaseVisualUpdate : 1;  // 0x2E0(0x1)
	char pad_737_1 : 7;  // 0x2E1(0x1)
	bool UseBaseLightVisualUpdate : 1;  // 0x2E1(0x1)
	char pad_738[2];  // 0x2E2(0x2)
	struct FVector InitialButtonLocationVector;  // 0x2E4(0xC)
	struct UMaterialInterface* ButtonDMI_SourceMaterial;  // 0x2F0(0x8)
	struct FName ButtonDMI_VectorParameterName;  // 0x2F8(0x8)
	struct USoundCue* ActiveSoundCue;  // 0x300(0x8)

	void UserConstructionScript(); // Function BP_Button_Switch_Base.BP_Button_Switch_Base_C.UserConstructionScript
	void ButtonAnimationTimeline__FinishedFunc(); // Function BP_Button_Switch_Base.BP_Button_Switch_Base_C.ButtonAnimationTimeline__FinishedFunc
	void ButtonAnimationTimeline__UpdateFunc(); // Function BP_Button_Switch_Base.BP_Button_Switch_Base_C.ButtonAnimationTimeline__UpdateFunc
	void LightTimeline__FinishedFunc(); // Function BP_Button_Switch_Base.BP_Button_Switch_Base_C.LightTimeline__FinishedFunc
	void LightTimeline__UpdateFunc(); // Function BP_Button_Switch_Base.BP_Button_Switch_Base_C.LightTimeline__UpdateFunc
	void OnOpenStateChanged(bool IsOpen, struct AActor* ActorInstigator); // Function BP_Button_Switch_Base.BP_Button_Switch_Base_C.OnOpenStateChanged
	void ImplementableOnLightTimelineFinished(char ETimelineDirection TimelineDirection); // Function BP_Button_Switch_Base.BP_Button_Switch_Base_C.ImplementableOnLightTimelineFinished
	void OnUpdateVisualState(bool IsOpen); // Function BP_Button_Switch_Base.BP_Button_Switch_Base_C.OnUpdateVisualState
	void ExecuteUbergraph_BP_Button_Switch_Base(int32_t EntryPoint); // Function BP_Button_Switch_Base.BP_Button_Switch_Base_C.ExecuteUbergraph_BP_Button_Switch_Base
}; 



