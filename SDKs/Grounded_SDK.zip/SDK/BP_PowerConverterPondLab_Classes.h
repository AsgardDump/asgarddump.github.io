#pragma once 
#include <BP_PowerConverterPondLab_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_PowerConverterPondLab.BP_PowerConverterPondLab_C
// Size: 0x2A0(Inherited: 0x230) 
struct ABP_PowerConverterPondLab_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x230(0x8)
	struct UStaticMeshComponent* SM_Lab_Breaker_Indicator_A;  // 0x238(0x8)
	struct UConditionalToggleComponent* ConditionalToggle_PondBreakers1stTimeFinish;  // 0x240(0x8)
	struct UConditionalToggleComponent* ConditionalToggle_AllBreakersOn;  // 0x248(0x8)
	struct UPointLightComponent* PointLight3;  // 0x250(0x8)
	struct UPointLightComponent* PointLight2;  // 0x258(0x8)
	struct UPointLightComponent* PointLight1;  // 0x260(0x8)
	struct UPersistenceComponent* PersistenceComponent;  // 0x268(0x8)
	struct UObsidianIDComponent* ObsidianIDComponent;  // 0x270(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x278(0x8)
	int32_t nLightOn;  // 0x280(0x4)
	char pad_644[4];  // 0x284(0x4)
	struct ADoor* MoonpoolDoor;  // 0x288(0x8)
	struct TArray<struct ABP_Fan_B_C*> ConnectedFans;  // 0x290(0x10)

	void LightTurnOn(int32_t BreakerID); // Function BP_PowerConverterPondLab.BP_PowerConverterPondLab_C.LightTurnOn
	void BndEvt__ConditionalToggle_AllBreakersOn_K2Node_ComponentBoundEvent_0_OnConditionalStateChanged__DelegateSignature(bool bIsActive); // Function BP_PowerConverterPondLab.BP_PowerConverterPondLab_C.BndEvt__ConditionalToggle_AllBreakersOn_K2Node_ComponentBoundEvent_0_OnConditionalStateChanged__DelegateSignature
	void ToggleConnectedFans(bool ToggleOn); // Function BP_PowerConverterPondLab.BP_PowerConverterPondLab_C.ToggleConnectedFans
	void ExecuteUbergraph_BP_PowerConverterPondLab(int32_t EntryPoint); // Function BP_PowerConverterPondLab.BP_PowerConverterPondLab_C.ExecuteUbergraph_BP_PowerConverterPondLab
}; 



