#pragma once 
#include <BP_BuildingLootBag_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_BuildingLootBag.BP_BuildingLootBag_C
// Size: 0x348(Inherited: 0x340) 
struct ABP_BuildingLootBag_C : public ALootBag
{
	struct UStaticMeshComponent* StaticMesh;  // 0x340(0x8)

}; 



