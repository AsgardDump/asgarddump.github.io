#pragma once 
#include <BP_Explosive_VFX_HazeFungus_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Explosive_VFX_HazeFungus.BP_Explosive_VFX_HazeFungus_C
// Size: 0x34C(Inherited: 0x34C) 
struct ABP_Explosive_VFX_HazeFungus_C : public ABP_Explosive_VFX_Base_C
{

}; 



