#pragma once 
#include <BP_BerryDestroy_Particle_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_BerryDestroy_Particle.BP_BerryDestroy_Particle_C
// Size: 0x270(Inherited: 0x230) 
struct ABP_BerryDestroy_Particle_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x230(0x8)
	struct USceneComponent* Root;  // 0x238(0x8)
	struct UParticleSystemComponent* P_Bug_Juice_A;  // 0x240(0x8)
	float FadeStartDelay;  // 0x248(0x4)
	float Fade Duration;  // 0x24C(0x4)
	struct UDecalComponent* SpawnedDecal;  // 0x250(0x8)
	struct FLinearColor DecalColor;  // 0x258(0x10)
	struct UMaterialInterface* DecalMaterial;  // 0x268(0x8)

	void ReceiveBeginPlay(); // Function BP_BerryDestroy_Particle.BP_BerryDestroy_Particle_C.ReceiveBeginPlay
	void ExecuteUbergraph_BP_BerryDestroy_Particle(int32_t EntryPoint); // Function BP_BerryDestroy_Particle.BP_BerryDestroy_Particle_C.ExecuteUbergraph_BP_BerryDestroy_Particle
}; 



