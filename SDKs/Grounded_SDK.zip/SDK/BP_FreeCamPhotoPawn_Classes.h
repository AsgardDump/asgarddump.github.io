#pragma once 
#include <BP_FreeCamPhotoPawn_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_FreeCamPhotoPawn.BP_FreeCamPhotoPawn_C
// Size: 0x320(Inherited: 0x308) 
struct ABP_FreeCamPhotoPawn_C : public AMaineFreeCamPhotoPawn
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x308(0x8)
	struct USphereComponent* WaterCollision;  // 0x310(0x8)
	char pad_792_1 : 7;  // 0x318(0x1)
	bool AreSettingsOpen : 1;  // 0x318(0x1)
	char pad_793[3];  // 0x319(0x3)
	int32_t WaterVolumeOverlapCount;  // 0x31C(0x4)

	void ExitPhotoMode(); // Function BP_FreeCamPhotoPawn.BP_FreeCamPhotoPawn_C.ExitPhotoMode
	void BrowsePhotos(); // Function BP_FreeCamPhotoPawn.BP_FreeCamPhotoPawn_C.BrowsePhotos
	void ChangeCameraType(); // Function BP_FreeCamPhotoPawn.BP_FreeCamPhotoPawn_C.ChangeCameraType
	void ExecuteUbergraph_BP_FreeCamPhotoPawn(int32_t EntryPoint); // Function BP_FreeCamPhotoPawn.BP_FreeCamPhotoPawn_C.ExecuteUbergraph_BP_FreeCamPhotoPawn
}; 



