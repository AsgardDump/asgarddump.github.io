#pragma once 
#include "SDK.h" 
 
 
// Function BP_Button_Switch_Base.BP_Button_Switch_Base_C.ExecuteUbergraph_BP_Button_Switch_Base
// Size: 0x11C(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Button_Switch_Base
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UDynamicMaterialCache* CallFunc_GetDynamicMaterialCache_ReturnValue;  // 0x8(0x8)
	char ETimelineDirection Temp_byte_Variable;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)
	struct FLinearColor K2Node_Select_Default;  // 0x14(0x10)
	char pad_36_1 : 7;  // 0x24(0x1)
	bool K2Node_Event_IsOpen_2 : 1;  // 0x24(0x1)
	char pad_37[3];  // 0x25(0x3)
	struct AActor* K2Node_Event_ActorInstigator;  // 0x28(0x8)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x30(0xC)
	char ETimelineDirection K2Node_CustomEvent_TimelineDirection;  // 0x3C(0x1)
	char pad_61[3];  // 0x3D(0x3)
	struct UMaterialInstanceDynamic* CallFunc_AssignDynamicMaterialWithColor_ReturnValue;  // 0x40(0x8)
	struct FRotator CallFunc_K2_GetComponentRotation_ReturnValue;  // 0x48(0xC)
	struct FVector CallFunc_GetUpVector_ReturnValue;  // 0x54(0xC)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue;  // 0x60(0xC)
	struct FVector CallFunc_Add_VectorVector_ReturnValue;  // 0x6C(0xC)
	struct FVector CallFunc_VLerp_ReturnValue;  // 0x78(0xC)
	char pad_132_1 : 7;  // 0x84(0x1)
	bool K2Node_Event_IsOpen : 1;  // 0x84(0x1)
	char pad_133[3];  // 0x85(0x3)
	struct FHitResult CallFunc_K2_SetWorldLocation_SweepHitResult;  // 0x88(0x88)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_2;  // 0x110(0xC)

}; 
// Function BP_Button_Switch_Base.BP_Button_Switch_Base_C.UserConstructionScript
// Size: 0xC(Inherited: 0x0) 
struct FUserConstructionScript : public FUserConstructionScript
{
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue;  // 0x0(0xC)

}; 
// Function BP_Button_Switch_Base.BP_Button_Switch_Base_C.ImplementableOnLightTimelineFinished
// Size: 0x1(Inherited: 0x0) 
struct FImplementableOnLightTimelineFinished
{
	char ETimelineDirection TimelineDirection;  // 0x0(0x1)

}; 
// Function BP_Button_Switch_Base.BP_Button_Switch_Base_C.OnUpdateVisualState
// Size: 0x1(Inherited: 0x1) 
struct FOnUpdateVisualState : public FOnUpdateVisualState
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool IsOpen : 1;  // 0x0(0x1)

}; 
// Function BP_Button_Switch_Base.BP_Button_Switch_Base_C.OnOpenStateChanged
// Size: 0x10(Inherited: 0x10) 
struct FOnOpenStateChanged : public FOnOpenStateChanged
{
	char pad_16_1 : 7;  // 0x10(0x1)
	bool IsOpen : 1;  // 0x0(0x1)
	struct AActor* ActorInstigator;  // 0x8(0x8)

}; 
