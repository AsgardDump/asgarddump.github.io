#pragma once 
#include <BP_Grapple_Point_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Grapple_Point.BP_Grapple_Point_C
// Size: 0x258(Inherited: 0x230) 
struct ABP_Grapple_Point_C : public AActor
{
	struct UBillboardComponent* Billboard;  // 0x230(0x8)
	struct UStaticMeshComponent* RootMesh2;  // 0x238(0x8)
	struct UStaticMeshComponent* RootMesh1;  // 0x240(0x8)
	struct USceneComponent* GrapplePoint;  // 0x248(0x8)
	struct UStaticMeshComponent* RootMesh;  // 0x250(0x8)

}; 



