#pragma once 
#include <BP_Rock_ArmorStone3_A_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Rock_ArmorStone3_A.BP_Rock_ArmorStone3_A_C
// Size: 0x398(Inherited: 0x398) 
struct ABP_Rock_ArmorStone3_A_C : public ABP_Rock_ArmorStone1_A_Large_C
{

}; 



