#pragma once 
#include <BP_Mushroom_SmallRound_A_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Mushroom_SmallRound_A.BP_Mushroom_SmallRound_A_C
// Size: 0x469(Inherited: 0x469) 
struct ABP_Mushroom_SmallRound_A_C : public ABP_BASE_Mushroom_C
{

}; 



