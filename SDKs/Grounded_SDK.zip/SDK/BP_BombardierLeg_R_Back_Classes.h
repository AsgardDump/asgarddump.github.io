#pragma once 
#include <BP_BombardierLeg_R_Back_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_BombardierLeg_R_Back.BP_BombardierLeg_R_Back_C
// Size: 0x2A3(Inherited: 0x2A3) 
struct ABP_BombardierLeg_R_Back_C : public ABP_InsectPart_C
{

}; 



