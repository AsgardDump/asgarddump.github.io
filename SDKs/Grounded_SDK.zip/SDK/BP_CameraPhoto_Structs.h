#pragma once 
#include "SDK.h" 
 
 
// Function BP_CameraPhoto.BP_CameraPhoto_C.ExecuteUbergraph_BP_CameraPhoto
// Size: 0x18(Inherited: 0x0) 
struct FExecuteUbergraph_BP_CameraPhoto
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UTexture* K2Node_CustomEvent_Texture;  // 0x8(0x8)
	struct UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue;  // 0x10(0x8)

}; 
// Function BP_CameraPhoto.BP_CameraPhoto_C.SetTexture
// Size: 0x8(Inherited: 0x0) 
struct FSetTexture
{
	struct UTexture* Texture;  // 0x0(0x8)

}; 
