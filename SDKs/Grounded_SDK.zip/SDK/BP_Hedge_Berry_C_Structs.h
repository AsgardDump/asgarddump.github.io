#pragma once 
#include "SDK.h" 
 
 
// Function BP_Hedge_Berry_C.BP_Hedge_Berry_C_C.ExecuteUbergraph_BP_Hedge_Berry_C
// Size: 0x4(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Hedge_Berry_C
{
	int32_t EntryPoint;  // 0x0(0x4)

}; 
