#pragma once 
#include "SDK.h" 
 
 
// Function BP_BuilderPawn.BP_BuilderPawn_C.Handle Boop
// Size: 0x88(Inherited: 0x0) 
struct FHandle Boop
{
	struct FHitResult HitResult;  // 0x0(0x88)

}; 
// Function BP_BuilderPawn.BP_BuilderPawn_C.ExecuteUbergraph_BP_BuilderPawn
// Size: 0x770(Inherited: 0x0) 
struct FExecuteUbergraph_BP_BuilderPawn
{
	int32_t EntryPoint;  // 0x0(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x4(0x4)
	struct FRotator CallFunc_MakeRotator_ReturnValue;  // 0x8(0xC)
	struct FRotator CallFunc_MakeRotator_ReturnValue_2;  // 0x14(0xC)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0x20(0x1)
	char pad_33[3];  // 0x21(0x3)
	float K2Node_Event_DeltaSeconds;  // 0x24(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_2;  // 0x28(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0x2C(0x4)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_HitComponent;  // 0x30(0x8)
	struct AActor* K2Node_ComponentBoundEvent_OtherActor;  // 0x38(0x8)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OtherComp;  // 0x40(0x8)
	struct FVector K2Node_ComponentBoundEvent_NormalImpulse;  // 0x48(0xC)
	struct FHitResult K2Node_ComponentBoundEvent_Hit;  // 0x54(0x88)
	struct FHitResult CallFunc_K2_SetRelativeRotation_SweepHitResult;  // 0xDC(0x88)
	char pad_356[4];  // 0x164(0x4)
	struct AProjectile* K2Node_DynamicCast_AsProjectile;  // 0x168(0x8)
	char pad_368_1 : 7;  // 0x170(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x170(0x1)
	char pad_369[7];  // 0x171(0x7)
	struct ASpawnedItem* K2Node_DynamicCast_AsSpawned_Item;  // 0x178(0x8)
	char pad_384_1 : 7;  // 0x180(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x180(0x1)
	char pad_385[7];  // 0x181(0x7)
	struct APawn* K2Node_DynamicCast_AsPawn;  // 0x188(0x8)
	char pad_400_1 : 7;  // 0x190(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x190(0x1)
	char pad_401[3];  // 0x191(0x3)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x194(0xC)
	struct FHitResult K2Node_CustomEvent_HitResult_2;  // 0x1A0(0x88)
	char pad_552_1 : 7;  // 0x228(0x1)
	bool CallFunc_BreakHitResult_bBlockingHit : 1;  // 0x228(0x1)
	char pad_553_1 : 7;  // 0x229(0x1)
	bool CallFunc_BreakHitResult_bInitialOverlap : 1;  // 0x229(0x1)
	char pad_554[2];  // 0x22A(0x2)
	float CallFunc_BreakHitResult_Time;  // 0x22C(0x4)
	float CallFunc_BreakHitResult_Distance;  // 0x230(0x4)
	struct FVector CallFunc_BreakHitResult_Location;  // 0x234(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactPoint;  // 0x240(0xC)
	struct FVector CallFunc_BreakHitResult_Normal;  // 0x24C(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactNormal;  // 0x258(0xC)
	char pad_612[4];  // 0x264(0x4)
	struct UPhysicalMaterial* CallFunc_BreakHitResult_PhysMat;  // 0x268(0x8)
	struct AActor* CallFunc_BreakHitResult_HitActor;  // 0x270(0x8)
	struct UPrimitiveComponent* CallFunc_BreakHitResult_HitComponent;  // 0x278(0x8)
	struct FName CallFunc_BreakHitResult_HitBoneName;  // 0x280(0x8)
	int32_t CallFunc_BreakHitResult_HitItem;  // 0x288(0x4)
	int32_t CallFunc_BreakHitResult_ElementIndex;  // 0x28C(0x4)
	int32_t CallFunc_BreakHitResult_FaceIndex;  // 0x290(0x4)
	struct FVector CallFunc_BreakHitResult_TraceStart;  // 0x294(0xC)
	struct FVector CallFunc_BreakHitResult_TraceEnd;  // 0x2A0(0xC)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue;  // 0x2AC(0xC)
	char pad_696_1 : 7;  // 0x2B8(0x1)
	bool K2Node_Event_bEnabled : 1;  // 0x2B8(0x1)
	char pad_697[3];  // 0x2B9(0x3)
	float CallFunc_SelectFloat_ReturnValue;  // 0x2BC(0x4)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_2;  // 0x2C0(0xC)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_3;  // 0x2CC(0xC)
	struct FLinearColor CallFunc_Conv_VectorToLinearColor_ReturnValue;  // 0x2D8(0x10)
	char pad_744_1 : 7;  // 0x2E8(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x2E8(0x1)
	char pad_745[3];  // 0x2E9(0x3)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_4;  // 0x2EC(0xC)
	char EEndPlayReason K2Node_Event_EndPlayReason;  // 0x2F8(0x1)
	char pad_761[7];  // 0x2F9(0x7)
	struct UParticleSystemComponent* CallFunc_SpawnEmitterAtLocation_ReturnValue;  // 0x300(0x8)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_5;  // 0x308(0xC)
	char pad_788[4];  // 0x314(0x4)
	struct UParticleSystemComponent* CallFunc_SpawnEmitterAtLocation_ReturnValue_2;  // 0x318(0x8)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_6;  // 0x320(0xC)
	float CallFunc_Add_FloatFloat_ReturnValue_2;  // 0x32C(0x4)
	float CallFunc_SamplePerlinNoise1D_ReturnValue;  // 0x330(0x4)
	float CallFunc_SamplePerlinNoise1D_ReturnValue_2;  // 0x334(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_3;  // 0x338(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_4;  // 0x33C(0x4)
	struct FVector CallFunc_MakeVector_ReturnValue;  // 0x340(0xC)
	struct FHitResult CallFunc_K2_SetRelativeLocation_SweepHitResult;  // 0x34C(0x88)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_7;  // 0x3D4(0xC)
	struct ASurvivalGameState* CallFunc_GetSurvivalGameState_ReturnValue;  // 0x3E0(0x8)
	struct FRotator K2Node_CustomEvent_EndResult;  // 0x3E8(0xC)
	float K2Node_CustomEvent_SpeedScaler;  // 0x3F4(0x4)
	float CallFunc_GetWorldDeltaSeconds_ReturnValue;  // 0x3F8(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_5;  // 0x3FC(0x4)
	struct FRotator CallFunc_RandomRotator_ReturnValue;  // 0x400(0xC)
	struct FRotator CallFunc_RLerp_ReturnValue;  // 0x40C(0xC)
	struct FHitResult CallFunc_K2_SetRelativeRotation_SweepHitResult_2;  // 0x418(0x88)
	struct FHitResult K2Node_CustomEvent_HitResult;  // 0x4A0(0x88)
	char pad_1320_1 : 7;  // 0x528(0x1)
	bool CallFunc_BreakHitResult_bBlockingHit_2 : 1;  // 0x528(0x1)
	char pad_1321_1 : 7;  // 0x529(0x1)
	bool CallFunc_BreakHitResult_bInitialOverlap_2 : 1;  // 0x529(0x1)
	char pad_1322[2];  // 0x52A(0x2)
	float CallFunc_BreakHitResult_Time_2;  // 0x52C(0x4)
	float CallFunc_BreakHitResult_Distance_2;  // 0x530(0x4)
	struct FVector CallFunc_BreakHitResult_Location_2;  // 0x534(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactPoint_2;  // 0x540(0xC)
	struct FVector CallFunc_BreakHitResult_Normal_2;  // 0x54C(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactNormal_2;  // 0x558(0xC)
	char pad_1380[4];  // 0x564(0x4)
	struct UPhysicalMaterial* CallFunc_BreakHitResult_PhysMat_2;  // 0x568(0x8)
	struct AActor* CallFunc_BreakHitResult_HitActor_2;  // 0x570(0x8)
	struct UPrimitiveComponent* CallFunc_BreakHitResult_HitComponent_2;  // 0x578(0x8)
	struct FName CallFunc_BreakHitResult_HitBoneName_2;  // 0x580(0x8)
	int32_t CallFunc_BreakHitResult_HitItem_2;  // 0x588(0x4)
	int32_t CallFunc_BreakHitResult_ElementIndex_2;  // 0x58C(0x4)
	int32_t CallFunc_BreakHitResult_FaceIndex_2;  // 0x590(0x4)
	struct FVector CallFunc_BreakHitResult_TraceStart_2;  // 0x594(0xC)
	struct FVector CallFunc_BreakHitResult_TraceEnd_2;  // 0x5A0(0xC)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue_2;  // 0x5AC(0xC)
	struct FHitResult CallFunc_K2_SetRelativeRotation_SweepHitResult_3;  // 0x5B8(0x88)
	struct FRotator CallFunc_NormalizedDeltaRotator_ReturnValue;  // 0x640(0xC)
	float CallFunc_BreakRotator_Roll;  // 0x64C(0x4)
	float CallFunc_BreakRotator_Pitch;  // 0x650(0x4)
	float CallFunc_BreakRotator_Yaw;  // 0x654(0x4)
	char pad_1624_1 : 7;  // 0x658(0x1)
	bool CallFunc_LessEqual_FloatFloat_ReturnValue : 1;  // 0x658(0x1)
	char pad_1625_1 : 7;  // 0x659(0x1)
	bool CallFunc_LessEqual_FloatFloat_ReturnValue_2 : 1;  // 0x659(0x1)
	char pad_1626_1 : 7;  // 0x65A(0x1)
	bool CallFunc_LessEqual_FloatFloat_ReturnValue_3 : 1;  // 0x65A(0x1)
	char pad_1627_1 : 7;  // 0x65B(0x1)
	bool CallFunc_IsNightTime_ReturnValue : 1;  // 0x65B(0x1)
	char pad_1628_1 : 7;  // 0x65C(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x65C(0x1)
	char pad_1629_1 : 7;  // 0x65D(0x1)
	bool CallFunc_BooleanAND_ReturnValue_2 : 1;  // 0x65D(0x1)
	char pad_1630[2];  // 0x65E(0x2)
	struct FHitResult CallFunc_K2_SetRelativeRotation_SweepHitResult_4;  // 0x660(0x88)
	struct FHitResult CallFunc_K2_SetRelativeLocation_SweepHitResult_2;  // 0x6E8(0x88)

}; 
// Function BP_BuilderPawn.BP_BuilderPawn_C.ReceiveTick
// Size: 0x4(Inherited: 0x4) 
struct FReceiveTick : public FReceiveTick
{
	float DeltaSeconds;  // 0x0(0x4)

}; 
// Function BP_BuilderPawn.BP_BuilderPawn_C.HandleHit
// Size: 0x88(Inherited: 0x0) 
struct FHandleHit
{
	struct FHitResult HitResult;  // 0x0(0x88)

}; 
// Function BP_BuilderPawn.BP_BuilderPawn_C.BndEvt__CapsuleComponent_K2Node_ComponentBoundEvent_1_ComponentHitSignature__DelegateSignature
// Size: 0xAC(Inherited: 0x0) 
struct FBndEvt__CapsuleComponent_K2Node_ComponentBoundEvent_1_ComponentHitSignature__DelegateSignature
{
	struct UPrimitiveComponent* HitComponent;  // 0x0(0x8)
	struct AActor* OtherActor;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	struct FVector NormalImpulse;  // 0x18(0xC)
	struct FHitResult Hit;  // 0x24(0x88)

}; 
// Function BP_BuilderPawn.BP_BuilderPawn_C.ReceiveEndPlay
// Size: 0x1(Inherited: 0x1) 
struct FReceiveEndPlay : public FReceiveEndPlay
{
	char EEndPlayReason EndPlayReason;  // 0x0(0x1)

}; 
// Function BP_BuilderPawn.BP_BuilderPawn_C.RotateMeshTo
// Size: 0x10(Inherited: 0x0) 
struct FRotateMeshTo
{
	struct FRotator EndResult;  // 0x0(0xC)
	float SpeedScaler;  // 0xC(0x4)

}; 
// Function BP_BuilderPawn.BP_BuilderPawn_C.InputLightTogglePressed
// Size: 0x1(Inherited: 0x1) 
struct FInputLightTogglePressed : public FInputLightTogglePressed
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool bEnabled : 1;  // 0x0(0x1)

}; 
// Function BP_BuilderPawn.BP_BuilderPawn_C.GetCameraViewTransform
// Size: 0x60(Inherited: 0x30) 
struct FGetCameraViewTransform : public FGetCameraViewTransform
{
	struct FTransform ReturnValue;  // 0x0(0x30)
	struct FTransform CallFunc_GetSocketTransform_ReturnValue;  // 0x30(0x30)

}; 
// Function BP_BuilderPawn.BP_BuilderPawn_C.InitHeadlampMID
// Size: 0x10(Inherited: 0x0) 
struct FInitHeadlampMID
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue;  // 0x8(0x8)

}; 
