#pragma once 
#include <BP_Mushroom_SmallRound_B_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Mushroom_SmallRound_B.BP_Mushroom_SmallRound_B_C
// Size: 0x469(Inherited: 0x469) 
struct ABP_Mushroom_SmallRound_B_C : public ABP_BASE_Mushroom_C
{

}; 



