#pragma once 
#include <BP_Mushroom_Toadstool_B_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Mushroom_Toadstool_B.BP_Mushroom_Toadstool_B_C
// Size: 0x498(Inherited: 0x498) 
struct ABP_Mushroom_Toadstool_B_C : public ABP_Mushroom_Toadstool_A_C
{

}; 



