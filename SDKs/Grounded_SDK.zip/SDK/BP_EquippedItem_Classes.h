#pragma once 
#include <BP_EquippedItem_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_EquippedItem.BP_EquippedItem_C
// Size: 0x4A8(Inherited: 0x488) 
struct ABP_EquippedItem_C : public ASpawnedItem
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x488(0x8)
	struct UStaticMeshComponent* StaticMesh;  // 0x490(0x8)
	struct USceneComponent* SceneRoot;  // 0x498(0x8)
	struct UDropletContentsComponent* DropletContents;  // 0x4A0(0x8)

	bool ValidateItemData(struct TArray<struct FText>& ValidationErrors); // Function BP_EquippedItem.BP_EquippedItem_C.ValidateItemData
	char EInteractionState IsInteractionEnabled(uint8_t  Channel, struct AActor* InstigatedBy); // Function BP_EquippedItem.BP_EquippedItem_C.IsInteractionEnabled
	void ReceiveBeginPlay(); // Function BP_EquippedItem.BP_EquippedItem_C.ReceiveBeginPlay
	void PowerStateChanged(bool PowerState); // Function BP_EquippedItem.BP_EquippedItem_C.PowerStateChanged
	void ExecuteUbergraph_BP_EquippedItem(int32_t EntryPoint); // Function BP_EquippedItem.BP_EquippedItem_C.ExecuteUbergraph_BP_EquippedItem
}; 



