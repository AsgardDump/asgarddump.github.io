#pragma once 
#include <BP_Protohive_Fallen_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Protohive_Fallen.BP_Protohive_Fallen_C
// Size: 0x368(Inherited: 0x368) 
struct ABP_Protohive_Fallen_C : public ABP_StaticHarvestNode_C
{

}; 



