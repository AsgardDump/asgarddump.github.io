#pragma once 
#include "SDK.h" 
 
 
// Function BP_Milk_Nugget_Personal.BP_Milk_Nugget_Personal_C.ExecuteUbergraph_BP_Milk_Nugget_Personal
// Size: 0x112(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Milk_Nugget_Personal
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UHealthComponent* K2Node_ComponentBoundEvent_SourceHealthComponent;  // 0x8(0x8)
	float K2Node_ComponentBoundEvent_NewHealth;  // 0x10(0x4)
	float K2Node_ComponentBoundEvent_OldHealth;  // 0x14(0x4)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OverlappedComponent;  // 0x18(0x8)
	struct AActor* K2Node_ComponentBoundEvent_OtherActor;  // 0x20(0x8)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OtherComp;  // 0x28(0x8)
	int32_t K2Node_ComponentBoundEvent_OtherBodyIndex;  // 0x30(0x4)
	char pad_52_1 : 7;  // 0x34(0x1)
	bool K2Node_ComponentBoundEvent_bFromSweep : 1;  // 0x34(0x1)
	char pad_53[3];  // 0x35(0x3)
	struct FHitResult K2Node_ComponentBoundEvent_SweepResult;  // 0x38(0x88)
	struct FDataTableRowHandle K2Node_MakeStruct_DataTableRowHandle;  // 0xC0(0x10)
	struct ASurvivalPlayerCharacter* K2Node_DynamicCast_AsSurvival_Player_Character;  // 0xD0(0x8)
	char pad_216_1 : 7;  // 0xD8(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0xD8(0x1)
	char pad_217[7];  // 0xD9(0x7)
	struct ASurvivalPlayerState* CallFunc_GetPlayerStateMatchingCharacter_ReturnValue;  // 0xE0(0x8)
	float CallFunc_GetHealthRatio_ReturnValue;  // 0xE8(0x4)
	char pad_236_1 : 7;  // 0xEC(0x1)
	bool CallFunc_Less_FloatFloat_ReturnValue : 1;  // 0xEC(0x1)
	char pad_237[3];  // 0xED(0x3)
	int32_t CallFunc_GetConsoleVariableIntValue_ReturnValue;  // 0xF0(0x4)
	char pad_244_1 : 7;  // 0xF4(0x1)
	bool CallFunc_GreaterEqual_IntInt_ReturnValue : 1;  // 0xF4(0x1)
	char pad_245[3];  // 0xF5(0x3)
	struct TArray<struct UStaticMeshComponent*> K2Node_MakeArray_Array;  // 0xF8(0x10)
	struct UStaticMeshComponent* K2Node_Event_Chunk;  // 0x108(0x8)
	char pad_272_1 : 7;  // 0x110(0x1)
	bool CallFunc_IsPlaying_ReturnValue : 1;  // 0x110(0x1)
	char pad_273_1 : 7;  // 0x111(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x111(0x1)

}; 
// Function BP_Milk_Nugget_Personal.BP_Milk_Nugget_Personal_C.BndEvt__BP_Milk_Nugget_Personal_HealthComponent_K2Node_ComponentBoundEvent_1_HealthChangedDelegate__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FBndEvt__BP_Milk_Nugget_Personal_HealthComponent_K2Node_ComponentBoundEvent_1_HealthChangedDelegate__DelegateSignature
{
	struct UHealthComponent* SourceHealthComponent;  // 0x0(0x8)
	float NewHealth;  // 0x8(0x4)
	float OldHealth;  // 0xC(0x4)

}; 
// Function BP_Milk_Nugget_Personal.BP_Milk_Nugget_Personal_C.ShouldRestoreTransform
// Size: 0x1(Inherited: 0x1) 
struct FShouldRestoreTransform : public FShouldRestoreTransform
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function BP_Milk_Nugget_Personal.BP_Milk_Nugget_Personal_C.BndEvt__BP_Milk_Nugget_Personal_TutorialOverlap_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature
// Size: 0xA8(Inherited: 0x0) 
struct FBndEvt__BP_Milk_Nugget_Personal_TutorialOverlap_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature
{
	struct UPrimitiveComponent* OverlappedComponent;  // 0x0(0x8)
	struct AActor* OtherActor;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	int32_t OtherBodyIndex;  // 0x18(0x4)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool bFromSweep : 1;  // 0x1C(0x1)
	char pad_29[3];  // 0x1D(0x3)
	struct FHitResult SweepResult;  // 0x20(0x88)

}; 
// Function BP_Milk_Nugget_Personal.BP_Milk_Nugget_Personal_C.DestroyChunk
// Size: 0x8(Inherited: 0x8) 
struct FDestroyChunk : public FDestroyChunk
{
	struct UStaticMeshComponent* Chunk;  // 0x0(0x8)

}; 
