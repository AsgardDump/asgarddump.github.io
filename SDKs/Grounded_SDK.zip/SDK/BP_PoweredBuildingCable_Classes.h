#pragma once 
#include <BP_PoweredBuildingCable_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_PoweredBuildingCable.BP_PoweredBuildingCable_C
// Size: 0x2A0(Inherited: 0x288) 
struct ABP_PoweredBuildingCable_C : public ABuildingPowerCable
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x288(0x8)
	struct USplineMeshComponent* SplineMesh;  // 0x290(0x8)
	struct UMaterialInstanceDynamic* TracerMID;  // 0x298(0x8)

	void UserConstructionScript(); // Function BP_PoweredBuildingCable.BP_PoweredBuildingCable_C.UserConstructionScript
	void ReceiveTick(float DeltaSeconds); // Function BP_PoweredBuildingCable.BP_PoweredBuildingCable_C.ReceiveTick
	void ExecuteUbergraph_BP_PoweredBuildingCable(int32_t EntryPoint); // Function BP_PoweredBuildingCable.BP_PoweredBuildingCable_C.ExecuteUbergraph_BP_PoweredBuildingCable
}; 



