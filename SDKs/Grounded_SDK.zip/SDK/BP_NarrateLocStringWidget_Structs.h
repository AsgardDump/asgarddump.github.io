#pragma once 
#include "SDK.h" 
 
 
// Function BP_NarrateLocStringWidget.BP_NarrateLocStringWidget_C.GetNarration
// Size: 0x50(Inherited: 0x18) 
struct FGetNarration : public FGetNarration
{
	struct TArray<struct FNarrationChunk> Chunks;  // 0x0(0x10)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool bVerbose : 1;  // 0x10(0x1)
	struct FString CallFunc_GetLocStringText_ReturnValue;  // 0x18(0x10)
	struct FNarrationChunk CallFunc_AddNarrationChunkString_ReturnValue;  // 0x28(0x28)

}; 
