#pragma once 
#include <BP_Food_Donut_Rotten_Bite_StandIn_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Food_Donut_Rotten_Bite_StandIn.BP_Food_Donut_Rotten_Bite_StandIn_C
// Size: 0x240(Inherited: 0x240) 
struct ABP_Food_Donut_Rotten_Bite_StandIn_C : public AProxyStandInActor
{

}; 



