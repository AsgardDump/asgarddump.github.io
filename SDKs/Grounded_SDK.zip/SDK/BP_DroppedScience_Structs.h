#pragma once 
#include "SDK.h" 
 
 
// Function BP_DroppedScience.BP_DroppedScience_C.ExecuteUbergraph_BP_DroppedScience
// Size: 0x28(Inherited: 0x0) 
struct FExecuteUbergraph_BP_DroppedScience
{
	int32_t EntryPoint;  // 0x0(0x4)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x4(0xC)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x10(0x10)
	struct ASurvivalPlayerCharacter* K2Node_CustomEvent_Character;  // 0x20(0x8)

}; 
// Function BP_DroppedScience.BP_DroppedScience_C.CustomEvent_1
// Size: 0x8(Inherited: 0x0) 
struct FCustomEvent_1
{
	struct ASurvivalPlayerCharacter* Character;  // 0x0(0x8)

}; 
