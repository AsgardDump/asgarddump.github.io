#pragma once 
#include <BP_BleedDamage_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_BleedDamage.BP_BleedDamage_C
// Size: 0x78(Inherited: 0x78) 
struct UBP_BleedDamage_C : public USurvivalDamageType
{

}; 



