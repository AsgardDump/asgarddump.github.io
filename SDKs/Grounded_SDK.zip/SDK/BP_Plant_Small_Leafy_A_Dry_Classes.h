#pragma once 
#include <BP_Plant_Small_Leafy_A_Dry_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Plant_Small_Leafy_A_Dry.BP_Plant_Small_Leafy_A_Dry_C
// Size: 0x4B8(Inherited: 0x4A8) 
struct ABP_Plant_Small_Leafy_A_Dry_C : public ABP_WorldItem_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x4A8(0x8)
	struct USceneComponent* Particle Spawn Pos;  // 0x4B0(0x8)

	void ReceiveBeginPlay(); // Function BP_Plant_Small_Leafy_A_Dry.BP_Plant_Small_Leafy_A_Dry_C.ReceiveBeginPlay
	void SpawnParticles(struct AActor* DestroyedActor); // Function BP_Plant_Small_Leafy_A_Dry.BP_Plant_Small_Leafy_A_Dry_C.SpawnParticles
	void ExecuteUbergraph_BP_Plant_Small_Leafy_A_Dry(int32_t EntryPoint); // Function BP_Plant_Small_Leafy_A_Dry.BP_Plant_Small_Leafy_A_Dry_C.ExecuteUbergraph_BP_Plant_Small_Leafy_A_Dry
}; 



