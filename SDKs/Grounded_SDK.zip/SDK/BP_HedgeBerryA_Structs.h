#pragma once 
#include "SDK.h" 
 
 
// Function BP_HedgeBerryA.BP_HedgeBerryA_C.OnRep_Squishmode
// Size: 0x18(Inherited: 0x0) 
struct FOnRep_Squishmode
{
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x0(0xC)
	char pad_12[4];  // 0xC(0x4)
	struct UAudioComponent* CallFunc_SpawnSoundAtLocation_ReturnValue;  // 0x10(0x8)

}; 
// Function BP_HedgeBerryA.BP_HedgeBerryA_C.ExecuteUbergraph_BP_HedgeBerryA
// Size: 0x15D(Inherited: 0x0) 
struct FExecuteUbergraph_BP_HedgeBerryA
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_HitComponent;  // 0x8(0x8)
	struct AActor* K2Node_ComponentBoundEvent_OtherActor;  // 0x10(0x8)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OtherComp;  // 0x18(0x8)
	struct FVector K2Node_ComponentBoundEvent_NormalImpulse;  // 0x20(0xC)
	struct FHitResult K2Node_ComponentBoundEvent_Hit;  // 0x2C(0x88)
	char pad_180_1 : 7;  // 0xB4(0x1)
	bool CallFunc_BreakHitResult_bBlockingHit : 1;  // 0xB4(0x1)
	char pad_181_1 : 7;  // 0xB5(0x1)
	bool CallFunc_BreakHitResult_bInitialOverlap : 1;  // 0xB5(0x1)
	char pad_182[2];  // 0xB6(0x2)
	float CallFunc_BreakHitResult_Time;  // 0xB8(0x4)
	float CallFunc_BreakHitResult_Distance;  // 0xBC(0x4)
	struct FVector CallFunc_BreakHitResult_Location;  // 0xC0(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactPoint;  // 0xCC(0xC)
	struct FVector CallFunc_BreakHitResult_Normal;  // 0xD8(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactNormal;  // 0xE4(0xC)
	struct UPhysicalMaterial* CallFunc_BreakHitResult_PhysMat;  // 0xF0(0x8)
	struct AActor* CallFunc_BreakHitResult_HitActor;  // 0xF8(0x8)
	struct UPrimitiveComponent* CallFunc_BreakHitResult_HitComponent;  // 0x100(0x8)
	struct FName CallFunc_BreakHitResult_HitBoneName;  // 0x108(0x8)
	int32_t CallFunc_BreakHitResult_HitItem;  // 0x110(0x4)
	int32_t CallFunc_BreakHitResult_ElementIndex;  // 0x114(0x4)
	int32_t CallFunc_BreakHitResult_FaceIndex;  // 0x118(0x4)
	struct FVector CallFunc_BreakHitResult_TraceStart;  // 0x11C(0xC)
	struct FVector CallFunc_BreakHitResult_TraceEnd;  // 0x128(0xC)
	float CallFunc_GetMass_ReturnValue;  // 0x134(0x4)
	float CallFunc_VSize_ReturnValue;  // 0x138(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x13C(0x4)
	struct FVector CallFunc_Vector_Up_ReturnValue;  // 0x140(0xC)
	char pad_332_1 : 7;  // 0x14C(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue : 1;  // 0x14C(0x1)
	char pad_333[3];  // 0x14D(0x3)
	struct FRotator CallFunc_FindLookAtRotation_ReturnValue;  // 0x150(0xC)
	char pad_348_1 : 7;  // 0x15C(0x1)
	bool CallFunc_K2_SetActorRotation_ReturnValue : 1;  // 0x15C(0x1)

}; 
// Function BP_HedgeBerryA.BP_HedgeBerryA_C.BndEvt__StaticMesh_K2Node_ComponentBoundEvent_0_ComponentHitSignature__DelegateSignature
// Size: 0xAC(Inherited: 0x0) 
struct FBndEvt__StaticMesh_K2Node_ComponentBoundEvent_0_ComponentHitSignature__DelegateSignature
{
	struct UPrimitiveComponent* HitComponent;  // 0x0(0x8)
	struct AActor* OtherActor;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	struct FVector NormalImpulse;  // 0x18(0xC)
	struct FHitResult Hit;  // 0x24(0x88)

}; 
// Function BP_HedgeBerryA.BP_HedgeBerryA_C.UserConstructionScript
// Size: 0x1(Inherited: 0x0) 
struct FUserConstructionScript : public FUserConstructionScript
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool CallFunc_SetStaticMesh_ReturnValue : 1;  // 0x0(0x1)

}; 
// Function BP_HedgeBerryA.BP_HedgeBerryA_C.UpdateStaticMesh
// Size: 0x1(Inherited: 0x0) 
struct FUpdateStaticMesh
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool CallFunc_SetStaticMesh_ReturnValue : 1;  // 0x0(0x1)

}; 
