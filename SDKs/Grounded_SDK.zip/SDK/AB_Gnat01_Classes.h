#pragma once 
#include <AB_Gnat01_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass AB_Gnat01.AB_Gnat01_C
// Size: 0x1240(Inherited: 0x360) 
struct UAB_Gnat01_C : public UCharacterAnimInstance
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x360(0x8)
	struct FAnimNode_Root AnimGraphNode_Root;  // 0x368(0x30)
	char pad_920[8];  // 0x398(0x8)
	struct FAnimNode_RigidBody AnimGraphNode_RigidBody;  // 0x3A0(0x830)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace;  // 0xBD0(0x20)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace;  // 0xBF0(0x20)
	struct FAnimNode_Slot AnimGraphNode_Slot;  // 0xC10(0x48)
	char pad_3160[8];  // 0xC58(0x8)
	struct FAnimNode_Trail AnimGraphNode_Trail_2;  // 0xC60(0x260)
	struct FAnimNode_Trail AnimGraphNode_Trail;  // 0xEC0(0x260)
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool;  // 0x1120(0xA0)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer;  // 0x11C0(0x80)

	void AnimGraph(struct FPoseLink& AnimGraph); // Function AB_Gnat01.AB_Gnat01_C.AnimGraph
	void ExecuteUbergraph_AB_Gnat01(int32_t EntryPoint); // Function AB_Gnat01.AB_Gnat01_C.ExecuteUbergraph_AB_Gnat01
}; 



