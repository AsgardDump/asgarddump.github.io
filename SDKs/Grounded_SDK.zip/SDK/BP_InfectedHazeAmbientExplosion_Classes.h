#pragma once 
#include <BP_InfectedHazeAmbientExplosion_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_InfectedHazeAmbientExplosion.BP_InfectedHazeAmbientExplosion_C
// Size: 0x2E4(Inherited: 0x230) 
struct ABP_InfectedHazeAmbientExplosion_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x230(0x8)
	struct UStaticMeshComponent* SM_Weevil02_Gib_06;  // 0x238(0x8)
	struct UStaticMeshComponent* SM_Weevil02_Gib_05;  // 0x240(0x8)
	struct UStaticMeshComponent* SM_Weevil02_Gib_04;  // 0x248(0x8)
	struct UStaticMeshComponent* SM_Weevil02_Gib_01;  // 0x250(0x8)
	struct UStaticMeshComponent* SM_Weevil02_Gib_02;  // 0x258(0x8)
	struct UStaticMeshComponent* SM_Weevil02_Gib_03;  // 0x260(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x268(0x8)
	float TL_MeshDissolve_DissolveAmount_446D0F6F45CFC639465410A2266866C5;  // 0x270(0x4)
	char ETimelineDirection TL_MeshDissolve__Direction_446D0F6F45CFC639465410A2266866C5;  // 0x274(0x1)
	char pad_629[3];  // 0x275(0x3)
	struct UTimelineComponent* TL_MeshDissolve;  // 0x278(0x8)
	float TL_DecalEmissive_EmissiveValue_CEED249C4EDBCE64C7C2C2BD108EB63D;  // 0x280(0x4)
	char ETimelineDirection TL_DecalEmissive__Direction_CEED249C4EDBCE64C7C2C2BD108EB63D;  // 0x284(0x1)
	char pad_645[3];  // 0x285(0x3)
	struct UTimelineComponent* TL_DecalEmissive;  // 0x288(0x8)
	struct TArray<char EObjectTypeQuery> ObjectTypes;  // 0x290(0x10)
	struct TArray<struct UMeshComponent*> MeshArray;  // 0x2A0(0x10)
	struct TArray<struct UMaterialInstanceDynamic*> WeevilMIDs;  // 0x2B0(0x10)
	struct UMaterialInstanceDynamic* SplatterMID;  // 0x2C0(0x8)
	struct FVector HitLocation;  // 0x2C8(0xC)
	int32_t MeshSleepCount;  // 0x2D4(0x4)
	struct UDecalComponent* SplatterDecal;  // 0x2D8(0x8)
	float ClosestPlayerSquared;  // 0x2E0(0x4)

	void TL_DecalEmissive__FinishedFunc(); // Function BP_InfectedHazeAmbientExplosion.BP_InfectedHazeAmbientExplosion_C.TL_DecalEmissive__FinishedFunc
	void TL_DecalEmissive__UpdateFunc(); // Function BP_InfectedHazeAmbientExplosion.BP_InfectedHazeAmbientExplosion_C.TL_DecalEmissive__UpdateFunc
	void TL_MeshDissolve__FinishedFunc(); // Function BP_InfectedHazeAmbientExplosion.BP_InfectedHazeAmbientExplosion_C.TL_MeshDissolve__FinishedFunc
	void TL_MeshDissolve__UpdateFunc(); // Function BP_InfectedHazeAmbientExplosion.BP_InfectedHazeAmbientExplosion_C.TL_MeshDissolve__UpdateFunc
	void ReceiveBeginPlay(); // Function BP_InfectedHazeAmbientExplosion.BP_InfectedHazeAmbientExplosion_C.ReceiveBeginPlay
	void BndEvt__SM_Weevil02_Gib_03_K2Node_ComponentBoundEvent_1_ComponentSleepSignature__DelegateSignature(struct UPrimitiveComponent* SleepingComponent, struct FName BoneName); // Function BP_InfectedHazeAmbientExplosion.BP_InfectedHazeAmbientExplosion_C.BndEvt__SM_Weevil02_Gib_03_K2Node_ComponentBoundEvent_1_ComponentSleepSignature__DelegateSignature
	void BndEvt__SM_Weevil02_Gib_02_K2Node_ComponentBoundEvent_2_ComponentSleepSignature__DelegateSignature(struct UPrimitiveComponent* SleepingComponent, struct FName BoneName); // Function BP_InfectedHazeAmbientExplosion.BP_InfectedHazeAmbientExplosion_C.BndEvt__SM_Weevil02_Gib_02_K2Node_ComponentBoundEvent_2_ComponentSleepSignature__DelegateSignature
	void BndEvt__SM_Weevil02_Gib_01_K2Node_ComponentBoundEvent_3_ComponentSleepSignature__DelegateSignature(struct UPrimitiveComponent* SleepingComponent, struct FName BoneName); // Function BP_InfectedHazeAmbientExplosion.BP_InfectedHazeAmbientExplosion_C.BndEvt__SM_Weevil02_Gib_01_K2Node_ComponentBoundEvent_3_ComponentSleepSignature__DelegateSignature
	void BndEvt__SM_Weevil02_Gib_04_K2Node_ComponentBoundEvent_4_ComponentSleepSignature__DelegateSignature(struct UPrimitiveComponent* SleepingComponent, struct FName BoneName); // Function BP_InfectedHazeAmbientExplosion.BP_InfectedHazeAmbientExplosion_C.BndEvt__SM_Weevil02_Gib_04_K2Node_ComponentBoundEvent_4_ComponentSleepSignature__DelegateSignature
	void BndEvt__SM_Weevil02_Gib_05_K2Node_ComponentBoundEvent_5_ComponentSleepSignature__DelegateSignature(struct UPrimitiveComponent* SleepingComponent, struct FName BoneName); // Function BP_InfectedHazeAmbientExplosion.BP_InfectedHazeAmbientExplosion_C.BndEvt__SM_Weevil02_Gib_05_K2Node_ComponentBoundEvent_5_ComponentSleepSignature__DelegateSignature
	void BndEvt__SM_Weevil02_Gib_06_K2Node_ComponentBoundEvent_6_ComponentSleepSignature__DelegateSignature(struct UPrimitiveComponent* SleepingComponent, struct FName BoneName); // Function BP_InfectedHazeAmbientExplosion.BP_InfectedHazeAmbientExplosion_C.BndEvt__SM_Weevil02_Gib_06_K2Node_ComponentBoundEvent_6_ComponentSleepSignature__DelegateSignature
	void ExecuteUbergraph_BP_InfectedHazeAmbientExplosion(int32_t EntryPoint); // Function BP_InfectedHazeAmbientExplosion.BP_InfectedHazeAmbientExplosion_C.ExecuteUbergraph_BP_InfectedHazeAmbientExplosion
}; 



