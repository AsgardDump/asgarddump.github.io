#pragma once 
#include <BP_FreshSlashingDamage_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_FreshSlashingDamage.BP_FreshSlashingDamage_C
// Size: 0x78(Inherited: 0x78) 
struct UBP_FreshSlashingDamage_C : public UBP_FreshDamage_C
{

}; 



