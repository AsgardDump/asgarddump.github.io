#pragma once 
#include <BP_GrassBlade_Dead_B_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_GrassBlade_Dead_B.BP_GrassBlade_Dead_B_C
// Size: 0x418(Inherited: 0x418) 
struct ABP_GrassBlade_Dead_B_C : public ABP_BASE_GrassBlade_Dead_C
{

}; 



