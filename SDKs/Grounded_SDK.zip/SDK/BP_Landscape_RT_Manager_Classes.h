#pragma once 
#include <BP_Landscape_RT_Manager_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Landscape_RT_Manager.BP_Landscape_RT_Manager_C
// Size: 0x2E8(Inherited: 0x280) 
struct ABP_Landscape_RT_Manager_C : public ALandscapeRTManager
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x280(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x288(0x8)
	struct UMaterialInstanceDynamic* MID_RT_Grid_Stamp_TEST;  // 0x290(0x8)
	struct UMaterialInstanceDynamic* MID_RT_Offset;  // 0x298(0x8)
	struct UMaterialInstanceDynamic* MID_RT_OffsetAdd;  // 0x2A0(0x8)
	struct UMaterialInstanceDynamic* MID_RT_Erase;  // 0x2A8(0x8)
	struct FVector UV Grid;  // 0x2B0(0xC)
	struct FVector UV Segment;  // 0x2BC(0xC)
	struct FLinearColor PlayerLocationUVGrid;  // 0x2C8(0x10)
	struct FLinearColor PlayerLocationUVSegment;  // 0x2D8(0x10)

	void GetObjectUVCoords(struct FVector Object Location, struct FVector& UV Grid, struct FVector& UV Segment); // Function BP_Landscape_RT_Manager.BP_Landscape_RT_Manager_C.GetObjectUVCoords
	void Draw To Render Target(); // Function BP_Landscape_RT_Manager.BP_Landscape_RT_Manager_C.Draw To Render Target
	void ClearRenderTarget(); // Function BP_Landscape_RT_Manager.BP_Landscape_RT_Manager_C.ClearRenderTarget
	void ReceiveBeginPlay(); // Function BP_Landscape_RT_Manager.BP_Landscape_RT_Manager_C.ReceiveBeginPlay
	void ReceiveTick(float DeltaSeconds); // Function BP_Landscape_RT_Manager.BP_Landscape_RT_Manager_C.ReceiveTick
	void ExecuteUbergraph_BP_Landscape_RT_Manager(int32_t EntryPoint); // Function BP_Landscape_RT_Manager.BP_Landscape_RT_Manager_C.ExecuteUbergraph_BP_Landscape_RT_Manager
}; 



