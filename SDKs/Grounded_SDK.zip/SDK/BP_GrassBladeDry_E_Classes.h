#pragma once 
#include <BP_GrassBladeDry_E_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_GrassBladeDry_E.BP_GrassBladeDry_E_C
// Size: 0x468(Inherited: 0x468) 
struct ABP_GrassBladeDry_E_C : public ABP_GrassBlade_E_C
{

}; 



