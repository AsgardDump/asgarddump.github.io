#pragma once 
#include "SDK.h" 
 
 
// Function BP_ModelViewModel.BP_ModelViewModel_C.ExecuteUbergraph_BP_ModelViewModel
// Size: 0x360(Inherited: 0x0) 
struct FExecuteUbergraph_BP_ModelViewModel
{
	int32_t EntryPoint;  // 0x0(0x4)
	int32_t Temp_int_Variable;  // 0x4(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x8(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0xC(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x10(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0x14(0x4)
	int32_t Temp_int_Array_Index_Variable_2;  // 0x18(0x4)
	int32_t Temp_int_Loop_Counter_Variable_2;  // 0x1C(0x4)
	struct TArray<struct UMaterialInterface*> K2Node_MakeArray_Array;  // 0x20(0x10)
	struct UMaterialInterface* CallFunc_Array_Get_Item;  // 0x30(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x38(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_3;  // 0x3C(0x4)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x40(0x1)
	char pad_65[3];  // 0x41(0x3)
	int32_t Temp_int_Variable_2;  // 0x44(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_4;  // 0x48(0x4)
	char pad_76[4];  // 0x4C(0x4)
	struct UStaticMesh* K2Node_CustomEvent_StaticMesh;  // 0x50(0x8)
	struct TArray<struct UMaterialInterface*> K2Node_CustomEvent_Materials_2;  // 0x58(0x10)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool K2Node_CustomEvent_CenterMeshAtRotationOrigin_2 : 1;  // 0x68(0x1)
	char pad_105[3];  // 0x69(0x3)
	int32_t CallFunc_GetNumMaterials_ReturnValue;  // 0x6C(0x4)
	struct FVector CallFunc_GetLocalBounds_Min;  // 0x70(0xC)
	struct FVector CallFunc_GetLocalBounds_Max;  // 0x7C(0xC)
	int32_t CallFunc_Subtract_IntInt_ReturnValue;  // 0x88(0x4)
	struct FVector CallFunc_Add_VectorVector_ReturnValue;  // 0x8C(0xC)
	char pad_152_1 : 7;  // 0x98(0x1)
	bool CallFunc_LessEqual_IntInt_ReturnValue : 1;  // 0x98(0x1)
	char pad_153[3];  // 0x99(0x3)
	struct FVector CallFunc_Divide_VectorFloat_ReturnValue;  // 0x9C(0xC)
	struct FVector CallFunc_Subtract_VectorVector_ReturnValue;  // 0xA8(0xC)
	char pad_180_1 : 7;  // 0xB4(0x1)
	bool CallFunc_SetStaticMesh_ReturnValue : 1;  // 0xB4(0x1)
	char pad_181[3];  // 0xB5(0x3)
	struct FHitResult CallFunc_K2_AddActorWorldOffset_SweepHitResult;  // 0xB8(0x88)
	struct UMaterialInterface* CallFunc_Array_Get_Item_2;  // 0x140(0x8)
	int32_t CallFunc_Array_Length_ReturnValue_2;  // 0x148(0x4)
	int32_t CallFunc_Array_Length_ReturnValue_3;  // 0x14C(0x4)
	char pad_336_1 : 7;  // 0x150(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_2 : 1;  // 0x150(0x1)
	char pad_337_1 : 7;  // 0x151(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue : 1;  // 0x151(0x1)
	char pad_338[6];  // 0x152(0x6)
	struct USkeletalMesh* K2Node_CustomEvent_SkeletalMesh_2;  // 0x158(0x8)
	struct TArray<struct UMaterialInterface*> K2Node_CustomEvent_Materials;  // 0x160(0x10)
	char pad_368_1 : 7;  // 0x170(0x1)
	bool K2Node_CustomEvent_CenterMeshAtRotationOrigin : 1;  // 0x170(0x1)
	char pad_369[3];  // 0x171(0x3)
	struct FHitResult CallFunc_K2_AddRelativeLocation_SweepHitResult;  // 0x174(0x88)
	int32_t CallFunc_Array_Length_ReturnValue_4;  // 0x1FC(0x4)
	char pad_512_1 : 7;  // 0x200(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue_2 : 1;  // 0x200(0x1)
	char pad_513[3];  // 0x201(0x3)
	int32_t CallFunc_GetNumMaterials_ReturnValue_2;  // 0x204(0x4)
	int32_t CallFunc_Subtract_IntInt_ReturnValue_2;  // 0x208(0x4)
	char pad_524_1 : 7;  // 0x20C(0x1)
	bool CallFunc_LessEqual_IntInt_ReturnValue_2 : 1;  // 0x20C(0x1)
	char pad_525[3];  // 0x20D(0x3)
	struct FBoxSphereBounds CallFunc_GetBounds_ReturnValue;  // 0x210(0x1C)
	struct FVector CallFunc_Divide_VectorFloat_ReturnValue_2;  // 0x22C(0xC)
	struct FVector CallFunc_Subtract_VectorVector_ReturnValue_2;  // 0x238(0xC)
	struct FHitResult CallFunc_K2_AddActorWorldOffset_SweepHitResult_2;  // 0x244(0x88)
	struct FHitResult CallFunc_K2_AddRelativeLocation_SweepHitResult_2;  // 0x2CC(0x88)
	char pad_852[4];  // 0x354(0x4)
	struct USkeletalMesh* K2Node_CustomEvent_SkeletalMesh;  // 0x358(0x8)

}; 
// Function BP_ModelViewModel.BP_ModelViewModel_C.GetMeshBounds
// Size: 0x30(Inherited: 0x0) 
struct FGetMeshBounds
{
	struct FVector BoundsMin;  // 0x0(0xC)
	struct FVector CallFunc_GetLocalBounds_Min;  // 0xC(0xC)
	struct FVector CallFunc_GetLocalBounds_Max;  // 0x18(0xC)
	struct FVector CallFunc_Subtract_VectorVector_ReturnValue;  // 0x24(0xC)

}; 
// Function BP_ModelViewModel.BP_ModelViewModel_C.AddChildMesh
// Size: 0x8(Inherited: 0x0) 
struct FAddChildMesh
{
	struct USkeletalMesh* SkeletalMesh;  // 0x0(0x8)

}; 
// Function BP_ModelViewModel.BP_ModelViewModel_C.SetSkeletalMesh
// Size: 0x19(Inherited: 0x0) 
struct FSetSkeletalMesh
{
	struct USkeletalMesh* SkeletalMesh;  // 0x0(0x8)
	struct TArray<struct UMaterialInterface*> Materials;  // 0x8(0x10)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CenterMeshAtRotationOrigin : 1;  // 0x18(0x1)

}; 
// Function BP_ModelViewModel.BP_ModelViewModel_C.GetSkeletalMeshBounds
// Size: 0x28(Inherited: 0x0) 
struct FGetSkeletalMeshBounds
{
	struct FVector Bounds;  // 0x0(0xC)
	struct FBoxSphereBounds CallFunc_GetBounds_ReturnValue;  // 0xC(0x1C)

}; 
// Function BP_ModelViewModel.BP_ModelViewModel_C.SetStaticMesh
// Size: 0x19(Inherited: 0x0) 
struct FSetStaticMesh
{
	struct UStaticMesh* StaticMesh;  // 0x0(0x8)
	struct TArray<struct UMaterialInterface*> Materials;  // 0x8(0x10)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CenterMeshAtRotationOrigin : 1;  // 0x18(0x1)

}; 
