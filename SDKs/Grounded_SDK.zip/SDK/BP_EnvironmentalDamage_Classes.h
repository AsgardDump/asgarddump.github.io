#pragma once 
#include <BP_EnvironmentalDamage_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_EnvironmentalDamage.BP_EnvironmentalDamage_C
// Size: 0x78(Inherited: 0x78) 
struct UBP_EnvironmentalDamage_C : public USurvivalDamageType
{

}; 



