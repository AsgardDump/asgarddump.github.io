#pragma once 
#include <AB_Analyzer_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass AB_Analyzer.AB_Analyzer_C
// Size: 0x3C0(Inherited: 0x2C0) 
struct UAB_Analyzer_C : public UAnimInstance
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x2C0(0x8)
	struct FAnimNode_Root AnimGraphNode_Root;  // 0x2C8(0x30)
	struct FAnimNode_Slot AnimGraphNode_Slot;  // 0x2F8(0x48)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer;  // 0x340(0x80)

	void AnimGraph(struct FPoseLink& AnimGraph); // Function AB_Analyzer.AB_Analyzer_C.AnimGraph
	void ExecuteUbergraph_AB_Analyzer(int32_t EntryPoint); // Function AB_Analyzer.AB_Analyzer_C.ExecuteUbergraph_AB_Analyzer
}; 



