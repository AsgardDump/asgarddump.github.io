#pragma once 
#include "SDK.h" 
 
 
// Function BP_Eelgrass_A.BP_Eelgrass_A_C.ExecuteUbergraph_BP_Eelgrass_A
// Size: 0x4(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Eelgrass_A
{
	int32_t EntryPoint;  // 0x0(0x4)

}; 
