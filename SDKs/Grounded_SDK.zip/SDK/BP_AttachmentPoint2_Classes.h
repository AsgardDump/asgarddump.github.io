#pragma once 
#include <BP_AttachmentPoint2_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_AttachmentPoint2.BP_AttachmentPoint2_C
// Size: 0x250(Inherited: 0x240) 
struct ABP_AttachmentPoint2_C : public AAttachmentPoint
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x240(0x8)
	struct USphereComponent* Sphere;  // 0x248(0x8)

	void ReceiveTick(float DeltaSeconds); // Function BP_AttachmentPoint2.BP_AttachmentPoint2_C.ReceiveTick
	void ExecuteUbergraph_BP_AttachmentPoint2(int32_t EntryPoint); // Function BP_AttachmentPoint2.BP_AttachmentPoint2_C.ExecuteUbergraph_BP_AttachmentPoint2
}; 



