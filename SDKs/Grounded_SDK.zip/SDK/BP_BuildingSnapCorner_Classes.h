#pragma once 
#include <BP_BuildingSnapCorner_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_BuildingSnapCorner.BP_BuildingSnapCorner_C
// Size: 0x238(Inherited: 0x230) 
struct ABP_BuildingSnapCorner_C : public AActor
{
	struct UStaticMeshComponent* Sphere;  // 0x230(0x8)

}; 



