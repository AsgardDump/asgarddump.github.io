#pragma once 
#include "SDK.h" 
 
 
// UserDefinedStruct BlendTriggerAttributes.BlendTriggerAttributes
// Size: 0x2C(Inherited: 0x0) 
struct FBlendTriggerAttributes
{
	float SkylightIntensityMin_22_1708ECBF43E5B5E2C907DA87156D0623;  // 0x0(0x4)
	float SkylightIntensityMax_23_9C0F03C14C0828A92DE20692B508ABE9;  // 0x4(0x4)
	float SunIntensityMin_24_93F852144EB419390DC482AB75B93F6D;  // 0x8(0x4)
	float SunIntensityMax_25_C304BAEA4A33F4E59410BEBB93A8F26A;  // 0xC(0x4)
	float MoonIntensityMin_27_DF0B0FCB44A4DB9705CA67B595BA6EFF;  // 0x10(0x4)
	float MoonIntensityMax_29_669BF51E4EA3C908E03AECAE5CFECD34;  // 0x14(0x4)
	float FogThicknessMin_34_8FFB8E0E41DBA1FF84269D936BBC8112;  // 0x18(0x4)
	float FogThicknessMax_35_3DB54C924BB98D27A14BD780B541C9D4;  // 0x1C(0x4)
	float HedgeContributionMin_38_A2EE601A4E0D4F27A6C59A92B2F6DB44;  // 0x20(0x4)
	float HedgeContributionMax_39_BD5C9AF5428E1F24E954B0B8A3EE6893;  // 0x24(0x4)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool InteriorDaylightContribution_42_2FD238F24DED2654FBE2089C517D1243 : 1;  // 0x28(0x1)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool PostProcessExposureContribution_45_62BAC72F4A5A6695674AFFAD446A4888 : 1;  // 0x29(0x1)
	char pad_42_1 : 7;  // 0x2A(0x1)
	bool GroundSpecularContribution_47_3D951CDD460BBD56090E3D94BB35EE33 : 1;  // 0x2A(0x1)
	char pad_43_1 : 7;  // 0x2B(0x1)
	bool UpdateVolumetricFogDrawDistance_51_8F884236424ABB49A5D6DB8C43E2F56A : 1;  // 0x2B(0x1)

}; 
