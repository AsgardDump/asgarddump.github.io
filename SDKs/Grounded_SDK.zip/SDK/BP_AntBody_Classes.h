#pragma once 
#include <BP_AntBody_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_AntBody.BP_AntBody_C
// Size: 0x2E8(Inherited: 0x2A3) 
struct ABP_AntBody_C : public ABP_InsectPart_C
{
	char pad_675[5];  // 0x2A3(0x5)
	struct UCableComponent* CableHead;  // 0x2A8(0x8)
	struct UCableComponent* CableAbdomen;  // 0x2B0(0x8)
	struct UCableComponent* CableLegRBack;  // 0x2B8(0x8)
	struct UCableComponent* CableLegLFront;  // 0x2C0(0x8)
	struct UCableComponent* CableLegRMid;  // 0x2C8(0x8)
	struct UCableComponent* CableLegRFront;  // 0x2D0(0x8)
	struct UCableComponent* CableLegLMid;  // 0x2D8(0x8)
	struct UCableComponent* CableLegLBack;  // 0x2E0(0x8)

}; 



