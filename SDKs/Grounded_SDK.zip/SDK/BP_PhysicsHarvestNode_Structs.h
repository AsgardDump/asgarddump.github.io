#pragma once 
#include "SDK.h" 
 
 
// Function BP_PhysicsHarvestNode.BP_PhysicsHarvestNode_C.BndEvt__HealthComponent_K2Node_ComponentBoundEvent_0_DamagedDelegate__DelegateSignature
// Size: 0x81(Inherited: 0x0) 
struct FBndEvt__HealthComponent_K2Node_ComponentBoundEvent_0_DamagedDelegate__DelegateSignature
{
	float Damage;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FDamageInfo DamageInfo;  // 0x8(0x68)
	struct AController* InstigatedBy;  // 0x70(0x8)
	struct UBaseLODActor* DamageCauser;  // 0x78(0x8)
	char pad_128_1 : 7;  // 0x80(0x1)
	bool IsKillingBlow : 1;  // 0x80(0x1)

}; 
// Function BP_PhysicsHarvestNode.BP_PhysicsHarvestNode_C.ReceiveActorBeginOverlap
// Size: 0x8(Inherited: 0x8) 
struct FReceiveActorBeginOverlap : public FReceiveActorBeginOverlap
{
	struct AActor* OtherActor;  // 0x0(0x8)

}; 
// Function BP_PhysicsHarvestNode.BP_PhysicsHarvestNode_C.ExecuteUbergraph_BP_PhysicsHarvestNode
// Size: 0x28A(Inherited: 0x0) 
struct FExecuteUbergraph_BP_PhysicsHarvestNode
{
	int32_t EntryPoint;  // 0x0(0x4)
	float K2Node_ComponentBoundEvent_Damage;  // 0x4(0x4)
	struct FDamageInfo K2Node_ComponentBoundEvent_DamageInfo_2;  // 0x8(0x68)
	struct AController* K2Node_ComponentBoundEvent_InstigatedBy;  // 0x70(0x8)
	struct UBaseLODActor* K2Node_ComponentBoundEvent_DamageCauser;  // 0x78(0x8)
	char pad_128_1 : 7;  // 0x80(0x1)
	bool K2Node_ComponentBoundEvent_IsKillingBlow : 1;  // 0x80(0x1)
	char pad_129_1 : 7;  // 0x81(0x1)
	bool CallFunc_GreaterEqual_FloatFloat_ReturnValue : 1;  // 0x81(0x1)
	char pad_130[6];  // 0x82(0x6)
	struct FDamageInfo K2Node_ComponentBoundEvent_DamageInfo;  // 0x88(0x68)
	float K2Node_Event_DeltaSeconds;  // 0xF0(0x4)
	char pad_244[4];  // 0xF4(0x4)
	struct AActor* K2Node_CustomEvent_SelfActor;  // 0xF8(0x8)
	struct AActor* K2Node_CustomEvent_OtherActor;  // 0x100(0x8)
	struct FVector K2Node_CustomEvent_NormalImpulse;  // 0x108(0xC)
	struct FHitResult K2Node_CustomEvent_Hit;  // 0x114(0x88)
	char pad_412_1 : 7;  // 0x19C(0x1)
	bool CallFunc_BreakHitResult_bBlockingHit : 1;  // 0x19C(0x1)
	char pad_413_1 : 7;  // 0x19D(0x1)
	bool CallFunc_BreakHitResult_bInitialOverlap : 1;  // 0x19D(0x1)
	char pad_414[2];  // 0x19E(0x2)
	float CallFunc_BreakHitResult_Time;  // 0x1A0(0x4)
	float CallFunc_BreakHitResult_Distance;  // 0x1A4(0x4)
	struct FVector CallFunc_BreakHitResult_Location;  // 0x1A8(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactPoint;  // 0x1B4(0xC)
	struct FVector CallFunc_BreakHitResult_Normal;  // 0x1C0(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactNormal;  // 0x1CC(0xC)
	struct UPhysicalMaterial* CallFunc_BreakHitResult_PhysMat;  // 0x1D8(0x8)
	struct AActor* CallFunc_BreakHitResult_HitActor;  // 0x1E0(0x8)
	struct UPrimitiveComponent* CallFunc_BreakHitResult_HitComponent;  // 0x1E8(0x8)
	struct FName CallFunc_BreakHitResult_HitBoneName;  // 0x1F0(0x8)
	int32_t CallFunc_BreakHitResult_HitItem;  // 0x1F8(0x4)
	int32_t CallFunc_BreakHitResult_ElementIndex;  // 0x1FC(0x4)
	int32_t CallFunc_BreakHitResult_FaceIndex;  // 0x200(0x4)
	struct FVector CallFunc_BreakHitResult_TraceStart;  // 0x204(0xC)
	struct FVector CallFunc_BreakHitResult_TraceEnd;  // 0x210(0xC)
	char pad_540_1 : 7;  // 0x21C(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0x21C(0x1)
	char pad_541[3];  // 0x21D(0x3)
	float CallFunc_GetAudioTimeSeconds_ReturnValue;  // 0x220(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0x224(0x4)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x228(0x10)
	char pad_568_1 : 7;  // 0x238(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue : 1;  // 0x238(0x1)
	char pad_569[7];  // 0x239(0x7)
	struct AActor* K2Node_Event_OtherActor_2;  // 0x240(0x8)
	struct FVector CallFunc_GetComponentVelocity_ReturnValue;  // 0x248(0xC)
	char pad_596[4];  // 0x254(0x4)
	struct APhysicsVolume* K2Node_DynamicCast_AsPhysics_Volume;  // 0x258(0x8)
	char pad_608_1 : 7;  // 0x260(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x260(0x1)
	char pad_609[3];  // 0x261(0x3)
	float CallFunc_VSize_ReturnValue;  // 0x264(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x268(0x4)
	float CallFunc_FClamp_ReturnValue;  // 0x26C(0x4)
	char pad_624_1 : 7;  // 0x270(0x1)
	bool CallFunc_GreaterEqual_FloatFloat_ReturnValue_2 : 1;  // 0x270(0x1)
	char pad_625_1 : 7;  // 0x271(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x271(0x1)
	char pad_626[6];  // 0x272(0x6)
	struct AActor* K2Node_Event_OtherActor;  // 0x278(0x8)
	struct APhysicsVolume* K2Node_DynamicCast_AsPhysics_Volume_2;  // 0x280(0x8)
	char pad_648_1 : 7;  // 0x288(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x288(0x1)
	char pad_649_1 : 7;  // 0x289(0x1)
	bool CallFunc_IsOverlappingWaterVolume_ReturnValue : 1;  // 0x289(0x1)

}; 
// Function BP_PhysicsHarvestNode.BP_PhysicsHarvestNode_C.ReceiveActorEndOverlap
// Size: 0x8(Inherited: 0x8) 
struct FReceiveActorEndOverlap : public FReceiveActorEndOverlap
{
	struct AActor* OtherActor;  // 0x0(0x8)

}; 
// Function BP_PhysicsHarvestNode.BP_PhysicsHarvestNode_C.On Hit
// Size: 0xA4(Inherited: 0x0) 
struct FOn Hit
{
	struct AActor* SelfActor;  // 0x0(0x8)
	struct AActor* OtherActor;  // 0x8(0x8)
	struct FVector NormalImpulse;  // 0x10(0xC)
	struct FHitResult Hit;  // 0x1C(0x88)

}; 
// Function BP_PhysicsHarvestNode.BP_PhysicsHarvestNode_C.BndEvt__HealthComponent_K2Node_ComponentBoundEvent_1_DeathDelegate__DelegateSignature
// Size: 0x68(Inherited: 0x0) 
struct FBndEvt__HealthComponent_K2Node_ComponentBoundEvent_1_DeathDelegate__DelegateSignature
{
	struct FDamageInfo DamageInfo;  // 0x0(0x68)

}; 
// Function BP_PhysicsHarvestNode.BP_PhysicsHarvestNode_C.ReceiveTick
// Size: 0x4(Inherited: 0x4) 
struct FReceiveTick : public FReceiveTick
{
	float DeltaSeconds;  // 0x0(0x4)

}; 
