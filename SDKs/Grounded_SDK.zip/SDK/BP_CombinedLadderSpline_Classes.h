#pragma once 
#include <BP_CombinedLadderSpline_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_CombinedLadderSpline.BP_CombinedLadderSpline_C
// Size: 0x248(Inherited: 0x248) 
struct ABP_CombinedLadderSpline_C : public ACombinedLadder
{

}; 



