#pragma once 
#include <BP_DeadBug_StinkBug_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_DeadBug_StinkBug.BP_DeadBug_StinkBug_C
// Size: 0x4A8(Inherited: 0x4A8) 
struct ABP_DeadBug_StinkBug_C : public ABP_WorldItem_C
{

}; 



