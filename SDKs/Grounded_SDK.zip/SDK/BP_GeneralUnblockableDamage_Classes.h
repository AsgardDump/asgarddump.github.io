#pragma once 
#include <BP_GeneralUnblockableDamage_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_GeneralUnblockableDamage.BP_GeneralUnblockableDamage_C
// Size: 0x78(Inherited: 0x78) 
struct UBP_GeneralUnblockableDamage_C : public USurvivalDamageType
{

}; 



