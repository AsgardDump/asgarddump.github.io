#pragma once 
#include "SDK.h" 
 
 
// Function BP_Haze_Fungus.BP_Haze_Fungus_C.OnTakeAnyDamage_Event_1
// Size: 0x28(Inherited: 0x0) 
struct FOnTakeAnyDamage_Event_1
{
	struct AActor* DamagedActor;  // 0x0(0x8)
	float Damage;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct UDamageType* DamageType;  // 0x10(0x8)
	struct AController* InstigatedBy;  // 0x18(0x8)
	struct AActor* DamageCauser;  // 0x20(0x8)

}; 
// Function BP_Haze_Fungus.BP_Haze_Fungus_C.ExecuteUbergraph_BP_Haze_Fungus
// Size: 0x48(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Haze_Fungus
{
	int32_t EntryPoint;  // 0x0(0x4)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x4(0x10)
	char pad_20[4];  // 0x14(0x4)
	struct AActor* K2Node_CustomEvent_DamagedActor;  // 0x18(0x8)
	float K2Node_CustomEvent_Damage;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)
	struct UDamageType* K2Node_CustomEvent_DamageType;  // 0x28(0x8)
	struct AController* K2Node_CustomEvent_InstigatedBy;  // 0x30(0x8)
	struct AActor* K2Node_CustomEvent_DamageCauser;  // 0x38(0x8)
	struct UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue;  // 0x40(0x8)

}; 
