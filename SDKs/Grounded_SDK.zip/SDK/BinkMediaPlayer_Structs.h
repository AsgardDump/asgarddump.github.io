#pragma once 
#include "SDK.h" 
 
 
// Function BinkMediaPlayer.BinkMediaPlayer.IsPlaying
// Size: 0x1(Inherited: 0x0) 
struct FIsPlaying
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function BinkMediaPlayer.BinkMediaPlayer.CanPause
// Size: 0x1(Inherited: 0x0) 
struct FCanPause
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function BinkMediaPlayer.BinkMediaPlayer.IsLooping
// Size: 0x1(Inherited: 0x0) 
struct FIsLooping
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function BinkMediaPlayer.BinkMediaPlayer.GetRate
// Size: 0x4(Inherited: 0x0) 
struct FGetRate
{
	float ReturnValue;  // 0x0(0x4)

}; 
// DelegateFunction BinkMediaPlayer.OnBinkMediaPlayerMediaOpened__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FOnBinkMediaPlayerMediaOpened__DelegateSignature
{
	struct FString OpenedUrl;  // 0x0(0x10)

}; 
// Function BinkMediaPlayer.BinkMediaPlayer.GetUrl
// Size: 0x10(Inherited: 0x0) 
struct FGetUrl
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// Function BinkMediaPlayer.BinkFunctionLibrary.BinkLoadingMovie_GetDuration
// Size: 0x8(Inherited: 0x0) 
struct FBinkLoadingMovie_GetDuration
{
	struct FTimespan ReturnValue;  // 0x0(0x8)

}; 
// Function BinkMediaPlayer.BinkMediaPlayer.GetCurrentUrl
// Size: 0x10(Inherited: 0x0) 
struct FGetCurrentUrl
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// Function BinkMediaPlayer.BinkFunctionLibrary.BinkLoadingMovie_GetTime
// Size: 0x8(Inherited: 0x0) 
struct FBinkLoadingMovie_GetTime
{
	struct FTimespan ReturnValue;  // 0x0(0x8)

}; 
// Function BinkMediaPlayer.BinkMediaPlayer.GetDuration
// Size: 0x8(Inherited: 0x0) 
struct FGetDuration
{
	struct FTimespan ReturnValue;  // 0x0(0x8)

}; 
// Function BinkMediaPlayer.BinkMediaPlayer.IsPaused
// Size: 0x1(Inherited: 0x0) 
struct FIsPaused
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function BinkMediaPlayer.BinkMediaPlayer.Draw
// Size: 0x18(Inherited: 0x0) 
struct FDraw
{
	struct UTexture* Texture;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool tonemap : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	int32_t out_nits;  // 0xC(0x4)
	float Alpha;  // 0x10(0x4)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool srgb_decode : 1;  // 0x14(0x1)
	char pad_21_1 : 7;  // 0x15(0x1)
	bool hdr : 1;  // 0x15(0x1)
	char pad_22[2];  // 0x16(0x2)

}; 
// Function BinkMediaPlayer.BinkMediaPlayer.CanPlay
// Size: 0x1(Inherited: 0x0) 
struct FCanPlay
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function BinkMediaPlayer.BinkMediaPlayer.GetTime
// Size: 0x8(Inherited: 0x0) 
struct FGetTime
{
	struct FTimespan ReturnValue;  // 0x0(0x8)

}; 
// Function BinkMediaPlayer.BinkMediaPlayer.IsInitialized
// Size: 0x1(Inherited: 0x0) 
struct FIsInitialized
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function BinkMediaPlayer.BinkMediaPlayer.IsStopped
// Size: 0x1(Inherited: 0x0) 
struct FIsStopped
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function BinkMediaPlayer.BinkMediaPlayer.OpenUrl
// Size: 0x18(Inherited: 0x0) 
struct FOpenUrl
{
	struct FString NewUrl;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function BinkMediaPlayer.BinkMediaPlayer.Pause
// Size: 0x1(Inherited: 0x0) 
struct FPause
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function BinkMediaPlayer.BinkMediaPlayer.Play
// Size: 0x1(Inherited: 0x0) 
struct FPlay
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function BinkMediaPlayer.BinkMediaPlayer.Rewind
// Size: 0x1(Inherited: 0x0) 
struct FRewind
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function BinkMediaPlayer.BinkMediaPlayer.Seek
// Size: 0x10(Inherited: 0x0) 
struct FSeek
{
	struct FTimespan InTime;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function BinkMediaPlayer.BinkMediaPlayer.SeekToNextFrame
// Size: 0x1(Inherited: 0x0) 
struct FSeekToNextFrame
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function BinkMediaPlayer.BinkMediaPlayer.SetLooping
// Size: 0x2(Inherited: 0x0) 
struct FSetLooping
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool InLooping : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool ReturnValue : 1;  // 0x1(0x1)

}; 
// Function BinkMediaPlayer.BinkMediaPlayer.SetRate
// Size: 0x8(Inherited: 0x0) 
struct FSetRate
{
	float Rate;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool ReturnValue : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)

}; 
// Function BinkMediaPlayer.BinkMediaPlayer.SetVolume
// Size: 0x4(Inherited: 0x0) 
struct FSetVolume
{
	float Rate;  // 0x0(0x4)

}; 
// Function BinkMediaPlayer.BinkMediaPlayer.SupportsRate
// Size: 0x8(Inherited: 0x0) 
struct FSupportsRate
{
	float Rate;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Unthinned : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool ReturnValue : 1;  // 0x5(0x1)
	char pad_6[2];  // 0x6(0x2)

}; 
// Function BinkMediaPlayer.BinkMediaPlayer.SupportsScrubbing
// Size: 0x1(Inherited: 0x0) 
struct FSupportsScrubbing
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function BinkMediaPlayer.BinkMediaPlayer.SupportsSeeking
// Size: 0x1(Inherited: 0x0) 
struct FSupportsSeeking
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function BinkMediaPlayer.BinkMediaTexture.SetMediaPlayer
// Size: 0x8(Inherited: 0x0) 
struct FSetMediaPlayer
{
	struct UBinkMediaPlayer* InMediaPlayer;  // 0x0(0x8)

}; 
