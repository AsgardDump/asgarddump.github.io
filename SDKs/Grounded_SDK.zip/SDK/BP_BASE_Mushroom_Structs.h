#pragma once 
#include "SDK.h" 
 
 
// Function BP_BASE_Mushroom.BP_BASE_Mushroom_C.ExecuteUbergraph_BP_BASE_Mushroom
// Size: 0x18(Inherited: 0x0) 
struct FExecuteUbergraph_BP_BASE_Mushroom
{
	int32_t EntryPoint;  // 0x0(0x4)
	struct FVector K2Node_ComponentBoundEvent_HitLocation;  // 0x4(0xC)
	struct UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue;  // 0x10(0x8)

}; 
// Function BP_BASE_Mushroom.BP_BASE_Mushroom_C.BndEvt__HealthComponent_K2Node_ComponentBoundEvent_0_OnHandleEffectsEvent__DelegateSignature
// Size: 0xC(Inherited: 0x0) 
struct FBndEvt__HealthComponent_K2Node_ComponentBoundEvent_0_OnHandleEffectsEvent__DelegateSignature
{
	struct FVector HitLocation;  // 0x0(0xC)

}; 
