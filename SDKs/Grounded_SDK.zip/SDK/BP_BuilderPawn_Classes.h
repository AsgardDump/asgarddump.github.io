#pragma once 
#include <BP_BuilderPawn_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_BuilderPawn.BP_BuilderPawn_C
// Size: 0x1709(Inherited: 0x620) 
struct ABP_BuilderPawn_C : public ABuilderPawn
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x620(0x8)
	struct USphereComponent* CameraCollision;  // 0x628(0x8)
	struct UPointLightComponent* SCAB_Light;  // 0x630(0x8)
	struct USpotLightComponent* SpotLight;  // 0x638(0x8)
	struct UAudioComponent* FlapAudio1;  // 0x640(0x8)
	struct UAudioComponent* Audio1;  // 0x648(0x8)
	struct USceneComponent* wing_grp_R1;  // 0x650(0x8)
	struct USceneComponent* wing_grp_L1;  // 0x658(0x8)
	struct UStaticMeshComponent* wing_flipbook_R1;  // 0x660(0x8)
	struct UStaticMeshComponent* wing_stopped_R1;  // 0x668(0x8)
	struct UStaticMeshComponent* wing_dark_R1;  // 0x670(0x8)
	struct USceneComponent* wing_pivot_R1;  // 0x678(0x8)
	struct UStaticMeshComponent* wing_flipbook_L1;  // 0x680(0x8)
	struct UStaticMeshComponent* wing_stopped_L1;  // 0x688(0x8)
	struct UStaticMeshComponent* wing_dark_L1;  // 0x690(0x8)
	struct USceneComponent* wing_pivot_L1;  // 0x698(0x8)
	struct USkeletalMeshComponent* Head2;  // 0x6A0(0x8)
	struct UStaticMeshComponent* Hammer;  // 0x6A8(0x8)
	float Timeline_0_wingFlap_12B792B44BC85A9775627B9A40B1FACD;  // 0x6B0(0x4)
	char ETimelineDirection Timeline_0__Direction_12B792B44BC85A9775627B9A40B1FACD;  // 0x6B4(0x1)
	char pad_1717[3];  // 0x6B5(0x3)
	struct UTimelineComponent* Timeline_1;  // 0x6B8(0x8)
	float TotalSeconds;  // 0x6C0(0x4)
	char pad_1732[4];  // 0x6C4(0x4)
	struct USoundBase* BoopSound;  // 0x6C8(0x8)
	struct USoundBase* BuilderModeStartSound;  // 0x6D0(0x8)
	struct UMaterialInstanceDynamic* HeadlampMID;  // 0x6D8(0x8)
	struct FPerlinNoise Wiggle;  // 0x6E0(0x1014)
	char pad_5876[4];  // 0x16F4(0x4)
	struct USoundBase* DespawnSound;  // 0x16F8(0x8)
	struct USoundBase* DamageSound;  // 0x1700(0x8)
	char pad_5896_1 : 7;  // 0x1708(0x1)
	bool IsFalling : 1;  // 0x1708(0x1)

	void InitHeadlampMID(); // Function BP_BuilderPawn.BP_BuilderPawn_C.InitHeadlampMID
	struct FTransform GetCameraViewTransform(); // Function BP_BuilderPawn.BP_BuilderPawn_C.GetCameraViewTransform
	void Timeline_0__FinishedFunc(); // Function BP_BuilderPawn.BP_BuilderPawn_C.Timeline_0__FinishedFunc
	void Timeline_0__UpdateFunc(); // Function BP_BuilderPawn.BP_BuilderPawn_C.Timeline_0__UpdateFunc
	void ReceiveTick(float DeltaSeconds); // Function BP_BuilderPawn.BP_BuilderPawn_C.ReceiveTick
	void ReceiveBeginPlay(); // Function BP_BuilderPawn.BP_BuilderPawn_C.ReceiveBeginPlay
	void BndEvt__CapsuleComponent_K2Node_ComponentBoundEvent_1_ComponentHitSignature__DelegateSignature(struct UPrimitiveComponent* HitComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, struct FVector NormalImpulse, struct FHitResult& Hit); // Function BP_BuilderPawn.BP_BuilderPawn_C.BndEvt__CapsuleComponent_K2Node_ComponentBoundEvent_1_ComponentHitSignature__DelegateSignature
	void Handle Boop(struct FHitResult HitResult); // Function BP_BuilderPawn.BP_BuilderPawn_C.Handle Boop
	void InputLightTogglePressed(bool bEnabled); // Function BP_BuilderPawn.BP_BuilderPawn_C.InputLightTogglePressed
	void ReceiveEndPlay(char EEndPlayReason EndPlayReason); // Function BP_BuilderPawn.BP_BuilderPawn_C.ReceiveEndPlay
	void FallFromHit(); // Function BP_BuilderPawn.BP_BuilderPawn_C.FallFromHit
	void RotateMeshTo(struct FRotator EndResult, float SpeedScaler); // Function BP_BuilderPawn.BP_BuilderPawn_C.RotateMeshTo
	void HandleHit(struct FHitResult HitResult); // Function BP_BuilderPawn.BP_BuilderPawn_C.HandleHit
	void ExecuteUbergraph_BP_BuilderPawn(int32_t EntryPoint); // Function BP_BuilderPawn.BP_BuilderPawn_C.ExecuteUbergraph_BP_BuilderPawn
}; 



