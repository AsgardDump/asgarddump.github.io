#pragma once 
#include <BP_Firefly_StandIn_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Firefly_StandIn.BP_Firefly_StandIn_C
// Size: 0x12D0(Inherited: 0x12C0) 
struct ABP_Firefly_StandIn_C : public AProxyCharacterStandInActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x12C0(0x8)
	struct UParticleSystemComponent* GlowVFX;  // 0x12C8(0x8)

	void ReceiveBeginPlay(); // Function BP_Firefly_StandIn.BP_Firefly_StandIn_C.ReceiveBeginPlay
	void ToggleVFX(int32_t NewHour, int32_t NewDay); // Function BP_Firefly_StandIn.BP_Firefly_StandIn_C.ToggleVFX
	void ExecuteUbergraph_BP_Firefly_StandIn(int32_t EntryPoint); // Function BP_Firefly_StandIn.BP_Firefly_StandIn_C.ExecuteUbergraph_BP_Firefly_StandIn
}; 



