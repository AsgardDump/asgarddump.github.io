#pragma once 
#include "SDK.h" 
 
 
// Function BP_Eelgrass_D.BP_Eelgrass_D_C.ExecuteUbergraph_BP_Eelgrass_D
// Size: 0x4(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Eelgrass_D
{
	int32_t EntryPoint;  // 0x0(0x4)

}; 
