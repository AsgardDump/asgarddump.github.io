#pragma once 
#include "SDK.h" 
 
 
// Function BP_Pond_Biodome.BP_Pond_Biodome_C.StartDomeOpeningSequence
// Size: 0x1(Inherited: 0x0) 
struct FStartDomeOpeningSequence
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool IsActive : 1;  // 0x0(0x1)

}; 
// Function BP_Pond_Biodome.BP_Pond_Biodome_C.ExecuteUbergraph_BP_Pond_Biodome
// Size: 0x100(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Pond_Biodome
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_IsOpen_ReturnValue : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool K2Node_CustomEvent_IsActive : 1;  // 0x5(0x1)
	char pad_6_1 : 7;  // 0x6(0x1)
	bool CallFunc_IsEnabled_ReturnValue : 1;  // 0x6(0x1)
	char pad_7[1];  // 0x7(0x1)
	float CallFunc_GetTimelineLength_ReturnValue;  // 0x8(0x4)
	float CallFunc_GetTimelineLength_ReturnValue_2;  // 0xC(0x4)
	float CallFunc_GetTimelineLength_ReturnValue_3;  // 0x10(0x4)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool CallFunc_IsOpen_ReturnValue_2 : 1;  // 0x14(0x1)
	char pad_21_1 : 7;  // 0x15(0x1)
	bool CallFunc_BooleanOR_ReturnValue : 1;  // 0x15(0x1)
	char pad_22_1 : 7;  // 0x16(0x1)
	bool K2Node_ComponentBoundEvent_bIsActive : 1;  // 0x16(0x1)
	char pad_23[1];  // 0x17(0x1)
	struct UObject* CallFunc_Conv_SoftObjectReferenceToObject_ReturnValue;  // 0x18(0x8)
	struct ABP_BlendTrigger_C* K2Node_DynamicCast_AsBP_Blend_Trigger;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x28(0x1)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x29(0x1)
	char pad_42[6];  // 0x2A(0x6)
	struct UObject* CallFunc_Conv_SoftObjectReferenceToObject_ReturnValue_2;  // 0x30(0x8)
	struct ABP_BlendTrigger_C* K2Node_DynamicCast_AsBP_Blend_Trigger_2;  // 0x38(0x8)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x40(0x1)
	char pad_65_1 : 7;  // 0x41(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x41(0x1)
	char pad_66[6];  // 0x42(0x6)
	struct UObject* CallFunc_Conv_SoftObjectReferenceToObject_ReturnValue_3;  // 0x48(0x8)
	struct ABP_BlendTrigger_C* K2Node_DynamicCast_AsBP_Blend_Trigger_3;  // 0x50(0x8)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x58(0x1)
	char pad_89_1 : 7;  // 0x59(0x1)
	bool CallFunc_IsValid_ReturnValue_3 : 1;  // 0x59(0x1)
	char pad_90[6];  // 0x5A(0x6)
	struct UObject* CallFunc_Conv_SoftObjectReferenceToObject_ReturnValue_4;  // 0x60(0x8)
	struct ABP_BlendTriggerSphere_C* K2Node_DynamicCast_AsBP_Blend_Trigger_Sphere;  // 0x68(0x8)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool K2Node_DynamicCast_bSuccess_4 : 1;  // 0x70(0x1)
	char pad_113[7];  // 0x71(0x7)
	struct UObject* CallFunc_Conv_SoftObjectReferenceToObject_ReturnValue_5;  // 0x78(0x8)
	char pad_128_1 : 7;  // 0x80(0x1)
	bool CallFunc_IsValid_ReturnValue_4 : 1;  // 0x80(0x1)
	char pad_129[7];  // 0x81(0x7)
	struct ABP_BlendTriggerSphere_C* K2Node_DynamicCast_AsBP_Blend_Trigger_Sphere_2;  // 0x88(0x8)
	char pad_144_1 : 7;  // 0x90(0x1)
	bool K2Node_DynamicCast_bSuccess_5 : 1;  // 0x90(0x1)
	char pad_145_1 : 7;  // 0x91(0x1)
	bool CallFunc_IsValid_ReturnValue_5 : 1;  // 0x91(0x1)
	char pad_146[6];  // 0x92(0x6)
	struct UObject* CallFunc_Conv_SoftObjectReferenceToObject_ReturnValue_6;  // 0x98(0x8)
	struct ABP_BlendTriggerSphere_C* K2Node_DynamicCast_AsBP_Blend_Trigger_Sphere_3;  // 0xA0(0x8)
	char pad_168_1 : 7;  // 0xA8(0x1)
	bool K2Node_DynamicCast_bSuccess_6 : 1;  // 0xA8(0x1)
	char pad_169_1 : 7;  // 0xA9(0x1)
	bool CallFunc_IsValid_ReturnValue_6 : 1;  // 0xA9(0x1)
	char pad_170[2];  // 0xAA(0x2)
	float CallFunc_Multiply_IntFloat_ReturnValue;  // 0xAC(0x4)
	struct UAudioComponent* CallFunc_SpawnSoundAttached_ReturnValue;  // 0xB0(0x8)
	struct UAudioComponent* CallFunc_SpawnSoundAttached_ReturnValue_2;  // 0xB8(0x8)
	struct UAudioComponent* CallFunc_SpawnSoundAttached_ReturnValue_3;  // 0xC0(0x8)
	struct UAudioComponent* CallFunc_SpawnSoundAttached_ReturnValue_4;  // 0xC8(0x8)
	struct FConversationReference CallFunc_MakeConversationReference_ReturnValue;  // 0xD0(0x18)
	struct ASurvivalPlayerCharacter* CallFunc_GetLocalSurvivalPlayerCharacter_ReturnValue;  // 0xE8(0x8)
	struct FGuid CallFunc_GetConversationID_ReturnValue;  // 0xF0(0x10)

}; 
// Function BP_Pond_Biodome.BP_Pond_Biodome_C.BndEvt__ConditionalToggle_DomeOpen_K2Node_ComponentBoundEvent_0_OnConditionalStateChanged__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FBndEvt__ConditionalToggle_DomeOpen_K2Node_ComponentBoundEvent_0_OnConditionalStateChanged__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bIsActive : 1;  // 0x0(0x1)

}; 
// Function BP_Pond_Biodome.BP_Pond_Biodome_C.SetRotationY
// Size: 0xB8(Inherited: 0x0) 
struct FSetRotationY
{
	struct UStaticMeshComponent* TargetActor;  // 0x0(0x8)
	float NewRotationY;  // 0x8(0x4)
	struct FRotator CallFunc_K2_GetComponentRotation_ReturnValue;  // 0xC(0xC)
	float CallFunc_BreakRotator_Roll;  // 0x18(0x4)
	float CallFunc_BreakRotator_Pitch;  // 0x1C(0x4)
	float CallFunc_BreakRotator_Yaw;  // 0x20(0x4)
	struct FRotator CallFunc_MakeRotator_ReturnValue;  // 0x24(0xC)
	struct FHitResult CallFunc_K2_SetWorldRotation_SweepHitResult;  // 0x30(0x88)

}; 
