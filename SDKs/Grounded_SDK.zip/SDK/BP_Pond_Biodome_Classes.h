#pragma once 
#include <BP_Pond_Biodome_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Pond_Biodome.BP_Pond_Biodome_C
// Size: 0x348(Inherited: 0x230) 
struct ABP_Pond_Biodome_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x230(0x8)
	struct UAudioComponent* SFXDomePivotJoint02;  // 0x238(0x8)
	struct UAudioComponent* SFXDomePivotJoint01;  // 0x240(0x8)
	struct UAudioComponent* domeloop;  // 0x248(0x8)
	struct UOCLComponent* OCL;  // 0x250(0x8)
	struct UConditionalToggleComponent* ConditionalToggle_DomeOpen;  // 0x258(0x8)
	struct UPersistenceComponent* Persistence;  // 0x260(0x8)
	struct UObsidianIDComponent* ObsidianId;  // 0x268(0x8)
	struct UStaticMeshComponent* RetainingShield02;  // 0x270(0x8)
	struct UStaticMeshComponent* RetainingShield01;  // 0x278(0x8)
	struct UStaticMeshComponent* OuterShield02;  // 0x280(0x8)
	struct UStaticMeshComponent* OuterShield01;  // 0x288(0x8)
	struct UStaticMeshComponent* MidShield02;  // 0x290(0x8)
	struct UStaticMeshComponent* MidShield01;  // 0x298(0x8)
	struct UStaticMeshComponent* InnerShield01;  // 0x2A0(0x8)
	struct UStaticMeshComponent* InnerShield02;  // 0x2A8(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x2B0(0x8)
	float TL_DomeLightTransition_Alpha_8692F3AA43B59E3E778088930B4AB0EC;  // 0x2B8(0x4)
	char ETimelineDirection TL_DomeLightTransition__Direction_8692F3AA43B59E3E778088930B4AB0EC;  // 0x2BC(0x1)
	char pad_701[3];  // 0x2BD(0x3)
	struct UTimelineComponent* TL_DomeLightTransition;  // 0x2C0(0x8)
	float RotateOuterShields_Rotation_BA090F5D4B6988ABED09D99D10B0AEB6;  // 0x2C8(0x4)
	char ETimelineDirection RotateOuterShields__Direction_BA090F5D4B6988ABED09D99D10B0AEB6;  // 0x2CC(0x1)
	char pad_717[3];  // 0x2CD(0x3)
	struct UTimelineComponent* RotateOuterShields;  // 0x2D0(0x8)
	float RotateMidShields_Rotation_5A5BC6DC4F5DCE7DC6322199518453CA;  // 0x2D8(0x4)
	char ETimelineDirection RotateMidShields__Direction_5A5BC6DC4F5DCE7DC6322199518453CA;  // 0x2DC(0x1)
	char pad_733[3];  // 0x2DD(0x3)
	struct UTimelineComponent* RotateMidShields;  // 0x2E0(0x8)
	float RotateInnerShields_Rotation_CC4178A94EA6E16F54A75CA681C5B351;  // 0x2E8(0x4)
	char ETimelineDirection RotateInnerShields__Direction_CC4178A94EA6E16F54A75CA681C5B351;  // 0x2EC(0x1)
	char pad_749[3];  // 0x2ED(0x3)
	struct UTimelineComponent* RotateInnerShields;  // 0x2F0(0x8)
	struct TSoftObjectPtr<ABP_BlendTrigger_C> BlendTrigger;  // 0x2F8(0x28)
	struct TSoftObjectPtr<ABP_BlendTriggerSphere_C> BlendTriggerSphere;  // 0x320(0x28)

	void SetRotationY(struct UStaticMeshComponent* TargetActor, float NewRotationY); // Function BP_Pond_Biodome.BP_Pond_Biodome_C.SetRotationY
	void RotateInnerShields__FinishedFunc(); // Function BP_Pond_Biodome.BP_Pond_Biodome_C.RotateInnerShields__FinishedFunc
	void RotateInnerShields__UpdateFunc(); // Function BP_Pond_Biodome.BP_Pond_Biodome_C.RotateInnerShields__UpdateFunc
	void RotateInnerShields__StartNext__EventFunc(); // Function BP_Pond_Biodome.BP_Pond_Biodome_C.RotateInnerShields__StartNext__EventFunc
	void RotateMidShields__FinishedFunc(); // Function BP_Pond_Biodome.BP_Pond_Biodome_C.RotateMidShields__FinishedFunc
	void RotateMidShields__UpdateFunc(); // Function BP_Pond_Biodome.BP_Pond_Biodome_C.RotateMidShields__UpdateFunc
	void RotateMidShields__StartNext__EventFunc(); // Function BP_Pond_Biodome.BP_Pond_Biodome_C.RotateMidShields__StartNext__EventFunc
	void RotateOuterShields__FinishedFunc(); // Function BP_Pond_Biodome.BP_Pond_Biodome_C.RotateOuterShields__FinishedFunc
	void RotateOuterShields__UpdateFunc(); // Function BP_Pond_Biodome.BP_Pond_Biodome_C.RotateOuterShields__UpdateFunc
	void TL_DomeLightTransition__FinishedFunc(); // Function BP_Pond_Biodome.BP_Pond_Biodome_C.TL_DomeLightTransition__FinishedFunc
	void TL_DomeLightTransition__UpdateFunc(); // Function BP_Pond_Biodome.BP_Pond_Biodome_C.TL_DomeLightTransition__UpdateFunc
	void StartDomeOpeningSequence(bool IsActive); // Function BP_Pond_Biodome.BP_Pond_Biodome_C.StartDomeOpeningSequence
	void ReceiveBeginPlay(); // Function BP_Pond_Biodome.BP_Pond_Biodome_C.ReceiveBeginPlay
	void BndEvt__ConditionalToggle_DomeOpen_K2Node_ComponentBoundEvent_0_OnConditionalStateChanged__DelegateSignature(bool bIsActive); // Function BP_Pond_Biodome.BP_Pond_Biodome_C.BndEvt__ConditionalToggle_DomeOpen_K2Node_ComponentBoundEvent_0_OnConditionalStateChanged__DelegateSignature
	void ExecuteUbergraph_BP_Pond_Biodome(int32_t EntryPoint); // Function BP_Pond_Biodome.BP_Pond_Biodome_C.ExecuteUbergraph_BP_Pond_Biodome
}; 



