#pragma once 
#include <BP_Haze_Fungus_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Haze_Fungus.BP_Haze_Fungus_C
// Size: 0x450(Inherited: 0x420) 
struct ABP_Haze_Fungus_C : public ABP_ToppleHarvestNode_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x420(0x8)
	struct UParticleSystemComponent* SporeParticles;  // 0x428(0x8)
	struct UPointLightComponent* PointLight;  // 0x430(0x8)
	float Timeline_0_NewTrack_0_C70F7A10406D19FFE2A661B5A3C4BFF8;  // 0x438(0x4)
	char ETimelineDirection Timeline_0__Direction_C70F7A10406D19FFE2A661B5A3C4BFF8;  // 0x43C(0x1)
	char pad_1085[3];  // 0x43D(0x3)
	struct UTimelineComponent* Timeline_1;  // 0x440(0x8)
	struct UMaterialInstanceDynamic* MID_Body;  // 0x448(0x8)

	void Timeline_0__FinishedFunc(); // Function BP_Haze_Fungus.BP_Haze_Fungus_C.Timeline_0__FinishedFunc
	void Timeline_0__UpdateFunc(); // Function BP_Haze_Fungus.BP_Haze_Fungus_C.Timeline_0__UpdateFunc
	void ReceiveBeginPlay(); // Function BP_Haze_Fungus.BP_Haze_Fungus_C.ReceiveBeginPlay
	void OnTakeAnyDamage_Event_1(struct AActor* DamagedActor, float Damage, struct UDamageType* DamageType, struct AController* InstigatedBy, struct AActor* DamageCauser); // Function BP_Haze_Fungus.BP_Haze_Fungus_C.OnTakeAnyDamage_Event_1
	void Multicast On Dmg Taken(); // Function BP_Haze_Fungus.BP_Haze_Fungus_C.Multicast On Dmg Taken
	void ExecuteUbergraph_BP_Haze_Fungus(int32_t EntryPoint); // Function BP_Haze_Fungus.BP_Haze_Fungus_C.ExecuteUbergraph_BP_Haze_Fungus
}; 



