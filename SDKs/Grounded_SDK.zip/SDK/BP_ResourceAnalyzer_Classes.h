#pragma once 
#include <BP_ResourceAnalyzer_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_ResourceAnalyzer.BP_ResourceAnalyzer_C
// Size: 0x768(Inherited: 0x730) 
struct ABP_ResourceAnalyzer_C : public AResourceAnalyzerBuilding
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x730(0x8)
	struct USpotLightComponent* PinkLight;  // 0x738(0x8)
	struct UPointLightComponent* GreenLight;  // 0x740(0x8)
	struct USkeletalMeshComponent* SkeletalMesh;  // 0x748(0x8)
	struct UTransmitterComponent* TransmitterComponent;  // 0x750(0x8)
	struct FLocString InteractString;  // 0x758(0x10)

	void GetInteractionText(uint8_t  Channel, struct AActor* InstigatedBy, struct FString& OutText); // Function BP_ResourceAnalyzer.BP_ResourceAnalyzer_C.GetInteractionText
	void Interact(uint8_t  Channel, struct AActor* InstigatedBy); // Function BP_ResourceAnalyzer.BP_ResourceAnalyzer_C.Interact
	void ReceiveBeginPlay(); // Function BP_ResourceAnalyzer.BP_ResourceAnalyzer_C.ReceiveBeginPlay
	void ExecuteUbergraph_BP_ResourceAnalyzer(int32_t EntryPoint); // Function BP_ResourceAnalyzer.BP_ResourceAnalyzer_C.ExecuteUbergraph_BP_ResourceAnalyzer
}; 



