#pragma once 
#include "SDK.h" 
 
 
// Function BP_BASE_GrassBlade_Burned.BP_BASE_GrassBlade_Burned_C.ExecuteUbergraph_BP_BASE_GrassBlade_Burned
// Size: 0x1A8(Inherited: 0x0) 
struct FExecuteUbergraph_BP_BASE_GrassBlade_Burned
{
	int32_t EntryPoint;  // 0x0(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x4(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x8(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0xC(0x4)
	int32_t Temp_int_Array_Index_Variable_2;  // 0x10(0x4)
	int32_t Temp_int_Loop_Counter_Variable_2;  // 0x14(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0x18(0x4)
	int32_t Temp_int_Array_Index_Variable_3;  // 0x1C(0x4)
	struct TArray<struct FName> CallFunc_GetAllSocketNames_ReturnValue;  // 0x20(0x10)
	struct UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue;  // 0x30(0x8)
	struct FName CallFunc_Array_Get_Item;  // 0x38(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x40(0x4)
	char pad_68[12];  // 0x44(0xC)
	struct FTransform CallFunc_GetSocketTransform_ReturnValue;  // 0x50(0x30)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0x80(0x4)
	char pad_132[12];  // 0x84(0xC)
	struct FTransform CallFunc_Array_Get_Item_2;  // 0x90(0x30)
	int32_t CallFunc_Array_Length_ReturnValue_2;  // 0xC0(0x4)
	struct FVector CallFunc_BreakTransform_Location;  // 0xC4(0xC)
	struct FRotator CallFunc_BreakTransform_Rotation;  // 0xD0(0xC)
	struct FVector CallFunc_BreakTransform_Scale;  // 0xDC(0xC)
	char pad_232_1 : 7;  // 0xE8(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0xE8(0x1)
	char pad_233[7];  // 0xE9(0x7)
	struct UParticleSystemComponent* CallFunc_SpawnEmitterAtLocation_ReturnValue;  // 0xF0(0x8)
	int32_t Temp_int_Loop_Counter_Variable_3;  // 0xF8(0x4)
	char pad_252_1 : 7;  // 0xFC(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_2 : 1;  // 0xFC(0x1)
	char pad_253[3];  // 0xFD(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue_3;  // 0x100(0x4)
	char pad_260[4];  // 0x104(0x4)
	struct TArray<struct USceneComponent*> CallFunc_GetChildrenComponents_Children;  // 0x108(0x10)
	struct USceneComponent* CallFunc_Array_Get_Item_3;  // 0x118(0x8)
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0x120(0x8)
	int32_t CallFunc_Array_Length_ReturnValue_3;  // 0x128(0x4)
	char pad_300[4];  // 0x12C(0x4)
	struct ASpawnedItem* K2Node_DynamicCast_AsSpawned_Item;  // 0x130(0x8)
	char pad_312_1 : 7;  // 0x138(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x138(0x1)
	char pad_313_1 : 7;  // 0x139(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_3 : 1;  // 0x139(0x1)
	char pad_314[6];  // 0x13A(0x6)
	struct FDamageInfo K2Node_Event_DamageInfo;  // 0x140(0x68)

}; 
// Function BP_BASE_GrassBlade_Burned.BP_BASE_GrassBlade_Burned_C.Handle Death
// Size: 0x68(Inherited: 0xAC) 
struct FHandle Death : public FHandle Death
{
	struct FDamageInfo DamageInfo;  // 0x0(0x68)

}; 
