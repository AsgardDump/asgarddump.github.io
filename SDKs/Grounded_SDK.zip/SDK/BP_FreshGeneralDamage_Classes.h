#pragma once 
#include <BP_FreshGeneralDamage_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_FreshGeneralDamage.BP_FreshGeneralDamage_C
// Size: 0x78(Inherited: 0x78) 
struct UBP_FreshGeneralDamage_C : public USurvivalDamageType
{

}; 



