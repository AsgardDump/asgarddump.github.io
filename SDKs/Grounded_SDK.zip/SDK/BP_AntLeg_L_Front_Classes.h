#pragma once 
#include <BP_AntLeg_L_Front_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_AntLeg_L_Front.BP_AntLeg_L_Front_C
// Size: 0x2B0(Inherited: 0x2A3) 
struct ABP_AntLeg_L_Front_C : public ABP_InsectPart_C
{
	char pad_675[5];  // 0x2A3(0x5)
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x2A8(0x8)

	void ReceiveTick(float DeltaSeconds); // Function BP_AntLeg_L_Front.BP_AntLeg_L_Front_C.ReceiveTick
	void ExecuteUbergraph_BP_AntLeg_L_Front(int32_t EntryPoint); // Function BP_AntLeg_L_Front.BP_AntLeg_L_Front_C.ExecuteUbergraph_BP_AntLeg_L_Front
}; 



