#pragma once 
#include <BP_AcidDamage_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_AcidDamage.BP_AcidDamage_C
// Size: 0x78(Inherited: 0x78) 
struct UBP_AcidDamage_C : public USurvivalDamageType
{

}; 



