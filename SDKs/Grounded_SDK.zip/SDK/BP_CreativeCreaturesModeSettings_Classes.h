#pragma once 
#include <BP_CreativeCreaturesModeSettings_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_CreativeCreaturesModeSettings.BP_CreativeCreaturesModeSettings_C
// Size: 0x78(Inherited: 0x78) 
struct UBP_CreativeCreaturesModeSettings_C : public USurvivalGameModeSettings
{

}; 



