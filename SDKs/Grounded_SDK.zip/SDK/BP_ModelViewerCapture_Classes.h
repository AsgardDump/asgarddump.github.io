#pragma once 
#include <BP_ModelViewerCapture_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_ModelViewerCapture.BP_ModelViewerCapture_C
// Size: 0x30D(Inherited: 0x250) 
struct ABP_ModelViewerCapture_C : public AModelViewerCapture
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x250(0x8)
	struct UPointLightComponent* TopLight;  // 0x258(0x8)
	struct UPointLightComponent* PointLight2;  // 0x260(0x8)
	struct UPointLightComponent* PointLight1;  // 0x268(0x8)
	struct UPointLightComponent* PointLight;  // 0x270(0x8)
	struct USceneComponent* LightOffset;  // 0x278(0x8)
	struct USceneCaptureComponent2D* SceneCaptureComponent2DColor;  // 0x280(0x8)
	struct USceneCaptureComponent2D* SceneCaptureComponent2DAlpha;  // 0x288(0x8)
	struct USceneComponent* Offset;  // 0x290(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x298(0x8)
	struct TArray<struct USceneCaptureComponent2D*> SceneCaptureComponents;  // 0x2A0(0x10)
	struct AActor* TempViewingModel;  // 0x2B0(0x8)
	struct AActor* ExistingViewingModel;  // 0x2B8(0x8)
	char pad_704_1 : 7;  // 0x2C0(0x1)
	bool AutoRotate : 1;  // 0x2C0(0x1)
	char pad_705_1 : 7;  // 0x2C1(0x1)
	bool Orthographic : 1;  // 0x2C1(0x1)
	char pad_706[2];  // 0x2C2(0x2)
	struct FVector ViewOffset;  // 0x2C4(0xC)
	struct UUI_ModelViewer_C* SourceUIModelViewer;  // 0x2D0(0x8)
	char pad_728_1 : 7;  // 0x2D8(0x1)
	bool RequiresLightChannelChanges : 1;  // 0x2D8(0x1)
	char pad_729[7];  // 0x2D9(0x7)
	struct UStaticMesh* ArmorDummyMesh;  // 0x2E0(0x8)
	struct UStaticMesh* AphidPetMesh;  // 0x2E8(0x8)
	struct FMulticastInlineDelegate OnNewModelViewed;  // 0x2F0(0x10)
	struct FVector DefaultActorSpawnLocation;  // 0x300(0xC)
	char pad_780_1 : 7;  // 0x30C(0x1)
	bool ScaleToFitMinBounds : 1;  // 0x30C(0x1)

	void UpdateCaptureSource(); // Function BP_ModelViewerCapture.BP_ModelViewerCapture_C.UpdateCaptureSource
	void RemoveFilmGrain(); // Function BP_ModelViewerCapture.BP_ModelViewerCapture_C.RemoveFilmGrain
	void GetModel(struct AActor*& Model); // Function BP_ModelViewerCapture.BP_ModelViewerCapture_C.GetModel
	void UserConstructionScript(); // Function BP_ModelViewerCapture.BP_ModelViewerCapture_C.UserConstructionScript
	void ReceiveBeginPlay(); // Function BP_ModelViewerCapture.BP_ModelViewerCapture_C.ReceiveBeginPlay
	void Setup(struct UTextureRenderTarget2D* ColorRenderTarget, struct UTextureRenderTarget2D* AlphaRenderTarget); // Function BP_ModelViewerCapture.BP_ModelViewerCapture_C.Setup
	void ViewExistingActor(struct AActor* Actor, struct FVector Offset); // Function BP_ModelViewerCapture.BP_ModelViewerCapture_C.ViewExistingActor
	void ReceiveDestroyed(); // Function BP_ModelViewerCapture.BP_ModelViewerCapture_C.ReceiveDestroyed
	void AddRotationSelf(struct FVector2D UIRotation, bool DisableAutoRotate); // Function BP_ModelViewerCapture.BP_ModelViewerCapture_C.AddRotationSelf
	void AddRotationModel(struct FVector2D UIRotation); // Function BP_ModelViewerCapture.BP_ModelViewerCapture_C.AddRotationModel
	void ForceSetOrthoWidth(float OrthoWidth); // Function BP_ModelViewerCapture.BP_ModelViewerCapture_C.ForceSetOrthoWidth
	void AddRotationDegrees(float RotationX, float RotationY); // Function BP_ModelViewerCapture.BP_ModelViewerCapture_C.AddRotationDegrees
	void SetOrthographicWidth(float OrthoWidth); // Function BP_ModelViewerCapture.BP_ModelViewerCapture_C.SetOrthographicWidth
	void HandleSceneCapture(); // Function BP_ModelViewerCapture.BP_ModelViewerCapture_C.HandleSceneCapture
	void SetChannelLightingEnabled(bool Active); // Function BP_ModelViewerCapture.BP_ModelViewerCapture_C.SetChannelLightingEnabled
	void ClearModel(); // Function BP_ModelViewerCapture.BP_ModelViewerCapture_C.ClearModel
	void UpdateAndCaptureScene(float DeltaSeconds); // Function BP_ModelViewerCapture.BP_ModelViewerCapture_C.UpdateAndCaptureScene
	void SetLightScalar(float LightScalar); // Function BP_ModelViewerCapture.BP_ModelViewerCapture_C.SetLightScalar
	void ShowOverheadSpotlight(); // Function BP_ModelViewerCapture.BP_ModelViewerCapture_C.ShowOverheadSpotlight
	void HandlePaperdollEquipmentVisibility2(struct UEquipmentComponent* Sender, struct UItem* ForItem); // Function BP_ModelViewerCapture.BP_ModelViewerCapture_C.HandlePaperdollEquipmentVisibility2
	void HandlePaperdollEquipmentVisibility(); // Function BP_ModelViewerCapture.BP_ModelViewerCapture_C.HandlePaperdollEquipmentVisibility
	void Cleanup(); // Function BP_ModelViewerCapture.BP_ModelViewerCapture_C.Cleanup
	void ViewBlueprint(AActor* BlueprintClass, float Scale, struct FVector Offset); // Function BP_ModelViewerCapture.BP_ModelViewerCapture_C.ViewBlueprint
	void ViewSkeletalMesh(struct USkeletalMesh* Mesh, struct TArray<struct UMaterialInterface*>& Materials, float Scale, struct FVector Offset); // Function BP_ModelViewerCapture.BP_ModelViewerCapture_C.ViewSkeletalMesh
	void ViewStaticMesh(struct UStaticMesh* Mesh, struct TArray<struct UMaterialInterface*>& Materials, float Scale, struct FVector Offset); // Function BP_ModelViewerCapture.BP_ModelViewerCapture_C.ViewStaticMesh
	void ViewArmorMesh(struct USkeletalMesh* Mesh, struct TArray<struct UMaterialInterface*>& Materials, float Scale, struct FVector Offset, uint8_t  Slot, bool bUsePet); // Function BP_ModelViewerCapture.BP_ModelViewerCapture_C.ViewArmorMesh
	void SetShowSkyLight(bool bShow); // Function BP_ModelViewerCapture.BP_ModelViewerCapture_C.SetShowSkyLight
	void View2DTexture(struct UTexture* Texture); // Function BP_ModelViewerCapture.BP_ModelViewerCapture_C.View2DTexture
	void ExecuteUbergraph_BP_ModelViewerCapture(int32_t EntryPoint); // Function BP_ModelViewerCapture.BP_ModelViewerCapture_C.ExecuteUbergraph_BP_ModelViewerCapture
	void OnNewModelViewed__DelegateSignature(); // Function BP_ModelViewerCapture.BP_ModelViewerCapture_C.OnNewModelViewed__DelegateSignature
}; 



