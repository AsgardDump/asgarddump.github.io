#pragma once 
#include <BP_Protohive_Topple_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Protohive_Topple.BP_Protohive_Topple_C
// Size: 0x430(Inherited: 0x420) 
struct ABP_Protohive_Topple_C : public ABP_ToppleHarvestNode_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x420(0x8)
	AActor* SpawnOnDeathActor;  // 0x428(0x8)

	struct FVector GetItemSourceWorldLocation(struct FDataTableRowHandle& ItemType); // Function BP_Protohive_Topple.BP_Protohive_Topple_C.GetItemSourceWorldLocation
	bool IsSourceForItem(struct FDataTableRowHandle& ItemType); // Function BP_Protohive_Topple.BP_Protohive_Topple_C.IsSourceForItem
	void Handle Death(struct FDamageInfo DamageInfo); // Function BP_Protohive_Topple.BP_Protohive_Topple_C.Handle Death
	void MulticastHandleDestroy(); // Function BP_Protohive_Topple.BP_Protohive_Topple_C.MulticastHandleDestroy
	void ExecuteUbergraph_BP_Protohive_Topple(int32_t EntryPoint); // Function BP_Protohive_Topple.BP_Protohive_Topple_C.ExecuteUbergraph_BP_Protohive_Topple
}; 



