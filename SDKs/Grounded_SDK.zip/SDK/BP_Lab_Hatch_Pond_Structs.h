#pragma once 
#include "SDK.h" 
 
 
// Function BP_Lab_Hatch_Pond.BP_Lab_Hatch_Pond_C.IsInteractionEnabled
// Size: 0x13(Inherited: 0x18) 
struct FIsInteractionEnabled : public FIsInteractionEnabled
{
	uint8_t  Channel;  // 0x0(0x1)
	struct AActor* InstigatedBy;  // 0x8(0x8)
	char EInteractionState ReturnValue;  // 0x10(0x1)
	char pad_34_1 : 7;  // 0x22(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // 0x11(0x1)
	char pad_35_1 : 7;  // 0x23(0x1)
	bool CallFunc_IsEnabled_ReturnValue : 1;  // 0x12(0x1)

}; 
// Function BP_Lab_Hatch_Pond.BP_Lab_Hatch_Pond_C.ExecuteUbergraph_BP_Lab_Hatch_Pond
// Size: 0x3F8(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Lab_Hatch_Pond
{
	int32_t EntryPoint;  // 0x0(0x4)
	struct FRotator CallFunc_MakeRotator_ReturnValue;  // 0x4(0xC)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x10(0x4)
	struct FHitResult CallFunc_K2_SetRelativeRotation_SweepHitResult;  // 0x14(0x88)
	struct FRotator CallFunc_MakeRotator_ReturnValue_2;  // 0x9C(0xC)
	struct FRotator CallFunc_MakeRotator_ReturnValue_3;  // 0xA8(0xC)
	struct FRotator CallFunc_MakeRotator_ReturnValue_4;  // 0xB4(0xC)
	struct FHitResult CallFunc_K2_SetRelativeRotation_SweepHitResult_2;  // 0xC0(0x88)
	struct FHitResult CallFunc_K2_SetRelativeRotation_SweepHitResult_3;  // 0x148(0x88)
	struct FHitResult CallFunc_K2_SetRelativeRotation_SweepHitResult_4;  // 0x1D0(0x88)
	struct FHitResult CallFunc_K2_SetRelativeRotation_SweepHitResult_5;  // 0x258(0x88)
	struct FHitResult CallFunc_K2_SetRelativeRotation_SweepHitResult_6;  // 0x2E0(0x88)
	struct FHitResult CallFunc_K2_SetRelativeRotation_SweepHitResult_7;  // 0x368(0x88)
	char pad_1008_1 : 7;  // 0x3F0(0x1)
	bool K2Node_ComponentBoundEvent_bIsActive : 1;  // 0x3F0(0x1)
	char pad_1009_1 : 7;  // 0x3F1(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0x3F1(0x1)
	char pad_1010_1 : 7;  // 0x3F2(0x1)
	bool CallFunc_IsEnabled_ReturnValue : 1;  // 0x3F2(0x1)
	char pad_1011[1];  // 0x3F3(0x1)
	float CallFunc_GetTimelineLength_ReturnValue;  // 0x3F4(0x4)

}; 
// Function BP_Lab_Hatch_Pond.BP_Lab_Hatch_Pond_C.BndEvt__ConditionalToggle_HatchOpened_K2Node_ComponentBoundEvent_2_OnConditionalStateChanged__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FBndEvt__ConditionalToggle_HatchOpened_K2Node_ComponentBoundEvent_2_OnConditionalStateChanged__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bIsActive : 1;  // 0x0(0x1)

}; 
