#pragma once 
#include <BP_BlendTriggerSphere_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_BlendTriggerSphere.BP_BlendTriggerSphere_C
// Size: 0x2C0(Inherited: 0x230) 
struct ABP_BlendTriggerSphere_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x230(0x8)
	struct USphereComponent* Sphere;  // 0x238(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x240(0x8)
	float X;  // 0x248(0x4)
	char pad_588[4];  // 0x24C(0x4)
	struct ASurvivalGameState* SurvivalGameState;  // 0x250(0x8)
	struct APlayerCameraManager* CameraManager;  // 0x258(0x8)
	struct ABP_TimeOfDayLighting_C* TimeOfDay;  // 0x260(0x8)
	struct TArray<struct ABP_VolumeFog_C*> ScaledFog;  // 0x268(0x10)
	float BlendMargin;  // 0x278(0x4)
	float BlendMarginZ;  // 0x27C(0x4)
	float Radius;  // 0x280(0x4)
	char pad_644_1 : 7;  // 0x284(0x1)
	bool IsBlending : 1;  // 0x284(0x1)
	char pad_645[3];  // 0x285(0x3)
	float Y;  // 0x288(0x4)
	float Z;  // 0x28C(0x4)
	char pad_656_1 : 7;  // 0x290(0x1)
	bool IsCylinder : 1;  // 0x290(0x1)
	char pad_657[3];  // 0x291(0x3)
	float InteriorDaylightMultiplier;  // 0x294(0x4)
	float StrengthOfSkyLight;  // 0x298(0x4)
	char pad_668_1 : 7;  // 0x29C(0x1)
	bool ContributesToSun : 1;  // 0x29C(0x1)
	char pad_669_1 : 7;  // 0x29D(0x1)
	bool ContributesToMoon : 1;  // 0x29D(0x1)
	char pad_670_1 : 7;  // 0x29E(0x1)
	bool ContributesToHedge : 1;  // 0x29E(0x1)
	char pad_671_1 : 7;  // 0x29F(0x1)
	bool ContributesToFog : 1;  // 0x29F(0x1)
	char pad_672_1 : 7;  // 0x2A0(0x1)
	bool ContributesToInteriorDaylights : 1;  // 0x2A0(0x1)
	char pad_673_1 : 7;  // 0x2A1(0x1)
	bool ContributesToPostProcess : 1;  // 0x2A1(0x1)
	char pad_674[2];  // 0x2A2(0x2)
	struct FLinearColor TintSkylightColor;  // 0x2A4(0x10)
	char pad_692_1 : 7;  // 0x2B4(0x1)
	bool BlendX : 1;  // 0x2B4(0x1)
	char pad_693_1 : 7;  // 0x2B5(0x1)
	bool BlendY : 1;  // 0x2B5(0x1)
	char pad_694_1 : 7;  // 0x2B6(0x1)
	bool BlendZ : 1;  // 0x2B6(0x1)
	char pad_695_1 : 7;  // 0x2B7(0x1)
	bool ShowBoundsInGame : 1;  // 0x2B7(0x1)
	char pad_696_1 : 7;  // 0x2B8(0x1)
	bool BlendR : 1;  // 0x2B8(0x1)
	char pad_697_1 : 7;  // 0x2B9(0x1)
	bool BlocksBuilding : 1;  // 0x2B9(0x1)
	char pad_698[2];  // 0x2BA(0x2)
	float ExternalMultiplier;  // 0x2BC(0x4)

	void CheckCollisionMatch(struct UPrimitiveComponent* OtherComponent, bool& ActorComponentCondition); // Function BP_BlendTriggerSphere.BP_BlendTriggerSphere_C.CheckCollisionMatch
	void TrackTriggerOverlap(int32_t IncrementValue); // Function BP_BlendTriggerSphere.BP_BlendTriggerSphere_C.TrackTriggerOverlap
	void UserConstructionScript(); // Function BP_BlendTriggerSphere.BP_BlendTriggerSphere_C.UserConstructionScript
	void ReceiveTick(float DeltaSeconds); // Function BP_BlendTriggerSphere.BP_BlendTriggerSphere_C.ReceiveTick
	void ReceiveBeginPlay(); // Function BP_BlendTriggerSphere.BP_BlendTriggerSphere_C.ReceiveBeginPlay
	void HandleEndOverlapRespawn(struct APlayerController* Controller); // Function BP_BlendTriggerSphere.BP_BlendTriggerSphere_C.HandleEndOverlapRespawn
	void BndEvt__Sphere_K2Node_ComponentBoundEvent_4_ComponentBeginOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult& SweepResult); // Function BP_BlendTriggerSphere.BP_BlendTriggerSphere_C.BndEvt__Sphere_K2Node_ComponentBoundEvent_4_ComponentBeginOverlapSignature__DelegateSignature
	void BndEvt__Sphere_K2Node_ComponentBoundEvent_7_ComponentEndOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex); // Function BP_BlendTriggerSphere.BP_BlendTriggerSphere_C.BndEvt__Sphere_K2Node_ComponentBoundEvent_7_ComponentEndOverlapSignature__DelegateSignature
	void ExecuteUbergraph_BP_BlendTriggerSphere(int32_t EntryPoint); // Function BP_BlendTriggerSphere.BP_BlendTriggerSphere_C.ExecuteUbergraph_BP_BlendTriggerSphere
}; 



