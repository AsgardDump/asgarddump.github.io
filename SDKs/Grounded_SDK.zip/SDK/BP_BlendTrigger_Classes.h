#pragma once 
#include <BP_BlendTrigger_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_BlendTrigger.BP_BlendTrigger_C
// Size: 0x36D(Inherited: 0x230) 
struct ABP_BlendTrigger_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x230(0x8)
	struct UStaticMeshComponent* DarkeningPlane;  // 0x238(0x8)
	struct UStaticMeshComponent* TriggerBoxInnerVisual;  // 0x240(0x8)
	struct UStaticMeshComponent* CylinderInner;  // 0x248(0x8)
	struct UStaticMeshComponent* CylinderOuter;  // 0x250(0x8)
	struct UStaticMeshComponent* TriggerBoxVisual;  // 0x258(0x8)
	struct UBoxComponent* BoxInner;  // 0x260(0x8)
	struct UBoxComponent* BoxOuter;  // 0x268(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x270(0x8)
	float X;  // 0x278(0x4)
	char pad_636[4];  // 0x27C(0x4)
	struct ASurvivalGameState* SurvivalGameState;  // 0x280(0x8)
	struct APlayerCameraManager* CameraManager;  // 0x288(0x8)
	struct ABP_TimeOfDayLighting_C* TimeOfDay;  // 0x290(0x8)
	struct TSoftObjectPtr<ABP_TimeOfDayLighting_C> TimeOfDayRef;  // 0x298(0x28)
	struct TArray<struct ABP_VolumeFog_C*> ScaledFog;  // 0x2C0(0x10)
	struct TArray<struct TSoftObjectPtr<ABP_VolumeFog_C>> ScaledFogRefs;  // 0x2D0(0x10)
	float BlendMargin;  // 0x2E0(0x4)
	float BlendMarginZ;  // 0x2E4(0x4)
	float Radius;  // 0x2E8(0x4)
	float ExternalMultiplier;  // 0x2EC(0x4)
	char pad_752_1 : 7;  // 0x2F0(0x1)
	bool Initialized : 1;  // 0x2F0(0x1)
	char pad_753_1 : 7;  // 0x2F1(0x1)
	bool IsBlending : 1;  // 0x2F1(0x1)
	char pad_754[2];  // 0x2F2(0x2)
	float Y;  // 0x2F4(0x4)
	float Z;  // 0x2F8(0x4)
	char pad_764_1 : 7;  // 0x2FC(0x1)
	bool OneSided : 1;  // 0x2FC(0x1)
	char pad_765_1 : 7;  // 0x2FD(0x1)
	bool IsCylinder : 1;  // 0x2FD(0x1)
	char pad_766_1 : 7;  // 0x2FE(0x1)
	bool BlendX : 1;  // 0x2FE(0x1)
	char pad_767_1 : 7;  // 0x2FF(0x1)
	bool BlendY : 1;  // 0x2FF(0x1)
	char pad_768_1 : 7;  // 0x300(0x1)
	bool BlendZ : 1;  // 0x300(0x1)
	char pad_769_1 : 7;  // 0x301(0x1)
	bool ShowBoundsInGame : 1;  // 0x301(0x1)
	char pad_770_1 : 7;  // 0x302(0x1)
	bool BlendR : 1;  // 0x302(0x1)
	char pad_771_1 : 7;  // 0x303(0x1)
	bool BlocksBuilding : 1;  // 0x303(0x1)
	int32_t Priority;  // 0x304(0x4)
	struct FBlendTriggerAttributes BlendTriggerAttributes;  // 0x308(0x2C)
	char pad_820_1 : 7;  // 0x334(0x1)
	bool PrintBlendValue : 1;  // 0x334(0x1)
	char pad_821_1 : 7;  // 0x335(0x1)
	bool HasDarkeningPlane : 1;  // 0x335(0x1)
	char pad_822[2];  // 0x336(0x2)
	float PixelDepthFade;  // 0x338(0x4)
	float BaselineOpacity;  // 0x33C(0x4)
	struct UMaterialInstanceDynamic* PlaneMID;  // 0x340(0x8)
	struct FVector Outer Box Extent;  // 0x348(0xC)
	struct FVector Relative Location;  // 0x354(0xC)
	struct FVector Inner Box Extent;  // 0x360(0xC)
	char pad_876_1 : 7;  // 0x36C(0x1)
	bool CanBlockFactionWaves : 1;  // 0x36C(0x1)

	void CheckBuilderOverlap(bool& OverlapFound); // Function BP_BlendTrigger.BP_BlendTrigger_C.CheckBuilderOverlap
	void CheckCollisionMatchBuilder(struct UPrimitiveComponent* OtherComponent, bool& IsBuilder); // Function BP_BlendTrigger.BP_BlendTrigger_C.CheckCollisionMatchBuilder
	void BlendDarkeningPlane(float BlendAlpha); // Function BP_BlendTrigger.BP_BlendTrigger_C.BlendDarkeningPlane
	void UpdateBlocksBuilding(); // Function BP_BlendTrigger.BP_BlendTrigger_C.UpdateBlocksBuilding
	void SetBlendAlphaFromLocation(float InverseTransformAxis, float TriggerDimension, float BlendMargin, float& BlendAlpha); // Function BP_BlendTrigger.BP_BlendTrigger_C.SetBlendAlphaFromLocation
	void CheckCollisionMatch(struct UPrimitiveComponent* OtherComponent, bool& IsPlayer); // Function BP_BlendTrigger.BP_BlendTrigger_C.CheckCollisionMatch
	void CheckPlayerOverlap(bool& OverlapFound); // Function BP_BlendTrigger.BP_BlendTrigger_C.CheckPlayerOverlap
	void Initialize(); // Function BP_BlendTrigger.BP_BlendTrigger_C.Initialize
	void UserConstructionScript(); // Function BP_BlendTrigger.BP_BlendTrigger_C.UserConstructionScript
	void ReceiveTick(float DeltaSeconds); // Function BP_BlendTrigger.BP_BlendTrigger_C.ReceiveTick
	void BndEvt__Box_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult& SweepResult); // Function BP_BlendTrigger.BP_BlendTrigger_C.BndEvt__Box_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature
	void BndEvt__Box_K2Node_ComponentBoundEvent_1_ComponentEndOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex); // Function BP_BlendTrigger.BP_BlendTrigger_C.BndEvt__Box_K2Node_ComponentBoundEvent_1_ComponentEndOverlapSignature__DelegateSignature
	void ReceiveBeginPlay(); // Function BP_BlendTrigger.BP_BlendTrigger_C.ReceiveBeginPlay
	void HandleEndOverlapRespawn(struct APlayerController* Controller); // Function BP_BlendTrigger.BP_BlendTrigger_C.HandleEndOverlapRespawn
	void BndEvt__Cylinder_K2Node_ComponentBoundEvent_2_ComponentBeginOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult& SweepResult); // Function BP_BlendTrigger.BP_BlendTrigger_C.BndEvt__Cylinder_K2Node_ComponentBoundEvent_2_ComponentBeginOverlapSignature__DelegateSignature
	void BndEvt__Cylinder_K2Node_ComponentBoundEvent_3_ComponentEndOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex); // Function BP_BlendTrigger.BP_BlendTrigger_C.BndEvt__Cylinder_K2Node_ComponentBoundEvent_3_ComponentEndOverlapSignature__DelegateSignature
	void CylinderBlend(); // Function BP_BlendTrigger.BP_BlendTrigger_C.CylinderBlend
	void OnPlayerRespawned(struct APlayerController* Controller); // Function BP_BlendTrigger.BP_BlendTrigger_C.OnPlayerRespawned
	void HandleBuildModeChanged(struct APlayerController* PlayerController, bool IsInBuildMode); // Function BP_BlendTrigger.BP_BlendTrigger_C.HandleBuildModeChanged
	void OnBuildModeEnteredNoOverlap(); // Function BP_BlendTrigger.BP_BlendTrigger_C.OnBuildModeEnteredNoOverlap
	void OnBuildModeExitWithOverlap(); // Function BP_BlendTrigger.BP_BlendTrigger_C.OnBuildModeExitWithOverlap
	void OnBuildModeExitNoOverlap(); // Function BP_BlendTrigger.BP_BlendTrigger_C.OnBuildModeExitNoOverlap
	void ExecuteUbergraph_BP_BlendTrigger(int32_t EntryPoint); // Function BP_BlendTrigger.BP_BlendTrigger_C.ExecuteUbergraph_BP_BlendTrigger
}; 



