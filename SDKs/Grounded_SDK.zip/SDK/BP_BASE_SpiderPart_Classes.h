#pragma once 
#include <BP_BASE_SpiderPart_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_BASE_SpiderPart.BP_BASE_SpiderPart_C
// Size: 0x2B0(Inherited: 0x2A3) 
struct ABP_BASE_SpiderPart_C : public ABP_InsectPart_C
{
	char pad_675[5];  // 0x2A3(0x5)
	struct UPhobiaControllerComponent* PhobiaController;  // 0x2A8(0x8)

}; 



