#pragma once 
#include <BP_AntLeg_R_Mid_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_AntLeg_R_Mid.BP_AntLeg_R_Mid_C
// Size: 0x2A3(Inherited: 0x2A3) 
struct ABP_AntLeg_R_Mid_C : public ABP_InsectPart_C
{

}; 



