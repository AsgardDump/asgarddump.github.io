#pragma once 
#include <BP_CustomModeSettings_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_CustomModeSettings.BP_CustomModeSettings_C
// Size: 0x78(Inherited: 0x78) 
struct UBP_CustomModeSettings_C : public USurvivalGameModeSettings
{

}; 



