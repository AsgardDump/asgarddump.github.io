#pragma once 
#include <BP_Plant_Small_Leafy_B_Dry_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Plant_Small_Leafy_B_Dry.BP_Plant_Small_Leafy_B_Dry_C
// Size: 0x4B8(Inherited: 0x4B8) 
struct ABP_Plant_Small_Leafy_B_Dry_C : public ABP_Plant_Small_Leafy_A_Dry_C
{

}; 



