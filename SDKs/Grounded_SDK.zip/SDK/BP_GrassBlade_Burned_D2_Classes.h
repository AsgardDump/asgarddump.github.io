#pragma once 
#include <BP_GrassBlade_Burned_D2_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_GrassBlade_Burned_D2.BP_GrassBlade_Burned_D2_C
// Size: 0x408(Inherited: 0x408) 
struct ABP_GrassBlade_Burned_D2_C : public ABP_BASE_GrassBlade_Burned_C
{

}; 



