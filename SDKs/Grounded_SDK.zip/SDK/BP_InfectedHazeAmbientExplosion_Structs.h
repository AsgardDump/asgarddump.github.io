#pragma once 
#include "SDK.h" 
 
 
// Function BP_InfectedHazeAmbientExplosion.BP_InfectedHazeAmbientExplosion_C.ExecuteUbergraph_BP_InfectedHazeAmbientExplosion
// Size: 0x315(Inherited: 0x0) 
struct FExecuteUbergraph_BP_InfectedHazeAmbientExplosion
{
	int32_t EntryPoint;  // 0x0(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x4(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x8(0x4)
	int32_t Temp_int_Loop_Counter_Variable_2;  // 0xC(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0x10(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x14(0x4)
	int32_t Temp_int_Array_Index_Variable_2;  // 0x18(0x4)
	int32_t Temp_int_Loop_Counter_Variable_3;  // 0x1C(0x4)
	int32_t Temp_int_Loop_Counter_Variable_4;  // 0x20(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_3;  // 0x24(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_4;  // 0x28(0x4)
	int32_t Temp_int_Array_Index_Variable_3;  // 0x2C(0x4)
	int32_t Temp_int_Array_Index_Variable_4;  // 0x30(0x4)
	int32_t Temp_int_Loop_Counter_Variable_5;  // 0x34(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_5;  // 0x38(0x4)
	int32_t Temp_int_Array_Index_Variable_5;  // 0x3C(0x4)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x40(0xC)
	float CallFunc_RandomFloatInRange_ReturnValue;  // 0x4C(0x4)
	struct UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue;  // 0x50(0x8)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_SleepingComponent_6;  // 0x58(0x8)
	struct FName K2Node_ComponentBoundEvent_BoneName_6;  // 0x60(0x8)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_SleepingComponent_5;  // 0x68(0x8)
	struct FName K2Node_ComponentBoundEvent_BoneName_5;  // 0x70(0x8)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_SleepingComponent_4;  // 0x78(0x8)
	struct FName K2Node_ComponentBoundEvent_BoneName_4;  // 0x80(0x8)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_SleepingComponent_3;  // 0x88(0x8)
	struct FName K2Node_ComponentBoundEvent_BoneName_3;  // 0x90(0x8)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_SleepingComponent_2;  // 0x98(0x8)
	struct FName K2Node_ComponentBoundEvent_BoneName_2;  // 0xA0(0x8)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_SleepingComponent;  // 0xA8(0x8)
	struct FName K2Node_ComponentBoundEvent_BoneName;  // 0xB0(0x8)
	struct TArray<struct AActor*> Temp_object_Variable;  // 0xB8(0x10)
	struct UMaterialInstanceDynamic* CallFunc_Array_Get_Item;  // 0xC8(0x8)
	int32_t CallFunc_Add_IntInt_ReturnValue_6;  // 0xD0(0x4)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0xD4(0x4)
	int32_t Temp_int_Variable;  // 0xD8(0x4)
	char pad_220_1 : 7;  // 0xDC(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0xDC(0x1)
	char pad_221[3];  // 0xDD(0x3)
	float CallFunc_K2_GetScalarParameterValue_ReturnValue;  // 0xE0(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0xE4(0x4)
	struct TArray<struct USceneComponent*> CallFunc_GetChildrenComponents_Children;  // 0xE8(0x10)
	struct USceneComponent* CallFunc_Array_Get_Item_2;  // 0xF8(0x8)
	struct UMeshComponent* CallFunc_Array_Get_Item_3;  // 0x100(0x8)
	struct UMeshComponent* K2Node_DynamicCast_AsMesh_Component;  // 0x108(0x8)
	char pad_272_1 : 7;  // 0x110(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x110(0x1)
	char pad_273[3];  // 0x111(0x3)
	int32_t CallFunc_Array_AddUnique_ReturnValue;  // 0x114(0x4)
	struct TArray<struct UMaterialInterface*> CallFunc_GetMaterials_ReturnValue;  // 0x118(0x10)
	struct UMaterialInterface* CallFunc_Array_Get_Item_4;  // 0x128(0x8)
	int32_t CallFunc_Array_Length_ReturnValue_2;  // 0x130(0x4)
	char pad_308[4];  // 0x134(0x4)
	struct UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue_2;  // 0x138(0x8)
	char pad_320_1 : 7;  // 0x140(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_2 : 1;  // 0x140(0x1)
	char pad_321[3];  // 0x141(0x3)
	int32_t CallFunc_Array_AddUnique_ReturnValue_2;  // 0x144(0x4)
	int32_t CallFunc_Array_Length_ReturnValue_3;  // 0x148(0x4)
	int32_t CallFunc_Array_Length_ReturnValue_4;  // 0x14C(0x4)
	char pad_336_1 : 7;  // 0x150(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_3 : 1;  // 0x150(0x1)
	char pad_337_1 : 7;  // 0x151(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_4 : 1;  // 0x151(0x1)
	char pad_338[6];  // 0x152(0x6)
	struct UMeshComponent* CallFunc_Array_Get_Item_5;  // 0x158(0x8)
	int32_t CallFunc_Array_Length_ReturnValue_5;  // 0x160(0x4)
	char pad_356_1 : 7;  // 0x164(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_5 : 1;  // 0x164(0x1)
	char pad_357[3];  // 0x165(0x3)
	int32_t CallFunc_Array_LastIndex_ReturnValue;  // 0x168(0x4)
	char pad_364[4];  // 0x16C(0x4)
	struct UPartyComponent* CallFunc_GetPartyComponent_ReturnValue;  // 0x170(0x8)
	char pad_376_1 : 7;  // 0x178(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue : 1;  // 0x178(0x1)
	char pad_377[3];  // 0x179(0x3)
	float CallFunc_GetClosestPartyMemberDistanceSquared_ReturnValue;  // 0x17C(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_2;  // 0x180(0x4)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_2;  // 0x184(0xC)
	float CallFunc_Multiply_FloatFloat_ReturnValue_3;  // 0x190(0x4)
	struct FVector CallFunc_Subtract_VectorVector_ReturnValue;  // 0x194(0xC)
	struct FVector CallFunc_Add_VectorVector_ReturnValue;  // 0x1A0(0xC)
	struct FHitResult CallFunc_LineTraceSingleForObjects_OutHit;  // 0x1AC(0x88)
	char pad_564_1 : 7;  // 0x234(0x1)
	bool CallFunc_LineTraceSingleForObjects_ReturnValue : 1;  // 0x234(0x1)
	char pad_565_1 : 7;  // 0x235(0x1)
	bool CallFunc_BreakHitResult_bBlockingHit : 1;  // 0x235(0x1)
	char pad_566_1 : 7;  // 0x236(0x1)
	bool CallFunc_BreakHitResult_bInitialOverlap : 1;  // 0x236(0x1)
	char pad_567[1];  // 0x237(0x1)
	float CallFunc_BreakHitResult_Time;  // 0x238(0x4)
	float CallFunc_BreakHitResult_Distance;  // 0x23C(0x4)
	struct FVector CallFunc_BreakHitResult_Location;  // 0x240(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactPoint;  // 0x24C(0xC)
	struct FVector CallFunc_BreakHitResult_Normal;  // 0x258(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactNormal;  // 0x264(0xC)
	struct UPhysicalMaterial* CallFunc_BreakHitResult_PhysMat;  // 0x270(0x8)
	struct AActor* CallFunc_BreakHitResult_HitActor;  // 0x278(0x8)
	struct UPrimitiveComponent* CallFunc_BreakHitResult_HitComponent;  // 0x280(0x8)
	struct FName CallFunc_BreakHitResult_HitBoneName;  // 0x288(0x8)
	int32_t CallFunc_BreakHitResult_HitItem;  // 0x290(0x4)
	int32_t CallFunc_BreakHitResult_ElementIndex;  // 0x294(0x4)
	int32_t CallFunc_BreakHitResult_FaceIndex;  // 0x298(0x4)
	struct FVector CallFunc_BreakHitResult_TraceStart;  // 0x29C(0xC)
	struct FVector CallFunc_BreakHitResult_TraceEnd;  // 0x2A8(0xC)
	char pad_692_1 : 7;  // 0x2B4(0x1)
	bool CallFunc_LessEqual_FloatFloat_ReturnValue : 1;  // 0x2B4(0x1)
	char pad_693[3];  // 0x2B5(0x3)
	struct FRotator CallFunc_Conv_VectorToRotator_ReturnValue;  // 0x2B8(0xC)
	float CallFunc_BreakRotator_Roll;  // 0x2C4(0x4)
	float CallFunc_BreakRotator_Pitch;  // 0x2C8(0x4)
	float CallFunc_BreakRotator_Yaw;  // 0x2CC(0x4)
	struct FRotator CallFunc_MakeRotFromZ_ReturnValue;  // 0x2D0(0xC)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0x2DC(0x4)
	struct UParticleSystemComponent* CallFunc_SpawnEmitterAtLocation_ReturnValue;  // 0x2E0(0x8)
	float CallFunc_Add_FloatFloat_ReturnValue_2;  // 0x2E8(0x4)
	struct FRotator CallFunc_MakeRotator_ReturnValue;  // 0x2EC(0xC)
	struct UDecalComponent* CallFunc_SpawnDecalAtLocation_ReturnValue;  // 0x2F8(0x8)
	float CallFunc_Multiply_FloatFloat_ReturnValue_4;  // 0x300(0x4)
	char pad_772_1 : 7;  // 0x304(0x1)
	bool CallFunc_LessEqual_FloatFloat_ReturnValue_2 : 1;  // 0x304(0x1)
	char pad_773[3];  // 0x305(0x3)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_3;  // 0x308(0xC)
	char pad_788_1 : 7;  // 0x314(0x1)
	bool CallFunc_LessEqual_FloatFloat_ReturnValue_3 : 1;  // 0x314(0x1)

}; 
// Function BP_InfectedHazeAmbientExplosion.BP_InfectedHazeAmbientExplosion_C.BndEvt__SM_Weevil02_Gib_02_K2Node_ComponentBoundEvent_2_ComponentSleepSignature__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FBndEvt__SM_Weevil02_Gib_02_K2Node_ComponentBoundEvent_2_ComponentSleepSignature__DelegateSignature
{
	struct UPrimitiveComponent* SleepingComponent;  // 0x0(0x8)
	struct FName BoneName;  // 0x8(0x8)

}; 
// Function BP_InfectedHazeAmbientExplosion.BP_InfectedHazeAmbientExplosion_C.BndEvt__SM_Weevil02_Gib_06_K2Node_ComponentBoundEvent_6_ComponentSleepSignature__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FBndEvt__SM_Weevil02_Gib_06_K2Node_ComponentBoundEvent_6_ComponentSleepSignature__DelegateSignature
{
	struct UPrimitiveComponent* SleepingComponent;  // 0x0(0x8)
	struct FName BoneName;  // 0x8(0x8)

}; 
// Function BP_InfectedHazeAmbientExplosion.BP_InfectedHazeAmbientExplosion_C.BndEvt__SM_Weevil02_Gib_05_K2Node_ComponentBoundEvent_5_ComponentSleepSignature__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FBndEvt__SM_Weevil02_Gib_05_K2Node_ComponentBoundEvent_5_ComponentSleepSignature__DelegateSignature
{
	struct UPrimitiveComponent* SleepingComponent;  // 0x0(0x8)
	struct FName BoneName;  // 0x8(0x8)

}; 
// Function BP_InfectedHazeAmbientExplosion.BP_InfectedHazeAmbientExplosion_C.BndEvt__SM_Weevil02_Gib_03_K2Node_ComponentBoundEvent_1_ComponentSleepSignature__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FBndEvt__SM_Weevil02_Gib_03_K2Node_ComponentBoundEvent_1_ComponentSleepSignature__DelegateSignature
{
	struct UPrimitiveComponent* SleepingComponent;  // 0x0(0x8)
	struct FName BoneName;  // 0x8(0x8)

}; 
// Function BP_InfectedHazeAmbientExplosion.BP_InfectedHazeAmbientExplosion_C.BndEvt__SM_Weevil02_Gib_01_K2Node_ComponentBoundEvent_3_ComponentSleepSignature__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FBndEvt__SM_Weevil02_Gib_01_K2Node_ComponentBoundEvent_3_ComponentSleepSignature__DelegateSignature
{
	struct UPrimitiveComponent* SleepingComponent;  // 0x0(0x8)
	struct FName BoneName;  // 0x8(0x8)

}; 
// Function BP_InfectedHazeAmbientExplosion.BP_InfectedHazeAmbientExplosion_C.BndEvt__SM_Weevil02_Gib_04_K2Node_ComponentBoundEvent_4_ComponentSleepSignature__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FBndEvt__SM_Weevil02_Gib_04_K2Node_ComponentBoundEvent_4_ComponentSleepSignature__DelegateSignature
{
	struct UPrimitiveComponent* SleepingComponent;  // 0x0(0x8)
	struct FName BoneName;  // 0x8(0x8)

}; 
