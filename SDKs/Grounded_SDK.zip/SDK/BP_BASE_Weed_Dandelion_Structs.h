#pragma once 
#include "SDK.h" 
 
 
// Function BP_BASE_Weed_Dandelion.BP_BASE_Weed_Dandelion_C.ExecuteUbergraph_BP_BASE_Weed_Dandelion
// Size: 0x4(Inherited: 0x0) 
struct FExecuteUbergraph_BP_BASE_Weed_Dandelion
{
	int32_t EntryPoint;  // 0x0(0x4)

}; 
