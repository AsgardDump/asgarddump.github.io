#pragma once 
#include <BP_FreshChoppingDamage_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_FreshChoppingDamage.BP_FreshChoppingDamage_C
// Size: 0x78(Inherited: 0x78) 
struct UBP_FreshChoppingDamage_C : public UBP_FreshDamage_C
{

}; 



