#pragma once 
#include "SDK.h" 
 
 
// Function BP_PondLab_Biodome_Terminal.BP_PondLab_Biodome_Terminal_C.ExecuteUbergraph_BP_PondLab_Biodome_Terminal
// Size: 0xC4(Inherited: 0x0) 
struct FExecuteUbergraph_BP_PondLab_Biodome_Terminal
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool K2Node_Event_IsOpen : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct AActor* K2Node_Event_ActorInstigator;  // 0x8(0x8)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x10(0x4)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool CallFunc_IsEnabled_ReturnValue : 1;  // 0x14(0x1)
	char pad_21[3];  // 0x15(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct UTextureRenderTarget2D* CallFunc_GetRenderTarget_ReturnValue;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue;  // 0x30(0x8)
	struct UUserWidget* CallFunc_GetUserWidgetObject_ReturnValue;  // 0x38(0x8)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)
	struct UUI_PondDomeTerminal_C* K2Node_DynamicCast_AsUI_Pond_Dome_Terminal;  // 0x48(0x8)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x50(0x1)
	char pad_81_1 : 7;  // 0x51(0x1)
	bool CallFunc_IsValid_ReturnValue_3 : 1;  // 0x51(0x1)
	char pad_82[2];  // 0x52(0x2)
	int32_t Temp_int_Array_Index_Variable;  // 0x54(0x4)
	struct UUMGSequencePlayer* CallFunc_PlayAnimation_ReturnValue;  // 0x58(0x8)
	struct UUMGSequencePlayer* CallFunc_PlayAnimation_ReturnValue_2;  // 0x60(0x8)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0x68(0x1)
	char pad_105[3];  // 0x69(0x3)
	float K2Node_Event_DeltaSeconds;  // 0x6C(0x4)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool CallFunc_WasRecentlyRendered_ReturnValue : 1;  // 0x70(0x1)
	char pad_113_1 : 7;  // 0x71(0x1)
	bool K2Node_ComponentBoundEvent_bIsActive_2 : 1;  // 0x71(0x1)
	char pad_114_1 : 7;  // 0x72(0x1)
	bool K2Node_ComponentBoundEvent_bIsActive : 1;  // 0x72(0x1)
	char pad_115_1 : 7;  // 0x73(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x73(0x1)
	char pad_116_1 : 7;  // 0x74(0x1)
	bool CallFunc_IsEnabled_ReturnValue_2 : 1;  // 0x74(0x1)
	char pad_117_1 : 7;  // 0x75(0x1)
	bool CallFunc_IsEnabled_ReturnValue_3 : 1;  // 0x75(0x1)
	char pad_118_1 : 7;  // 0x76(0x1)
	bool CallFunc_NotEqual_IntInt_ReturnValue : 1;  // 0x76(0x1)
	char pad_119_1 : 7;  // 0x77(0x1)
	bool CallFunc_NotEqual_IntInt_ReturnValue_2 : 1;  // 0x77(0x1)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x78(0x4)
	char pad_124[4];  // 0x7C(0x4)
	struct TSoftObjectPtr<ABP_Lab_Hatch_Pond_C> CallFunc_Array_Get_Item;  // 0x80(0x28)
	char pad_168_1 : 7;  // 0xA8(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_2 : 1;  // 0xA8(0x1)
	char pad_169[7];  // 0xA9(0x7)
	struct UObject* CallFunc_Conv_SoftObjectReferenceToObject_ReturnValue;  // 0xB0(0x8)
	struct ABP_Lab_Hatch_Pond_C* K2Node_DynamicCast_AsBP_Lab_Hatch_Pond;  // 0xB8(0x8)
	char pad_192_1 : 7;  // 0xC0(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0xC0(0x1)
	char pad_193_1 : 7;  // 0xC1(0x1)
	bool CallFunc_IsValidSoftObjectReference_ReturnValue : 1;  // 0xC1(0x1)
	char pad_194_1 : 7;  // 0xC2(0x1)
	bool CallFunc_IsValid_ReturnValue_4 : 1;  // 0xC2(0x1)
	char pad_195_1 : 7;  // 0xC3(0x1)
	bool CallFunc_IsOpen_ReturnValue : 1;  // 0xC3(0x1)

}; 
// Function BP_PondLab_Biodome_Terminal.BP_PondLab_Biodome_Terminal_C.ReceiveTick
// Size: 0x4(Inherited: 0x4) 
struct FReceiveTick : public FReceiveTick
{
	float DeltaSeconds;  // 0x0(0x4)

}; 
// Function BP_PondLab_Biodome_Terminal.BP_PondLab_Biodome_Terminal_C.BndEvt__ConditionalToggle_Vis_UnlockScreen_K2Node_ComponentBoundEvent_1_OnConditionalStateChanged__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FBndEvt__ConditionalToggle_Vis_UnlockScreen_K2Node_ComponentBoundEvent_1_OnConditionalStateChanged__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bIsActive : 1;  // 0x0(0x1)

}; 
// Function BP_PondLab_Biodome_Terminal.BP_PondLab_Biodome_Terminal_C.GetInteractionText
// Size: 0x41(Inherited: 0x20) 
struct FGetInteractionText : public FGetInteractionText
{
	uint8_t  Channel;  // 0x0(0x1)
	struct AActor* InstigatedBy;  // 0x8(0x8)
	struct FString OutText;  // 0x10(0x10)
	struct FString CallFunc_GetLocStringText_ReturnValue;  // 0x20(0x10)
	struct FString CallFunc_GetLocStringText_ReturnValue_2;  // 0x30(0x10)
	char pad_89_1 : 7;  // 0x59(0x1)
	bool CallFunc_IsEnabled_ReturnValue : 1;  // 0x40(0x1)

}; 
// Function BP_PondLab_Biodome_Terminal.BP_PondLab_Biodome_Terminal_C.IsInteractionEnabled
// Size: 0x15(Inherited: 0x18) 
struct FIsInteractionEnabled : public FIsInteractionEnabled
{
	uint8_t  Channel;  // 0x0(0x1)
	struct AActor* InstigatedBy;  // 0x8(0x8)
	char EInteractionState ReturnValue;  // 0x10(0x1)
	char EInteractionState CallFunc_IsInteractionEnabled_ReturnValue;  // 0x11(0x1)
	char pad_35_1 : 7;  // 0x23(0x1)
	bool CallFunc_IsEnabled_ReturnValue : 1;  // 0x12(0x1)
	char pad_36_1 : 7;  // 0x24(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x13(0x1)
	char pad_37_1 : 7;  // 0x25(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x14(0x1)

}; 
// Function BP_PondLab_Biodome_Terminal.BP_PondLab_Biodome_Terminal_C.BndEvt__ConditionalToggle_Vis_LoginScreen_K2Node_ComponentBoundEvent_0_OnConditionalStateChanged__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FBndEvt__ConditionalToggle_Vis_LoginScreen_K2Node_ComponentBoundEvent_0_OnConditionalStateChanged__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bIsActive : 1;  // 0x0(0x1)

}; 
// Function BP_PondLab_Biodome_Terminal.BP_PondLab_Biodome_Terminal_C.OnOpenStateChanged
// Size: 0x10(Inherited: 0x10) 
struct FOnOpenStateChanged : public FOnOpenStateChanged
{
	char pad_16_1 : 7;  // 0x10(0x1)
	bool IsOpen : 1;  // 0x0(0x1)
	struct AActor* ActorInstigator;  // 0x8(0x8)

}; 
// Function BP_PondLab_Biodome_Terminal.BP_PondLab_Biodome_Terminal_C.PartyHasAllPasswordPieces
// Size: 0x37(Inherited: 0x0) 
struct FPartyHasAllPasswordPieces
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool PartyHasAllPasswordPieces : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool PartyMissingPasswordPiece : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool Temp_bool_True_if_break_was_hit_Variable : 1;  // 0x2(0x1)
	char pad_3[1];  // 0x3(0x1)
	int32_t Temp_int_Array_Index_Variable;  // 0x4(0x4)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	int32_t Temp_int_Loop_Counter_Variable;  // 0xC(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x10(0x4)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_2 : 1;  // 0x14(0x1)
	char pad_21[3];  // 0x15(0x3)
	struct UPartyComponent* CallFunc_GetPartyComponent_ReturnValue;  // 0x18(0x8)
	struct FDataTableRowHandle CallFunc_Array_Get_Item;  // 0x20(0x10)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x30(0x4)
	char pad_52_1 : 7;  // 0x34(0x1)
	bool CallFunc_HasKeyItem_ReturnValue : 1;  // 0x34(0x1)
	char pad_53_1 : 7;  // 0x35(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x35(0x1)
	char pad_54_1 : 7;  // 0x36(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x36(0x1)

}; 
