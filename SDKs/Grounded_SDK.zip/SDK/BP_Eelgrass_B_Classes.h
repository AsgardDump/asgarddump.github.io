#pragma once 
#include <BP_Eelgrass_B_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Eelgrass_B.BP_Eelgrass_B_C
// Size: 0x4E8(Inherited: 0x4D0) 
struct ABP_Eelgrass_B_C : public ABP_BASE_Eelgrass_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x4D0(0x8)
	struct USceneComponent* SpawnA;  // 0x4D8(0x8)
	struct USceneComponent* SpawnD;  // 0x4E0(0x8)

	void ReceiveBeginPlay(); // Function BP_Eelgrass_B.BP_Eelgrass_B_C.ReceiveBeginPlay
	void ExecuteUbergraph_BP_Eelgrass_B(int32_t EntryPoint); // Function BP_Eelgrass_B.BP_Eelgrass_B_C.ExecuteUbergraph_BP_Eelgrass_B
}; 



