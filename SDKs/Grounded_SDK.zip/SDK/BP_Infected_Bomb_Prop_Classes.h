#pragma once 
#include <BP_Infected_Bomb_Prop_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Infected_Bomb_Prop.BP_Infected_Bomb_Prop_C
// Size: 0x240(Inherited: 0x230) 
struct ABP_Infected_Bomb_Prop_C : public AActor
{
	struct UStaticMeshComponent* StaticMesh;  // 0x230(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x238(0x8)

}; 



