#pragma once 
#include <BP_Plant_Small_Leafy_A_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Plant_Small_Leafy_A.BP_Plant_Small_Leafy_A_C
// Size: 0x4A8(Inherited: 0x4A8) 
struct ABP_Plant_Small_Leafy_A_C : public ABP_WorldItem_C
{

}; 



