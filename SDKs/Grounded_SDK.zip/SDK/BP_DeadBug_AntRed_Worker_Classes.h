#pragma once 
#include <BP_DeadBug_AntRed_Worker_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_DeadBug_AntRed_Worker.BP_DeadBug_AntRed_Worker_C
// Size: 0x4A8(Inherited: 0x4A8) 
struct ABP_DeadBug_AntRed_Worker_C : public ABP_WorldItem_C
{

}; 



