#pragma once 
#include "SDK.h" 
 
 
// Function BP_EquippedItem.BP_EquippedItem_C.ExecuteUbergraph_BP_EquippedItem
// Size: 0x68(Inherited: 0x0) 
struct FExecuteUbergraph_BP_EquippedItem
{
	int32_t EntryPoint;  // 0x0(0x4)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x4(0x10)
	int32_t Temp_int_Array_Index_Variable;  // 0x14(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct TArray<struct UMaterialInterface*> CallFunc_GetMaterials_ReturnValue;  // 0x20(0x10)
	struct UMaterialInterface* CallFunc_Array_Get_Item;  // 0x30(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x38(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x3C(0x4)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)
	struct UItem* CallFunc_GetItem_ReturnValue;  // 0x48(0x8)
	struct UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue;  // 0x50(0x8)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x58(0x1)
	char pad_89_1 : 7;  // 0x59(0x1)
	bool CallFunc_GetIsPowerOn_ReturnValue : 1;  // 0x59(0x1)
	char pad_90_1 : 7;  // 0x5A(0x1)
	bool CallFunc_UsesPower_ReturnValue : 1;  // 0x5A(0x1)
	char pad_91_1 : 7;  // 0x5B(0x1)
	bool K2Node_CustomEvent_PowerState : 1;  // 0x5B(0x1)
	char pad_92[4];  // 0x5C(0x4)
	struct UItem* CallFunc_GetItem_ReturnValue_2;  // 0x60(0x8)

}; 
// Function BP_EquippedItem.BP_EquippedItem_C.PowerStateChanged
// Size: 0x1(Inherited: 0x0) 
struct FPowerStateChanged
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool PowerState : 1;  // 0x0(0x1)

}; 
// Function BP_EquippedItem.BP_EquippedItem_C.ValidateItemData
// Size: 0x11(Inherited: 0x18) 
struct FValidateItemData : public FValidateItemData
{
	struct TArray<struct FText> ValidationErrors;  // 0x0(0x10)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)

}; 
// Function BP_EquippedItem.BP_EquippedItem_C.IsInteractionEnabled
// Size: 0x11(Inherited: 0x18) 
struct FIsInteractionEnabled : public FIsInteractionEnabled
{
	uint8_t  Channel;  // 0x0(0x1)
	struct AActor* InstigatedBy;  // 0x8(0x8)
	char EInteractionState ReturnValue;  // 0x10(0x1)

}; 
