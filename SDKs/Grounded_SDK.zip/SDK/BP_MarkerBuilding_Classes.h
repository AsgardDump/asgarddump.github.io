#pragma once 
#include <BP_MarkerBuilding_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_MarkerBuilding.BP_MarkerBuilding_C
// Size: 0x690(Inherited: 0x670) 
struct ABP_MarkerBuilding_C : public AMarkerBuilding
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x670(0x8)
	struct UMaineStaticMeshComponent* Building;  // 0x678(0x8)
	struct FLocString SetCustomMarkerText;  // 0x680(0x10)

	struct FText GetUseText(uint8_t  Channel, struct AActor* InstigatedBy); // Function BP_MarkerBuilding.BP_MarkerBuilding_C.GetUseText
	void ProcessLoadData(); // Function BP_MarkerBuilding.BP_MarkerBuilding_C.ProcessLoadData
	void ExecuteUbergraph_BP_MarkerBuilding(int32_t EntryPoint); // Function BP_MarkerBuilding.BP_MarkerBuilding_C.ExecuteUbergraph_BP_MarkerBuilding
}; 



