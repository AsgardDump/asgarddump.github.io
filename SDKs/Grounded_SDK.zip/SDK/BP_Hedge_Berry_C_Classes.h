#pragma once 
#include <BP_Hedge_Berry_C_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Hedge_Berry_C.BP_Hedge_Berry_C_C
// Size: 0x450(Inherited: 0x430) 
struct ABP_Hedge_Berry_C_C : public ABP_BASE_Hedge_Berry_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x430(0x8)
	struct USceneComponent* SpawnPoint2;  // 0x438(0x8)
	struct USceneComponent* SpawnPoint1;  // 0x440(0x8)
	struct UStaticMeshComponent* Berry2;  // 0x448(0x8)

	void ReceiveBeginPlay(); // Function BP_Hedge_Berry_C.BP_Hedge_Berry_C_C.ReceiveBeginPlay
	void ExecuteUbergraph_BP_Hedge_Berry_C(int32_t EntryPoint); // Function BP_Hedge_Berry_C.BP_Hedge_Berry_C_C.ExecuteUbergraph_BP_Hedge_Berry_C
}; 



