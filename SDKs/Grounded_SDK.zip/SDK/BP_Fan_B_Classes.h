#pragma once 
#include <BP_Fan_B_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Fan_B.BP_Fan_B_C
// Size: 0x328(Inherited: 0x230) 
struct ABP_Fan_B_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x230(0x8)
	struct UAudioComponent* SFX_Fan_Bubbles;  // 0x238(0x8)
	struct UObsidianIDComponent* ObsidianId;  // 0x240(0x8)
	struct UPersistenceComponent* Persistence;  // 0x248(0x8)
	struct UAudioComponent* SFX_Fan;  // 0x250(0x8)
	struct UBoxComponent* Box;  // 0x258(0x8)
	struct UParticleSystemComponent* ParticleSystem;  // 0x260(0x8)
	struct UStaticMeshComponent* SM_Fan_A_Base;  // 0x268(0x8)
	struct USceneComponent* Root;  // 0x270(0x8)
	struct UStaticMeshComponent* SM_Fan_A_Blades;  // 0x278(0x8)
	float Timeline___SFX_Automation_Frequency_DCDB41964F80A7E5D36A33ABE2031828;  // 0x280(0x4)
	float Timeline___SFX_Automation_Pitch_DCDB41964F80A7E5D36A33ABE2031828;  // 0x284(0x4)
	char ETimelineDirection Timeline___SFX_Automation__Direction_DCDB41964F80A7E5D36A33ABE2031828;  // 0x288(0x1)
	char pad_649[7];  // 0x289(0x7)
	struct UTimelineComponent* Timeline - SFX Automation;  // 0x290(0x8)
	float Fan_Rotation_NewTrack_0_892B378940B754C5447B1E9119DFDED1;  // 0x298(0x4)
	char ETimelineDirection Fan_Rotation__Direction_892B378940B754C5447B1E9119DFDED1;  // 0x29C(0x1)
	char pad_669[3];  // 0x29D(0x3)
	struct UTimelineComponent* Fan_Rotation;  // 0x2A0(0x8)
	int32_t ForceScalar;  // 0x2A8(0x4)
	char pad_684_1 : 7;  // 0x2AC(0x1)
	bool IsForceInverted : 1;  // 0x2AC(0x1)
	char pad_685_1 : 7;  // 0x2AD(0x1)
	bool IsOn : 1;  // 0x2AD(0x1)
	char pad_686[2];  // 0x2AE(0x2)
	float ForceVolumeExtent;  // 0x2B0(0x4)
	char pad_692_1 : 7;  // 0x2B4(0x1)
	bool DoesStateLoop : 1;  // 0x2B4(0x1)
	char pad_693[3];  // 0x2B5(0x3)
	float OnSecondsLoop;  // 0x2B8(0x4)
	float OffSecondsLoop;  // 0x2BC(0x4)
	float ForceVolumeWidthX;  // 0x2C0(0x4)
	float ForceVolumeWidthY;  // 0x2C4(0x4)
	struct TMap<struct UAudioComponent*, struct ASurvivalPlayerCharacter*> ActiveAudioMap;  // 0x2C8(0x50)
	char pad_792_1 : 7;  // 0x318(0x1)
	bool IsPausedForOptimization : 1;  // 0x318(0x1)
	char pad_793[3];  // 0x319(0x3)
	float MinForceScalarRatio;  // 0x31C(0x4)
	struct USoundBase* PushSound;  // 0x320(0x8)

	void UpdateFanState(); // Function BP_Fan_B.BP_Fan_B_C.UpdateFanState
	void StopSound(); // Function BP_Fan_B.BP_Fan_B_C.StopSound
	void OnRep_IsOn(); // Function BP_Fan_B.BP_Fan_B_C.OnRep_IsOn
	void UserConstructionScript(); // Function BP_Fan_B.BP_Fan_B_C.UserConstructionScript
	void Fan_Rotation__FinishedFunc(); // Function BP_Fan_B.BP_Fan_B_C.Fan_Rotation__FinishedFunc
	void Fan_Rotation__UpdateFunc(); // Function BP_Fan_B.BP_Fan_B_C.Fan_Rotation__UpdateFunc
	void Timeline - SFX Automation__FinishedFunc(); // Function BP_Fan_B.BP_Fan_B_C.Timeline - SFX Automation__FinishedFunc
	void Timeline - SFX Automation__UpdateFunc(); // Function BP_Fan_B.BP_Fan_B_C.Timeline - SFX Automation__UpdateFunc
	void ReceiveBeginPlay(); // Function BP_Fan_B.BP_Fan_B_C.ReceiveBeginPlay
	void ReceiveTick(float DeltaSeconds); // Function BP_Fan_B.BP_Fan_B_C.ReceiveTick
	void BndEvt__Box_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult& SweepResult); // Function BP_Fan_B.BP_Fan_B_C.BndEvt__Box_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature
	void MulticastAddForce(struct UCharacterMovementComponent* CharMovementTarget, struct FVector NewForce); // Function BP_Fan_B.BP_Fan_B_C.MulticastAddForce
	void StopFan(); // Function BP_Fan_B.BP_Fan_B_C.StopFan
	void StartFan(); // Function BP_Fan_B.BP_Fan_B_C.StartFan
	void TimerFanOn(); // Function BP_Fan_B.BP_Fan_B_C.TimerFanOn
	void BndEvt__Box_K2Node_ComponentBoundEvent_1_ComponentEndOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex); // Function BP_Fan_B.BP_Fan_B_C.BndEvt__Box_K2Node_ComponentBoundEvent_1_ComponentEndOverlapSignature__DelegateSignature
	void PauseFanForOptimization(); // Function BP_Fan_B.BP_Fan_B_C.PauseFanForOptimization
	void UnpauseFanForOptimization(); // Function BP_Fan_B.BP_Fan_B_C.UnpauseFanForOptimization
	void SetFanState(bool NewFanState); // Function BP_Fan_B.BP_Fan_B_C.SetFanState
	void ToggleFanVisuals(bool NewFanVisualState); // Function BP_Fan_B.BP_Fan_B_C.ToggleFanVisuals
	void TimerFanOff(); // Function BP_Fan_B.BP_Fan_B_C.TimerFanOff
	void ExecuteUbergraph_BP_Fan_B(int32_t EntryPoint); // Function BP_Fan_B.BP_Fan_B_C.ExecuteUbergraph_BP_Fan_B
}; 



