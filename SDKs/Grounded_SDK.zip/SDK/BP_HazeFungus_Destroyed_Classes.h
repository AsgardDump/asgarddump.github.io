#pragma once 
#include <BP_HazeFungus_Destroyed_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_HazeFungus_Destroyed.BP_HazeFungus_Destroyed_C
// Size: 0x279(Inherited: 0x279) 
struct ABP_HazeFungus_Destroyed_C : public ABP_BugDeath_Particle_C
{

}; 



