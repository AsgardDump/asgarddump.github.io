#pragma once 
#include <BP_Control_Panel_Standing_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Control_Panel_Standing.BP_Control_Panel_Standing_C
// Size: 0x358(Inherited: 0x308) 
struct ABP_Control_Panel_Standing_C : public ABP_Button_Switch_Base_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x308(0x8)
	struct UStaticMeshComponent* Plane;  // 0x310(0x8)
	struct UPointLightComponent* PointLight;  // 0x318(0x8)
	struct UStaticMeshComponent* SM_Lab_Control_Panel_Standing_Light_Strip;  // 0x320(0x8)
	struct UStaticMeshComponent* SM_Lab_Control_Panel_Standing_B;  // 0x328(0x8)
	struct UStaticMeshComponent* SM_Lab_Control_Panel_Standing_A;  // 0x330(0x8)
	char pad_824_1 : 7;  // 0x338(0x1)
	bool hasLightStrip : 1;  // 0x338(0x1)
	char pad_825[3];  // 0x339(0x3)
	int32_t panelStyle;  // 0x33C(0x4)
	struct UMaterialInterface* StandMaterial;  // 0x340(0x8)
	struct UMaterialInterface* LightStripMaterial;  // 0x348(0x8)
	struct UMaterialInterface* EmissiveMaterial;  // 0x350(0x8)

	void UserConstructionScript(); // Function BP_Control_Panel_Standing.BP_Control_Panel_Standing_C.UserConstructionScript
	void ReceiveBeginPlay(); // Function BP_Control_Panel_Standing.BP_Control_Panel_Standing_C.ReceiveBeginPlay
	void ImplementableOnLightTimelineFinished(char ETimelineDirection TimelineDirection); // Function BP_Control_Panel_Standing.BP_Control_Panel_Standing_C.ImplementableOnLightTimelineFinished
	void ExecuteUbergraph_BP_Control_Panel_Standing(int32_t EntryPoint); // Function BP_Control_Panel_Standing.BP_Control_Panel_Standing_C.ExecuteUbergraph_BP_Control_Panel_Standing
}; 



