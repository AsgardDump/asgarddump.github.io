#pragma once 
#include <BP_FreshDamage_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_FreshDamage.BP_FreshDamage_C
// Size: 0x78(Inherited: 0x78) 
struct UBP_FreshDamage_C : public USurvivalDamageType
{

}; 



