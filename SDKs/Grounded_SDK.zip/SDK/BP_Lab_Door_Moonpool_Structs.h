#pragma once 
#include "SDK.h" 
 
 
// Function BP_Lab_Door_Moonpool.BP_Lab_Door_Moonpool_C.ExecuteUbergraph_BP_Lab_Door_Moonpool
// Size: 0x390(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Lab_Door_Moonpool
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct FVector CallFunc_MakeVector_ReturnValue;  // 0x8(0xC)
	struct FVector CallFunc_MakeVector_ReturnValue_2;  // 0x14(0xC)
	struct FHitResult CallFunc_K2_SetRelativeLocation_SweepHitResult;  // 0x20(0x88)
	struct FHitResult CallFunc_K2_SetRelativeLocation_SweepHitResult_2;  // 0xA8(0x88)
	struct FVector CallFunc_MakeVector_ReturnValue_3;  // 0x130(0xC)
	struct FVector CallFunc_MakeVector_ReturnValue_4;  // 0x13C(0xC)
	struct FHitResult CallFunc_K2_SetRelativeLocation_SweepHitResult_3;  // 0x148(0x88)
	struct FHitResult CallFunc_K2_SetRelativeLocation_SweepHitResult_4;  // 0x1D0(0x88)
	struct FVector CallFunc_MakeVector_ReturnValue_5;  // 0x258(0xC)
	struct FVector CallFunc_MakeVector_ReturnValue_6;  // 0x264(0xC)
	struct FHitResult CallFunc_K2_SetRelativeLocation_SweepHitResult_5;  // 0x270(0x88)
	struct FHitResult CallFunc_K2_SetRelativeLocation_SweepHitResult_6;  // 0x2F8(0x88)
	struct UAudioComponent* CallFunc_SpawnSoundAttached_ReturnValue;  // 0x380(0x8)
	struct UAudioComponent* CallFunc_SpawnSoundAttached_ReturnValue_2;  // 0x388(0x8)

}; 
