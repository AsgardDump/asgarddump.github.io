#pragma once 
#include <BP_DroppedScience_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_DroppedScience.BP_DroppedScience_C
// Size: 0x2C8(Inherited: 0x2A8) 
struct ABP_DroppedScience_C : public AScienceCollectable
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x2A8(0x8)
	struct UPointLightComponent* CenterLight;  // 0x2B0(0x8)
	struct UAudioComponent* ScienceEmitter;  // 0x2B8(0x8)
	struct UStaticMeshComponent* StaticMesh;  // 0x2C0(0x8)

	void ReceiveBeginPlay(); // Function BP_DroppedScience.BP_DroppedScience_C.ReceiveBeginPlay
	void CustomEvent_1(struct ASurvivalPlayerCharacter* Character); // Function BP_DroppedScience.BP_DroppedScience_C.CustomEvent_1
	void ExecuteUbergraph_BP_DroppedScience(int32_t EntryPoint); // Function BP_DroppedScience.BP_DroppedScience_C.ExecuteUbergraph_BP_DroppedScience
}; 



