#pragma once 
#include <BP_Grass_Stems_Burned_D_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Grass_Stems_Burned_D.BP_Grass_Stems_Burned_D_C
// Size: 0x408(Inherited: 0x408) 
struct ABP_Grass_Stems_Burned_D_C : public ABP_BASE_GrassBlade_Burned_C
{

}; 



