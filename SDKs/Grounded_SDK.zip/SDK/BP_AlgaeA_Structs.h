#pragma once 
#include "SDK.h" 
 
 
// Function BP_AlgaeA.BP_AlgaeA_C.ExecuteUbergraph_BP_AlgaeA
// Size: 0x4(Inherited: 0x0) 
struct FExecuteUbergraph_BP_AlgaeA
{
	int32_t EntryPoint;  // 0x0(0x4)

}; 
