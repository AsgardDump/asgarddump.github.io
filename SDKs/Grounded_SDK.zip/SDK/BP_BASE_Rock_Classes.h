#pragma once 
#include <BP_BASE_Rock_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_BASE_Rock.BP_BASE_Rock_C
// Size: 0x390(Inherited: 0x368) 
struct ABP_BASE_Rock_C : public ABP_StaticHarvestNode_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x368(0x8)
	struct USceneComponent* SpawnA;  // 0x370(0x8)
	struct USceneComponent* SpawnD;  // 0x378(0x8)
	struct USceneComponent* SpawnC;  // 0x380(0x8)
	struct USceneComponent* SpawnB;  // 0x388(0x8)

	void ReceiveBeginPlay(); // Function BP_BASE_Rock.BP_BASE_Rock_C.ReceiveBeginPlay
	void ExecuteUbergraph_BP_BASE_Rock(int32_t EntryPoint); // Function BP_BASE_Rock.BP_BASE_Rock_C.ExecuteUbergraph_BP_BASE_Rock
}; 



