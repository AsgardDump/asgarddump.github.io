#pragma once 
#include <BP_QuestManagerComponent_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_QuestManagerComponent.BP_QuestManagerComponent_C
// Size: 0x3B0(Inherited: 0xB0) 
struct UBP_QuestManagerComponent_C : public UActorComponent
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0xB0(0x8)
	struct TArray<struct FName> CampingRecipes;  // 0xB8(0x10)
	struct FDataTableRowHandle DewDrop;  // 0xC8(0x10)
	struct FDataTableRowHandle Mushroom;  // 0xD8(0x10)
	struct FDataTableRowHandle Axe;  // 0xE8(0x10)
	struct FDataTableRowHandle AxeRecipe;  // 0xF8(0x10)
	struct TArray<struct FName> BaseRecipes;  // 0x108(0x10)
	struct FDataTableRowHandle Marker;  // 0x118(0x10)
	struct FDataTableRowHandle Campfire;  // 0x128(0x10)
	struct FDataTableRowHandle LeanTo;  // 0x138(0x10)
	struct FDataTableRowHandle Spear;  // 0x148(0x10)
	struct FDataTableRowHandle CookedAphidMeat;  // 0x158(0x10)
	struct FDataTableRowHandle Wall;  // 0x168(0x10)
	struct FDataTableRowHandle SpikeBarricade;  // 0x178(0x10)
	struct FDataTableRowHandle Workbench;  // 0x188(0x10)
	struct TArray<struct FName> BasicArmorRecipes;  // 0x198(0x10)
	struct FDataTableRowHandle CloverTop;  // 0x1A8(0x10)
	struct FDataTableRowHandle CloverHeadRecipe;  // 0x1B8(0x10)
	struct FDataTableRowHandle CloverChestRecipe;  // 0x1C8(0x10)
	struct FDataTableRowHandle CloverLegsRecipe;  // 0x1D8(0x10)
	struct FDataTableRowHandle FoodQuest;  // 0x1E8(0x10)
	struct FDataTableRowHandle WaterQuest;  // 0x1F8(0x10)
	struct FDataTableRowHandle RespawnPointQuest;  // 0x208(0x10)
	struct FDataTableRowHandle SleepQuest;  // 0x218(0x10)
	struct FDataTableRowHandle AxeRecipeQuest;  // 0x228(0x10)
	struct FDataTableRowHandle AxeCraftQuest;  // 0x238(0x10)
	struct FDataTableRowHandle WorkbenchQuest;  // 0x248(0x10)
	struct FDataTableRowHandle ArmorCraftQuest;  // 0x258(0x10)
	struct FDataTableRowHandle ArmorRecipeQuest;  // 0x268(0x10)
	struct UDataTable* EquipmentRecipeDataTable;  // 0x278(0x8)
	struct FDataTableRowHandle BandageRecipe;  // 0x280(0x10)
	struct FDataTableRowHandle BandageQuest;  // 0x290(0x10)
	struct FDataTableRowHandle BandageEfficientRecipe;  // 0x2A0(0x10)
	struct FDataTableRowHandle PersonalMilkNugQuest;  // 0x2B0(0x10)
	struct FDataTableRowHandle PeepQuest;  // 0x2C0(0x10)
	struct FDataTableRowHandle Torch;  // 0x2D0(0x10)
	struct FDataTableRowHandle TorchRecipe;  // 0x2E0(0x10)
	struct FDataTableRowHandle CraftTorchQuest;  // 0x2F0(0x10)
	struct FDataTableRowHandle BuildingTutorial;  // 0x300(0x10)
	struct FDataTableRowHandle MapRespawnPointTurtorial;  // 0x310(0x10)
	struct FDataTableRowHandle TrailMarkerTutorial;  // 0x320(0x10)
	struct FDataTableRowHandle MapRespawnPointTurtorialGamepad;  // 0x330(0x10)
	struct FDataTableRowHandle AnalyzerReminderTutorial;  // 0x340(0x10)
	struct FDataTableRowHandle TorchPlus;  // 0x350(0x10)
	struct FDataTableRowHandle TorchPlusRecipe;  // 0x360(0x10)
	struct FDataTableRowHandle SmithingStationRecipeUnlock;  // 0x370(0x10)
	struct FDataTableRowHandle WeevilShieldRecipe;  // 0x380(0x10)
	struct FDataTableRowHandle WeevilShield;  // 0x390(0x10)
	struct FDataTableRowHandle ShieldQuest;  // 0x3A0(0x10)

	void VerifyTutorialQuestCompletion(); // Function BP_QuestManagerComponent.BP_QuestManagerComponent_C.VerifyTutorialQuestCompletion
	void StartArmorCraftTutorial(struct ASurvivalPlayerCharacter* PlayerCharacter); // Function BP_QuestManagerComponent.BP_QuestManagerComponent_C.StartArmorCraftTutorial
	void HandleStartArmorCraftTutorial(struct ASurvivalPlayerCharacter* PlayerCharacter); // Function BP_QuestManagerComponent.BP_QuestManagerComponent_C.HandleStartArmorCraftTutorial
	void StartAxeCraftTutorial(struct ASurvivalPlayerCharacter* PlayerCharacter); // Function BP_QuestManagerComponent.BP_QuestManagerComponent_C.StartAxeCraftTutorial
	void HandleStartAxeCraftTutorial(struct ASurvivalPlayerCharacter* PlayerCharacter); // Function BP_QuestManagerComponent.BP_QuestManagerComponent_C.HandleStartAxeCraftTutorial
	void StartRespawnTutorial(struct ASurvivalPlayerCharacter* PlayerCharacter); // Function BP_QuestManagerComponent.BP_QuestManagerComponent_C.StartRespawnTutorial
	void HandleStartRespawnTutorial(struct ABP_SurvivalPlayerCharacter_C* PlayerCharacter); // Function BP_QuestManagerComponent.BP_QuestManagerComponent_C.HandleStartRespawnTutorial
	void CheckBurgleQuests_Map(); // Function BP_QuestManagerComponent.BP_QuestManagerComponent_C.CheckBurgleQuests_Map
	void UpdateTimeBasedQuests(int32_t NewHour, int32_t NewDay); // Function BP_QuestManagerComponent.BP_QuestManagerComponent_C.UpdateTimeBasedQuests
	void GetPlayerStateFromComponent(struct UActorComponent* ActorComponent, struct ASurvivalPlayerState*& PlayerState); // Function BP_QuestManagerComponent.BP_QuestManagerComponent_C.GetPlayerStateFromComponent
	void GetPlayerStateFromActor(struct AActor* Actor, struct ASurvivalPlayerState*& PlayerState); // Function BP_QuestManagerComponent.BP_QuestManagerComponent_C.GetPlayerStateFromActor
	void CookingEvents(struct AItemProcessingBuilding* Campfire); // Function BP_QuestManagerComponent.BP_QuestManagerComponent_C.CookingEvents
	void OnFoodChanged(struct USurvivalComponent* Survival Component, float Old, float New); // Function BP_QuestManagerComponent.BP_QuestManagerComponent_C.OnFoodChanged
	void OnThirstChanged(struct USurvivalComponent* Survival Component, float Old, float New); // Function BP_QuestManagerComponent.BP_QuestManagerComponent_C.OnThirstChanged
	void HandleOnBuildingComplete(struct FDataTableRowHandle BuildingRowHandle); // Function BP_QuestManagerComponent.BP_QuestManagerComponent_C.HandleOnBuildingComplete
	void HandleOnItemCrafted(struct UInventoryComponent* Sender, struct FDataTableRowHandle ItemHandle); // Function BP_QuestManagerComponent.BP_QuestManagerComponent_C.HandleOnItemCrafted
	void ResourceResearched(struct FDataTableRowHandle ItemRowHandle, struct ASurvivalPlayerState* AcquirerPlayerState, struct TArray<struct FDataTableRowHandle_NetCrc>& RecipesLearned); // Function BP_QuestManagerComponent.BP_QuestManagerComponent_C.ResourceResearched
	void Item Processed Callback(struct UItem* OldItem, struct UItem* NewItem); // Function BP_QuestManagerComponent.BP_QuestManagerComponent_C.Item Processed Callback
	void HandleHourChange(int32_t NewHour, int32_t NewDay); // Function BP_QuestManagerComponent.BP_QuestManagerComponent_C.HandleHourChange
	void HandleOnInteract(struct TScriptInterface<IInteractableInterface> Interactable, struct AActor* Instigator); // Function BP_QuestManagerComponent.BP_QuestManagerComponent_C.HandleOnInteract
	void HandleOnItemAdded(struct UInventoryComponent* InventoryComponentOwner, struct FDataTableRowHandle ItemHandle, bool IsNewItem, int32_t Count, int32_t TotalCount); // Function BP_QuestManagerComponent.BP_QuestManagerComponent_C.HandleOnItemAdded
	void BindPlayerEvents(struct ABP_SurvivalPlayerCharacter_C* SurvivalPlayer); // Function BP_QuestManagerComponent.BP_QuestManagerComponent_C.BindPlayerEvents
	void ReceiveBeginPlay(); // Function BP_QuestManagerComponent.BP_QuestManagerComponent_C.ReceiveBeginPlay
	void OnPlayerUseItem(struct ASurvivalCharacter* User, struct FDataTableRowHandle ItemData); // Function BP_QuestManagerComponent.BP_QuestManagerComponent_C.OnPlayerUseItem
	void HandleAxeTutorialOverallFlow(bool WithTimer, bool IgnoreProgressStage); // Function BP_QuestManagerComponent.BP_QuestManagerComponent_C.HandleAxeTutorialOverallFlow
	void HandleOnRest(float RestDuration); // Function BP_QuestManagerComponent.BP_QuestManagerComponent_C.HandleOnRest
	void HandleBenchAndArmorTutorialOverallFlow(); // Function BP_QuestManagerComponent.BP_QuestManagerComponent_C.HandleBenchAndArmorTutorialOverallFlow
	void HandleOnBurgleQuestStarted(struct UBurgleQuestInstance* Quest); // Function BP_QuestManagerComponent.BP_QuestManagerComponent_C.HandleOnBurgleQuestStarted
	void BindPlayerStateEvents(struct ASurvivalPlayerState* PlayerState); // Function BP_QuestManagerComponent.BP_QuestManagerComponent_C.BindPlayerStateEvents
	void RespawnPointChanged(struct ASurvivalPlayerState* PlayerState, struct AActor* RespawnPoint); // Function BP_QuestManagerComponent.BP_QuestManagerComponent_C.RespawnPointChanged
	void OnPlayerCombatStateChanged(struct ASurvivalCharacter* Character, bool bInCombat); // Function BP_QuestManagerComponent.BP_QuestManagerComponent_C.OnPlayerCombatStateChanged
	void OnUpgradePointsAquired(bool IsPartyUpgradePoints, int32_t Amount, struct ASurvivalPlayerState* AcquirerPlayerState); // Function BP_QuestManagerComponent.BP_QuestManagerComponent_C.OnUpgradePointsAquired
	void HandlePersonalMilkNugQuestStart(struct ASurvivalPlayerState* SurvivalPlayerState, float Delay); // Function BP_QuestManagerComponent.BP_QuestManagerComponent_C.HandlePersonalMilkNugQuestStart
	void OnCollectibleUpgradesChanged(struct UPlayerUpgradeComponent* PlayerUpgradeComponent); // Function BP_QuestManagerComponent.BP_QuestManagerComponent_C.OnCollectibleUpgradesChanged
	void OnPartyUpgradeSpent(struct FGameplayTag StackTag, struct ASurvivalPlayerState* AquirerPlayerState); // Function BP_QuestManagerComponent.BP_QuestManagerComponent_C.OnPartyUpgradeSpent
	void OnTechUnlockDataUnlockedDelegate(struct FDataTableRowHandle TechUnlockDataRowHandle, struct ASurvivalPlayerState* UnlockerPlayerState); // Function BP_QuestManagerComponent.BP_QuestManagerComponent_C.OnTechUnlockDataUnlockedDelegate
	void CP09_GiveQuestItem(struct UQuest* QuestData); // Function BP_QuestManagerComponent.BP_QuestManagerComponent_C.CP09_GiveQuestItem
	void CP08_GiveRecipes(struct UQuest* QuestData); // Function BP_QuestManagerComponent.BP_QuestManagerComponent_C.CP08_GiveRecipes
	void OnBestiaryEntryUnlocked(struct FDataTableRowHandle KeyItemRowHandle, struct ASurvivalPlayerState* AcquirerPlayerState); // Function BP_QuestManagerComponent.BP_QuestManagerComponent_C.OnBestiaryEntryUnlocked
	void OnRecipeKnown(struct FDataTableRowHandle RecipeRowHandle, struct ASurvivalPlayerState* AcquirerPlayerState); // Function BP_QuestManagerComponent.BP_QuestManagerComponent_C.OnRecipeKnown
	void ExecuteUbergraph_BP_QuestManagerComponent(int32_t EntryPoint); // Function BP_QuestManagerComponent.BP_QuestManagerComponent_C.ExecuteUbergraph_BP_QuestManagerComponent
}; 



