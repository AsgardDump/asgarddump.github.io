#pragma once 
#include "SDK.h" 
 
 
// Function BP_InsectPart.BP_InsectPart_C.ExecuteUbergraph_BP_InsectPart
// Size: 0x1A0(Inherited: 0x0) 
struct FExecuteUbergraph_BP_InsectPart
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	int32_t Temp_int_Array_Index_Variable;  // 0x8(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0xC(0x4)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x10(0x10)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x20(0x4)
	int32_t Temp_int_Loop_Counter_Variable_2;  // 0x24(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0x28(0x4)
	int32_t Temp_int_Array_Index_Variable_2;  // 0x2C(0x4)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_SleepingComponent;  // 0x30(0x8)
	struct FName K2Node_ComponentBoundEvent_BoneName;  // 0x38(0x8)
	struct TArray<struct UMaterialInterface*> CallFunc_GetMaterials_ReturnValue;  // 0x40(0x10)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x50(0x4)
	int32_t Temp_int_Array_Index_Variable_3;  // 0x54(0x4)
	struct UMaterialInterface* CallFunc_Array_Get_Item;  // 0x58(0x8)
	struct UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue;  // 0x60(0x8)
	int32_t CallFunc_Array_AddUnique_ReturnValue;  // 0x68(0x4)
	char pad_108[4];  // 0x6C(0x4)
	struct UMaterialInstanceDynamic* CallFunc_Array_Get_Item_2;  // 0x70(0x8)
	int32_t CallFunc_Array_Length_ReturnValue_2;  // 0x78(0x4)
	char pad_124_1 : 7;  // 0x7C(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x7C(0x1)
	char pad_125[3];  // 0x7D(0x3)
	struct TArray<struct UCableComponent*> CallFunc_K2_GetComponentsByClass_ReturnValue;  // 0x80(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x90(0x10)
	char pad_160_1 : 7;  // 0xA0(0x1)
	bool CallFunc_Array_IsValidIndex_ReturnValue : 1;  // 0xA0(0x1)
	char pad_161[7];  // 0xA1(0x7)
	struct UCableComponent* CallFunc_Array_Get_Item_3;  // 0xA8(0x8)
	int32_t CallFunc_Array_Length_ReturnValue_3;  // 0xB0(0x4)
	char pad_180_1 : 7;  // 0xB4(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_2 : 1;  // 0xB4(0x1)
	char pad_181[3];  // 0xB5(0x3)
	struct TArray<struct FName> CallFunc_GetAllSocketNames_ReturnValue;  // 0xB8(0x10)
	struct FName CallFunc_Array_Get_Item_4;  // 0xC8(0x8)
	struct UCableComponent* CallFunc_Array_Get_Item_5;  // 0xD0(0x8)
	char pad_216[8];  // 0xD8(0x8)
	struct FTransform CallFunc_GetSocketTransform_ReturnValue;  // 0xE0(0x30)
	struct UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue_2;  // 0x110(0x8)
	struct FVector CallFunc_BreakTransform_Location;  // 0x118(0xC)
	struct FRotator CallFunc_BreakTransform_Rotation;  // 0x124(0xC)
	struct FVector CallFunc_BreakTransform_Scale;  // 0x130(0xC)
	struct FVector CallFunc_K2_GetComponentScale_ReturnValue;  // 0x13C(0xC)
	struct UParticleSystemComponent* CallFunc_SpawnEmitterAtLocation_ReturnValue;  // 0x148(0x8)
	struct FTimerHandle CallFunc_K2_SetTimerDelegate_ReturnValue;  // 0x150(0x8)
	struct FTimerHandle CallFunc_K2_SetTimerDelegate_ReturnValue_2;  // 0x158(0x8)
	struct AActor* K2Node_Event_OtherActor_2;  // 0x160(0x8)
	struct AActor* K2Node_Event_OtherActor;  // 0x168(0x8)
	struct APhysicsVolume* K2Node_DynamicCast_AsPhysics_Volume;  // 0x170(0x8)
	char pad_376_1 : 7;  // 0x178(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x178(0x1)
	char pad_377[7];  // 0x179(0x7)
	struct APhysicsVolume* K2Node_DynamicCast_AsPhysics_Volume_2;  // 0x180(0x8)
	char pad_392_1 : 7;  // 0x188(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x188(0x1)
	char pad_393[3];  // 0x189(0x3)
	float K2Node_Event_DeltaSeconds;  // 0x18C(0x4)
	char pad_400_1 : 7;  // 0x190(0x1)
	bool CallFunc_IsOverlappingWaterVolume_ReturnValue : 1;  // 0x190(0x1)
	char pad_401[3];  // 0x191(0x3)
	int32_t Temp_int_Loop_Counter_Variable_3;  // 0x194(0x4)
	char pad_408_1 : 7;  // 0x198(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_3 : 1;  // 0x198(0x1)
	char pad_409[3];  // 0x199(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue_3;  // 0x19C(0x4)

}; 
// Function BP_InsectPart.BP_InsectPart_C.ReceiveTick
// Size: 0x4(Inherited: 0x4) 
struct FReceiveTick : public FReceiveTick
{
	float DeltaSeconds;  // 0x0(0x4)

}; 
// Function BP_InsectPart.BP_InsectPart_C.ReceiveActorEndOverlap
// Size: 0x8(Inherited: 0x8) 
struct FReceiveActorEndOverlap : public FReceiveActorEndOverlap
{
	struct AActor* OtherActor;  // 0x0(0x8)

}; 
// Function BP_InsectPart.BP_InsectPart_C.ReceiveActorBeginOverlap
// Size: 0x8(Inherited: 0x8) 
struct FReceiveActorBeginOverlap : public FReceiveActorBeginOverlap
{
	struct AActor* OtherActor;  // 0x0(0x8)

}; 
// Function BP_InsectPart.BP_InsectPart_C.BndEvt__InsectPartMesh_K2Node_ComponentBoundEvent_0_ComponentSleepSignature__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FBndEvt__InsectPartMesh_K2Node_ComponentBoundEvent_0_ComponentSleepSignature__DelegateSignature
{
	struct UPrimitiveComponent* SleepingComponent;  // 0x0(0x8)
	struct FName BoneName;  // 0x8(0x8)

}; 
