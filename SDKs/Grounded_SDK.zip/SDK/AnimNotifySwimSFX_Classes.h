#pragma once 
#include <AnimNotifySwimSFX_Structs.h>
 
 
 
// BlueprintGeneratedClass AnimNotifySwimSFX.AnimNotifySwimSFX_C
// Size: 0x40(Inherited: 0x38) 
struct UAnimNotifySwimSFX_C : public UAnimNotify
{
	struct USoundBase* WaterAboveBelowSFX;  // 0x38(0x8)

	bool Received_Notify(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation); // Function AnimNotifySwimSFX.AnimNotifySwimSFX_C.Received_Notify
}; 



