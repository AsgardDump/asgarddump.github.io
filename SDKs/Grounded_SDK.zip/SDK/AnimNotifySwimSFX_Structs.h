#pragma once 
#include "SDK.h" 
 
 
// Function AnimNotifySwimSFX.AnimNotifySwimSFX_C.Received_Notify
// Size: 0x41(Inherited: 0x18) 
struct FReceived_Notify : public FReceived_Notify
{
	struct USkeletalMeshComponent* MeshComp;  // 0x0(0x8)
	struct UAnimSequenceBase* Animation;  // 0x8(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0x18(0x8)
	struct ABP_SurvivalPlayerCharacter_C* K2Node_DynamicCast_AsBP_Survival_Player_Character;  // 0x20(0x8)
	char pad_57_1 : 7;  // 0x39(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x28(0x1)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x2C(0xC)
	struct UAudioComponent* CallFunc_SpawnSoundAttached_ReturnValue;  // 0x38(0x8)
	char pad_78_1 : 7;  // 0x4E(0x1)
	bool CallFunc_IsUnderwater_ReturnValue : 1;  // 0x40(0x1)

}; 
