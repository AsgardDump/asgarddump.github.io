#pragma once 
#include <BP_Clover_A_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Clover_A.BP_Clover_A_C
// Size: 0x430(Inherited: 0x420) 
struct ABP_Clover_A_C : public ABP_ToppleHarvestNode_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x420(0x8)
	struct UStaticMeshComponent* NewVar_0_1;  // 0x428(0x8)

	void ReceiveBeginPlay(); // Function BP_Clover_A.BP_Clover_A_C.ReceiveBeginPlay
	void ExecuteUbergraph_BP_Clover_A(int32_t EntryPoint); // Function BP_Clover_A.BP_Clover_A_C.ExecuteUbergraph_BP_Clover_A
}; 



