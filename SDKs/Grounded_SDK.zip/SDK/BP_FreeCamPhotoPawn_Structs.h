#pragma once 
#include "SDK.h" 
 
 
// Function BP_FreeCamPhotoPawn.BP_FreeCamPhotoPawn_C.ExecuteUbergraph_BP_FreeCamPhotoPawn
// Size: 0x88(Inherited: 0x0) 
struct FExecuteUbergraph_BP_FreeCamPhotoPawn
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UWidgetManager* CallFunc_GetWidgetManager_ReturnValue;  // 0x8(0x8)
	struct UWindowWidget* CallFunc_GetActiveWindowOfType_ReturnValue;  // 0x10(0x8)
	struct UWidgetManager* CallFunc_GetWidgetManager_ReturnValue_2;  // 0x18(0x8)
	struct UPhotoModeHUD* K2Node_DynamicCast_AsPhoto_Mode_HUD;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct UWindowWidget* CallFunc_GetActiveWindowOfType_ReturnValue_2;  // 0x30(0x8)
	struct UPhotoModeHUD* K2Node_DynamicCast_AsPhoto_Mode_HUD_2;  // 0x38(0x8)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x40(0x1)
	char pad_65_1 : 7;  // 0x41(0x1)
	bool CallFunc_AreSettingsOpen_ReturnValue : 1;  // 0x41(0x1)
	char pad_66[6];  // 0x42(0x6)
	struct UPhotoModeSubsystem* CallFunc_GetGameInstanceSubsystem_ReturnValue;  // 0x48(0x8)
	struct APlayerController* CallFunc_GetActivatingPlayerController_ReturnValue;  // 0x50(0x8)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool CallFunc_ExitPhotoMode_ReturnValue : 1;  // 0x58(0x1)
	uint8_t  CallFunc_GetGamePlatform_ReturnValue;  // 0x59(0x1)
	char pad_90_1 : 7;  // 0x5A(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x5A(0x1)
	char pad_91[5];  // 0x5B(0x5)
	struct UWidgetManager* CallFunc_GetWidgetManager_ReturnValue_3;  // 0x60(0x8)
	struct UWindowWidget* CallFunc_GetActiveWindowOfType_ReturnValue_3;  // 0x68(0x8)
	struct UPhotoModeHUD* K2Node_DynamicCast_AsPhoto_Mode_HUD_3;  // 0x70(0x8)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x78(0x1)
	char pad_121[7];  // 0x79(0x7)
	struct APhotoPawn* CallFunc_ChangePhotoPawnType_ReturnValue;  // 0x80(0x8)

}; 
