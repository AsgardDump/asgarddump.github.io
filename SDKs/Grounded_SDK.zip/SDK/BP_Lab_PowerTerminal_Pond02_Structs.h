#pragma once 
#include "SDK.h" 
 
 
// Function BP_Lab_PowerTerminal_Pond02.BP_Lab_PowerTerminal_Pond02_C.ExecuteUbergraph_BP_Lab_PowerTerminal_Pond02
// Size: 0x48(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Lab_PowerTerminal_Pond02
{
	int32_t EntryPoint;  // 0x0(0x4)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x4(0xC)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool K2Node_Event_IsOpen : 1;  // 0x11(0x1)
	char pad_18[6];  // 0x12(0x6)
	struct AActor* K2Node_Event_ActorInstigator;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_IsEnabled_ReturnValue : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct UUMGSequencePlayer* CallFunc_PlayAnimation_ReturnValue;  // 0x28(0x8)
	struct UUMGSequencePlayer* CallFunc_PlayAnimation_ReturnValue_2;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool K2Node_ComponentBoundEvent_bIsActive_3 : 1;  // 0x38(0x1)
	char pad_57_1 : 7;  // 0x39(0x1)
	bool K2Node_ComponentBoundEvent_bIsActive_2 : 1;  // 0x39(0x1)
	char pad_58_1 : 7;  // 0x3A(0x1)
	bool CallFunc_HasAuthority_ReturnValue_2 : 1;  // 0x3A(0x1)
	char pad_59_1 : 7;  // 0x3B(0x1)
	bool K2Node_ComponentBoundEvent_bIsActive : 1;  // 0x3B(0x1)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_2;  // 0x3C(0xC)

}; 
// Function BP_Lab_PowerTerminal_Pond02.BP_Lab_PowerTerminal_Pond02_C.BndEvt__ConditionalToggle_HousePower_K2Node_ComponentBoundEvent_2_OnConditionalStateChanged__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FBndEvt__ConditionalToggle_HousePower_K2Node_ComponentBoundEvent_2_OnConditionalStateChanged__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bIsActive : 1;  // 0x0(0x1)

}; 
// Function BP_Lab_PowerTerminal_Pond02.BP_Lab_PowerTerminal_Pond02_C.BndEvt__ConditionalToggle_BreakersNeedReset_K2Node_ComponentBoundEvent_1_OnConditionalStateChanged__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FBndEvt__ConditionalToggle_BreakersNeedReset_K2Node_ComponentBoundEvent_1_OnConditionalStateChanged__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bIsActive : 1;  // 0x0(0x1)

}; 
// Function BP_Lab_PowerTerminal_Pond02.BP_Lab_PowerTerminal_Pond02_C.RedrawScreen
// Size: 0x9(Inherited: 0x7) 
struct FRedrawScreen : public FRedrawScreen
{
	char pad_7_1 : 7;  // 0x7(0x1)
	bool CallFunc_IsEnabled_ReturnValue : 1;  // 0x0(0x1)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CallFunc_NotEqual_IntInt_ReturnValue : 1;  // 0x1(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool CallFunc_IsEnabled_ReturnValue_2 : 1;  // 0x2(0x1)
	char pad_10_1 : 7;  // 0xA(0x1)
	bool CallFunc_IsEnabled_ReturnValue_3 : 1;  // 0x3(0x1)
	char pad_11_1 : 7;  // 0xB(0x1)
	bool CallFunc_IsEnabled_ReturnValue_4 : 1;  // 0x4(0x1)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool CallFunc_NotEqual_IntInt_ReturnValue_2 : 1;  // 0x5(0x1)
	char pad_13_1 : 7;  // 0xD(0x1)
	bool CallFunc_NotEqual_IntInt_ReturnValue_3 : 1;  // 0x6(0x1)
	char pad_14_1 : 7;  // 0xE(0x1)
	bool CallFunc_NotEqual_IntInt_ReturnValue_4 : 1;  // 0x7(0x1)
	char pad_15_1 : 7;  // 0xF(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x8(0x1)

}; 
// Function BP_Lab_PowerTerminal_Pond02.BP_Lab_PowerTerminal_Pond02_C.BndEvt__ConditionalToggle_BreakersReset_K2Node_ComponentBoundEvent_0_OnConditionalStateChanged__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FBndEvt__ConditionalToggle_BreakersReset_K2Node_ComponentBoundEvent_0_OnConditionalStateChanged__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bIsActive : 1;  // 0x0(0x1)

}; 
// Function BP_Lab_PowerTerminal_Pond02.BP_Lab_PowerTerminal_Pond02_C.OnOpenStateChanged
// Size: 0x10(Inherited: 0x10) 
struct FOnOpenStateChanged : public FOnOpenStateChanged
{
	char pad_16_1 : 7;  // 0x10(0x1)
	bool IsOpen : 1;  // 0x0(0x1)
	struct AActor* ActorInstigator;  // 0x8(0x8)

}; 
