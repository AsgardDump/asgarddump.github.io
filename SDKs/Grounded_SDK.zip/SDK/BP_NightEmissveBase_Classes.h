#pragma once 
#include <BP_NightEmissveBase_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_NightEmissveBase.BP_NightEmissveBase_C
// Size: 0x338(Inherited: 0x230) 
struct ABP_NightEmissveBase_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x230(0x8)
	struct USceneComponent* Root;  // 0x238(0x8)
	float TL_GardenLamp_OnOff_LightCurve_567D743F47CF9C1CEB34A19B7DA54431;  // 0x240(0x4)
	char ETimelineDirection TL_GardenLamp_OnOff__Direction_567D743F47CF9C1CEB34A19B7DA54431;  // 0x244(0x1)
	char pad_581[3];  // 0x245(0x3)
	struct UTimelineComponent* TL_GardenLamp_OnOff;  // 0x248(0x8)
	struct ABP_SurvivalGameState_C* GameState;  // 0x250(0x8)
	struct TArray<struct UMaterialInstanceDynamic*> EmissiveMIDs;  // 0x258(0x10)
	struct TArray<struct UMaterialInstanceDynamic*> LightConeMIDs;  // 0x268(0x10)
	float LightAttenuationRadius;  // 0x278(0x4)
	float LightIntensity;  // 0x27C(0x4)
	float LightConeIntensity;  // 0x280(0x4)
	float GlowIntensity;  // 0x284(0x4)
	char pad_648_1 : 7;  // 0x288(0x1)
	bool LightToggle : 1;  // 0x288(0x1)
	char pad_649_1 : 7;  // 0x289(0x1)
	bool LightSwitch : 1;  // 0x289(0x1)
	char pad_650[2];  // 0x28A(0x2)
	int32_t TransitionHourA;  // 0x28C(0x4)
	int32_t TransitionHourB;  // 0x290(0x4)
	char pad_660[4];  // 0x294(0x4)
	struct TArray<struct UStaticMeshComponent*> DynamicMeshArray;  // 0x298(0x10)
	struct TArray<struct USpotLightComponent*> SpotlightArray;  // 0x2A8(0x10)
	struct TArray<struct UStaticMeshComponent*> LightConeArray;  // 0x2B8(0x10)
	struct FLinearColor GlowColor01;  // 0x2C8(0x10)
	struct FLinearColor GlowColor02;  // 0x2D8(0x10)
	float MinStaggerDelay;  // 0x2E8(0x4)
	float MaxStaggerDelay;  // 0x2EC(0x4)
	char pad_752_1 : 7;  // 0x2F0(0x1)
	bool HasSpotlight : 1;  // 0x2F0(0x1)
	char pad_753_1 : 7;  // 0x2F1(0x1)
	bool HasLightCone : 1;  // 0x2F1(0x1)
	char pad_754[6];  // 0x2F2(0x6)
	struct TArray<struct FVector> LightConeScales;  // 0x2F8(0x10)
	struct ABP_TimeOfDayLighting_C* TimeOfDayLighting;  // 0x308(0x8)
	struct TSoftObjectPtr<ABP_TimeOfDayLighting_C> TimeOfDayRef;  // 0x310(0x28)

	void SetPhotoModeTickDelegates(); // Function BP_NightEmissveBase.BP_NightEmissveBase_C.SetPhotoModeTickDelegates
	void Find Time Of Day Manager(); // Function BP_NightEmissveBase.BP_NightEmissveBase_C.Find Time Of Day Manager
	void InitializeLightToggle(); // Function BP_NightEmissveBase.BP_NightEmissveBase_C.InitializeLightToggle
	void Toggle Lamp Internal(float LightCurve); // Function BP_NightEmissveBase.BP_NightEmissveBase_C.Toggle Lamp Internal
	void RegisterLightCone(struct UStaticMeshComponent* StaticMeshComponent); // Function BP_NightEmissveBase.BP_NightEmissveBase_C.RegisterLightCone
	void RegisterSpotlight(struct USpotLightComponent* SpotLightComponent); // Function BP_NightEmissveBase.BP_NightEmissveBase_C.RegisterSpotlight
	void RegisterGlowMesh(struct UStaticMeshComponent* StaticMeshComponent); // Function BP_NightEmissveBase.BP_NightEmissveBase_C.RegisterGlowMesh
	void ToggleInEditMode(struct ABP_TimeOfDayLighting_C* TimeOfDay, bool LightSwitch); // Function BP_NightEmissveBase.BP_NightEmissveBase_C.ToggleInEditMode
	void UserConstructionScript(); // Function BP_NightEmissveBase.BP_NightEmissveBase_C.UserConstructionScript
	void TL_GardenLamp_OnOff__FinishedFunc(); // Function BP_NightEmissveBase.BP_NightEmissveBase_C.TL_GardenLamp_OnOff__FinishedFunc
	void TL_GardenLamp_OnOff__UpdateFunc(); // Function BP_NightEmissveBase.BP_NightEmissveBase_C.TL_GardenLamp_OnOff__UpdateFunc
	void ReceiveBeginPlay(); // Function BP_NightEmissveBase.BP_NightEmissveBase_C.ReceiveBeginPlay
	void Toggle_GardenLamp(int32_t NewHour, int32_t NewDay); // Function BP_NightEmissveBase.BP_NightEmissveBase_C.Toggle_GardenLamp
	void ReceiveTick(float DeltaSeconds); // Function BP_NightEmissveBase.BP_NightEmissveBase_C.ReceiveTick
	void OnPhotoModeExited(); // Function BP_NightEmissveBase.BP_NightEmissveBase_C.OnPhotoModeExited
	void UpdatePhotoModeTimeOfDay(); // Function BP_NightEmissveBase.BP_NightEmissveBase_C.UpdatePhotoModeTimeOfDay
	void PhotoModeEnterEnableTick(struct APhotoPawn* PhotoPawn); // Function BP_NightEmissveBase.BP_NightEmissveBase_C.PhotoModeEnterEnableTick
	void PhotoModeExitDisableTick(); // Function BP_NightEmissveBase.BP_NightEmissveBase_C.PhotoModeExitDisableTick
	void ReceiveEndPlay(char EEndPlayReason EndPlayReason); // Function BP_NightEmissveBase.BP_NightEmissveBase_C.ReceiveEndPlay
	void OnRestingTimelapseChange(bool Active); // Function BP_NightEmissveBase.BP_NightEmissveBase_C.OnRestingTimelapseChange
	void ExecuteUbergraph_BP_NightEmissveBase(int32_t EntryPoint); // Function BP_NightEmissveBase.BP_NightEmissveBase_C.ExecuteUbergraph_BP_NightEmissveBase
}; 



