#pragma once 
#include <BP_Hosta_Flower_B_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Hosta_Flower_B.BP_Hosta_Flower_B_C
// Size: 0x368(Inherited: 0x368) 
struct ABP_Hosta_Flower_B_C : public ABP_StaticHarvestNode_C
{

}; 



