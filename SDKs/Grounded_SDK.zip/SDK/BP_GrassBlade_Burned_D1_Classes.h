#pragma once 
#include <BP_GrassBlade_Burned_D1_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_GrassBlade_Burned_D1.BP_GrassBlade_Burned_D1_C
// Size: 0x408(Inherited: 0x408) 
struct ABP_GrassBlade_Burned_D1_C : public ABP_BASE_GrassBlade_Burned_C
{

}; 



