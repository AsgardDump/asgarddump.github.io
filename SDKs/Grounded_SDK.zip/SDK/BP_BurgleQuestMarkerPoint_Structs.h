#pragma once 
#include "SDK.h" 
 
 
// Function BP_BurgleQuestMarkerPoint.BP_BurgleQuestMarkerPoint_C.ExecuteUbergraph_BP_BurgleQuestMarkerPoint
// Size: 0x48(Inherited: 0x0) 
struct FExecuteUbergraph_BP_BurgleQuestMarkerPoint
{
	int32_t EntryPoint;  // 0x0(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x4(0x4)
	struct UBurgleQuestManagerComponent* CallFunc_GetBurgleQuestManager_ReturnValue;  // 0x8(0x8)
	struct TArray<struct UBurgleQuestInstance*> CallFunc_GetActiveQuests_ReturnValue;  // 0x10(0x10)
	struct UBurgleQuestInstance* CallFunc_Array_Get_Item;  // 0x20(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x28(0x4)
	char pad_44[4];  // 0x2C(0x4)
	struct UBurgleQuestInstanceMarkPoint* K2Node_DynamicCast_AsBurgle_Quest_Instance_Mark_Point;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x38(0x1)
	char pad_57_1 : 7;  // 0x39(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x39(0x1)
	char pad_58_1 : 7;  // 0x3A(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue : 1;  // 0x3A(0x1)
	char pad_59_1 : 7;  // 0x3B(0x1)
	bool CallFunc_IsUnderConstruction_ReturnValue : 1;  // 0x3B(0x1)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x3C(0x4)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x40(0x1)
	char pad_65[3];  // 0x41(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x44(0x4)

}; 
