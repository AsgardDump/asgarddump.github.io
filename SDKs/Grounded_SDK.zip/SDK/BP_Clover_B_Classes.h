#pragma once 
#include <BP_Clover_B_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Clover_B.BP_Clover_B_C
// Size: 0x430(Inherited: 0x430) 
struct ABP_Clover_B_C : public ABP_Clover_A_C
{

}; 



