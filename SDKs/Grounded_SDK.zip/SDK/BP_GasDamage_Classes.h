#pragma once 
#include <BP_GasDamage_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_GasDamage.BP_GasDamage_C
// Size: 0x78(Inherited: 0x78) 
struct UBP_GasDamage_C : public USurvivalDamageType
{

}; 



