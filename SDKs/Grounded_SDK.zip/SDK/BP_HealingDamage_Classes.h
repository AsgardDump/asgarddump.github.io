#pragma once 
#include <BP_HealingDamage_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_HealingDamage.BP_HealingDamage_C
// Size: 0x78(Inherited: 0x78) 
struct UBP_HealingDamage_C : public USurvivalDamageType
{

}; 



