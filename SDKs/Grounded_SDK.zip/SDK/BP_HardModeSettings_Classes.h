#pragma once 
#include <BP_HardModeSettings_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_HardModeSettings.BP_HardModeSettings_C
// Size: 0x78(Inherited: 0x78) 
struct UBP_HardModeSettings_C : public USurvivalGameModeSettings
{

}; 



