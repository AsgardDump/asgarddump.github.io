#pragma once 
#include <BP_AlgaeB_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_AlgaeB.BP_AlgaeB_C
// Size: 0x4B0(Inherited: 0x4A8) 
struct ABP_AlgaeB_C : public ABP_WorldItem_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x4A8(0x8)

	void ReceiveBeginPlay(); // Function BP_AlgaeB.BP_AlgaeB_C.ReceiveBeginPlay
	void ExecuteUbergraph_BP_AlgaeB(int32_t EntryPoint); // Function BP_AlgaeB.BP_AlgaeB_C.ExecuteUbergraph_BP_AlgaeB
}; 



