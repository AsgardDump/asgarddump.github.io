#pragma once 
#include <BP_AntAbdomen_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_AntAbdomen.BP_AntAbdomen_C
// Size: 0x2A3(Inherited: 0x2A3) 
struct ABP_AntAbdomen_C : public ABP_InsectPart_C
{

}; 



