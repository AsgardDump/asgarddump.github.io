#pragma once 
#include <BP_Duper_Screen_State_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Duper_Screen_State.BP_Duper_Screen_State_C
// Size: 0x30(Inherited: 0x30) 
struct UBP_Duper_Screen_State_C : public UAnimNotifyState
{

	bool Received_NotifyEnd(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation); // Function BP_Duper_Screen_State.BP_Duper_Screen_State_C.Received_NotifyEnd
	bool Received_NotifyBegin(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation, float TotalDuration); // Function BP_Duper_Screen_State.BP_Duper_Screen_State_C.Received_NotifyBegin
}; 



