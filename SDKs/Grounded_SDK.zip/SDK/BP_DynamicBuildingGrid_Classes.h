#pragma once 
#include <BP_DynamicBuildingGrid_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_DynamicBuildingGrid.BP_DynamicBuildingGrid_C
// Size: 0x250(Inherited: 0x230) 
struct ABP_DynamicBuildingGrid_C : public AActor
{
	struct UBuildingGridComponent* BuildingGrid;  // 0x230(0x8)
	struct USceneComponent* Root;  // 0x238(0x8)
	struct UPersistenceComponent* Persistence;  // 0x240(0x8)
	struct UObsidianIDComponent* ObsidianId;  // 0x248(0x8)

}; 



