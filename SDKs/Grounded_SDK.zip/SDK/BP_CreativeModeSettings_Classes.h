#pragma once 
#include <BP_CreativeModeSettings_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_CreativeModeSettings.BP_CreativeModeSettings_C
// Size: 0x78(Inherited: 0x78) 
struct UBP_CreativeModeSettings_C : public USurvivalGameModeSettings
{

}; 



