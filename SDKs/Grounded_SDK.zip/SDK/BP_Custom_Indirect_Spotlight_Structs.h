#pragma once 
#include "SDK.h" 
 
 
// Function BP_Custom_Indirect_Spotlight.BP_Custom_Indirect_Spotlight_C.Toggle Bake Mode
// Size: 0x7(Inherited: 0x0) 
struct FToggle Bake Mode
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Bake On : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool BakeOn : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool Temp_bool_Variable : 1;  // 0x2(0x1)
	char EComponentMobility Temp_byte_Variable;  // 0x3(0x1)
	char EComponentMobility Temp_byte_Variable_2;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x5(0x1)
	char EComponentMobility K2Node_Select_Default;  // 0x6(0x1)

}; 
// Function BP_Custom_Indirect_Spotlight.BP_Custom_Indirect_Spotlight_C.SetLightColorIntensity
// Size: 0x18(Inherited: 0x0) 
struct FSetLightColorIntensity
{
	float IntensityAlpha;  // 0x0(0x4)
	struct FLinearColor Color;  // 0x4(0x10)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x14(0x4)

}; 
