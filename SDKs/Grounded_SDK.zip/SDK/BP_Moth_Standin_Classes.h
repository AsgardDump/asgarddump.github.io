#pragma once 
#include <BP_Moth_Standin_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Moth_Standin.BP_Moth_Standin_C
// Size: 0x12C0(Inherited: 0x12C0) 
struct ABP_Moth_Standin_C : public AProxyCharacterStandInActor
{

}; 



