#pragma once 
#include "SDK.h" 
 
 
// Function BP_BASE_Stump.BP_BASE_Stump_C.CanRevertToFoliage
// Size: 0x1(Inherited: 0x1) 
struct FCanRevertToFoliage : public FCanRevertToFoliage
{
	uint8_t  ReturnValue;  // 0x0(0x1)

}; 
