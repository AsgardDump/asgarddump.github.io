#pragma once 
#include <BP_Mosquito_Tiger_StandIn_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Mosquito_Tiger_StandIn.BP_Mosquito_Tiger_StandIn_C
// Size: 0x12C0(Inherited: 0x12C0) 
struct ABP_Mosquito_Tiger_StandIn_C : public ABP_Mosquito_StandIn_C
{

}; 



