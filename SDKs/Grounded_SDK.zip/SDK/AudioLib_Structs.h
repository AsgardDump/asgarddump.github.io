#pragma once 
#include "SDK.h" 
 
 
// Function AudioLib.AudioLib_C.SequenceContainer2D
// Size: 0x40(Inherited: 0x0) 
struct FSequenceContainer2D
{
	struct TArray<struct USoundBase*> Sound List;  // 0x0(0x10)
	struct UObject* __WorldContext;  // 0x10(0x8)
	int32_t SoundIndex;  // 0x18(0x4)
	int32_t CallFunc_Array_LastIndex_ReturnValue;  // 0x1C(0x4)
	struct USoundBase* CallFunc_Array_Get_Item;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool CallFunc_GreaterEqual_IntInt_ReturnValue : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct UAudioComponent* CallFunc_SpawnSound2D_ReturnValue;  // 0x30(0x8)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x38(0x4)
	int32_t Temp_int_Variable;  // 0x3C(0x4)

}; 
// Function AudioLib.AudioLib_C.GetLocalListenerLocation
// Size: 0x34(Inherited: 0x0) 
struct FGetLocalListenerLocation
{
	struct UObject* __WorldContext;  // 0x0(0x8)
	struct FVector Location;  // 0x8(0xC)
	char pad_20[4];  // 0x14(0x4)
	struct ASurvivalPlayerCharacter* CallFunc_GetLocalSurvivalPlayerCharacter_ReturnValue;  // 0x18(0x8)
	struct APlayerCameraManager* CallFunc_GetPlayerCameraManager_ReturnValue;  // 0x20(0x8)
	struct FVector CallFunc_GetCameraLocation_ReturnValue;  // 0x28(0xC)

}; 
// Function AudioLib.AudioLib_C.MultiGetDistanceToPlayer
// Size: 0xA4(Inherited: 0x0) 
struct FMultiGetDistanceToPlayer
{
	struct TArray<struct AActor*> Target;  // 0x0(0x10)
	float Duration;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct UObject* __WorldContext;  // 0x18(0x8)
	struct ASurvivalPlayerCharacter* CallFunc_GetLocalSurvivalPlayerCharacter_ReturnValue;  // 0x20(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x28(0x4)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x2C(0xC)
	int32_t Temp_int_Array_Index_Variable;  // 0x38(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x3C(0x4)
	struct AActor* CallFunc_Array_Get_Item;  // 0x40(0x8)
	struct FString CallFunc_GetDisplayName_ReturnValue;  // 0x48(0x10)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_2;  // 0x58(0xC)
	char pad_100[4];  // 0x64(0x4)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0x68(0x10)
	float CallFunc_Vector_Distance_ReturnValue;  // 0x78(0x4)
	char pad_124_1 : 7;  // 0x7C(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x7C(0x1)
	char pad_125[3];  // 0x7D(0x3)
	struct FString CallFunc_Conv_FloatToString_ReturnValue;  // 0x80(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_2;  // 0x90(0x10)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0xA0(0x4)

}; 
// Function AudioLib.AudioLib_C.GetDistanceToPlayer
// Size: 0x80(Inherited: 0x0) 
struct FGetDistanceToPlayer
{
	struct AActor* Target;  // 0x0(0x8)
	float Duration;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct UObject* __WorldContext;  // 0x10(0x8)
	struct FString CallFunc_GetDisplayName_ReturnValue;  // 0x18(0x10)
	struct ASurvivalPlayerCharacter* CallFunc_GetLocalSurvivalPlayerCharacter_ReturnValue;  // 0x28(0x8)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0x30(0x10)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x40(0xC)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_2;  // 0x4C(0xC)
	float CallFunc_Vector_Distance_ReturnValue;  // 0x58(0x4)
	char pad_92[4];  // 0x5C(0x4)
	struct FString CallFunc_Conv_FloatToString_ReturnValue;  // 0x60(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_2;  // 0x70(0x10)

}; 
// Function AudioLib.AudioLib_C.GetRandomStartTime
// Size: 0x18(Inherited: 0x0) 
struct FGetRandomStartTime
{
	struct UAudioComponent* NewParam;  // 0x0(0x8)
	struct UObject* __WorldContext;  // 0x8(0x8)
	float ReturnValue;  // 0x10(0x4)
	float CallFunc_RandomFloatInRange_ReturnValue;  // 0x14(0x4)

}; 
