#pragma once 
#include "SDK.h" 
 
 
// Function BP_AntLeg_L_Front.BP_AntLeg_L_Front_C.ExecuteUbergraph_BP_AntLeg_L_Front
// Size: 0x8(Inherited: 0x0) 
struct FExecuteUbergraph_BP_AntLeg_L_Front
{
	int32_t EntryPoint;  // 0x0(0x4)
	float K2Node_Event_DeltaSeconds;  // 0x4(0x4)

}; 
// Function BP_AntLeg_L_Front.BP_AntLeg_L_Front_C.ReceiveTick
// Size: 0x4(Inherited: 0x4) 
struct FReceiveTick : public FReceiveTick
{
	float DeltaSeconds;  // 0x0(0x4)

}; 
