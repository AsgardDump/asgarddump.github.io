#pragma once 
#include <BP_BASE_Mushroom_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_BASE_Mushroom.BP_BASE_Mushroom_C
// Size: 0x469(Inherited: 0x420) 
struct ABP_BASE_Mushroom_C : public ABP_ToppleHarvestNode_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x420(0x8)
	struct UVisualStateComponent* VisualState;  // 0x428(0x8)
	struct USceneComponent* SpawnA;  // 0x430(0x8)
	struct USceneComponent* SpawnD;  // 0x438(0x8)
	struct USceneComponent* SpawnC;  // 0x440(0x8)
	struct USceneComponent* SpawnB;  // 0x448(0x8)
	float Timeline_0_0_NewTrack_0_B92FCFFC486EBF9FD3B0ABB55DF8E804;  // 0x450(0x4)
	char ETimelineDirection Timeline_0_0__Direction_B92FCFFC486EBF9FD3B0ABB55DF8E804;  // 0x454(0x1)
	char pad_1109[3];  // 0x455(0x3)
	struct UTimelineComponent* Timeline_0_1;  // 0x458(0x8)
	struct UMaterialInstanceDynamic* MushroomMID;  // 0x460(0x8)
	char pad_1128_1 : 7;  // 0x468(0x1)
	bool DissolveOnDestroy : 1;  // 0x468(0x1)

	void Timeline_0_0__FinishedFunc(); // Function BP_BASE_Mushroom.BP_BASE_Mushroom_C.Timeline_0_0__FinishedFunc
	void Timeline_0_0__UpdateFunc(); // Function BP_BASE_Mushroom.BP_BASE_Mushroom_C.Timeline_0_0__UpdateFunc
	void ReceiveBeginPlay(); // Function BP_BASE_Mushroom.BP_BASE_Mushroom_C.ReceiveBeginPlay
	void BndEvt__HealthComponent_K2Node_ComponentBoundEvent_0_OnHandleEffectsEvent__DelegateSignature(struct FVector HitLocation); // Function BP_BASE_Mushroom.BP_BASE_Mushroom_C.BndEvt__HealthComponent_K2Node_ComponentBoundEvent_0_OnHandleEffectsEvent__DelegateSignature
	void ExecuteUbergraph_BP_BASE_Mushroom(int32_t EntryPoint); // Function BP_BASE_Mushroom.BP_BASE_Mushroom_C.ExecuteUbergraph_BP_BASE_Mushroom
}; 



