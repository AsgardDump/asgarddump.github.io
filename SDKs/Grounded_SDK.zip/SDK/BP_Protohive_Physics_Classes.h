#pragma once 
#include <BP_Protohive_Physics_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Protohive_Physics.BP_Protohive_Physics_C
// Size: 0x349(Inherited: 0x349) 
struct ABP_Protohive_Physics_C : public ABP_PhysicsHarvestNode_C
{

}; 



