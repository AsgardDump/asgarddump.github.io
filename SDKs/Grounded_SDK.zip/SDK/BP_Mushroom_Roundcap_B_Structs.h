#pragma once 
#include "SDK.h" 
 
 
// Function BP_Mushroom_Roundcap_B.BP_Mushroom_Roundcap_B_C.ExecuteUbergraph_BP_Mushroom_Roundcap_B
// Size: 0x4(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Mushroom_Roundcap_B
{
	int32_t EntryPoint;  // 0x0(0x4)

}; 
