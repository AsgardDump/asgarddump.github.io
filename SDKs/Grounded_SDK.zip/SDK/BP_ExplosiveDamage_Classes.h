#pragma once 
#include <BP_ExplosiveDamage_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_ExplosiveDamage.BP_ExplosiveDamage_C
// Size: 0x78(Inherited: 0x78) 
struct UBP_ExplosiveDamage_C : public USurvivalDamageType
{

}; 



