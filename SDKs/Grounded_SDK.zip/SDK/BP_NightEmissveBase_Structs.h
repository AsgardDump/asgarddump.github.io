#pragma once 
#include "SDK.h" 
 
 
// Function BP_NightEmissveBase.BP_NightEmissveBase_C.ToggleInEditMode
// Size: 0xF4(Inherited: 0x0) 
struct FToggleInEditMode
{
	struct ABP_TimeOfDayLighting_C* TimeOfDay;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool LightSwitch : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool LightOn : 1;  // 0x9(0x1)
	char pad_10[2];  // 0xA(0x2)
	int32_t Temp_int_Array_Index_Variable;  // 0xC(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x10(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x14(0x4)
	int32_t Temp_int_Loop_Counter_Variable_2;  // 0x18(0x4)
	int32_t Temp_int_Loop_Counter_Variable_3;  // 0x1C(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0x20(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_3;  // 0x24(0x4)
	int32_t Temp_int_Array_Index_Variable_2;  // 0x28(0x4)
	int32_t Temp_int_Loop_Counter_Variable_4;  // 0x2C(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_4;  // 0x30(0x4)
	int32_t Temp_int_Array_Index_Variable_3;  // 0x34(0x4)
	struct UMaterialInstanceDynamic* CallFunc_Array_Get_Item;  // 0x38(0x8)
	float CallFunc_Conv_BoolToFloat_ReturnValue;  // 0x40(0x4)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x44(0x4)
	struct FLinearColor CallFunc_Multiply_LinearColorFloat_ReturnValue;  // 0x48(0x10)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x58(0x1)
	char pad_89[3];  // 0x59(0x3)
	struct FLinearColor CallFunc_Multiply_LinearColorFloat_ReturnValue_2;  // 0x5C(0x10)
	int32_t CallFunc_Array_Length_ReturnValue_2;  // 0x6C(0x4)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_2 : 1;  // 0x70(0x1)
	char pad_113[3];  // 0x71(0x3)
	float CallFunc_Conv_IntToFloat_ReturnValue;  // 0x74(0x4)
	float CallFunc_Conv_IntToFloat_ReturnValue_2;  // 0x78(0x4)
	char pad_124_1 : 7;  // 0x7C(0x1)
	bool CallFunc_Less_FloatFloat_ReturnValue : 1;  // 0x7C(0x1)
	char pad_125_1 : 7;  // 0x7D(0x1)
	bool CallFunc_Less_FloatFloat_ReturnValue_2 : 1;  // 0x7D(0x1)
	char pad_126[2];  // 0x7E(0x2)
	struct USpotLightComponent* CallFunc_Array_Get_Item_2;  // 0x80(0x8)
	int32_t CallFunc_Array_Length_ReturnValue_3;  // 0x88(0x4)
	char pad_140_1 : 7;  // 0x8C(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_3 : 1;  // 0x8C(0x1)
	char pad_141[3];  // 0x8D(0x3)
	struct UMaterialInstanceDynamic* CallFunc_Array_Get_Item_3;  // 0x90(0x8)
	int32_t CallFunc_Array_Length_ReturnValue_4;  // 0x98(0x4)
	char pad_156_1 : 7;  // 0x9C(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_4 : 1;  // 0x9C(0x1)
	char pad_157[3];  // 0x9D(0x3)
	float CallFunc_Conv_BoolToFloat_ReturnValue_2;  // 0xA0(0x4)
	struct FLinearColor CallFunc_Multiply_LinearColorFloat_ReturnValue_3;  // 0xA4(0x10)
	struct FLinearColor CallFunc_Multiply_LinearColorFloat_ReturnValue_4;  // 0xB4(0x10)
	float CallFunc_Conv_BoolToFloat_ReturnValue_3;  // 0xC4(0x4)
	int32_t Temp_int_Array_Index_Variable_4;  // 0xC8(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0xCC(0x4)
	struct UStaticMeshComponent* CallFunc_Array_Get_Item_4;  // 0xD0(0x8)
	struct FVector CallFunc_Array_Get_Item_5;  // 0xD8(0xC)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue;  // 0xE4(0xC)
	float CallFunc_Multiply_FloatFloat_ReturnValue_2;  // 0xF0(0x4)

}; 
// Function BP_NightEmissveBase.BP_NightEmissveBase_C.SetPhotoModeTickDelegates
// Size: 0x28(Inherited: 0x0) 
struct FSetPhotoModeTickDelegates
{
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x0(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x10(0x10)
	struct UPhotoModeSubsystem* CallFunc_GetGameInstanceSubsystem_ReturnValue;  // 0x20(0x8)

}; 
// Function BP_NightEmissveBase.BP_NightEmissveBase_C.Toggle_GardenLamp
// Size: 0x8(Inherited: 0x0) 
struct FToggle_GardenLamp
{
	int32_t NewHour;  // 0x0(0x4)
	int32_t NewDay;  // 0x4(0x4)

}; 
// Function BP_NightEmissveBase.BP_NightEmissveBase_C.ExecuteUbergraph_BP_NightEmissveBase
// Size: 0xAB(Inherited: 0x0) 
struct FExecuteUbergraph_BP_NightEmissveBase
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UObject* CallFunc_LoadAsset_Blocking_ReturnValue;  // 0x8(0x8)
	struct ABP_TimeOfDayLighting_C* K2Node_DynamicCast_AsBP_Time_Of_Day_Lighting;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x1C(0x10)
	char pad_44[4];  // 0x2C(0x4)
	struct UPhotoModeSubsystem* CallFunc_GetGameInstanceSubsystem_ReturnValue;  // 0x30(0x8)
	struct UPhotoModeSubsystem* CallFunc_GetGameInstanceSubsystem_ReturnValue_2;  // 0x38(0x8)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool CallFunc_IsInPhotoMode_ReturnValue : 1;  // 0x40(0x1)
	char pad_65[3];  // 0x41(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x44(0x10)
	char pad_84[4];  // 0x54(0x4)
	struct UPhotoModeSubsystem* CallFunc_GetGameInstanceSubsystem_ReturnValue_3;  // 0x58(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_3;  // 0x60(0x10)
	struct AGameStateBase* CallFunc_GetGameState_ReturnValue;  // 0x70(0x8)
	int32_t K2Node_CustomEvent_NewHour;  // 0x78(0x4)
	int32_t K2Node_CustomEvent_NewDay;  // 0x7C(0x4)
	struct ABP_SurvivalGameState_C* K2Node_DynamicCast_AsBP_Survival_Game_State;  // 0x80(0x8)
	char pad_136_1 : 7;  // 0x88(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x88(0x1)
	char pad_137_1 : 7;  // 0x89(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue : 1;  // 0x89(0x1)
	char pad_138_1 : 7;  // 0x8A(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x8A(0x1)
	char pad_139_1 : 7;  // 0x8B(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue : 1;  // 0x8B(0x1)
	float CallFunc_Conv_BoolToFloat_ReturnValue;  // 0x8C(0x4)
	char pad_144_1 : 7;  // 0x90(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_2 : 1;  // 0x90(0x1)
	char pad_145[3];  // 0x91(0x3)
	float K2Node_Event_DeltaSeconds;  // 0x94(0x4)
	float CallFunc_RandomFloatInRange_ReturnValue;  // 0x98(0x4)
	char pad_156[4];  // 0x9C(0x4)
	struct APhotoPawn* K2Node_CustomEvent_PhotoPawn;  // 0xA0(0x8)
	char EEndPlayReason K2Node_Event_EndPlayReason;  // 0xA8(0x1)
	char pad_169_1 : 7;  // 0xA9(0x1)
	bool K2Node_CustomEvent_Active : 1;  // 0xA9(0x1)
	char pad_170_1 : 7;  // 0xAA(0x1)
	bool CallFunc_BooleanOR_ReturnValue : 1;  // 0xAA(0x1)

}; 
// Function BP_NightEmissveBase.BP_NightEmissveBase_C.UserConstructionScript
// Size: 0xA4(Inherited: 0x0) 
struct FUserConstructionScript : public FUserConstructionScript
{
	struct ABP_TimeOfDayLighting_C* TimeOfDay;  // 0x0(0x8)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x8(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0xC(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x10(0x4)
	int32_t CallFunc_GetWorldType_ReturnValue;  // 0x14(0x4)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct UObject* CallFunc_LoadAsset_Blocking_ReturnValue;  // 0x20(0x8)
	struct ABP_TimeOfDayLighting_C* K2Node_DynamicCast_AsBP_Time_Of_Day_Lighting;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x30(0x1)
	char pad_49[3];  // 0x31(0x3)
	int32_t Temp_int_Loop_Counter_Variable_2;  // 0x34(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0x38(0x4)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x3C(0x4)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x40(0x1)
	char pad_65[3];  // 0x41(0x3)
	int32_t Temp_int_Array_Index_Variable_2;  // 0x44(0x4)
	struct UStaticMeshComponent* CallFunc_Array_Get_Item;  // 0x48(0x8)
	struct UMaterialInterface* CallFunc_GetMaterial_ReturnValue;  // 0x50(0x8)
	struct FVector CallFunc_K2_GetComponentScale_ReturnValue;  // 0x58(0xC)
	char pad_100[4];  // 0x64(0x4)
	struct UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue;  // 0x68(0x8)
	int32_t CallFunc_Array_AddUnique_ReturnValue;  // 0x70(0x4)
	char pad_116[4];  // 0x74(0x4)
	struct UStaticMeshComponent* CallFunc_Array_Get_Item_2;  // 0x78(0x8)
	int32_t CallFunc_GetMaterialIndex_ReturnValue;  // 0x80(0x4)
	int32_t CallFunc_Array_Length_ReturnValue_2;  // 0x84(0x4)
	struct UMaterialInterface* CallFunc_GetMaterial_ReturnValue_2;  // 0x88(0x8)
	char pad_144_1 : 7;  // 0x90(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_2 : 1;  // 0x90(0x1)
	char pad_145[7];  // 0x91(0x7)
	struct UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue_2;  // 0x98(0x8)
	int32_t CallFunc_Array_AddUnique_ReturnValue_2;  // 0xA0(0x4)

}; 
// Function BP_NightEmissveBase.BP_NightEmissveBase_C.PhotoModeEnterEnableTick
// Size: 0x8(Inherited: 0x0) 
struct FPhotoModeEnterEnableTick
{
	struct APhotoPawn* PhotoPawn;  // 0x0(0x8)

}; 
// Function BP_NightEmissveBase.BP_NightEmissveBase_C.OnRestingTimelapseChange
// Size: 0x1(Inherited: 0x0) 
struct FOnRestingTimelapseChange
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Active : 1;  // 0x0(0x1)

}; 
// Function BP_NightEmissveBase.BP_NightEmissveBase_C.ReceiveEndPlay
// Size: 0x1(Inherited: 0x1) 
struct FReceiveEndPlay : public FReceiveEndPlay
{
	char EEndPlayReason EndPlayReason;  // 0x0(0x1)

}; 
// Function BP_NightEmissveBase.BP_NightEmissveBase_C.ReceiveTick
// Size: 0x4(Inherited: 0x4) 
struct FReceiveTick : public FReceiveTick
{
	float DeltaSeconds;  // 0x0(0x4)

}; 
// Function BP_NightEmissveBase.BP_NightEmissveBase_C.RegisterGlowMesh
// Size: 0xC(Inherited: 0x0) 
struct FRegisterGlowMesh
{
	struct UStaticMeshComponent* StaticMeshComponent;  // 0x0(0x8)
	int32_t CallFunc_Array_AddUnique_ReturnValue;  // 0x8(0x4)

}; 
// Function BP_NightEmissveBase.BP_NightEmissveBase_C.RegisterSpotlight
// Size: 0xC(Inherited: 0x0) 
struct FRegisterSpotlight
{
	struct USpotLightComponent* SpotLightComponent;  // 0x0(0x8)
	int32_t CallFunc_Array_AddUnique_ReturnValue;  // 0x8(0x4)

}; 
// Function BP_NightEmissveBase.BP_NightEmissveBase_C.RegisterLightCone
// Size: 0xC(Inherited: 0x0) 
struct FRegisterLightCone
{
	struct UStaticMeshComponent* StaticMeshComponent;  // 0x0(0x8)
	int32_t CallFunc_Array_AddUnique_ReturnValue;  // 0x8(0x4)

}; 
// Function BP_NightEmissveBase.BP_NightEmissveBase_C.Toggle Lamp Internal
// Size: 0xD0(Inherited: 0x0) 
struct FToggle Lamp Internal
{
	float LightCurve;  // 0x0(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x4(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x8(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0xC(0x4)
	int32_t Temp_int_Loop_Counter_Variable_2;  // 0x10(0x4)
	int32_t Temp_int_Loop_Counter_Variable_3;  // 0x14(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0x18(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_3;  // 0x1C(0x4)
	int32_t Temp_int_Array_Index_Variable_2;  // 0x20(0x4)
	int32_t Temp_int_Loop_Counter_Variable_4;  // 0x24(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_4;  // 0x28(0x4)
	int32_t Temp_int_Array_Index_Variable_3;  // 0x2C(0x4)
	struct FVector CallFunc_Array_Get_Item;  // 0x30(0xC)
	char pad_60[4];  // 0x3C(0x4)
	struct UStaticMeshComponent* CallFunc_Array_Get_Item_2;  // 0x40(0x8)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue;  // 0x48(0xC)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x54(0x4)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x58(0x1)
	char pad_89[3];  // 0x59(0x3)
	int32_t CallFunc_Array_Length_ReturnValue_2;  // 0x5C(0x4)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_2 : 1;  // 0x60(0x1)
	char pad_97[3];  // 0x61(0x3)
	struct FLinearColor CallFunc_Multiply_LinearColorFloat_ReturnValue;  // 0x64(0x10)
	char pad_116[4];  // 0x74(0x4)
	struct USpotLightComponent* CallFunc_Array_Get_Item_3;  // 0x78(0x8)
	int32_t CallFunc_Array_Length_ReturnValue_3;  // 0x80(0x4)
	char pad_132_1 : 7;  // 0x84(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_3 : 1;  // 0x84(0x1)
	char pad_133[3];  // 0x85(0x3)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x88(0x4)
	struct FLinearColor CallFunc_Multiply_LinearColorFloat_ReturnValue_2;  // 0x8C(0x10)
	char pad_156[4];  // 0x9C(0x4)
	struct UMaterialInstanceDynamic* CallFunc_Array_Get_Item_4;  // 0xA0(0x8)
	struct FLinearColor CallFunc_Multiply_LinearColorFloat_ReturnValue_3;  // 0xA8(0x10)
	int32_t CallFunc_Array_Length_ReturnValue_4;  // 0xB8(0x4)
	char pad_188_1 : 7;  // 0xBC(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_4 : 1;  // 0xBC(0x1)
	char pad_189[3];  // 0xBD(0x3)
	float CallFunc_Multiply_FloatFloat_ReturnValue_2;  // 0xC0(0x4)
	int32_t Temp_int_Array_Index_Variable_4;  // 0xC4(0x4)
	struct UMaterialInstanceDynamic* CallFunc_Array_Get_Item_5;  // 0xC8(0x8)

}; 
// Function BP_NightEmissveBase.BP_NightEmissveBase_C.InitializeLightToggle
// Size: 0x1A(Inherited: 0x0) 
struct FInitializeLightToggle
{
	struct AGameStateBase* CallFunc_GetGameState_ReturnValue;  // 0x0(0x8)
	struct ABP_SurvivalGameState_C* K2Node_DynamicCast_AsBP_Survival_Game_State;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)
	int32_t CallFunc_Get_Current_Hour_Current_Hour;  // 0x14(0x4)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_GreaterEqual_IntInt_ReturnValue : 1;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x19(0x1)

}; 
// Function BP_NightEmissveBase.BP_NightEmissveBase_C.Find Time Of Day Manager
// Size: 0x25(Inherited: 0x0) 
struct FFind Time Of Day Manager
{
	struct TArray<struct ABP_TimeOfDayLighting_C*> CallFunc_GetAllActorsOfClass_OutActors;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct ABP_TimeOfDayLighting_C* CallFunc_Array_Get_Item;  // 0x18(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x20(0x4)
	char pad_36_1 : 7;  // 0x24(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue : 1;  // 0x24(0x1)

}; 
