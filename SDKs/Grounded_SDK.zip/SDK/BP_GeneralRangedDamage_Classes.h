#pragma once 
#include <BP_GeneralRangedDamage_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_GeneralRangedDamage.BP_GeneralRangedDamage_C
// Size: 0x78(Inherited: 0x78) 
struct UBP_GeneralRangedDamage_C : public USurvivalDamageType
{

}; 



