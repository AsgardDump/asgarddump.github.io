#pragma once 
#include <BP_HungerDamage_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_HungerDamage.BP_HungerDamage_C
// Size: 0x78(Inherited: 0x78) 
struct UBP_HungerDamage_C : public USurvivalDamageType
{

}; 



