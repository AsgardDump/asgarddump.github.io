#pragma once 
#include <BP_PhysicsHarvestNode_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_PhysicsHarvestNode.BP_PhysicsHarvestNode_C
// Size: 0x349(Inherited: 0x300) 
struct ABP_PhysicsHarvestNode_C : public AHarvestNode
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x300(0x8)
	struct ULootComponent* Loot;  // 0x308(0x8)
	struct UForceFeedbackComponent* DestroyForceFeedback;  // 0x310(0x8)
	struct UForceFeedbackComponent* DamageForceFeedback;  // 0x318(0x8)
	struct UAttractionComponent* Attraction;  // 0x320(0x8)
	struct UStaticMeshComponent* StaticMesh;  // 0x328(0x8)
	char pad_816_1 : 7;  // 0x330(0x1)
	bool HasSpawnedLoot : 1;  // 0x330(0x1)
	char pad_817[3];  // 0x331(0x3)
	float LastPhysicsHitTime;  // 0x334(0x4)
	float PhysicsHitAudioDelay;  // 0x338(0x4)
	char pad_828[4];  // 0x33C(0x4)
	struct USoundCue* PhysicsImpactAudio;  // 0x340(0x8)
	char pad_840_1 : 7;  // 0x348(0x1)
	bool bInWater : 1;  // 0x348(0x1)

	void BndEvt__HealthComponent_K2Node_ComponentBoundEvent_0_DamagedDelegate__DelegateSignature(float Damage, struct FDamageInfo& DamageInfo, struct AController* InstigatedBy, struct UBaseLODActor* DamageCauser, bool IsKillingBlow); // Function BP_PhysicsHarvestNode.BP_PhysicsHarvestNode_C.BndEvt__HealthComponent_K2Node_ComponentBoundEvent_0_DamagedDelegate__DelegateSignature
	void BndEvt__HealthComponent_K2Node_ComponentBoundEvent_1_DeathDelegate__DelegateSignature(struct FDamageInfo& DamageInfo); // Function BP_PhysicsHarvestNode.BP_PhysicsHarvestNode_C.BndEvt__HealthComponent_K2Node_ComponentBoundEvent_1_DeathDelegate__DelegateSignature
	void MulticastExecuteLootSpawnVisuals(); // Function BP_PhysicsHarvestNode.BP_PhysicsHarvestNode_C.MulticastExecuteLootSpawnVisuals
	void HandleLootSpawn(); // Function BP_PhysicsHarvestNode.BP_PhysicsHarvestNode_C.HandleLootSpawn
	void HandleLootSpawnVisuals(); // Function BP_PhysicsHarvestNode.BP_PhysicsHarvestNode_C.HandleLootSpawnVisuals
	void ReceiveTick(float DeltaSeconds); // Function BP_PhysicsHarvestNode.BP_PhysicsHarvestNode_C.ReceiveTick
	void ReceiveBeginPlay(); // Function BP_PhysicsHarvestNode.BP_PhysicsHarvestNode_C.ReceiveBeginPlay
	void On Hit(struct AActor* SelfActor, struct AActor* OtherActor, struct FVector NormalImpulse, struct FHitResult& Hit); // Function BP_PhysicsHarvestNode.BP_PhysicsHarvestNode_C.On Hit
	void ReceiveActorBeginOverlap(struct AActor* OtherActor); // Function BP_PhysicsHarvestNode.BP_PhysicsHarvestNode_C.ReceiveActorBeginOverlap
	void ReceiveActorEndOverlap(struct AActor* OtherActor); // Function BP_PhysicsHarvestNode.BP_PhysicsHarvestNode_C.ReceiveActorEndOverlap
	void HandleDeath(); // Function BP_PhysicsHarvestNode.BP_PhysicsHarvestNode_C.HandleDeath
	void ExecuteUbergraph_BP_PhysicsHarvestNode(int32_t EntryPoint); // Function BP_PhysicsHarvestNode.BP_PhysicsHarvestNode_C.ExecuteUbergraph_BP_PhysicsHarvestNode
}; 



