#pragma once 
#include "SDK.h" 
 
 
// Function BP_Pond_Breaker_Switch_4.BP_Pond_Breaker_Switch_3_C.ExecuteUbergraph_BP_Pond_Breaker_Switch_4
// Size: 0x4(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Pond_Breaker_Switch_4
{
	int32_t EntryPoint;  // 0x0(0x4)

}; 
