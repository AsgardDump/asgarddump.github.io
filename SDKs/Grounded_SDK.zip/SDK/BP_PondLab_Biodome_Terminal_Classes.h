#pragma once 
#include <BP_PondLab_Biodome_Terminal_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_PondLab_Biodome_Terminal.BP_PondLab_Biodome_Terminal_C
// Size: 0x358(Inherited: 0x288) 
struct ABP_PondLab_Biodome_Terminal_C : public ASwitch
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x288(0x8)
	struct UStaticMeshComponent* StaticMesh;  // 0x290(0x8)
	struct UConditionalToggleComponent* ConditionalToggle_DomeOpen;  // 0x298(0x8)
	struct UAudioComponent* TerminalSFXLoop;  // 0x2A0(0x8)
	struct UConditionalToggleComponent* ConditionalToggle_Vis_WaitScreen;  // 0x2A8(0x8)
	struct UConditionalToggleComponent* ConditionalToggle_Vis_UnlockScreen;  // 0x2B0(0x8)
	struct UWidgetComponent* Widget;  // 0x2B8(0x8)
	struct UConditionalToggleComponent* ConditionalToggle_Vis_LoginScreen;  // 0x2C0(0x8)
	struct UConditionalToggleComponent* ConditionalToggle_TerminalInteractable;  // 0x2C8(0x8)
	struct UConditionalToggleComponent* ConditionalToggle_TerminalOnceOnly;  // 0x2D0(0x8)
	struct TArray<struct FDataTableRowHandle> RequiredPasswordKeyItems;  // 0x2D8(0x10)
	struct FLocString InteractionText_Reboot;  // 0x2E8(0x10)
	struct FLocString InteractionText_Login;  // 0x2F8(0x10)
	struct UMaterialInstanceDynamic* ScreenDMI;  // 0x308(0x8)
	struct UUI_PondDomeTerminal_C* UserWidgetObjectRef;  // 0x310(0x8)
	char pad_792_1 : 7;  // 0x318(0x1)
	bool InteractionBlocked : 1;  // 0x318(0x1)
	char pad_793[7];  // 0x319(0x7)
	struct FMulticastInlineDelegate BiodomeOpen;  // 0x320(0x10)
	struct TArray<struct TSoftObjectPtr<ABP_Pond_Biodome_C>> Dome_Door;  // 0x330(0x10)
	char pad_832_1 : 7;  // 0x340(0x1)
	bool ScreenPaused : 1;  // 0x340(0x1)
	char pad_833[3];  // 0x341(0x3)
	int32_t CurrentlyShownScreenIndex;  // 0x344(0x4)
	struct TArray<struct TSoftObjectPtr<ABP_Lab_Hatch_Pond_C>> HatchDoor;  // 0x348(0x10)

	void GetInteractionText(uint8_t  Channel, struct AActor* InstigatedBy, struct FString& OutText); // Function BP_PondLab_Biodome_Terminal.BP_PondLab_Biodome_Terminal_C.GetInteractionText
	char EInteractionState IsInteractionEnabled(uint8_t  Channel, struct AActor* InstigatedBy); // Function BP_PondLab_Biodome_Terminal.BP_PondLab_Biodome_Terminal_C.IsInteractionEnabled
	void PartyHasAllPasswordPieces(bool& PartyHasAllPasswordPieces); // Function BP_PondLab_Biodome_Terminal.BP_PondLab_Biodome_Terminal_C.PartyHasAllPasswordPieces
	void OnOpenStateChanged(bool IsOpen, struct AActor* ActorInstigator); // Function BP_PondLab_Biodome_Terminal.BP_PondLab_Biodome_Terminal_C.OnOpenStateChanged
	void EnableScreenDraw(); // Function BP_PondLab_Biodome_Terminal.BP_PondLab_Biodome_Terminal_C.EnableScreenDraw
	void DisableScreenDraw(); // Function BP_PondLab_Biodome_Terminal.BP_PondLab_Biodome_Terminal_C.DisableScreenDraw
	void MakeScreenDMI(); // Function BP_PondLab_Biodome_Terminal.BP_PondLab_Biodome_Terminal_C.MakeScreenDMI
	void HideAllScreens(); // Function BP_PondLab_Biodome_Terminal.BP_PondLab_Biodome_Terminal_C.HideAllScreens
	void SetUserWidgetObjectReference(); // Function BP_PondLab_Biodome_Terminal.BP_PondLab_Biodome_Terminal_C.SetUserWidgetObjectReference
	void ShowStart(); // Function BP_PondLab_Biodome_Terminal.BP_PondLab_Biodome_Terminal_C.ShowStart
	void ShowLocked(); // Function BP_PondLab_Biodome_Terminal.BP_PondLab_Biodome_Terminal_C.ShowLocked
	void ShowLockedFlash(); // Function BP_PondLab_Biodome_Terminal.BP_PondLab_Biodome_Terminal_C.ShowLockedFlash
	void ShowUnlocked(); // Function BP_PondLab_Biodome_Terminal.BP_PondLab_Biodome_Terminal_C.ShowUnlocked
	void ReceiveBeginPlay(); // Function BP_PondLab_Biodome_Terminal.BP_PondLab_Biodome_Terminal_C.ReceiveBeginPlay
	void ShowWaiting(); // Function BP_PondLab_Biodome_Terminal.BP_PondLab_Biodome_Terminal_C.ShowWaiting
	void ReceiveTick(float DeltaSeconds); // Function BP_PondLab_Biodome_Terminal.BP_PondLab_Biodome_Terminal_C.ReceiveTick
	void BndEvt__ConditionalToggle_Vis_LoginScreen_K2Node_ComponentBoundEvent_0_OnConditionalStateChanged__DelegateSignature(bool bIsActive); // Function BP_PondLab_Biodome_Terminal.BP_PondLab_Biodome_Terminal_C.BndEvt__ConditionalToggle_Vis_LoginScreen_K2Node_ComponentBoundEvent_0_OnConditionalStateChanged__DelegateSignature
	void BndEvt__ConditionalToggle_Vis_UnlockScreen_K2Node_ComponentBoundEvent_1_OnConditionalStateChanged__DelegateSignature(bool bIsActive); // Function BP_PondLab_Biodome_Terminal.BP_PondLab_Biodome_Terminal_C.BndEvt__ConditionalToggle_Vis_UnlockScreen_K2Node_ComponentBoundEvent_1_OnConditionalStateChanged__DelegateSignature
	void RedrawScreen(); // Function BP_PondLab_Biodome_Terminal.BP_PondLab_Biodome_Terminal_C.RedrawScreen
	void ExecuteUbergraph_BP_PondLab_Biodome_Terminal(int32_t EntryPoint); // Function BP_PondLab_Biodome_Terminal.BP_PondLab_Biodome_Terminal_C.ExecuteUbergraph_BP_PondLab_Biodome_Terminal
	void BiodomeOpen__DelegateSignature(); // Function BP_PondLab_Biodome_Terminal.BP_PondLab_Biodome_Terminal_C.BiodomeOpen__DelegateSignature
}; 



