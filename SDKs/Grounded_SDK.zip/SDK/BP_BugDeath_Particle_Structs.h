#pragma once 
#include "SDK.h" 
 
 
// Function BP_BugDeath_Particle.BP_BugDeath_Particle_C.ExecuteUbergraph_BP_BugDeath_Particle
// Size: 0x1C0(Inherited: 0x0) 
struct FExecuteUbergraph_BP_BugDeath_Particle
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue;  // 0x8(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x10(0x10)
	struct TArray<struct AActor*> Temp_object_Variable;  // 0x20(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x30(0x10)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x40(0xC)
	struct FVector CallFunc_Add_VectorVector_ReturnValue;  // 0x4C(0xC)
	struct FHitResult CallFunc_LineTraceSingle_OutHit;  // 0x58(0x88)
	char pad_224_1 : 7;  // 0xE0(0x1)
	bool CallFunc_LineTraceSingle_ReturnValue : 1;  // 0xE0(0x1)
	char pad_225_1 : 7;  // 0xE1(0x1)
	bool CallFunc_BreakHitResult_bBlockingHit : 1;  // 0xE1(0x1)
	char pad_226_1 : 7;  // 0xE2(0x1)
	bool CallFunc_BreakHitResult_bInitialOverlap : 1;  // 0xE2(0x1)
	char pad_227[1];  // 0xE3(0x1)
	float CallFunc_BreakHitResult_Time;  // 0xE4(0x4)
	float CallFunc_BreakHitResult_Distance;  // 0xE8(0x4)
	struct FVector CallFunc_BreakHitResult_Location;  // 0xEC(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactPoint;  // 0xF8(0xC)
	struct FVector CallFunc_BreakHitResult_Normal;  // 0x104(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactNormal;  // 0x110(0xC)
	char pad_284[4];  // 0x11C(0x4)
	struct UPhysicalMaterial* CallFunc_BreakHitResult_PhysMat;  // 0x120(0x8)
	struct AActor* CallFunc_BreakHitResult_HitActor;  // 0x128(0x8)
	struct UPrimitiveComponent* CallFunc_BreakHitResult_HitComponent;  // 0x130(0x8)
	struct FName CallFunc_BreakHitResult_HitBoneName;  // 0x138(0x8)
	int32_t CallFunc_BreakHitResult_HitItem;  // 0x140(0x4)
	int32_t CallFunc_BreakHitResult_ElementIndex;  // 0x144(0x4)
	int32_t CallFunc_BreakHitResult_FaceIndex;  // 0x148(0x4)
	struct FVector CallFunc_BreakHitResult_TraceStart;  // 0x14C(0xC)
	struct FVector CallFunc_BreakHitResult_TraceEnd;  // 0x158(0xC)
	struct FRotator CallFunc_Conv_VectorToRotator_ReturnValue;  // 0x164(0xC)
	float CallFunc_BreakRotator_Roll;  // 0x170(0x4)
	float CallFunc_BreakRotator_Pitch;  // 0x174(0x4)
	float CallFunc_BreakRotator_Yaw;  // 0x178(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0x17C(0x4)
	struct FTimerHandle CallFunc_K2_SetTimerDelegate_ReturnValue;  // 0x180(0x8)
	struct AActor* K2Node_CustomEvent_DestroyedActor;  // 0x188(0x8)
	float CallFunc_SelectFloat_ReturnValue;  // 0x190(0x4)
	char pad_404[4];  // 0x194(0x4)
	struct ASurvivalCreature* K2Node_DynamicCast_AsSurvival_Creature;  // 0x198(0x8)
	char pad_416_1 : 7;  // 0x1A0(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x1A0(0x1)
	char pad_417[3];  // 0x1A1(0x3)
	float CallFunc_RandomFloatInRange_ReturnValue;  // 0x1A4(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue_2;  // 0x1A8(0x4)
	struct FRotator CallFunc_MakeRotator_ReturnValue;  // 0x1AC(0xC)
	struct UDecalComponent* CallFunc_SpawnDecalAttached_ReturnValue;  // 0x1B8(0x8)

}; 
// Function BP_BugDeath_Particle.BP_BugDeath_Particle_C.FadeDecalParentCall
// Size: 0x8(Inherited: 0x0) 
struct FFadeDecalParentCall
{
	struct AActor* DestroyedActor;  // 0x0(0x8)

}; 
