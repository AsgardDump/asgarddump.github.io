#pragma once 
#include <BP_BASE_Anarchis_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_BASE_Anarchis.BP_BASE_Anarchis_C
// Size: 0x250(Inherited: 0x248) 
struct ABP_BASE_Anarchis_C : public ALODableActor
{
	struct UStaticMeshComponent* StaticMesh;  // 0x248(0x8)

}; 



