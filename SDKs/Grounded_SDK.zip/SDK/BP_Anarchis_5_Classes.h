#pragma once 
#include <BP_Anarchis_5_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Anarchis_5.BP_Anarchis_4_C
// Size: 0x280(Inherited: 0x250) 
struct ABP_Anarchis_4_C : public ABP_BASE_Anarchis_C
{
	struct UChildActorComponent* BP_AttachmentPoint5;  // 0x250(0x8)
	struct UChildActorComponent* BP_AttachmentPoint4;  // 0x258(0x8)
	struct UChildActorComponent* BP_AttachmentPoint3;  // 0x260(0x8)
	struct UChildActorComponent* BP_AttachmentPoint2;  // 0x268(0x8)
	struct UChildActorComponent* BP_AttachmentPoint1;  // 0x270(0x8)
	struct UChildActorComponent* BP_AttachmentPoint;  // 0x278(0x8)

}; 



