#pragma once 
#include <BP_PondLab_SecurityTerminal_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_PondLab_SecurityTerminal.BP_PondLab_SecurityTerminal_C
// Size: 0x37D(Inherited: 0x288) 
struct ABP_PondLab_SecurityTerminal_C : public ASwitch
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x288(0x8)
	struct UStaticMeshComponent* StaticMesh;  // 0x290(0x8)
	struct UConditionalToggleComponent* CT_DomeTerminalRebooted;  // 0x298(0x8)
	struct UConditionalToggleComponent* CT_UnlockSecurityDoors;  // 0x2A0(0x8)
	struct UConditionalToggleComponent* CT_BootUpDone;  // 0x2A8(0x8)
	struct UAudioComponent* TerminalSFXLoop;  // 0x2B0(0x8)
	struct UConditionalToggleComponent* CT_LowPowerWaitScreen;  // 0x2B8(0x8)
	struct UConditionalToggleComponent* CT_UnlockedScreen;  // 0x2C0(0x8)
	struct UWidgetComponent* Widget;  // 0x2C8(0x8)
	struct UConditionalToggleComponent* CT_LoginScreen;  // 0x2D0(0x8)
	struct FLocString InteractionText_Reboot;  // 0x2D8(0x10)
	struct FLocString InteractionText_Login;  // 0x2E8(0x10)
	struct UMaterialInstanceDynamic* ScreenDMI;  // 0x2F8(0x8)
	struct UUI_LANStatusTerminal_C* UserWidgetObjectRef;  // 0x300(0x8)
	char pad_776_1 : 7;  // 0x308(0x1)
	bool InteractionBlocked : 1;  // 0x308(0x1)
	char pad_777[7];  // 0x309(0x7)
	struct TArray<struct TSoftObjectPtr<ADoor>> BiodomeDoor;  // 0x310(0x10)
	struct TArray<struct TSoftObjectPtr<ABP_Lab_Hatch_Pond_C>> Hatch;  // 0x320(0x10)
	struct USoundBase* SecurityComputerSound;  // 0x330(0x8)
	struct TArray<struct TSoftObjectPtr<ADoor>> FirstFloorHatchDoor;  // 0x338(0x10)
	struct TArray<struct TSoftObjectPtr<ADoor>> TazTDoor;  // 0x348(0x10)
	struct TArray<struct TSoftObjectPtr<ADoor>> LivingQuartersDoor;  // 0x358(0x10)
	struct TArray<struct TSoftObjectPtr<ADoor>> StorageRoomDoor;  // 0x368(0x10)
	int32_t CurrentlyShownScreenIndex;  // 0x378(0x4)
	char pad_892_1 : 7;  // 0x37C(0x1)
	bool ScreenPaused : 1;  // 0x37C(0x1)

	void RedrawScreen(); // Function BP_PondLab_SecurityTerminal.BP_PondLab_SecurityTerminal_C.RedrawScreen
	void GetInteractionText(uint8_t  Channel, struct AActor* InstigatedBy, struct FString& OutText); // Function BP_PondLab_SecurityTerminal.BP_PondLab_SecurityTerminal_C.GetInteractionText
	char EInteractionState IsInteractionEnabled(uint8_t  Channel, struct AActor* InstigatedBy); // Function BP_PondLab_SecurityTerminal.BP_PondLab_SecurityTerminal_C.IsInteractionEnabled
	void OnOpenStateChanged(bool IsOpen, struct AActor* ActorInstigator); // Function BP_PondLab_SecurityTerminal.BP_PondLab_SecurityTerminal_C.OnOpenStateChanged
	void EnableScreenDraw(); // Function BP_PondLab_SecurityTerminal.BP_PondLab_SecurityTerminal_C.EnableScreenDraw
	void DisableScreenDraw(); // Function BP_PondLab_SecurityTerminal.BP_PondLab_SecurityTerminal_C.DisableScreenDraw
	void MakeScreenDMI(); // Function BP_PondLab_SecurityTerminal.BP_PondLab_SecurityTerminal_C.MakeScreenDMI
	void HideAllScreens(); // Function BP_PondLab_SecurityTerminal.BP_PondLab_SecurityTerminal_C.HideAllScreens
	void SetUserWidgetObjectReference(); // Function BP_PondLab_SecurityTerminal.BP_PondLab_SecurityTerminal_C.SetUserWidgetObjectReference
	void ShowStart(); // Function BP_PondLab_SecurityTerminal.BP_PondLab_SecurityTerminal_C.ShowStart
	void ShowLocked(); // Function BP_PondLab_SecurityTerminal.BP_PondLab_SecurityTerminal_C.ShowLocked
	void ShowLockedFlash(); // Function BP_PondLab_SecurityTerminal.BP_PondLab_SecurityTerminal_C.ShowLockedFlash
	void ShowUnlocked(); // Function BP_PondLab_SecurityTerminal.BP_PondLab_SecurityTerminal_C.ShowUnlocked
	void PlayPondBootupSequence(); // Function BP_PondLab_SecurityTerminal.BP_PondLab_SecurityTerminal_C.PlayPondBootupSequence
	void ReceiveBeginPlay(); // Function BP_PondLab_SecurityTerminal.BP_PondLab_SecurityTerminal_C.ReceiveBeginPlay
	void ShowWaiting(); // Function BP_PondLab_SecurityTerminal.BP_PondLab_SecurityTerminal_C.ShowWaiting
	void BndEvt__ConditionalToggle_UnlockSecurityDoor01_K2Node_ComponentBoundEvent_2_OnConditionalStateChanged__DelegateSignature(bool bIsActive); // Function BP_PondLab_SecurityTerminal.BP_PondLab_SecurityTerminal_C.BndEvt__ConditionalToggle_UnlockSecurityDoor01_K2Node_ComponentBoundEvent_2_OnConditionalStateChanged__DelegateSignature
	void BndEvt__ConditionalToggle_Vis_LoginScreen_K2Node_ComponentBoundEvent_0_OnConditionalStateChanged__DelegateSignature(bool bIsActive); // Function BP_PondLab_SecurityTerminal.BP_PondLab_SecurityTerminal_C.BndEvt__ConditionalToggle_Vis_LoginScreen_K2Node_ComponentBoundEvent_0_OnConditionalStateChanged__DelegateSignature
	void BndEvt__CT_DomeTerminalRebooted_K2Node_ComponentBoundEvent_1_OnConditionalStateChanged__DelegateSignature(bool bIsActive); // Function BP_PondLab_SecurityTerminal.BP_PondLab_SecurityTerminal_C.BndEvt__CT_DomeTerminalRebooted_K2Node_ComponentBoundEvent_1_OnConditionalStateChanged__DelegateSignature
	void ShowCompleted(); // Function BP_PondLab_SecurityTerminal.BP_PondLab_SecurityTerminal_C.ShowCompleted
	void BndEvt__CT_LowPowerWaitScreen_K2Node_ComponentBoundEvent_3_OnConditionalStateChanged__DelegateSignature(bool bIsActive); // Function BP_PondLab_SecurityTerminal.BP_PondLab_SecurityTerminal_C.BndEvt__CT_LowPowerWaitScreen_K2Node_ComponentBoundEvent_3_OnConditionalStateChanged__DelegateSignature
	void BndEvt__CT_UnlockedScreen_K2Node_ComponentBoundEvent_4_OnConditionalStateChanged__DelegateSignature(bool bIsActive); // Function BP_PondLab_SecurityTerminal.BP_PondLab_SecurityTerminal_C.BndEvt__CT_UnlockedScreen_K2Node_ComponentBoundEvent_4_OnConditionalStateChanged__DelegateSignature
	void ReceiveTick(float DeltaSeconds); // Function BP_PondLab_SecurityTerminal.BP_PondLab_SecurityTerminal_C.ReceiveTick
	void ExecuteUbergraph_BP_PondLab_SecurityTerminal(int32_t EntryPoint); // Function BP_PondLab_SecurityTerminal.BP_PondLab_SecurityTerminal_C.ExecuteUbergraph_BP_PondLab_SecurityTerminal
}; 



