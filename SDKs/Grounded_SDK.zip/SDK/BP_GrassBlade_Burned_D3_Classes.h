#pragma once 
#include <BP_GrassBlade_Burned_D3_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_GrassBlade_Burned_D3.BP_GrassBlade_Burned_D3_C
// Size: 0x408(Inherited: 0x408) 
struct ABP_GrassBlade_Burned_D3_C : public ABP_BASE_GrassBlade_Burned_C
{

}; 



