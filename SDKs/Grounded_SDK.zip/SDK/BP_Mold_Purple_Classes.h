#pragma once 
#include <BP_Mold_Purple_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Mold_Purple.BP_Mold_Purple_C
// Size: 0x370(Inherited: 0x368) 
struct ABP_Mold_Purple_C : public ABP_StaticHarvestNode_C
{
	struct UVisualStateComponent* VisualState;  // 0x368(0x8)

}; 



