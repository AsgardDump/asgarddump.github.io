#pragma once 
#include <BP_Lab_PowerTerminal_Pond02_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Lab_PowerTerminal_Pond02.BP_Lab_PowerTerminal_Pond02_C
// Size: 0x390(Inherited: 0x368) 
struct ABP_Lab_PowerTerminal_Pond02_C : public ABP_Base_PowerTerminal_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x368(0x8)
	struct UConditionalToggleComponent* ConditionalToggle_BreakersNeedReset;  // 0x370(0x8)
	struct UParticleSystemComponent* VFX_Spark;  // 0x378(0x8)
	struct UConditionalToggleComponent* ConditionalToggle_BreakersReset;  // 0x380(0x8)
	struct USoundBase* SparkSound;  // 0x388(0x8)

	void RedrawScreen(); // Function BP_Lab_PowerTerminal_Pond02.BP_Lab_PowerTerminal_Pond02_C.RedrawScreen
	void OnOpenStateChanged(bool IsOpen, struct AActor* ActorInstigator); // Function BP_Lab_PowerTerminal_Pond02.BP_Lab_PowerTerminal_Pond02_C.OnOpenStateChanged
	void Reroute Unsuccesful(); // Function BP_Lab_PowerTerminal_Pond02.BP_Lab_PowerTerminal_Pond02_C.Reroute Unsuccesful
	void BndEvt__ConditionalToggle_BreakersReset_K2Node_ComponentBoundEvent_0_OnConditionalStateChanged__DelegateSignature(bool bIsActive); // Function BP_Lab_PowerTerminal_Pond02.BP_Lab_PowerTerminal_Pond02_C.BndEvt__ConditionalToggle_BreakersReset_K2Node_ComponentBoundEvent_0_OnConditionalStateChanged__DelegateSignature
	void BndEvt__ConditionalToggle_BreakersNeedReset_K2Node_ComponentBoundEvent_1_OnConditionalStateChanged__DelegateSignature(bool bIsActive); // Function BP_Lab_PowerTerminal_Pond02.BP_Lab_PowerTerminal_Pond02_C.BndEvt__ConditionalToggle_BreakersNeedReset_K2Node_ComponentBoundEvent_1_OnConditionalStateChanged__DelegateSignature
	void BndEvt__ConditionalToggle_HousePower_K2Node_ComponentBoundEvent_2_OnConditionalStateChanged__DelegateSignature(bool bIsActive); // Function BP_Lab_PowerTerminal_Pond02.BP_Lab_PowerTerminal_Pond02_C.BndEvt__ConditionalToggle_HousePower_K2Node_ComponentBoundEvent_2_OnConditionalStateChanged__DelegateSignature
	void ExecuteUbergraph_BP_Lab_PowerTerminal_Pond02(int32_t EntryPoint); // Function BP_Lab_PowerTerminal_Pond02.BP_Lab_PowerTerminal_Pond02_C.ExecuteUbergraph_BP_Lab_PowerTerminal_Pond02
}; 



