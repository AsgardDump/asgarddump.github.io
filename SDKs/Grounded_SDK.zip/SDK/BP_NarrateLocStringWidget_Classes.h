#pragma once 
#include <BP_NarrateLocStringWidget_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass BP_NarrateLocStringWidget.BP_NarrateLocStringWidget_C
// Size: 0x280(Inherited: 0x270) 
struct UBP_NarrateLocStringWidget_C : public UNarratableUserWidget
{
	struct FLocString NarrateText;  // 0x270(0x10)

	void GetNarration(struct TArray<struct FNarrationChunk>& Chunks, bool bVerbose); // Function BP_NarrateLocStringWidget.BP_NarrateLocStringWidget_C.GetNarration
}; 



