#pragma once 
#include <BP_CameraShake_Weevil_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_CameraShake_Weevil.BP_CameraShake_Weevil_C
// Size: 0x1B0(Inherited: 0x1B0) 
struct UBP_CameraShake_Weevil_C : public UMatineeCameraShake
{

}; 



