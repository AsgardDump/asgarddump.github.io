#pragma once 
#include <BP_ItemDuplicator_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_ItemDuplicator.BP_ItemDuplicator_C
// Size: 0x7C9(Inherited: 0x6B0) 
struct ABP_ItemDuplicator_C : public ADuplicatorBuilding
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x6B0(0x8)
	struct UAudioComponent* Audio Idle Loop;  // 0x6B8(0x8)
	struct UCameraComponent* UpgradeCamera;  // 0x6C0(0x8)
	struct UInterfaceCamSpringArmComponent* UpgradeCamSpringArm;  // 0x6C8(0x8)
	struct UBoxComponent* ClearanceBox;  // 0x6D0(0x8)
	struct UCameraComponent* InteractCamera;  // 0x6D8(0x8)
	struct UInterfaceCamSpringArmComponent* InterfaceCamSpringArm;  // 0x6E0(0x8)
	struct UStaticMeshComponent* ZigZag;  // 0x6E8(0x8)
	struct UStaticMeshComponent* Triangle2;  // 0x6F0(0x8)
	struct UStaticMeshComponent* Grid;  // 0x6F8(0x8)
	struct UStaticMeshComponent* Ball1;  // 0x700(0x8)
	struct UStaticMeshComponent* Cube2;  // 0x708(0x8)
	struct USceneComponent* ScienceBitsPivot;  // 0x710(0x8)
	struct UNiagaraComponent* Niagara;  // 0x718(0x8)
	struct UPointLightComponent* ScienceLightRing;  // 0x720(0x8)
	struct UStaticMeshComponent* LightBlocker1;  // 0x728(0x8)
	struct UStaticMeshComponent* LightBlocker;  // 0x730(0x8)
	struct UPointLightComponent* ScienceLight;  // 0x738(0x8)
	struct UStaticMeshComponent* SM_Science_Blob;  // 0x740(0x8)
	struct UStaticMeshComponent* SM_Super_Duper_D;  // 0x748(0x8)
	struct UPointLightComponent* PointLightStatic03;  // 0x750(0x8)
	struct UPointLightComponent* PointLightStatic02;  // 0x758(0x8)
	struct UPointLightComponent* PointLightStatic01;  // 0x760(0x8)
	struct UPointLightComponent* PointLightStatic00;  // 0x768(0x8)
	struct UStaticMeshComponent* SM_Super_Duper_B;  // 0x770(0x8)
	struct UStaticMeshComponent* SM_Super_Duper_C;  // 0x778(0x8)
	struct UStaticMeshComponent* StaticMesh;  // 0x780(0x8)
	float TL_InteractCameraPan_PanCurve_4A20BB4E4D3D4132ADE334977A488B9A;  // 0x788(0x4)
	char ETimelineDirection TL_InteractCameraPan__Direction_4A20BB4E4D3D4132ADE334977A488B9A;  // 0x78C(0x1)
	char pad_1933[3];  // 0x78D(0x3)
	struct UTimelineComponent* TL_InteractCameraPan;  // 0x790(0x8)
	float TL_DuperAnimation_ScienceSpin_E39C24354B7EEA505A13CBAC041ED359;  // 0x798(0x4)
	float TL_DuperAnimation_Emissive_E39C24354B7EEA505A13CBAC041ED359;  // 0x79C(0x4)
	float TL_DuperAnimation_Spin_E39C24354B7EEA505A13CBAC041ED359;  // 0x7A0(0x4)
	float TL_DuperAnimation_Donut_E39C24354B7EEA505A13CBAC041ED359;  // 0x7A4(0x4)
	float TL_DuperAnimation_Effects_E39C24354B7EEA505A13CBAC041ED359;  // 0x7A8(0x4)
	char ETimelineDirection TL_DuperAnimation__Direction_E39C24354B7EEA505A13CBAC041ED359;  // 0x7AC(0x1)
	char pad_1965[3];  // 0x7AD(0x3)
	struct UTimelineComponent* TL_DuperAnimation;  // 0x7B0(0x8)
	float Blob Scale;  // 0x7B8(0x4)
	float Light Intensity;  // 0x7BC(0x4)
	struct UMaterialInstanceDynamic* MID_Donut;  // 0x7C0(0x8)
	char pad_1992_1 : 7;  // 0x7C8(0x1)
	bool isDuping : 1;  // 0x7C8(0x1)

	struct FTransform GetCameraViewTransform(); // Function BP_ItemDuplicator.BP_ItemDuplicator_C.GetCameraViewTransform
	struct FVector GetLookAtLocation(); // Function BP_ItemDuplicator.BP_ItemDuplicator_C.GetLookAtLocation
	bool HasLookAtLocation(); // Function BP_ItemDuplicator.BP_ItemDuplicator_C.HasLookAtLocation
	void EndDupeUpgrade(struct ASurvivalPlayerCharacter* Target); // Function BP_ItemDuplicator.BP_ItemDuplicator_C.EndDupeUpgrade
	void BeginDupeUpgrade(struct ASurvivalPlayerCharacter* Target); // Function BP_ItemDuplicator.BP_ItemDuplicator_C.BeginDupeUpgrade
	struct UPrimitiveComponent* GetUseVolume(); // Function BP_ItemDuplicator.BP_ItemDuplicator_C.GetUseVolume
	void UserConstructionScript(); // Function BP_ItemDuplicator.BP_ItemDuplicator_C.UserConstructionScript
	void TL_DuperAnimation__FinishedFunc(); // Function BP_ItemDuplicator.BP_ItemDuplicator_C.TL_DuperAnimation__FinishedFunc
	void TL_DuperAnimation__UpdateFunc(); // Function BP_ItemDuplicator.BP_ItemDuplicator_C.TL_DuperAnimation__UpdateFunc
	void TL_DuperAnimation__Particle Event__EventFunc(); // Function BP_ItemDuplicator.BP_ItemDuplicator_C.TL_DuperAnimation__Particle Event__EventFunc
	void TL_InteractCameraPan__FinishedFunc(); // Function BP_ItemDuplicator.BP_ItemDuplicator_C.TL_InteractCameraPan__FinishedFunc
	void TL_InteractCameraPan__UpdateFunc(); // Function BP_ItemDuplicator.BP_ItemDuplicator_C.TL_InteractCameraPan__UpdateFunc
	void ReceiveBeginPlay(); // Function BP_ItemDuplicator.BP_ItemDuplicator_C.ReceiveBeginPlay
	void OnDuplicateItem(); // Function BP_ItemDuplicator.BP_ItemDuplicator_C.OnDuplicateItem
	void Interact(uint8_t  Channel, struct AActor* InstigatedBy); // Function BP_ItemDuplicator.BP_ItemDuplicator_C.Interact
	void EndInteraction(struct AActor* InstigatedBy); // Function BP_ItemDuplicator.BP_ItemDuplicator_C.EndInteraction
	void OnDuplicatorUpgrade(); // Function BP_ItemDuplicator.BP_ItemDuplicator_C.OnDuplicatorUpgrade
	void ExecuteUbergraph_BP_ItemDuplicator(int32_t EntryPoint); // Function BP_ItemDuplicator.BP_ItemDuplicator_C.ExecuteUbergraph_BP_ItemDuplicator
}; 



