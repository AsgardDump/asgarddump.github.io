#pragma once 
#include "SDK.h" 
 
 
// Function AB_Analyzer.AB_Analyzer_C.ExecuteUbergraph_AB_Analyzer
// Size: 0x4(Inherited: 0x0) 
struct FExecuteUbergraph_AB_Analyzer
{
	int32_t EntryPoint;  // 0x0(0x4)

}; 
// Function AB_Analyzer.AB_Analyzer_C.AnimGraph
// Size: 0x10(Inherited: 0x0) 
struct FAnimGraph
{
	struct FPoseLink AnimGraph;  // 0x0(0x10)

}; 
