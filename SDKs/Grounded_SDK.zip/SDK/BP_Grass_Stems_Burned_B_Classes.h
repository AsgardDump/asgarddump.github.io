#pragma once 
#include <BP_Grass_Stems_Burned_B_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Grass_Stems_Burned_B.BP_Grass_Stems_Burned_B_C
// Size: 0x408(Inherited: 0x408) 
struct ABP_Grass_Stems_Burned_B_C : public ABP_BASE_GrassBlade_Burned_C
{

}; 



