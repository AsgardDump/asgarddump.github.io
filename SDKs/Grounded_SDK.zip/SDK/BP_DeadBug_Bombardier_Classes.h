#pragma once 
#include <BP_DeadBug_Bombardier_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_DeadBug_Bombardier.BP_DeadBug_Bombardier_C
// Size: 0x4A8(Inherited: 0x4A8) 
struct ABP_DeadBug_Bombardier_C : public ABP_WorldItem_C
{

}; 



