#pragma once 
#include <BP_BASE_GrassBlade_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_BASE_GrassBlade.BP_BASE_GrassBlade_C
// Size: 0x429(Inherited: 0x420) 
struct ABP_BASE_GrassBlade_C : public ABP_ToppleHarvestNode_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x420(0x8)
	char pad_1064_1 : 7;  // 0x428(0x1)
	bool bInWater : 1;  // 0x428(0x1)

	void ReceiveBeginPlay(); // Function BP_BASE_GrassBlade.BP_BASE_GrassBlade_C.ReceiveBeginPlay
	void ReceiveTick(float DeltaSeconds); // Function BP_BASE_GrassBlade.BP_BASE_GrassBlade_C.ReceiveTick
	void OnStaticTopBeginOverlap(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult& SweepResult); // Function BP_BASE_GrassBlade.BP_BASE_GrassBlade_C.OnStaticTopBeginOverlap
	void OnStaticTopEndOverlap(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex); // Function BP_BASE_GrassBlade.BP_BASE_GrassBlade_C.OnStaticTopEndOverlap
	void HandlePreDeathToExplosive(); // Function BP_BASE_GrassBlade.BP_BASE_GrassBlade_C.HandlePreDeathToExplosive
	void ExecuteUbergraph_BP_BASE_GrassBlade(int32_t EntryPoint); // Function BP_BASE_GrassBlade.BP_BASE_GrassBlade_C.ExecuteUbergraph_BP_BASE_GrassBlade
}; 



