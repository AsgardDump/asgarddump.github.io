#pragma once 
#include <BP_FreshStabbingDamage_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_FreshStabbingDamage.BP_FreshStabbingDamage_C
// Size: 0x78(Inherited: 0x78) 
struct UBP_FreshStabbingDamage_C : public UBP_FreshDamage_C
{

}; 



