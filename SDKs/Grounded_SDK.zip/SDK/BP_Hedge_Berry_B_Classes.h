#pragma once 
#include <BP_Hedge_Berry_B_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Hedge_Berry_B.BP_Hedge_Berry_B_C
// Size: 0x430(Inherited: 0x430) 
struct ABP_Hedge_Berry_B_C : public ABP_BASE_Hedge_Berry_C
{

}; 



