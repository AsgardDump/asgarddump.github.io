#pragma once 
#include <BP_FallbackWorldItem_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_FallbackWorldItem.BP_FallbackWorldItem_C
// Size: 0x4A8(Inherited: 0x4A8) 
struct ABP_FallbackWorldItem_C : public ABP_WorldItem_C
{

}; 



