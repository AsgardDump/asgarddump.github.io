#pragma once 
#include <BP_Backpack_Player_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Backpack_Player.BP_Backpack_Player_C
// Size: 0x35C(Inherited: 0x340) 
struct ABP_Backpack_Player_C : public ALootBag
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x340(0x8)
	struct UDropletContentsComponent* DropletContentsComponent;  // 0x348(0x8)
	struct UStaticMeshComponent* StaticMesh;  // 0x350(0x8)
	int32_t CurrentPlayerIndex;  // 0x358(0x4)

	void TestZ(); // Function BP_Backpack_Player.BP_Backpack_Player_C.TestZ
	void ReceiveBeginPlay(); // Function BP_Backpack_Player.BP_Backpack_Player_C.ReceiveBeginPlay
	void ResyncToLastKnownHostPosition(); // Function BP_Backpack_Player.BP_Backpack_Player_C.ResyncToLastKnownHostPosition
	void ExecuteUbergraph_BP_Backpack_Player(int32_t EntryPoint); // Function BP_Backpack_Player.BP_Backpack_Player_C.ExecuteUbergraph_BP_Backpack_Player
}; 



