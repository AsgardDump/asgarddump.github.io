#pragma once 
#include <BP_BASE_Weed_Dandelion_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_BASE_Weed_Dandelion.BP_BASE_Weed_Dandelion_C
// Size: 0x438(Inherited: 0x420) 
struct ABP_BASE_Weed_Dandelion_C : public ABP_ToppleHarvestNode_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x420(0x8)
	struct UParticleSystemSpawnComponent* BreakParticles1;  // 0x428(0x8)
	struct UParticleSystemSpawnComponent* BreakParticles2;  // 0x430(0x8)

	void ReceiveBeginPlay(); // Function BP_BASE_Weed_Dandelion.BP_BASE_Weed_Dandelion_C.ReceiveBeginPlay
	void HandleLootSpawnVisuals(); // Function BP_BASE_Weed_Dandelion.BP_BASE_Weed_Dandelion_C.HandleLootSpawnVisuals
	void ExecuteUbergraph_BP_BASE_Weed_Dandelion(int32_t EntryPoint); // Function BP_BASE_Weed_Dandelion.BP_BASE_Weed_Dandelion_C.ExecuteUbergraph_BP_BASE_Weed_Dandelion
}; 



