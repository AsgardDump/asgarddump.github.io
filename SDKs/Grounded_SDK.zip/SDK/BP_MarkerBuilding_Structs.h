#pragma once 
#include "SDK.h" 
 
 
// Function BP_MarkerBuilding.BP_MarkerBuilding_C.ExecuteUbergraph_BP_MarkerBuilding
// Size: 0xCD(Inherited: 0x0) 
struct FExecuteUbergraph_BP_MarkerBuilding
{
	int32_t EntryPoint;  // 0x0(0x4)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x4(0xC)
	struct FTransform CallFunc_MakeTransform_ReturnValue;  // 0x10(0x30)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool CallFunc_EqualEqual_VectorVector_ReturnValue : 1;  // 0x40(0x1)
	char pad_65[3];  // 0x41(0x3)
	struct FHitResult CallFunc_K2_SetActorTransform_SweepHitResult;  // 0x44(0x88)
	char pad_204_1 : 7;  // 0xCC(0x1)
	bool CallFunc_K2_SetActorTransform_ReturnValue : 1;  // 0xCC(0x1)

}; 
// Function BP_MarkerBuilding.BP_MarkerBuilding_C.GetUseText
// Size: 0x50(Inherited: 0x28) 
struct FGetUseText : public FGetUseText
{
	uint8_t  Channel;  // 0x0(0x1)
	struct AActor* InstigatedBy;  // 0x8(0x8)
	struct FText ReturnValue;  // 0x10(0x18)
	struct FString CallFunc_GetLocalizedString_ReturnValue;  // 0x28(0x10)
	struct FText CallFunc_Conv_StringToText_ReturnValue;  // 0x38(0x18)

}; 
