#pragma once 
#include "SDK.h" 
 
 
// Function BP_RawScience_A.BP_RawScience_A_C.ExecuteUbergraph_BP_RawScience_A
// Size: 0x380(Inherited: 0x0) 
struct FExecuteUbergraph_BP_RawScience_A
{
	int32_t EntryPoint;  // 0x0(0x4)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x4(0xC)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x10(0x10)
	struct FTransform CallFunc_MakeTransform_ReturnValue;  // 0x20(0x30)
	struct AActor* CallFunc_BeginDeferredActorSpawnFromClass_ReturnValue;  // 0x50(0x8)
	struct ABP_ScienceBits_C* CallFunc_FinishSpawningActor_ReturnValue;  // 0x58(0x8)
	float CallFunc_BreakVector_X;  // 0x60(0x4)
	float CallFunc_BreakVector_Y;  // 0x64(0x4)
	float CallFunc_BreakVector_Z;  // 0x68(0x4)
	struct FHitResult CallFunc_K2_AddLocalRotation_SweepHitResult;  // 0x6C(0x88)
	struct FHitResult CallFunc_K2_AddWorldRotation_SweepHitResult;  // 0xF4(0x88)
	struct FHitResult CallFunc_K2_AddWorldRotation_SweepHitResult_2;  // 0x17C(0x88)
	struct FHitResult CallFunc_K2_AddWorldRotation_SweepHitResult_3;  // 0x204(0x88)
	char pad_652[4];  // 0x28C(0x4)
	struct ASurvivalPlayerCharacter* K2Node_CustomEvent_Character;  // 0x290(0x8)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x298(0x4)
	char pad_668[4];  // 0x29C(0x4)
	struct ABP_SurvivalPlayerCharacter_C* K2Node_DynamicCast_AsBP_Survival_Player_Character;  // 0x2A0(0x8)
	char pad_680_1 : 7;  // 0x2A8(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x2A8(0x1)
	char pad_681[3];  // 0x2A9(0x3)
	struct FVector CallFunc_Conv_FloatToVector_ReturnValue;  // 0x2AC(0xC)
	float CallFunc_Multiply_FloatFloat_ReturnValue_2;  // 0x2B8(0x4)
	struct FVector CallFunc_MakeVector_ReturnValue;  // 0x2BC(0xC)
	float K2Node_Event_DeltaSeconds;  // 0x2C8(0x4)
	char pad_716_1 : 7;  // 0x2CC(0x1)
	bool CallFunc_WasRecentlyRendered_ReturnValue : 1;  // 0x2CC(0x1)
	char pad_717[3];  // 0x2CD(0x3)
	float CallFunc_RandomFloatInRange_ReturnValue;  // 0x2D0(0x4)
	float CallFunc_RandomFloatInRange_ReturnValue_2;  // 0x2D4(0x4)
	float CallFunc_RandomFloatInRange_ReturnValue_3;  // 0x2D8(0x4)
	struct FRotator CallFunc_MakeRotator_ReturnValue;  // 0x2DC(0xC)
	struct FHitResult CallFunc_K2_AddWorldRotation_SweepHitResult_4;  // 0x2E8(0x88)
	struct FChatterEventReference CallFunc_MakeChatterEventReference_ReturnValue;  // 0x370(0x10)

}; 
// Function BP_RawScience_A.BP_RawScience_A_C.ReceiveTick
// Size: 0x4(Inherited: 0x4) 
struct FReceiveTick : public FReceiveTick
{
	float DeltaSeconds;  // 0x0(0x4)

}; 
// Function BP_RawScience_A.BP_RawScience_A_C.OnCollectedEvent
// Size: 0x8(Inherited: 0x0) 
struct FOnCollectedEvent
{
	struct ASurvivalPlayerCharacter* Character;  // 0x0(0x8)

}; 
