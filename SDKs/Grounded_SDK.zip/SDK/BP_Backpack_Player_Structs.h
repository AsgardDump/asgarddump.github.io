#pragma once 
#include "SDK.h" 
 
 
// Function BP_Backpack_Player.BP_Backpack_Player_C.ExecuteUbergraph_BP_Backpack_Player
// Size: 0xAE(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Backpack_Player
{
	int32_t EntryPoint;  // 0x0(0x4)
	float CallFunc_RandomFloatInRange_ReturnValue;  // 0x4(0x4)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x8(0xC)
	struct FHitResult CallFunc_K2_SetActorLocation_SweepHitResult;  // 0x14(0x88)
	char pad_156_1 : 7;  // 0x9C(0x1)
	bool CallFunc_K2_SetActorLocation_ReturnValue : 1;  // 0x9C(0x1)
	char pad_157[3];  // 0x9D(0x3)
	float CallFunc_BreakVector_X;  // 0xA0(0x4)
	float CallFunc_BreakVector_Y;  // 0xA4(0x4)
	float CallFunc_BreakVector_Z;  // 0xA8(0x4)
	char pad_172_1 : 7;  // 0xAC(0x1)
	bool CallFunc_LessEqual_FloatFloat_ReturnValue : 1;  // 0xAC(0x1)
	char pad_173_1 : 7;  // 0xAD(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0xAD(0x1)

}; 
