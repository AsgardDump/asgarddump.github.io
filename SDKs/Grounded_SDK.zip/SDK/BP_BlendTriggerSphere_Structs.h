#pragma once 
#include "SDK.h" 
 
 
// Function BP_BlendTriggerSphere.BP_BlendTriggerSphere_C.UserConstructionScript
// Size: 0x2A(Inherited: 0x0) 
struct FUserConstructionScript : public FUserConstructionScript
{
	char ECollisionResponse Temp_byte_Variable;  // 0x0(0x1)
	char ECollisionResponse Temp_byte_Variable_2;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool Temp_bool_Variable : 1;  // 0x2(0x1)
	char pad_3[5];  // 0x3(0x5)
	struct TArray<struct ABP_TimeOfDayLighting_C*> CallFunc_GetAllActorsOfClass_OutActors;  // 0x8(0x10)
	char ECollisionResponse K2Node_Select_Default;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct ABP_TimeOfDayLighting_C* CallFunc_Array_Get_Item;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x28(0x1)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x29(0x1)

}; 
// Function BP_BlendTriggerSphere.BP_BlendTriggerSphere_C.BndEvt__Sphere_K2Node_ComponentBoundEvent_7_ComponentEndOverlapSignature__DelegateSignature
// Size: 0x1C(Inherited: 0x0) 
struct FBndEvt__Sphere_K2Node_ComponentBoundEvent_7_ComponentEndOverlapSignature__DelegateSignature
{
	struct UPrimitiveComponent* OverlappedComponent;  // 0x0(0x8)
	struct AActor* OtherActor;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	int32_t OtherBodyIndex;  // 0x18(0x4)

}; 
// Function BP_BlendTriggerSphere.BP_BlendTriggerSphere_C.ExecuteUbergraph_BP_BlendTriggerSphere
// Size: 0x211(Inherited: 0x0) 
struct FExecuteUbergraph_BP_BlendTriggerSphere
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OverlappedComponent;  // 0x8(0x8)
	struct AActor* K2Node_ComponentBoundEvent_OtherActor;  // 0x10(0x8)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OtherComp;  // 0x18(0x8)
	int32_t K2Node_ComponentBoundEvent_OtherBodyIndex;  // 0x20(0x4)
	char pad_36_1 : 7;  // 0x24(0x1)
	bool CallFunc_CheckCollisionMatch_ActorComponentCondition : 1;  // 0x24(0x1)
	char pad_37[3];  // 0x25(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x28(0x10)
	float K2Node_Event_DeltaSeconds;  // 0x38(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x3C(0x4)
	int32_t Temp_int_Array_Index_Variable_2;  // 0x40(0x4)
	char pad_68[4];  // 0x44(0x4)
	struct UObject* CallFunc_Array_Get_Item;  // 0x48(0x8)
	struct AActor* CallFunc_Array_Get_Item_2;  // 0x50(0x8)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x58(0x1)
	char pad_89[7];  // 0x59(0x7)
	struct UObject* CallFunc_Array_Get_Item_3;  // 0x60(0x8)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool CallFunc_Array_IsValidIndex_ReturnValue : 1;  // 0x68(0x1)
	char pad_105_1 : 7;  // 0x69(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x69(0x1)
	char pad_106[2];  // 0x6A(0x2)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x6C(0x4)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool CallFunc_Array_IsValidIndex_ReturnValue_2 : 1;  // 0x70(0x1)
	char pad_113[3];  // 0x71(0x3)
	int32_t CallFunc_Array_Length_ReturnValue_2;  // 0x74(0x4)
	struct ASurvivalPlayerCharacter* CallFunc_GetLocalSurvivalPlayerCharacter_ReturnValue;  // 0x78(0x8)
	char pad_128_1 : 7;  // 0x80(0x1)
	bool CallFunc_IsOverlappingActor_ReturnValue : 1;  // 0x80(0x1)
	char pad_129[3];  // 0x81(0x3)
	int32_t CallFunc_Array_Length_ReturnValue_3;  // 0x84(0x4)
	char pad_136_1 : 7;  // 0x88(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue : 1;  // 0x88(0x1)
	char pad_137[7];  // 0x89(0x7)
	struct APlayerController* K2Node_CustomEvent_Controller;  // 0x90(0x8)
	char pad_152_1 : 7;  // 0x98(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x98(0x1)
	char pad_153_1 : 7;  // 0x99(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_2 : 1;  // 0x99(0x1)
	char pad_154_1 : 7;  // 0x9A(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x9A(0x1)
	char pad_155_1 : 7;  // 0x9B(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_3 : 1;  // 0x9B(0x1)
	char pad_156_1 : 7;  // 0x9C(0x1)
	bool CallFunc_BooleanAND_ReturnValue_2 : 1;  // 0x9C(0x1)
	char pad_157[3];  // 0x9D(0x3)
	struct UObject* CallFunc_Array_Get_Item_4;  // 0xA0(0x8)
	char pad_168_1 : 7;  // 0xA8(0x1)
	bool CallFunc_Array_IsValidIndex_ReturnValue_3 : 1;  // 0xA8(0x1)
	char pad_169_1 : 7;  // 0xA9(0x1)
	bool CallFunc_IsValid_ReturnValue_3 : 1;  // 0xA9(0x1)
	char pad_170[2];  // 0xAA(0x2)
	int32_t CallFunc_Array_Length_ReturnValue_4;  // 0xAC(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0xB0(0x4)
	char pad_180[4];  // 0xB4(0x4)
	struct ABP_VolumeFog_C* CallFunc_Array_Get_Item_5;  // 0xB8(0x8)
	char pad_192_1 : 7;  // 0xC0(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0xC0(0x1)
	char pad_193[3];  // 0xC1(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0xC4(0x4)
	struct UObject* CallFunc_Array_Get_Item_6;  // 0xC8(0x8)
	char pad_208_1 : 7;  // 0xD0(0x1)
	bool CallFunc_Array_IsValidIndex_ReturnValue_4 : 1;  // 0xD0(0x1)
	char pad_209_1 : 7;  // 0xD1(0x1)
	bool CallFunc_IsValid_ReturnValue_4 : 1;  // 0xD1(0x1)
	char pad_210[2];  // 0xD2(0x2)
	int32_t CallFunc_Array_Length_ReturnValue_5;  // 0xD4(0x4)
	int32_t Temp_int_Loop_Counter_Variable_2;  // 0xD8(0x4)
	int32_t Temp_int_Array_Index_Variable_3;  // 0xDC(0x4)
	struct ABP_VolumeFog_C* CallFunc_Array_Get_Item_7;  // 0xE0(0x8)
	char pad_232_1 : 7;  // 0xE8(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_2 : 1;  // 0xE8(0x1)
	char pad_233[3];  // 0xE9(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0xEC(0x4)
	struct ASurvivalGameState* CallFunc_GetSurvivalGameState_ReturnValue;  // 0xF0(0x8)
	char pad_248_1 : 7;  // 0xF8(0x1)
	bool CallFunc_GetInCutscene_ReturnValue : 1;  // 0xF8(0x1)
	char pad_249[3];  // 0xF9(0x3)
	int32_t Temp_int_Array_Index_Variable_4;  // 0xFC(0x4)
	char pad_256_1 : 7;  // 0x100(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_4 : 1;  // 0x100(0x1)
	char pad_257[7];  // 0x101(0x7)
	struct ABP_VolumeFog_C* CallFunc_Array_Get_Item_8;  // 0x108(0x8)
	char pad_272_1 : 7;  // 0x110(0x1)
	bool CallFunc_BooleanAND_ReturnValue_3 : 1;  // 0x110(0x1)
	char pad_273[3];  // 0x111(0x3)
	int32_t Temp_int_Loop_Counter_Variable_3;  // 0x114(0x4)
	int32_t Temp_int_Loop_Counter_Variable_4;  // 0x118(0x4)
	char pad_284_1 : 7;  // 0x11C(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_3 : 1;  // 0x11C(0x1)
	char pad_285[3];  // 0x11D(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue_3;  // 0x120(0x4)
	char pad_292_1 : 7;  // 0x124(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_4 : 1;  // 0x124(0x1)
	char pad_293[3];  // 0x125(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue_4;  // 0x128(0x4)
	char pad_300[4];  // 0x12C(0x4)
	struct ASurvivalPlayerController* CallFunc_GetLocalSurvivalPlayerController_ReturnValue;  // 0x130(0x8)
	struct ABP_SurvivalPlayerController_C* K2Node_DynamicCast_AsBP_Survival_Player_Controller;  // 0x138(0x8)
	char pad_320_1 : 7;  // 0x140(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x140(0x1)
	char pad_321[7];  // 0x141(0x7)
	struct ASurvivalPlayerController* CallFunc_GetLocalSurvivalPlayerController_ReturnValue_2;  // 0x148(0x8)
	struct ASurvivalPlayerController* CallFunc_GetLocalSurvivalPlayerController_ReturnValue_3;  // 0x150(0x8)
	struct ABP_SurvivalPlayerController_C* K2Node_DynamicCast_AsBP_Survival_Player_Controller_2;  // 0x158(0x8)
	char pad_352_1 : 7;  // 0x160(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x160(0x1)
	char pad_353[7];  // 0x161(0x7)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OverlappedComponent_2;  // 0x168(0x8)
	struct AActor* K2Node_ComponentBoundEvent_OtherActor_2;  // 0x170(0x8)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OtherComp_2;  // 0x178(0x8)
	int32_t K2Node_ComponentBoundEvent_OtherBodyIndex_2;  // 0x180(0x4)
	char pad_388_1 : 7;  // 0x184(0x1)
	bool K2Node_ComponentBoundEvent_bFromSweep : 1;  // 0x184(0x1)
	char pad_389[3];  // 0x185(0x3)
	struct FHitResult K2Node_ComponentBoundEvent_SweepResult;  // 0x188(0x88)
	char pad_528_1 : 7;  // 0x210(0x1)
	bool CallFunc_CheckCollisionMatch_ActorComponentCondition_2 : 1;  // 0x210(0x1)

}; 
// Function BP_BlendTriggerSphere.BP_BlendTriggerSphere_C.BndEvt__Sphere_K2Node_ComponentBoundEvent_4_ComponentBeginOverlapSignature__DelegateSignature
// Size: 0xA8(Inherited: 0x0) 
struct FBndEvt__Sphere_K2Node_ComponentBoundEvent_4_ComponentBeginOverlapSignature__DelegateSignature
{
	struct UPrimitiveComponent* OverlappedComponent;  // 0x0(0x8)
	struct AActor* OtherActor;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	int32_t OtherBodyIndex;  // 0x18(0x4)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool bFromSweep : 1;  // 0x1C(0x1)
	char pad_29[3];  // 0x1D(0x3)
	struct FHitResult SweepResult;  // 0x20(0x88)

}; 
// Function BP_BlendTriggerSphere.BP_BlendTriggerSphere_C.HandleEndOverlapRespawn
// Size: 0x8(Inherited: 0x0) 
struct FHandleEndOverlapRespawn
{
	struct APlayerController* Controller;  // 0x0(0x8)

}; 
// Function BP_BlendTriggerSphere.BP_BlendTriggerSphere_C.ReceiveTick
// Size: 0x4(Inherited: 0x4) 
struct FReceiveTick : public FReceiveTick
{
	float DeltaSeconds;  // 0x0(0x4)

}; 
// Function BP_BlendTriggerSphere.BP_BlendTriggerSphere_C.TrackTriggerOverlap
// Size: 0x4(Inherited: 0x0) 
struct FTrackTriggerOverlap
{
	int32_t IncrementValue;  // 0x0(0x4)

}; 
// Function BP_BlendTriggerSphere.BP_BlendTriggerSphere_C.CheckCollisionMatch
// Size: 0x22(Inherited: 0x0) 
struct FCheckCollisionMatch
{
	struct UPrimitiveComponent* OtherComponent;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ActorComponentCondition : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct ASurvivalPlayerCharacter* CallFunc_GetLocalSurvivalPlayerCharacter_ReturnValue;  // 0x10(0x8)
	struct ABP_SurvivalPlayerCharacter_C* K2Node_DynamicCast_AsBP_Survival_Player_Character;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x20(0x1)
	char pad_33_1 : 7;  // 0x21(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue : 1;  // 0x21(0x1)

}; 
