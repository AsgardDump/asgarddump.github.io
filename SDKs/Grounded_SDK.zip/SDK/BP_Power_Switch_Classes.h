#pragma once 
#include <BP_Power_Switch_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Power_Switch.BP_Power_Switch_C
// Size: 0x319(Inherited: 0x288) 
struct ABP_Power_Switch_C : public ASwitch
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x288(0x8)
	struct UAudioComponent* LeverLoopAudio;  // 0x290(0x8)
	struct UBoxComponent* Box;  // 0x298(0x8)
	struct UStaticMeshComponent* SM_Power_Switch_B;  // 0x2A0(0x8)
	struct UStaticMeshComponent* SM_Power_Switch_A;  // 0x2A8(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x2B0(0x8)
	float Timeline___SFX_Pitch_Pitch_4706CE364EDCA45B849DAC8249522827;  // 0x2B8(0x4)
	char ETimelineDirection Timeline___SFX_Pitch__Direction_4706CE364EDCA45B849DAC8249522827;  // 0x2BC(0x1)
	char pad_701[3];  // 0x2BD(0x3)
	struct UTimelineComponent* Timeline - SFX Pitch;  // 0x2C0(0x8)
	float Timeline_0_Driver_CA528E8F401A79529E8ACC906530DBFB;  // 0x2C8(0x4)
	char ETimelineDirection Timeline_0__Direction_CA528E8F401A79529E8ACC906530DBFB;  // 0x2CC(0x1)
	char pad_717[3];  // 0x2CD(0x3)
	struct UTimelineComponent* Timeline_1;  // 0x2D0(0x8)
	struct FLinearColor OnLightColor;  // 0x2D8(0x10)
	struct FLinearColor OffLightColor;  // 0x2E8(0x10)
	struct USoundBase* Lever Up SFX;  // 0x2F8(0x8)
	struct USoundBase* Lever Down SFX;  // 0x300(0x8)
	char pad_776_1 : 7;  // 0x308(0x1)
	bool IsReadyForAudio : 1;  // 0x308(0x1)
	char pad_777[7];  // 0x309(0x7)
	struct USoundBase* LeverLoopSFX;  // 0x310(0x8)
	char pad_792_1 : 7;  // 0x318(0x1)
	bool SwapLightColorAndSwitchDir : 1;  // 0x318(0x1)

	void UserConstructionScript(); // Function BP_Power_Switch.BP_Power_Switch_C.UserConstructionScript
	void Timeline_0__FinishedFunc(); // Function BP_Power_Switch.BP_Power_Switch_C.Timeline_0__FinishedFunc
	void Timeline_0__UpdateFunc(); // Function BP_Power_Switch.BP_Power_Switch_C.Timeline_0__UpdateFunc
	void Timeline - SFX Pitch__FinishedFunc(); // Function BP_Power_Switch.BP_Power_Switch_C.Timeline - SFX Pitch__FinishedFunc
	void Timeline - SFX Pitch__UpdateFunc(); // Function BP_Power_Switch.BP_Power_Switch_C.Timeline - SFX Pitch__UpdateFunc
	void ReceiveBeginPlay(); // Function BP_Power_Switch.BP_Power_Switch_C.ReceiveBeginPlay
	void OnUpdateVisualState(bool IsOpen); // Function BP_Power_Switch.BP_Power_Switch_C.OnUpdateVisualState
	void HandleOpenAudio(); // Function BP_Power_Switch.BP_Power_Switch_C.HandleOpenAudio
	void HandleClosedAudio(); // Function BP_Power_Switch.BP_Power_Switch_C.HandleClosedAudio
	void TimelineFinished(); // Function BP_Power_Switch.BP_Power_Switch_C.TimelineFinished
	void ExecuteUbergraph_BP_Power_Switch(int32_t EntryPoint); // Function BP_Power_Switch.BP_Power_Switch_C.ExecuteUbergraph_BP_Power_Switch
}; 



