#pragma once 
#include <BP_Pupa_Physics_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Pupa_Physics.BP_Pupa_Physics_C
// Size: 0x349(Inherited: 0x349) 
struct ABP_Pupa_Physics_C : public ABP_PhysicsHarvestNode_C
{

}; 



