#pragma once 
#include <BP_BurgleQuestMarkerPoint_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_BurgleQuestMarkerPoint.BP_BurgleQuestMarkerPoint_C
// Size: 0x699(Inherited: 0x690) 
struct ABP_BurgleQuestMarkerPoint_C : public ABP_MarkerBuilding_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x690(0x8)
	char pad_1688_1 : 7;  // 0x698(0x1)
	bool bLoadValidated : 1;  // 0x698(0x1)

	void ProcessLoadData(); // Function BP_BurgleQuestMarkerPoint.BP_BurgleQuestMarkerPoint_C.ProcessLoadData
	void ExecuteUbergraph_BP_BurgleQuestMarkerPoint(int32_t EntryPoint); // Function BP_BurgleQuestMarkerPoint.BP_BurgleQuestMarkerPoint_C.ExecuteUbergraph_BP_BurgleQuestMarkerPoint
}; 



