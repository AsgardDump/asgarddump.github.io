#pragma once 
#include <BP_Lab_Door_A_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Lab_Door_A.BP_Lab_Door_A_C
// Size: 0x489(Inherited: 0x288) 
struct ABP_Lab_Door_A_C : public ADoor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x288(0x8)
	struct UPointLightComponent* PointLight1;  // 0x290(0x8)
	struct UPointLightComponent* PointLight;  // 0x298(0x8)
	struct UMaineStaticMeshComponent* SM_Key_Card_Reader1;  // 0x2A0(0x8)
	struct UMaineStaticMeshComponent* SM_Key_Card_Reader;  // 0x2A8(0x8)
	struct UStaticMeshComponent* SM_Door_Lock_Indicator_A_02;  // 0x2B0(0x8)
	struct UStaticMeshComponent* SM_Door_Lock_Indicator_A_01;  // 0x2B8(0x8)
	struct UAudioComponent* DirectionAudio;  // 0x2C0(0x8)
	struct UStaticMeshComponent* TS_Lab_Round_Hll_DoorWay_C_Bolt_04;  // 0x2C8(0x8)
	struct UStaticMeshComponent* TS_Lab_Round_Hll_DoorWay_C_Bolt_03;  // 0x2D0(0x8)
	struct UStaticMeshComponent* TS_Lab_Round_Hll_DoorWay_C_Bolt_02;  // 0x2D8(0x8)
	struct UStaticMeshComponent* TS_Lab_Round_Hll_DoorWay_C_Bolt_01;  // 0x2E0(0x8)
	struct UStaticMeshComponent* TS_Lab_Round_Hll_DoorWay_B_Bolt_04;  // 0x2E8(0x8)
	struct UStaticMeshComponent* TS_Lab_Round_Hll_DoorWay_B_Bolt_03;  // 0x2F0(0x8)
	struct UStaticMeshComponent* TS_Lab_Round_Hll_DoorWay_B_Bolt_02;  // 0x2F8(0x8)
	struct UStaticMeshComponent* TS_Lab_Round_Hll_DoorWay_B_Bolt_01;  // 0x300(0x8)
	struct UStaticMeshComponent* TS_Lab_Round_Hll_DoorWay_A_Bolt_04;  // 0x308(0x8)
	struct UStaticMeshComponent* TS_Lab_Round_Hll_DoorWay_A_Bolt_03;  // 0x310(0x8)
	struct UStaticMeshComponent* TS_Lab_Round_Hll_DoorWay_A_Bolt_02;  // 0x318(0x8)
	struct UStaticMeshComponent* TS_Lab_Round_Hll_DoorWay_A_Bolt_01;  // 0x320(0x8)
	struct UStaticMeshComponent* TS_Lab_Round_Hll_DoorWay_C_NoBolts;  // 0x328(0x8)
	struct UStaticMeshComponent* TS_Lab_Round_Hll_DoorWay_B_NoBolts;  // 0x330(0x8)
	struct UStaticMeshComponent* TS_Lab_Round_Hll_DoorWay_A_NoBolts;  // 0x338(0x8)
	struct UStaticMeshComponent* TS_Lab_Door_A_04;  // 0x340(0x8)
	struct UStaticMeshComponent* TS_Lab_Door_A_05;  // 0x348(0x8)
	struct UStaticMeshComponent* TS_Lab_Door_A_02;  // 0x350(0x8)
	struct UStaticMeshComponent* TS_Lab_Door_A_03;  // 0x358(0x8)
	struct UBoxComponent* Box;  // 0x360(0x8)
	struct UStaticMeshComponent* TS_Lab_Door_A_06;  // 0x368(0x8)
	struct UStaticMeshComponent* TS_Lab_Door_A_01;  // 0x370(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x378(0x8)
	char ETimelineDirection DoorSound__Direction_D1308DDA4595E1153C23E7A77A6E7FE0;  // 0x380(0x1)
	char pad_897[7];  // 0x381(0x7)
	struct UTimelineComponent* DoorSound;  // 0x388(0x8)
	float Timeline_0_BoltsSpin_A8EA40214D549441765FAE943FF3B84E;  // 0x390(0x4)
	float Timeline_0_OpeningPhase03_A8EA40214D549441765FAE943FF3B84E;  // 0x394(0x4)
	float Timeline_0_OpeningPhase02_A8EA40214D549441765FAE943FF3B84E;  // 0x398(0x4)
	float Timeline_0_OpeningPhase01_A8EA40214D549441765FAE943FF3B84E;  // 0x39C(0x4)
	char ETimelineDirection Timeline_0__Direction_A8EA40214D549441765FAE943FF3B84E;  // 0x3A0(0x1)
	char pad_929[7];  // 0x3A1(0x7)
	struct UTimelineComponent* Timeline_1;  // 0x3A8(0x8)
	char pad_944_1 : 7;  // 0x3B0(0x1)
	bool Hide_Lock_Indicators : 1;  // 0x3B0(0x1)
	char pad_945_1 : 7;  // 0x3B1(0x1)
	bool IsDirty : 1;  // 0x3B1(0x1)
	char pad_946[2];  // 0x3B2(0x2)
	int32_t DoorwayType;  // 0x3B4(0x4)
	struct TArray<struct AActor*> ActorsOverlapped;  // 0x3B8(0x10)
	struct FLinearColor Locked_Color;  // 0x3C8(0x10)
	struct FLinearColor Unlocked_Color;  // 0x3D8(0x10)
	struct FMulticastInlineDelegate OnLockedChanged_ServerOnly;  // 0x3E8(0x10)
	struct FMulticastInlineDelegate OnDoorOpen;  // 0x3F8(0x10)
	struct FMulticastInlineDelegate OnDoorClosed;  // 0x408(0x10)
	struct FMulticastInlineDelegate OnDoorOpen_ServerOnly;  // 0x418(0x10)
	struct FMulticastInlineDelegate OnDoorClosed_ServerOnly;  // 0x428(0x10)
	struct TSoftObjectPtr<ASwitch> ControllingSwitch;  // 0x438(0x28)
	struct TSoftObjectPtr<AScanSwitch> ScanningSwitch;  // 0x460(0x28)
	char pad_1160_1 : 7;  // 0x488(0x1)
	bool Hide_Key_Card_Reader : 1;  // 0x488(0x1)

	void DebugShowControllingSwitch(); // Function BP_Lab_Door_A.BP_Lab_Door_A_C.DebugShowControllingSwitch
	void OnControllingSwitchOpenStateChanged(bool IsOpen, struct AActor* Instigator); // Function BP_Lab_Door_A.BP_Lab_Door_A_C.OnControllingSwitchOpenStateChanged
	void UserConstructionScript(); // Function BP_Lab_Door_A.BP_Lab_Door_A_C.UserConstructionScript
	void Timeline_0__FinishedFunc(); // Function BP_Lab_Door_A.BP_Lab_Door_A_C.Timeline_0__FinishedFunc
	void Timeline_0__UpdateFunc(); // Function BP_Lab_Door_A.BP_Lab_Door_A_C.Timeline_0__UpdateFunc
	void DoorSound__FinishedFunc(); // Function BP_Lab_Door_A.BP_Lab_Door_A_C.DoorSound__FinishedFunc
	void DoorSound__UpdateFunc(); // Function BP_Lab_Door_A.BP_Lab_Door_A_C.DoorSound__UpdateFunc
	void BndEvt__Box_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult& SweepResult); // Function BP_Lab_Door_A.BP_Lab_Door_A_C.BndEvt__Box_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature
	void OnOpenDoor(); // Function BP_Lab_Door_A.BP_Lab_Door_A_C.OnOpenDoor
	void OnCloseDoor(); // Function BP_Lab_Door_A.BP_Lab_Door_A_C.OnCloseDoor
	void BndEvt__Box_K2Node_ComponentBoundEvent_1_ComponentEndOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex); // Function BP_Lab_Door_A.BP_Lab_Door_A_C.BndEvt__Box_K2Node_ComponentBoundEvent_1_ComponentEndOverlapSignature__DelegateSignature
	void SetLocked(bool Locked); // Function BP_Lab_Door_A.BP_Lab_Door_A_C.SetLocked
	void EvaluateDoorState(); // Function BP_Lab_Door_A.BP_Lab_Door_A_C.EvaluateDoorState
	void OnLockStateChanged(bool IsLocked); // Function BP_Lab_Door_A.BP_Lab_Door_A_C.OnLockStateChanged
	void OnUpdateVisualState(bool IsOpen); // Function BP_Lab_Door_A.BP_Lab_Door_A_C.OnUpdateVisualState
	void ReceiveBeginPlay(); // Function BP_Lab_Door_A.BP_Lab_Door_A_C.ReceiveBeginPlay
	void UpdateLockIndicatorVisual(); // Function BP_Lab_Door_A.BP_Lab_Door_A_C.UpdateLockIndicatorVisual
	void BndEvt__BP_Lab_Door_A_TerminalSwitchListener_K2Node_ComponentBoundEvent_2_OnTerminalStateChange__DelegateSignature(struct ATerminalSwitch* Terminal, struct FTerminalConditional& ConditionalState); // Function BP_Lab_Door_A.BP_Lab_Door_A_C.BndEvt__BP_Lab_Door_A_TerminalSwitchListener_K2Node_ComponentBoundEvent_2_OnTerminalStateChange__DelegateSignature
	void ExecuteUbergraph_BP_Lab_Door_A(int32_t EntryPoint); // Function BP_Lab_Door_A.BP_Lab_Door_A_C.ExecuteUbergraph_BP_Lab_Door_A
	void OnDoorClosed_ServerOnly__DelegateSignature(); // Function BP_Lab_Door_A.BP_Lab_Door_A_C.OnDoorClosed_ServerOnly__DelegateSignature
	void OnDoorOpen_ServerOnly__DelegateSignature(); // Function BP_Lab_Door_A.BP_Lab_Door_A_C.OnDoorOpen_ServerOnly__DelegateSignature
	void OnDoorClosed__DelegateSignature(); // Function BP_Lab_Door_A.BP_Lab_Door_A_C.OnDoorClosed__DelegateSignature
	void OnDoorOpen__DelegateSignature(); // Function BP_Lab_Door_A.BP_Lab_Door_A_C.OnDoorOpen__DelegateSignature
	void OnLockedChanged_ServerOnly__DelegateSignature(); // Function BP_Lab_Door_A.BP_Lab_Door_A_C.OnLockedChanged_ServerOnly__DelegateSignature
}; 



