#pragma once 
#include <BP_ChoppingSlashingDamage_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_ChoppingSlashingDamage.BP_ChoppingSlashingDamage_C
// Size: 0x78(Inherited: 0x78) 
struct UBP_ChoppingSlashingDamage_C : public USurvivalDamageType
{

}; 



