#pragma once 
#include <BP_Explosive_VFX_Base_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Explosive_VFX_Base.BP_Explosive_VFX_Base_C
// Size: 0x34C(Inherited: 0x230) 
struct ABP_Explosive_VFX_Base_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x230(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x238(0x8)
	float TL_DecalEmissive_EmissiveValue_9B9CF44D45DA457CEDFE1C87FA58BA41;  // 0x240(0x4)
	char ETimelineDirection TL_DecalEmissive__Direction_9B9CF44D45DA457CEDFE1C87FA58BA41;  // 0x244(0x1)
	char pad_581[3];  // 0x245(0x3)
	struct UTimelineComponent* TL_DecalEmissive;  // 0x248(0x8)
	struct UMaterialInterface* DecalSourceMaterial;  // 0x250(0x8)
	struct UMaterialInstanceDynamic* DecalMID;  // 0x258(0x8)
	char pad_608_1 : 7;  // 0x260(0x1)
	bool ReturnHit : 1;  // 0x260(0x1)
	char pad_609[7];  // 0x261(0x7)
	struct TArray<struct FHitResult> OutHits;  // 0x268(0x10)
	struct TArray<struct FVector> ImpactNormals;  // 0x278(0x10)
	struct FVector ImpactNormalAverage;  // 0x288(0xC)
	struct FVector ImpactPoint;  // 0x294(0xC)
	char pad_672_1 : 7;  // 0x2A0(0x1)
	bool DownwardTrace : 1;  // 0x2A0(0x1)
	char pad_673[3];  // 0x2A1(0x3)
	float LengthOfDownwardTrace;  // 0x2A4(0x4)
	float LengthOfMultidirectionalTrace;  // 0x2A8(0x4)
	struct FName TraceProfile;  // 0x2AC(0x8)
	char pad_692[4];  // 0x2B4(0x4)
	struct UDecalComponent* SpawnedDecal;  // 0x2B8(0x8)
	struct FVector DecalSize;  // 0x2C0(0xC)
	float FadeDelay;  // 0x2CC(0x4)
	float FadeOutDuration;  // 0x2D0(0x4)
	char pad_724[4];  // 0x2D4(0x4)
	struct TArray<struct UParticleSystem*> PrimaryEmitters;  // 0x2D8(0x10)
	UMatineeCameraShake* CameraShake;  // 0x2E8(0x8)
	float CameraShakeRadius;  // 0x2F0(0x4)
	char pad_756[4];  // 0x2F4(0x4)
	struct TArray<struct UNiagaraSystem*> PrimaryEmittersNiagara;  // 0x2F8(0x10)
	struct UParticleSystem* SurfaceEmitter;  // 0x308(0x8)
	struct USoundBase* SFX_Explosion;  // 0x310(0x8)
	struct USoundBase* SFX_PostExplosion_Surface;  // 0x318(0x8)
	struct UNiagaraSystem* SurfaceEmitterNiagara;  // 0x320(0x8)
	float ParticleScale;  // 0x328(0x4)
	float FadeInDuration;  // 0x32C(0x4)
	char pad_816_1 : 7;  // 0x330(0x1)
	bool UseNiagara : 1;  // 0x330(0x1)
	char pad_817[7];  // 0x331(0x7)
	struct UParticleSystemComponent* SpawnedEmitter;  // 0x338(0x8)
	struct UNiagaraComponent* SpawnedNiagaraEmitter;  // 0x340(0x8)
	float CameraShakeFalloff;  // 0x348(0x4)

	void TL_DecalEmissive__FinishedFunc(); // Function BP_Explosive_VFX_Base.BP_Explosive_VFX_Base_C.TL_DecalEmissive__FinishedFunc
	void TL_DecalEmissive__UpdateFunc(); // Function BP_Explosive_VFX_Base.BP_Explosive_VFX_Base_C.TL_DecalEmissive__UpdateFunc
	void ReceiveBeginPlay(); // Function BP_Explosive_VFX_Base.BP_Explosive_VFX_Base_C.ReceiveBeginPlay
	void BndEvt__BP_Explosive_VFX_Base_SpawnedEmitter_K2Node_ComponentBoundEvent_1_OnSystemFinished__DelegateSignature(struct UParticleSystemComponent* PSystem); // Function BP_Explosive_VFX_Base.BP_Explosive_VFX_Base_C.BndEvt__BP_Explosive_VFX_Base_SpawnedEmitter_K2Node_ComponentBoundEvent_1_OnSystemFinished__DelegateSignature
	void BndEvt__BP_Explosive_VFX_Base_SpawnedNiagaraEmitter_K2Node_ComponentBoundEvent_2_OnNiagaraSystemFinished__DelegateSignature(struct UNiagaraComponent* PSystem); // Function BP_Explosive_VFX_Base.BP_Explosive_VFX_Base_C.BndEvt__BP_Explosive_VFX_Base_SpawnedNiagaraEmitter_K2Node_ComponentBoundEvent_2_OnNiagaraSystemFinished__DelegateSignature
	void ExecuteUbergraph_BP_Explosive_VFX_Base(int32_t EntryPoint); // Function BP_Explosive_VFX_Base.BP_Explosive_VFX_Base_C.ExecuteUbergraph_BP_Explosive_VFX_Base
}; 



