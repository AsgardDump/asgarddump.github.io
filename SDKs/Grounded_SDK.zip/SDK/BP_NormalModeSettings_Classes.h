#pragma once 
#include <BP_NormalModeSettings_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_NormalModeSettings.BP_NormalModeSettings_C
// Size: 0x78(Inherited: 0x78) 
struct UBP_NormalModeSettings_C : public USurvivalGameModeSettings
{

}; 



