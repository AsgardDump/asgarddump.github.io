#pragma once 
#include <BP_Pond_Moss_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Pond_Moss.BP_Pond_Moss_C
// Size: 0x370(Inherited: 0x368) 
struct ABP_Pond_Moss_C : public ABP_BASE_Stump_C
{
	struct UVisualStateComponent* VisualState;  // 0x368(0x8)

}; 



