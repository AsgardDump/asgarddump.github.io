#pragma once 
#include <BP_Bee_StandIn_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Bee_StandIn.BP_Bee_StandIn_C
// Size: 0x12C0(Inherited: 0x12C0) 
struct ABP_Bee_StandIn_C : public AProxyCharacterStandInActor
{

}; 



