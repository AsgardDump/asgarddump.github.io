#pragma once 
#include "SDK.h" 
 
 
// Function BP_PoweredBuildingCable.BP_PoweredBuildingCable_C.ExecuteUbergraph_BP_PoweredBuildingCable
// Size: 0x44(Inherited: 0x0) 
struct FExecuteUbergraph_BP_PoweredBuildingCable
{
	int32_t EntryPoint;  // 0x0(0x4)
	float K2Node_Event_DeltaSeconds;  // 0x4(0x4)
	struct FVector CallFunc_GetStartPosition_ReturnValue;  // 0x8(0xC)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x14(0x1)
	char pad_21[3];  // 0x15(0x3)
	struct FLinearColor CallFunc_Conv_VectorToLinearColor_ReturnValue;  // 0x18(0x10)
	struct FVector CallFunc_GetEndPosition_ReturnValue;  // 0x28(0xC)
	struct FLinearColor CallFunc_Conv_VectorToLinearColor_ReturnValue_2;  // 0x34(0x10)

}; 
// Function BP_PoweredBuildingCable.BP_PoweredBuildingCable_C.ReceiveTick
// Size: 0x4(Inherited: 0x4) 
struct FReceiveTick : public FReceiveTick
{
	float DeltaSeconds;  // 0x0(0x4)

}; 
// Function BP_PoweredBuildingCable.BP_PoweredBuildingCable_C.UserConstructionScript
// Size: 0x8(Inherited: 0x0) 
struct FUserConstructionScript : public FUserConstructionScript
{
	struct UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue;  // 0x0(0x8)

}; 
