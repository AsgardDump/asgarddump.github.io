#pragma once 
#include <BP_BASE_Eelgrass_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_BASE_Eelgrass.BP_BASE_Eelgrass_C
// Size: 0x4D0(Inherited: 0x420) 
struct ABP_BASE_Eelgrass_C : public ABP_ToppleHarvestNode_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x420(0x8)
	float TL_DissolveEelgrass_DissolveAmount_9AA54D5D4343D843BD6D9EB8A4E6241C;  // 0x428(0x4)
	char ETimelineDirection TL_DissolveEelgrass__Direction_9AA54D5D4343D843BD6D9EB8A4E6241C;  // 0x42C(0x1)
	char pad_1069[3];  // 0x42D(0x3)
	struct UTimelineComponent* TL_DissolveEelgrass;  // 0x430(0x8)
	struct TArray<struct FTransform> SocketTransforms;  // 0x438(0x10)
	char pad_1096_1 : 7;  // 0x448(0x1)
	bool DeathTriggered : 1;  // 0x448(0x1)
	char pad_1097[7];  // 0x449(0x7)
	struct UParticleSystem* DestroyedEmitter;  // 0x450(0x8)
	struct FDamageInfo DamageInfo;  // 0x458(0x68)
	struct TArray<struct UMaterialInstanceDynamic*> MIDs;  // 0x4C0(0x10)

	void OnRep_DeathTriggered(); // Function BP_BASE_Eelgrass.BP_BASE_Eelgrass_C.OnRep_DeathTriggered
	void TL_DissolveEelgrass__FinishedFunc(); // Function BP_BASE_Eelgrass.BP_BASE_Eelgrass_C.TL_DissolveEelgrass__FinishedFunc
	void TL_DissolveEelgrass__UpdateFunc(); // Function BP_BASE_Eelgrass.BP_BASE_Eelgrass_C.TL_DissolveEelgrass__UpdateFunc
	void ReceiveBeginPlay(); // Function BP_BASE_Eelgrass.BP_BASE_Eelgrass_C.ReceiveBeginPlay
	void HandleDeathEffects(); // Function BP_BASE_Eelgrass.BP_BASE_Eelgrass_C.HandleDeathEffects
	void Handle Death(struct FDamageInfo DamageInfo); // Function BP_BASE_Eelgrass.BP_BASE_Eelgrass_C.Handle Death
	void ExecuteUbergraph_BP_BASE_Eelgrass(int32_t EntryPoint); // Function BP_BASE_Eelgrass.BP_BASE_Eelgrass_C.ExecuteUbergraph_BP_BASE_Eelgrass
}; 



