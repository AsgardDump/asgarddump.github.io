#pragma once 
#include <BP_BombardierLeg_R_Front_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_BombardierLeg_R_Front.BP_BombardierLeg_R_Front_C
// Size: 0x2A3(Inherited: 0x2A3) 
struct ABP_BombardierLeg_R_Front_C : public ABP_InsectPart_C
{

}; 



