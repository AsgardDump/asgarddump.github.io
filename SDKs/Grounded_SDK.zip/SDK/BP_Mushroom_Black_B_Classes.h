#pragma once 
#include <BP_Mushroom_Black_B_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Mushroom_Black_B.BP_Mushroom_Black_B_C
// Size: 0x498(Inherited: 0x498) 
struct ABP_Mushroom_Black_B_C : public ABP_Mushroom_Black_A_C
{

}; 



