#pragma once 
#include "SDK.h" 
 
 
// Function BP_Control_Panel_Standing.BP_Control_Panel_Standing_C.ExecuteUbergraph_BP_Control_Panel_Standing
// Size: 0x20(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Control_Panel_Standing
{
	int32_t EntryPoint;  // 0x0(0x4)
	char ETimelineDirection Temp_byte_Variable;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	int32_t CallFunc_GetConsoleVariableIntValue_ReturnValue;  // 0x8(0x4)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool CallFunc_GreaterEqual_IntInt_ReturnValue : 1;  // 0xC(0x1)
	char ETimelineDirection K2Node_Event_TimelineDirection;  // 0xD(0x1)
	char pad_14[2];  // 0xE(0x2)
	struct FLinearColor K2Node_Select_Default;  // 0x10(0x10)

}; 
// Function BP_Control_Panel_Standing.BP_Control_Panel_Standing_C.UserConstructionScript
// Size: 0x22(Inherited: 0xC) 
struct FUserConstructionScript : public FUserConstructionScript
{
	char pad_12_1 : 7;  // 0xC(0x1)
	bool Temp_bool_Variable : 1;  // 0x0(0x1)
	struct UMaterialInterface* Temp_object_Variable;  // 0x8(0x8)
	struct UMaterialInterface* CallFunc_GetMaterial_ReturnValue;  // 0x10(0x8)
	struct UMaterialInterface* K2Node_Select_Default;  // 0x18(0x8)
	char pad_37_1 : 7;  // 0x25(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue : 1;  // 0x20(0x1)
	char pad_38_1 : 7;  // 0x26(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue_2 : 1;  // 0x21(0x1)

}; 
// Function BP_Control_Panel_Standing.BP_Control_Panel_Standing_C.ImplementableOnLightTimelineFinished
// Size: 0x1(Inherited: 0x1) 
struct FImplementableOnLightTimelineFinished : public FImplementableOnLightTimelineFinished
{
	char ETimelineDirection TimelineDirection;  // 0x0(0x1)

}; 
