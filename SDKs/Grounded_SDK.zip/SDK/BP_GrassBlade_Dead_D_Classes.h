#pragma once 
#include <BP_GrassBlade_Dead_D_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_GrassBlade_Dead_D.BP_GrassBlade_Dead_D_C
// Size: 0x418(Inherited: 0x418) 
struct ABP_GrassBlade_Dead_D_C : public ABP_BASE_GrassBlade_Dead_C
{

}; 



