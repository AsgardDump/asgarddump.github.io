#pragma once 
#include <BP_PoisonDamage_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_PoisonDamage.BP_PoisonDamage_C
// Size: 0x78(Inherited: 0x78) 
struct UBP_PoisonDamage_C : public USurvivalDamageType
{

}; 



