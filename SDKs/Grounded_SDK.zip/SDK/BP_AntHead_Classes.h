#pragma once 
#include <BP_AntHead_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_AntHead.BP_AntHead_C
// Size: 0x2A3(Inherited: 0x2A3) 
struct ABP_AntHead_C : public ABP_InsectPart_C
{

}; 



