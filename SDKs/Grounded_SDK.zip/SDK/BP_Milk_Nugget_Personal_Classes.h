#pragma once 
#include <BP_Milk_Nugget_Personal_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Milk_Nugget_Personal.BP_Milk_Nugget_Personal_C
// Size: 0x4A8(Inherited: 0x420) 
struct ABP_Milk_Nugget_Personal_C : public ABP_ToppleHarvestNode_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x420(0x8)
	struct UAudioComponent* SFX Obj Milk Molar Loop Cue;  // 0x428(0x8)
	struct USphereComponent* TutorialOverlap;  // 0x430(0x8)
	struct UPointLightComponent* CenterLight;  // 0x438(0x8)
	struct UArrowComponent* Arrow;  // 0x440(0x8)
	struct UStaticMeshComponent* MeshCenter;  // 0x448(0x8)
	struct UStaticMeshComponent* MeshK;  // 0x450(0x8)
	struct UStaticMeshComponent* MeshJ;  // 0x458(0x8)
	struct UStaticMeshComponent* MeshI;  // 0x460(0x8)
	struct UStaticMeshComponent* MeshH;  // 0x468(0x8)
	struct UStaticMeshComponent* MeshG;  // 0x470(0x8)
	struct UStaticMeshComponent* MeshF;  // 0x478(0x8)
	struct UStaticMeshComponent* MeshE;  // 0x480(0x8)
	struct UStaticMeshComponent* MeshD;  // 0x488(0x8)
	struct UStaticMeshComponent* MeshC;  // 0x490(0x8)
	struct UStaticMeshComponent* MeshB;  // 0x498(0x8)
	struct UTransmitterComponent* Transmitter;  // 0x4A0(0x8)

	bool ShouldRestoreTransform(); // Function BP_Milk_Nugget_Personal.BP_Milk_Nugget_Personal_C.ShouldRestoreTransform
	void ReceiveBeginPlay(); // Function BP_Milk_Nugget_Personal.BP_Milk_Nugget_Personal_C.ReceiveBeginPlay
	void BndEvt__BP_Milk_Nugget_Personal_TutorialOverlap_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult& SweepResult); // Function BP_Milk_Nugget_Personal.BP_Milk_Nugget_Personal_C.BndEvt__BP_Milk_Nugget_Personal_TutorialOverlap_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature
	void SetLightShadowSettings(); // Function BP_Milk_Nugget_Personal.BP_Milk_Nugget_Personal_C.SetLightShadowSettings
	void DestroyChunk(struct UStaticMeshComponent* Chunk); // Function BP_Milk_Nugget_Personal.BP_Milk_Nugget_Personal_C.DestroyChunk
	void BndEvt__BP_Milk_Nugget_Personal_HealthComponent_K2Node_ComponentBoundEvent_1_HealthChangedDelegate__DelegateSignature(struct UHealthComponent* SourceHealthComponent, float NewHealth, float OldHealth); // Function BP_Milk_Nugget_Personal.BP_Milk_Nugget_Personal_C.BndEvt__BP_Milk_Nugget_Personal_HealthComponent_K2Node_ComponentBoundEvent_1_HealthChangedDelegate__DelegateSignature
	void ExecuteUbergraph_BP_Milk_Nugget_Personal(int32_t EntryPoint); // Function BP_Milk_Nugget_Personal.BP_Milk_Nugget_Personal_C.ExecuteUbergraph_BP_Milk_Nugget_Personal
}; 



