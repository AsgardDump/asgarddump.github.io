#pragma once 
#include <BP_HedgeBerryA_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_HedgeBerryA.BP_HedgeBerryA_C
// Size: 0x370(Inherited: 0x349) 
struct ABP_HedgeBerryA_C : public ABP_PhysicsHarvestNode_C
{
	char pad_841[7];  // 0x349(0x7)
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x350(0x8)
	struct UVisualStateComponent* VisualState;  // 0x358(0x8)
	char pad_864_1 : 7;  // 0x360(0x1)
	bool Squishmode : 1;  // 0x360(0x1)
	char pad_865_1 : 7;  // 0x361(0x1)
	bool PreSquashed : 1;  // 0x361(0x1)
	char pad_866[6];  // 0x362(0x6)
	struct UStaticMesh* SquishmodeMesh;  // 0x368(0x8)

	void UpdateStaticMesh(); // Function BP_HedgeBerryA.BP_HedgeBerryA_C.UpdateStaticMesh
	void OnRep_Squishmode(); // Function BP_HedgeBerryA.BP_HedgeBerryA_C.OnRep_Squishmode
	void UserConstructionScript(); // Function BP_HedgeBerryA.BP_HedgeBerryA_C.UserConstructionScript
	void BndEvt__StaticMesh_K2Node_ComponentBoundEvent_0_ComponentHitSignature__DelegateSignature(struct UPrimitiveComponent* HitComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, struct FVector NormalImpulse, struct FHitResult& Hit); // Function BP_HedgeBerryA.BP_HedgeBerryA_C.BndEvt__StaticMesh_K2Node_ComponentBoundEvent_0_ComponentHitSignature__DelegateSignature
	void ExecuteUbergraph_BP_HedgeBerryA(int32_t EntryPoint); // Function BP_HedgeBerryA.BP_HedgeBerryA_C.ExecuteUbergraph_BP_HedgeBerryA
}; 



