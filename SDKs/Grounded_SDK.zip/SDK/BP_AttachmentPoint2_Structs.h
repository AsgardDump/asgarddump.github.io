#pragma once 
#include "SDK.h" 
 
 
// Function BP_AttachmentPoint2.BP_AttachmentPoint2_C.ExecuteUbergraph_BP_AttachmentPoint2
// Size: 0x8(Inherited: 0x0) 
struct FExecuteUbergraph_BP_AttachmentPoint2
{
	int32_t EntryPoint;  // 0x0(0x4)
	float K2Node_Event_DeltaSeconds;  // 0x4(0x4)

}; 
// Function BP_AttachmentPoint2.BP_AttachmentPoint2_C.ReceiveTick
// Size: 0x4(Inherited: 0x4) 
struct FReceiveTick : public FReceiveTick
{
	float DeltaSeconds;  // 0x0(0x4)

}; 
