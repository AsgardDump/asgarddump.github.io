#pragma once 
#include "SDK.h" 
 
 
// Function BP_Landscape_RT_Manager.BP_Landscape_RT_Manager_C.ReceiveTick
// Size: 0x4(Inherited: 0x4) 
struct FReceiveTick : public FReceiveTick
{
	float DeltaSeconds;  // 0x0(0x4)

}; 
// Function BP_Landscape_RT_Manager.BP_Landscape_RT_Manager_C.ExecuteUbergraph_BP_Landscape_RT_Manager
// Size: 0x169(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Landscape_RT_Manager
{
	int32_t EntryPoint;  // 0x0(0x4)
	struct FLinearColor CallFunc_GetVectorParameterValue_ReturnValue;  // 0x4(0x10)
	float K2Node_Event_DeltaSeconds;  // 0x14(0x4)
	struct UCapsuleComponent* CallFunc_GetLocalSurvivalPlayerCapsule_ReturnValue;  // 0x18(0x8)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue;  // 0x20(0xC)
	struct FVector CallFunc_GetObjectUVCoords_UV_Grid;  // 0x2C(0xC)
	struct FVector CallFunc_GetObjectUVCoords_UV_Segment;  // 0x38(0xC)
	struct FLinearColor CallFunc_Conv_VectorToLinearColor_ReturnValue;  // 0x44(0x10)
	struct FLinearColor CallFunc_Conv_VectorToLinearColor_ReturnValue_2;  // 0x54(0x10)
	struct FLinearColor CallFunc_Conv_VectorToLinearColor_ReturnValue_3;  // 0x64(0x10)
	struct FLinearColor CallFunc_Conv_VectorToLinearColor_ReturnValue_4;  // 0x74(0x10)
	struct FLinearColor CallFunc_GetVectorParameterValue_ReturnValue_2;  // 0x84(0x10)
	char pad_148[4];  // 0x94(0x4)
	struct ASurvivalPlayerCharacter* CallFunc_GetLocalSurvivalPlayerCharacter_ReturnValue;  // 0x98(0x8)
	struct ASurvivalPlayerCharacter* CallFunc_GetLocalSurvivalPlayerCharacter_ReturnValue_2;  // 0xA0(0x8)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0xA8(0xC)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_2;  // 0xB4(0xC)
	struct FLinearColor CallFunc_Conv_VectorToLinearColor_ReturnValue_5;  // 0xC0(0x10)
	struct FVector CallFunc_GetObjectUVCoords_UV_Grid_2;  // 0xD0(0xC)
	struct FVector CallFunc_GetObjectUVCoords_UV_Segment_2;  // 0xDC(0xC)
	struct FVector CallFunc_Conv_LinearColorToVector_ReturnValue;  // 0xE8(0xC)
	struct FVector CallFunc_Conv_LinearColorToVector_ReturnValue_2;  // 0xF4(0xC)
	char pad_256_1 : 7;  // 0x100(0x1)
	bool CallFunc_EqualEqual_VectorVector_ReturnValue : 1;  // 0x100(0x1)
	char pad_257[3];  // 0x101(0x3)
	struct FVector CallFunc_Subtract_VectorVector_ReturnValue;  // 0x104(0xC)
	struct FLinearColor CallFunc_Conv_VectorToLinearColor_ReturnValue_6;  // 0x110(0x10)
	struct FVector CallFunc_Conv_LinearColorToVector_ReturnValue_3;  // 0x120(0xC)
	struct FVector CallFunc_Subtract_VectorVector_ReturnValue_2;  // 0x12C(0xC)
	struct FLinearColor CallFunc_MakeColor_ReturnValue;  // 0x138(0x10)
	struct FLinearColor CallFunc_Conv_VectorToLinearColor_ReturnValue_7;  // 0x148(0x10)
	struct ASurvivalPlayerCharacter* CallFunc_GetLocalSurvivalPlayerCharacter_ReturnValue_3;  // 0x158(0x8)
	char pad_352_1 : 7;  // 0x160(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x160(0x1)
	char pad_353[3];  // 0x161(0x3)
	int32_t CallFunc_Set_Length_ReturnValue;  // 0x164(0x4)
	char pad_360_1 : 7;  // 0x168(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue : 1;  // 0x168(0x1)

}; 
// Function BP_Landscape_RT_Manager.BP_Landscape_RT_Manager_C.GetObjectUVCoords
// Size: 0xA8(Inherited: 0x0) 
struct FGetObjectUVCoords
{
	struct FVector Object Location;  // 0x0(0xC)
	struct FVector UV Grid;  // 0xC(0xC)
	struct FVector UV Segment;  // 0x18(0xC)
	float CallFunc_GetScalarParameterValue_ReturnValue;  // 0x24(0x4)
	float CallFunc_GetScalarParameterValue_ReturnValue_2;  // 0x28(0x4)
	struct FVector CallFunc_Divide_VectorFloat_ReturnValue;  // 0x2C(0xC)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x38(0x4)
	float CallFunc_BreakVector_X;  // 0x3C(0x4)
	float CallFunc_BreakVector_Y;  // 0x40(0x4)
	float CallFunc_BreakVector_Z;  // 0x44(0x4)
	struct FVector CallFunc_Divide_VectorFloat_ReturnValue_2;  // 0x48(0xC)
	int32_t CallFunc_FFloor_ReturnValue;  // 0x54(0x4)
	float CallFunc_BreakVector_X_2;  // 0x58(0x4)
	float CallFunc_BreakVector_Y_2;  // 0x5C(0x4)
	float CallFunc_BreakVector_Z_2;  // 0x60(0x4)
	float CallFunc_Conv_IntToFloat_ReturnValue;  // 0x64(0x4)
	int32_t CallFunc_FFloor_ReturnValue_2;  // 0x68(0x4)
	int32_t CallFunc_FFloor_ReturnValue_3;  // 0x6C(0x4)
	float CallFunc_Conv_IntToFloat_ReturnValue_2;  // 0x70(0x4)
	float CallFunc_Conv_IntToFloat_ReturnValue_3;  // 0x74(0x4)
	int32_t CallFunc_FFloor_ReturnValue_4;  // 0x78(0x4)
	int32_t CallFunc_FFloor_ReturnValue_5;  // 0x7C(0x4)
	float CallFunc_Conv_IntToFloat_ReturnValue_4;  // 0x80(0x4)
	float CallFunc_Conv_IntToFloat_ReturnValue_5;  // 0x84(0x4)
	struct FVector CallFunc_MakeVector_ReturnValue;  // 0x88(0xC)
	int32_t CallFunc_FFloor_ReturnValue_6;  // 0x94(0x4)
	float CallFunc_Conv_IntToFloat_ReturnValue_6;  // 0x98(0x4)
	struct FVector CallFunc_MakeVector_ReturnValue_2;  // 0x9C(0xC)

}; 
