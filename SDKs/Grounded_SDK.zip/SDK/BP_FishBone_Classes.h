#pragma once 
#include <BP_FishBone_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_FishBone.BP_FishBone_C
// Size: 0x368(Inherited: 0x368) 
struct ABP_FishBone_C : public ABP_StaticHarvestNode_C
{

}; 



