#pragma once 
#include <BP_AlgaeA_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_AlgaeA.BP_AlgaeA_C
// Size: 0x4B0(Inherited: 0x4A8) 
struct ABP_AlgaeA_C : public ABP_WorldItem_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x4A8(0x8)

	void ReceiveBeginPlay(); // Function BP_AlgaeA.BP_AlgaeA_C.ReceiveBeginPlay
	void ExecuteUbergraph_BP_AlgaeA(int32_t EntryPoint); // Function BP_AlgaeA.BP_AlgaeA_C.ExecuteUbergraph_BP_AlgaeA
}; 



