#pragma once 
#include <BP_FallbackEquippedItem_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_FallbackEquippedItem.BP_FallbackEquippedItem_C
// Size: 0x4A8(Inherited: 0x4A8) 
struct ABP_FallbackEquippedItem_C : public ABP_EquippedItem_C
{

}; 



