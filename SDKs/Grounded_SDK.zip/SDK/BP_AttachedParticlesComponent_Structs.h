#pragma once 
#include "SDK.h" 
 
 
// Function BP_AttachedParticlesComponent.BP_AttachedParticlesComponent_C.ExecuteUbergraph_BP_AttachedParticlesComponent
// Size: 0x2DA(Inherited: 0x0) 
struct FExecuteUbergraph_BP_AttachedParticlesComponent
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Temp_bool_True_if_break_was_hit_Variable : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	int32_t Temp_int_Variable;  // 0x8(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0xC(0x4)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x14(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x24(0x10)
	int32_t Temp_int_Variable_2;  // 0x34(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0x38(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x3C(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_3;  // 0x40(0x4)
	float K2Node_Event_DeltaSeconds;  // 0x44(0x4)
	struct UParticleSystemComponent* CallFunc_SpawnEmitterAttached_ReturnValue;  // 0x48(0x8)
	struct AActor* K2Node_CustomEvent_OverlappedActor_4;  // 0x50(0x8)
	struct AActor* K2Node_CustomEvent_OtherActor_4;  // 0x58(0x8)
	struct AActor* K2Node_CustomEvent_OverlappedActor_3;  // 0x60(0x8)
	struct AActor* K2Node_CustomEvent_OtherActor_3;  // 0x68(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x70(0x4)
	int32_t CallFunc_Array_Length_ReturnValue_2;  // 0x74(0x4)
	struct ATriggerBox* CallFunc_Array_Get_Item;  // 0x78(0x8)
	int32_t CallFunc_Array_Length_ReturnValue_3;  // 0x80(0x4)
	char pad_132_1 : 7;  // 0x84(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x84(0x1)
	char pad_133[3];  // 0x85(0x3)
	struct ATriggerBox* CallFunc_Array_Get_Item_2;  // 0x88(0x8)
	int32_t CallFunc_Array_Length_ReturnValue_4;  // 0x90(0x4)
	int32_t CallFunc_Array_Length_ReturnValue_5;  // 0x94(0x4)
	char pad_152_1 : 7;  // 0x98(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_2 : 1;  // 0x98(0x1)
	char pad_153_1 : 7;  // 0x99(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_3 : 1;  // 0x99(0x1)
	char pad_154_1 : 7;  // 0x9A(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x9A(0x1)
	char pad_155[5];  // 0x9B(0x5)
	struct AActor* K2Node_CustomEvent_OverlappedActor_2;  // 0xA0(0x8)
	struct AActor* K2Node_CustomEvent_OtherActor_2;  // 0xA8(0x8)
	struct AActor* K2Node_CustomEvent_OverlappedActor;  // 0xB0(0x8)
	struct AActor* K2Node_CustomEvent_OtherActor;  // 0xB8(0x8)
	int32_t Temp_int_Array_Index_Variable;  // 0xC0(0x4)
	char pad_196[4];  // 0xC4(0x4)
	struct ATriggerBox* CallFunc_Array_Get_Item_3;  // 0xC8(0x8)
	char pad_208_1 : 7;  // 0xD0(0x1)
	bool CallFunc_IsOverlappingActor_ReturnValue : 1;  // 0xD0(0x1)
	char pad_209_1 : 7;  // 0xD1(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0xD1(0x1)
	char pad_210_1 : 7;  // 0xD2(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0xD2(0x1)
	char pad_211[1];  // 0xD3(0x1)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_3;  // 0xD4(0x10)
	struct FVector CallFunc_GetComponentBounds_Origin;  // 0xE4(0xC)
	struct FVector CallFunc_GetComponentBounds_BoxExtent;  // 0xF0(0xC)
	float CallFunc_GetComponentBounds_SphereRadius;  // 0xFC(0x4)
	float CallFunc_BreakVector_X;  // 0x100(0x4)
	float CallFunc_BreakVector_Y;  // 0x104(0x4)
	float CallFunc_BreakVector_Z;  // 0x108(0x4)
	char pad_268_1 : 7;  // 0x10C(0x1)
	bool CallFunc_IsValid_ReturnValue_3 : 1;  // 0x10C(0x1)
	char pad_269[3];  // 0x10D(0x3)
	float CallFunc_Abs_ReturnValue;  // 0x110(0x4)
	char pad_276[4];  // 0x114(0x4)
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0x118(0x8)
	struct ABP_SurvivalPlayerCharacter_C* K2Node_DynamicCast_AsBP_Survival_Player_Character;  // 0x120(0x8)
	char pad_296_1 : 7;  // 0x128(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x128(0x1)
	char pad_297[7];  // 0x129(0x7)
	struct UParticleSystemComponent* CallFunc_SpawnEmitterAttached_ReturnValue_2;  // 0x130(0x8)
	struct UParticleSystemComponent* CallFunc_SpawnEmitterAttached_ReturnValue_3;  // 0x138(0x8)
	struct UParticleSystemComponent* CallFunc_SpawnEmitterAttached_ReturnValue_4;  // 0x140(0x8)
	char pad_328_1 : 7;  // 0x148(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue : 1;  // 0x148(0x1)
	char pad_329_1 : 7;  // 0x149(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue_2 : 1;  // 0x149(0x1)
	char pad_330[6];  // 0x14A(0x6)
	struct UParticleSystemComponent* CallFunc_SpawnEmitterAttached_ReturnValue_5;  // 0x150(0x8)
	char pad_344_1 : 7;  // 0x158(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue_3 : 1;  // 0x158(0x1)
	char pad_345_1 : 7;  // 0x159(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue_4 : 1;  // 0x159(0x1)
	char pad_346[6];  // 0x15A(0x6)
	struct UParticleSystemComponent* CallFunc_SpawnEmitterAttached_ReturnValue_6;  // 0x160(0x8)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue;  // 0x168(0xC)
	float CallFunc_BreakVector_X_2;  // 0x174(0x4)
	float CallFunc_BreakVector_Y_2;  // 0x178(0x4)
	float CallFunc_BreakVector_Z_2;  // 0x17C(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0x180(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue;  // 0x184(0x4)
	char pad_392_1 : 7;  // 0x188(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue : 1;  // 0x188(0x1)
	char pad_393[3];  // 0x189(0x3)
	float CallFunc_Abs_ReturnValue_2;  // 0x18C(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue_2;  // 0x190(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue_3;  // 0x194(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x198(0x4)
	struct FVector CallFunc_MakeVector_ReturnValue;  // 0x19C(0xC)
	struct FHitResult CallFunc_K2_SetRelativeLocation_SweepHitResult;  // 0x1A8(0x88)
	int32_t Temp_int_Variable_3;  // 0x230(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_4;  // 0x234(0x4)
	struct ATriggerVolume* CallFunc_Array_Get_Item_4;  // 0x238(0x8)
	char pad_576_1 : 7;  // 0x240(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_4 : 1;  // 0x240(0x1)
	char pad_577_1 : 7;  // 0x241(0x1)
	bool K2Node_CustomEvent_InWater : 1;  // 0x241(0x1)
	char pad_578[6];  // 0x242(0x6)
	struct ABP_Water_Large_C* K2Node_CustomEvent_OverlappedWaterVolume;  // 0x248(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_4;  // 0x250(0x10)
	int32_t Temp_int_Variable_4;  // 0x260(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_5;  // 0x264(0x4)
	struct ATriggerVolume* CallFunc_Array_Get_Item_5;  // 0x268(0x8)
	char pad_624_1 : 7;  // 0x270(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_5 : 1;  // 0x270(0x1)
	char pad_625[3];  // 0x271(0x3)
	float CallFunc_MapRangeClamped_ReturnValue;  // 0x274(0x4)
	struct AActor* CallFunc_GetOwner_ReturnValue_2;  // 0x278(0x8)
	struct ABP_SurvivalPlayerCharacter_C* K2Node_DynamicCast_AsBP_Survival_Player_Character_2;  // 0x280(0x8)
	char pad_648_1 : 7;  // 0x288(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x288(0x1)
	char pad_649[7];  // 0x289(0x7)
	struct UBoxComponent* CallFunc_GetLastWaterVolumeCollider_Collision;  // 0x290(0x8)
	int32_t CallFunc_GetNumWaterVolumes_Num;  // 0x298(0x4)
	struct FVector CallFunc_GetComponentBounds_Origin_2;  // 0x29C(0xC)
	struct FVector CallFunc_GetComponentBounds_BoxExtent_2;  // 0x2A8(0xC)
	float CallFunc_GetComponentBounds_SphereRadius_2;  // 0x2B4(0x4)
	char pad_696_1 : 7;  // 0x2B8(0x1)
	bool CallFunc_GreaterEqual_IntInt_ReturnValue : 1;  // 0x2B8(0x1)
	char pad_697[3];  // 0x2B9(0x3)
	float CallFunc_BreakVector_X_3;  // 0x2BC(0x4)
	float CallFunc_BreakVector_Y_3;  // 0x2C0(0x4)
	float CallFunc_BreakVector_Z_3;  // 0x2C4(0x4)
	float CallFunc_BreakVector_X_4;  // 0x2C8(0x4)
	float CallFunc_BreakVector_Y_4;  // 0x2CC(0x4)
	float CallFunc_BreakVector_Z_4;  // 0x2D0(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue_2;  // 0x2D4(0x4)
	char pad_728_1 : 7;  // 0x2D8(0x1)
	bool CallFunc_IsValid_ReturnValue_4 : 1;  // 0x2D8(0x1)
	char pad_729_1 : 7;  // 0x2D9(0x1)
	bool CallFunc_IsValid_ReturnValue_5 : 1;  // 0x2D9(0x1)

}; 
// Function BP_AttachedParticlesComponent.BP_AttachedParticlesComponent_C.SetWaterParticles
// Size: 0x10(Inherited: 0x0) 
struct FSetWaterParticles
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool InWater : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct ABP_Water_Large_C* OverlappedWaterVolume;  // 0x8(0x8)

}; 
// Function BP_AttachedParticlesComponent.BP_AttachedParticlesComponent_C.ReceiveTick
// Size: 0x4(Inherited: 0x4) 
struct FReceiveTick : public FReceiveTick
{
	float DeltaSeconds;  // 0x0(0x4)

}; 
// Function BP_AttachedParticlesComponent.BP_AttachedParticlesComponent_C.EndOverlapLab
// Size: 0x10(Inherited: 0x0) 
struct FEndOverlapLab
{
	struct AActor* OverlappedActor;  // 0x0(0x8)
	struct AActor* OtherActor;  // 0x8(0x8)

}; 
// Function BP_AttachedParticlesComponent.BP_AttachedParticlesComponent_C.BeginOverlapLab
// Size: 0x10(Inherited: 0x0) 
struct FBeginOverlapLab
{
	struct AActor* OverlappedActor;  // 0x0(0x8)
	struct AActor* OtherActor;  // 0x8(0x8)

}; 
// Function BP_AttachedParticlesComponent.BP_AttachedParticlesComponent_C.EndOverlapWeedKiller
// Size: 0x10(Inherited: 0x0) 
struct FEndOverlapWeedKiller
{
	struct AActor* OverlappedActor;  // 0x0(0x8)
	struct AActor* OtherActor;  // 0x8(0x8)

}; 
// Function BP_AttachedParticlesComponent.BP_AttachedParticlesComponent_C.BeginOverlapWeedKiller
// Size: 0x10(Inherited: 0x0) 
struct FBeginOverlapWeedKiller
{
	struct AActor* OverlappedActor;  // 0x0(0x8)
	struct AActor* OtherActor;  // 0x8(0x8)

}; 
