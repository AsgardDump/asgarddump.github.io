#pragma once 
#include <BP_CameraShake_Bomb_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_CameraShake_Bomb.BP_CameraShake_Bomb_C
// Size: 0x1B0(Inherited: 0x1B0) 
struct UBP_CameraShake_Bomb_C : public UMatineeCameraShake
{

}; 



