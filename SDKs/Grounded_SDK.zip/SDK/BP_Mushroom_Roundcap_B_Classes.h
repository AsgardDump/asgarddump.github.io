#pragma once 
#include <BP_Mushroom_Roundcap_B_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Mushroom_Roundcap_B.BP_Mushroom_Roundcap_B_C
// Size: 0x498(Inherited: 0x469) 
struct ABP_Mushroom_Roundcap_B_C : public ABP_BASE_Mushroom_C
{
	char pad_1129[7];  // 0x469(0x7)
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x470(0x8)
	struct UParticleSystemSpawnComponent* BreakParticles3;  // 0x478(0x8)
	struct UParticleSystemSpawnComponent* BreakParticles1;  // 0x480(0x8)
	struct UParticleSystemSpawnComponent* BreakParticles2;  // 0x488(0x8)
	struct UParticleSystemSpawnComponent* BreakParticles4;  // 0x490(0x8)

	void HandleLootSpawnVisuals(); // Function BP_Mushroom_Roundcap_B.BP_Mushroom_Roundcap_B_C.HandleLootSpawnVisuals
	void ExecuteUbergraph_BP_Mushroom_Roundcap_B(int32_t EntryPoint); // Function BP_Mushroom_Roundcap_B.BP_Mushroom_Roundcap_B_C.ExecuteUbergraph_BP_Mushroom_Roundcap_B
}; 



