#pragma once 
#include <BP_ChoppingDamage_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_ChoppingDamage.BP_ChoppingDamage_C
// Size: 0x78(Inherited: 0x78) 
struct UBP_ChoppingDamage_C : public USurvivalDamageType
{

}; 



