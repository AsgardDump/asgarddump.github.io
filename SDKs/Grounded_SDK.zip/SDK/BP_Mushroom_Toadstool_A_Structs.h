#pragma once 
#include "SDK.h" 
 
 
// Function BP_Mushroom_Toadstool_A.BP_Mushroom_Toadstool_A_C.ExecuteUbergraph_BP_Mushroom_Toadstool_A
// Size: 0x4(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Mushroom_Toadstool_A
{
	int32_t EntryPoint;  // 0x0(0x4)

}; 
