#pragma once 
#include <BP_BurningDamage_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_BurningDamage.BP_BurningDamage_C
// Size: 0x78(Inherited: 0x78) 
struct UBP_BurningDamage_C : public USurvivalDamageType
{

}; 



