#pragma once 
#include <BP_GrassBlade_Burned_F_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_GrassBlade_Burned_F.BP_GrassBlade_Burned_F_C
// Size: 0x408(Inherited: 0x408) 
struct ABP_GrassBlade_Burned_F_C : public ABP_BASE_GrassBlade_Burned_C
{

}; 



