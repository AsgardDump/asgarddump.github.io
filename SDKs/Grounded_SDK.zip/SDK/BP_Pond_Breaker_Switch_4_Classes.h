#pragma once 
#include <BP_Pond_Breaker_Switch_4_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Pond_Breaker_Switch_4.BP_Pond_Breaker_Switch_3_C
// Size: 0x460(Inherited: 0x454) 
struct ABP_Pond_Breaker_Switch_3_C : public ABP_Pond_Breaker_Switch_Base_C
{
	char pad_1108[4];  // 0x454(0x4)
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x458(0x8)

	void ToggleIsOnGlobalVariableImplementation(); // Function BP_Pond_Breaker_Switch_4.BP_Pond_Breaker_Switch_3_C.ToggleIsOnGlobalVariableImplementation
	void ExecuteUbergraph_BP_Pond_Breaker_Switch_4(int32_t EntryPoint); // Function BP_Pond_Breaker_Switch_4.BP_Pond_Breaker_Switch_3_C.ExecuteUbergraph_BP_Pond_Breaker_Switch_4
}; 



