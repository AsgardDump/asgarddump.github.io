#pragma once 
#include <BP_CameraPhoto_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_CameraPhoto.BP_CameraPhoto_C
// Size: 0x250(Inherited: 0x230) 
struct ABP_CameraPhoto_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x230(0x8)
	struct UStaticMeshComponent* PhotoMesh;  // 0x238(0x8)
	struct UMaineStaticMeshComponent* MaineStaticMesh;  // 0x240(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x248(0x8)

	void SetTexture(struct UTexture* Texture); // Function BP_CameraPhoto.BP_CameraPhoto_C.SetTexture
	void ExecuteUbergraph_BP_CameraPhoto(int32_t EntryPoint); // Function BP_CameraPhoto.BP_CameraPhoto_C.ExecuteUbergraph_BP_CameraPhoto
}; 



