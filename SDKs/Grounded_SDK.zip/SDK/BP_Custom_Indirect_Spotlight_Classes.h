#pragma once 
#include <BP_Custom_Indirect_Spotlight_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Custom_Indirect_Spotlight.BP_Custom_Indirect_Spotlight_C
// Size: 0x258(Inherited: 0x248) 
struct ABP_Custom_Indirect_Spotlight_C : public ASpotLight
{
	char pad_584_1 : 7;  // 0x248(0x1)
	bool InteriorDaylight : 1;  // 0x248(0x1)
	char pad_585_1 : 7;  // 0x249(0x1)
	bool BakeIndirect : 1;  // 0x249(0x1)
	char pad_586[2];  // 0x24A(0x2)
	float BAKE INTENSITY;  // 0x24C(0x4)
	float ACTUAL INTENSITY;  // 0x250(0x4)
	float TOD_IntensityMultiplier;  // 0x254(0x4)

	void SetLightColorIntensity(float IntensityAlpha, struct FLinearColor Color); // Function BP_Custom_Indirect_Spotlight.BP_Custom_Indirect_Spotlight_C.SetLightColorIntensity
	void Toggle Bake Mode(bool Bake On); // Function BP_Custom_Indirect_Spotlight.BP_Custom_Indirect_Spotlight_C.Toggle Bake Mode
}; 



