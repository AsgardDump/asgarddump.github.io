#pragma once 
#include <BP_GrassBlade_C_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_GrassBlade_C.BP_GrassBlade_C_C
// Size: 0x478(Inherited: 0x429) 
struct ABP_GrassBlade_C_C : public ABP_BASE_GrassBlade_C
{
	char pad_1065[7];  // 0x429(0x7)
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x430(0x8)
	struct UParticleSystemSpawnComponent* BreakParticles3;  // 0x438(0x8)
	struct UParticleSystemSpawnComponent* BreakParticles2;  // 0x440(0x8)
	struct UParticleSystemSpawnComponent* BreakParticles1;  // 0x448(0x8)
	struct UClimbableSplineComponent* ClimbableSpline2;  // 0x450(0x8)
	struct UClimbableSplineComponent* ClimbableSpline1;  // 0x458(0x8)
	struct UStaticMeshComponent* SM_Grass_Blade_Chunk_Mid;  // 0x460(0x8)
	struct UStaticMeshComponent* SM_Grass_Blade_Chunk_Left;  // 0x468(0x8)
	struct UStaticMeshComponent* SM_Grass_Blade_Chunk_Right;  // 0x470(0x8)

	void ReceiveBeginPlay(); // Function BP_GrassBlade_C.BP_GrassBlade_C_C.ReceiveBeginPlay
	void HandleLootSpawnVisuals(); // Function BP_GrassBlade_C.BP_GrassBlade_C_C.HandleLootSpawnVisuals
	void ExecuteUbergraph_BP_GrassBlade_C(int32_t EntryPoint); // Function BP_GrassBlade_C.BP_GrassBlade_C_C.ExecuteUbergraph_BP_GrassBlade_C
}; 



