#pragma once 
#include <BP_BASE_Hedge_Berry_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_BASE_Hedge_Berry.BP_BASE_Hedge_Berry_C
// Size: 0x430(Inherited: 0x420) 
struct ABP_BASE_Hedge_Berry_C : public ABP_ToppleHarvestNode_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x420(0x8)
	AActor* SpawnOnDeathActor;  // 0x428(0x8)

	struct FVector GetItemSourceWorldLocation(struct FDataTableRowHandle& ItemType); // Function BP_BASE_Hedge_Berry.BP_BASE_Hedge_Berry_C.GetItemSourceWorldLocation
	bool IsSourceForItem(struct FDataTableRowHandle& ItemType); // Function BP_BASE_Hedge_Berry.BP_BASE_Hedge_Berry_C.IsSourceForItem
	void Handle Death(struct FDamageInfo DamageInfo); // Function BP_BASE_Hedge_Berry.BP_BASE_Hedge_Berry_C.Handle Death
	void MulticastHandleDestroy(); // Function BP_BASE_Hedge_Berry.BP_BASE_Hedge_Berry_C.MulticastHandleDestroy
	void ExecuteUbergraph_BP_BASE_Hedge_Berry(int32_t EntryPoint); // Function BP_BASE_Hedge_Berry.BP_BASE_Hedge_Berry_C.ExecuteUbergraph_BP_BASE_Hedge_Berry
}; 



