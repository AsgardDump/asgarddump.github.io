#pragma once 
#include <BP_Base_PowerTerminal_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Base_PowerTerminal.BP_Base_PowerTerminal_C
// Size: 0x368(Inherited: 0x288) 
struct ABP_Base_PowerTerminal_C : public ASwitch
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x288(0x8)
	struct UStaticMeshComponent* StaticMesh;  // 0x290(0x8)
	struct UAudioComponent* LeverLoopAudio;  // 0x298(0x8)
	struct UConditionalToggleComponent* ConditionalToggle_BatteryBackUp;  // 0x2A0(0x8)
	struct UBoxComponent* Box;  // 0x2A8(0x8)
	struct UStaticMeshComponent* SM_SwitchHandle;  // 0x2B0(0x8)
	struct USceneComponent* PowerSwitchRoot;  // 0x2B8(0x8)
	struct UAudioComponent* TerminalSFXLoop;  // 0x2C0(0x8)
	struct UConditionalToggleComponent* ConditionalToggle_HousePower;  // 0x2C8(0x8)
	struct UWidgetComponent* Widget;  // 0x2D0(0x8)
	struct UConditionalToggleComponent* ConditionalToggle_HousePowerDiverted;  // 0x2D8(0x8)
	struct UConditionalToggleComponent* ConditionalToggle_TerminalInteractable;  // 0x2E0(0x8)
	float Timeline_SFX_PItch_Pitch_3192A9C143F03F51F0529E9D4715ADFE;  // 0x2E8(0x4)
	char ETimelineDirection Timeline_SFX_PItch__Direction_3192A9C143F03F51F0529E9D4715ADFE;  // 0x2EC(0x1)
	char pad_749[3];  // 0x2ED(0x3)
	struct UTimelineComponent* Timeline_SFX_PItch;  // 0x2F0(0x8)
	float Timeline_HandleRot_Driver_7A987BD94B4A2BFB25735A95CA9056FD;  // 0x2F8(0x4)
	char ETimelineDirection Timeline_HandleRot__Direction_7A987BD94B4A2BFB25735A95CA9056FD;  // 0x2FC(0x1)
	char pad_765[3];  // 0x2FD(0x3)
	struct UTimelineComponent* Timeline_HandleRot;  // 0x300(0x8)
	struct FLocString InteractionText_Reboot;  // 0x308(0x10)
	struct FLocString InteractionText_Login;  // 0x318(0x10)
	struct UMaterialInstanceDynamic* ScreenDMI;  // 0x328(0x8)
	struct UUI_PowerGridTerminal_C* UserWidgetObjectRef;  // 0x330(0x8)
	char pad_824_1 : 7;  // 0x338(0x1)
	bool InteractionBlocked : 1;  // 0x338(0x1)
	char pad_825_1 : 7;  // 0x339(0x1)
	bool IsReadyForAudio : 1;  // 0x339(0x1)
	char pad_826[6];  // 0x33A(0x6)
	struct USoundBase* Lever Down SFX;  // 0x340(0x8)
	struct USoundBase* Lever Up SFX;  // 0x348(0x8)
	struct USoundBase* LeverLoopSFX;  // 0x350(0x8)
	struct USoundBase* ComputerSound;  // 0x358(0x8)
	char pad_864_1 : 7;  // 0x360(0x1)
	bool ScreenPaused : 1;  // 0x360(0x1)
	char pad_865[3];  // 0x361(0x3)
	int32_t CurrentlyShownScreenIndex;  // 0x364(0x4)

	void RedrawScreen(); // Function BP_Base_PowerTerminal.BP_Base_PowerTerminal_C.RedrawScreen
	void GetInteractionText(uint8_t  Channel, struct AActor* InstigatedBy, struct FString& OutText); // Function BP_Base_PowerTerminal.BP_Base_PowerTerminal_C.GetInteractionText
	char EInteractionState IsInteractionEnabled(uint8_t  Channel, struct AActor* InstigatedBy); // Function BP_Base_PowerTerminal.BP_Base_PowerTerminal_C.IsInteractionEnabled
	void UserConstructionScript(); // Function BP_Base_PowerTerminal.BP_Base_PowerTerminal_C.UserConstructionScript
	void Timeline_HandleRot__FinishedFunc(); // Function BP_Base_PowerTerminal.BP_Base_PowerTerminal_C.Timeline_HandleRot__FinishedFunc
	void Timeline_HandleRot__UpdateFunc(); // Function BP_Base_PowerTerminal.BP_Base_PowerTerminal_C.Timeline_HandleRot__UpdateFunc
	void Timeline_SFX_PItch__FinishedFunc(); // Function BP_Base_PowerTerminal.BP_Base_PowerTerminal_C.Timeline_SFX_PItch__FinishedFunc
	void Timeline_SFX_PItch__UpdateFunc(); // Function BP_Base_PowerTerminal.BP_Base_PowerTerminal_C.Timeline_SFX_PItch__UpdateFunc
	void OnOpenStateChanged(bool IsOpen, struct AActor* ActorInstigator); // Function BP_Base_PowerTerminal.BP_Base_PowerTerminal_C.OnOpenStateChanged
	void EnableScreenDraw(); // Function BP_Base_PowerTerminal.BP_Base_PowerTerminal_C.EnableScreenDraw
	void DisableScreenDraw(); // Function BP_Base_PowerTerminal.BP_Base_PowerTerminal_C.DisableScreenDraw
	void MakeScreenDMI(); // Function BP_Base_PowerTerminal.BP_Base_PowerTerminal_C.MakeScreenDMI
	void HideAllScreens(); // Function BP_Base_PowerTerminal.BP_Base_PowerTerminal_C.HideAllScreens
	void SetUserWidgetObjectReference(); // Function BP_Base_PowerTerminal.BP_Base_PowerTerminal_C.SetUserWidgetObjectReference
	void ShowStart(); // Function BP_Base_PowerTerminal.BP_Base_PowerTerminal_C.ShowStart
	void ShowLocked(); // Function BP_Base_PowerTerminal.BP_Base_PowerTerminal_C.ShowLocked
	void ShowLockedFlash(); // Function BP_Base_PowerTerminal.BP_Base_PowerTerminal_C.ShowLockedFlash
	void ShowUnlocked(); // Function BP_Base_PowerTerminal.BP_Base_PowerTerminal_C.ShowUnlocked
	void ReceiveBeginPlay(); // Function BP_Base_PowerTerminal.BP_Base_PowerTerminal_C.ReceiveBeginPlay
	void ShowWaiting(); // Function BP_Base_PowerTerminal.BP_Base_PowerTerminal_C.ShowWaiting
	void OnUpdateVisualState(bool IsOpen); // Function BP_Base_PowerTerminal.BP_Base_PowerTerminal_C.OnUpdateVisualState
	void HandleOpenAudio(); // Function BP_Base_PowerTerminal.BP_Base_PowerTerminal_C.HandleOpenAudio
	void HandleClosedAudio(); // Function BP_Base_PowerTerminal.BP_Base_PowerTerminal_C.HandleClosedAudio
	void TimelineFinished(); // Function BP_Base_PowerTerminal.BP_Base_PowerTerminal_C.TimelineFinished
	void ReceiveTick(float DeltaSeconds); // Function BP_Base_PowerTerminal.BP_Base_PowerTerminal_C.ReceiveTick
	void BndEvt__ConditionalToggle_BatteryBackUp_K2Node_ComponentBoundEvent_0_OnConditionalStateChanged__DelegateSignature(bool bIsActive); // Function BP_Base_PowerTerminal.BP_Base_PowerTerminal_C.BndEvt__ConditionalToggle_BatteryBackUp_K2Node_ComponentBoundEvent_0_OnConditionalStateChanged__DelegateSignature
	void BndEvt__ConditionalToggle_HousePower_K2Node_ComponentBoundEvent_1_OnConditionalStateChanged__DelegateSignature(bool bIsActive); // Function BP_Base_PowerTerminal.BP_Base_PowerTerminal_C.BndEvt__ConditionalToggle_HousePower_K2Node_ComponentBoundEvent_1_OnConditionalStateChanged__DelegateSignature
	void BndEvt__ConditionalToggle_HousePowerDiverted_K2Node_ComponentBoundEvent_2_OnConditionalStateChanged__DelegateSignature(bool bIsActive); // Function BP_Base_PowerTerminal.BP_Base_PowerTerminal_C.BndEvt__ConditionalToggle_HousePowerDiverted_K2Node_ComponentBoundEvent_2_OnConditionalStateChanged__DelegateSignature
	void ExecuteUbergraph_BP_Base_PowerTerminal(int32_t EntryPoint); // Function BP_Base_PowerTerminal.BP_Base_PowerTerminal_C.ExecuteUbergraph_BP_Base_PowerTerminal
}; 



