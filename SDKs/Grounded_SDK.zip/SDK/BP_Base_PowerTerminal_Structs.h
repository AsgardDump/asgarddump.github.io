#pragma once 
#include "SDK.h" 
 
 
// Function BP_Base_PowerTerminal.BP_Base_PowerTerminal_C.BndEvt__ConditionalToggle_BatteryBackUp_K2Node_ComponentBoundEvent_0_OnConditionalStateChanged__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FBndEvt__ConditionalToggle_BatteryBackUp_K2Node_ComponentBoundEvent_0_OnConditionalStateChanged__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bIsActive : 1;  // 0x0(0x1)

}; 
// Function BP_Base_PowerTerminal.BP_Base_PowerTerminal_C.ExecuteUbergraph_BP_Base_PowerTerminal
// Size: 0x124(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Base_PowerTerminal
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Temp_bool_IsClosed_Variable : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool Temp_bool_Has_Been_Initd_Variable : 1;  // 0x5(0x1)
	char pad_6_1 : 7;  // 0x6(0x1)
	bool K2Node_Event_IsOpen_2 : 1;  // 0x6(0x1)
	char pad_7[1];  // 0x7(0x1)
	struct AActor* K2Node_Event_ActorInstigator;  // 0x8(0x8)
	struct UTextureRenderTarget2D* CallFunc_GetRenderTarget_ReturnValue;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue;  // 0x20(0x8)
	struct UUserWidget* CallFunc_GetUserWidgetObject_ReturnValue;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)
	struct UUI_PowerGridTerminal_C* K2Node_DynamicCast_AsUI_Power_Grid_Terminal;  // 0x38(0x8)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x40(0x1)
	char pad_65_1 : 7;  // 0x41(0x1)
	bool CallFunc_IsValid_ReturnValue_3 : 1;  // 0x41(0x1)
	char pad_66[6];  // 0x42(0x6)
	struct UUMGSequencePlayer* CallFunc_PlayAnimation_ReturnValue;  // 0x48(0x8)
	struct UUMGSequencePlayer* CallFunc_PlayAnimation_ReturnValue_2;  // 0x50(0x8)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool Temp_bool_Has_Been_Initd_Variable_2 : 1;  // 0x58(0x1)
	char pad_89[3];  // 0x59(0x3)
	struct FRotator CallFunc_MakeRotator_ReturnValue;  // 0x5C(0xC)
	struct FRotator CallFunc_RLerp_ReturnValue;  // 0x68(0xC)
	char pad_116_1 : 7;  // 0x74(0x1)
	bool K2Node_Event_IsOpen : 1;  // 0x74(0x1)
	char pad_117[3];  // 0x75(0x3)
	struct FHitResult CallFunc_K2_SetRelativeLocationAndRotation_SweepHitResult;  // 0x78(0x88)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x100(0xC)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_2;  // 0x10C(0xC)
	char pad_280_1 : 7;  // 0x118(0x1)
	bool Temp_bool_IsClosed_Variable_2 : 1;  // 0x118(0x1)
	char pad_281_1 : 7;  // 0x119(0x1)
	bool CallFunc_IsValid_ReturnValue_4 : 1;  // 0x119(0x1)
	char pad_282_1 : 7;  // 0x11A(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0x11A(0x1)
	char pad_283_1 : 7;  // 0x11B(0x1)
	bool CallFunc_IsValid_ReturnValue_5 : 1;  // 0x11B(0x1)
	float K2Node_Event_DeltaSeconds;  // 0x11C(0x4)
	char pad_288_1 : 7;  // 0x120(0x1)
	bool CallFunc_WasRecentlyRendered_ReturnValue : 1;  // 0x120(0x1)
	char pad_289_1 : 7;  // 0x121(0x1)
	bool K2Node_ComponentBoundEvent_bIsActive_3 : 1;  // 0x121(0x1)
	char pad_290_1 : 7;  // 0x122(0x1)
	bool K2Node_ComponentBoundEvent_bIsActive_2 : 1;  // 0x122(0x1)
	char pad_291_1 : 7;  // 0x123(0x1)
	bool K2Node_ComponentBoundEvent_bIsActive : 1;  // 0x123(0x1)

}; 
// Function BP_Base_PowerTerminal.BP_Base_PowerTerminal_C.IsInteractionEnabled
// Size: 0x15(Inherited: 0x18) 
struct FIsInteractionEnabled : public FIsInteractionEnabled
{
	uint8_t  Channel;  // 0x0(0x1)
	struct AActor* InstigatedBy;  // 0x8(0x8)
	char EInteractionState ReturnValue;  // 0x10(0x1)
	char EInteractionState CallFunc_IsInteractionEnabled_ReturnValue;  // 0x11(0x1)
	char pad_35_1 : 7;  // 0x23(0x1)
	bool CallFunc_IsEnabled_ReturnValue : 1;  // 0x12(0x1)
	char pad_36_1 : 7;  // 0x24(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x13(0x1)
	char pad_37_1 : 7;  // 0x25(0x1)
	bool CallFunc_BooleanOR_ReturnValue : 1;  // 0x14(0x1)

}; 
// Function BP_Base_PowerTerminal.BP_Base_PowerTerminal_C.OnUpdateVisualState
// Size: 0x1(Inherited: 0x1) 
struct FOnUpdateVisualState : public FOnUpdateVisualState
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool IsOpen : 1;  // 0x0(0x1)

}; 
// Function BP_Base_PowerTerminal.BP_Base_PowerTerminal_C.BndEvt__ConditionalToggle_HousePowerDiverted_K2Node_ComponentBoundEvent_2_OnConditionalStateChanged__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FBndEvt__ConditionalToggle_HousePowerDiverted_K2Node_ComponentBoundEvent_2_OnConditionalStateChanged__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bIsActive : 1;  // 0x0(0x1)

}; 
// Function BP_Base_PowerTerminal.BP_Base_PowerTerminal_C.OnOpenStateChanged
// Size: 0x10(Inherited: 0x10) 
struct FOnOpenStateChanged : public FOnOpenStateChanged
{
	char pad_16_1 : 7;  // 0x10(0x1)
	bool IsOpen : 1;  // 0x0(0x1)
	struct AActor* ActorInstigator;  // 0x8(0x8)

}; 
// Function BP_Base_PowerTerminal.BP_Base_PowerTerminal_C.BndEvt__ConditionalToggle_HousePower_K2Node_ComponentBoundEvent_1_OnConditionalStateChanged__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FBndEvt__ConditionalToggle_HousePower_K2Node_ComponentBoundEvent_1_OnConditionalStateChanged__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bIsActive : 1;  // 0x0(0x1)

}; 
// Function BP_Base_PowerTerminal.BP_Base_PowerTerminal_C.ReceiveTick
// Size: 0x4(Inherited: 0x4) 
struct FReceiveTick : public FReceiveTick
{
	float DeltaSeconds;  // 0x0(0x4)

}; 
// Function BP_Base_PowerTerminal.BP_Base_PowerTerminal_C.GetInteractionText
// Size: 0x38(Inherited: 0x20) 
struct FGetInteractionText : public FGetInteractionText
{
	uint8_t  Channel;  // 0x0(0x1)
	struct AActor* InstigatedBy;  // 0x8(0x8)
	struct FString OutText;  // 0x10(0x10)
	char pad_57_1 : 7;  // 0x39(0x1)
	bool CallFunc_IsEnabled_ReturnValue : 1;  // 0x20(0x1)
	struct FString CallFunc_GetLocStringText_ReturnValue;  // 0x28(0x10)

}; 
// Function BP_Base_PowerTerminal.BP_Base_PowerTerminal_C.RedrawScreen
// Size: 0x7(Inherited: 0x0) 
struct FRedrawScreen
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool CallFunc_IsEnabled_ReturnValue : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_IsEnabled_ReturnValue_2 : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool CallFunc_NotEqual_IntInt_ReturnValue : 1;  // 0x2(0x1)
	char pad_3_1 : 7;  // 0x3(0x1)
	bool CallFunc_NotEqual_IntInt_ReturnValue_2 : 1;  // 0x3(0x1)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_NotEqual_IntInt_ReturnValue_3 : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x5(0x1)
	char pad_6_1 : 7;  // 0x6(0x1)
	bool CallFunc_IsEnabled_ReturnValue_3 : 1;  // 0x6(0x1)

}; 
