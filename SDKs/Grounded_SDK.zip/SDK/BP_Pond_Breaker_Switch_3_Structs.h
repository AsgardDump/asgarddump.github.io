#pragma once 
#include "SDK.h" 
 
 
// Function BP_Pond_Breaker_Switch_3.BP_Pond_Breaker_Switch_2_C.ExecuteUbergraph_BP_Pond_Breaker_Switch_3
// Size: 0x4(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Pond_Breaker_Switch_3
{
	int32_t EntryPoint;  // 0x0(0x4)

}; 
