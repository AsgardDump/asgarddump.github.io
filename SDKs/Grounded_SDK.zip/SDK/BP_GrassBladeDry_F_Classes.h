#pragma once 
#include <BP_GrassBladeDry_F_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_GrassBladeDry_F.BP_GrassBladeDry_F_C
// Size: 0x478(Inherited: 0x478) 
struct ABP_GrassBladeDry_F_C : public ABP_GrassBlade_F_C
{

}; 



