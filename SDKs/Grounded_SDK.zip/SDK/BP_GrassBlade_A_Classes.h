#pragma once 
#include <BP_GrassBlade_A_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_GrassBlade_A.BP_GrassBlade_A_C
// Size: 0x468(Inherited: 0x429) 
struct ABP_GrassBlade_A_C : public ABP_BASE_GrassBlade_C
{
	char pad_1065[7];  // 0x429(0x7)
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x430(0x8)
	struct UParticleSystemSpawnComponent* BreakParticles2;  // 0x438(0x8)
	struct UParticleSystemSpawnComponent* BreakParticles1;  // 0x440(0x8)
	struct UClimbableSplineComponent* ClimbableSpline;  // 0x448(0x8)
	struct UStaticMeshComponent* SM_Grass_Blade_Chunk_Mid;  // 0x450(0x8)
	struct UStaticMeshComponent* SM_Grass_Blade_Chunk_Left;  // 0x458(0x8)
	struct UStaticMeshComponent* SM_Grass_Blade_Chunk_Right;  // 0x460(0x8)

	void ReceiveBeginPlay(); // Function BP_GrassBlade_A.BP_GrassBlade_A_C.ReceiveBeginPlay
	void HandleLootSpawnVisuals(); // Function BP_GrassBlade_A.BP_GrassBlade_A_C.HandleLootSpawnVisuals
	void ExecuteUbergraph_BP_GrassBlade_A(int32_t EntryPoint); // Function BP_GrassBlade_A.BP_GrassBlade_A_C.ExecuteUbergraph_BP_GrassBlade_A
}; 



