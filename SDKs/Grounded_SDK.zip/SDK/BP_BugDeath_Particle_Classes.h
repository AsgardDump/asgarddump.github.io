#pragma once 
#include <BP_BugDeath_Particle_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_BugDeath_Particle.BP_BugDeath_Particle_C
// Size: 0x279(Inherited: 0x238) 
struct ABP_BugDeath_Particle_C : public AVFXActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x238(0x8)
	struct USceneComponent* Root;  // 0x240(0x8)
	struct UParticleSystemComponent* P_Bug_Juice_A;  // 0x248(0x8)
	float FadeStartDelay;  // 0x250(0x4)
	float Fade Duration;  // 0x254(0x4)
	struct UDecalComponent* SpawnedDecal;  // 0x258(0x8)
	struct FLinearColor DecalColor;  // 0x260(0x10)
	struct UMaterialInterface* Decal Material;  // 0x270(0x8)
	char pad_632_1 : 7;  // 0x278(0x1)
	bool TimerFade : 1;  // 0x278(0x1)

	void FadeOutDecal(); // Function BP_BugDeath_Particle.BP_BugDeath_Particle_C.FadeOutDecal
	void FadeDecalParentCall(struct AActor* DestroyedActor); // Function BP_BugDeath_Particle.BP_BugDeath_Particle_C.FadeDecalParentCall
	void ReceiveBeginPlay(); // Function BP_BugDeath_Particle.BP_BugDeath_Particle_C.ReceiveBeginPlay
	void ExecuteUbergraph_BP_BugDeath_Particle(int32_t EntryPoint); // Function BP_BugDeath_Particle.BP_BugDeath_Particle_C.ExecuteUbergraph_BP_BugDeath_Particle
}; 



