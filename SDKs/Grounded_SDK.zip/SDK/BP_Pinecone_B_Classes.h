#pragma once 
#include <BP_Pinecone_B_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Pinecone_B.BP_Pinecone_B_C
// Size: 0x460(Inherited: 0x420) 
struct ABP_Pinecone_B_C : public ABP_ToppleHarvestNode_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x420(0x8)
	struct UStaticMeshComponent* SM_Pinecone_Piece_H;  // 0x428(0x8)
	struct UStaticMeshComponent* SM_Pinecone_Piece_G;  // 0x430(0x8)
	struct UStaticMeshComponent* SM_Pinecone_Piece_F;  // 0x438(0x8)
	struct UStaticMeshComponent* SM_Pinecone_Piece_E;  // 0x440(0x8)
	struct UStaticMeshComponent* SM_Pinecone_Piece_D;  // 0x448(0x8)
	struct UStaticMeshComponent* SM_Pinecone_Piece_C;  // 0x450(0x8)
	struct UStaticMeshComponent* SM_Pinecone_Piece_B;  // 0x458(0x8)

	void ReceiveBeginPlay(); // Function BP_Pinecone_B.BP_Pinecone_B_C.ReceiveBeginPlay
	void ExecuteUbergraph_BP_Pinecone_B(int32_t EntryPoint); // Function BP_Pinecone_B.BP_Pinecone_B_C.ExecuteUbergraph_BP_Pinecone_B
}; 



