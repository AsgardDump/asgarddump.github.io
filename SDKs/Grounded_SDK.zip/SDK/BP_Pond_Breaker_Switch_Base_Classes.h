#pragma once 
#include <BP_Pond_Breaker_Switch_Base_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Pond_Breaker_Switch_Base.BP_Pond_Breaker_Switch_Base_C
// Size: 0x454(Inherited: 0x319) 
struct ABP_Pond_Breaker_Switch_Base_C : public ABP_Power_Switch_C
{
	char pad_793[7];  // 0x319(0x7)
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x320(0x8)
	struct UConditionalToggleComponent* ConditionalToggle_Vis_PostPowerSurge_Off;  // 0x328(0x8)
	struct UConditionalToggleComponent* ConditionalToggle_Vis_PrePowerSurge;  // 0x330(0x8)
	struct UConditionalToggleComponent* ConditionalToggle_Vis_PostPowerSurge_On;  // 0x338(0x8)
	struct UPointLightComponent* PointLight;  // 0x340(0x8)
	struct UStaticMeshComponent* Light_M2;  // 0x348(0x8)
	struct USceneComponent* ParticleSpawn03;  // 0x350(0x8)
	struct USceneComponent* ParticleSpawn02;  // 0x358(0x8)
	struct USceneComponent* ParticleSpawn01;  // 0x360(0x8)
	struct UStaticMeshComponent* Switch;  // 0x368(0x8)
	struct UStaticMeshComponent* SwitchHousing;  // 0x370(0x8)
	float Anim_InnerDialRotation_SwitchBarMovement_85AEB6E249CCF57A373562851B80BE80;  // 0x378(0x4)
	char ETimelineDirection Anim_InnerDialRotation__Direction_85AEB6E249CCF57A373562851B80BE80;  // 0x37C(0x1)
	char pad_893[3];  // 0x37D(0x3)
	struct UTimelineComponent* Anim_InnerDialRotation;  // 0x380(0x8)
	struct FRotator SwitchStartRotation;  // 0x388(0xC)
	struct FRotator SwitchEndRotation;  // 0x394(0xC)
	struct FLinearColor BaseLightColorValue;  // 0x3A0(0x10)
	struct FLinearColor RedLightValue;  // 0x3B0(0x10)
	struct TArray<struct USoundBase*> Sparks sound;  // 0x3C0(0x10)
	struct ABP_PowerConverterPondLab_C* PowerConverter;  // 0x3D0(0x8)
	struct TArray<struct ABP_Fan_B_C*> ConnectedFans;  // 0x3D8(0x10)
	struct FLocString InteractionText;  // 0x3E8(0x10)
	struct UMaterialInstanceDynamic* EmissiveMID;  // 0x3F8(0x8)
	float LightIntensity;  // 0x400(0x4)
	struct FLinearColor GlowColor01_Enabled;  // 0x404(0x10)
	struct FLinearColor GlowColor02_Enabled;  // 0x414(0x10)
	char pad_1060_1 : 7;  // 0x424(0x1)
	bool OnState : 1;  // 0x424(0x1)
	char pad_1061[3];  // 0x425(0x3)
	struct UMaterialInstanceDynamic* Switch_Casing_MID;  // 0x428(0x8)
	int32_t BreakerID;  // 0x430(0x4)
	struct FLinearColor GlowColor01_Disabled;  // 0x434(0x10)
	struct FLinearColor GlowColor02_Disabled;  // 0x444(0x10)

	char EInteractionState IsInteractionEnabled(uint8_t  Channel, struct AActor* InstigatedBy); // Function BP_Pond_Breaker_Switch_Base.BP_Pond_Breaker_Switch_Base_C.IsInteractionEnabled
	void GetInteractionText(uint8_t  Channel, struct AActor* InstigatedBy, struct FString& OutText); // Function BP_Pond_Breaker_Switch_Base.BP_Pond_Breaker_Switch_Base_C.GetInteractionText
	void UserConstructionScript(); // Function BP_Pond_Breaker_Switch_Base.BP_Pond_Breaker_Switch_Base_C.UserConstructionScript
	void Anim_InnerDialRotation__FinishedFunc(); // Function BP_Pond_Breaker_Switch_Base.BP_Pond_Breaker_Switch_Base_C.Anim_InnerDialRotation__FinishedFunc
	void Anim_InnerDialRotation__UpdateFunc(); // Function BP_Pond_Breaker_Switch_Base.BP_Pond_Breaker_Switch_Base_C.Anim_InnerDialRotation__UpdateFunc
	void Light Off(); // Function BP_Pond_Breaker_Switch_Base.BP_Pond_Breaker_Switch_Base_C.Light Off
	void LightOn(bool IsEnabled); // Function BP_Pond_Breaker_Switch_Base.BP_Pond_Breaker_Switch_Base_C.LightOn
	void OnOpenStateChanged(bool IsOpen, struct AActor* ActorInstigator); // Function BP_Pond_Breaker_Switch_Base.BP_Pond_Breaker_Switch_Base_C.OnOpenStateChanged
	void ReceiveBeginPlay(); // Function BP_Pond_Breaker_Switch_Base.BP_Pond_Breaker_Switch_Base_C.ReceiveBeginPlay
	void BndEvt__ConditionalToggle_IsOn_K2Node_ComponentBoundEvent_0_OnConditionalStateChanged__DelegateSignature(bool bIsActive); // Function BP_Pond_Breaker_Switch_Base.BP_Pond_Breaker_Switch_Base_C.BndEvt__ConditionalToggle_IsOn_K2Node_ComponentBoundEvent_0_OnConditionalStateChanged__DelegateSignature
	void ToggleConnectedFans(bool ToggleOn); // Function BP_Pond_Breaker_Switch_Base.BP_Pond_Breaker_Switch_Base_C.ToggleConnectedFans
	void ToggleIsOnGlobalVariableImplementation(); // Function BP_Pond_Breaker_Switch_Base.BP_Pond_Breaker_Switch_Base_C.ToggleIsOnGlobalVariableImplementation
	void BndEvt__ConditionalToggle_Vis_PostPowerSurge_Off_K2Node_ComponentBoundEvent_2_OnConditionalStateChanged__DelegateSignature(bool bIsActive); // Function BP_Pond_Breaker_Switch_Base.BP_Pond_Breaker_Switch_Base_C.BndEvt__ConditionalToggle_Vis_PostPowerSurge_Off_K2Node_ComponentBoundEvent_2_OnConditionalStateChanged__DelegateSignature
	void PanelEmissiveOn(); // Function BP_Pond_Breaker_Switch_Base.BP_Pond_Breaker_Switch_Base_C.PanelEmissiveOn
	void PanelEmissiveEnabled(); // Function BP_Pond_Breaker_Switch_Base.BP_Pond_Breaker_Switch_Base_C.PanelEmissiveEnabled
	void PanelEmissiveDisabled(); // Function BP_Pond_Breaker_Switch_Base.BP_Pond_Breaker_Switch_Base_C.PanelEmissiveDisabled
	void OnUpdateVisualState(bool IsOpen); // Function BP_Pond_Breaker_Switch_Base.BP_Pond_Breaker_Switch_Base_C.OnUpdateVisualState
	void PlayOpenSound(); // Function BP_Pond_Breaker_Switch_Base.BP_Pond_Breaker_Switch_Base_C.PlayOpenSound
	void EvaluatePanelVFX(); // Function BP_Pond_Breaker_Switch_Base.BP_Pond_Breaker_Switch_Base_C.EvaluatePanelVFX
	void ExecuteUbergraph_BP_Pond_Breaker_Switch_Base(int32_t EntryPoint); // Function BP_Pond_Breaker_Switch_Base.BP_Pond_Breaker_Switch_Base_C.ExecuteUbergraph_BP_Pond_Breaker_Switch_Base
}; 



