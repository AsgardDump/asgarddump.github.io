#pragma once 
#include <BP_Lint_Node_A_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Lint_Node_A.BP_Lint_Node_A_C
// Size: 0x370(Inherited: 0x368) 
struct ABP_Lint_Node_A_C : public ABP_StaticHarvestNode_C
{
	struct UVisualStateComponent* VisualState;  // 0x368(0x8)

}; 



