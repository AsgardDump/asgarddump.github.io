#pragma once 
#include "SDK.h" 
 
 
// Function BP_MainMenuGameMode.BP_MainMenuGameMode_C.K2_PostLogin
// Size: 0x8(Inherited: 0x8) 
struct FK2_PostLogin : public FK2_PostLogin
{
	struct APlayerController* NewPlayer;  // 0x0(0x8)

}; 
// Function BP_MainMenuGameMode.BP_MainMenuGameMode_C.ExecuteUbergraph_BP_MainMenuGameMode
// Size: 0x10(Inherited: 0x0) 
struct FExecuteUbergraph_BP_MainMenuGameMode
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct APlayerController* K2Node_Event_NewPlayer;  // 0x8(0x8)

}; 
