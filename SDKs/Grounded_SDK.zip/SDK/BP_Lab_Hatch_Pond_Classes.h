#pragma once 
#include <BP_Lab_Hatch_Pond_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Lab_Hatch_Pond.BP_Lab_Hatch_Pond_C
// Size: 0x338(Inherited: 0x288) 
struct ABP_Lab_Hatch_Pond_C : public ADoor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x288(0x8)
	struct UAudioComponent* HatchAudio;  // 0x290(0x8)
	struct UConditionalToggleComponent* ConditionalToggle_HatchOpen;  // 0x298(0x8)
	struct UStaticMeshComponent* TS_Lab_Hatch_A_03;  // 0x2A0(0x8)
	struct UStaticMeshComponent* TS_Lab_Hatch_A_08;  // 0x2A8(0x8)
	struct UStaticMeshComponent* TS_Lab_Hatch_A_05;  // 0x2B0(0x8)
	struct UStaticMeshComponent* TS_Lab_Hatch_A_06;  // 0x2B8(0x8)
	struct UStaticMeshComponent* TS_Lab_Hatch_A_07;  // 0x2C0(0x8)
	struct UStaticMeshComponent* TS_Lab_Hatch_A_07_Dummy;  // 0x2C8(0x8)
	struct UStaticMeshComponent* TS_Lab_Hatch_A_08_Dummy;  // 0x2D0(0x8)
	struct UStaticMeshComponent* TS_Lab_Hatch_A_06_Dummy;  // 0x2D8(0x8)
	struct UStaticMeshComponent* TS_Lab_Hatch_A_05_Dummy;  // 0x2E0(0x8)
	struct UStaticMeshComponent* TS_Lab_Hatch_A_03_Dummy;  // 0x2E8(0x8)
	struct UStaticMeshComponent* TS_Lab_Hatch_A_02;  // 0x2F0(0x8)
	struct UStaticMeshComponent* TS_Lab_Hatch_A_02_Dummy;  // 0x2F8(0x8)
	struct UStaticMeshComponent* TS_Lab_Hatch_A_01;  // 0x300(0x8)
	struct UStaticMeshComponent* TS_Lab_Hatch_A_01_Dummy;  // 0x308(0x8)
	struct UStaticMeshComponent* TS_Lab_Hatch_A_04;  // 0x310(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x318(0x8)
	float HatchRotation_Door_Open_26E3EACC4CC9265A1508878F25153765;  // 0x320(0x4)
	float HatchRotation_Rotator_02_26E3EACC4CC9265A1508878F25153765;  // 0x324(0x4)
	float HatchRotation_Rotator_01_26E3EACC4CC9265A1508878F25153765;  // 0x328(0x4)
	char ETimelineDirection HatchRotation__Direction_26E3EACC4CC9265A1508878F25153765;  // 0x32C(0x1)
	char pad_813[3];  // 0x32D(0x3)
	struct UTimelineComponent* HatchRotation;  // 0x330(0x8)

	char EInteractionState IsInteractionEnabled(uint8_t  Channel, struct AActor* InstigatedBy); // Function BP_Lab_Hatch_Pond.BP_Lab_Hatch_Pond_C.IsInteractionEnabled
	void HatchRotation__FinishedFunc(); // Function BP_Lab_Hatch_Pond.BP_Lab_Hatch_Pond_C.HatchRotation__FinishedFunc
	void HatchRotation__UpdateFunc(); // Function BP_Lab_Hatch_Pond.BP_Lab_Hatch_Pond_C.HatchRotation__UpdateFunc
	void OpenHatch(); // Function BP_Lab_Hatch_Pond.BP_Lab_Hatch_Pond_C.OpenHatch
	void BndEvt__ConditionalToggle_HatchOpened_K2Node_ComponentBoundEvent_2_OnConditionalStateChanged__DelegateSignature(bool bIsActive); // Function BP_Lab_Hatch_Pond.BP_Lab_Hatch_Pond_C.BndEvt__ConditionalToggle_HatchOpened_K2Node_ComponentBoundEvent_2_OnConditionalStateChanged__DelegateSignature
	void ReceiveBeginPlay(); // Function BP_Lab_Hatch_Pond.BP_Lab_Hatch_Pond_C.ReceiveBeginPlay
	void ExecuteUbergraph_BP_Lab_Hatch_Pond(int32_t EntryPoint); // Function BP_Lab_Hatch_Pond.BP_Lab_Hatch_Pond_C.ExecuteUbergraph_BP_Lab_Hatch_Pond
}; 



