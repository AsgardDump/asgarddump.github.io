#pragma once 
#include <BP_Lab_Door_Moonpool_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Lab_Door_Moonpool.BP_Lab_Door_Moonpool_C
// Size: 0x4F8(Inherited: 0x489) 
struct ABP_Lab_Door_Moonpool_C : public ABP_Lab_Door_A_C
{
	char pad_1161[7];  // 0x489(0x7)
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x490(0x8)
	struct UAudioComponent* S_Door_Lp;  // 0x498(0x8)
	struct UStaticMeshComponent* SM_Moonpool_Door_B_02;  // 0x4A0(0x8)
	struct UStaticMeshComponent* SM_Moonpool_Door_A_02;  // 0x4A8(0x8)
	struct UStaticMeshComponent* SM_Moonpool_Door_B_01;  // 0x4B0(0x8)
	struct UStaticMeshComponent* SM_Moonpool_Door_A_01;  // 0x4B8(0x8)
	struct UStaticMeshComponent* SM_Moonpool_Door_C_02;  // 0x4C0(0x8)
	struct UStaticMeshComponent* SM_Moonpool_Door_C_01;  // 0x4C8(0x8)
	float Moonpool_Timeline_Audio_SoundPitch_2ADDACD64DEC96E2ACD7DCB24B1C0477;  // 0x4D0(0x4)
	float Moonpool_Timeline_NewTrack_6_2ADDACD64DEC96E2ACD7DCB24B1C0477;  // 0x4D4(0x4)
	float Moonpool_Timeline_Door_C_02_2ADDACD64DEC96E2ACD7DCB24B1C0477;  // 0x4D8(0x4)
	float Moonpool_Timeline_Door_C_01_2ADDACD64DEC96E2ACD7DCB24B1C0477;  // 0x4DC(0x4)
	float Moonpool_Timeline_Door_B_01_2ADDACD64DEC96E2ACD7DCB24B1C0477;  // 0x4E0(0x4)
	float Moonpool_Timeline_Door_A_01_2ADDACD64DEC96E2ACD7DCB24B1C0477;  // 0x4E4(0x4)
	char ETimelineDirection Moonpool_Timeline__Direction_2ADDACD64DEC96E2ACD7DCB24B1C0477;  // 0x4E8(0x1)
	char pad_1257[7];  // 0x4E9(0x7)
	struct UTimelineComponent* Moonpool_Timeline;  // 0x4F0(0x8)

	void UserConstructionScript(); // Function BP_Lab_Door_Moonpool.BP_Lab_Door_Moonpool_C.UserConstructionScript
	void Moonpool_Timeline__FinishedFunc(); // Function BP_Lab_Door_Moonpool.BP_Lab_Door_Moonpool_C.Moonpool_Timeline__FinishedFunc
	void Moonpool_Timeline__UpdateFunc(); // Function BP_Lab_Door_Moonpool.BP_Lab_Door_Moonpool_C.Moonpool_Timeline__UpdateFunc
	void Moonpool_Timeline__AudioEvent_Impacts__EventFunc(); // Function BP_Lab_Door_Moonpool.BP_Lab_Door_Moonpool_C.Moonpool_Timeline__AudioEvent_Impacts__EventFunc
	void Moonpool_Timeline__AudioEvent_End__EventFunc(); // Function BP_Lab_Door_Moonpool.BP_Lab_Door_Moonpool_C.Moonpool_Timeline__AudioEvent_End__EventFunc
	void Moonpool_Timeline__AudioEvent_Begin__EventFunc(); // Function BP_Lab_Door_Moonpool.BP_Lab_Door_Moonpool_C.Moonpool_Timeline__AudioEvent_Begin__EventFunc
	void OnCloseDoor(); // Function BP_Lab_Door_Moonpool.BP_Lab_Door_Moonpool_C.OnCloseDoor
	void OnOpenDoor(); // Function BP_Lab_Door_Moonpool.BP_Lab_Door_Moonpool_C.OnOpenDoor
	void ExecuteUbergraph_BP_Lab_Door_Moonpool(int32_t EntryPoint); // Function BP_Lab_Door_Moonpool.BP_Lab_Door_Moonpool_C.ExecuteUbergraph_BP_Lab_Door_Moonpool
}; 



