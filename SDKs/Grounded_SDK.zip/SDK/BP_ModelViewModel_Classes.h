#pragma once 
#include <BP_ModelViewModel_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_ModelViewModel.BP_ModelViewModel_C
// Size: 0x260(Inherited: 0x230) 
struct ABP_ModelViewModel_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x230(0x8)
	struct USkeletalMeshComponent* ChildArmorMesh;  // 0x238(0x8)
	struct USkeletalMeshComponent* SkeletalMesh;  // 0x240(0x8)
	struct UStaticMeshComponent* StaticMesh;  // 0x248(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x250(0x8)
	struct USkeletalMeshComponent* PetArmorMesh;  // 0x258(0x8)

	void GetSkeletalMeshBounds(struct FVector& Bounds); // Function BP_ModelViewModel.BP_ModelViewModel_C.GetSkeletalMeshBounds
	void GetMeshBounds(struct FVector& BoundsMin); // Function BP_ModelViewModel.BP_ModelViewModel_C.GetMeshBounds
	void SetStaticMesh(struct UStaticMesh* StaticMesh, struct TArray<struct UMaterialInterface*>& Materials, bool CenterMeshAtRotationOrigin); // Function BP_ModelViewModel.BP_ModelViewModel_C.SetStaticMesh
	void SetSkeletalMesh(struct USkeletalMesh* SkeletalMesh, struct TArray<struct UMaterialInterface*>& Materials, bool CenterMeshAtRotationOrigin); // Function BP_ModelViewModel.BP_ModelViewModel_C.SetSkeletalMesh
	void AddChildMesh(struct USkeletalMesh* SkeletalMesh); // Function BP_ModelViewModel.BP_ModelViewModel_C.AddChildMesh
	void ExecuteUbergraph_BP_ModelViewModel(int32_t EntryPoint); // Function BP_ModelViewModel.BP_ModelViewModel_C.ExecuteUbergraph_BP_ModelViewModel
}; 



