#pragma once 
#include <BP_InsectPart_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_InsectPart.BP_InsectPart_C
// Size: 0x2A3(Inherited: 0x230) 
struct ABP_InsectPart_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x230(0x8)
	struct USceneComponent* Root;  // 0x238(0x8)
	struct UStaticMeshComponent* InsectPartMesh;  // 0x240(0x8)
	float CableDissolve_CableDissolveAmount_268F75E34A028FE0D6EFCFA9583DE26D;  // 0x248(0x4)
	char ETimelineDirection CableDissolve__Direction_268F75E34A028FE0D6EFCFA9583DE26D;  // 0x24C(0x1)
	char pad_589[3];  // 0x24D(0x3)
	struct UTimelineComponent* CableDissolve;  // 0x250(0x8)
	float TL_CreatureDissolve_DissolveAmount_4ECC820247A457E5C29F54BEFA4543ED;  // 0x258(0x4)
	char ETimelineDirection TL_CreatureDissolve__Direction_4ECC820247A457E5C29F54BEFA4543ED;  // 0x25C(0x1)
	char pad_605[3];  // 0x25D(0x3)
	struct UTimelineComponent* TL_CreatureDissolve;  // 0x260(0x8)
	struct TArray<struct UMaterialInstanceDynamic*> InsectPartMIDs;  // 0x268(0x10)
	struct TArray<struct UCableComponent*> InsectPartCables;  // 0x278(0x10)
	struct UMaterialInstanceDynamic* CableMID;  // 0x288(0x8)
	struct UParticleSystem* GoopEmitter;  // 0x290(0x8)
	float ShortTimer;  // 0x298(0x4)
	float FallbackTimer;  // 0x29C(0x4)
	char pad_672_1 : 7;  // 0x2A0(0x1)
	bool DissolveOnRest : 1;  // 0x2A0(0x1)
	char pad_673_1 : 7;  // 0x2A1(0x1)
	bool IsDissolving : 1;  // 0x2A1(0x1)
	char pad_674_1 : 7;  // 0x2A2(0x1)
	bool bInWater : 1;  // 0x2A2(0x1)

	void TL_CreatureDissolve__FinishedFunc(); // Function BP_InsectPart.BP_InsectPart_C.TL_CreatureDissolve__FinishedFunc
	void TL_CreatureDissolve__UpdateFunc(); // Function BP_InsectPart.BP_InsectPart_C.TL_CreatureDissolve__UpdateFunc
	void CableDissolve__FinishedFunc(); // Function BP_InsectPart.BP_InsectPart_C.CableDissolve__FinishedFunc
	void CableDissolve__UpdateFunc(); // Function BP_InsectPart.BP_InsectPart_C.CableDissolve__UpdateFunc
	void ReceiveBeginPlay(); // Function BP_InsectPart.BP_InsectPart_C.ReceiveBeginPlay
	void BndEvt__InsectPartMesh_K2Node_ComponentBoundEvent_0_ComponentSleepSignature__DelegateSignature(struct UPrimitiveComponent* SleepingComponent, struct FName BoneName); // Function BP_InsectPart.BP_InsectPart_C.BndEvt__InsectPartMesh_K2Node_ComponentBoundEvent_0_ComponentSleepSignature__DelegateSignature
	void DissolveAfterShortTimer(); // Function BP_InsectPart.BP_InsectPart_C.DissolveAfterShortTimer
	void DissolveAfterFallbackTimer(); // Function BP_InsectPart.BP_InsectPart_C.DissolveAfterFallbackTimer
	void ReceiveActorBeginOverlap(struct AActor* OtherActor); // Function BP_InsectPart.BP_InsectPart_C.ReceiveActorBeginOverlap
	void ReceiveActorEndOverlap(struct AActor* OtherActor); // Function BP_InsectPart.BP_InsectPart_C.ReceiveActorEndOverlap
	void ReceiveTick(float DeltaSeconds); // Function BP_InsectPart.BP_InsectPart_C.ReceiveTick
	void ExecuteUbergraph_BP_InsectPart(int32_t EntryPoint); // Function BP_InsectPart.BP_InsectPart_C.ExecuteUbergraph_BP_InsectPart
}; 



