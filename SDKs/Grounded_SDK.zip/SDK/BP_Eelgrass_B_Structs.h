#pragma once 
#include "SDK.h" 
 
 
// Function BP_Eelgrass_B.BP_Eelgrass_B_C.ExecuteUbergraph_BP_Eelgrass_B
// Size: 0x4(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Eelgrass_B
{
	int32_t EntryPoint;  // 0x0(0x4)

}; 
