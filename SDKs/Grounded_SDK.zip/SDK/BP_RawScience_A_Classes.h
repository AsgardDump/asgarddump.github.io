#pragma once 
#include <BP_RawScience_A_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_RawScience_A.BP_RawScience_A_C
// Size: 0x36C(Inherited: 0x2A8) 
struct ABP_RawScience_A_C : public AScienceCollectable
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x2A8(0x8)
	struct UStaticMeshComponent* ZigZag;  // 0x2B0(0x8)
	struct UStaticMeshComponent* Triangle2;  // 0x2B8(0x8)
	struct UStaticMeshComponent* Triangle1;  // 0x2C0(0x8)
	struct UParticleSystemComponent* Molecules;  // 0x2C8(0x8)
	struct UStaticMeshComponent* Grid;  // 0x2D0(0x8)
	struct UStaticMeshComponent* Ball2;  // 0x2D8(0x8)
	struct UStaticMeshComponent* Ball1;  // 0x2E0(0x8)
	struct UStaticMeshComponent* Cube;  // 0x2E8(0x8)
	struct UStaticMeshComponent* Cube2;  // 0x2F0(0x8)
	struct UStaticMeshComponent* Cone;  // 0x2F8(0x8)
	struct USceneComponent* RotationPivot;  // 0x300(0x8)
	struct UForceFeedbackComponent* ScienceARumble;  // 0x308(0x8)
	struct UAudioComponent* ScienceEmitterLow;  // 0x310(0x8)
	struct UPointLightComponent* CenterLight;  // 0x318(0x8)
	struct UAudioComponent* ScienceEmitter;  // 0x320(0x8)
	struct UStaticMeshComponent* StaticMesh;  // 0x328(0x8)
	struct UTransmitterComponent* Transmitter;  // 0x330(0x8)
	float Timeline_0_ScaleChange_BEC0E6374BB217E20C7A3D8571F195EE;  // 0x338(0x4)
	char ETimelineDirection Timeline_0__Direction_BEC0E6374BB217E20C7A3D8571F195EE;  // 0x33C(0x1)
	char pad_829[3];  // 0x33D(0x3)
	struct UTimelineComponent* Timeline_1;  // 0x340(0x8)
	float Bounce;  // 0x348(0x4)
	float Time;  // 0x34C(0x4)
	struct FVector ZigZagScale;  // 0x350(0xC)
	char pad_860_1 : 7;  // 0x35C(0x1)
	bool ScienceCollected : 1;  // 0x35C(0x1)
	char pad_861_1 : 7;  // 0x35D(0x1)
	bool TimelineActive : 1;  // 0x35D(0x1)
	char pad_862[2];  // 0x35E(0x2)
	float RandomRotX;  // 0x360(0x4)
	float RandomRotY;  // 0x364(0x4)
	float RandomRotZ;  // 0x368(0x4)

	void Timeline_0__FinishedFunc(); // Function BP_RawScience_A.BP_RawScience_A_C.Timeline_0__FinishedFunc
	void Timeline_0__UpdateFunc(); // Function BP_RawScience_A.BP_RawScience_A_C.Timeline_0__UpdateFunc
	void ReceiveBeginPlay(); // Function BP_RawScience_A.BP_RawScience_A_C.ReceiveBeginPlay
	void OnCollectedEvent(struct ASurvivalPlayerCharacter* Character); // Function BP_RawScience_A.BP_RawScience_A_C.OnCollectedEvent
	void ReceiveTick(float DeltaSeconds); // Function BP_RawScience_A.BP_RawScience_A_C.ReceiveTick
	void CreateRandomRotatorInRange(); // Function BP_RawScience_A.BP_RawScience_A_C.CreateRandomRotatorInRange
	void ExecuteUbergraph_BP_RawScience_A(int32_t EntryPoint); // Function BP_RawScience_A.BP_RawScience_A_C.ExecuteUbergraph_BP_RawScience_A
}; 



