#pragma once 
#include "SDK.h" 
 
 
// Function BP_ResourceAnalyzer.BP_ResourceAnalyzer_C.Interact
// Size: 0x10(Inherited: 0x10) 
struct FInteract : public FInteract
{
	uint8_t  Channel;  // 0x0(0x1)
	struct AActor* InstigatedBy;  // 0x8(0x8)

}; 
// Function BP_ResourceAnalyzer.BP_ResourceAnalyzer_C.ExecuteUbergraph_BP_ResourceAnalyzer
// Size: 0x10(Inherited: 0x0) 
struct FExecuteUbergraph_BP_ResourceAnalyzer
{
	int32_t EntryPoint;  // 0x0(0x4)
	uint8_t  K2Node_Event_Channel;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct AActor* K2Node_Event_InstigatedBy;  // 0x8(0x8)

}; 
// Function BP_ResourceAnalyzer.BP_ResourceAnalyzer_C.GetInteractionText
// Size: 0x30(Inherited: 0x20) 
struct FGetInteractionText : public FGetInteractionText
{
	uint8_t  Channel;  // 0x0(0x1)
	struct AActor* InstigatedBy;  // 0x8(0x8)
	struct FString OutText;  // 0x10(0x10)
	struct FString CallFunc_GetLocStringText_ReturnValue;  // 0x20(0x10)

}; 
