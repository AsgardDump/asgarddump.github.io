#pragma once 
#include <BP_Hedge_Leaf_A_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Hedge_Leaf_A.BP_Hedge_Leaf_A_C
// Size: 0x258(Inherited: 0x248) 
struct ABP_Hedge_Leaf_A_C : public ALODableActor
{
	struct UStaticMeshComponent* StaticMesh;  // 0x248(0x8)
	struct UAttractionComponent* Attraction;  // 0x250(0x8)

}; 



