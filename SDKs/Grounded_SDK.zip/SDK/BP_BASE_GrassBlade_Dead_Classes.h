#pragma once 
#include <BP_BASE_GrassBlade_Dead_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_BASE_GrassBlade_Dead.BP_BASE_GrassBlade_Dead_C
// Size: 0x418(Inherited: 0x368) 
struct ABP_BASE_GrassBlade_Dead_C : public ABP_StaticHarvestNode_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x368(0x8)
	float TL_DissolveGrassBlade_DissolveAmount_74D4A8B0433AE235136BBFB664527F55;  // 0x370(0x4)
	char ETimelineDirection TL_DissolveGrassBlade__Direction_74D4A8B0433AE235136BBFB664527F55;  // 0x374(0x1)
	char pad_885[3];  // 0x375(0x3)
	struct UTimelineComponent* TL_DissolveGrassBlade;  // 0x378(0x8)
	char pad_896_1 : 7;  // 0x380(0x1)
	bool DeathTriggered : 1;  // 0x380(0x1)
	char pad_897[7];  // 0x381(0x7)
	struct FDamageInfo DamageInfo;  // 0x388(0x68)
	struct UParticleSystem* DestroyedEmitter;  // 0x3F0(0x8)
	struct TArray<struct FTransform> SocketTransforms;  // 0x3F8(0x10)
	struct TArray<struct UMaterialInstanceDynamic*> MID_Array;  // 0x408(0x10)

	void OnRep_DeathTriggered(); // Function BP_BASE_GrassBlade_Dead.BP_BASE_GrassBlade_Dead_C.OnRep_DeathTriggered
	void TL_DissolveGrassBlade__FinishedFunc(); // Function BP_BASE_GrassBlade_Dead.BP_BASE_GrassBlade_Dead_C.TL_DissolveGrassBlade__FinishedFunc
	void TL_DissolveGrassBlade__UpdateFunc(); // Function BP_BASE_GrassBlade_Dead.BP_BASE_GrassBlade_Dead_C.TL_DissolveGrassBlade__UpdateFunc
	void Handle Death(struct FDamageInfo DamageInfo); // Function BP_BASE_GrassBlade_Dead.BP_BASE_GrassBlade_Dead_C.Handle Death
	void HandleDeathEffects(); // Function BP_BASE_GrassBlade_Dead.BP_BASE_GrassBlade_Dead_C.HandleDeathEffects
	void ExecuteUbergraph_BP_BASE_GrassBlade_Dead(int32_t EntryPoint); // Function BP_BASE_GrassBlade_Dead.BP_BASE_GrassBlade_Dead_C.ExecuteUbergraph_BP_BASE_GrassBlade_Dead
}; 



