#pragma once 
#include <BP_GrassBladeDry_D_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_GrassBladeDry_D.BP_GrassBladeDry_D_C
// Size: 0x468(Inherited: 0x468) 
struct ABP_GrassBladeDry_D_C : public ABP_GrassBlade_D_C
{

}; 



