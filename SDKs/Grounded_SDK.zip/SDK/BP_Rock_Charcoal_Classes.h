#pragma once 
#include <BP_Rock_Charcoal_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Rock_Charcoal.BP_Rock_Charcoal_C
// Size: 0x3A8(Inherited: 0x390) 
struct ABP_Rock_Charcoal_C : public ABP_BASE_Rock_C
{
	struct UParticleSystemComponent* PS_Smoke;  // 0x390(0x8)
	struct UPointLightComponent* PointLight;  // 0x398(0x8)
	struct UVisualStateComponent* VisualState;  // 0x3A0(0x8)

}; 



