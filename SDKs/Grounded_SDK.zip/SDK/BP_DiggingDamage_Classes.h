#pragma once 
#include <BP_DiggingDamage_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_DiggingDamage.BP_DiggingDamage_C
// Size: 0x78(Inherited: 0x78) 
struct UBP_DiggingDamage_C : public USurvivalDamageType
{

}; 



