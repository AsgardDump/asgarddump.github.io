#pragma once 
#include "SDK.h" 
 
 
// Function BP_ItemDuplicator.BP_ItemDuplicator_C.ExecuteUbergraph_BP_ItemDuplicator
// Size: 0x2C4(Inherited: 0x0) 
struct FExecuteUbergraph_BP_ItemDuplicator
{
	int32_t EntryPoint;  // 0x0(0x4)
	float CallFunc_Lerp_ReturnValue;  // 0x4(0x4)
	float CallFunc_Lerp_ReturnValue_2;  // 0x8(0x4)
	float CallFunc_Lerp_ReturnValue_3;  // 0xC(0x4)
	struct FVector CallFunc_MakeVector_ReturnValue;  // 0x10(0xC)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x1C(0x4)
	struct FRotator CallFunc_MakeRotator_ReturnValue;  // 0x20(0xC)
	float CallFunc_Reciprocal_Result;  // 0x2C(0x4)
	float CallFunc_Lerp_ReturnValue_4;  // 0x30(0x4)
	float CallFunc_Lerp_ReturnValue_5;  // 0x34(0x4)
	struct FVector CallFunc_Conv_FloatToVector_ReturnValue;  // 0x38(0xC)
	struct FHitResult CallFunc_K2_SetRelativeLocation_SweepHitResult;  // 0x44(0x88)
	uint8_t  K2Node_Event_Channel;  // 0xCC(0x1)
	char pad_205[3];  // 0xCD(0x3)
	struct AActor* K2Node_Event_InstigatedBy_2;  // 0xD0(0x8)
	struct ASurvivalPlayerCharacter* CallFunc_GetLocalSurvivalPlayerCharacter_ReturnValue;  // 0xD8(0x8)
	struct AActor* K2Node_Event_InstigatedBy;  // 0xE0(0x8)
	char pad_232_1 : 7;  // 0xE8(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue : 1;  // 0xE8(0x1)
	char pad_233_1 : 7;  // 0xE9(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue_2 : 1;  // 0xE9(0x1)
	char pad_234[2];  // 0xEA(0x2)
	struct FHitResult CallFunc_K2_AddWorldRotation_SweepHitResult;  // 0xEC(0x88)
	float CallFunc_Reciprocal_Result_2;  // 0x174(0x4)
	float CallFunc_MakeLiteralFloat_ReturnValue;  // 0x178(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_2;  // 0x17C(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_3;  // 0x180(0x4)
	struct FRotator CallFunc_MakeRotator_ReturnValue_2;  // 0x184(0xC)
	struct FRotator CallFunc_MakeRotator_ReturnValue_3;  // 0x190(0xC)
	struct FHitResult CallFunc_K2_SetRelativeRotation_SweepHitResult;  // 0x19C(0x88)
	struct FHitResult CallFunc_K2_SetRelativeRotation_SweepHitResult_2;  // 0x224(0x88)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x2AC(0xC)
	struct FVector CallFunc_Add_VectorVector_ReturnValue;  // 0x2B8(0xC)

}; 
// Function BP_ItemDuplicator.BP_ItemDuplicator_C.GetUseVolume
// Size: 0x8(Inherited: 0x8) 
struct FGetUseVolume : public FGetUseVolume
{
	struct UPrimitiveComponent* ReturnValue;  // 0x0(0x8)

}; 
// Function BP_ItemDuplicator.BP_ItemDuplicator_C.UserConstructionScript
// Size: 0x8(Inherited: 0x0) 
struct FUserConstructionScript : public FUserConstructionScript
{
	struct UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue;  // 0x0(0x8)

}; 
// Function BP_ItemDuplicator.BP_ItemDuplicator_C.EndInteraction
// Size: 0x8(Inherited: 0x8) 
struct FEndInteraction : public FEndInteraction
{
	struct AActor* InstigatedBy;  // 0x0(0x8)

}; 
// Function BP_ItemDuplicator.BP_ItemDuplicator_C.HasLookAtLocation
// Size: 0x1(Inherited: 0x0) 
struct FHasLookAtLocation
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function BP_ItemDuplicator.BP_ItemDuplicator_C.EndDupeUpgrade
// Size: 0x8(Inherited: 0x0) 
struct FEndDupeUpgrade
{
	struct ASurvivalPlayerCharacter* Target;  // 0x0(0x8)

}; 
// Function BP_ItemDuplicator.BP_ItemDuplicator_C.Interact
// Size: 0x10(Inherited: 0x10) 
struct FInteract : public FInteract
{
	uint8_t  Channel;  // 0x0(0x1)
	struct AActor* InstigatedBy;  // 0x8(0x8)

}; 
// Function BP_ItemDuplicator.BP_ItemDuplicator_C.BeginDupeUpgrade
// Size: 0x8(Inherited: 0x0) 
struct FBeginDupeUpgrade
{
	struct ASurvivalPlayerCharacter* Target;  // 0x0(0x8)

}; 
// Function BP_ItemDuplicator.BP_ItemDuplicator_C.GetLookAtLocation
// Size: 0xC(Inherited: 0x0) 
struct FGetLookAtLocation
{
	struct FVector ReturnValue;  // 0x0(0xC)

}; 
// Function BP_ItemDuplicator.BP_ItemDuplicator_C.GetCameraViewTransform
// Size: 0xD0(Inherited: 0x0) 
struct FGetCameraViewTransform
{
	struct FTransform ReturnValue;  // 0x0(0x30)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool Temp_bool_Variable : 1;  // 0x30(0x1)
	char pad_49[15];  // 0x31(0xF)
	struct FTransform CallFunc_K2_GetComponentToWorld_ReturnValue;  // 0x40(0x30)
	struct FTransform CallFunc_K2_GetComponentToWorld_ReturnValue_2;  // 0x70(0x30)
	struct FTransform K2Node_Select_Default;  // 0xA0(0x30)

}; 
