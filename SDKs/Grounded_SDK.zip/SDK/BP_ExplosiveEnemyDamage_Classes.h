#pragma once 
#include <BP_ExplosiveEnemyDamage_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_ExplosiveEnemyDamage.BP_ExplosiveEnemyDamage_C
// Size: 0x78(Inherited: 0x78) 
struct UBP_ExplosiveEnemyDamage_C : public USurvivalDamageType
{

}; 



