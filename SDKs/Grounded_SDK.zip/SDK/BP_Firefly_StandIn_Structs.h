#pragma once 
#include "SDK.h" 
 
 
// Function BP_Firefly_StandIn.BP_Firefly_StandIn_C.ExecuteUbergraph_BP_Firefly_StandIn
// Size: 0x38(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Firefly_StandIn
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UCalendarComponent* CallFunc_GetCalendarComponent_ReturnValue;  // 0x8(0x8)
	int32_t CallFunc_GetHour_ReturnValue;  // 0x10(0x4)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x14(0x10)
	char pad_36_1 : 7;  // 0x24(0x1)
	bool CallFunc_LessEqual_IntInt_ReturnValue : 1;  // 0x24(0x1)
	char pad_37_1 : 7;  // 0x25(0x1)
	bool CallFunc_GreaterEqual_IntInt_ReturnValue : 1;  // 0x25(0x1)
	char pad_38_1 : 7;  // 0x26(0x1)
	bool CallFunc_BooleanOR_ReturnValue : 1;  // 0x26(0x1)
	char pad_39[1];  // 0x27(0x1)
	struct UCalendarComponent* CallFunc_GetCalendarComponent_ReturnValue_2;  // 0x28(0x8)
	int32_t K2Node_CustomEvent_NewHour;  // 0x30(0x4)
	int32_t K2Node_CustomEvent_NewDay;  // 0x34(0x4)

}; 
// Function BP_Firefly_StandIn.BP_Firefly_StandIn_C.ToggleVFX
// Size: 0x8(Inherited: 0x0) 
struct FToggleVFX
{
	int32_t NewHour;  // 0x0(0x4)
	int32_t NewDay;  // 0x4(0x4)

}; 
