#pragma once 
#include <BP_Rock_ArmorStone1_A_Large_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Rock_ArmorStone1_A_Large.BP_Rock_ArmorStone1_A_Large_C
// Size: 0x398(Inherited: 0x390) 
struct ABP_Rock_ArmorStone1_A_Large_C : public ABP_BASE_Rock_C
{
	struct UVisualStateComponent* VisualState;  // 0x390(0x8)

}; 



