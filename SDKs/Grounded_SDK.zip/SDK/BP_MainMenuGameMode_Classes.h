#pragma once 
#include <BP_MainMenuGameMode_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_MainMenuGameMode.BP_MainMenuGameMode_C
// Size: 0x2E0(Inherited: 0x2D0) 
struct ABP_MainMenuGameMode_C : public AGameModeBase
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x2D0(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x2D8(0x8)

	void K2_PostLogin(struct APlayerController* NewPlayer); // Function BP_MainMenuGameMode.BP_MainMenuGameMode_C.K2_PostLogin
	void ExecuteUbergraph_BP_MainMenuGameMode(int32_t EntryPoint); // Function BP_MainMenuGameMode.BP_MainMenuGameMode_C.ExecuteUbergraph_BP_MainMenuGameMode
}; 



