#pragma once 
#include "SDK.h" 
 
 
// Function BP_Eelgrass_C.BP_Eelgrass_C_C.ExecuteUbergraph_BP_Eelgrass_C
// Size: 0x4(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Eelgrass_C
{
	int32_t EntryPoint;  // 0x0(0x4)

}; 
