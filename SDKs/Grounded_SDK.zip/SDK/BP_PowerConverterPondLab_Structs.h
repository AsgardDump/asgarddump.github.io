#pragma once 
#include "SDK.h" 
 
 
// Function BP_PowerConverterPondLab.BP_PowerConverterPondLab_C.BndEvt__ConditionalToggle_AllBreakersOn_K2Node_ComponentBoundEvent_0_OnConditionalStateChanged__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FBndEvt__ConditionalToggle_AllBreakersOn_K2Node_ComponentBoundEvent_0_OnConditionalStateChanged__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bIsActive : 1;  // 0x0(0x1)

}; 
// Function BP_PowerConverterPondLab.BP_PowerConverterPondLab_C.ExecuteUbergraph_BP_PowerConverterPondLab
// Size: 0x38(Inherited: 0x0) 
struct FExecuteUbergraph_BP_PowerConverterPondLab
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	int32_t K2Node_CustomEvent_BreakerID;  // 0x8(0x4)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool K2Node_SwitchInteger_CmpSuccess : 1;  // 0xC(0x1)
	char pad_13_1 : 7;  // 0xD(0x1)
	bool CallFunc_HasAuthority_ReturnValue_2 : 1;  // 0xD(0x1)
	char pad_14_1 : 7;  // 0xE(0x1)
	bool K2Node_ComponentBoundEvent_bIsActive : 1;  // 0xE(0x1)
	char pad_15_1 : 7;  // 0xF(0x1)
	bool K2Node_CustomEvent_ToggleOn : 1;  // 0xF(0x1)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_HasAuthority_ReturnValue_3 : 1;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x14(0x4)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_HasAuthority_ReturnValue_4 : 1;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x1C(0x4)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x20(0x1)
	char pad_33[3];  // 0x21(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x24(0x4)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool CallFunc_IsEnabled_ReturnValue : 1;  // 0x28(0x1)
	char pad_41[3];  // 0x29(0x3)
	int32_t Temp_int_Array_Index_Variable;  // 0x2C(0x4)
	struct ABP_Fan_B_C* CallFunc_Array_Get_Item;  // 0x30(0x8)

}; 
// Function BP_PowerConverterPondLab.BP_PowerConverterPondLab_C.ToggleConnectedFans
// Size: 0x1(Inherited: 0x0) 
struct FToggleConnectedFans
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ToggleOn : 1;  // 0x0(0x1)

}; 
// Function BP_PowerConverterPondLab.BP_PowerConverterPondLab_C.LightTurnOn
// Size: 0x4(Inherited: 0x0) 
struct FLightTurnOn
{
	int32_t BreakerID;  // 0x0(0x4)

}; 
